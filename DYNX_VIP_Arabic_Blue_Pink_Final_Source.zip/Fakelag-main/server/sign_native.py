#!/usr/bin/env python3
"""
Sign and publish a native lib into the live-update store — VPS/localhost only,
never an HTTP endpoint (same trust boundary as admin.py). The Ed25519 signing key
lives only on this box; CI produces the unsigned `.so`, this signs it.

    python sign_native.py libnuvola_native.so --version 1 --semver 0.1.0 \
        [--abi arm64-v8a] [--valid-days 90] [--rollout-permille 1000] [--kill] \
        [--base-url https://66.154.107.27]

`--version` is the MONOTONIC client-facing version (assigned here, decoupled from
the git tag) and drives the client's downgrade guard. It must strictly increase.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import shutil
import sys
from pathlib import Path

from app import native
from app.settings import NATIVE_DIR, get_secrets


def _iso(dt: datetime.datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def main() -> int:
    p = argparse.ArgumentParser(description="Sign + publish a native lib")
    p.add_argument("so", help="path to the built libnuvola_native.so")
    p.add_argument("--abi", default="arm64-v8a")
    p.add_argument("--version", type=int, required=True, help="monotonic client version")
    p.add_argument("--semver", default="0.0.0")
    p.add_argument("--min-loader", type=int, default=native.CURRENT_MIN_LOADER)
    p.add_argument("--valid-days", type=int, default=90)
    p.add_argument("--rollout-permille", type=int, default=1000)
    p.add_argument("--kill", action="store_true")
    p.add_argument("--base-url", default="https://66.154.107.27")
    a = p.parse_args()

    get_secrets()  # fail fast if the signing key is missing/misconfigured

    so = Path(a.so)
    if not so.is_file():
        print(f"no such file: {so}", file=sys.stderr)
        return 2
    data = so.read_bytes()
    sha = hashlib.sha256(data).hexdigest()

    # Downgrade guard: refuse to publish a version <= the current high-water mark.
    hw_file = NATIVE_DIR / a.abi / "high_water"
    if hw_file.exists():
        try:
            hw = int(hw_file.read_text().strip())
        except ValueError:
            hw = 0
        if a.version <= hw:
            print(f"refusing: version {a.version} <= high_water {hw}", file=sys.stderr)
            return 2

    now = datetime.datetime.now(datetime.timezone.utc)
    fields = {
        "abi": a.abi,
        "version": a.version,
        "semver": a.semver,
        "sha256": sha,
        "size": len(data),
        "min_loader": a.min_loader,
        "not_before": _iso(now),
        "not_after": _iso(now + datetime.timedelta(days=a.valid_days)),
        "rollout_permille": a.rollout_permille,
        "kill": a.kill,
        "url": f"{a.base_url}/native/lib/{a.version}?abi={a.abi}",
    }
    manifest = native.sign_manifest(fields)

    # Publish: copy the lib under its version dir, then swap the manifest atomically.
    dst_dir = NATIVE_DIR / a.abi / str(a.version)
    dst_dir.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(so, dst_dir / "lib.so")

    mp = native.manifest_path(a.abi)
    mp.parent.mkdir(parents=True, exist_ok=True)
    tmp = mp.with_suffix(".json.new")
    tmp.write_text(json.dumps(manifest, indent=2))
    tmp.replace(mp)
    hw_file.write_text(str(a.version))

    print(f"published {a.abi} version={a.version} semver={a.semver} sha256={sha}")
    print(f"  lib:      {dst_dir / 'lib.so'}")
    print(f"  manifest: {mp}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
