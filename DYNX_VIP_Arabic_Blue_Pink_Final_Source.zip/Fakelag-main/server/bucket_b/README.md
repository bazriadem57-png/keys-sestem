# Bucket-B source (server-only, withheld from the APK)

Each `*.json` here is one section of the runtime config blob served by `/config`
and held only in the client's RAM. These files are the reverse-engineered
knowledge that used to ship in the APK as packed strings / constants — moving
them here removes them from a jadx decompile. See `docs/SECURITY_MODEL.md` §3.

**Phase 1 sections (extracted from the Java, then the Java table deleted):**
- `cmd_catalogue.json` — the 1974-id command name table (from
  `decode/body/CmdCatalogue.java`).
- `body_decoder_table.json` — the 1604 `(cmd,dir)` wire-layout programs (from
  `decode/body/BodyDecoderTable.java` / `BodyDecoderText.java`).

**Extraction is a client-side step, not done yet:** a small tool reads the
packed-string constants out of those two Java files and writes them here, then
the constants are removed from the Java (which becomes a thin `ConfigStore`
accessor). Until then, `sample_cmd_catalogue.json` lets the server run end to end.

Do not commit the real extracted tables if this repo is ever made public — they
are the crown jewels. They are safe to keep here while the repo is private
(`github.com/tonytranrp/Fakelag` is private), but the whole point is that they
never enter the shipped APK.
