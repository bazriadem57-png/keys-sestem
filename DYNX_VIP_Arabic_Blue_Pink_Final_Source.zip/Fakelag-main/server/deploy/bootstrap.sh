#!/usr/bin/env bash
#
# One-run VPS setup for the Nuvola backend. Run as root ON THE VPS after copying
# the server/ tree to /opt/nuvola/server (e.g. scp -r server root@HOST:/opt/nuvola/server).
#
#   ssh root@66.154.107.27
#   bash /opt/nuvola/server/deploy/bootstrap.sh
#
# It creates a service user, a venv, a self-signed TLS cert, the server signing
# key + fingerprint salt, installs the systemd unit, starts it, and PRINTS the
# two values to paste into the Android client's AuthConfig.java
# (CERT_PIN and SERVER_ED25519_PUB_HEX). Idempotent-ish: safe to re-run; it will
# not overwrite an existing server_keys.json or cert (delete them to rotate).
#
# Firewall reminder (do this yourself): allow 22 + 443 only.
set -euo pipefail

APP=/opt/nuvola
SRV="$APP/server"
IP="${NUVOLA_IP:-66.154.107.27}"

if [ ! -d "$SRV/app" ]; then
    echo "ERROR: $SRV/app not found. Copy the server/ tree to $SRV first." >&2
    exit 1
fi

echo "[1/7] packages"
apt-get update -y
apt-get install -y python3-venv openssl

echo "[2/7] service user"
id -u nuvola >/dev/null 2>&1 || useradd -r -s /usr/sbin/nologin -d "$APP" nuvola
mkdir -p "$APP/certs"

echo "[3/7] venv + deps"
[ -d "$SRV/.venv" ] || python3 -m venv "$SRV/.venv"
"$SRV/.venv/bin/pip" install -q --upgrade pip
"$SRV/.venv/bin/pip" install -q -r "$SRV/requirements.txt"

echo "[4/7] self-signed TLS cert (EC P-256, SAN=IP:$IP, ~2y)"
if [ ! -f "$APP/certs/nuvola.crt" ]; then
    openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes \
        -keyout "$APP/certs/nuvola.key" -out "$APP/certs/nuvola.crt" -days 825 \
        -subj "/CN=$IP" -addext "subjectAltName=IP:$IP"
else
    echo "     cert exists, keeping it"
fi

echo "[5/7] server signing key + salt (persistent)"
# NUVOLA_ALLOW_KEYGEN=1 explicitly permits first-time key generation; the running
# service loads the resulting server_keys.json silently and never regenerates.
( cd "$SRV" && NUVOLA_ALLOW_KEYGEN=1 "$SRV/.venv/bin/python" -c "from app.settings import get_secrets; get_secrets()" )

echo "[6/7] permissions + systemd"
chown -R nuvola:nuvola "$APP"
chmod 600 "$APP/certs/nuvola.key" "$SRV/server_keys.json"
cp "$SRV/deploy/nuvola.service" /etc/systemd/system/nuvola.service
systemctl daemon-reload
systemctl enable --now nuvola
sleep 2
systemctl --no-pager --lines=5 status nuvola || true

echo "[7/7] values for the Android client (AuthConfig.java)"
echo "-------------------------------------------------------------"
echo "CERT_PIN (paste into AuthConfig.CERT_PIN):"
openssl x509 -in "$APP/certs/nuvola.crt" -pubkey -noout \
  | openssl pkey -pubin -outform der \
  | openssl dgst -sha256 -binary \
  | openssl enc -base64 | sed 's#^#sha256/#'
echo
echo "SERVER_ED25519_PUB_HEX (paste into AuthConfig.SERVER_ED25519_PUB_HEX):"
"$SRV/.venv/bin/python" - "$SRV/server_keys.json" <<'PY'
import json, sys
from cryptography.hazmat.primitives.serialization import load_pem_private_key, Encoding, PublicFormat
d = json.load(open(sys.argv[1]))
sk = load_pem_private_key(d["ed25519_sk_pem"].encode(), None)
print(sk.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw).hex())
PY
echo
echo "TLS CERT (public — paste the whole block, including BEGIN/END, back to Claude"
echo "so the release build can trust this bare-IP cert):"
cat "$APP/certs/nuvola.crt"
echo "-------------------------------------------------------------"
echo "Done. Mint a key with:  cd $SRV && .venv/bin/python admin.py mint --devices 2"
echo "Test from your machine: curl -k https://$IP/health   (should print {\"ok\":true})"
