#!/usr/bin/env python3
"""
End-to-end client simulation — also the reference the Java client mirrors.

Run the server first:
    uvicorn app.main:app --host 127.0.0.1 --port 8000
Then:
    python test_client.py

It mints a license directly in the DB, then exercises /auth/activate,
/auth/refresh, /config (with the full ECDH → HKDF → AES-GCM unwrap), verifies
the offline lease signature, and checks that a revoked license is refused and a
replayed refresh token is caught.
"""
from __future__ import annotations

import base64
import json
import os
import secrets
import urllib.request

from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey, X25519PublicKey,
)
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes, serialization

from app import crypto
from app.db import connect, init_db, now
from app.settings import get_secrets

BASE = os.environ.get("NUVOLA_TEST_BASE", "http://127.0.0.1:8000")


def post(path, body):
    req = urllib.request.Request(
        BASE + path, data=json.dumps(body).encode(),
        headers={"content-type": "application/json"}, method="POST")
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())


def post_auth(path, body, token):
    req = urllib.request.Request(
        BASE + path, data=json.dumps(body).encode(),
        headers={"content-type": "application/json",
                 "authorization": f"Bearer {token}"}, method="POST")
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())


def jwt_payload(token: str) -> dict:
    mid = token.split(".")[1]
    mid += "=" * (-len(mid) % 4)
    return json.loads(base64.urlsafe_b64decode(mid))


def mint_key() -> str:
    key = "NVLA-" + secrets.token_hex(8).upper()
    with connect() as c:
        c.execute("INSERT INTO licenses(key_hash,tier,status,expiry,max_devices,"
                  "config_version,created_at,note) VALUES(?,?,?,?,?,?,?,?)",
                  (crypto.sha256_hex(key), "standard", "active", None, 2, 1, now(), "test"))
    return key


def main():
    init_db()
    s = get_secrets()
    key = mint_key()
    print("minted:", key)

    # Real device EC key for proof-of-possession (mirrors DeviceIdentity).
    dev_priv = ec.generate_private_key(ec.SECP256R1())
    dev_pub_b64 = base64.b64encode(dev_priv.public_key().public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo)).decode()
    fp_inputs = {"ssaid": "aaaabbbbccccdddd", "device_pubkey": dev_pub_b64}

    ch = post("/auth/challenge", {"device_pubkey": dev_pub_b64})
    nonce = ch["nonce"]
    sig = base64.b64encode(dev_priv.sign(
        bytes.fromhex(nonce), ec.ECDSA(hashes.SHA256()))).decode()
    bundle = post("/auth/activate", {
        "license_key": key, "fingerprint_inputs": fp_inputs,
        "app_version": 1, "challenge_nonce": nonce, "signature": sig})
    print("activate OK (proof-of-possession)  tier=%s cfgv=%s"
          % (bundle["tier"], bundle["config_version"]))

    # Verify the offline lease signature with the server public key.
    raw_b64, sig_hex = bundle["lease"].split(".")
    Ed25519PublicKey.from_public_bytes(
        s.ed25519_pk.public_bytes_raw()).verify(
        bytes.fromhex(sig_hex), base64.b64decode(raw_b64))
    print("lease signature OK:", json.loads(base64.b64decode(raw_b64)))

    # /config — full envelope open.
    access = bundle["access_token"]
    jti = jwt_payload(access)["jti"]
    client_sk = X25519PrivateKey.generate()
    client_nonce = secrets.token_bytes(16)
    resp = post_auth("/config", {
        "client_x25519_pub": client_sk.public_key().public_bytes_raw().hex(),
        "client_nonce": client_nonce.hex()}, access)
    aad = f"{jti}|{resp['config_version']}|{resp['expiry']}".encode()
    shared = client_sk.exchange(
        X25519PublicKey.from_public_bytes(bytes.fromhex(resp["server_x25519_pub"])))
    session = HKDF(algorithm=hashes.SHA256(), length=32, salt=client_nonce,
                   info=crypto.CONFIG_INFO).derive(shared)
    data_key = AESGCM(session).decrypt(
        bytes.fromhex(resp["wrap_nonce"]), bytes.fromhex(resp["wrapped_data_key"]), aad)
    blob = AESGCM(data_key).decrypt(
        bytes.fromhex(resp["ct_nonce"]), bytes.fromhex(resp["ciphertext"]), aad)
    parsed = json.loads(blob)
    print("config OK  wm=%s  sections=%s" % (parsed["wm"], list(parsed["sections"])))

    # Refresh once (rotates), then replay the OLD one → must 401.
    r1 = post("/auth/refresh", {"refresh_token": bundle["refresh_token"],
                                "fingerprint_inputs": fp_inputs})
    print("refresh OK (rotated)")
    try:
        post("/auth/refresh", {"refresh_token": bundle["refresh_token"],
                               "fingerprint_inputs": fp_inputs})
        print("!! FAIL: replayed refresh token was accepted")
    except urllib.error.HTTPError as e:
        print("replay refused:", e.code, "(reuse-detection works)")

    # Refresh from a DIFFERENT device (same token) → must 401 (device binding).
    try:
        post("/auth/refresh", {"refresh_token": r1["refresh_token"],
                               "fingerprint_inputs": {"ssaid": "other", "device_pubkey": "b3RoZXI="}})
        print("!! FAIL: refresh from a different device was accepted")
    except urllib.error.HTTPError as e:
        print("device-bound refresh OK:", e.code)

    print("\nALL CHECKS PASSED")


if __name__ == "__main__":
    main()
