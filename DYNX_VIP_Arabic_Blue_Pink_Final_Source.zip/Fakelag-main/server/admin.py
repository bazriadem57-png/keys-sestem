#!/usr/bin/env python3
"""
Nuvola admin CLI — SSH/localhost only, never an HTTP endpoint.

    python admin.py mint --tier standard --devices 2 [--expiry-days 30] [--note "buyer"]
    python admin.py revoke <license_id>
    python admin.py list [--devices]
    python admin.py deactivate-device <license_id> <fingerprint>
    python admin.py set-config-version <license_id> <version>
    python admin.py trace <watermark_hex>

`mint` prints the cleartext key ONCE; only its hash is stored.
"""
from __future__ import annotations

import argparse
import secrets
import sys

from app import crypto
from app.config_blob import trace_watermark
from app.db import connect, init_db, now
from app.settings import DEFAULT_MAX_DEVICES, get_secrets


def _gen_key() -> str:
    # 20 groups of base32-ish, grouped for readability: NVLA-XXXX-XXXX-XXXX-XXXX
    raw = secrets.token_hex(10).upper()
    return "NVLA-" + "-".join(raw[i:i + 4] for i in range(0, len(raw), 4))


def mint(args):
    key = _gen_key()
    expiry = now() + args.expiry_days * 86400 if args.expiry_days else None
    with connect() as c:
        c.execute("INSERT INTO licenses(key_hash,tier,status,expiry,max_devices,"
                  "config_version,created_at,note) VALUES(?,?,?,?,?,?,?,?)",
                  (crypto.sha256_hex(key), args.tier, "active", expiry,
                   args.devices, 1, now(), args.note))
        lid = c.execute("SELECT last_insert_rowid() id").fetchone()["id"]
    print(f"license_id={lid}  tier={args.tier}  devices={args.devices}  "
          f"expiry={'lifetime' if not expiry else expiry}")
    print(f"KEY (shown once): {key}")


def revoke(args):
    with connect() as c:
        n = c.execute("UPDATE licenses SET status='revoked' WHERE id=?",
                      (args.license_id,)).rowcount
        c.execute("UPDATE refresh_tokens SET revoked=1 WHERE license_id=?",
                  (args.license_id,))
    print("revoked" if n else "no such license")


def list_(args):
    with connect() as c:
        for lic in c.execute("SELECT * FROM licenses ORDER BY id").fetchall():
            print(f"[{lic['id']}] {lic['status']:8} tier={lic['tier']} "
                  f"devices<= {lic['max_devices']} cfgv={lic['config_version']} "
                  f"note={lic['note'] or ''}")
            if args.devices:
                for d in c.execute("SELECT * FROM devices WHERE license_id=?",
                                   (lic["id"],)).fetchall():
                    star = "" if d["active"] else " (inactive)"
                    print(f"      device {d['fingerprint'][:16]}…{star}")


def deactivate_device(args):
    with connect() as c:
        dev = c.execute("SELECT id FROM devices WHERE license_id=? AND fingerprint=?",
                        (args.license_id, args.fingerprint)).fetchone()
        if dev is None:
            print("no such device")
            return
        c.execute("UPDATE devices SET active=0 WHERE id=?", (dev["id"],))
        # Kill its refresh tokens too, or the freed seat keeps refreshing (H4).
        c.execute("UPDATE refresh_tokens SET revoked=1 WHERE device_id=?", (dev["id"],))
    print("deactivated + refresh revoked")


def set_config_version(args):
    with connect() as c:
        n = c.execute("UPDATE licenses SET config_version=? WHERE id=?",
                      (args.version, args.license_id)).rowcount
    print("updated" if n else "no such license")


def trace(args):
    # Watermarks are per-SEAT (license_id:fingerprint), so enumerate every known
    # seat: each license's bound devices, plus a license-level fallback for any
    # blob minted before a device row existed.
    s = get_secrets()
    with connect() as c:
        seats = []
        for r in c.execute("SELECT id FROM licenses").fetchall():
            lid = r["id"]
            seats.append(f"{lid}:")   # license-level fallback (empty did)
            for d in c.execute("SELECT fingerprint FROM devices WHERE license_id=?",
                               (lid,)).fetchall():
                seats.append(f"{lid}:{d['fingerprint']}")
    hit = trace_watermark(s.server_salt, args.watermark, seats)
    if hit:
        lid, _, fp = hit.partition(":")
        print(f"watermark → license_id={lid} seat_fingerprint={fp or '(pre-device)'}")
    else:
        print("no match")


def main():
    init_db()
    p = argparse.ArgumentParser(description="Nuvola admin")
    sub = p.add_subparsers(dest="cmd", required=True)

    m = sub.add_parser("mint"); m.set_defaults(fn=mint)
    m.add_argument("--tier", default="standard")
    m.add_argument("--devices", type=int, default=DEFAULT_MAX_DEVICES)
    m.add_argument("--expiry-days", type=int, default=0)
    m.add_argument("--note", default="")

    r = sub.add_parser("revoke"); r.set_defaults(fn=revoke)
    r.add_argument("license_id", type=int)

    l = sub.add_parser("list"); l.set_defaults(fn=list_)
    l.add_argument("--devices", action="store_true")

    d = sub.add_parser("deactivate-device"); d.set_defaults(fn=deactivate_device)
    d.add_argument("license_id", type=int); d.add_argument("fingerprint")

    s = sub.add_parser("set-config-version"); s.set_defaults(fn=set_config_version)
    s.add_argument("license_id", type=int); s.add_argument("version", type=int)

    t = sub.add_parser("trace"); t.set_defaults(fn=trace)
    t.add_argument("watermark")

    args = p.parse_args()
    args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
