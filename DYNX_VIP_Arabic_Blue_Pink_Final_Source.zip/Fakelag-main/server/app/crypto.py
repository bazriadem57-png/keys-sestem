"""
Crypto primitives shared by the endpoints. Kept in one place so the client
(Java/Tink) has one spec to mirror.

Config-delivery KDF (client MUST match, see docs/LOGIN_AND_SERVER.md §4):
    shared   = X25519(server_eph_sk, client_eph_pk)
    session  = HKDF-SHA256(ikm=shared, salt=client_nonce, info=b"nuvola-config-v1", len=32)
    data_key = 32 random bytes
    ct       = AES-256-GCM(data_key, nonce=ct_nonce,   pt=blob,      aad=AAD)
    wrapped  = AES-256-GCM(session,  nonce=wrap_nonce,  pt=data_key,  aad=AAD)
    AAD      = f"{jti}|{config_version}|{expiry}".encode()
"""
from __future__ import annotations

import hashlib
import hmac
import os

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey, X25519PublicKey,
)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes, serialization

CONFIG_INFO = b"nuvola-config-v1"


def device_fingerprint(server_salt: bytes, ssaid: str) -> str:
    """
    HMAC-SHA256(salt, SSAID) — the SEAT identity: which physical device a license
    is bound to.

    Deliberately keyed on the SSAID alone, NOT on the device pubkey. The pubkey is
    a per-install Android Keystore key; folding it into the seat meant every app
    reinstall (new Keystore key) minted a brand-new seat, so a few beta reinstalls
    exhausted max_devices and locked the key out forever (2026-09-18, availability
    CRIT). SSAID is stable across reinstall on the same signing key + device (it
    changes only on factory reset), so one physical device is one seat.

    Proof-of-possession is preserved separately: the pubkey is stored per seat
    (devices.pubkey), verified on every refresh against the key the caller presents
    (see /auth/refresh), and re-enrolled only via /auth/activate — which requires
    the license key. So dropping the pubkey from the seat id does not weaken the
    "must exercise the enrolled hardware key" property; it only stops reinstalls
    from burning seats.
    """
    msg = ssaid.encode("utf-8")
    return hmac.new(server_salt, msg, hashlib.sha256).hexdigest()


def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def new_opaque_token() -> str:
    return os.urandom(32).hex()


def hkdf_session_key(shared: bytes, client_nonce: bytes) -> bytes:
    return HKDF(
        algorithm=hashes.SHA256(), length=32,
        salt=client_nonce, info=CONFIG_INFO,
    ).derive(shared)


def seal_config(blob: bytes, client_x25519_pub_raw: bytes, client_nonce: bytes,
                aad: bytes) -> dict:
    """Envelope-encrypt `blob` for a live session. Returns wire fields (hex)."""
    server_eph = X25519PrivateKey.generate()
    peer = X25519PublicKey.from_public_bytes(client_x25519_pub_raw)
    shared = server_eph.exchange(peer)
    session_key = hkdf_session_key(shared, client_nonce)

    data_key = os.urandom(32)
    ct_nonce = os.urandom(12)
    wrap_nonce = os.urandom(12)
    ciphertext = AESGCM(data_key).encrypt(ct_nonce, blob, aad)
    wrapped = AESGCM(session_key).encrypt(wrap_nonce, data_key, aad)

    server_pub_raw = server_eph.public_key().public_bytes_raw()
    return {
        "server_x25519_pub": server_pub_raw.hex(),
        "wrapped_data_key": wrapped.hex(),
        "wrap_nonce": wrap_nonce.hex(),
        "ciphertext": ciphertext.hex(),
        "ct_nonce": ct_nonce.hex(),
    }


def sign_lease(ed25519_sk, payload: bytes) -> str:
    """Detached Ed25519 signature (hex) over the canonical lease bytes."""
    return ed25519_sk.sign(payload).hex()


def verify_device_sig(device_pubkey_der_b64: str, message: bytes, sig_der: bytes) -> bool:
    """
    Verify an ECDSA-P256/SHA256 signature made by the client's Android Keystore
    device key (DeviceIdentity), proving possession of the private key bound to
    device_pubkey (proof-of-possession, H3). The pubkey is the X.509/DER
    SubjectPublicKeyInfo the client sent as device_pubkey (base64).
    """
    try:
        import base64
        pub = serialization.load_der_public_key(base64.b64decode(device_pubkey_der_b64))
        if not isinstance(pub, ec.EllipticCurvePublicKey):
            return False
        pub.verify(sig_der, message, ec.ECDSA(hashes.SHA256()))
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False
