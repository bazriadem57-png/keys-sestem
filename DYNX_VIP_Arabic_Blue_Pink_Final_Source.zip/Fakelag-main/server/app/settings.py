"""
Server settings + long-lived secrets.

Secrets (Ed25519 signing key, the fingerprint HMAC salt) are read from
environment variables in production. If absent, a dev keyfile is generated once
so the server runs out-of-the-box for local testing — with a LOUD warning,
because a dev keyfile committed or copied around is a leaked signing key.

NEVER commit server_keys.json. It is gitignored.
"""
from __future__ import annotations

import json
import os
import secrets
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.environ.get("NUVOLA_DB", BASE_DIR / "nuvola.db"))
KEYFILE = BASE_DIR / "server_keys.json"
BUCKET_B_DIR = Path(os.environ.get("NUVOLA_BUCKET_B", BASE_DIR / "bucket_b"))
# Native-lib live-update store: <NATIVE_DIR>/<abi>/{manifest.json, <version>/lib.so}
NATIVE_DIR = Path(os.environ.get("NUVOLA_NATIVE_DIR", BASE_DIR / "native_store"))

# Tunables (defaults from docs/LOGIN_AND_SERVER.md §8; override via env).
ACCESS_TTL_SEC = int(os.environ.get("NUVOLA_ACCESS_TTL", 600))          # 10 min
LEASE_GRACE_SEC = int(os.environ.get("NUVOLA_LEASE_GRACE", 72 * 3600))  # 72 h
CONFIG_TTL_SEC = int(os.environ.get("NUVOLA_CONFIG_TTL", 120))          # 2 min
# The server-gated decode profile's validity is DECOUPLED from the 2-min config
# TTL: the config TTL is short for token-replay reasons, but the decode profile
# only needs to prove "a licensed session fetched config recently", so it must
# outlast a FULL match (20-30+ min) or DECODE_LEASH would black out ESP mid-game.
# 6 h means a daily login keeps a legit device armed all session; the anti-crack
# property is unchanged (an offline/cracked client still gets NO profile at all).
DECODE_PROFILE_TTL_SEC = int(os.environ.get("NUVOLA_DECODE_PROFILE_TTL", 6 * 3600))  # 6 h
# Continuous-auth heartbeat: the ROLLING decode-profile TTL, re-armed by
# /auth/heartbeat every HEARTBEAT_INTERVAL_SEC. Short enough that a stubbed/blocked
# heartbeat (or a login-bypassed client that never beats) fail-closes within one
# window, long enough to ride out multi-minute mobile network blips. The rolling
# TTL supersedes the static 6 h profile once HEARTBEAT_ENFORCE is on the client.
# Ratchet 6h -> 30min -> 12min on-device, watching ESP_LEASH_CLOSED. See
# docs/CONTINUOUS_AUTH_AND_DECODE_PLAN.md.
ROLLING_TTL_SEC = int(os.environ.get("NUVOLA_ROLLING_TTL", 12 * 60))          # 12 min
HEARTBEAT_INTERVAL_SEC = int(os.environ.get("NUVOLA_HB_INTERVAL", 4 * 60))    # 4 min (advertised to the client)
DEFAULT_MAX_DEVICES = int(os.environ.get("NUVOLA_MAX_DEVICES", 3))
# A seat unused for this long may be reclaimed when a new device hits the cap, so
# a genuinely replaced device (e.g. factory reset changed the SSAID, orphaning the
# old seat) can take a seat instead of the license locking out. Concurrent, live
# devices are never reclaimed — only stale ones (2026-09-18 availability fix).
STALE_SEAT_SEC = int(os.environ.get("NUVOLA_STALE_SEAT", 14 * 86400))   # 14 d
MIN_SUPPORTED_VERSION = int(os.environ.get("NUVOLA_MIN_VERSION", 1))
LATEST_VERSION = int(os.environ.get("NUVOLA_LATEST_VERSION", 1))
UPDATE_URL = os.environ.get("NUVOLA_UPDATE_URL", "")


class Secrets:
    def __init__(self, ed25519_sk: Ed25519PrivateKey, server_salt: bytes):
        self.ed25519_sk = ed25519_sk
        self.ed25519_pk = ed25519_sk.public_key()
        self.server_salt = server_salt

    @property
    def signing_pem(self) -> bytes:
        return self.ed25519_sk.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        )

    @property
    def public_pem(self) -> bytes:
        return self.ed25519_pk.public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )


def _load_from_env() -> Secrets | None:
    sk_pem = os.environ.get("NUVOLA_ED25519_SK_PEM")
    salt_hex = os.environ.get("NUVOLA_SERVER_SALT_HEX")
    if not sk_pem or not salt_hex:
        return None
    sk = serialization.load_pem_private_key(sk_pem.encode(), password=None)
    if not isinstance(sk, Ed25519PrivateKey):
        raise ValueError("NUVOLA_ED25519_SK_PEM is not an Ed25519 key")
    return Secrets(sk, bytes.fromhex(salt_hex))


def _load_keyfile() -> Secrets:
    data = json.loads(KEYFILE.read_text())
    sk = serialization.load_pem_private_key(data["ed25519_sk_pem"].encode(), password=None)
    return Secrets(sk, bytes.fromhex(data["server_salt_hex"]))


def _make_keyfile() -> Secrets:
    sk = Ed25519PrivateKey.generate()
    salt = secrets.token_bytes(32)
    s = Secrets(sk, salt)
    KEYFILE.write_text(json.dumps({
        "ed25519_sk_pem": s.signing_pem.decode(),
        "server_salt_hex": salt.hex(),
    }))
    try:
        os.chmod(KEYFILE, 0o600)
    except OSError:
        pass
    print(f"Generated a persistent signing key at {KEYFILE} (chmod 600). "
          "Back it up; losing it invalidates every issued token and lease.")
    return s


_secrets: Secrets | None = None


def get_secrets() -> Secrets:
    """
    Resolution order:
      1. env NUVOLA_ED25519_SK_PEM + NUVOLA_SERVER_SALT_HEX (preferred in prod),
      2. an existing server_keys.json (loaded silently — bootstrap generates it),
      3. generate a new keyfile ONLY when explicitly allowed
         (NUVOLA_ALLOW_KEYGEN=1, as bootstrap.sh sets, or NUVOLA_ENV=dev).
    Otherwise fail fast rather than silently running on an auto-generated key in
    production (M3).
    """
    global _secrets
    if _secrets is None:
        _secrets = _load_from_env()
        if _secrets is None:
            if KEYFILE.exists():
                _secrets = _load_keyfile()
            elif os.environ.get("NUVOLA_ALLOW_KEYGEN") == "1" or \
                    os.environ.get("NUVOLA_ENV") == "dev":
                _secrets = _make_keyfile()
            else:
                raise RuntimeError(
                    "No signing key. Set NUVOLA_ED25519_SK_PEM + "
                    "NUVOLA_SERVER_SALT_HEX, or run deploy/bootstrap.sh "
                    "(which sets NUVOLA_ALLOW_KEYGEN=1) to generate one.")
    return _secrets
