"""
Live-update of the native packet-core `.so`.

The server signs a small manifest describing the current `libnuvola_native.so`
with the SAME Ed25519 key the offline lease uses (the client already pins its
public half in AuthConfig.SERVER_ED25519_PUB_HEX and can verify it without any
new trust root). The client verifies the signature + SHA-256 before it ever
`System.load()`s the file, and refuses a downgrade. See docs/NATIVE_LIVE_UPDATE.md.

Signing is done here, on the VPS, NEVER in CI: CI only produces the unsigned
`.so` + provenance; a leaked CI token therefore cannot mint a lib the client will
load. The signed bytes are a FIXED-ORDER, domain-separated string (not JSON), so
there is no canonicalisation ambiguity and a lease signature can never be
replayed as a lib manifest.
"""
from __future__ import annotations

import base64
import json
from pathlib import Path

from .settings import NATIVE_DIR, get_secrets

MANIFEST_SCHEMA = "nuvola-native-manifest-v2"
# The Rust↔Java contract version. Bump when the JNI surface / self-test changes;
# a client whose loader ABI is older than a manifest's min_loader refuses the lib.
CURRENT_MIN_LOADER = 1

# `abi` arrives as an untrusted query string and is used to build a filesystem
# path under NATIVE_DIR — allowlist it so it can never be a path-traversal
# (e.g. abi="../../etc"). Only the standard Android ABI strings are ever valid.
ALLOWED_ABIS = frozenset({"arm64-v8a", "armeabi-v7a", "x86", "x86_64"})


def abi_ok(abi: str) -> bool:
    return abi in ALLOWED_ABIS


def _kill_str(kill: bool) -> str:
    """Match the JSON boolean the client reads back (lowercase true/false)."""
    return "true" if kill else "false"


def canonical_bytes(abi: str, version: int, semver: str, sha256: str, size: int,
                    min_loader: int, not_before: str, not_after: str,
                    rollout_permille: int, kill: bool, url: str) -> bytes:
    """The exact bytes that get signed/verified. The client rebuilds this from
    the manifest fields; keep the two in lockstep. v2 folds the control fields
    (rollout_permille, kill, url) INTO the signature so the transport is not
    trusted for them (2026-09-18 security review M1)."""
    return (
        f"{MANIFEST_SCHEMA}\n"
        f"abi={abi}\n"
        f"version={version}\n"
        f"semver={semver}\n"
        f"sha256={sha256}\n"
        f"size={size}\n"
        f"min_loader={min_loader}\n"
        f"not_before={not_before}\n"
        f"not_after={not_after}\n"
        f"rollout_permille={rollout_permille}\n"
        f"kill={_kill_str(kill)}\n"
        f"url={url}\n"
    ).encode("utf-8")


def sign_manifest(fields: dict) -> dict:
    """Given the descriptive fields, return the full client-facing manifest dict
    with the Ed25519 signature attached. `fields` must carry abi, version,
    semver, sha256, size, min_loader, not_before, not_after, rollout_permille,
    kill, url — ALL of which are now signed."""
    s = get_secrets()
    rollout = fields.get("rollout_permille", 1000)
    kill = fields.get("kill", False)
    url = fields["url"]
    raw = canonical_bytes(
        fields["abi"], fields["version"], fields["semver"], fields["sha256"],
        fields["size"], fields["min_loader"], fields["not_before"],
        fields["not_after"], rollout, kill, url,
    )
    sig = s.ed25519_sk.sign(raw)
    out = {
        "schema": MANIFEST_SCHEMA,
        "abi": fields["abi"],
        "version": fields["version"],
        "semver": fields["semver"],
        "sha256": fields["sha256"],
        "size": fields["size"],
        "min_loader": fields["min_loader"],
        "not_before": fields["not_before"],
        "not_after": fields["not_after"],
        "rollout_permille": rollout,
        "kill": kill,
        "url": url,
        "sig_alg": "ed25519",
        "sig": base64.b64encode(sig).decode(),
    }
    return out


def manifest_path(abi: str) -> Path:
    return NATIVE_DIR / abi / "manifest.json"


def lib_path(abi: str, version: int) -> Path:
    return NATIVE_DIR / abi / str(version) / "lib.so"


def load_manifest(abi: str) -> dict | None:
    p = manifest_path(abi)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text())
    except (ValueError, OSError):
        return None
