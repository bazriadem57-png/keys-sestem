"""Request/response bodies (pydantic). The wire contract with the client."""
from __future__ import annotations

from pydantic import BaseModel, Field

# Length caps (2026-09-18 audit M3): reject oversized bodies with a 422 BEFORE any
# hex/base64 decode or allocation, so a multi-megabyte field cannot pressure memory.
# All values are generous vs. real inputs (a DER-b64 P-256 key is ~120 chars, a
# 32-byte hex key is 64 chars, an 80-bit license key is 20 hex chars).
_KEY = Field(max_length=64)
_SSAID = Field(max_length=128)
_PUBKEY = Field(max_length=4096)      # base64 DER device Keystore public key
_SIG = Field(max_length=4096)         # base64 DER ECDSA signature
_NONCE = Field(max_length=256)        # hex nonce / HKDF salt
_X25519 = Field(max_length=128)       # hex 32-byte raw X25519 public key
_SECTION = Field(max_length=64)
_REFRESH = Field(max_length=512)


class FingerprintInputs(BaseModel):
    ssaid: str = _SSAID
    device_pubkey: str = _PUBKEY   # base64 DER of the device Keystore public key


class ChallengeRequest(BaseModel):
    device_pubkey: str = _PUBKEY   # base64 DER of the device Keystore public key


class ChallengeResponse(BaseModel):
    nonce: str                  # hex; sign this with the device key, then activate
    expiry: int


class ActivateRequest(BaseModel):
    license_key: str = _KEY
    fingerprint_inputs: FingerprintInputs
    app_version: int
    # Proof-of-possession (H3): the challenge nonce and its ECDSA-P256/SHA256
    # signature made with the device Keystore key.
    challenge_nonce: str = _NONCE
    signature: str = _SIG          # base64 DER ECDSA signature over the nonce bytes


class TokenBundle(BaseModel):
    access_token: str
    refresh_token: str
    lease: str                  # base64(json) + "." + hex signature
    tier: str
    config_version: int


class RefreshRequest(BaseModel):
    refresh_token: str = _REFRESH
    # Device binding is re-proven on every refresh: the server recomputes the
    # fingerprint from these and checks it against the token's bound device.
    fingerprint_inputs: FingerprintInputs
    # Proof-of-possession on EVERY refresh (not just activation): the client must
    # sign a fresh challenge nonce with its hardware Keystore key. Without this a
    # refresh token lifted off one device could be replayed from curl on any host
    # for the life of the family; with it, refreshing requires the private key to
    # be exercised on the bound device each time (2026-09-17 audit, HIGH).
    challenge_nonce: str = _NONCE
    signature: str = _SIG          # base64 DER ECDSA signature over the nonce bytes


class ConfigRequest(BaseModel):
    client_x25519_pub: str = _X25519   # hex, 32-byte raw X25519 public key
    client_nonce: str = _NONCE         # hex, HKDF salt
    section: str | None = Field(default=None, max_length=64)


class ConfigResponse(BaseModel):
    server_x25519_pub: str
    wrapped_data_key: str
    wrap_nonce: str
    ciphertext: str
    ct_nonce: str
    config_version: int
    expiry: int


class HeartbeatRequest(BaseModel):
    # Continuous-auth heartbeat: same sealed-envelope handshake as /config, but
    # cheap (no Bucket-B blob) so it can run every few minutes. Re-arms the rolling
    # decode profile. Fresh ephemeral X25519 pubkey + nonce each beat.
    client_x25519_pub: str = _X25519   # hex, 32-byte raw X25519 public key
    client_nonce: str = _NONCE         # hex, HKDF salt + freshness
    epoch_have: int = 0                # highest rolling-profile epoch the client holds


class HeartbeatResponse(BaseModel):
    server_x25519_pub: str
    wrapped_data_key: str
    wrap_nonce: str
    ciphertext: str
    ct_nonce: str
    # Plaintext, AAD-bound (like /config's expiry/config_version): the client needs
    # them to reconstruct the AAD before it can decrypt, and GCM tamper-detection
    # over the AAD makes trusting them safe. `epoch` is monotonic (reject <= held);
    # `valid_until` is the rolling deadline; `server_now` (inside the blob) lets the
    # client convert to its monotonic clock.
    epoch: int
    valid_until: int
    # Advertised cadence so the client paces itself to the server, not a baked const.
    interval: int


class VersionResponse(BaseModel):
    min_supported: int
    latest: int
    url: str
    # Native-lib live-update channel: {"abi","version"} of the current signed lib,
    # or null when none is published. The client fetches /native/manifest to get
    # the signed details and decide whether to download. Off the packet hot path.
    native: dict | None = None
