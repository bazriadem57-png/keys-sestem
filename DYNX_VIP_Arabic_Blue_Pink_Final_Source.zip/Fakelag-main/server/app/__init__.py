"""Nuvola licensing + config-delivery backend. See docs/LOGIN_AND_SERVER.md."""
