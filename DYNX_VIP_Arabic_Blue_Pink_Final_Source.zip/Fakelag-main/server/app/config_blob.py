"""
Build the per-user, watermarked Bucket-B blob delivered by /config.

Source sections live as JSON under bucket_b/ (server-only; withheld from the
APK). Phase 1 sections: cmd_catalogue, body_decoder_table. The blob is JSON so
the Android client parses it with the built-in org.json (no extra dep). It is
AES-GCM-encrypted before it ever leaves the process, so plaintext JSON here is
fine.

Watermark (traitor tracing):
  * `wm` = HMAC-SHA256(server_salt, str(license_id))[:16], embedded in the blob.
    A leaked blob is traced by recomputing this over every license until it
    matches — the id is never written in the clear.
  * every list section is deterministically rotated by a per-license offset, so
    a leaker who strips the `wm` field still ships an ordering unique to them.
"""
from __future__ import annotations

import hashlib
import hmac
import json

from .settings import BUCKET_B_DIR

# ---- Server-gated decode profile (anti-crack) ----------------------------
# The structural parameters the native decoder needs to interpret the wire.
# They live ONLY here (server-side) and are delivered inside the AES-GCM /config
# envelope; the APK carries no baked copy, so a cracked offline client has no
# way to construct a valid profile. The native decoder fail-closes without an
# unexpired profile, leashing BOTH the 2012 ESP chain decode and the reliable-
# channel decrypt to a live licensed session. See
# docs/SERVER_GATED_DECODE_DESIGN.md and native/nuvola-core/src/chain.rs.
_CHAIN_DECODE_PARAMS = {
    "max_len": 1400,
    "max_records": 64,
    "min_record_bytes": 16,
    "min_record_x": 500,
    "max_entity_id": 64,
}

# ---- Field-semantic maps (the "which v[i] means what" knowledge) --------------
# These move the DECODE INTERPRETATION server-side (docs/CONTINUOUS_AUTH_AND_DECODE_PLAN.md
# stage C, from the decode-porting spec). They are decode-side only: they never
# touch a byte on the wire, so packets do not lengthen and no round-trip is added.
# A cracked offline client that has the walker code but not these maps decodes
# garbage. Consumers (client PositionSync/AimFilter/PriSync/MarkFilter/EspEngine +
# the native decoders) are wired + gated incrementally; each map is validated
# against real captures when its consumer is switched over. Values are the current
# baked constants, sourced file:line by the decode-porting spec.
_KEEPALIVE_V_MAP = {           # Cmd 2001, 23-varint body
    "body_varints": 23,
    "pos": [0, 1, 2], "move_dir": [6, 7], "vel": [8, 9, 10],
    "phys_state": 11, "pose": 12, "cam_dir": [13, 14, 15],
    "platform_id": 16, "rtt": 18, "slide": 20, "tick": 22,
}
_CHAIN_FIELDS = {              # Cmd 2012 record layout (wire order)
    "record_fields": ["id", "x", "z", "y", "vx", "vz", "vy",
                      "body_yaw:u8", "aim_yaw:u8", "aim_pitch:i8",
                      "mode", "state", "res", "res"],
    "self_echo_varints": 16,
    "pose": {"yaw_deg_per_lsb_num": 360, "yaw_deg_per_lsb_den": 256},
    "units_per_metre": 1000,
}
# (The Cmd-106 hit106_field_map — the headshot-forgery program/checkParams — was
# REMOVED 2026-09-18 along with the client AimFilter it fed. Not delivered.)
_PRI_KEY_LAYOUT = {            # Cmd 1900 EPRI player-namespace id map
    "cur_hp": 0, "max_hp": 1, "vest": 2, "helmet": 3, "on_hand": 4,
    "cur_ep": 6, "max_ep": 7, "firing": 21, "total_dmg": 31,
    "value_mask_bits": 56,
}
_MARK148_LAYOUT = {            # Cmd 148
    "fields": ["U:author", "B:is_del", "B:type", "Z:x", "Z:up", "Z:z",
               "B:slot", "B:sound", "B:zero"],
    "type_notice_enemy": 1,
}
_VEHICLE_LAYOUT = {            # Cmd 2002/2069 mounted carriers
    "cmd": [2002, 2069], "op_byte_index": 8, "quat_scale": 1000, "vel_scale": 100,
}
_DECODE_GATES = {              # Ghost/Freeze/Teleport id sets
    "own_pos_carriers": [2001, 2002, 2006, 2031],
    "mounted_carriers": [2002, 2006, 2031],
    "world_state_stream": [2001, 2002, 2003, 2009, 2012, 2014, 2016],
    "transport_max": 99,
}
# Camera/projection calibration — the ONE decode-knowledge set that is NOT wire-
# rediscoverable: it came from the DECRYPTED il2cpp image (the shipped libil2cpp.so
# has encrypted method bodies that decompile to garbage), so an APK-only attacker
# cannot recompute it. Delivered as the EspTuning getFloat DEFAULT; a value the user
# saved in the tune panel still wins. Values here MUST equal the baked DEF_* in
# EspTuning.java (parity-guarded) until the owner ships a deliberately-offset
# placeholder baked-side coupled with the DECODE_LEASH flip.
_CALIBRATION = {
    "fov_x_deg": 91.49,
    "boom_m": 2.50,
    "shoulder_m": -0.40,
}


def _decode_maps() -> dict:
    """The full field-semantic map set, deep-copied so a caller can't mutate the
    module constants. Included in the /config decode_profile; the cheap rolling
    heartbeat does NOT re-send these (the client keeps them from /config)."""
    return {
        "keepalive_v_map": dict(_KEEPALIVE_V_MAP),
        "pri_key_layout": dict(_PRI_KEY_LAYOUT),
        "mark148_layout": dict(_MARK148_LAYOUT),
        "vehicle_layout": dict(_VEHICLE_LAYOUT),
        "gates": dict(_DECODE_GATES),
        "calibration": dict(_CALIBRATION),
    }


def _watermark(server_salt: bytes, seat: str) -> str:
    return hmac.new(server_salt, seat.encode(), hashlib.sha256).hexdigest()[:16]


def _rotate_offset(server_salt: bytes, seat: str) -> int:
    h = hmac.new(server_salt, b"rot" + seat.encode(), hashlib.sha256).digest()
    return int.from_bytes(h[:4], "big")


def _load_sections(want: str | None) -> dict:
    sections = {}
    if not BUCKET_B_DIR.exists():
        return sections
    for path in sorted(BUCKET_B_DIR.glob("*.json")):
        name = path.stem
        if want and name != want:
            continue
        try:
            sections[name] = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
    return sections


def _apply_ordering_watermark(sections: dict, offset: int) -> None:
    """Deterministically rotate any top-level list in each section in place."""
    for section in sections.values():
        if isinstance(section, dict):
            for k, v in section.items():
                if isinstance(v, list) and len(v) > 1:
                    n = len(v)
                    off = offset % n
                    section[k] = v[off:] + v[:off]


def build_blob(server_salt: bytes, license_id: int, seat: str, config_version: int,
               section: str | None, profile_valid_until: int = 0) -> bytes:
    """
    `seat` is a per-device identifier (``"{license_id}:{fingerprint}"``) so two
    devices on one license receive distinguishable blobs — a leak traces to the
    seat, not just the license. Both the `wm` field and the list-ordering rotation
    key on it.

    `profile_valid_until` (unix seconds) arms the native decoder's server-gated
    leash: the decoder fail-closes after this instant, so a client must keep a
    live licensed session (refreshing /config) to decode anything. 0 omits the
    profile (e.g. a section-only fetch that isn't arming the decoder).
    """
    sections = _load_sections(section)
    _apply_ordering_watermark(sections, _rotate_offset(server_salt, seat))
    blob = {
        "config_version": config_version,
        "wm": _watermark(server_salt, seat),
        "sections": sections,
    }
    if profile_valid_until > 0:
        chain = dict(_CHAIN_DECODE_PARAMS)
        chain.update(_CHAIN_FIELDS)            # scalars + field semantics
        prof = {"valid_until": profile_valid_until, "chain": chain}
        prof.update(_decode_maps())            # keepalive/hit106/pri/mark/vehicle/gates
        blob["decode_profile"] = prof
    return json.dumps(blob, separators=(",", ":")).encode("utf-8")


def build_rolling_profile(valid_until: int, server_now: int, epoch: int) -> bytes:
    """
    The small, section-free profile delivered by /auth/heartbeat to RE-ARM the
    rolling decode leash. Unlike build_blob it carries no Bucket-B sections (so it
    is cheap enough to run every few minutes) — only the decode profile: the same
    structural chain params, a short `valid_until`, the server clock `server_now`
    (so the client can convert to its monotonic domain), and a monotonic `epoch`
    (so a replayed older ACK is rejected). Sealed by the caller (seal_config) just
    like /config, inside the authenticated AES-GCM envelope.
    """
    profile = {
        "valid_until": valid_until,
        "server_now": server_now,
        "epoch": epoch,
        "chain": dict(_CHAIN_DECODE_PARAMS),
    }
    return json.dumps({"decode_profile": profile},
                      separators=(",", ":")).encode("utf-8")


def trace_watermark(server_salt: bytes, wm: str, seats: list[str]) -> str | None:
    """Given a leaked `wm`, return the seat id (``"{license}:{fingerprint}"``)
    that produced it, or None. Callers pass the seat ids to test."""
    for seat in seats:
        if hmac.compare_digest(_watermark(server_salt, seat), wm):
            return seat
    return None
