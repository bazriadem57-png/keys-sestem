"""SQLite storage. One connection per request (sqlite3 is fine at this scale)."""
from __future__ import annotations

import sqlite3
import time
from contextlib import contextmanager

from fastapi import HTTPException

from .settings import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS licenses (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    key_hash      TEXT UNIQUE NOT NULL,
    tier          TEXT NOT NULL DEFAULT 'standard',
    status        TEXT NOT NULL DEFAULT 'active',   -- active | revoked
    expiry        INTEGER,                          -- unix secs, NULL = lifetime
    max_devices   INTEGER NOT NULL DEFAULT 2,
    config_version INTEGER NOT NULL DEFAULT 1,
    created_at    INTEGER NOT NULL,
    note          TEXT
);
CREATE TABLE IF NOT EXISTS devices (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    license_id    INTEGER NOT NULL,
    fingerprint   TEXT NOT NULL,
    pubkey        TEXT,
    first_seen    INTEGER NOT NULL,
    last_seen     INTEGER NOT NULL,
    active        INTEGER NOT NULL DEFAULT 1,
    UNIQUE(license_id, fingerprint)
);
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    license_id    INTEGER NOT NULL,
    device_id     INTEGER NOT NULL,
    token_hash    TEXT UNIQUE NOT NULL,
    family_id     TEXT NOT NULL,
    used          INTEGER NOT NULL DEFAULT 0,
    revoked       INTEGER NOT NULL DEFAULT 0,
    created_at    INTEGER NOT NULL
);
-- One-time-use guard for /config: a given access token's jti may fetch the
-- Bucket-B blob at most once, so a captured /config response cannot be replayed
-- to re-request it (M1). Rows are pruned lazily past their expiry.
CREATE TABLE IF NOT EXISTS config_spent (
    jti           TEXT PRIMARY KEY,
    expiry        INTEGER NOT NULL
);
-- Proof-of-possession challenges (H3): /auth/challenge issues a nonce bound to a
-- device pubkey; /auth/activate requires a signature over it made with the
-- device's hardware Keystore key. One-time, short-lived.
CREATE TABLE IF NOT EXISTS challenges (
    nonce         TEXT PRIMARY KEY,
    pubkey        TEXT NOT NULL,
    expiry        INTEGER NOT NULL,
    used          INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS audit (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    license_id    INTEGER,
    fingerprint   TEXT,
    ip            TEXT,
    endpoint      TEXT,
    ts            INTEGER NOT NULL
);
-- Indexes for the hot lookups (2026-09-18 audit L3): the refresh reuse-detection
-- successor scan + family-revoke walk refresh_tokens by family_id/device_id every
-- refresh, and the seat-cap counts devices by license_id. Without these they full-
-- scan tables that grow one row per refresh forever.
CREATE INDEX IF NOT EXISTS idx_refresh_family ON refresh_tokens(family_id);
CREATE INDEX IF NOT EXISTS idx_refresh_device ON refresh_tokens(device_id);
CREATE INDEX IF NOT EXISTS idx_devices_license ON devices(license_id);
"""


def init_db() -> None:
    with connect() as c:
        c.executescript(SCHEMA)


@contextmanager
def connect():
    """
    One transaction per request.

    The endpoints in main.py deliberately write security-critical rows — audit
    entries for failed auth, the refresh-token-family revocation on reuse
    detection, the challenge one-time-use flag — and THEN raise an
    ``HTTPException`` to return the 4xx. Those writes MUST survive the raise, so
    an ``HTTPException`` (a deliberate business outcome) commits before
    re-raising. Any OTHER exception is an unexpected crash and rolls back, so a
    half-finished multi-write handler never persists inconsistent state.

    Before this, ``commit()`` ran only on a clean return, so every failure-path
    write was discarded on ``close()`` — which silently turned reuse-detection
    into a no-op, blinded the audit log to exactly the attacks it exists to
    catch, and let a failed activation reuse its challenge (see the 2026-09-17
    security audit; CRIT).
    """
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    # Concurrency hardening (2026-09-18, audit F3): the default busy_timeout is 0,
    # so two overlapping writers (FastAPI runs sync endpoints in a threadpool,
    # each with its own connection) would fail with "database is locked" instead
    # of serializing. A 5s timeout makes the second writer wait for the first to
    # commit, so the atomic seat-cap check in /auth/activate re-reads the updated
    # count. WAL lets reads proceed while a write is in flight.
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA journal_mode=WAL")
    try:
        yield conn
    except HTTPException:
        conn.commit()   # persist audit / revoke / consume, then let it 4xx
        raise
    except BaseException:
        conn.rollback()
        raise
    else:
        conn.commit()
    finally:
        conn.close()


def now() -> int:
    return int(time.time())


def audit(conn, endpoint: str, ip: str | None,
          license_id: int | None = None, fingerprint: str | None = None) -> None:
    conn.execute(
        "INSERT INTO audit(license_id, fingerprint, ip, endpoint, ts) "
        "VALUES(?,?,?,?,?)",
        (license_id, fingerprint, ip, endpoint, now()),
    )
