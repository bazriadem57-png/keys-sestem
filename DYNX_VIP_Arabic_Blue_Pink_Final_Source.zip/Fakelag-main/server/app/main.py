"""
Nuvola backend — auth, licensing, config delivery, version gate.
Contract: docs/LOGIN_AND_SERVER.md. Ops: docs/SERVER_OPS.md.

Run (dev):  uvicorn app.main:app --host 127.0.0.1 --port 8000
Behind Caddy/nginx terminating TLS with the client-pinned self-signed cert.
"""
from __future__ import annotations

import base64
import ipaddress
import json
import time
from collections import defaultdict, deque

import jwt
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse

from . import crypto, native
from .config_blob import build_blob, build_rolling_profile
from .db import audit, connect, init_db, now
from .models import (
    ActivateRequest, ChallengeRequest, ChallengeResponse, ConfigRequest,
    ConfigResponse, HeartbeatRequest, HeartbeatResponse, RefreshRequest,
    TokenBundle, VersionResponse,
)
from .settings import (
    ACCESS_TTL_SEC, CONFIG_TTL_SEC, DECODE_PROFILE_TTL_SEC, DEFAULT_MAX_DEVICES,
    HEARTBEAT_INTERVAL_SEC, LATEST_VERSION, LEASE_GRACE_SEC, MIN_SUPPORTED_VERSION,
    ROLLING_TTL_SEC, STALE_SEAT_SEC, UPDATE_URL, get_secrets,
)

app = FastAPI(title="Nuvola", docs_url=None, redoc_url=None, openapi_url=None)


@app.on_event("startup")
def _startup() -> None:
    init_db()
    get_secrets()  # fail fast if keys are misconfigured


# ---- tiny in-process rate limiter -----------------------------------------
# Buckets are keyed on (rate-limit key, endpoint tag) so that traffic to one
# endpoint cannot exhaust another's budget (a client refreshing normally used to
# be able to 429 its own /auth/activate, because every endpoint shared one
# per-IP deque — 2026-09-17 audit, MED). Single-process uvicorn only: see the
# note in deploy/nuvola.service. If ever scaled to --workers>1, move this and the
# one-time guards to shared storage (Redis) or every limit multiplies by N.
_hits: dict[tuple, deque] = defaultdict(deque)
_MAX_BUCKETS = 20000


def _rate_limit(key: str, tag: str, limit: int, window: int = 60) -> None:
    t = time.time()
    q = _hits[(key, tag)]
    while q and q[0] < t - window:
        q.popleft()
    # Bound memory under IP rotation: prune stale buckets, and if still over cap
    # (a flood of distinct fresh keys, none stale yet) evict the oldest so the
    # map cannot grow without limit or make the prune itself a DoS.
    if len(_hits) > _MAX_BUCKETS:
        for k in [k for k, v in list(_hits.items()) if not v or v[-1] < t - window]:
            _hits.pop(k, None)
        if len(_hits) > _MAX_BUCKETS:
            for k in sorted(_hits, key=lambda k: _hits[k][-1] if _hits[k] else 0
                            )[:len(_hits) - _MAX_BUCKETS]:
                _hits.pop(k, None)
    if len(q) >= limit:
        raise HTTPException(status_code=429, detail="rate_limited")
    q.append(t)


def _rl_key(request: Request) -> str:
    """
    Rate-limit key = the real peer address, with IPv6 collapsed to its /64. A
    single client with a routed /64 would otherwise have 2**64 fresh buckets and
    bypass every limit (2026-09-17 audit, MED). X-Forwarded-For is deliberately
    NOT trusted: this deploy terminates TLS in uvicorn with no reverse proxy, so
    XFF is attacker-controlled. If a trusted proxy is ever added, parse XFF only
    via Starlette ProxyHeadersMiddleware with an explicit trusted-hops allowlist.
    """
    ip = request.client.host if request.client else "?"
    try:
        addr = ipaddress.ip_address(ip)
        if addr.version == 6:
            return str(ipaddress.ip_network(f"{ip}/64", strict=False).network_address)
    except ValueError:
        pass
    return ip


def _client_ip(request: Request) -> str:
    """The real peer address, for the audit log (full precision, not bucketed)."""
    return request.client.host if request.client else "?"


# ---- token + lease helpers -------------------------------------------------
def _issue_access(license_id: int, tier: str, fp_id: str, cfg_ver: int) -> tuple[str, str, int]:
    s = get_secrets()
    iat = now()
    exp = iat + ACCESS_TTL_SEC
    jti = crypto.new_opaque_token()[:24]
    claims = {"sub": str(license_id), "lic": license_id, "tier": tier,
              "did": fp_id, "jti": jti, "iat": iat, "exp": exp, "cfgv": cfg_ver}
    token = jwt.encode(claims, s.signing_pem, algorithm="EdDSA")
    return token, jti, exp


def _make_lease(license_id: int, status: str, device_pubkey_b64: str) -> str:
    s = get_secrets()
    # Bind the offline lease to the device public key. The client re-derives
    # sha256(its own device pubkey) and refuses a lease whose `dpk` does not
    # match, so a lease file copied to another device no longer admits it during
    # the offline grace window (2026-09-17 audit, MED). `dpk` is a hash, not the
    # key, so it leaks nothing an attacker with the lease did not already send.
    dpk = crypto.sha256_hex(device_pubkey_b64)
    payload = {"license_id": license_id, "status": status,
               "valid_until": now() + LEASE_GRACE_SEC,
               "dpk": dpk,
               "lease_id": crypto.new_opaque_token()[:16]}
    raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    sig = crypto.sign_lease(s.ed25519_sk, raw)
    return base64.b64encode(raw).decode() + "." + sig


def _verify_challenge(c, nonce: str, device_pubkey_b64: str, signature_b64: str,
                      ip: str, fp: str) -> None:
    """
    Proof-of-possession gate shared by /auth/activate and /auth/refresh: the
    challenge must exist, be unused, unexpired, and bound to THIS device pubkey,
    and the signature must verify under it. Consumes the challenge (used=1) so it
    cannot be replayed — this now persists on the failure path too, because the
    connection commits on HTTPException (see db.connect). Raises on any failure.
    """
    ch = c.execute("SELECT * FROM challenges WHERE nonce=?", (nonce,)).fetchone()
    if ch is None or ch["used"] or ch["expiry"] < now() \
            or ch["pubkey"] != device_pubkey_b64:
        audit(c, "pop_bad_challenge", ip, None, fp)
        raise HTTPException(status_code=400, detail="bad_challenge")
    try:
        sig = base64.b64decode(signature_b64)
        nonce_bytes = bytes.fromhex(nonce)
    except (ValueError, TypeError):
        raise HTTPException(status_code=400, detail="bad_signature_encoding")
    # Consume first, so a bad signature cannot be retried against the same nonce.
    c.execute("UPDATE challenges SET used=1 WHERE nonce=?", (nonce,))
    if not crypto.verify_device_sig(device_pubkey_b64, nonce_bytes, sig):
        audit(c, "pop_bad_signature", ip, None, fp)
        raise HTTPException(status_code=401, detail="bad_signature")


def _verify_access(authorization: str | None) -> dict:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="missing_token")
    token = authorization.split(" ", 1)[1]
    s = get_secrets()
    try:
        claims = jwt.decode(token, s.public_pem, algorithms=["EdDSA"])
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="bad_token")
    # Revocation is immediate without a jti denylist: /config and /auth/refresh
    # both re-check license status on every call, and the access token lives only
    # ~10 min, so a revoked license cannot fetch config or refresh.
    return claims


def _license_ok(row) -> bool:
    return row and row["status"] == "active" and (
        row["expiry"] is None or row["expiry"] > now())


def _device_active(c, license_id: int, did: str | None) -> bool:
    """M2: the DEVICE seat must still be active, not just the license. `did` is the
    server-side fingerprint carried in the access token (== devices.fingerprint).
    admin deactivate-device flips devices.active=0; checking it here + on heartbeat
    cuts decode-revocation latency from ~6 h to one token/heartbeat interval."""
    if not did:
        return False
    row = c.execute("SELECT active FROM devices WHERE license_id=? AND fingerprint=?",
                    (license_id, did)).fetchone()
    return bool(row and row["active"])


def _reclaim_stale_seat(c, license_id: int, max_devices: int) -> None:
    """
    If the license is at its seat cap, free the single STALEST active seat when it
    has not been seen in STALE_SEAT_SEC, so a genuinely replaced device can take a
    seat rather than the license locking out (2026-09-18). Live/recent devices are
    never touched — only a seat gone quiet for the whole window — so this does not
    let a sharer cycle unlimited concurrent devices. Deactivating it also revokes
    its refresh family, matching admin deactivate-device (H4).
    """
    active = c.execute(
        "SELECT id, last_seen FROM devices WHERE license_id=? AND active=1 "
        "ORDER BY last_seen ASC", (license_id,)).fetchall()
    if len(active) < max_devices:
        return
    stalest = active[0]
    if stalest["last_seen"] < now() - STALE_SEAT_SEC:
        c.execute("UPDATE devices SET active=0 WHERE id=?", (stalest["id"],))
        c.execute("UPDATE refresh_tokens SET revoked=1 WHERE device_id=?",
                  (stalest["id"],))


# ---- endpoints -------------------------------------------------------------
@app.post("/auth/challenge", response_model=ChallengeResponse)
def challenge(req: ChallengeRequest, request: Request):
    """Issue a one-time nonce the client must sign with its device Keystore key,
    proving hardware possession before a seat is bound (H3)."""
    _rate_limit(_rl_key(request), "challenge", 10)
    nonce = crypto.new_opaque_token()  # 32 random bytes, hex
    exp = now() + 120
    with connect() as c:
        c.execute("DELETE FROM challenges WHERE expiry < ?", (now(),))
        c.execute("INSERT OR REPLACE INTO challenges(nonce,pubkey,expiry,used) "
                  "VALUES(?,?,?,0)", (nonce, req.device_pubkey, exp))
    return ChallengeResponse(nonce=nonce, expiry=exp)


@app.post("/auth/activate", response_model=TokenBundle)
def activate(req: ActivateRequest, request: Request):
    ip = _client_ip(request)
    _rate_limit(_rl_key(request), "activate", 5)
    if req.app_version < MIN_SUPPORTED_VERSION:
        raise HTTPException(status_code=426, detail="update_required")
    s = get_secrets()
    key_hash = crypto.sha256_hex(req.license_key)
    pubkey = req.fingerprint_inputs.device_pubkey
    # Seat identity is the SSAID alone (see crypto.device_fingerprint): stable
    # across reinstall, so a reinstall re-enrolls the SAME seat instead of burning
    # a new one. The pubkey is the proof-of-possession credential, stored/updated
    # per seat below and re-verified on every refresh.
    fp = crypto.device_fingerprint(s.server_salt, req.fingerprint_inputs.ssaid)
    with connect() as c:
        # Proof-of-possession: the caller must sign the challenge with the hardware
        # key it presents (self-consistent proof it holds a live Keystore key).
        _verify_challenge(c, req.challenge_nonce, pubkey, req.signature, ip, fp)
        lic = c.execute("SELECT * FROM licenses WHERE key_hash=?", (key_hash,)).fetchone()
        if not _license_ok(lic):
            audit(c, "activate_fail", ip, None, fp)
            raise HTTPException(status_code=403, detail="invalid_or_revoked")
        lid = lic["id"]
        maxd = lic["max_devices"] or DEFAULT_MAX_DEVICES
        dev = c.execute("SELECT * FROM devices WHERE license_id=? AND fingerprint=?",
                        (lid, fp)).fetchone()
        # Seat-cap enforcement is done in the WRITE statement itself, not as a
        # separate COUNT-then-write (audit F3): the read-then-write was a TOCTOU
        # race — N concurrent activations with N distinct new fingerprints could
        # all observe active_count == maxd-1 and all insert, overshooting the cap.
        # `... WHERE (SELECT COUNT(*) ...) < maxd` makes the check and the write
        # one atomic statement, and busy_timeout (db.py) serializes overlapping
        # writers so the loser re-reads the committed count and inserts 0 rows.
        if dev is None:
            _reclaim_stale_seat(c, lid, maxd)
            cur = c.execute(
                "INSERT INTO devices(license_id,fingerprint,pubkey,first_seen,last_seen,active) "
                "SELECT ?,?,?,?,?,1 "
                "WHERE (SELECT COUNT(*) FROM devices WHERE license_id=? AND active=1) < ?",
                (lid, fp, pubkey, now(), now(), lid, maxd))
            if cur.rowcount != 1:
                audit(c, "activate_device_limit", ip, lid, fp)
                raise HTTPException(status_code=409, detail="device_limit")
            dev_id = c.execute("SELECT id FROM devices WHERE license_id=? AND fingerprint=?",
                               (lid, fp)).fetchone()["id"]
        else:
            dev_id = dev["id"]
            if not dev["active"]:
                # A previously DEACTIVATED device re-activating is a fresh seat
                # grab — it must re-count against max_devices, or admin
                # deactivation would be a free, client-reversible no-op (H4). Flip
                # active=1 ONLY if under cap, atomically, and re-enroll the PoP key.
                _reclaim_stale_seat(c, lid, maxd)
                cur = c.execute(
                    "UPDATE devices SET last_seen=?, active=1, pubkey=? "
                    "WHERE id=? AND active=0 "
                    "AND (SELECT COUNT(*) FROM devices WHERE license_id=? AND active=1) < ?",
                    (now(), pubkey, dev_id, lid, maxd))
                if cur.rowcount != 1:
                    audit(c, "activate_device_limit", ip, lid, fp)
                    raise HTTPException(status_code=409, detail="device_limit")
            else:
                # Already active: refresh last_seen + re-enroll the PoP key (a
                # reinstall on the same physical device presents a fresh Keystore
                # pubkey; same SSAID → same seat, no cap check needed).
                c.execute("UPDATE devices SET last_seen=?, active=1, pubkey=? WHERE id=?",
                          (now(), pubkey, dev_id))
        access, _, _ = _issue_access(lid, lic["tier"], fp, lic["config_version"])
        refresh, family = crypto.new_opaque_token(), crypto.new_opaque_token()[:16]
        c.execute("INSERT INTO refresh_tokens(license_id,device_id,token_hash,"
                  "family_id,created_at) VALUES(?,?,?,?,?)",
                  (lid, dev_id, crypto.sha256_hex(refresh), family, now()))
        audit(c, "activate", ip, lid, fp)
        return TokenBundle(access_token=access, refresh_token=refresh,
                           lease=_make_lease(lid, "active",
                                             req.fingerprint_inputs.device_pubkey),
                           tier=lic["tier"],
                           config_version=lic["config_version"])


@app.post("/auth/refresh", response_model=TokenBundle)
def refresh(req: RefreshRequest, request: Request):
    ip = _client_ip(request)
    _rate_limit(_rl_key(request), "refresh", 10)
    s = get_secrets()
    pubkey = req.fingerprint_inputs.device_pubkey
    fp = crypto.device_fingerprint(s.server_salt, req.fingerprint_inputs.ssaid)
    th = crypto.sha256_hex(req.refresh_token)
    with connect() as c:
        row = c.execute("SELECT * FROM refresh_tokens WHERE token_hash=?", (th,)).fetchone()
        if row is None:
            raise HTTPException(status_code=401, detail="bad_refresh")
        # Device binding + proof-of-possession are checked BEFORE the reuse logic,
        # so a token replayed from another host (no enrolled key / no private key)
        # is rejected here and can NEVER trigger a family revoke. That stops a thief
        # from griefing the real owner by burning their family, AND stops a benign
        # rejection from nuking the family. Only the genuine device — matching
        # enrolled pubkey plus a valid PoP signature — reaches the reuse handling.
        dev = c.execute("SELECT * FROM devices WHERE id=?", (row["device_id"],)).fetchone()
        if dev is None or dev["fingerprint"] != fp or not dev["active"] \
                or dev["pubkey"] != pubkey:
            audit(c, "refresh_device_mismatch", ip, row["license_id"], fp)
            raise HTTPException(status_code=401, detail="device_mismatch")
        _verify_challenge(c, req.challenge_nonce, pubkey, req.signature, ip, fp)
        lic = c.execute("SELECT * FROM licenses WHERE id=?", (row["license_id"],)).fetchone()
        if not _license_ok(lic):
            audit(c, "refresh_revoked", ip, row["license_id"], fp)
            raise HTTPException(status_code=401, detail="revoked")
        if row["revoked"]:
            # This exact token was explicitly killed (a prior family revoke, an
            # admin deactivate, or a retired lost-response successor). Do not
            # resurrect a chain from it; the client re-activates instead.
            audit(c, "refresh_revoked_token", ip, row["license_id"], fp)
            raise HTTPException(status_code=401, detail="refresh_reuse")
        if row["used"]:
            # Already rotated. Distinguish a benign lost-response retry (the client
            # never received its successor, so no later token was ever used) from
            # genuine theft (the chain already advanced on another copy). A dropped
            # rotation response is routine on mobile and must NOT nuke the family
            # (2026-09-18 availability CRIT — this was the tester lockout).
            succ = c.execute("SELECT used FROM refresh_tokens "
                             "WHERE family_id=? AND id>?",
                             (row["family_id"], row["id"])).fetchall()
            if any(x["used"] for x in succ):
                c.execute("UPDATE refresh_tokens SET revoked=1 WHERE family_id=?",
                          (row["family_id"],))
                audit(c, "refresh_reuse", ip, row["license_id"], fp)
                raise HTTPException(status_code=401, detail="refresh_reuse")
            # Lost-response replay: retire the orphaned successor(s) so they cannot
            # fork a second live chain, then mint a fresh token below. The family
            # survives and the user never sees a logout.
            c.execute("UPDATE refresh_tokens SET revoked=1 "
                      "WHERE family_id=? AND id>?", (row["family_id"], row["id"]))
            audit(c, "refresh_replay_grace", ip, row["license_id"], fp)
        c.execute("UPDATE refresh_tokens SET used=1 WHERE id=?", (row["id"],))
        c.execute("UPDATE devices SET last_seen=? WHERE id=?", (now(), dev["id"]))
        new_refresh = crypto.new_opaque_token()
        c.execute("INSERT INTO refresh_tokens(license_id,device_id,token_hash,"
                  "family_id,created_at) VALUES(?,?,?,?,?)",
                  (lic["id"], row["device_id"], crypto.sha256_hex(new_refresh),
                   row["family_id"], now()))
        access, _, _ = _issue_access(lic["id"], lic["tier"], fp, lic["config_version"])
        audit(c, "refresh", ip, lic["id"], fp)
        return TokenBundle(access_token=access, refresh_token=new_refresh,
                           lease=_make_lease(lic["id"], "active",
                                             req.fingerprint_inputs.device_pubkey),
                           tier=lic["tier"],
                           config_version=lic["config_version"])


@app.post("/config", response_model=ConfigResponse)
def config(req: ConfigRequest, request: Request, authorization: str = Header(None)):
    _rate_limit(_rl_key(request), "config", 30)
    claims = _verify_access(authorization)
    lid = int(claims["lic"])
    s = get_secrets()
    # Validate crypto inputs up front → 400, not an unhandled 500 (L2).
    try:
        client_pub = bytes.fromhex(req.client_x25519_pub)
        client_nonce = bytes.fromhex(req.client_nonce)
    except ValueError:
        raise HTTPException(status_code=400, detail="bad_hex")
    if len(client_pub) != 32 or len(client_nonce) < 16:
        raise HTTPException(status_code=400, detail="bad_params")
    jti = claims.get("jti", "")
    with connect() as c:
        lic = c.execute("SELECT * FROM licenses WHERE id=?", (lid,)).fetchone()
        if not _license_ok(lic):
            raise HTTPException(status_code=401, detail="revoked")
        # M2: the device seat must still be active, not only the license.
        if not _device_active(c, lid, claims.get("did")):
            raise HTTPException(status_code=401, detail="deactivated")
        # One-time use: this access token may fetch config at most once (M1).
        c.execute("DELETE FROM config_spent WHERE expiry < ?", (now(),))
        if c.execute("SELECT 1 FROM config_spent WHERE jti=?", (jti,)).fetchone():
            raise HTTPException(status_code=409, detail="config_replay")
        c.execute("INSERT INTO config_spent(jti, expiry) VALUES(?, ?)",
                  (jti, now() + CONFIG_TTL_SEC + 1200))
        cfg_ver = lic["config_version"]
        audit(c, "config", _client_ip(request), lid, claims.get("did"))
    expiry = now() + CONFIG_TTL_SEC
    aad = f"{jti}|{cfg_ver}|{expiry}".encode()
    # Per-SEAT watermark: key on (license, device) not just license, so the two
    # devices of one license get distinguishable blobs and a leak traces to a
    # seat, not merely a license (2026-09-17 audit, MED). `did` is the server-side
    # HMAC fingerprint from the access token — attacker-opaque and stable per seat.
    seat = f"{lid}:{claims.get('did', '')}"
    # Arm the native decoder's server-gated leash. Its validity is DECOUPLED from
    # the 2-min config expiry and set to a generous, match-safe grace
    # (DECODE_PROFILE_TTL_SEC, 6 h): the profile only proves "a licensed session
    # fetched config recently", so it must outlast a full match or DECODE_LEASH
    # would black out ESP mid-game. An offline/cracked client still gets NO blob
    # it can open, so the anti-crack property is unchanged. See
    # docs/SERVER_GATED_DECODE_DESIGN.md.
    profile_valid_until = now() + DECODE_PROFILE_TTL_SEC
    blob = build_blob(s.server_salt, lid, seat, cfg_ver, req.section, profile_valid_until)
    sealed = crypto.seal_config(blob, client_pub, client_nonce, aad)
    return ConfigResponse(config_version=cfg_ver, expiry=expiry, **sealed)


@app.post("/auth/heartbeat", response_model=HeartbeatResponse)
def heartbeat(req: HeartbeatRequest, request: Request, authorization: str = Header(None)):
    """
    Continuous-auth heartbeat: re-arm the ROLLING decode profile. Same sealed
    X25519->AES-GCM handshake as /config, but cheap (no Bucket-B blob) and NOT
    one-time-jti (one 10-min access token drives several beats). A login-bypassed
    client never reaches here (no access token) so it is never armed; a stubbed or
    network-blocked heartbeat lets the rolling valid_until lapse within ROLLING_TTL
    and decode fail-closes. Revocation (license or device-seat) bites at the next
    beat via _license_ok + _device_active. See docs/CONTINUOUS_AUTH_AND_DECODE_PLAN.md.
    """
    _rate_limit(_rl_key(request), "heartbeat", 30)
    claims = _verify_access(authorization)
    lid = int(claims["lic"])
    try:
        client_pub = bytes.fromhex(req.client_x25519_pub)
        client_nonce = bytes.fromhex(req.client_nonce)
    except ValueError:
        raise HTTPException(status_code=400, detail="bad_hex")
    if len(client_pub) != 32 or len(client_nonce) < 16:
        raise HTTPException(status_code=400, detail="bad_params")
    with connect() as c:
        lic = c.execute("SELECT * FROM licenses WHERE id=?", (lid,)).fetchone()
        if not _license_ok(lic):
            raise HTTPException(status_code=401, detail="revoked")
        if not _device_active(c, lid, claims.get("did")):
            raise HTTPException(status_code=401, detail="deactivated")
        audit(c, "heartbeat", _client_ip(request), lid, claims.get("did"))
    server_now = now()
    valid_until = server_now + ROLLING_TTL_SEC
    # Monotonic epoch (wall-clock seconds; beats are minutes apart, so strictly
    # increasing). The client rejects an ACK whose epoch <= the one it holds, so a
    # replayed older ACK cannot re-arm. AAD binds jti|epoch|valid_until.
    epoch = server_now
    jti = claims.get("jti", "")
    aad = f"{jti}|{epoch}|{valid_until}".encode()
    blob = build_rolling_profile(valid_until, server_now, epoch)
    sealed = crypto.seal_config(blob, client_pub, client_nonce, aad)
    return HeartbeatResponse(epoch=epoch, valid_until=valid_until,
                             interval=HEARTBEAT_INTERVAL_SEC, **sealed)


@app.get("/version", response_model=VersionResponse)
def version(request: Request):
    _rate_limit(_rl_key(request), "version", 60)   # L4: was unthrottled
    m = native.load_manifest("arm64-v8a")
    nat = {"abi": m["abi"], "version": m["version"]} if m else None
    return VersionResponse(min_supported=MIN_SUPPORTED_VERSION,
                           latest=LATEST_VERSION, url=UPDATE_URL, native=nat)


@app.get("/native/manifest")
def native_manifest(request: Request, abi: str = "arm64-v8a"):
    """The signed manifest for the current native lib. The client verifies the
    Ed25519 signature (pinned SERVER_ED25519_PUB_HEX) + SHA-256 before loading.
    Read-only static content; launch-time, never on the packet path."""
    _rate_limit(_rl_key(request), "native", 30)
    if not native.abi_ok(abi):
        raise HTTPException(status_code=400, detail="bad_abi")
    m = native.load_manifest(abi)
    if m is None:
        raise HTTPException(status_code=404, detail="no_native_manifest")
    return m


@app.get("/native/lib/{version}")
def native_lib(version: int, request: Request, abi: str = "arm64-v8a"):
    """The raw signed-and-published `.so` bytes for a version."""
    # The lib is multi-MB; rate-limit it tighter than the tiny manifest to blunt
    # unauthenticated bandwidth amplification (2026-09-18 review M5).
    _rate_limit(_rl_key(request), "native_lib", 10)
    if not native.abi_ok(abi):
        raise HTTPException(status_code=400, detail="bad_abi")
    p = native.lib_path(abi, version)
    if not p.exists():
        raise HTTPException(status_code=404, detail="no_native_lib")
    return FileResponse(str(p), media_type="application/octet-stream",
                        filename=f"libnuvola_native-{version}.so")


@app.get("/health")
def health():
    return {"ok": True}
