"""Unit tests for the /config blob builder — the server half of the
server-gated decode leash (docs/SERVER_GATED_DECODE_DESIGN.md) plus the existing
watermark / list-rotation invariants. Pure (no running server):

    server/.venv/Scripts/python -m pytest test_config_blob.py -q
"""
from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from app.config_blob import (  # noqa: E402
    _CHAIN_DECODE_PARAMS,
    build_blob,
    trace_watermark,
)

SALT = b"unit-test-salt--" * 2  # 32 bytes


def _blob(profile_valid_until: int = 0, seat: str = "1:devA", section=None):
    return json.loads(build_blob(SALT, 1, seat, 7, section, profile_valid_until))


def test_decode_profile_present_when_armed():
    d = _blob(profile_valid_until=1_893_456_000)
    assert "decode_profile" in d
    dp = d["decode_profile"]
    assert dp["valid_until"] == 1_893_456_000
    assert dp["chain"] == _CHAIN_DECODE_PARAMS
    # the chain params carry the real structural values the native decoder needs
    assert dp["chain"]["min_record_x"] == 500
    assert dp["chain"]["max_entity_id"] == 64


def test_decode_profile_absent_when_not_armed():
    d = _blob(profile_valid_until=0)
    assert "decode_profile" not in d, "a zero validity must omit the profile"


def test_params_are_copied_not_shared():
    # build_blob must not hand out a reference an endpoint could mutate.
    d = _blob(profile_valid_until=1)
    d["decode_profile"]["chain"]["min_record_x"] = 999
    assert _CHAIN_DECODE_PARAMS["min_record_x"] == 500, "module constant was mutated"


def test_watermark_is_deterministic_and_traceable():
    a = _blob(seat="1:devA")
    b = _blob(seat="1:devA")
    c = _blob(seat="1:devB")
    assert a["wm"] == b["wm"], "same seat -> same watermark"
    assert a["wm"] != c["wm"], "different seat -> different watermark"
    # a leaked wm traces back to the exact seat that produced it
    assert trace_watermark(SALT, a["wm"], ["1:devB", "1:devA", "2:devC"]) == "1:devA"
    assert trace_watermark(SALT, "deadbeef", ["1:devA"]) is None


def test_config_version_threaded():
    assert _blob()["config_version"] == 7


if __name__ == "__main__":
    # Runs without pytest (the server venv has no pytest): execute every test_*.
    import traceback

    fns = [v for k, v in sorted(globals().items())
           if k.startswith("test_") and callable(v)]
    failed = 0
    for fn in fns:
        try:
            fn()
            print(f"ok   {fn.__name__}")
        except Exception:  # noqa: BLE001
            failed += 1
            print(f"FAIL {fn.__name__}")
            traceback.print_exc()
    print(f"\n{len(fns) - failed}/{len(fns)} passed")
    sys.exit(1 if failed else 0)
