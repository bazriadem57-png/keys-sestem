# Nuvola backend

Licensing + config-delivery API for the Nuvola client. Design:
`docs/LOGIN_AND_SERVER.md`. Ops/runbook: `docs/SERVER_OPS.md`. Threat model:
`docs/SECURITY_MODEL.md`.

## Layout
```
server/
  app/            FastAPI app
    main.py       endpoints: /auth/activate /auth/refresh /config /version /health
    crypto.py     Ed25519 sign, X25519 ECDH, HKDF, AES-256-GCM, fingerprint HMAC
    db.py         SQLite schema + helpers
    config_blob.py per-user watermarked Bucket-B blob builder
    settings.py   secrets (env in prod; dev keyfile fallback) + tunables
    models.py     request/response contracts
  admin.py        SSH-only CLI: mint / revoke / list / trace / rotate
  test_client.py  end-to-end client simulation (also the Java client's reference)
  bucket_b/       server-only Bucket-B sections (withheld from the APK)
  deploy/         systemd unit + Caddyfile
  requirements.txt
```

## Run locally (dev)
```
cd server
python -m venv .venv && . .venv/Scripts/activate   # Windows; use bin/activate on Linux
pip install -r requirements.txt
uvicorn app.main:app --host 127.0.0.1 --port 8000
```
On first run with no `NUVOLA_ED25519_SK_PEM` / `NUVOLA_SERVER_SALT_HEX` env vars,
a **dev** `server_keys.json` is generated (loud warning). Fine for local testing;
set the env vars on the VPS.

Test it end-to-end (server running in another shell):
```
python test_client.py
```
Expect: activate OK → lease signature OK → config OK → refresh OK → replay
refused → ALL CHECKS PASSED.

Mint a real key:
```
python admin.py mint --tier standard --devices 2 --expiry-days 30 --note "buyer#1"
```

## Production (VPS 66.154.107.27)
See `docs/SERVER_OPS.md`: lock SSH, create the `nuvola` user, generate the
Ed25519 key + salt into `/opt/nuvola/nuvola.env`, generate the self-signed cert,
pin its SPKI in the client, install `deploy/nuvola.service` + `deploy/Caddyfile`.
Never commit `server_keys.json`, `nuvola.db`, `nuvola.env`, or the cert key.

## Wire contract (client mirrors this)
- Fingerprint: `HMAC-SHA256(server_salt, SSAID ‖ device_pubkey_b64)`.
- Access token: EdDSA JWT, ~10 min; client reads its own `jti` for the config AAD.
- Config AAD: `f"{jti}|{config_version}|{expiry}"`.
- Config KDF: `HKDF-SHA256(ikm=X25519(server_eph,client_eph), salt=client_nonce,
  info="nuvola-config-v1", len=32)`, then AES-256-GCM unwrap data key → decrypt blob.
- Lease: `base64(canonical_json) + "." + hex(Ed25519 sig)`, verified with the
  server public key offline.
