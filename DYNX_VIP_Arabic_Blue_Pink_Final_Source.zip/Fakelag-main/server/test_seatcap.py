"""Seat-cap enforcement (audit F3) — verifies the atomic conditional
INSERT/UPDATE that replaced the read-then-write TOCTOU in /auth/activate.
Self-contained (stdlib sqlite3 only, no app deps):

    server/.venv/Scripts/python test_seatcap.py   (or any python3)
"""
from __future__ import annotations

import sqlite3
import sys

# Mirrors the `devices` table + its statements in app/db.py / app/main.py.
DDL = """
CREATE TABLE devices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    license_id INTEGER NOT NULL,
    fingerprint TEXT NOT NULL,
    pubkey TEXT,
    first_seen INTEGER NOT NULL,
    last_seen INTEGER NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    UNIQUE(license_id, fingerprint)
);
"""

INSERT_IF_UNDER_CAP = (
    "INSERT INTO devices(license_id,fingerprint,pubkey,first_seen,last_seen,active) "
    "SELECT ?,?,?,?,?,1 "
    "WHERE (SELECT COUNT(*) FROM devices WHERE license_id=? AND active=1) < ?"
)
REACTIVATE_IF_UNDER_CAP = (
    "UPDATE devices SET last_seen=?, active=1, pubkey=? "
    "WHERE id=? AND active=0 "
    "AND (SELECT COUNT(*) FROM devices WHERE license_id=? AND active=1) < ?"
)


def db():
    c = sqlite3.connect(":memory:")
    c.executescript(DDL)
    return c


def insert(c, lid, fp, maxd):
    return c.execute(INSERT_IF_UNDER_CAP, (lid, fp, "pk", 0, 0, lid, maxd)).rowcount


def test_insert_stops_at_cap():
    c = db()
    assert insert(c, 1, "a", 2) == 1
    assert insert(c, 1, "b", 2) == 1
    # Third distinct fingerprint is over the cap of 2 -> inserted 0 rows.
    assert insert(c, 1, "c", 2) == 0
    n = c.execute("SELECT COUNT(*) FROM devices WHERE license_id=1 AND active=1").fetchone()[0]
    assert n == 2, f"cap must hold, got {n}"


def test_other_license_unaffected():
    c = db()
    assert insert(c, 1, "a", 1) == 1
    assert insert(c, 1, "b", 1) == 0  # license 1 full
    assert insert(c, 2, "a", 1) == 1  # license 2 independent
    assert insert(c, 2, "b", 1) == 0


def test_reactivate_respects_cap():
    c = db()
    assert insert(c, 1, "a", 1) == 1
    # a is deactivated (admin); b takes the only seat.
    c.execute("UPDATE devices SET active=0 WHERE license_id=1 AND fingerprint='a'")
    assert insert(c, 1, "b", 1) == 1
    aid = c.execute("SELECT id FROM devices WHERE license_id=1 AND fingerprint='a'").fetchone()[0]
    # a re-activating while b holds the seat -> refused (0 rows).
    assert c.execute(REACTIVATE_IF_UNDER_CAP, (0, "pk", aid, 1, 1)).rowcount == 0
    # free the seat, then a can reactivate.
    c.execute("UPDATE devices SET active=0 WHERE license_id=1 AND fingerprint='b'")
    assert c.execute(REACTIVATE_IF_UNDER_CAP, (0, "pk", aid, 1, 1)).rowcount == 1


def test_unique_constraint_blocks_duplicate_seat():
    c = db()
    assert insert(c, 1, "a", 5) == 1
    try:
        # Same (license, fingerprint) again must violate UNIQUE, not add a seat.
        c.execute(INSERT_IF_UNDER_CAP, (1, "a", "pk", 0, 0, 1, 5))
        raised = False
    except sqlite3.IntegrityError:
        raised = True
    assert raised, "duplicate (license, fingerprint) must be rejected by UNIQUE"


if __name__ == "__main__":
    import traceback

    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for fn in fns:
        try:
            fn()
            print(f"ok   {fn.__name__}")
        except Exception:  # noqa: BLE001
            failed += 1
            print(f"FAIL {fn.__name__}")
            traceback.print_exc()
    print(f"\n{len(fns) - failed}/{len(fns)} passed")
    sys.exit(1 if failed else 0)
