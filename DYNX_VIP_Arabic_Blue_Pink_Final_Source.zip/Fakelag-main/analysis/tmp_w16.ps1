param([string]$Csv)
# SMOOTH SIGNED BYTE-LEVEL DELTAS (+-1, +-2, +-3...) dominate solo changes at bytes 21-24 and 30-31.
# This is the signature of PLAINTEXT BYTES CHANGING SMOOTHLY under a CONSTANT XOR MASK.
# i.e. the keepalive bytes 12+ are (mostly) unmasked or masked with constant bytes, and contain
# smoothly-varying quantities. The structure: several 16-bit fields stepping by small amounts.
# Now: full-plaintext reconstruction attempt via mask guess. In idle, everything but b0/b1 frozen.
# The values like 8603 (w16~900) decreasing ~2/packet = a 100ms ticking countdown timer (from 900, -2/100ms => 20/sec).
# Let's verify w16 decrements over idle stretches.
$rows = Import-Csv $Csv
function HexToBytes([string]$h) {
  $b = New-Object byte[] ($h.Length/2)
  for ($i=0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($h.Substring(2*$i,2),16) }
  return $b
}
$bytes = New-Object System.Collections.ArrayList
foreach ($r in $rows) { [void]$bytes.Add((HexToBytes $r.hex32)) }

# consecutive same-len: track w16 delta histogram (LE, signed)
$dh = @{}
$n = 0
for ($i=1; $i -lt $rows.Count; $i++) {
  if ($rows[$i].len -ne $rows[$i-1].len) { continue }
  $a = $bytes[$i-1]; $b = $bytes[$i]
  $va = $a[16]+256*$a[17]; $vb = $b[16]+256*$b[17]
  $d = $vb - $va
  if ($d -gt 32768) { $d -= 65536 }
  if ($d -lt -32768) { $d += 65536 }
  if (-not $dh.ContainsKey($d)) { $dh[$d]=0 }
  $dh[$d]++
  $n++
}
Write-Host ("w16 (bytes16-17 LE) delta histogram over {0} same-len pairs:" -f $n)
$dh.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 12 | ForEach-Object { Write-Host ("  {0}: {1}" -f $_.Key, $_.Value) }

# w14 (bytes 14-15)
$dh = @{}
for ($i=1; $i -lt $rows.Count; $i++) {
  if ($rows[$i].len -ne $rows[$i-1].len) { continue }
  $a = $bytes[$i-1]; $b = $bytes[$i]
  $va = $a[14]+256*$a[15]; $vb = $b[14]+256*$b[15]
  $d = $vb - $va
  if ($d -gt 32768) { $d -= 65536 }
  if ($d -lt -32768) { $d += 65536 }
  if (-not $dh.ContainsKey($d)) { $dh[$d]=0 }
  $dh[$d]++
}
Write-Host "w14 (bytes14-15 LE) delta histogram:"
$dh.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 12 | ForEach-Object { Write-Host ("  {0}: {1}" -f $_.Key, $_.Value) }
