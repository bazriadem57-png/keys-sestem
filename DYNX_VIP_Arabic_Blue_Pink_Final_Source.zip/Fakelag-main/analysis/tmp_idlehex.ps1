param([string]$Csv)
# IMPORTANT INSIGHT ATTEMPT: maybe the mask is not constant per byte — it's a KEYSTREAM. In pull6 keepalives,
# bytes 4-7 constant (0C DD 0B 0C) and bytes 8-11 constant (85 80 80 08) — these are MASK bytes visible because
# plaintext there is constant/zero. Byte 3 varies with length (0C3D=L57, 0C38=L56...).
# Actually earlier data: pull6 hdr(2-7) = 0C 3D 0C DD 0B 0C for len57, 0C 38 for len56, 0C 3F for len59...
# byte3 = f(len). pull7: 9D 4C 9A AC 9D 9D with byte5 varying with len (A9=L60, AC=L57...).
# So mask bytes at 2..7 are roughly constant per session with byte3/5 modulated by packet length (payload content!).
# KEY: The mask in pull6 has repeating pattern 0C..0C..0B 0C 85 80 80 08 - looks like mask[i] = 0x0C for even, 0x0D-ish for odd?
# Look at raw payload of an IDLE keepalive: 66 7C 0C 27 0C DD 0B 0C 85 80 80 08 E4 D8 50 E4 86 03 ED DC 1B 0D 00 C7 01 00 00 00 00 00 00
# If plaintext of idle keepalive is: [b0 b1 = counter] [type=?] [len] [00 00 00 00 00 ...], then mask = payload XOR plain.
# The trailing 000000000000 suggests mask bytes 26..31 are ZERO -> plaintext zero. So NO MASK on tail?!
# That means the tail IS plaintext! C701 = 455 = maybe health/ammo? And 1B0D = 6925?
# Test: if mask is zero for bytes >= some offset, then values are literal. w22=0x0D1B? etc.
# Let's check whether byte 26.. can be literal: e.g. 00 C7 01 00 ... no wait that's hex pairs: bytes 22..31 = 1B 0D 00 C7 01 00 00 00 00 00
# As LE 16-bit: 0x0D1B=3355, 0xC700=50944, 0x0001=1, 0,0
# Hmm alternatively read as: 1B 0D = 3355; 00 C7 = 50944; 01 00 = 1; 00 00; 00 00
# Or as bytes: 0x1B, 0x0D, 0x00, 0xC7, 0x01, 0x00...
# 0xC7 = 199, 0x01 = 1 -> could be 16-bit LE at offset 25: C7 01 = 455. Suspicious!
# Offsets: 0-indexed byte positions in hex string: 66(0) 7C(1) 0C(2) 27(3) 0C(4) DD(5) 0B(6) 0C(7) 85(8) 80(9) 80(10) 08(11) E4(12) D8(13) 50(14) E4(15) 86(16) 03(17) ED(18) DC(19) 1B(20) 0D(21) 00(22) C7(23) 01(24) 00(25) 00(26) 00(27) 00(28) 00(29) 00(30) 00(31)
# So the idle payload: E4D8 50E4 8603 EDDC 1B0D 00C7 01 then zeros.
# NOTE: 8603 in run was 8E03, 8C03... and EDDC-> varied. The 4-byte group E4D8 50E4 could be a 32-bit timestamp/counter.
# The '03' high bytes: 8E03 8C03 8A03... = LE 0x038E=910, decreasing ~2/packet: a 16-bit value ~910 counting down slowly!
# And EDDC/1B0D: LE 0xDCED=56557, 0x0D1B=3355...
# This is consistent with COUNTER fields. The question remains where POSITION is.
$rows = Import-Csv $Csv
Write-Host ("rows: " + $rows.Count)
# Print hex of 30 consecutive IDLE packets (same len) to see which subfields tick
$cnt = 0
for ($i=1; $i -lt $rows.Count -and $cnt -lt 30; $i++) {
  if ($rows[$i].len -ne $rows[$i-1].len) { continue }
  $h = $rows[$i].hex32
  # idle if tail (bytes 26-31) all zero
  $tail = $h.Substring(52,12)
  if ($tail -ne '000000000000') { continue }
  Write-Host ("  {0}" -f $h)
  $cnt++
}
