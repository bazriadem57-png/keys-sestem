#!/usr/bin/env python3
"""T1: cross-entity pos-9 timer agreement (global timer => K[9]=0 or const).
T2: numeric interpretation of IN/26 pos 10-25 within entity: float32/int32/int16/LE/BE smoothness.
T3: OUT/24 pos 8-23 numeric smoothness (own state)."""
import sys, collections, struct, math

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def main():
    path = sys.argv[1]
    rows = load(path)
    ins = [r for r in rows if r['dir'] == 'IN']
    in26 = [r for r in ins if r['ln'] == 26]
    sub = collections.Counter((r['p'][2], r['p'][5], r['p'][6]) for r in in26).most_common(1)[0][0]
    g = [r for r in in26 if (r['p'][2], r['p'][5], r['p'][6]) == sub]
    byE = collections.defaultdict(list)
    for r in g:
        byE[r['p'][0]].append(r)
    ents = sorted(byE.items(), key=lambda kv: -len(kv[1]))[:6]

    # T1: cross-entity pos9 agreement within 50ms windows
    print("[T1] cross-entity pos9/pos8 agreement (packets within 50ms):")
    mism9 = tot = 0
    mism8 = 0
    for i in range(len(g) - 1):
        a, b = g[i], g[i+1]
        if a['p'][0] != b['p'][0] and abs(b['ts'] - a['ts']) <= 50:
            tot += 1
            if a['p'][9] != b['p'][9]:
                mism9 += 1
            if a['p'][8] != b['p'][8]:
                mism8 += 1
    print(f"  pairs={tot}: pos9 mismatch {mism9} ({100*mism9/max(tot,1):.1f}%), pos8 mismatch {mism8} ({100*mism8/max(tot,1):.1f}%)")
    # distribution of pos9 differences for near-simultaneous pairs
    d9 = collections.Counter((b['p'][9] - a['p'][9]) & 0xFF for a, b in zip(g, g[1:])
                             if a['p'][0] != b['p'][0] and abs(b['ts'] - a['ts']) <= 50)
    print(f"  pos9 delta dist (cross-entity, <=50ms): {d9.most_common(6)}")

    # T2: numeric smoothness within entity for various interpretations
    e, seq = ents[0]
    print(f"\n[T2] entity {e:02X} n={len(seq)}: numeric smoothness of pos 10-25 interpretations.")
    print("  (med |delta| between consecutive packets; ~2-5 packets/sec)")

    def smooth(getter, label):
        vals = [getter(r['p']) for r in seq]
        good = [v for v in vals if v is not None]
        if len(good) < 10:
            return
        deltas = [abs(b - a) for a, b in zip(good, good[1:]) if a is not None and b is not None]
        if not deltas:
            return
        deltas.sort()
        n = len(deltas)
        # also wrap-aware for ints
        print(f"  {label:28s}: n={len(good):4d} med|d|={deltas[n//2]:10.3f} p90={deltas[9*n//10]:10.3f} min={min(good):12.3f} max={max(good):12.3f}")

    for off in (10, 14, 18):
        smooth(lambda p, o=off: struct.unpack('<f', p[o:o+4])[0] if math.isfinite(struct.unpack('<f', p[o:o+4])[0]) and abs(struct.unpack('<f', p[o:o+4])[0]) < 1e7 else None, f"LE float32 @{off}")
        smooth(lambda p, o=off: struct.unpack('>f', p[o:o+4])[0] if math.isfinite(struct.unpack('>f', p[o:o+4])[0]) and abs(struct.unpack('>f', p[o:o+4])[0]) < 1e7 else None, f"BE float32 @{off}")
        smooth(lambda p, o=off: struct.unpack('<i', p[o:o+4])[0], f"LE int32 @{off}")
        smooth(lambda p, o=off: struct.unpack('>i', p[o:o+4])[0], f"BE int32 @{off}")
    for off in (10, 12, 14, 16, 18, 20, 22, 24):
        smooth(lambda p, o=off: struct.unpack('<h', p[o:o+2])[0], f"LE int16 @{off}")

    # float16?
    for off in (10, 12, 14, 16):
        smooth(lambda p, o=off: struct.unpack('<e', p[o:o+2])[0] if math.isfinite(struct.unpack('<e', p[o:o+2])[0]) else None, f"LE float16 @{off}")

    # T3: OUT/24 own state
    outs = [r for r in rows if r['dir'] == 'OUT' and r['ln'] == 24]
    print(f"\n[T3] OUT/24 n={len(outs)} own-state numeric smoothness (31ms cadence):")
    seq = outs
    for off in (8, 12, 16):
        smooth(lambda p, o=off: struct.unpack('<f', p[o:o+4])[0] if math.isfinite(struct.unpack('<f', p[o:o+4])[0]) and abs(struct.unpack('<f', p[o:o+4])[0]) < 1e7 else None, f"LE float32 @{off}")
        smooth(lambda p, o=off: struct.unpack('<i', p[o:o+4])[0], f"LE int32 @{off}")
    for off in (8, 10, 12, 14, 16, 18, 20, 22):
        smooth(lambda p, o=off: struct.unpack('<h', p[o:o+2])[0], f"LE int16 @{off}")

if __name__ == '__main__':
    main()
