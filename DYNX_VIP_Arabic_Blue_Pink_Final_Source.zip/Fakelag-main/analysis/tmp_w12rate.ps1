param([string]$File)
# When input changes, ALL 16 bytes (8-23) change (2079/2267 = 92%) - full diffusion.
# So 24B volatile region is a diffusing encoding: hash/checksum/encryption of the input state.
# LAST angle: keepalive carries aim too? During FREEZE the keepalive was frozen (193/281 pairs) but 88 changed.
# Check keepalive volatility during 24B-active windows vs 24B-idle windows:
# if keepalive bytes move only when 24B moves... they're both driven by player action.
# For the ESP: own position must come from keepalive (only smoothly-varying channel).
# Determine WHICH keepalive offsets are best position candidates via a "smoothness" ranking on ACTIVE pairs only,
# plus check w12 rate consistency (+1050/100ms in one run) => w12 might be tick count, not position.
# Let's check w12 delta vs dt correlation.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapY {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len < 45 || len > 64) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapY]::Parse($File)
$n = [CapY]::Ts.Count
Write-Host ("keepalives: " + $n)
# w12 delta / dt per same-len pair (signed 16-bit LE, bytes 12-13)
$rates = New-Object System.Collections.Generic.List[double]
for ($i=1; $i -lt $n; $i++) {
  if ([CapY]::Lens[$i] -ne [CapY]::Lens[$i-1]) { continue }
  $a = [CapY]::ToBytes([CapY]::Hex[$i-1]); $b = [CapY]::ToBytes([CapY]::Hex[$i])
  if ($a.Length -lt 14) { continue }
  $va = $a[12]+256*$a[13]; $vb = $b[12]+256*$b[13]
  $d = $vb - $va
  if ($d -gt 32768) { $d -= 65536 }
  if ($d -lt -32768) { $d += 65536 }
  if ($d -eq 0) { continue }
  $dt = ([CapY]::Ts[$i] - [CapY]::Ts[$i-1]) / 1000.0
  if ($dt -le 0) { continue }
  $rates.Add($d/$dt)
}
$srt = $rates | Sort-Object
Write-Host ("w12 rate (units/sec) over {0} changing pairs: p5={1:N0} p25={2:N0} med={3:N0} p75={4:N0} p95={5:N0}" -f $rates.Count, $srt[[int]($rates.Count*0.05)], $srt[[int]($rates.Count*0.25)], $srt[[int]($rates.Count*0.5)], $srt[[int]($rates.Count*0.75)], $srt[[int]($rates.Count*0.95)])
# also absolute
$abs = $rates | ForEach-Object { [Math]::Abs($_) } | Sort-Object
Write-Host ("|rate|: med={0:N0} p75={1:N0} p95={2:N0}" -f $abs[[int]($abs.Count*0.5)], $abs[[int]($abs.Count*0.75)], $abs[[int]($abs.Count*0.95)])
