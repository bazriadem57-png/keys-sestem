#!/usr/bin/env python3
"""Checksum-structure hunt on IN/26 (and other inbound families).

Hypothesis: p8 = checksum(plaintext p9..p25) computed BEFORE masking.
Then for XOR-type checksum:  Q = ct[8] ^ XOR(ct[9..25]) = K[8]^...^K[25] = session const.
For additive: A = sum(ct[8..25]) mod 256 = 2*sum(plain[9..25]) + ... (messy) — test anyway:
  if plain[8] = sum(plain[9..25]) mod 256, then
  sum(ct[8..25]) = sum(plain) + sum(K over 8..25)
                 = 2*sum(plain[9..25]) + sum(K) mod 256 — not constant.
  Instead test: (sum(ct[9..25]) - ct[8]) mod 256 = sum(K[9..25]) - K[8] = const.
Also test ranges starting at 2 (full payload after header) and including p1.
"""
import sys, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def xor_range(p, lo, hi):
    x = 0
    for i in range(lo, hi + 1):
        x ^= p[i]
    return x

def main():
    path = sys.argv[1]
    rows = load(path)
    ins = [r for r in rows if r['dir'] == 'IN']

    for L in (26, 25, 24, 23, 22):
        pk = [r for r in ins if r['ln'] == L]
        if len(pk) < 50:
            continue
        print(f"\nIN/{L} n={len(pk)}")
        # Test 1: ct[8] == XOR(ct[9..L-1])? (checksum over ciphertext)
        ok = sum(1 for r in pk if r['p'][8] == xor_range(r['p'], 9, L - 1))
        print(f"  ct[8]==XOR(ct[9..{L-1}]): {ok}/{len(pk)}")
        # Test 2: Q = ct[8]^XOR(ct[9..L-1]) constant?
        Q = collections.Counter(r['p'][8] ^ xor_range(r['p'], 9, L - 1) for r in pk)
        top = Q.most_common(3)
        print(f"  Q=ct[8]^XOR(ct[9..{L-1}]) top: {[(f'{v:02X}', c, f'{100*c/len(pk):.0f}%') for v, c in top]}")
        # Test 3: additive: (sum(ct[9..L-1]) - ct[8]) mod 256 constant?
        S = collections.Counter((sum(r['p'][9:L]) - r['p'][8]) % 256 for r in pk)
        top = S.most_common(3)
        print(f"  (sum(ct[9..])-ct[8]) mod 256 top: {[(f'{v:02X}', c, f'{100*c/len(pk):.0f}%') for v, c in top]}")
        # Test 4: Q over full range incl header: ct[8]^XOR(ct[2..7])^XOR(ct[9..])
        Q2 = collections.Counter(r['p'][8] ^ xor_range(r['p'], 2, 7) ^ xor_range(r['p'], 9, L - 1) for r in pk)
        top = Q2.most_common(3)
        print(f"  Q2 (incl hdr) top: {[(f'{v:02X}', c, f'{100*c/len(pk):.0f}%') for v, c in top]}")
        # Test 5: p1 as checksum: ct[1] == XOR(ct[9..L-1]) or with 0x7F mask?
        ok1 = sum(1 for r in pk if (r['p'][1] & 0x7F) == (xor_range(r['p'], 9, L - 1) & 0x7F))
        print(f"  (ct[1]&7F)==(XOR(ct[9..])&7F): {ok1}/{len(pk)}")
        Q3 = collections.Counter((r['p'][1] ^ xor_range(r['p'], 9, L - 1)) & 0xFF for r in pk)
        print(f"  ct[1]^XOR(ct[9..]) top: {[(f'{v:02X}', c, f'{100*c/len(pk):.0f}%') for v, c in Q3.most_common(3)]}")
        # Test 6: ct[1] bit7 pattern
        b7 = collections.Counter(r['p'][1] >> 7 for r in pk)
        print(f"  ct[1] bit7 counts: {dict(b7)}  max ct[1]={max(r['p'][1] for r in pk):02X} min={min(r['p'][1] for r in pk):02X}")

if __name__ == '__main__':
    main()
