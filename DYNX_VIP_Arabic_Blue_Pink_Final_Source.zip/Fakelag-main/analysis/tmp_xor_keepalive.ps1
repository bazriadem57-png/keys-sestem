param([string]$File)
# XOR consecutive same-length keepalive payloads; show XOR masks (mask cancels -> only changed bytes show)
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class Cap6 {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len < 45 || len > 64) continue;
      string hex = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in hex) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(hex);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[Cap6]::Parse($File)
$n = [Cap6]::Ts.Count

foreach ($L in (57,58,59,60)) {
  $idx = New-Object System.Collections.Generic.List[int]
  for ($i=0; $i -lt $n; $i++) { if ([Cap6]::Lens[$i] -eq $L) { $idx.Add($i) } }
  if ($idx.Count -lt 100) { continue }
  Write-Host ("`n===== len={0} count={1}" -f $L, $idx.Count)
  # find longest run of consecutive same-length packets (no other keepalive length in between)
  $runs = New-Object System.Collections.Generic.List[object]
  $start = 0
  for ($j=1; $j -le $idx.Count; $j++) {
    $brk = ($j -eq $idx.Count)
    if (-not $brk) {
      # find if any other keepalive packet lies between idx[j-1] and idx[j]
      $a = $idx[$j-1]; $b = $idx[$j]
      for ($i=$a+1; $i -lt $b; $i++) { $brk = $true; break }
    }
    if ($brk) {
      $len = $j - $start
      if ($len -ge 5) { $runs.Add(@($idx.GetRange($start,$len).ToArray())) }
      $start = $j
    }
  }
  Write-Host ("runs>=5: {0}" -f $runs.Count)
  foreach ($run in ($runs | Select-Object -First 3)) {
    Write-Host ("-- run of {0} packets, ts {1}..{2}" -f $run.Count, [Cap6]::Ts[$run[0]], [Cap6]::Ts[$run[-1]])
    for ($j=0; $j -lt [Math]::Min(8, $run.Count); $j++) {
      Write-Host ("   " + [Cap6]::Hex[$run[$j]])
    }
    # XOR consecutive
    for ($j=1; $j -lt [Math]::Min(8, $run.Count); $j++) {
      $a = [Cap6]::ToBytes([Cap6]::Hex[$run[$j-1]])
      $b = [Cap6]::ToBytes([Cap6]::Hex[$run[$j]])
      $x = New-Object System.Text.StringBuilder
      for ($k=0; $k -lt [Math]::Min(32, $a.Length); $k++) { [void]$x.Append(('{0:X2}' -f ($a[$k] -bxor $b[$k]))) }
      Write-Host ("  XOR " + $x.ToString())
    }
  }
}
