param([string]$Csv)
# While tail all-zero (idle): does byte 12-13 / 18-19 continue changing? -> that would identify timer vs position.
$rows = Import-Csv $Csv
function HexToBytes([string]$h) {
  $b = New-Object byte[] ($h.Length/2)
  for ($i=0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($h.Substring(2*$i,2),16) }
  return $b
}
# group rows into idle vs active by tail
$idle = New-Object System.Collections.Generic.List[object]
$active = New-Object System.Collections.Generic.List[object]
foreach ($r in $rows) {
  $b = HexToBytes $r.hex32
  $nz = 0
  for ($k=26; $k -lt 32; $k++) { if ($b[$k] -ne 0) { $nz++ } }
  if ($nz -eq 0) { $idle.Add($r) } else { $active.Add($r) }
}
Write-Host ("idle rows: {0}  active rows: {1}" -f $idle.Count, $active.Count)

# within idle, consecutive same-len pairs: which bytes change?
function Vol($list, $label) {
  $chg = New-Object int[] 32; $pairs = 0
  for ($j=1; $j -lt $list.Count; $j++) {
    if ($list[$j].len -ne $list[$j-1].len) { continue }
    $a = HexToBytes $list[$j-1].hex32
    $b = HexToBytes $list[$j].hex32
    for ($k=0; $k -lt 32; $k++) { if ($a[$k] -ne $b[$k]) { $chg[$k]++ } }
    $pairs++
  }
  $line = ""
  for ($k=0; $k -lt 32; $k++) { $line += ("{0,3} " -f [int](100*$chg[$k]/[Math]::Max(1,$pairs))) }
  Write-Host ("{0} (pairs={1}): {2}" -f $label, $pairs, $line)
}
Vol $idle "IDLE  "
Vol $active "ACTIVE"
