param([string]$File)
# Keepalive len mapping: for pull7 220209, byte3=0x4C constant while pull6 had varying byte3. 
# In pull7: hdr bytes 4-7 vary: 9AA C.. etc. Actually hdr(2-7)=0x9D4C9AAC9D9D -> bytes2..7 = 9D 4C 9A AC 9D 9D.
# Let's tabulate full 8-byte header (bytes 0..7) distribution for keepalives and how it maps to len.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapE {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static List<string> Dir = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw); Dir.Add(p[3]);
    }
  }
}
"@
Add-Type -TypeDefinition $src
[CapE]::Parse($File)
$n = [CapE]::Ts.Count
Write-Host ("OUT rows parsed: " + $n)

# group keepalive rows by bytes 2-7 (6-byte header), then show len distribution within each group
$groups = @{}
for ($i=0; $i -lt $n; $i++) {
  $l = [CapE]::Lens[$i]
  if ($l -lt 45 -or $l -gt 64) { continue }
  if ([CapE]::Hex[$i].Length -lt 16) { continue }
  $hdr = [CapE]::Hex[$i].Substring(4,12)  # bytes 2-7
  if (-not $groups.ContainsKey($hdr)) { $groups[$hdr] = @{} }
  if (-not $groups[$hdr].ContainsKey($l)) { $groups[$hdr][$l] = 0 }
  $groups[$hdr][$l]++
}
Write-Host "keepalive groups by bytes2-7 header (with len distribution):"
foreach ($g in ($groups.GetEnumerator() | Sort-Object { ($_.Value.Values | Measure-Object -Sum).Sum } -Descending | Select-Object -First 15)) {
  $lens = ($g.Value.GetEnumerator() | Sort-Object Name | ForEach-Object { "L{0}x{1}" -f $_.Key, $_.Value }) -join ' '
  Write-Host ("  hdr=0x{0}  total={1}  {2}" -f $g.Key, ($g.Value.Values | Measure-Object -Sum).Sum, $lens)
}
# Also byte0-1 volatility within one header group: are they a counter?
Write-Host "`n--- within biggest header group, first 20 (byte0,byte1) and 16-bit LE:"
$bigHdr = ($groups.GetEnumerator() | Sort-Object { ($_.Value.Values | Measure-Object -Sum).Sum } -Descending | Select-Object -First 1).Key
$shown = 0
for ($i=0; $i -lt $n -and $shown -lt 20; $i++) {
  $l = [CapE]::Lens[$i]
  if ($l -lt 45 -or $l -gt 64) { continue }
  if ([CapE]::Hex[$i].Length -lt 16) { continue }
  if ([CapE]::Hex[$i].Substring(4,12) -ne $bigHdr) { continue }
  $b0 = [Convert]::ToInt32([CapE]::Hex[$i].Substring(0,2),16)
  $b1 = [Convert]::ToInt32([CapE]::Hex[$i].Substring(2,2),16)
  Write-Host ("  ts={0} len={1} b0={2,3} b1={3,3} v16LE={4}" -f [CapE]::Ts[$i], $l, $b0, $b1, ($b0 + 256*$b1))
  $shown++
}
