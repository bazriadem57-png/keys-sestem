param([string]$Csv)
# w20 and w24 move together (47170/47184, 47683/47688, 48194/48196...) - correlated pair!
# w12 rises ~+1050/packet (100ms) => ~10.5 units/ms. w18 falls then wraps.
# Look: w20 ~ w24 with small offset. Check correlation of w20 vs w24, and w12 vs time.
$rows = Import-Csv $Csv
function HexToBytes([string]$h) {
  $b = New-Object byte[] ($h.Length/2)
  for ($i=0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($h.Substring(2*$i,2),16) }
  return $b
}
$bytes = New-Object System.Collections.ArrayList
foreach ($r in $rows) { [void]$bytes.Add((HexToBytes $r.hex32)) }

# Collect (w20, w24) pairs; compute w20-w24 differences
$diffs = @{}
for ($i=0; $i -lt $rows.Count; $i++) {
  $b = $bytes[$i]
  $w20 = $b[20]+256*$b[21]; $w24 = $b[24]+256*$b[25]
  $d = (($w20 - $w24) + 65536) % 65536
  if ($d -gt 32768) { $d -= 65536 }
  if (-not $diffs.ContainsKey($d)) { $diffs[$d]=0 }
  $diffs[$d]++
}
Write-Host "w20-w24 difference histogram (top 10):"
$diffs.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 10 | ForEach-Object { Write-Host ("  d={0}: {1}" -f $_.Key, $_.Value) }

# w12 vs w18: check w12+w18 (maybe complementary)
$sums = @{}
for ($i=0; $i -lt $rows.Count; $i++) {
  $b = $bytes[$i]
  $w12 = $b[12]+256*$b[13]; $w18 = $b[18]+256*$b[19]
  $s = ($w12 + $w18) % 65536
  if (-not $sums.ContainsKey($s)) { $sums[$s]=0 }
  $sums[$s]++
}
Write-Host "w12+w18 mod 65536 histogram (top 10):"
$sums.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 10 | ForEach-Object { Write-Host ("  s={0}: {1}" -f $_.Key, $_.Value) }

# w22 vs w26
$diffs2 = @{}
for ($i=0; $i -lt $rows.Count; $i++) {
  $b = $bytes[$i]
  $w22 = $b[22]+256*$b[23]; $w26 = $b[26]+256*$b[27]
  $d = (($w22 - $w26) + 65536) % 65536
  if ($d -gt 32768) { $d -= 65536 }
  if (-not $diffs2.ContainsKey($d)) { $diffs2[$d]=0 }
  $diffs2[$d]++
}
Write-Host "w22-w26 difference histogram (top 10):"
$diffs2.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 10 | ForEach-Object { Write-Host ("  d={0}: {1}" -f $_.Key, $_.Value) }
