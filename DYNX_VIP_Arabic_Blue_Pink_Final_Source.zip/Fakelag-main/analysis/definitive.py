#!/usr/bin/env python3
"""Definitive tests: selection bias, entity grouping, hit-packet masking, K extraction."""
import sys, os, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def hist_line(pk, i):
    c = collections.Counter(r['p'][i] for r in pk if i < len(r['p']))
    tot = sum(c.values())
    tops = c.most_common(3)
    return ' | '.join(f"{v:02X}:{100*cnt/tot:.0f}%" for v, cnt in tops) + f"  uniq={len(c)}"

def main():
    for path in sys.argv[1:]:
        rows = load(path)
        name = os.path.basename(path)
        ins = [r for r in rows if r['dir'] == 'IN']
        print(f"\n{'='*90}\nFILE: {name} rows={len(rows)}")

        # T1: selection bias — ALL IN/25, IN/26 packets: fraction with tail 00 00
        for L in (25, 26):
            pk = [r for r in ins if r['ln'] == L]
            if len(pk) < 50:
                continue
            tz = sum(1 for r in pk if r['p'][-2:] == b'\x00\x00')
            # also per-position value 00 frequency at tail positions
            print(f"\n[T1] ALL IN/{L}: n={len(pk)}, tail00={tz} ({100*tz/len(pk):.1f}%)")
            for i in list(range(0, 8)) + list(range(L-8, L)):
                print(f"   pos {i:2d}: {hist_line(pk, i)}")

        # T2: entity grouping on IN/26 pos0
        in26 = [r for r in ins if r['ln'] == 26]
        if len(in26) > 100:
            byE = collections.defaultdict(list)
            for r in in26:
                byE[r['p'][0]].append(r)
            print(f"\n[T2] IN/26 grouped by pos0: {len(byE)} groups; sizes: {sorted((len(v) for v in byE.values()), reverse=True)[:15]}")
            # biggest group: consecutive delta structure
            big = max(byE.values(), key=len)
            print(f"  biggest group n={len(big)}: pos0={big[0]['p'][0]:02X}")
            print("  per-pos: mode share | consecutive-pair XOR zero% (within group):")
            for i in range(26):
                c = collections.Counter(r['p'][i] for r in big)
                v, cnt = c.most_common(1)[0]
                z = sum(1 for a, b in zip(big, big[1:]) if a['p'][i] ^ b['p'][i] == 0)
                print(f"   {i:2d}: mode {v:02X}@{100*cnt/len(big):2.0f}%  xor0={100*z/(len(big)-1):3.0f}%")

        # T3: hit packets — are they masked like IN/26? Compare pos 2-7 with IN/26 constants
        # Use relaxed hit filter WITHOUT requiring tail-zero (use dmg<=130 + len 22-26 + tail 0000),
        # but ALSO show the complement (tail nonzero) for bias check.
        hits = [r for r in ins if 22 <= r['ln'] <= 26 and r['p'][-2:] == b'\x00\x00' and r['p'][-3] <= 130]
        nonhit = [r for r in ins if 22 <= r['ln'] <= 26 and not (r['p'][-2:] == b'\x00\x00' and r['p'][-3] <= 130)]
        print(f"\n[T3] len22-26 inbound: hitlike={len(hits)} other={len(nonhit)}")
        for label, pk in (('HITLIKE', hits), ('OTHER', nonhit)):
            if len(pk) < 20:
                continue
            print(f"  {label} n={len(pk)} positions 0-21:")
            for i in range(0, 22):
                print(f"   {i:2d}: {hist_line(pk, i)}")

if __name__ == '__main__':
    main()
