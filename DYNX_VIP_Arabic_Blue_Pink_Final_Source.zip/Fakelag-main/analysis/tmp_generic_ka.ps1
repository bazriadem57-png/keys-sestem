param([string]$Csv)
# Summarize keepalive structure hypothesis and validate on any capture (session-independent).
$File = $Csv
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapP {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len < 45 || len > 64) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapP]::Parse($File)
$n = [CapP]::Ts.Count
Write-Host ("keepalive packets: " + $n)
$bytes = New-Object System.Collections.ArrayList
foreach ($i in 0..($n-1)) { [void]$bytes.Add([CapP]::ToBytes([CapP]::Hex[$i])) }

# solo-byte changes
$soloByte = @{}
for ($i=1; $i -lt $n; $i++) {
  if ([CapP]::Lens[$i] -ne [CapP]::Lens[$i-1]) { continue }
  $a = $bytes[$i-1]; $b = $bytes[$i]
  $changed = @()
  for ($k=12; $k -lt [Math]::Min(32,$a.Length); $k++) { if ($a[$k] -ne $b[$k]) { $changed += $k } }
  if ($changed.Count -eq 1) {
    $k = $changed[0]
    if (-not $soloByte.ContainsKey($k)) { $soloByte[$k]=0 }
    $soloByte[$k]++
  }
}
Write-Host "solo-byte change counts by offset:"
foreach ($k in ($soloByte.Keys | Sort-Object)) { Write-Host ("  byte {0}: {1}" -f $k, $soloByte[$k]) }

# idle runs: fully frozen beyond b0/b1
$idlePairs = 0; $activePairs = 0
for ($i=1; $i -lt $n; $i++) {
  if ([CapP]::Lens[$i] -ne [CapP]::Lens[$i-1]) { continue }
  $a = $bytes[$i-1]; $b = $bytes[$i]
  $ch = $false
  for ($k=2; $k -lt [Math]::Min(32,$a.Length); $k++) { if ($a[$k] -ne $b[$k]) { $ch = $true; break } }
  if ($ch) { $activePairs++ } else { $idlePairs++ }
}
Write-Host ("same-len pairs: idle(frozen)={0} active={1}" -f $idlePairs, $activePairs)
