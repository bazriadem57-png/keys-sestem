param([string]$File)
# 24B stream: bytes 8-15 vs 16-23 have different change rates in pull5 (95% vs 98%) - two 8-byte groups.
# Hypothesis: 8-15 = movement input (joystick), 16-23 = aim/camera (mouse). Both volatile when active.
# Deep dive: 16-bit LE values at 8..22 and their delta histograms for a session; check for angle-like wrap.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapR {
  public static List<long> Ts = new List<long>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len != 24) continue;
      string raw = p[p.Length-1];
      if (raw.Length != 48) continue;
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapR]::Parse($File)
$n = [CapR]::Ts.Count
Write-Host ("24B OUT packets: " + $n)
$bytes = New-Object System.Collections.ArrayList
foreach ($i in 0..($n-1)) { [void]$bytes.Add([CapR]::ToBytes([CapR]::Hex[$i])) }

# Check: when bytes 8-15 are frozen but 16-23 change (aim-only), and vice versa (move-only)
$aimOnly = 0; $moveOnly = 0; $both = 0; $neither = 0
for ($i=1; $i -lt $n; $i++) {
  $a = $bytes[$i-1]; $b = $bytes[$i]
  $m = $false; $aim = $false
  for ($k=8; $k -lt 16; $k++) { if ($a[$k] -ne $b[$k]) { $m = $true; break } }
  for ($k=16; $k -lt 24; $k++) { if ($a[$k] -ne $b[$k]) { $aim = $true; break } }
  if ($m -and $aim) { $both++ } elseif ($m) { $moveOnly++ } elseif ($aim) { $aimOnly++ } else { $neither++ }
}
Write-Host ("moveOnly(8-15)={0} aimOnly(16-23)={1} both={2} neither={3}" -f $moveOnly, $aimOnly, $both, $neither)

# During aimOnly pairs: 16-bit LE deltas at 16-17..22-23
$dh = @{}
foreach ($off in @(16,18,20,22)) { $dh[$off] = @{} }
for ($i=1; $i -lt $n; $i++) {
  $a = $bytes[$i-1]; $b = $bytes[$i]
  $m = $false
  for ($k=8; $k -lt 16; $k++) { if ($a[$k] -ne $b[$k]) { $m = $true; break } }
  if ($m) { continue }
  $aim = $false
  for ($k=16; $k -lt 24; $k++) { if ($a[$k] -ne $b[$k]) { $aim = $true; break } }
  if (-not $aim) { continue }
  foreach ($off in @(16,18,20,22)) {
    $va = $a[$off]+256*$a[$off+1]; $vb = $b[$off]+256*$b[$off+1]
    $d = $vb - $va
    if ($d -gt 32768) { $d -= 65536 }
    if ($d -lt -32768) { $d += 65536 }
    if (-not $dh[$off].ContainsKey($d)) { $dh[$off][$d]=0 }
    $dh[$off][$d]++
  }
}
foreach ($off in @(16,18,20,22)) {
  Write-Host ("aimOnly w{0} deltas top10: {1}" -f $off, (($dh[$off].GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 10 | ForEach-Object { "{0}x{1}" -f $_.Key, $_.Value }) -join ' '))
}
