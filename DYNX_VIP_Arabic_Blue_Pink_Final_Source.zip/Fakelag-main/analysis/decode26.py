#!/usr/bin/env python3
"""Decode pipeline: infer per-position mask from unmasked session families (IN/11/12/13)
and apply to IN/26. Includes entity-relative-position cluster search."""
import sys, os, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def small_packet_key(ins):
    """IN/11,12,13 packets share pos2-7 keystream but pos3 varies by family.
    Use IN/13 for pos 0-7 with corrections."""
    # From observed: IN/13 has pos 2:C8 3:CD 4:C8 5:CB 6:C8 7:C8 (16:10)
    # OUT/24 has           pos 2:C8 3:D8 4:C8 5:CA 6:C8 7:C9
    # IN/26 has            pos 3:D8 4:C8 7:C9  — matches OUT/24!
    # So OUT/24 gives K at 2-7 directly (same key, plaintext header 00 00 00 00 00 00-ish)
    pass

def main():
    for path in sys.argv[1:]:
        rows = load(path)
        name = os.path.basename(path)
        ins = [r for r in rows if r['dir'] == 'IN']
        outs = [r for r in rows if r['dir'] == 'OUT']
        print(f"\n{'='*90}\nFILE: {name}")

        # Step 1: K[0..7] from OUT/24 mode (assume plaintext header all-zero-ish?)
        out24 = [r for r in outs if r['ln'] == 24]
        in26 = [r for r in ins if r['ln'] == 26]
        if len(out24) < 100 or len(in26) < 100:
            print("  not enough packets")
            continue
        K = [None] * 26
        conf = [0] * 26
        for i in range(8):
            c = collections.Counter(r['p'][i] for r in out24)
            v, cnt = c.most_common(1)[0]
            K[i] = v
            conf[i] = cnt / len(out24)
        print(f"K[0..7] from OUT/24 mode: " + ' '.join(f"{v:02X}@{c:.0%}" if v is not None else '??' for v, c in zip(K[:8], conf[:8])))

        # Step 2: IN/26 header decode check: ct[3]^K[3] should be plaintext
        # OUT/24: pos2=C8 pos3=D8 pos4=C8 -> if plaintext 00, K=C8,D8,C8. IN/26 pos3=D8 -> plain 00. good.
        # What is OUT/24 plaintext header actually? 0x65 0x4C... in 13:43 (ct). If K=AF: 0x65^AF=0xCA...
        # Let's decode IN/26 with K from OUT/24 and print samples + histograms of decoded bytes 8-25
        dec = [bytes(r['p'][i] ^ K[i] if i < 8 and K[i] is not None else r['p'][i] for i in range(26)) for r in in26]
        print("\nDecoded IN/26 samples (pos 0-7 XORed with K, 8-25 raw):")
        for r, d in list(zip(in26, dec))[:6]:
            print(f"  raw {r['p'].hex().upper()}")
            print(f"  dec {d.hex().upper()}")

        # Step 3: coordinate search — within one entity, decode with candidate K extension.
        # Assume pos 8-25 are position data; test all 256 values of K[8] (say) by smoothness?
        # Better: entity-frame search described in analysis.
        byE = collections.defaultdict(list)
        for r, d in zip(in26, dec):
            byE[r['p'][0]].append((r, d))
        big = max(byE.values(), key=len)
        print(f"\nEntity pos0={big[0][0]['p'][0]:02X} n={len(big)} — consecutive decoded-byte magnitudes:")
        # treat pairs (10,11),(12,13),...,(24,25) as LE 16-bit; report |delta| stats per pair
        for lo in (8, 10, 12, 14, 16, 18, 20, 22, 24):
            if lo + 1 >= 26: break
            vals = [(d[lo] | (d[lo+1] << 8)) for _, d in big]
            deltas = [abs(b - a) for a, b in zip(vals, vals[1:])]
            deltas.sort()
            n = len(deltas)
            if n:
                print(f"  bytes {lo}-{lo+1} LE16: med|d|={deltas[n//2]:5d} p90={deltas[9*n//10]:5d} max={deltas[-1]:5d}")

if __name__ == '__main__':
    main()
