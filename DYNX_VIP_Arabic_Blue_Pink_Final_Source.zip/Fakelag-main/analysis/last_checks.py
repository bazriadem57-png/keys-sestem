#!/usr/bin/env python3
"""Last checks:
 A: IN/26 p0 exact value set (entity IDs ^ M[0]?) across sessions.
 B: OUT/24 missing byte values at positions 8-14 (uniq ~230).
 C: within-entity p10-17 block stay vs byte stay (block update structure).
 D: IN/26 p1 7-bit structure: is p1 == f(payload)? test 7-bit xor/additive over ct and pt-guess.
"""
import sys, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

SESSIONS = [
    ('13:43', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_134332.txt'),
    ('14:50', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_145006.txt'),
    ('14:58', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_145845.txt'),
    ('15:19', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_151920.txt'),
    ('15:46', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_154602.txt'),
    ('16:10', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_161055.txt'),
]

def main():
    for name, path in SESSIONS:
        rows = load(path)
        ins = [r for r in rows if r['dir'] == 'IN']
        outs = [r for r in rows if r['dir'] == 'OUT']
        in26 = [r for r in ins if r['ln'] == 26]
        out24 = [r for r in outs if r['ln'] == 24]

        # A: p0 value set
        p0in = collections.Counter(r['p'][0] for r in in26)
        p0out = collections.Counter(r['p'][0] for r in out24)
        sin = sorted(p0in)
        sout = sorted(p0out)
        # check contiguity
        cont_in = sin == list(range(sin[0], sin[0]+len(sin))) if sin else False
        cont_out = sout == list(range(sout[0], sout[0]+len(sout))) if sout else False
        print(f"\n{name}:")
        print(f"  IN/26 p0: {len(sin)} values [{' '.join(f'{x:02X}' for x in sin)}] contiguous={cont_in}")
        print(f"  OUT/24 p0: {len(sout)} values [{' '.join(f'{x:02X}' for x in sout)}] contiguous={cont_out}")

        # B: missing values at pos 8-14
        if out24:
            for i in (8, 10, 12):
                present = set(r['p'][i] for r in out24)
                missing = [v for v in range(256) if v not in present]
                if missing:
                    print(f"  OUT/24 pos{i}: {len(missing)} missing: {' '.join(f'{v:02X}' for v in missing[:26])}")

        # C: block vs byte stay (16:10-style dominant subtype)
        if in26:
            sub = collections.Counter((r['p'][2], r['p'][5], r['p'][6]) for r in in26).most_common(1)[0][0]
            g = [r for r in in26 if (r['p'][2], r['p'][5], r['p'][6]) == sub]
            byE = collections.defaultdict(list)
            for r in g:
                byE[r['p'][0]].append(r)
            e, seq = max(byE.items(), key=lambda kv: len(kv[1]))
            if len(seq) > 100:
                # joint distribution: number of changed bytes in block A (10-17) vs block B (18-25)
                chgA = collections.Counter()
                chgB = collections.Counter()
                for a, b in zip(seq, seq[1:]):
                    chgA[sum(1 for i in range(10, 18) if a['p'][i] != b['p'][i])] += 1
                    chgB[sum(1 for i in range(18, 26) if a['p'][i] != b['p'][i])] += 1
                n = len(seq) - 1
                print(f"  entity {e:02X} n={len(seq)}: #changed-bytes dist in block p10-17: {[(k, f'{100*c/n:.0f}%') for k, c in sorted(chgA.items())]}")
                print(f"                        #changed-bytes dist in block p18-25: {[(k, f'{100*c/n:.0f}%') for k, c in sorted(chgB.items())]}")

if __name__ == '__main__':
    main()
