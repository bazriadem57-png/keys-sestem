#!/usr/bin/env python3
"""Split IN/26 entity streams by p9 high nibble (D/E flag) and test smoothness per substream.
If substreams are smooth -> payload is XOR-masked structured data (recoverable).
If still wild -> encrypted."""
import sys, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def analyze(seq, label):
    if len(seq) < 30:
        print(f"  {label}: n={len(seq)} too small")
        return
    # consecutive identical per position
    zf = []
    for i in range(10, 26):
        z = sum(1 for a, b in zip(seq, seq[1:]) if a['p'][i] == b['p'][i])
        zf.append(int(100 * z / (len(seq) - 1)))
    nchg = collections.Counter(sum(1 for i in range(10, 26) if a['p'][i] != b['p'][i]) for a, b in zip(seq, seq[1:]))
    few = sum(c for k, c in nchg.items() if k <= 4)
    # small-delta fraction per byte (delta magnitude <= 15 arithmetic)
    small = []
    for i in range(10, 26):
        s = sum(1 for a, b in zip(seq, seq[1:]) if abs((b['p'][i] - a['p'][i]) & 0xFF) <= 15 or abs(((b['p'][i] - a['p'][i]) & 0xFF) - 256) <= 15)
        small.append(int(100 * s / (len(seq) - 1)))
    print(f"  {label} n={len(seq)}:")
    print(f"    identical%/pos10-25: {' '.join(map(str, zf))}")
    print(f"    |delta|<=15%/pos:    {' '.join(map(str, small))}")
    print(f"    pairs with <=4 changed bytes (of 16): {100*few/(len(seq)-1):.0f}%")

def main():
    path = sys.argv[1]
    rows = load(path)
    ins = [r for r in rows if r['dir'] == 'IN']
    in26 = [r for r in ins if r['ln'] == 26]
    sub = collections.Counter((r['p'][2], r['p'][5], r['p'][6]) for r in in26).most_common(1)[0][0]
    g = [r for r in in26 if (r['p'][2], r['p'][5], r['p'][6]) == sub]
    byE = collections.defaultdict(list)
    for r in g:
        byE[r['p'][0]].append(r)

    for e, seq in sorted(byE.items(), key=lambda kv: -len(kv[1]))[:3]:
        print(f"\nentity {e:02X} n={len(seq)}")
        # split by p9 high nibble
        byH = collections.defaultdict(list)
        for r in seq:
            byH[r['p'][9] >> 4].append(r)
        for h, s in sorted(byH.items()):
            analyze(s, f"p9hi={h:X}")
        # split by p1 parity / ranges? try p1>>6
        byP = collections.defaultdict(list)
        for r in seq:
            byP[r['p'][1] >> 5].append(r)
        for h, s in sorted(byP.items()):
            analyze(s, f"p1hi(>>5)={h:X}")
        # split by p8 parity
        byP8 = collections.defaultdict(list)
        for r in seq:
            byP8[r['p'][8] & 1].append(r)
        for h, s in sorted(byP8.items()):
            analyze(s, f"p8parity={h}")

if __name__ == '__main__':
    main()
