#!/usr/bin/env python3
"""Final round:
 F1: cross-session IN/26 A-block overlap (session-keyed block cipher?).
 F2: OUT/24 payload block-change histogram (blocks 8-15, 16-23).
 F3: IN/24 mirror payload structure (encrypted or masked-smooth?).
 F4: K nibble-structure table across sessions.
"""
import sys, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

SESSIONS = [
    ('13:43', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_134332.txt'),
    ('14:50', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_145006.txt'),
    ('14:58', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_145845.txt'),
    ('15:19', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_151920.txt'),
    ('15:46', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_154602.txt'),
    ('16:10', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_161055.txt'),
]

def in26_subtype(rows):
    ins = [r for r in rows if r['dir'] == 'IN']
    in26 = [r for r in ins if r['ln'] == 26]
    if not in26:
        return []
    sub = collections.Counter((r['p'][2], r['p'][5], r['p'][6]) for r in in26).most_common(1)[0][0]
    return [r for r in in26 if (r['p'][2], r['p'][5], r['p'][6]) == sub]

def main():
    data = {}
    for name, path in SESSIONS:
        data[name] = load(path)

    # F1: cross-session A-block overlap
    print("[F1] cross-session IN/26 A-block (p10-17) overlap:")
    asets = {}
    bsets = {}
    for name, rows in data.items():
        g = in26_subtype(rows)
        if not g:
            continue
        asets[name] = set(r['p'][10:18] for r in g)
        bsets[name] = set(r['p'][10:26] for r in g)
    names = list(asets)
    for i in range(len(names)):
        for j in range(i+1, len(names)):
            ov = len(asets[names[i]] & asets[names[j]])
            ovb = len(bsets[names[i]] & bsets[names[j]])
            print(f"  {names[i]} vs {names[j]}: A-blocks {len(asets[names[i]])}x{len(asets[names[j]])} overlap={ov}; full16 overlap={ovb}")

    # F2: OUT/24 payload block-change histogram
    print("\n[F2] OUT/24 consecutive-pair changed-byte histogram per 8-byte block:")
    for name, rows in data.items():
        out24 = [r for r in rows if r['dir'] == 'OUT' and r['ln'] == 24]
        if len(out24) < 500:
            continue
        hA = collections.Counter()  # bytes 8-15
        hB = collections.Counter()  # bytes 16-23
        for a, b in zip(out24, out24[1:]):
            hA[sum(1 for i in range(8, 16) if a['p'][i] != b['p'][i])] += 1
            hB[sum(1 for i in range(16, 24) if a['p'][i] != b['p'][i])] += 1
        n = len(out24) - 1
        print(f"  {name} n={n}: block8-15 chg dist: {[(k, f'{100*c/n:.0f}%') for k, c in sorted(hA.items())]}")
        print(f"  {'':13s} block16-23 chg dist: {[(k, f'{100*c/n:.0f}%') for k, c in sorted(hB.items())]}")

    # F3: IN/24 mirror payload structure
    print("\n[F3] IN/24 mirror: consecutive-pair changed-byte histogram (bytes 8-23), value structure:")
    for name, rows in data.items():
        in24 = [r for r in rows if r['dir'] == 'IN' and r['ln'] == 24]
        if len(in24) < 100:
            continue
        h = collections.Counter()
        for a, b in zip(in24, in24[1:]):
            h[sum(1 for i in range(8, 24) if a['p'][i] != b['p'][i])] += 1
        n = len(in24) - 1
        dist = [(k, f'{100*c/n:.0f}%') for k, c in sorted(h.items())]
        # value range at pos 8-15
        rngs = []
        for i in range(8, 24):
            vals = [r['p'][i] for r in in24]
            rngs.append(f"{min(vals):02X}-{max(vals):02X}/{len(set(vals))}")
        print(f"  {name} n={len(in24)}: chg dist(8-23): {dist}")
        print(f"    ranges pos8-23: {' '.join(rngs)}")

    # F4: K nibble structure
    print("\n[F4] K[2..7] per session and K[i]^K[2] pattern:")
    for name, rows in data.items():
        out24 = [r for r in rows if r['dir'] == 'OUT' and r['ln'] == 24]
        if not out24:
            continue
        K = [collections.Counter(r['p'][i] for r in out24).most_common(1)[0][0] for i in range(2, 8)]
        base = K[0]
        pat = ' '.join(f"{x ^ base:02X}" for x in K)
        print(f"  {name}: K={' '.join(f'{x:02X}' for x in K)}  K^K2: {pat}")

if __name__ == '__main__':
    main()
