param([string]$File, [int]$Len = 60)
# Keepalive XOR: check if changing bytes are SMALL deltas (arithmetic +/- small) rather than random XOR.
# For a value encoded as plain integer + constant XOR mask, XOR-diff of small arithmetic deltas concentrates on small values
# but also shows borrow patterns. Test: interpret consecutive values as 16-bit LE at each offset and look at deltas.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapG {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapG]::Parse($File)
$n = [CapG]::Ts.Count

# collect all consecutive same-len pairs; for offsets 12..31 compute 16-bit LE delta stats
$offs = 12..30
$deltaHist = @{}
foreach ($o in $offs) { $deltaHist[$o] = New-Object System.Collections.Generic.List[int] }
$pairs = 0
for ($i=1; $i -lt $n; $i++) {
  if ([CapG]::Lens[$i] -ne $Len -or [CapG]::Lens[$i-1] -ne $Len) { continue }
  $a = [CapG]::ToBytes([CapG]::Hex[$i-1]); $b = [CapG]::ToBytes([CapG]::Hex[$i])
  $m = [Math]::Min($a.Length, $b.Length)
  if ($m -lt 32) { continue }
  $pairs++
  foreach ($o in $offs) {
    if ($o+1 -ge $m) { continue }
    $va = $a[$o] + 256*$a[$o+1]
    $vb = $b[$o] + 256*$b[$o+1]
    $d = $vb - $va
    if ($d -gt 32768) { $d -= 65536 }
    if ($d -lt -32768) { $d += 65536 }
    $deltaHist[$o].Add($d)
  }
}
Write-Host ("len={0} pairs={1}" -f $Len, $pairs)
foreach ($o in $offs) {
  $arr = $deltaHist[$o]
  if ($arr.Count -eq 0) { continue }
  $mn = ($arr | Measure-Object -Minimum).Minimum
  $mx = ($arr | Measure-Object -Maximum).Maximum
  $avg = ($arr | Measure-Object -Average).Average
  # count of |d|<=64 (small deltas)
  $small = @($arr | Where-Object { [Math]::Abs($_) -le 64 }).Count
  $med = ($arr | Sort-Object)[[int]($arr.Count/2)]
  Write-Host ("off {0,2}: n={1,4} min={2,6} max={3,6} med={4,5} mean={5,8:N1} small(|d|<=64)={6,4} ({7,3}%)" -f $o, $arr.Count, $mn, $mx, $med, $avg, $small, [int](100*$small/[double]$arr.Count))
}
