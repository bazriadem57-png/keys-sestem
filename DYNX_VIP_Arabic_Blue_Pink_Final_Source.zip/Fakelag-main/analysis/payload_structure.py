#!/usr/bin/env python3
"""Decode entire IN/26 stream using session key K from OUT/24 headers, and examine payload structure.

V5: entity-level time series of decoded payload bytes: is pos 10-11 a stable timer?
V6: distribution of decoded (10,11) LE16 and (12,13) etc for one entity.
V7: hit-packet zone decoding with same K: K[17] test.
"""
import sys, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def main():
    path = sys.argv[1]
    rows = load(path)
    outs = [r for r in rows if r['dir'] == 'OUT']
    ins = [r for r in rows if r['dir'] == 'IN']
    out24 = [r for r in outs if r['ln'] == 24]
    # Build K over positions 0..7 from OUT/24 modes (pos2-7 100% stable, pos0-1 vary)
    K = {}
    for i in range(2, 8):
        c = collections.Counter(r['p'][i] for r in out24)
        v, cnt = c.most_common(1)[0]
        if cnt / len(out24) > 0.99:
            K[i] = v
    print(f"K (from OUT/24): " + ' '.join(f"{i}:{v:02X}" for i, v in sorted(K.items())))

    in26 = [r for r in ins if r['ln'] == 26]
    byE = collections.defaultdict(list)
    for r in in26:
        byE[r['p'][0]].append(r)
    big = max(byE.values(), key=len)
    print(f"\n[V5] entity {big[0]['p'][0]:02X} n={len(big)}: time-series of raw payload bytes 8-25 (first 25 pkts):")
    for r in big[:25]:
        ts_s = (r['ts'] - big[0]['ts'])
        print(f"  t+{ts_s:6d}ms  {r['p'][8:].hex().upper()}")

    print(f"\n[V6] entity {big[0]['p'][0]:02X}: LE16 pairs (10,11) and (12,13) and (14,15) raw values, first 40:")
    for r in big[:40]:
        p = r['p']
        v1 = p[10] | p[11] << 8
        v2 = p[12] | p[13] << 8
        v3 = p[14] | p[15] << 8
        v4 = p[16] | p[17] << 8
        print(f"  t+{r['ts']-big[0]['ts']:6d}  w10={v1:5d} w12={v2:5d} w14={v3:5d} w16={v4:5d}")

    print("\n[V7] check LE16 pair deltas within-entity (raw, no decode):")
    for lo in (10, 12, 14, 16, 18, 20, 22, 24):
        vals = [(r['p'][lo] | r['p'][lo+1] << 8) for r in big]
        d = sorted(abs(b - a) for a, b in zip(vals, vals[1:]))
        n = len(d)
        # also wrap-around aware diff
        def wdiff(a, b):
            d0 = (b - a) & 0xFFFF
            return d0 if d0 < 0x8000 else d0 - 0x10000
        wd = sorted(abs(wdiff(a, b)) for a, b in zip(vals, vals[1:]))
        print(f"  pair({lo},{lo+1}): med|d|={d[n//2]:5d} p90={d[9*n//10]:5d} | wrap-aware med={wd[n//2]:5d} p90={wd[9*n//10]:5d}")

if __name__ == '__main__':
    main()
