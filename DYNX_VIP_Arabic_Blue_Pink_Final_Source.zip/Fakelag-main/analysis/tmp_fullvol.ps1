param([string]$File, [int]$MaxLen = 120)
# Analyze per-length volatility + cadence for OUT packets, full-hex rows only.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class Cap8 {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      string raw = p[p.Length-1];
      if (raw.Length != len*2) continue;
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[Cap8]::Parse($File)
$n = [Cap8]::Ts.Count
Write-Host ("full-hex OUT rows: " + $n)
$byLen = @{}
for ($i=0; $i -lt $n; $i++) {
  $l = [Cap8]::Lens[$i]
  if (-not $byLen.ContainsKey($l)) { $byLen[$l] = @() }
  $byLen[$l] += $i
}
foreach ($l in ($byLen.Keys | Sort-Object)) {
  $arr = $byLen[$l]
  if ($arr.Count -lt 100) { continue }
  $chg = New-Object int[] $l
  for ($j=1; $j -lt $arr.Count; $j++) {
    $a = [Cap8]::Hex[$arr[$j-1]]; $b = [Cap8]::Hex[$arr[$j]]
    for ($k=0; $k -lt $l; $k++) { if ($a[2*$k] -ne $b[2*$k] -or $a[2*$k+1] -ne $b[2*$k+1]) { $chg[$k]++ } }
  }
  $dts = New-Object System.Collections.Generic.List[double]
  for ($j=1; $j -lt $arr.Count; $j++) { $dts.Add([Cap8]::Ts[$arr[$j]] - [Cap8]::Ts[$arr[$j-1]]) }
  $srt = $dts | Sort-Object
  $line = ""
  for ($k=0; $k -lt $l; $k++) { $line += ("{0,3} " -f [int](100*$chg[$k]/($arr.Count-1))) }
  Write-Host ("len={0} n={1} med_dt={2}ms :: {3}" -f $l, $arr.Count, $srt[[int]($srt.Count/2)], $line)
}
