param([string]$Csv)
# Notable recurring patterns in tail deltas: (+66, +1) and (-62, +2) on byte pairs (28,29)? Let's recheck.
# From output: bytes 22..31. The pair at columns 8-9 (bytes 30-31) shows (66,1) (62,-2) recurring;
# and pair at columns 6-7 (bytes 28-29) shows (0,66) (0,1)? Actually "0 66 1" = byte29=0? confusing.
# Let's take clean look: print w28..w31 as LE 16-bit for a long ACTIVE stretch with same len.
$rows = Import-Csv $Csv
function HexToBytes([string]$h) {
  $b = New-Object byte[] ($h.Length/2)
  for ($i=0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($h.Substring(2*$i,2),16) }
  return $b
}
# find longest run of same-len keepalives with active tail
$best = @(); $cur = @()
for ($i=0; $i -lt $rows.Count; $i++) {
  $b = HexToBytes $rows[$i].hex32
  $nz = 0
  for ($k=26; $k -lt 32; $k++) { if ($b[$k] -ne 0) { $nz++ } }
  $active = ($nz -gt 0)
  if ($i -gt 0 -and $rows[$i].len -eq $rows[$i-1].len -and $active) {
    $cur += $i
  } else {
    if ($cur.Count -gt $best.Count) { $best = $cur }
    $cur = @(,$i)
  }
}
if ($cur.Count -gt $best.Count) { $best = $cur }
Write-Host ("longest active same-len run: {0} packets" -f $best.Count)
foreach ($i in ($best | Select-Object -First 40)) {
  $b = HexToBytes $rows[$i].hex32
  $w22 = $b[22]+256*$b[23]; $w24=$b[24]+256*$b[25]; $w26=$b[26]+256*$b[27]; $w28=$b[28]+256*$b[29]; $w30=$b[30]+256*$b[31]
  $w18 = $b[18]+256*$b[19]; $w20 = $b[20]+256*$b[21]; $w12 = $b[12]+256*$b[13]
  Write-Host ("ts={0} len={1} w12={2,6} w18={3,6} w20={4,6} w22={5,6} w24={6,6} w26={7,6} w28={8,6} w30={9,6}" -f $rows[$i].ts, $rows[$i].len, $w12, $w18, $w20, $w22, $w24, $w26, $w28, $w30)
}
