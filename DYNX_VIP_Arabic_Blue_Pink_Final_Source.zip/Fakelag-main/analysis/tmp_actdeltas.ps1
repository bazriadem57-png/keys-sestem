param([string]$Csv)
# Active keepalives: study the XOR-diff 16-bit deltas at offsets 12-13, 18-19, 24-25 etc. to find position fields.
# Since mask is constant per session, arithmetic deltas between consecutive plaintext values appear directly.
$rows = Import-Csv $Csv
function HexToBytes([string]$h) {
  $b = New-Object byte[] ($h.Length/2)
  for ($i=0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($h.Substring(2*$i,2),16) }
  return $b
}
# consecutive same-len ACTIVE pairs
$pairs = New-Object System.Collections.Generic.List[object]
for ($j=1; $j -lt $rows.Count; $j++) {
  $ra = $rows[$j-1]; $rb = $rows[$j]
  if ($ra.len -ne $rb.len) { continue }
  $a = HexToBytes $ra.hex32; $b = HexToBytes $rb.hex32
  $nzTail = 0
  for ($k=26; $k -lt 32; $k++) { if ($b[$k] -ne 0) { $nzTail++ } }
  if ($nzTail -eq 0) { continue }
  $pairs.Add(@{a=$a; b=$b; ta=[double]$ra.ts; tb=[double]$rb.ts})
}
Write-Host ("active same-len pairs: " + $pairs.Count)

# for offsets 12..25 compute 16-bit LE delta; report median and IQR and fraction of small deltas
foreach ($off in (12,14,16,18,20,22,24)) {
  $deltas = New-Object System.Collections.Generic.List[int]
  foreach ($p in $pairs) {
    $va = $p.a[$off] + 256*$p.a[$off+1]
    $vb = $p.b[$off] + 256*$p.b[$off+1]
    $d = $vb - $va
    if ($d -gt 32768) { $d -= 65536 }
    if ($d -lt -32768) { $d += 65536 }
    $deltas.Add($d)
  }
  $srt = $deltas | Sort-Object
  $n = $srt.Count
  $med = $srt[[int]($n/2)]
  $q1 = $srt[[int]($n*0.25)]; $q3 = $srt[[int]($n*0.75)]
  $mn = $srt[0]; $mx = $srt[-1]
  $small = @($deltas | Where-Object { [Math]::Abs($_) -le 600 }).Count
  Write-Host ("off {0,2}-{1}: med={2,6} q1={3,6} q3={4,6} min={5,7} max={6,7} |d|<=600: {7}/{8} ({9:P0})" -f $off, ($off+1), $med, $q1, $q3, $mn, $mx, $small, $n, ($small/[double]$n))
}

# Show 12 consecutive ACTIVE packets hex for eyeball
Write-Host "--- sample 12 active packets:"
$shown=0
for ($j=0; $j -lt $rows.Count -and $shown -lt 12; $j++) {
  $b = HexToBytes $rows[$j].hex32
  $nz = 0
  for ($k=26; $k -lt 32; $k++) { if ($b[$k] -ne 0) { $nz++ } }
  if ($nz -eq 0) { continue }
  Write-Host ("  {0}" -f $rows[$j].hex32)
  $shown++
}
