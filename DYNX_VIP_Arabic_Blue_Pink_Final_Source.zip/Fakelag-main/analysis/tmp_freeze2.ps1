param([string]$File)
# Distinguish: while FREEZE (ghost on), the player's TRUE aim still changes (they can look around).
# The keepalive packets during FREEZE are replayed (frozen position payload) — check whether they are byte-identical
# to the last pre-freeze packet (then volatility in FREEZE ~0 for all bytes) — but we see 10% volatility. 
# Check: are FREEZE keepalives literally identical packets? Compare each FREEZE keepalive to the previous one ANY phase.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapO {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static List<string> Phase = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len < 45 || len > 64) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw); Phase.Add(p[2]);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapO]::Parse($File)
$n = [CapO]::Ts.Count

# The 24B input stream is what carries aim. During FREEZE the keepalive is frozen, but 24B continues.
# So: KEEPALIVE = position channel. 24B = aim/input channel.
# Now confirm with a "still vs moving" split on the 24B stream during BEFORE: 
# find time windows where 24B volatile region is CONSTANT (idle) vs changing (aiming), then check keepalive v12.

# Instead directly: correlation between keepalive bytes and time windows.
# Let's dump a clean CSV of keepalive (ts, len, hex[0:32]) for offline analysis.
$out = [System.IO.Path]::GetDirectoryName($File)
$csv = [System.IO.Path]::Combine($out, 'ka_dump.csv')
$sw = New-Object System.IO.StreamWriter($csv)
$sw.WriteLine('ts,len,phase,hex32')
for ($i=0; $i -lt $n; $i++) {
  $h = [CapO]::Hex[$i]
  $h32 = if ($h.Length -ge 64) { $h.Substring(0,64) } else { $h }
  $sw.WriteLine([string][CapO]::Ts[$i] + ',' + [string][CapO]::Lens[$i] + ',' + [string][CapO]::Phase[$i] + ',' + $h32)
}
$sw.Close()
Write-Host ("dumped to " + $csv)

# Quick check: during each BEFORE window, count how many consecutive same-len keepalives are FULLY identical beyond b0/b1
$still = 0; $moving = 0
for ($i=1; $i -lt $n; $i++) {
  if ([CapO]::Phase[$i] -ne 'BEFORE') { continue }
  if ([CapO]::Lens[$i] -ne [CapO]::Lens[$i-1]) { continue }
  $a = [CapO]::ToBytes([CapO]::Hex[$i-1]); $b = [CapO]::ToBytes([CapO]::Hex[$i])
  $m = [Math]::Min(32, [Math]::Min($a.Length,$b.Length))
  $diff = 0
  for ($k=2; $k -lt $m; $k++) { if ($a[$k] -ne $b[$k]) { $diff++ } }
  if ($diff -eq 0) { $still++ } else { $moving++ }
}
Write-Host ("BEFORE same-len pairs: fully-frozen-beyond-b0b1={0} changed={1}" -f $still, $moving)
