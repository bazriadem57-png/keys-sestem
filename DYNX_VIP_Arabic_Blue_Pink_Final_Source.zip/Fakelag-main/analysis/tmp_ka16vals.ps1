param([string]$File)
# Study keepalive byte 12-13 ("48-49%" volatile) more closely: are they a 16-bit counter?
# In pull7 220209 len60: bytes 12-13 changed 75-77%. Look at the 16-bit LE value progression over a run.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapJ {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapJ]::Parse($File)
$n = [CapJ]::Ts.Count

# print first 30 consecutive same-len (any len) keepalives with bytes 12..19 as 16-bit LE values
$shown = 0
$prevLen = -1
for ($i=0; $i -lt $n -and $shown -lt 40; $i++) {
  $L = [CapJ]::Lens[$i]
  $h = [CapJ]::Hex[$i]
  if ($h.Length -lt 40) { continue }
  $b = [CapJ]::ToBytes($h)
  $v12 = $b[12] + 256*$b[13]
  $v14 = $b[14] + 256*$b[15]
  $v16 = $b[16] + 256*$b[17]
  $v18 = $b[18] + 256*$b[19]
  $v20 = $b[20] + 256*$b[21]
  $v22 = $b[22] + 256*$b[23]
  Write-Host ("len={0} ts={1} v12={2,6} v14={3,6} v16={4,6} v18={5,6} v20={6,6} v22={7,6}" -f $L, [CapJ]::Ts[$i], $v12, $v14, $v16, $v18, $v20, $v22)
  $shown++
}
