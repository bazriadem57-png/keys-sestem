param([string]$Csv)
# CONJECTURE: mask is NOT constant; each byte position i has mask byte M[i] constant per session.
# Under that, plaintext P = C XOR M. Differences we computed are already plaintext diffs.
# Observed: w16 stays ~900-925 (small drift); w26 counts 414,435,437,441,445,447,453 (increasing by ~2-4 per packet);
# w28 values 905,723,981,965,941,911,441,99 ~ nonmonotonic; w30 increments ~+30-450.
# w26 looks like a POSITION coordinate (monotonic increase while walking!), w30 maybe another coordinate.
# Let's verify w26/w28/w30 monotonic runs & estimate step per 100ms.
$rows = Import-Csv $Csv
function HexToBytes([string]$h) {
  $b = New-Object byte[] ($h.Length/2)
  for ($i=0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($h.Substring(2*$i,2),16) }
  return $b
}
# full sequence of w26, w28, w30 (16-bit LE) over ALL keepalives, with len
$seq = New-Object System.Collections.Generic.List[object]
foreach ($r in $rows) {
  $b = HexToBytes $r.hex32
  $seq.Add(@{ts=[double]$r.ts; len=[int]$r.len; w26=($b[26]+256*$b[27]); w28=($b[28]+256*$b[29]); w30=($b[30]+256*$b[31]); w20=($b[20]+256*$b[21]); w22=($b[22]+256*$b[23]); w24=($b[24]+256*$b[25])})
}
# count monotonic runs for each word over consecutive keepalives (ignoring len changes)
foreach ($name in ('w26','w28','w30','w20','w22','w24')) {
  $inc=0; $dec=0; $same=0
  for ($i=1; $i -lt $seq.Count; $i++) {
    $d = $seq[$i][$name] - $seq[$i-1][$name]
    if ($d -gt 0) { $inc++ } elseif ($d -lt 0) { $dec++ } else { $same++ }
  }
  Write-Host ("{0}: inc={1} dec={2} same={3} (n={4})" -f $name, $inc, $dec, $same, $seq.Count)
}
# distribution of delta for w26 when nonzero
foreach ($name in ('w26','w30')) {
  $dh = @{}
  for ($i=1; $i -lt $seq.Count; $i++) {
    $d = $seq[$i][$name] - $seq[$i-1][$name]
    if ($d -eq 0) { continue }
    if (-not $dh.ContainsKey($d)) { $dh[$d]=0 }
    $dh[$d]++
  }
  Write-Host ("{0} nonzero deltas top12: {1}" -f $name, (($dh.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 12 | ForEach-Object { "{0}x{1}" -f $_.Key, $_.Value }) -join ' '))
}
