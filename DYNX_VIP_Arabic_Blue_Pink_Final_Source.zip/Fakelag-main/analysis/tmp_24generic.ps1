param([string]$Csv)
# Now the 24B input stream across sessions: does it contain yaw/pitch? Check byte-level solo deltas + value ranges
# in pull5 session (20260907_161055) and pull7 (220209). Also look for 16-bit monotonic sweeps (yaw scan).
$File = $Csv
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapQ {
  public static List<long> Ts = new List<long>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len != 24) continue;
      string raw = p[p.Length-1];
      if (raw.Length != 48) continue;
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapQ]::Parse($File)
$n = [CapQ]::Ts.Count
Write-Host ("24B OUT packets: " + $n)
$bytes = New-Object System.Collections.ArrayList
foreach ($i in 0..($n-1)) { [void]$bytes.Add([CapQ]::ToBytes([CapQ]::Hex[$i])) }

# header bytes 2-7 dominant value
$h = @{}
for ($i=0; $i -lt $n; $i++) { $k = [CapQ]::Hex[$i].Substring(4,12); if (-not $h.ContainsKey($k)) { $h[$k]=0 }; $h[$k]++ }
$h.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 2 | ForEach-Object { Write-Host ("  hdr(2-7)=0x{0} x{1} ({2:P1})" -f $_.Key, $_.Value, ($_.Value/[double]$n)) }

# per-byte change rate
$chg = New-Object int[] 24
for ($i=1; $i -lt $n; $i++) {
  $a = $bytes[$i-1]; $b = $bytes[$i]
  for ($k=0; $k -lt 24; $k++) { if ($a[$k] -ne $b[$k]) { $chg[$k]++ } }
}
$line = ""
for ($k=0; $k -lt 24; $k++) { $line += ("{0,3} " -f [int](100*$chg[$k]/[Math]::Max(1,$n-1))) }
Write-Host ("change%: " + $line)

# idle detection: bytes 8-23 all identical to previous
$idle = 0
for ($i=1; $i -lt $n; $i++) {
  $a = $bytes[$i-1]; $b = $bytes[$i]
  $same = $true
  for ($k=8; $k -lt 24; $k++) { if ($a[$k] -ne $b[$k]) { $same = $false; break } }
  if ($same) { $idle++ }
}
Write-Host ("pairs with bytes8-23 fully frozen: {0}/{1}" -f $idle, ($n-1))
