param([string]$File)
# Wrap-up: get precise idle-vs-active split for keepalive bytes 2-7 (family/len bytes) and the b0/b1 counter behavior
# during FREEZE, plus a summary of 26/30 byte solo-changes (position candidates ranked by smoothness on ACTIVE pairs).
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapZ {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static List<string> Phase = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len < 45 || len > 64) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw); Phase.Add(p[2]);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapZ]::Parse($File)
$n = [CapZ]::Ts.Count

# ACTIVE pairs = same-len, payload (b2+) changed. For those, signed byte delta histograms per offset 12..31.
$dh = @{}
for ($k=12; $k -lt 32; $k++) { $dh[$k] = @{} }
$act = 0
for ($i=1; $i -lt $n; $i++) {
  if ([CapZ]::Lens[$i] -ne [CapZ]::Lens[$i-1]) { continue }
  $a = [CapZ]::ToBytes([CapZ]::Hex[$i-1]); $b = [CapZ]::ToBytes([CapZ]::Hex[$i])
  $m = [Math]::Min(32, [Math]::Min($a.Length, $b.Length))
  $changed = $false
  for ($k=2; $k -lt $m; $k++) { if ($a[$k] -ne $b[$k]) { $changed = $true; break } }
  if (-not $changed) { continue }
  $act++
  for ($k=12; $k -lt $m; $k++) {
    $d = $b[$k] - $a[$k]
    if ($d -gt 127) { $d -= 256 }
    if (-not $dh[$k].ContainsKey($d)) { $dh[$k][$d]=0 }
    $dh[$k][$d]++
  }
}
Write-Host ("ACTIVE same-len pairs: " + $act)
foreach ($k in (12..31)) {
  $top = $dh[$k].GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 5
  $s = ($top | ForEach-Object { "{0}x{1}" -f $_.Key, $_.Value }) -join ' '
  Write-Host ("byte {0,2}: top signed deltas: {1}" -f $k, $s)
}
