#!/usr/bin/env python3
"""Session K-invariant + K[i] structure investigation.

Facts so far:
- OUT/24 header (pos2-7) constant per session; between 'keystream' sessions
  (14:50/14:58/15:46/16:10) the XOR difference is a SINGLE constant byte
  (AF/87/B5/32/3E-palindrome), i.e. K[i] = base[i] ^ session_byte in those.
- 13:43 behaves differently: difference vs 16:10 = 16 07 07 15 15 16.

Tests here:
 T-A: For each session, XOR OUT/24 header with candidate plaintext headers and
      see which yields K with K[2]==K[4]==K[6] pattern seen in 16:10 (C8 C8 C8).
 T-B: IN/26 decoded header across sessions using K = OUT24hdr ^ plain(0500006E0700).
 T-C: The 'b2==b3' sessions: 13:43 has ct[2]=DE ct[3]=DF; if K[2]=DB then plain=05,
      K[3]=DF then plain=00... wait b2==b3 refers to bytes 2 and 3 equal in plaintext?
"""
import sys, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

PLAIN = bytes.fromhex('0500006E0700')  # guessed IN/26 decoded header from 16:10

def main():
    sessions = [
        ('13:43', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_134332.txt'),
        ('14:50', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_145006.txt'),
        ('14:58', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_145845.txt'),
        ('15:19', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_151920.txt'),
        ('15:46', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_154602.txt'),
        ('16:10', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_161055.txt'),
    ]

    for name, path in sessions:
        rows = load(path)
        out24 = [r for r in rows if r['dir'] == 'OUT' and r['ln'] == 24]
        in26 = [r for r in rows if r['dir'] == 'IN' and r['ln'] == 26]
        if not out24:
            continue
        hdr = bytes(collections.Counter(r['p'][i] for r in out24).most_common(1)[0][0] for i in range(2, 8))
        K = bytes(a ^ b for a, b in zip(hdr, PLAIN))
        print(f"\n{name}: OUT/24 hdr={hdr.hex().upper()}  K[2..7]={K.hex().upper()}")
        # decode first IN/26 of the biggest entity
        if in26:
            byE = collections.defaultdict(list)
            for r in in26:
                byE[r['p'][0]].append(r)
            big = max(byE.values(), key=len)
            # decoded header of entity packets (pos 2-7)
            dec_hdrs = collections.Counter()
            for r in big[:200]:
                dh = bytes(r['p'][i] ^ K[i-2] for i in range(2, 8))
                dec_hdrs[dh] += 1
            print(f"  decoded IN/26 hdr[2..7] top3: {[(k.hex().upper(), v) for k, v in dec_hdrs.most_common(3)]}")
            # decoded pos 5,6 variants (entity subtypes?)
            c56 = collections.Counter((r['p'][5] ^ K[3], r['p'][6] ^ K[4]) for r in big)
            print(f"  decoded (pos5,pos6) top4: {[(f'{a:02X},{b:02X}', c) for (a, b), c in c56.most_common(4)]}")

if __name__ == '__main__':
    main()

