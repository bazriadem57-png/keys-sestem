param([string]$File)
# KEY FINDING: 24B stream bimodal: either IDENTICAL (1299/3567 = idle, 0 bits) or ~64 bits (random-looking).
# Mean HD 40 over all pairs. The ~64-bit HD packets = completely different bytes 8-23 => NOT smooth analog values.
# This is consistent with ENCRYPTED (keystream per packet, e.g. nonce-based) or strongly scrambled/bit-packed input.
# If it were 16-bit yaw under a constant XOR mask, HD would be small (few bits) per packet during smooth aim.
# => The 24B input stream payload is per-packet-encrypted or contains high-entropy data (button bitfield + checksum?).
# Let's verify with pull6 (the big one) and check whether bytes 8-23 ever show SMALL nonzero HD (2-20 bits).
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapU {
  public static List<long> Ts = new List<long>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len != 24) continue;
      string raw = p[p.Length-1];
      if (raw.Length != 48) continue;
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapU]::Parse($File)
$n = [CapU]::Ts.Count
Write-Host ("24B OUT packets: " + $n)
$bytes = New-Object System.Collections.ArrayList
foreach ($i in 0..($n-1)) { [void]$bytes.Add([CapU]::ToBytes([CapU]::Hex[$i])) }
$hist = @{}
for ($i=1; $i -lt $n; $i++) {
  $a = $bytes[$i-1]; $b = $bytes[$i]
  $bits = 0
  for ($k=8; $k -lt 24; $k++) {
    $x = $a[$k] -bxor $b[$k]
    while ($x -ne 0) { $bits += ($x -band 1); $x = $x -shr 1 }
  }
  if (-not $hist.ContainsKey($bits)) { $hist[$bits]=0 }
  $hist[$bits]++
}
$small = 0; $mid = 0; $big = 0; $zero = 0
foreach ($k in $hist.Keys) {
  if ($k -eq 0) { $zero += $hist[$k] }
  elseif ($k -le 20) { $small += $hist[$k] }
  elseif ($k -le 45) { $mid += $hist[$k] }
  else { $big += $hist[$k] }
}
Write-Host ("HD=0: {0}  HD 1-20: {1}  HD 21-45: {2}  HD 46+: {3}  (total {4})" -f $zero, $small, $mid, $big, ($n-1))
# sub-histogram 1..20
for ($k=1; $k -le 20; $k++) { if ($hist.ContainsKey($k)) { Write-Host ("  HD {0,2}: {1}" -f $k, $hist[$k]) } }
