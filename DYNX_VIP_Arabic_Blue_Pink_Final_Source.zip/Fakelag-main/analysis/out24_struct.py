#!/usr/bin/env python3
"""Determine OUT/24 plaintext header per session layout, via the mask structure.

Key question: is K really constant across the whole packet (positions 2-25),
or does it only cover a header region?

Method: OUT/24 payloads share a rigid plaintext structure (player state feed).
For 13:43 (K would be 'DE DF CF DF DD DF' if pt=0), examine full-packet
per-position constancy in OUT/24: positions with uniq=1 identify fixed pt.
Also compare OUT/24 payload bytes 8+ across sessions for shared plaintext
structure (if K=0 there, ct should show identical structure).
"""
import sys, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

SESSIONS = [
    ('13:43', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_134332.txt'),
    ('14:50', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_145006.txt'),
    ('14:58', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_145845.txt'),
    ('15:19', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_151920.txt'),
    ('15:46', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_154602.txt'),
    ('16:10', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_161055.txt'),
]

def main():
    data = {}
    for name, path in SESSIONS:
        rows = load(path)
        out24 = [r for r in rows if r['dir'] == 'OUT' and r['ln'] == 24]
        data[name] = out24
        print(f"\n=== {name} OUT/24 n={len(out24)} per-position uniq (pos 0-23):")
        u = []
        for i in range(24):
            c = collections.Counter(r['p'][i] for r in out24)
            u.append(len(c))
        print('  ' + ' '.join(f"{x:3d}" for x in u))
        # top value at each pos
        tv = [c.most_common(1)[0][0] for c in (collections.Counter(r['p'][i] for r in out24) for i in range(24))]
        print('  ' + ' '.join(f"{x:02X}" for x in tv))
        # show 3 consecutive packets
        for r in out24[:3]:
            print(f"   {r['p'].hex().upper()}")

    # Cross-session: XOR of OUT/24 mode vectors
    print("\n\nCross-session OUT/24 mode XOR (pos 2-23):")
    names = list(data)
    for i in range(len(names)):
        for j in range(i+1, len(names)):
            a = data[names[i]]; b = data[names[j]]
            ma = [collections.Counter(r['p'][k] for r in a).most_common(1)[0][0] for k in range(24)]
            mb = [collections.Counter(r['p'][k] for r in b).most_common(1)[0][0] for k in range(24)]
            d = [x ^ y for x, y in zip(ma, mb)]
            print(f"  {names[i]}^{names[j]}: " + ' '.join(f"{x:02X}" for x in d))

if __name__ == '__main__':
    main()
