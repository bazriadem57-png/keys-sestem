#!/usr/bin/env python3
"""Subtype-split delta analysis.

S1: OUT/62-63 consecutive-pair per-position XOR-zero% (is own-state smooth under fixed mask?)
S2: IN/26 split by (entity p[0], subtype p[2],p[5],p[6]) -> consecutive delta analysis per group.
S3: IN/26 within-entity: recurrence analysis of p[10..17] (8B block) and p[18..25].
"""
import sys, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def delta_profile(packets, L, label):
    if len(packets) < 30:
        return
    zf = []
    for i in range(L):
        z = sum(1 for a, b in zip(packets, packets[1:]) if i < len(a['p']) and i < len(b['p']) and a['p'][i] == b['p'][i])
        n = sum(1 for a, b in zip(packets, packets[1:]) if i < len(a['p']) and i < len(b['p']))
        zf.append(100 * z / n if n else 0)
    print(f"  {label} n={len(packets)} consecutive-identical% per pos:")
    print("   " + ' '.join(f"{x:.0f}" for x in zf))

def main():
    path = sys.argv[1]
    rows = load(path)
    outs = [r for r in rows if r['dir'] == 'OUT']
    ins = [r for r in rows if r['dir'] == 'IN']

    # S1: OUT/62-63
    move = [r for r in outs if r['ln'] in (62, 63)]
    print(f"[S1] OUT/62-63 n={len(move)}")
    delta_profile(move, 40, 'OUT/62-63')
    # show 3 consecutive raw payloads
    for r in move[:4]:
        print(f"   {r['p'].hex().upper()}")

    # S2: IN/26 by entity+subtype
    in26 = [r for r in ins if r['ln'] == 26]
    print(f"\n[S2] IN/26 n={len(in26)}")
    groups = collections.defaultdict(list)
    for r in in26:
        groups[(r['p'][0], r['p'][2], r['p'][5], r['p'][6])].append(r)
    print(f"  (p0,p2,p5,p6) groups: {len(groups)}; top sizes: {sorted((len(v) for v in groups.values()), reverse=True)[:10]}")
    for key, g in sorted(groups.items(), key=lambda kv: -len(kv[1]))[:6]:
        delta_profile(g, 26, f"grp p0={key[0]:02X} p2={key[1]:02X} p5={key[2]:02X} p6={key[3]:02X}")

    # S3: block recurrence within entity
    byE = collections.defaultdict(list)
    for r in in26:
        byE[r['p'][0]].append(r)
    print(f"\n[S3] block recurrence within entities:")
    for e, g in sorted(byE.items(), key=lambda kv: -len(kv[1]))[:4]:
        blkA = collections.Counter(r['p'][10:18] for r in g)
        blkB = collections.Counter(r['p'][18:26] for r in g)
        n = len(g)
        dupA = sum(c for c in blkA.values() if c > 1)
        dupB = sum(c for c in blkB.values() if c > 1)
        print(f"  entity {e:02X} n={n}: p10-17 recurring values: {dupA}/{n} ({100*dupA/n:.0f}%), distinct={len(blkA)}; "
              f"p18-25 recurring: {dupB}/{n} ({100*dupB/n:.0f}%), distinct={len(blkB)}")
        # consecutive same-block rates
        consecA = sum(1 for a, b in zip(g, g[1:]) if a['p'][10:18] == b['p'][10:18])
        consecB = sum(1 for a, b in zip(g, g[1:]) if a['p'][18:26] == b['p'][18:26])
        print(f"    consecutive-same p10-17: {100*consecA/(n-1):.0f}%, p18-25: {100*consecB/(n-1):.0f}%")

    # S4: OUT/24 consecutive delta (is own 31ms state feed smooth?)
    out24 = [r for r in outs if r['ln'] == 24]
    print(f"\n[S4] OUT/24 n={len(out24)}")
    delta_profile(out24, 24, 'OUT/24')

    # S5: IN/24 mirror consecutive delta
    in24 = [r for r in ins if r['ln'] == 24]
    print(f"\n[S5] IN/24 n={len(in24)}")
    delta_profile(in24, 24, 'IN/24')

if __name__ == '__main__':
    main()
