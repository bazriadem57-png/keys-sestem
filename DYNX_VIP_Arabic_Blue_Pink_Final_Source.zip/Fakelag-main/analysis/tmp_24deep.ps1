param([string]$File, [int]$Len = 24)
# Deep dive 24B input stream: XOR consecutive, look at 16-bit pair structure of bytes 8-23.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class Cap9 {
  public static List<long> Ts = new List<long>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file, int len) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int l;
      if (!int.TryParse(p[8], out l)) continue;
      if (l != len) continue;
      string raw = p[p.Length-1];
      if (raw.Length != len*2) continue;
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[Cap9]::Parse($File, $Len)
$n = [Cap9]::Ts.Count
Write-Host ("24B OUT packets: " + $n)

# Compute 16-bit LE values at each offset pair (8..22) and their consecutive deltas; check monotonic runs
# Also check byte-pair (odd offset) byte value at offsets 8-23: statistics
$vals = @{}
for ($off=8; $off -lt 23; $off++) { $vals[$off] = New-Object System.Collections.Generic.List[int] }
for ($i=0; $i -lt $n; $i++) {
  $b = [Cap9]::ToBytes([Cap9]::Hex[$i])
  for ($off=8; $off -lt 23; $off++) { $vals[$off].Add($b[$off]) }
}
Write-Host "--- byte value stats (offset: min max mean unique):"
for ($off=8; $off -lt 23; $off++) {
  $arr = $vals[$off]
  $u = ($arr | Sort-Object -Unique).Count
  $mn = ($arr | Measure-Object -Minimum).Minimum
  $mx = ($arr | Measure-Object -Maximum).Maximum
  $avg = ($arr | Measure-Object -Average).Average
  Write-Host ("byte {0,2}: min={1,3} max={2,3} mean={3,6:N1} unique={4}" -f $off, $mn, $mx, $avg, $u)
}

# 16-bit deltas between consecutive packets at offsets 8-22 (LE and BE)
Write-Host "--- 16-bit consecutive deltas (offset pair):"
for ($off=8; $off -le 21; $off+=1) {
  $dLE = New-Object System.Collections.Generic.List[int]
  for ($i=1; $i -lt $n; $i++) {
    $a = [Cap9]::ToBytes([Cap9]::Hex[$i-1]); $b = [Cap9]::ToBytes([Cap9]::Hex[$i])
    $va = $a[$off] + 256*$a[$off+1]
    $vb = $b[$off] + 256*$b[$off+1]
    $d = $vb - $va
    if ($d -gt 32768) { $d -= 65536 }
    if ($d -lt -32768) { $d += 65536 }
    $dLE.Add($d)
  }
  $mn = ($dLE | Measure-Object -Minimum).Minimum
  $mx = ($dLE | Measure-Object -Maximum).Maximum
  $avg = ($dLE | Measure-Object -Average).Average
  $ss = 0
  foreach ($d in $dLE) { $ss += [double]$d * [double]$d }
  $sd = [Math]::Sqrt($ss / $dLE.Count - $avg*$avg)
  Write-Host ("off {0,2}-{1,2} LE: min={2,6} max={3,6} mean={4,8:N2} sd={5,8:N2}" -f $off, ($off+1), $mn, $mx, $avg, $sd)
}
