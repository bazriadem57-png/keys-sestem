$f = 'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull6\capture_raw_20260908_195156.txt'
Get-Content $f -TotalCount 15 | ForEach-Object {
  $parts = @($_ -split ' ')
  Write-Host ("cols=" + $parts.Count + " :: " + $_)
}
