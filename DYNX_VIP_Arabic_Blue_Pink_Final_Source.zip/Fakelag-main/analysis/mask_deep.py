#!/usr/bin/env python3
"""Deep mask-recovery analysis for FF Max captures.

Per session:
  A. OUT/24 stream: model ciphertext = plain ^ mask. Check b2==b3-equivalent
     invariants: for each pair (i,j) of positions, fraction of packets where
     ct[i]==ct[j]. If plaintext has fixed equality (e.g. header bytes equal),
     constant mask preserves it; keystream breaks it.
  B. IN/26 stream: assume positional keystream K[i] constant over session
     (hypothesis H1). Estimate K[i] as mode(ct[i]) XOR assumed_plain[i] where
     assumed_plain=0. Check how much of the stream is explained.
  C. Consecutive-pair XOR (delta) zero-fraction per position, restricted to
     pairs with small dt (<=100ms) vs all pairs.
  D. Reconstruct: XOR all IN/26 packets with candidate constant mask from the
     4 header positions (mode) and inspect output structure.
"""
import sys, os, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            # find hex: last field
            hx = parts[-1]
            if len(hx) != ln * 2:
                # maybe layout has family/kind; try parts[10] and parts[12]
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def eq_matrix(pk, positions=range(0, 10)):
    """fraction of packets where ct[i]==ct[j] for header positions"""
    n = len(pk)
    res = {}
    for i in positions:
        for j in positions:
            if j <= i: continue
            eq = sum(1 for r in pk if r['p'][i] == r['p'][j])
            res[(i, j)] = eq / n
    return res

def main():
    for path in sys.argv[1:]:
        rows = load(path)
        name = os.path.basename(path)
        ins = [r for r in rows if r['dir'] == 'IN']
        outs = [r for r in rows if r['dir'] == 'OUT']
        print(f"\n{'='*80}\nFILE: {name} rows={len(rows)} IN={len(ins)} OUT={len(outs)}")

        out24 = [r for r in outs if r['ln'] == 24]
        in26 = [r for r in ins if r['ln'] == 26]

        # A. equality invariants on OUT/24 header
        if len(out24) > 100:
            m = eq_matrix(out24)
            print("\n[A] OUT/24 ct[i]==ct[j] fractions (i,j:fraction) for header pos 0-9:")
            print('  ' + '  '.join(f"{i},{j}:{m[(i,j)]:.2f}" for (i, j) in sorted(m) if m[(i, j)] > 0.5))

        # B. IN/26 positional keystream hypothesis: mode per position
        if len(in26) > 100:
            modes = []
            for i in range(26):
                c = collections.Counter(r['p'][i] for r in in26)
                v, cnt = c.most_common(1)[0]
                modes.append((v, cnt / len(in26), len(c)))
            print("\n[B] IN/26 mode per position (val, share, n_unique):")
            for i, (v, s, u) in enumerate(modes):
                print(f"  {i:2d}: {v:02X} {s*100:3.0f}% uniq={u}")

        # C. delta analysis by dt bucket
        if len(in26) > 100:
            for maxdt in (100, 1000, 10**9):
                pairs = [(a, b) for a, b in zip(in26, in26[1:]) if b['ts'] - a['ts'] <= maxdt]
                if len(pairs) < 30:
                    continue
                zf = []
                for i in range(26):
                    z = sum(1 for a, b in pairs if a['p'][i] ^ b['p'][i] == 0)
                    zf.append(100 * z / len(pairs))
                print(f"\n[C] IN/26 dt<={maxdt}ms n={len(pairs)} zero% per pos:")
                print('  ' + ' '.join(f"{x:.0f}" for x in zf))

        # D. cross-check: is IN/26 header 4 bytes == OUT/24-style header?
        #    and reconstruct IN/26 with mask = mode (assuming plain 0) for stable positions
        if len(in26) > 100:
            # candidate mask from positions with mode share > 90%
            mask = {}
            for i in range(26):
                c = collections.Counter(r['p'][i] for r in in26)
                v, cnt = c.most_common(1)[0]
                if cnt / len(in26) > 0.9:
                    mask[i] = v
            print(f"\n[D] positions with >90% single value (candidate K[i] if plain==0): { {k: f'{v:02X}' for k, v in mask.items()} }")

if __name__ == '__main__':
    main()
