param([string]$File)
# 24B stream: find pairs of DISTINCT payloads (from the whole session) differing in exactly 1 byte; report offset.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapX {
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len != 24) continue;
      string raw = p[p.Length-1];
      if (raw.Length != 48) continue;
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      Hex.Add(raw);
    }
  }
}
"@
Add-Type -TypeDefinition $src
[CapX]::Parse($File)
$n = [CapX]::Hex.Count
Write-Host ("24B packets: " + $n)
# distinct payloads
$distinct = New-Object System.Collections.Generic.List[string]
$seen = @{}
foreach ($h in [CapX]::Hex) { if (-not $seen.ContainsKey($h)) { $seen[$h]=1; $distinct.Add($h) } }
Write-Host ("distinct: " + $distinct.Count)
# group by bytes 8..23 substring; within group, payloads differ only in b0/b1 (already known).
# Instead: compare consecutive distinct payloads in TIME order (each new distinct payload vs the previous distinct one)
# and count byte differences in 8-23.
$diffHist = @{}
$prev = $null
foreach ($h in [CapX]::Hex) {
  if ($seen[$h] -gt 1) { continue }  # only first occurrence
  if ($null -ne $prev) {
    $d = 0
    for ($k=8; $k -lt 24; $k++) { if ($h[2*$k] -ne $prev[2*$k] -or $h[2*$k+1] -ne $prev[2*$k+1]) { $d++ } }
    if (-not $diffHist.ContainsKey($d)) { $diffHist[$d]=0 }
    $diffHist[$d]++
  }
  $prev = $h
}
Write-Host "byte-diff count between consecutive NEW payloads (bytes 8-23):"
foreach ($k in ($diffHist.Keys | Sort-Object)) { Write-Host ("  {0,2} bytes differ: {1}" -f $k, $diffHist[$k]) }
