# XOR-Mask Recovery Analysis — Findings (2026-09-08)

Scope: phone_pull5 (pull5/pull6/pull7 are MD5-identical copies — same data), 6 sessions:
13:43, 14:50, 14:58, 15:19, 15:46, 16:10. Scripts: analysis/*.py in this repo.

## Executive verdict

1. **The "mask" is real, session-constant, direction- and family-independent — and
   recoverable live in every session with ~100 packets.** It is a 6-byte XOR header
   mask at positions 2-7 (plus a 1-byte XOR at position 0 on OUT packets only).
2. **Absolute coordinates are NOT recoverable from the 26B enemy packets** in any
   session: the payload (bytes 10-25) is a session-keyed block cipher, not XOR
   obfuscation. Delta (packet N XOR N+1) does not survive either — all-or-nothing
   8-byte avalanche. A delta-only radar is *not* possible.
3. **The hit-confirm packets (22-26B) are mostly plaintext** (K≈0 beyond the header),
   which is why damage/zone/weapon read out raw. This is layout-dependent, not
   luck: see "hit layout rotation" below.
4. The game appears to protect exactly what matters: positions (block cipher),
   and leaves readable what is cheap: damage events, heartbeats, timers.

## The mask structure (fully characterized)

Every observed session has a session-constant XOR keystream K[i], applied
identically to both directions and all packet families:

- K[2..7] = the mode (most common value) of OUT/24 ciphertext at positions 2-7.
  OUT/24 plaintext header is `00 00 00 00 00 00` at those positions in most
  layouts, making the mode equal K directly.
- Verification across families (16:10 session, K[2..7] = C8 D8 C8 CA C8 C9):
  - OUT/24  (n=16,706):  pos2-7 all uniq=1, values C8 D8 C8 CA C8 C9  (100% each)
  - IN/26 dominant subtype: pos 3,4,7 = D8, C8, C9 (100%)
  - IN/13 (n=695): decode → `00 15 00 01 00 01`  (pt[3]=0x15=len+2)
  - IN/12 (n=204): decode → `00 14 00 D2 07 01`  (pt[3]=0x14=len+2)
  - IN/11 (n=158): decode → `00 13 00 D2 07 01`  (pt[3]=0x13=len+2)
  - IN/24 (n=998): decode → `00 00 00 00 00 00` (mostly) — the mirror family
  The pt[3]=len+2 invariant in IN/11/12/13 proves the same K covers inbound.
- K[0] differs per direction: OUT/24 pos0 takes exactly 10 contiguous values
  (64-6D, a 10-player lobby) XOR a single session byte; IN/26 pos0 takes ~15-20
  near-contiguous values (5A-6D) XOR K[0]-inbound. Entity IDs = player indices.
- K[1] = 0 for inbound: ct[1] is a full-range 7-bit value (uniq=128, bit7 always 0)
  — a per-packet sequence/nonce. Unchanged for OUT.
- K[8..] = 0: no evidence of any mask beyond position 7 in any session.

### Session table (K[2..7])

| Session | K[2..7] | hit layout |
|---|---|---|
| 13:43 | DE DF CF DF DD DF | len 25, zone@18 (80%) |
| 14:50 | 71 70 72 70 60 70 | len 25, zone@20 (100%) |
| 14:58 | 4F 5F 4F 4D 4F 4E | len 23, no plaintext zone |
| 15:19 |  K deducible; layout variant  | len 23, no plaintext zone |
| 15:46 | FA EA FA F8 FA FB | len 25, zone@17 (93%) |
| 16:10 | C8 D8 C8 CA C8 C9 | len 24, zone@19 (100%) |

Note K nibble structure: K[2]^K[3]=0x10, K[2]^K[4]=0x00, K[2]^K[5]=0x02, K[2]^K[6]=0x00,
K[2]^K[7]=0x01 in 14:58/15:46/16:10 — the OUT/24 plaintext header is not all-zero in
those layouts (decoded pt header = `05 00 00 6E 07 00` for IN/26 subtype), explaining the
"keystream variant" sessions: same mechanism, different plaintext header constants.

### Live recovery algorithm (works every session)

1. Collect ~100 OUT/24 packets (arrive within ~3s at 31ms cadence).
2. K[i] = mode of ct[i] for i in 2..7. (uniq=1 observed in all 6 sessions at
   those positions; the mode is unambiguous.)
3. Decode any packet: pt[i] = ct[i] ^ K[i] for i in 2..7; pt[0] = ct[0] ^ K0_out
   where K0_out is recoverable by requiring pos0 values to be contiguous; all
   other bytes pass through unchanged.
4. Validate: decode IN/11/12/13 → expect pt[3] == len+2. If not, the session is
   a rotated-layout variant; test K candidates against IN/13 until pt[3]=len+2
   holds for >90% of packets (solves 13:43/14:50-type layouts too).

## Why hit-confirms read plaintext (the actual answer)

The hit packets are NOT "unmasked sessions". Their payload beyond the header is
sent with K[i]=0 (i>=8) — the same is true for the 26B enemy packets' bytes 8-9
(checksum/timer). What rotates per session is *which fields land beyond the
encrypted region*:
- The zone byte is plaintext at different offsets per session (18/20/17/19 or
  absent) because the hit-packet layout itself rotates (len 23/24/25 variants).
- The `00 00` tail is a genuine plaintext trailer present in all layouts.
- Damage (plen-3) is plaintext in all observed layouts (dmg≤130 filter works
  in all 6 sessions; 87-97% of candidates show small values).

## Position data: encrypted, not masked (definitive)

IN/26 payload (bytes 10-25, two 8-byte halves A=p10-17, B=p18-25):
- Consecutive same-entity packets: A-half changes 0 or 8 of 8 bytes (75%/25%),
  never 1-6 (<=2%). B-half same pattern. Joint: both change together 74-83%.
- This is block-cipher avalanche, not XOR masking (XOR mask would produce
  small per-byte deltas).
- Cross-session block overlap: 0 shared ciphertext blocks between any two
  sessions (15/15 pairs, up to 383x337 blocks compared) → session-keyed cipher.
- No CRC8/additive checksum relation found for p8 over any tested range
  (10 variants, all <5% match).
- Payload is not timer-encoded (p9 is the timer low byte; cross-entity p9
  agrees within 50ms windows 95-99.7% → global timer, plaintext, K[9]=0).

Therefore: **delta radar impossible** (deltas are full-block random), and
**absolute coordinate recovery requires breaking the block cipher** (out of
scope; likely per-session AES/custom 64-bit block keyed by the session key).

## What IS readable live, per session

- Enemy entity IDs and their packet timing (IN/26 pos0 ^ K0_in; ~10 entities).
- Hit events: damage (plen-3), zone (layout-dependent position), weapon tags
  (p16/p11/p12 correlate with damage class), and hit clustering/timing.
- OUT/24 cadence analysis (firing detection) — works as before, unmasked
  payload beyond header is also block-encrypted but timing is plaintext.
- Heartbeat families (IN/11/12/13) fully decode once K is known.

## Files

- `analysis/mask_analysis.py` — first-pass histograms, b2==b3 classifier
- `analysis/mask_deep.py`, `fam_hist.py`, `keystream_compare.py` — per-family constancy
- `analysis/definitive.py`, `final_validation.py`, `alignment_test.py` — K extraction + validation
- `analysis/subtype_delta.py`, `substream_split.py`, `numeric_test.py` — delta/numeric tests (encrypted verdict)
- `analysis/blockcipher_confirm.py` — avalanche + cross-session cipher proof
- `analysis/crc_hunt.py`, `checksum_hunt.py` — checksum negative results
- `analysis/zone_scan.py`, `hit_fields.py` — hit-packet field maps
