$f = 'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull6\capture_raw_20260908_195156.txt'
# Count OUT rows by len bucket using regex on raw lines
$hist = @{}
$tot = 0
foreach ($line in [System.IO.File]::ReadLines($f)) {
  if ($line.Length -eq 0 -or $line[0] -eq '#') { continue }
  $p = $line.Split(' ')
  if ($p.Length -lt 12) { continue }
  if ($p[3] -ne 'OUT') { continue }
  $tot++
  $l = $p[8]
  if (-not $hist.ContainsKey($l)) { $hist[$l] = 0 }
  $hist[$l]++
}
Write-Host ("total OUT rows: " + $tot)
foreach ($k in ($hist.Keys | Sort-Object {[int]$_})) { Write-Host ("len={0} count={1}" -f $k, $hist[$k]) }
