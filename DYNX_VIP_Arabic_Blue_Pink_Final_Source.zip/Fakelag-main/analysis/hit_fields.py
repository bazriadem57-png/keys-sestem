import collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

rows = load(r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_161055.txt')
ins = [r for r in rows if r['dir'] == 'IN']
cand = [r for r in ins if 22 <= r['ln'] <= 26 and r['p'][-2:] == b'\x00\x00' and r['p'][-3] <= 130]
sub = [r for r in cand if r['ln'] == 24]
print("16:10 IN/24-tail hits n=%d: fields p8 p11 p12 p15 p16 p19 p21=dmg" % len(sub))
for r in sub[:25]:
    p = r['p']
    print(f"  {p[8]:02X} {p[11]:02X} {p[12]:02X} {p[15]:02X} {p[16]:02X} {p[19]:02X} dmg={p[21]:3d}")
byzone = collections.defaultdict(list)
for r in sub:
    byzone[(r['p'][16], r['p'][19])].append(r['p'][21])
print("\n(p16,p19) vs damage:")
for k, v in sorted(byzone.items(), key=lambda kv: -len(kv[1])):
    v.sort()
    print(f"  (p16={k[0]:02X},p19={k[1]:02X}) n={len(v)} dmg med={v[len(v)//2]} max={v[-1]}")

# check 14:58: is p11/p15 (10/08 flags) correlated with damage p20?
rows2 = load(r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_145845.txt')
ins2 = [r for r in rows2 if r['dir'] == 'IN']
cand2 = [r for r in ins2 if 22 <= r['ln'] <= 26 and r['p'][-2:] == b'\x00\x00' and r['p'][-3] <= 130]
sub2 = [r for r in cand2 if r['ln'] == 23]
print(f"\n14:58 IN/23-tail hits n={len(sub2)}: p8 p11 p12 p15 p16 p17 p18 p20=dmg")
for r in sub2[:25]:
    p = r['p']
    print(f"  {p[8]:02X} {p[11]:02X} {p[12]:02X} {p[15]:02X} {p[16]:02X} {p[17]:02X} {p[18]:02X} dmg={p[20]:3d}")
byz2 = collections.defaultdict(list)
for r in sub2:
    byz2[(r['p'][11], r['p'][15])].append(r['p'][20])
for k, v in sorted(byz2.items(), key=lambda kv: -len(kv[1]))[:12]:
    v.sort()
    print(f"  (p11={k[0]:02X},p15={k[1]:02X}) n={len(v)} dmg med={v[len(v)//2]} max={v[-1]}")
