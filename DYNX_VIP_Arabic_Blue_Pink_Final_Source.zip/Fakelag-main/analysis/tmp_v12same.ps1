param([string]$File)
# Same-len-consecutive-only monotonic check for v12, and magnitude distribution of deltas (is it smooth ~few hundred per 100ms?)
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapL {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len < 45 || len > 64) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapL]::Parse($File)
$n = [CapL]::Ts.Count

foreach ($off in (12,18,24)) {
  Write-Host ("`n=== offset {0}-{1} (same-len consecutive pairs only)" -f $off, ($off+1))
  $prev = -1; $prevTs = -1; $prevLen = -1
  $dh = @{}
  $dec=0; $inc=0; $same=0
  for ($i=0; $i -lt $n; $i++) {
    $h = [CapL]::Hex[$i]
    if ($h.Length -lt 2*($off+2)) { continue }
    if ($prevLen -ge 0 -and [CapL]::Lens[$i] -eq $prevLen) {
      $b = [CapL]::ToBytes($h)
      $v = $b[$off] + 256*$b[$off+1]
      $d = $v - $prev
      if ($d -lt 0) { $dec++ } elseif ($d -gt 0) { $inc++ } else { $same++ }
      $k = $d
      if (-not $dh.ContainsKey($k)) { $dh[$k]=0 }
      $dh[$k]++
    }
    $b2 = [CapL]::ToBytes($h)
    $prev = $b2[$off] + 256*$b2[$off+1]
    $prevTs = [CapL]::Ts[$i]; $prevLen = [CapL]::Lens[$i]
  }
  Write-Host ("dec={0} inc={1} same={2}" -f $dec, $inc, $same)
  $top = $dh.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 15
  foreach ($t in $top) { Write-Host ("  delta {0,7}: {1,5}" -f $t.Key, $t.Value) }
}
