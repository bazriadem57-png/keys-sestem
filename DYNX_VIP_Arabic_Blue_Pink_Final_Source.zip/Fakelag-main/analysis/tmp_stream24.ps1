param([string]$File, [int]$TargetLen = 24, [int]$MaxShow = 40)
# Dump consecutive OUT packets of TargetLen with timestamps & inter-packet deltas + per-byte XOR heatmap
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class Cap2 {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static List<string> Dir = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      string hex = p[p.Length-1];
      if (hex.Length != len * 2) continue;
      bool ok = true;
      foreach (char c in hex) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(hex); Dir.Add(p[3]);
    }
  }
}
"@
Add-Type -TypeDefinition $src
[Cap2]::Parse($File)
$n = [Cap2]::Ts.Count
# gather indexes of OUT packets of target len
$idx = New-Object System.Collections.Generic.List[int]
for ($i=0; $i -lt $n; $i++) {
  if ([Cap2]::Dir[$i] -eq 'OUT' -and [Cap2]::Lens[$i] -eq $TargetLen) { $idx.Add($i) }
}
Write-Host ("OUT len={0} packets: {1}" -f $TargetLen, $idx.Count)
# timestamps cadence stats
$dts = New-Object System.Collections.Generic.List[double]
for ($j=1; $j -lt $idx.Count; $j++) { $dts.Add([Cap2]::Ts[$idx[$j]] - [Cap2]::Ts[$idx[$j-1]]) }
if ($dts.Count -gt 0) {
  $sorted = $dts | Sort-Object
  $med = $sorted[[int]($sorted.Count/2)]
  $mean = ($dts | Measure-Object -Average).Average
  Write-Host ("dt ms: median={0} mean={1:N1} min={2} max={3} rate={4:N1} Hz" -f $med, $mean, ($dts | Measure-Object -Minimum).Minimum, ($dts | Measure-Object -Maximum).Maximum, (1000.0/$mean))
}
# show first MaxShow packets with dt
$prev = -1
for ($j=0; $j -lt [Math]::Min($MaxShow, $idx.Count); $j++) {
  $i = $idx[$j]
  $dt = if ($prev -ge 0) { [Cap2]::Ts[$i] - $prev } else { 0 }
  Write-Host ("{0,5} dt={1,4} {2}" -f $j, $dt, [Cap2]::Hex[$i])
  $prev = [Cap2]::Ts[$i]
}
# per-byte volatility: fraction of consecutive pairs where byte changed
$L = $TargetLen
$chg = New-Object double[] $L
$pairs = $idx.Count - 1
for ($j=1; $j -lt $idx.Count; $j++) {
  $a = [Cap2]::Hex[$idx[$j-1]]; $b = [Cap2]::Hex[$idx[$j]]
  for ($k=0; $k -lt $L; $k++) {
    if ($a[2*$k] -ne $b[2*$k] -or $a[2*$k+1] -ne $b[2*$k+1]) { $chg[$k]++ }
  }
}
Write-Host "--- per-byte change rate (consecutive 24B OUT packets):"
for ($k=0; $k -lt $L; $k++) { Write-Host ("byte {0,2}: {1,8:P2}" -f $k, ($chg[$k]/[Math]::Max(1,$pairs))) }
