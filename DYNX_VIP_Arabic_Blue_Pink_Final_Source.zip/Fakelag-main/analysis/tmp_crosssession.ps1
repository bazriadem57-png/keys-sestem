param([string]$File)
# Cross-session comparison of the 24B stream + keepalive header, to verify mask-independence.
# Sessions: pull5 20260907_134332, pull6 195156, pull7 220209 (different capture dates -> likely different masks)
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapD {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static List<string> Dir = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      string raw = p[p.Length-1];
      string hex = raw.TrimEnd('.');
      bool ok = true;
      foreach (char c in hex) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(hex); Dir.Add(p[3]);
    }
  }
}
"@
Add-Type -TypeDefinition $src

$files = @(
  'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_134332.txt',
  'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull6\capture_raw_20260908_195156.txt',
  'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull7\capture_raw_20260908_220209.txt'
)
foreach ($f in $files) {
  [CapD]::Ts.Clear(); [CapD]::Lens.Clear(); [CapD]::Hex.Clear(); [CapD]::Dir.Clear()
  [CapD]::Parse($f)
  $n = [CapD]::Ts.Count
  Write-Host ("`n########## " + (Split-Path (Split-Path $f -Parent) -Leaf) + "\" + (Split-Path $f -Leaf))
  Write-Host ("rows: " + $n)
  # 24B stream header bytes 2-7 constancy
  $h24 = @{}
  $c24 = 0
  for ($i=0; $i -lt $n; $i++) {
    if ([CapD]::Dir[$i] -ne 'OUT' -or [CapD]::Lens[$i] -ne 24) { continue }
    if ([CapD]::Hex[$i].Length -lt 48) { continue }
    $c24++
    $k = [CapD]::Hex[$i].Substring(4,12)
    if (-not $h24.ContainsKey($k)) { $h24[$k]=0 }; $h24[$k]++
  }
  Write-Host ("24B OUT count: " + $c24)
  $h24.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 3 | ForEach-Object { Write-Host ("  hdr(2-7)=0x{0} count={1} ({2:P1})" -f $_.Key, $_.Value, ($_.Value/[double]$c24)) }
  # keepalive header bytes 2-7 constancy
  $hk = @{}
  $ck = 0
  for ($i=0; $i -lt $n; $i++) {
    if ([CapD]::Dir[$i] -ne 'OUT') { continue }
    $l = [CapD]::Lens[$i]; if ($l -lt 45 -or $l -gt 64) { continue }
    if ([CapD]::Hex[$i].Length -lt 64) { continue }
    $ck++
    $k = [CapD]::Hex[$i].Substring(4,12)
    if (-not $hk.ContainsKey($k)) { $hk[$k]=0 }; $hk[$k]++
  }
  Write-Host ("keepalive(45-64B) OUT count: " + $ck)
  $hk.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 3 | ForEach-Object { Write-Host ("  hdr(2-7)=0x{0} count={1} ({2:P1})" -f $_.Key, $_.Value, ($_.Value/[double]$ck)) }
  # keepalive raw byte2/byte3 distributions
  $b2 = @{}; $b3 = @{}
  for ($i=0; $i -lt $n; $i++) {
    if ([CapD]::Dir[$i] -ne 'OUT') { continue }
    $l = [CapD]::Lens[$i]; if ($l -lt 45 -or $l -gt 64) { continue }
    if ([CapD]::Hex[$i].Length -lt 8) { continue }
    $k2 = [CapD]::Hex[$i].Substring(4,2); $k3 = [CapD]::Hex[$i].Substring(6,2)
    if (-not $b2.ContainsKey($k2)) { $b2[$k2]=0 }; $b2[$k2]++
    if (-not $b3.ContainsKey($k3)) { $b3[$k3]=0 }; $b3[$k3]++
  }
  Write-Host "keepalive raw byte2 top5:"
  $b2.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 5 | ForEach-Object { Write-Host ("  0x{0}: {1}" -f $_.Key, $_.Value) }
  Write-Host "keepalive raw byte3 top5:"
  $b3.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 5 | ForEach-Object { Write-Host ("  0x{0}: {1}" -f $_.Key, $_.Value) }
}
