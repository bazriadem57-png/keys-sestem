#!/usr/bin/env python3
"""Free Fire Max UDP XOR-mask recovery feasibility analysis.

Usage: python mask_analysis.py <capture_raw file> [more files]

Reads full-hex rows only (hexlen == len*2), and runs:
  1. Session classification (constant mask vs positional keystream) via b2==b3 test
     on the 24B outbound stream.
  2. Per-position byte histograms for inbound 26B / 34B packets -> dominant values.
  3. Hit-confirm structural check: last-two-bytes 00 00, damage<=130.
  4. Consecutive same-length packet XOR (delta) analysis: fraction of zero bytes
     per position in XOR of packet N vs N+1.
  5. Constant-mask candidate extraction: mode(ciphertext[i]) per position,
     assuming dominant plaintext 0x00 (padding/header).
"""
import sys, os, collections, statistics

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                seq = int(parts[0]); ts = int(parts[1])
                phase = parts[2]; d = parts[3]; decision = parts[4]
                dip, sp, dp = parts[5], parts[6], parts[7]
                ln = int(parts[8])
                # column layouts: old = seq ts phase dir decision dip sp dp len type payload
                #                 new = seq ts phase dir decision dip sp dp len type family kind payload
                if len(parts) >= 13 and all(len(x) <= 12 for x in parts[9:12]):
                    ptype = parts[9]; fam = parts[10]; kind = parts[11]
                    hx = parts[12]
                else:
                    ptype = parts[9]; fam = ''; kind = ''
                    hx = parts[10] if len(parts) > 10 else ''
            except ValueError:
                continue
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(seq=seq, ts=ts, dir=d, ln=ln, fam=fam, kind=kind, p=payload, type=ptype))
    return rows

def classify(rows):
    """Use OUT/24 stream: if plaintext b2==b3 invariant exists, constant mask."""
    out24 = [r for r in rows if r['dir'] == 'OUT' and r['ln'] == 24]
    if len(out24) < 50:
        return None, len(out24)
    eq = sum(1 for r in out24 if r['p'][2] == r['p'][3])
    return eq / len(out24), len(out24)

def position_hist(packets, maxpos):
    hists = [collections.Counter() for _ in range(maxpos)]
    for r in packets:
        for i, b in enumerate(r['p']):
            if i < maxpos:
                hists[i][b] += 1
    return hists

def main():
    for path in sys.argv[1:]:
        rows = load(path)
        name = os.path.basename(path)
        print(f"\n{'='*80}\nFILE: {name}  rows={len(rows)}")
        ins = [r for r in rows if r['dir'] == 'IN']
        outs = [r for r in rows if r['dir'] == 'OUT']
        print(f"IN={len(ins)} OUT={len(outs)}")

        # 1. classify
        frac, n24 = classify(rows)
        print(f"\n[1] b2==b3 on OUT/24: {frac} (n={n24})")

        # length census
        cnt_in = collections.Counter(r['ln'] for r in ins)
        cnt_out = collections.Counter(r['ln'] for r in outs)
        print("Top IN lengths:", cnt_in.most_common(12))
        print("Top OUT lengths:", cnt_out.most_common(12))

        # 2. per-position histograms for IN/26 and IN/34
        for L in (26, 34):
            pk = [r for r in ins if r['ln'] == L]
            if len(pk) < 30:
                print(f"\n[2] IN/{L}: only {len(pk)} packets, skip")
                continue
            hists = position_hist(pk, L)
            print(f"\n[2] IN/{L} n={len(pk)} — per-position top-2 values (pos: val:cnt pct | val:cnt pct):")
            for i, h in enumerate(hists):
                tot = sum(h.values())
                top = h.most_common(2)
                s = ' | '.join(f"{v:02X}:{c}({100*c/tot:.0f}%)" for v, c in top)
                print(f"  {i:2d}: {s}")

        # 3. hit-confirm structural check
        hits = []
        for r in ins:
            p = r['p']
            if 22 <= len(p) <= 26 and p[-2:] == b'\x00\x00':
                dmg = p[-3]
                if dmg <= 130:
                    hits.append(r)
        print(f"\n[3] structural hit candidates: {len(hits)}")
        if hits:
            zone_ct = collections.Counter(h['p'][17] for h in hits)
            print(f"    byte17 values: {zone_ct.most_common(8)}")
            # tail-zero test: is mask zero at last two positions?
            # compare with per-position histogram of the hits
            hh = position_hist(hits, max(len(h['p']) for h in hits))
            print("    hit packet per-position top-1 (positions 15-25):")
            for i in range(15, len(hh)):
                tot = sum(hh[i].values())
                v, c = hh[i].most_common(1)[0]
                print(f"      {i:2d}: {v:02X} ({100*c/tot:.0f}%)")

        # 4. delta analysis: consecutive same-length IN packets
        for L in (26, 34):
            pk = [r for r in ins if r['ln'] == L]
            if len(pk) < 30:
                continue
            zero_frac_per_pos = [collections.Counter() for _ in range(L)]
            npairs = 0
            for a, b in zip(pk, pk[1:]):
                # only adjacent-in-stream, any time gap
                xa = a['p']; xb = b['p']
                npairs += 1
                for i in range(L):
                    zero_frac_per_pos[i][(xa[i] ^ xb[i]) == 0] += 1
            if npairs < 30:
                continue
            print(f"\n[4] IN/{L} consecutive-pair XOR: n={npairs} — % pairs where byte i XORs to 0:")
            line = []
            for i in range(L):
                c = zero_frac_per_pos[i]
                tot = sum(c.values())
                line.append(f"{100*c[True]/tot:.0f}")
            print("  " + ' '.join(line))

        # 5. OUT/62-63 MOVE stream per-position histogram (known plaintext: 0000 at offsets 20-21?)
        move = [r for r in outs if r['ln'] in (62, 63)]
        if len(move) > 100:
            hists = position_hist(move, 62)
            print(f"\n[5] OUT/62-63 MOVE n={len(move)} — per-position top-1:")
            for i, h in enumerate(hists):
                tot = sum(h.values())
                v, c = h.most_common(1)[0]
                print(f"  {i:2d}: {v:02X} ({100*c/tot:.0f}%) n_uniq={len(h)}")

if __name__ == '__main__':
    main()
