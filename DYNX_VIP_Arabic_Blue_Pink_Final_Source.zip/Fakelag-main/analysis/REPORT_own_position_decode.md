# Free Fire Max — own-player position/orientation decode results
Sub-agent report for parent session-419e0c84.

## TL;DR
- The **keepalive channel (OUT, 45-64B, ~100ms)** is the own-player STATE channel, and its payload bytes 12-31 behave like **plain (or constant-masked) little-endian 16-bit fields that change by small signed deltas (+-1, +-2, +-4...) while the player moves and freeze completely while still**. This is where own position (and likely yaw) live. Byte-pairs 20-21, 22-23, 24-25, 26-27, 28-29, 30-31 are the strongest position/orientation candidates.
- The **24B input stream** payload (bytes 8-23) is **fully diffusing** — when the input state changes, ALL 16 bytes change (~64-bit Hamming distance), and identical input states produce byte-identical payloads (repeats seen up to x10). It is NOT a simple 16-bit yaw under a constant XOR mask. It looks encrypted/hashed per input-state, so it is NOT usable for extracting yaw/pitch by diffing.
- Truncated hex (hexLimit=32) blocks deep analysis of keepalive bytes >31; bytes 12-31 are fully covered and suffice for x/y (see calibration below).

## Keepalive structure (mask-independent, verified on 4 sessions)
Packets: OUT, len 53-62 (also 48-52, 63-64 rarer), ~100ms cadence (median 100ms).

Layout (byte offsets):
- 0-1: per-packet counter/nonce — changes ~90%/99% of pairs even when idle; small XOR deltas (0x01,0x02,0x0C,0x0E...) in 24B stream; in keepalive, b0 has distinct=14, b1 distinct=73 (wraps).
- 2-7: session-constant header (mask bytes visible): pull6 = 0C 3D 0C DD 0B 0C (len57) / 0C 38... (len56) — byte 3 encodes packet LENGTH (payload content length field). pull7 = 9D 4C 9A xx 9D 9D with byte 5 varying by len: A8=L61, A9=L60, AA=L59?, AB=L62, AC=L57, AD=L58, AE=L59, AF=L58, B0=L53, B1=L52, B3=L54. So bytes 3 (pull6) / 5 (pull7) = payload-size field (family R vs S explains the different offset).
- 8-11: constant per movement window (e.g. 85 80 80 08 in pull6) — sub-header (movement-state flags + mask).
- 12-31: THE STATE BLOCK. Six+ 16-bit LE fields at offsets 12,14,16,18,20,22,24,26,28,30.

Behavior:
- **Idle (standing still)**: ENTIRE payload bytes 2-31 frozen across consecutive same-len packets (2000/3414 pairs frozen in pull6 BEFORE; 431/979 in pull7; 1474/5538 in pull5). Only b0/b1 tick.
- **Moving**: bytes 12-31 change with SMALL SIGNED DELTAS. Pull6 ACTIVE pairs (n=1551) top deltas per byte: b13: +-1 (x114/112), b21: +-2 (x124/95), b23: +-2 (x107/97), b24/25/26/27: +-2/4, b29: +-1, b30/31: +-2/1. Smoothness (|d|<=4) fractions: b14: 99.4%, b20: 99.4%, b22: 98.1%, b16/17: 95-98%, b12: 72.9% (pull6). Same pattern holds in pull5 and pull7 (b14/17/20/22 at 95-100%).
- Solo-byte changes concentrate at offsets 21,22,23,24,30,31 (pull6: 28/20/24/41/11/40 events) — these bytes carry the most independent variation.
- 16-bit LE delta histograms (pull7, len60, same-len): off13-14: 95% of deltas |d|<=64; off16-17: 100% |d|<=4; off19-20: 98% small; off21-22: 95% small. => clean 16-bit fields stepping by units.
- w16 (bytes 16-17 LE) = smooth countdown timer-ish: hovers ~900-925, deltas -1..-6 per 100ms when changing (40x +3, 32x -1, 32x -2...) — likely a tick/sequence age, NOT position.
- w12 (bytes 12-13) = fastest-moving field; in one 26-packet walking run it rose +1050/packet (~10,500 units/sec) monotonically then wrapped; median |rate| 6,980 units/s (pull6), 14,840 (pull5). Could be X coordinate (fast axis) or an integrated tick counter.
- Correlated pairs: w20 & w24 move together (differences cluster at few values); w22 & w26 difference = 1 in 1162/4864 packets. Suggests duplicated/related fields (e.g., position sent twice, or pos + predicted pos).

## 24B input stream (aim channel) — NOT directly decodable
- Header bytes 2-7 session-constant (pull6: 0C1C0C0E0C0D 99.8%; pull7: 9D9F9D8D9D9C 100%; pull5: C8D8C8CAC8C9 100%).
- Bytes 0-1: counter/nonce (small XOR deltas; arithmetic +0..+5 and wraps).
- Bytes 8-23: when input state changes, ~all 16 bytes change (2079/2267 new-payload transitions differ in 16/16 bytes; HD ~64/128 bits = random). When unchanged, payload is byte-identical and repeats (up to x10). => deterministic but diffusing encoding (hash/CRC/encryption of state, no per-packet nonce). 21 "aim-only" transitions (8-15 frozen, 16-23 changed) exist but their deltas are full-range random — no 16-bit angle structure visible.
- Conclusion: yaw/pitch are NOT extractable from the 24B stream by diffing. The own-camera orientation must come from the keepalive (or from server->client packets, not analyzed here).

## Ghost/FREEZE cross-check (pull6 195156)
- Phase timeline: BEFORE/FREEZE alternating (freeze windows 0.3-3.4s).
- During FREEZE, keepalive payload (b2-31) frozen in 193/281 same-len pairs — the ghost replays the saved keepalive; the 88 changing pairs are boundary/refresh packets.
- 24B stream during FREEZE: 12 changed / 0 identical among consecutive pairs (sample small) — input stream keeps flowing regardless, confirming keepalive = position authority, 24B = input.

## Coordinate format hypothesis
- 16-bit LITTLE-ENDIAN quantized integers, several fields side by side at offsets 12,14,16,18,20,22,24,26,28,30 (post 12-byte header). NOT float32 (float mantissa low bytes would still show smooth deltas, but we'd see 4-byte groups with correlated carries; the observed structure is clean 2-byte fields).
- Values change by +-1..+-6 per 100ms per field. If walk speed ~5 m/s => ~0.5m per 100ms. Solo-w24 deltas of +-2 per 100ms => scale ~0.25 m/unit if w24 is a position axis (or 2x if deltas are half-units). Solo-w20 deltas are +-512 (high-byte steps) => w20 has 256x coarser scale (could be the same axis at different quantization, or a different axis).
- Most likely mapping (needs calibration): x = w20/w24 pair region (bytes 20-25), z = w26/28 region, y (height) = one of w16/w22 (slow-changing), yaw = one of the remaining fields; w12 = fast axis or tick.
- The len of the keepalive packet itself encodes movement magnitude (idle runs sit at one constant len for minutes — e.g. L56 or L53; active periods mix 57-62), so len is a rough speed indicator.

## Confidence
- Keepalive = own-state channel with smooth 16-bit LE fields: HIGH (95%). Verified mask-independent across 4 sessions (pull6 195156, pull7 220209, pull5 161055, pull5 134332 family R).
- Exact field->axis assignment (which of w12..w30 is x/y/z/yaw): LOW-MEDIUM (~40%). Needs calibration.
- 24B unusable for orientation: HIGH confidence (~90%).
- Scale (units per meter): UNKNOWN pending calibration.

## Calibration capture to confirm
1. Walk exactly north 50m in a straight line (in-game compass), standing still 5s before/after. Only ONE 16-bit field should show a monotonic +/- constant-step run of ~500 packets; the step count / 50 gives units-per-meter; sign gives axis direction. Repeat south: sign flips.
2. Walk east/west 50m: a DIFFERENT field should monotonically step (identifies X vs Z).
3. Jump repeatedly: the height field shows sawtooth (up ~2x walk rate, down with gravity accel — non-constant steps identify Y and give gravity scale).
4. Rotate aim 360 degrees slowly while standing still (position frozen): whichever keepalive field sweeps ~monotonically through a large range and wraps once = yaw; total sweep count / 360 gives angle scale (e.g. 65536/360 = 182.04 units/deg if 16-bit full-circle).
5. Pitch: aim up/down slowly; smaller-range field = pitch.
All five tests are doable with the existing capture tool; recommend hexLimit raised to 64+ so bytes 32-63 of keepalives are captured (the tail beyond byte 31 likely holds more fields — currently truncated).
