param([string]$File)
# KEY HYPOTHESIS TEST: keepalive bytes 12-13 (16-bit LE) decrease monotonically over time (like a countdown timer / tick counter).
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapK {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len < 45 || len > 64) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapK]::Parse($File)
$n = [CapK]::Ts.Count
Write-Host ("keepalive packets: " + $n)

# track v12 across all keepalives sorted by ts (already in order)
$prev = -1; $prevTs = -1
$dec = 0; $inc = 0; $same = 0
$deltaPerSec = New-Object System.Collections.Generic.List[double]
for ($i=0; $i -lt $n; $i++) {
  $h = [CapK]::Hex[$i]
  if ($h.Length -lt 28) { continue }
  $b = [CapK]::ToBytes($h)
  $v = $b[12] + 256*$b[13]
  if ($prev -ge 0) {
    $d = $v - $prev
    if ($d -lt 0) { $dec++ } elseif ($d -gt 0) { $inc++ } else { $same++ }
    $dt = ([CapK]::Ts[$i] - $prevTs)/1000.0
    if ($dt -gt 0.5 -and $dt -lt 2.5 -and $d -lt 0) { $deltaPerSec.Add(-$d/$dt) }
  }
  $prev = $v; $prevTs = [CapK]::Ts[$i]
}
Write-Host ("v12(LE of bytes 12-13) transitions: dec={0} inc={1} same={2}" -f $dec, $inc, $same)
if ($deltaPerSec.Count -gt 0) {
  $srt = $deltaPerSec | Sort-Object
  Write-Host ("decrease rate per second: median={0:N1} min={1:N1} max={2:N1} n={3}" -f $srt[[int]($srt.Count/2)], $srt[0], $srt[-1], $deltaPerSec.Count)
}

# ALSO: bytes 14-15? and bytes 18-19? check monotonic tendencies
foreach ($off in (14,18,16,20,22,24)) {
  $prev = -1; $dec=0; $inc=0; $same=0
  for ($i=0; $i -lt $n; $i++) {
    $h = [CapK]::Hex[$i]
    if ($h.Length -lt 2*($off+2)) { continue }
    $b = [CapK]::ToBytes($h)
    $v = $b[$off] + 256*$b[$off+1]
    if ($prev -ge 0) {
      $d = $v - $prev
      if ($d -lt 0) { $dec++ } elseif ($d -gt 0) { $inc++ } else { $same++ }
    }
    $prev = $v
  }
  Write-Host ("off {0}-{1} transitions: dec={2} inc={3} same={4}" -f $off, ($off+1), $dec, $inc, $same)
}
