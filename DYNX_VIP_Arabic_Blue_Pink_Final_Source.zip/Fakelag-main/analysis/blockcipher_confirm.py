#!/usr/bin/env python3
"""Block-cipher confirmation tests on IN/26 payload:
 E1: joint distribution P(A-changed, B-changed) — independence of the two 8-byte halves.
 E2: recurrence pairs (same A block, different packets): do they share p1/p8? (rules out
     per-packet keystream derived from p1/p8)
 E3: cross-entity block sharing (same ciphertext block for different entity IDs).
 E4: avalanche quantification: for pairs where A changes, #changed bytes histogram (already
     seen: 0 or 8). Confirm at finer granularity incl. 1-6.
"""
import sys, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def main():
    path = sys.argv[1]
    rows = load(path)
    ins = [r for r in rows if r['dir'] == 'IN']
    in26 = [r for r in ins if r['ln'] == 26]
    sub = collections.Counter((r['p'][2], r['p'][5], r['p'][6]) for r in in26).most_common(1)[0][0]
    g = [r for r in in26 if (r['p'][2], r['p'][5], r['p'][6]) == sub]
    byE = collections.defaultdict(list)
    for r in g:
        byE[r['p'][0]].append(r)
    print(f"subtype n={len(g)} entities={len(byE)}")

    # E1: joint A/B change (within entity, consecutive)
    joint = collections.Counter()
    finer = collections.Counter()
    for e, seq in byE.items():
        if len(seq) < 30:
            continue
        for a, b in zip(seq, seq[1:]):
            cA = sum(1 for i in range(10, 18) if a['p'][i] != b['p'][i])
            cB = sum(1 for i in range(18, 26) if a['p'][i] != b['p'][i])
            joint[(min(cA, 1), min(cB, 1))] += 1
            finer[(cA, cB)] += 1
    tot = sum(joint.values())
    print(f"\n[E1] joint (A-changed?, B-changed?) over {tot} consecutive pairs:")
    for k in sorted(joint):
        print(f"   A{'chg' if k[0] else 'same'} B{'chg' if k[1] else 'same'}: {joint[k]} ({100*joint[k]/tot:.1f}%)")
    print(f"\n[E4] finer histogram (cA, cB) top-12: {finer.most_common(12)}")

    # E2: recurrence pairs — same A block within entity, different packets
    print("\n[E2] recurrence pairs (same p10-17, same entity, different packets):")
    shown = 0
    diff_p1 = same_p1 = 0
    for e, seq in byE.items():
        seen = {}
        for r in seq:
            key = r['p'][10:18]
            if key in seen:
                prev = seen[key]
                if r['ts'] - prev['ts'] > 1000:  # only distant recurrences
                    if shown < 8:
                        print(f"   entity {e:02X} dt={r['ts']-prev['ts']}ms p1: {prev['p'][1]:02X} vs {r['p'][1]:02X}, p8: {prev['p'][8]:02X} vs {r['p'][8]:02X}, p9: {prev['p'][9]:02X} vs {r['p'][9]:02X}")
                        shown += 1
                    if prev['p'][1] == r['p'][1]:
                        same_p1 += 1
                    else:
                        diff_p1 += 1
                # keep first occurrence... actually keep latest for chains
            else:
                seen[key] = r
    print(f"   distant recurrence pairs: same-p1={same_p1}, diff-p1={diff_p1}")

    # E3: cross-entity block sharing
    blocks = collections.defaultdict(set)
    block_count = collections.Counter()
    for r in g:
        blocks[r['p'][10:18]].add(r['p'][0])
        block_count[r['p'][10:18]] += 1
    shared = [b for b, es in blocks.items() if len(es) > 1]
    print(f"\n[E3] distinct A-blocks={len(blocks)}, blocks seen at >1 entity={len(shared)} ({100*len(shared)/max(len(blocks),1):.1f}%)")
    # how many packets in shared blocks
    pk = sum(block_count[b] for b in shared)
    print(f"   packets with shared A-block: {pk}/{len(g)} ({100*pk/len(g):.1f}%)")
    # full 16-byte block sharing across entities
    blocks16 = collections.defaultdict(set)
    for r in g:
        blocks16[r['p'][10:26]].add(r['p'][0])
    shared16 = [b for b, es in blocks16.items() if len(es) > 1]
    print(f"   distinct full-16B blocks={len(blocks16)}, shared across entities={len(shared16)}")

if __name__ == '__main__':
    main()
