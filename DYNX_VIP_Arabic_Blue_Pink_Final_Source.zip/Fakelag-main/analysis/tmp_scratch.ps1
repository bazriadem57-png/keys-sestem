param([string]$Csv)
# Investigate the 24B "payload-same-but-header-differs" pairs (3241): b0/b1 always change, payload repeats.
# During repeated-payload stretches the input is CONSTANT (idle). b0/b1 = per-packet nonce/counter.
# Then aim = when payload CHANGES. Since payload appears fully random between distinct inputs,
# the 16 bytes 8-23 are likely ENCRYPTED (keystream from b0/b1 nonce) OR contain bitfield+seq+checksum.
# Test: do repeated payloads recur across the session (same plaintext input re-sent)? If encryption is nonce-based, no.
# We saw 1030 payloads repeat with x9, x10 counts... so same 16 bytes recur -> NOT nonce-encrypted!
# => plaintext-mapped: same input state = same 16 bytes. So it's a deterministic encoding of input state,
#    but different input states differ in ~all bytes -> the encoding is diffusing (e.g., CRC/bit-packed with position?).
# Test 2: maybe bytes 8-23 = encrypted with key derived from b0/b1 of PREVIOUS packet (chained) - but repeats disprove.
# Test 3: The 16 bytes could contain a small integer in low entropy + CHECKSUM/hash that diffuses. 
# Check: among distinct payloads, is there any linear structure? Take pairs of payloads that differ in exactly 1 byte.
$rows = Import-Csv $Csv
