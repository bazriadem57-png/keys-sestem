param([string]$File)
# Parse capture, extract OUT rows grouped by len, compute per-byte volatility for 24B input stream
$rows = [System.Collections.Generic.List[object]]::New()
$sr = New-Object System.IO.StreamReader($File)
while ($null -ne ($line = $sr.ReadLine())) {
  if ($line.StartsWith('#')) { continue }
  $p = $line -split ' '
  if ($p.Count -lt 12) { continue }
  $hex = $p[11]
  $len = [int]$p[9]
  # usable rows only: full hex
  if ($hex.Length -ne ($len*2)) { continue }
  if ($hex -notmatch '^[0-9A-F]+$') { continue }
  $rows.Add([pscustomobject]@{
    seq=[int]$p[0]; ts=[double]$p[1]; dir=$p[3]; len=$len; fam=$p[8]; kind=$p[9+0]; hex=$hex
  })
}
$sr.Close()
Write-Host "usable rows: $($rows.Count)"
# group OUT by length
$byLen = $rows | Where-Object {$_.dir -eq 'OUT'} | Group-Object len | Sort-Object {[int]$_.Name}
foreach ($g in $byLen) {
  Write-Host ("len={0} count={1}" -f $g.Name, $g.Count)
}
