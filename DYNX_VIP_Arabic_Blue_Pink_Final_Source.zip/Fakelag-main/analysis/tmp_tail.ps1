param([string]$Csv)
# Look for structure in the keepalive tail: packets where bytes 26-31 look like "0000..0000" (idle) vs non-zero (moving).
# Also examine bytes 18-19 region: "1Bxx" pattern - the third byte pair that changes on movement.
$rows = Import-Csv $Csv
Write-Host ("rows: " + $rows.Count)

function HexToBytes([string]$h) {
  $b = New-Object byte[] ($h.Length/2)
  for ($i=0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($h.Substring(2*$i,2),16) }
  return $b
}

# Distribution of "tail activity": for each row, count nonzero bytes among offsets 26..31
$hist = @{}
foreach ($r in $rows) {
  $b = HexToBytes $r.hex32
  $nz = 0
  for ($k=26; $k -lt 32; $k++) { if ($b[$k] -ne 0) { $nz++ } }
  if (-not $hist.ContainsKey($nz)) { $hist[$nz]=0 }
  $hist[$nz]++
}
Write-Host "nonzero count among bytes 26-31:"
foreach ($k in ($hist.Keys | Sort-Object)) { Write-Host ("  {0}: {1}" -f $k, $hist[$k]) }

# The 0x00 tail appears when idle. Correlate: rows with all-zero tail -> look at byte 18-19 and 12-13 constancy
# Show a sliding window sample: for each 10 consecutive rows, mark tail activity
Write-Host "--- timeline (window=20 rows): fraction with nonzero tail, plus len"
$w = 20
for ($i=0; $i -lt $rows.Count; $i += $w) {
  $act = 0
  $lens = @{}
  for ($j=$i; $j -lt [Math]::Min($i+$w, $rows.Count); $j++) {
    $b = HexToBytes $rows[$j].hex32
    $nz = 0
    for ($k=26; $k -lt 32; $k++) { if ($b[$k] -ne 0) { $nz++ } }
    if ($nz -gt 0) { $act++ }
    $l = $rows[$j].len
    if (-not $lens.ContainsKey($l)) { $lens[$l]=0 }; $lens[$l]++
  }
  $ls = ($lens.GetEnumerator() | Sort-Object Name | ForEach-Object { "$($_.Key)x$($_.Value)" }) -join ' '
  Write-Host ("  t={0} act={1,2}/{2,2} lens: {3}" -f $rows[$i].ts, $act, [Math]::Min($w, $rows.Count-$i), $ls)
}
