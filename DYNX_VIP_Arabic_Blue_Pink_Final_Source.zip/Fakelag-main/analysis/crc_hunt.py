#!/usr/bin/env python3
"""p8 = checksum hypothesis: test CRC8 variants over payload (plaintext) for IN/26.
Since payload bytes appear to be plaintext (K=0 for i>=8, timer at pos9 global),
p8 should equal some checksum of p9..p25 (or p9..p25 + header).
"""
import sys, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def crc8_generic(data, poly, init, refin, refout, xorout):
    def reflect(x, n):
        r = 0
        for i in range(n):
            if x & (1 << i):
                r |= 1 << (n - 1 - i)
        return r
    crc = init
    for b in data:
        if refin:
            b = reflect(b, 8)
        crc ^= b
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ poly) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    if refout:
        crc = reflect(crc, 8)
    return crc ^ xorout

VARIANTS = {
    'CRC-8':          (0x07, 0x00, False, False, 0x00),
    'CRC-8/CDMA':     (0x9B, 0xFF, False, False, 0x00),
    'CRC-8/DARC':     (0x39, 0x00, True, True, 0x00),
    'CRC-8/DVB-S2':   (0xD5, 0x00, False, False, 0x00),
    'CRC-8/EBU':      (0x1D, 0xFF, True, True, 0x00),
    'CRC-8/I-CODE':   (0x1D, 0xFD, False, False, 0x00),
    'CRC-8/ITU':      (0x07, 0x00, False, False, 0x55),
    'CRC-8/MAXIM':    (0x31, 0x00, True, True, 0x00),
    'CRC-8/ROHC':     (0x07, 0xFF, True, True, 0x00),
    'CRC-8/WCDMA':    (0x9B, 0x00, True, True, 0x00),
    'CRC-8/XOR0-07':  (0x07, 0x00, False, False, 0x00),
}

def main():
    path = sys.argv[1]
    rows = load(path)
    ins = [r for r in rows if r['dir'] == 'IN']
    in26 = [r for r in ins if r['ln'] == 26]
    sub = collections.Counter((r['p'][2], r['p'][5], r['p'][6]) for r in in26).most_common(1)[0][0]
    g = [r for r in in26 if (r['p'][2], r['p'][5], r['p'][6]) == sub][:500]
    print(f"IN/26 subtype n={len(g)}")

    ranges = [(9, 26), (10, 26), (2, 26), (9, 25), (0, 26)]
    for lo, hi in ranges:
        for name, (poly, init, refin, refout, xorout) in VARIANTS.items():
            ok = sum(1 for r in g if crc8_generic(r['p'][lo:hi], poly, init, refin, refout, xorout) == r['p'][8])
            if ok > len(g) * 0.05:
                print(f"  {name} over [{lo}:{hi}): {ok}/{len(g)}")
        # simple sums/xors with rotation
        s = sum(1 for r in g if (sum(r['p'][lo:hi]) + 0x100 - r['p'][8]) % 256 == 0)
        if s > len(g) * 0.05:
            print(f"  ADD over [{lo}:{hi}): {s}/{len(g)}")
        x = sum(1 for r in g if r['p'][8] == __import__('functools').reduce(lambda a, b: a ^ b, r['p'][lo:hi], 0))
        if x > len(g) * 0.05:
            print(f"  XOR over [{lo}:{hi}): {x}/{len(g)}")
    print("done (only >5% matches printed)")

if __name__ == '__main__':
    main()
