param([string]$File)
# KEY QUESTION: which keepalive bytes correlate with POSITION vs with AIM?
# Use ghost/REPLAY markers: find rows where decision or kind indicates REPLAY / ghost state.
# Also examine phase column values. Let's see distinct values of phase/decision/kind/family columns.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapM {
  public static List<string[]> Rows = new List<string[]>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      Rows.Add(p);
    }
  }
}
"@
Add-Type -TypeDefinition $src
[CapM]::Parse($File)
$n = [CapM]::Rows.Count
Write-Host ("rows: " + $n)
$phase=@{}; $dec=@{}; $typ=@{}; $fam=@{}; $kind=@{}
foreach ($r in [CapM]::Rows) {
  if (-not $phase.ContainsKey($r[2])) {$phase[$r[2]]=0}; $phase[$r[2]]++
  if (-not $dec.ContainsKey($r[4])) {$dec[$r[4]]=0}; $dec[$r[4]]++
  if (-not $typ.ContainsKey($r[9])) {$typ[$r[9]]=0}; $typ[$r[9]]++
  if (-not $kind.ContainsKey($r[10])) {$kind[$r[10]]=0}; $kind[$r[10]]++
}
Write-Host "phase values:"; $phase.GetEnumerator() | Sort-Object Value -Descending | ForEach-Object { Write-Host ("  {0}: {1}" -f $_.Key, $_.Value) }
Write-Host "decision values:"; $dec.GetEnumerator() | Sort-Object Value -Descending | ForEach-Object { Write-Host ("  {0}: {1}" -f $_.Key, $_.Value) }
Write-Host "type values:"; $typ.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 12 | ForEach-Object { Write-Host ("  {0}: {1}" -f $_.Key, $_.Value) }
Write-Host "kind values:"; $kind.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 12 | ForEach-Object { Write-Host ("  {0}: {1}" -f $_.Key, $_.Value) }
