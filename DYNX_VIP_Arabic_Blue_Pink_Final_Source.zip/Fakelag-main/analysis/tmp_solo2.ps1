param([string]$Csv)
# Find pairs where ONLY w20 changed (or only w22) - these are likely pure axis movements.
# For solo-w20 pairs: show the 16-bit delta distribution.
$rows = Import-Csv $Csv
function HexToBytes([string]$h) {
  $b = New-Object byte[] ($h.Length/2)
  for ($i=0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($h.Substring(2*$i,2),16) }
  return $b
}
$bytes = New-Object System.Collections.ArrayList
foreach ($r in $rows) { [void]$bytes.Add((HexToBytes $r.hex32)) }

foreach ($target in @(20,22,24)) {
  $dh = @{}
  $n = 0
  for ($i=1; $i -lt $rows.Count; $i++) {
    if ($rows[$i].len -ne $rows[$i-1].len) { continue }
    $a = $bytes[$i-1]; $b = $bytes[$i]
    $changed = @()
    foreach ($w in @(12,14,16,18,20,22,24)) {
      if ($a[$w] -ne $b[$w] -or $a[$w+1] -ne $b[$w+1]) { $changed += $w }
    }
    if ($changed.Count -ne 1 -or $changed[0] -ne $target) { continue }
    $va = $a[$target]+256*$a[$target+1]; $vb = $b[$target]+256*$b[$target+1]
    $d = $vb - $va
    if ($d -gt 32768) { $d -= 65536 }
    if ($d -lt -32768) { $d += 65536 }
    if (-not $dh.ContainsKey($d)) { $dh[$d]=0 }
    $dh[$d]++
    $n++
  }
  Write-Host ("solo-w{0}: n={1} delta histogram: {2}" -f $target, $n, (($dh.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 12 | ForEach-Object { "{0}x{1}" -f $_.Key, $_.Value }) -join ' '))
}

# Also pairs where exactly w20+w24 changed (the correlated pair)
$dh2 = @{}
$n2 = 0
for ($i=1; $i -lt $rows.Count; $i++) {
  if ($rows[$i].len -ne $rows[$i-1].len) { continue }
  $a = $bytes[$i-1]; $b = $bytes[$i]
  $changed = @()
  foreach ($w in @(12,14,16,18,20,22,24)) {
    if ($a[$w] -ne $b[$w] -or $a[$w+1] -ne $b[$w+1]) { $changed += $w }
  }
  if ($changed.Count -ne 2) { continue }
  if (!(($changed[0] -eq 20 -and $changed[1] -eq 24) -or ($changed[0] -eq 24 -and $changed[1] -eq 20))) { continue }
  $va = $a[20]+256*$a[21]; $vb = $b[20]+256*$b[21]
  $d = $vb - $va
  if ($d -gt 32768) { $d -= 65536 }
  if ($d -lt -32768) { $d += 65536 }
  if (-not $dh2.ContainsKey($d)) { $dh2[$d]=0 }
  $dh2[$d]++
  $n2++
}
Write-Host ("w20+w24-only pairs: n={0} w20-delta histogram: {1}" -f $n2, (($dh2.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 12 | ForEach-Object { "{0}x{1}" -f $_.Key, $_.Value }) -join ' '))
