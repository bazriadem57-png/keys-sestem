#!/usr/bin/env python3
"""Where is the zone byte in 14:58 / 15:19 hit packets? Scan ALL positions 2..L-3 raw."""
import sys, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

for name, path in [
    ('14:58', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_145845.txt'),
    ('15:19', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_151920.txt'),
    ('16:10', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_161055.txt'),
]:
    rows = load(path)
    ins = [r for r in rows if r['dir'] == 'IN']
    cand = [r for r in ins if 22 <= r['ln'] <= 26 and r['p'][-2:] == b'\x00\x00' and r['p'][-3] <= 130]
    bylen = collections.Counter(r['ln'] for r in cand)
    L = bylen.most_common(1)[0][0]
    sub = [r for r in cand if r['ln'] == L]
    print(f"\n{name}: dom hit len={L} n={len(sub)}")
    # per-position: fraction of values in {1,2,3,9} and top values, ALL positions
    for i in range(2, L - 2):
        c = collections.Counter(r['p'][i] for r in sub)
        frac = sum(v for k, v in c.items() if k in (1, 2, 3, 9)) / len(sub)
        top = c.most_common(3)
        s = ' '.join(f"{k:02X}:{v}" for k, v in top)
        flag = ' <== ZONE' if frac > 0.4 else ''
        print(f"  pos {i:2d}: zone-frac={frac:4.0%}  top: {s}{flag}")
