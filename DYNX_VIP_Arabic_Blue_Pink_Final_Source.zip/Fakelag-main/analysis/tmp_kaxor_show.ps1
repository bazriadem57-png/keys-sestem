param([string]$File, [int]$Len = 60)
# For keepalive len=X pairs where bytes 12-31 changed in 12 bytes (i.e. ALL of 12-31 region except b0,b1 changed):
# show hex + XOR to inspect structure. Focus on pairs where exactly 12 bytes changed (all of region).
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapI {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapI]::Parse($File)
$n = [CapI]::Ts.Count

$shown = 0
for ($i=1; $i -lt $n -and $shown -lt 12; $i++) {
  if ([CapI]::Lens[$i] -ne $Len -or [CapI]::Lens[$i-1] -ne $Len) { continue }
  $a = [CapI]::ToBytes([CapI]::Hex[$i-1]); $b = [CapI]::ToBytes([CapI]::Hex[$i])
  if ($a.Length -lt 32 -or $b.Length -lt 32) { continue }
  $cnt = 0
  for ($k=12; $k -lt 32; $k++) { if ($a[$k] -ne $b[$k]) { $cnt++ } }
  if ($cnt -lt 11) { continue }
  $x = New-Object System.Text.StringBuilder
  for ($k=0; $k -lt 32; $k++) { [void]$x.Append(('{0:X2}' -f ($a[$k] -bxor $b[$k]))) }
  Write-Host ("A {0}" -f [CapI]::Hex[$i-1].Substring(0,64))
  Write-Host ("B {0}" -f [CapI]::Hex[$i].Substring(0,64))
  Write-Host ("X {0}" -f $x.ToString())
  Write-Host ""
  $shown++
}
