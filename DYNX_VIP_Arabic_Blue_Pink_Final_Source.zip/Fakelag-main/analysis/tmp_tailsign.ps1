param([string]$Csv, [int]$StartRow = 0)
# SIGNED small deltas dominate (2 / 254=-2, 4 / 252=-4...). So tail bytes are SIGNED 8-bit deltas? or parts of 16-bit values.
# Actually a cleaner hypothesis: the tail contains DELTA-ENCODED movement (dx, dy, dz) as signed 8/16-bit values.
# byte pairs (26,27): deltas +2/-2 - a 16-bit value moving by small steps. But byte29 delta 66/194 recurring, byte30 194/66 recurring
# suggests byte29-30 pairs change together by +-66/194 -> maybe a 16-bit value with LE layout changing by 0x42? Hmm 66=0x42, 194=0xC2=-66 signed.
# Let's look at consecutive ACTIVE packets directly (hex + per-byte signed deltas) over a walking window.
$rows = Import-Csv $Csv
function HexToBytes([string]$h) {
  $b = New-Object byte[] ($h.Length/2)
  for ($i=0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($h.Substring(2*$i,2),16) }
  return $b
}
$shown = 0
$prev = $null
for ($i=1; $i -lt $rows.Count -and $shown -lt 25; $i++) {
  $ra = $rows[$i-1]; $rb = $rows[$i]
  if ($ra.len -ne $rb.len) { continue }
  $bb = HexToBytes $rb.hex32
  $nz = 0
  for ($k=26; $k -lt 32; $k++) { if ($bb[$k] -ne 0) { $nz++ } }
  if ($nz -eq 0) { continue }
  $a = HexToBytes $ra.hex32
  # signed per-byte delta string for 22..31
  $ds = ""
  for ($k=22; $k -lt 32; $k++) {
    $d = $bb[$k] - $a[$k]
    if ($d -gt 127) { $d -= 256 }
    $ds += ("{0,4} " -f $d)
  }
  Write-Host ("len={0} {1}" -f $rb.len, $rb.hex32)
  Write-Host ("   signed d[22..31]: {0}" -f $ds)
  $shown++
}
