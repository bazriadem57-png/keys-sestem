#!/usr/bin/env python3
"""Reconstruction experiments R1-R3."""
import sys, os, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def r1_delta_radar(in26):
    """within-entity consecutive deltas: magnitude profile per position."""
    byE = collections.defaultdict(list)
    for r in in26:
        byE[r['p'][0]].append(r)
    big = max(byE.values(), key=len)
    print(f"\n[R1] entity pos0={big[0]['p'][0]:02X} n={len(big)}")
    # delta magnitude: distribution of popcount and value-range of XOR deltas
    for i in range(8, 26):
        deltas = [a['p'][i] ^ b['p'][i] for a, b in zip(big, big[1:])]
        z = sum(1 for d in deltas if d == 0)
        # |delta| as signed-ish magnitude measure: count of bits
        pc = collections.Counter(bin(d).count('1') for d in deltas)
        small = sum(1 for d in deltas if d <= 0x0F or d >= 0xF1)  # near-zero magnitude
        print(f"  pos {i:2d}: zero={100*z/len(deltas):3.0f}%  bits<=2: {100*sum(c for b,c in pc.items() if b<=2)/len(deltas):3.0f}%  |d|<=15: {100*small/len(deltas):3.0f}%")

def r3_mirror(rows):
    """pair OUT/24 with nearest IN/24 within 500ms; XOR at each position."""
    out24 = [r for r in rows if r['dir'] == 'OUT' and r['ln'] == 24]
    in24 = [r for r in rows if r['dir'] == 'IN' and r['ln'] == 24]
    if not out24 or not in24:
        return
    pairs = []
    j = 0
    for o in out24:
        # advance j to first in24 >= o.ts
        while j < len(in24) and in24[j]['ts'] < o['ts']:
            j += 1
        if j < len(in24) and in24[j]['ts'] - o['ts'] <= 500:
            pairs.append((o, in24[j]))
    if len(pairs) < 50:
        print(f"\n[R3] mirror pairs too few: {len(pairs)}")
        return
    print(f"\n[R3] OUT/24 -> IN/24 mirror pairs: {len(pairs)}")
    for i in range(24):
        x = [a['p'][i] ^ b['p'][i] for a, b in pairs]
        z = sum(1 for d in x if d == 0)
        c = collections.Counter(x)
        v, cnt = c.most_common(1)[0]
        print(f"  pos {i:2d}: xor0={100*z/len(x):3.0f}%  mode={v:02X}@{100*cnt/len(x):3.0f}%")
    # sample 3 pairs full hex
    for o, m in pairs[:3]:
        print(f"   OUT {o['p'].hex().upper()}")
        print(f"   IN  {m['p'].hex().upper()}  (dt={m['ts']-o['ts']}ms)")

def r2_reconstruct(in26_1610, ref_mode_1343):
    """XOR 16:10 IN/26 with 13:43-derived key guess at constant positions; show sample decodes."""
    # We only reconstruct positions where reference mode exists
    print("\n[R2] sample IN/26 (16:10) decoded with K[i]=ct_mode_1610[i]^ct_mode_1343[i] (positions 2-9):")
    K = {}
    for i in range(2, 10):
        if i in ref_mode_1343:
            K[i] = ref_mode_1343[i]
    for r in in26_1610[:5]:
        dec = bytes(r['p'][i] ^ K.get(i, 0) for i in range(26))
        print(f"   raw {r['p'].hex().upper()}")
        print(f"   dec {dec.hex().upper()}")

def main():
    for path in sys.argv[1:]:
        rows = load(path)
        name = os.path.basename(path)
        print(f"\n{'='*90}\nFILE: {name} rows={len(rows)}")
        in26 = [r for r in rows if r['dir'] == 'IN' and r['ln'] == 26]
        if len(in26) > 100:
            r1_delta_radar(in26)
        r3_mirror(rows)

if __name__ == '__main__':
    main()
