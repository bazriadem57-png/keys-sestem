param([string]$Csv)
# CRITICAL: the tail "C701 0000 0000 0000" and "B301 C601 1FD4 0300 D7.." - these look like LITTLE-ENDIAN 16-bit values
# where high byte is 0xC7/0xB3/0xBC/0x29 and low byte varies. Actually pattern: byte pairs at 22-23,24-25,26-27,28-29,30-31
# e.g. C701 0000 0000 0000 -> LE values 0x01C7=455, 0, 0, 0
# e.g. B301 C601 1FD4 0300 D7 -> 0x01B3=435, 0x01C6=454, 0xD41F=54303, 0x0003=3
# Interesting: 455 and 454 - nearly equal! Suggests (speed, speed) pairs or (x,y) close together.
# Let's decode all 16-bit LE words from offset 12 to end for active packets and look for correlated pairs.
$rows = Import-Csv $Csv
function HexToBytes([string]$h) {
  $b = New-Object byte[] ($h.Length/2)
  for ($i=0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($h.Substring(2*$i,2),16) }
  return $b
}
$shown = 0
for ($j=0; $j -lt $rows.Count -and $shown -lt 40; $j++) {
  $b = HexToBytes $rows[$j].hex32
  $nz = 0
  for ($k=26; $k -lt 32; $k++) { if ($b[$k] -ne 0) { $nz++ } }
  if ($nz -eq 0) { continue }
  $words = @()
  for ($o=12; $o -le 30; $o+=2) { $words += ($b[$o] + 256*$b[$o+1]) }
  Write-Host ("len={0} w12={1,6} w14={2,6} w16={3,6} w18={4,6} w20={5,6} w22={6,6} w24={7,6} w26={8,6} w28={9,6} w30={10,6}" -f $rows[$j].len, $words[0],$words[1],$words[2],$words[3],$words[4],$words[5],$words[6],$words[7],$words[8],$words[9])
  $shown++
}
