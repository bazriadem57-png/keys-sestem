param([string]$File)
# 24B stream XOR-mask recovery attempt: assume payload = plain XOR mask (constant). Find packets where volatile region is IDENTICAL (same plaintext), diff headers.
# Actually simpler: look for REPEATED full payloads (same 24B hex) -> same plaintext+mask. Then XOR different repeats.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapB {
  public static List<long> Ts = new List<long>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int l;
      if (!int.TryParse(p[8], out l)) continue;
      if (l != 24) continue;
      string raw = p[p.Length-1];
      if (raw.Length != 48) continue;
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Hex.Add(raw);
    }
  }
}
"@
Add-Type -TypeDefinition $src
[CapB]::Parse($File)
$n = [CapB]::Ts.Count
Write-Host ("24B OUT packets: " + $n)

# exact duplicate payloads
$freq = @{}
for ($i=0; $i -lt $n; $i++) { $h = [CapB]::Hex[$i]; if (-not $freq.ContainsKey($h)) { $freq[$h]=0 }; $freq[$h]++ }
$dups = $freq.GetEnumerator() | Where-Object { $_.Value -gt 1 } | Sort-Object Value -Descending
Write-Host ("distinct payloads: {0}; payloads seen >1 times: {1}" -f $freq.Count, @($dups).Count)
foreach ($d in ($dups | Select-Object -First 5)) { Write-Host ("  {0} x{1}" -f $d.Key, $d.Value) }

# session-constant header check: bytes 2-7 across all packets
$h27 = @{}
for ($i=0; $i -lt $n; $i++) { $k = [CapB]::Hex[$i].Substring(4,12); if (-not $h27.ContainsKey($k)) { $h27[$k]=0 }; $h27[$k]++ }
Write-Host "--- header bytes 2-7 value counts:"
$h27.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 10 | ForEach-Object { Write-Host ("  hdr(2-7)=0x{0} count={1}" -f $_.Key, $_.Value) }
