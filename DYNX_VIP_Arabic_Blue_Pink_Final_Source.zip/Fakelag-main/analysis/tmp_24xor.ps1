param([string]$File)
# 24B stream: XOR consecutive payloads and study XOR-diff structure (mask cancels if constant XOR mask)
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapA {
  public static List<long> Ts = new List<long>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int l;
      if (!int.TryParse(p[8], out l)) continue;
      if (l != 24) continue;
      string raw = p[p.Length-1];
      if (raw.Length != 48) continue;
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapA]::Parse($File)
$n = [CapA]::Ts.Count
Write-Host ("24B OUT packets: " + $n)

# XOR of consecutive packets: for each byte, fraction nonzero; and the distribution of nonzero XOR values
$xorHist = New-Object 'System.Collections.Generic.Dictionary[int,System.Collections.Generic.Dictionary[int,int]]'
for ($off=0; $off -lt 24; $off++) { $xorHist[$off] = New-Object 'System.Collections.Generic.Dictionary[int,int]' }
for ($i=1; $i -lt $n; $i++) {
  $a = [CapA]::ToBytes([CapA]::Hex[$i-1]); $b = [CapA]::ToBytes([CapA]::Hex[$i])
  for ($off=0; $off -lt 24; $off++) {
    $x = $a[$off] -bxor $b[$off]
    if ($x -ne 0) {
      if (-not $xorHist[$off].ContainsKey($x)) { $xorHist[$off][$x] = 0 }
      $xorHist[$off][$x]++
    }
  }
}
Write-Host "--- XOR-diff byte value frequency (offset: top values with counts):"
for ($off=0; $off -lt 24; $off++) {
  $top = $xorHist[$off].GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 6
  $s = ($top | ForEach-Object { ("0x{0:X2}x{1}" -f $_.Key, $_.Value) }) -join ' '
  $tot = 0; foreach ($kv in $xorHist[$off].Values) { $tot += 0 }
  $nz = ($xorHist[$off].Values | Measure-Object -Sum).Sum
  Write-Host ("byte {0,2}: nonzero={1,6} distinct={2,3} top: {3}" -f $off, $nz, $xorHist[$off].Count, $s)
}
