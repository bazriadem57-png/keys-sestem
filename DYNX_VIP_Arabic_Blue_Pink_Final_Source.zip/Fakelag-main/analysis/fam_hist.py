#!/usr/bin/env python3
"""Comprehensive per-family positional analysis + cross-family keystream comparison."""
import sys, os, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def fam_hist(pk, label, maxpos=None, topn=2):
    if len(pk) < 20:
        return
    L = maxpos or max(len(r['p']) for r in pk)
    print(f"\n  --- {label}: n={len(pk)} ---")
    for i in range(L):
        c = collections.Counter(r['p'][i] for r in pk if i < len(r['p']))
        tot = sum(c.values())
        tops = c.most_common(topn)
        s = ' | '.join(f"{v:02X}:{100*cnt/tot:.0f}%" for v, cnt in tops)
        print(f"   {i:2d}: {s}  uniq={len(c)}")

def main():
    for path in sys.argv[1:]:
        rows = load(path)
        name = os.path.basename(path)
        ins = [r for r in rows if r['dir'] == 'IN']
        outs = [r for r in rows if r['dir'] == 'OUT']
        print(f"\n{'='*90}\nFILE: {name} rows={len(rows)} IN={len(ins)} OUT={len(outs)}")

        # OUT/24 full histogram
        fam_hist([r for r in outs if r['ln'] == 24], 'OUT/24')
        # IN/24 mirror
        fam_hist([r for r in ins if r['ln'] == 24], 'IN/24')
        # IN/26
        fam_hist([r for r in ins if r['ln'] == 26], 'IN/26')
        # hit family: 22-26B, tail 0000, dmg<=130
        hits = [r for r in ins if 22 <= r['ln'] <= 26 and r['p'][-2:] == b'\x00\x00' and r['p'][-3] <= 130]
        bylen = collections.Counter(h['ln'] for h in hits)
        print(f"\n  hit-family lengths: {bylen.most_common()}")
        for L in sorted(bylen):
            fam_hist([h for h in hits if h['ln'] == L], f'HIT/{L}')

if __name__ == '__main__':
    main()
