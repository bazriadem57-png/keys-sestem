param([string]$File)
# FREEZE phase = ghost active (keepalive replayed). Compare keepalive byte volatility BEFORE vs FREEZE.
# In FREEZE, the keepalive being sent is the SAME saved packet, so OUT keepalives should be identical except b0/b1 (or entirely absent).
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapN {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static List<string> Phase = new List<string>();
  public static List<string> Dec = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len < 45 || len > 64) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw); Phase.Add(p[2]); Dec.Add(p[4]);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapN]::Parse($File)
$n = [CapN]::Ts.Count
Write-Host ("keepalive OUT packets: " + $n)
$ph = @{}
for ($i=0; $i -lt $n; $i++) { if (-not $ph.ContainsKey([CapN]::Phase[$i])) { $ph[[CapN]::Phase[$i]]=0 }; $ph[[CapN]::Phase[$i]]++ }
$ph.GetEnumerator() | ForEach-Object { Write-Host ("  phase {0}: {1}" -f $_.Key, $_.Value) }
$dc = @{}
for ($i=0; $i -lt $n; $i++) { if (-not $dc.ContainsKey([CapN]::Dec[$i])) { $dc[[CapN]::Dec[$i]]=0 }; $dc[[CapN]::Dec[$i]]++ }
$dc.GetEnumerator() | ForEach-Object { Write-Host ("  decision {0}: {1}" -f $_.Key, $_.Value) }

# show timeline: phase transitions
Write-Host "--- phase timeline (keepalive OUT only):"
$cur = [CapN]::Phase[0]; $startTs = [CapN]::Ts[0]; $cnt = 1
for ($i=1; $i -lt $n; $i++) {
  if ([CapN]::Phase[$i] -ne $cur) {
    Write-Host ("  {0} from ts={1} count={2} duration={3}ms" -f $cur, $startTs, $cnt, ([CapN]::Ts[$i]-$startTs))
    $cur = [CapN]::Phase[$i]; $startTs = [CapN]::Ts[$i]; $cnt = 1
  } else { $cnt++ }
}
Write-Host ("  {0} from ts={1} count={2} (end)" -f $cur, $startTs, $cnt)

# Volatility BEFORE vs FREEZE (consecutive same-len, same-phase)
foreach ($phaseName in ('BEFORE','FREEZE')) {
  $chg = New-Object int[] 32; $pairs = 0
  for ($i=1; $i -lt $n; $i++) {
    if ([CapN]::Phase[$i] -ne $phaseName -or [CapN]::Phase[$i-1] -ne $phaseName) { continue }
    if ([CapN]::Lens[$i] -ne [CapN]::Lens[$i-1]) { continue }
    $a = [CapN]::ToBytes([CapN]::Hex[$i-1]); $b = [CapN]::ToBytes([CapN]::Hex[$i])
    $m = [Math]::Min(32, [Math]::Min($a.Length, $b.Length))
    for ($k=0; $k -lt $m; $k++) { if ($a[$k] -ne $b[$k]) { $chg[$k]++ } }
    $pairs++
  }
  $line = ""
  for ($k=0; $k -lt 32; $k++) { $line += ("{0,3} " -f [int](100*$chg[$k]/[Math]::Max(1,$pairs))) }
  Write-Host ("{0} (pairs={1}): {2}" -f $phaseName, $pairs, $line)
}
