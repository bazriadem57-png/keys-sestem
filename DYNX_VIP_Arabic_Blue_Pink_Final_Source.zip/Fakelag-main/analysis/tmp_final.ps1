param([string]$File)
# Final checks:
# A) During FREEZE (ghost on), does the 24B input stream keep changing? (aim channel independent of frozen position)
# B) For HD=0 pairs in 24B, is the WHOLE packet identical (b0/b1 too)?
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapW {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static List<string> Phase = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw); Phase.Add(p[2]);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapW]::Parse($File)
$n = [CapW]::Ts.Count
Write-Host ("OUT rows parsed: " + $n)

# A) 24B stream: volatility by phase
foreach ($ph in @('BEFORE','FREEZE')) {
  $chg = 0; $same = 0
  for ($i=1; $i -lt $n; $i++) {
    if ([CapW]::Lens[$i] -ne 24 -or [CapW]::Lens[$i-1] -ne 24) { continue }
    if ([CapW]::Phase[$i] -ne $ph) { continue }
    $a = [CapW]::ToBytes([CapW]::Hex[$i-1]); $b = [CapW]::ToBytes([CapW]::Hex[$i])
    $diff = $false
    for ($k=8; $k -lt 24; $k++) { if ($a[$k] -ne $b[$k]) { $diff = $true; break } }
    if ($diff) { $chg++ } else { $same++ }
  }
  Write-Host ("24B stream {0}: payload(8-23) changed={1} identical={2}" -f $ph, $chg, $same)
}

# B) 24B HD=0 pairs: whole-packet identity?
$full = 0; $partial = 0
for ($i=1; $i -lt $n; $i++) {
  if ([CapW]::Lens[$i] -ne 24 -or [CapW]::Lens[$i-1] -ne 24) { continue }
  if ([CapW]::Hex[$i] -eq [CapW]::Hex[$i-1]) { $full++ }
  else {
    $a = [CapW]::ToBytes([CapW]::Hex[$i-1]); $b = [CapW]::ToBytes([CapW]::Hex[$i])
    $diff = $false
    for ($k=8; $k -lt 24; $k++) { if ($a[$k] -ne $b[$k]) { $diff = $true; break } }
    if (-not $diff) { $partial++ }
  }
}
Write-Host ("24B consecutive pairs: fully-identical={0} payload-same-but-header-differs={1}" -f $full, $partial)

# C) keepalive during FREEZE: verify payload frozen (ghost replay) but check b0/b1
$kf = 0; $kfSame = 0
for ($i=1; $i -lt $n; $i++) {
  if ([CapW]::Phase[$i] -ne 'FREEZE') { continue }
  $l = [CapW]::Lens[$i]
  if ($l -lt 45 -or $l -gt 64) { continue }
  if ([CapW]::Lens[$i-1] -ne $l) { continue }
  if ([CapW]::Phase[$i-1] -ne 'FREEZE') { continue }
  $kf++
  $a = [CapW]::ToBytes([CapW]::Hex[$i-1]); $b = [CapW]::ToBytes([CapW]::Hex[$i])
  $diff = $false
  for ($k=2; $k -lt [Math]::Min(32,$a.Length); $k++) { if ($a[$k] -ne $b[$k]) { $diff = $true; break } }
  if (-not $diff) { $kfSame++ }
}
Write-Host ("keepalive FREEZE same-len pairs: {0}, payload(b2-31) frozen: {1}" -f $kf, $kfSame)
