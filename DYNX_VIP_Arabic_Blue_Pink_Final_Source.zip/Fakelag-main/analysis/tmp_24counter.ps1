param([string]$File)
# 24B: assume constant XOR mask M. For packets where plaintext likely = "idle input" (no movement/aim),
# volatile bytes are actually the mask-changed ones. Instead: study XOR of packets sharing IDENTICAL volatile region
# => same plaintext => XOR reveals nothing new. Instead study STRUCTURE:
# byte0 XOR-distinct=25 with top values 0x01,0x02,0x0C,0x0E,0x03,0x0F -> small deltas -> byte0 is a COUNTER (seq/ack)!
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapC {
  public static List<long> Ts = new List<long>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int l;
      if (!int.TryParse(p[8], out l)) continue;
      if (l != 24) continue;
      string raw = p[p.Length-1];
      if (raw.Length != 48) continue;
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapC]::Parse($File)
$n = [CapC]::Ts.Count
Write-Host ("24B OUT packets: " + $n)

# byte0 as counter: check if XOR delta == arithmetic delta often (i.e. value increments by 1 with occasional jumps)
$deltas = New-Object System.Collections.Generic.List[int]
$xdeltas = New-Object System.Collections.Generic.List[int]
for ($i=1; $i -lt $n; $i++) {
  $a = [CapC]::ToBytes([CapC]::Hex[$i-1]); $b = [CapC]::ToBytes([CapC]::Hex[$i])
  $d = ($b[0] - $a[0] + 256) % 256
  $x = $a[0] -bxor $b[0]
  $deltas.Add($d); $xdeltas.Add($x)
}
$dh = @{}
foreach ($d in $deltas) { if (-not $dh.ContainsKey($d)) { $dh[$d]=0 }; $dh[$d]++ }
Write-Host "byte0 arithmetic delta (mod 256) counts:"
$dh.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 12 | ForEach-Object { Write-Host ("  +{0}: {1}" -f $_.Key, $_.Value) }

# byte1: XOR top values 0x33,0x60,0x5F,0x4C ... maybe byte0-1 is 16-bit counter. Check 16-bit LE delta.
$d16 = @{}
for ($i=1; $i -lt $n; $i++) {
  $a = [CapC]::ToBytes([CapC]::Hex[$i-1]); $b = [CapC]::ToBytes([CapC]::Hex[$i])
  $va = $a[0] + 256*$a[1]; $vb = $b[0] + 256*$b[1]
  $d = ($vb - $va + 65536) % 65536
  if (-not $d16.ContainsKey($d)) { $d16[$d]=0 }
  $d16[$d]++
}
Write-Host "bytes0-1 16-bit LE delta (mod 65536) top counts:"
$d16.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 12 | ForEach-Object { Write-Host ("  +{0}: {1}" -f $_.Key, $_.Value) }

# Look at time gaps vs byte0 delta correlation: for dt~33ms (30Hz), is byte0 delta constant?
Write-Host "--- sample of (dt, byte0, byte1, 16bitLE) first 30:"
for ($i=0; $i -lt [Math]::Min(30,$n); $i++) {
  $b = [CapC]::ToBytes([CapC]::Hex[$i])
  $v16 = $b[0] + 256*$b[1]
  $dt = if ($i -gt 0) { [CapC]::Ts[$i] - [CapC]::Ts[$i-1] } else { 0 }
  Write-Host ("  dt={0,5} b0={1,3} b1={2,3} v16={3}" -f $dt, $b[0], $b[1], $v16)
}
