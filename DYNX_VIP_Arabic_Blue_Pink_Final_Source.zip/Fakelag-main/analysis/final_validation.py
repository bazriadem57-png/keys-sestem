#!/usr/bin/env python3
"""FINAL VALIDATION SUITE.

Model under test:
  M1: ct[i] = pt[i] ^ K[i], K session-constant (not per-packet).
  M2: K[2..7] = mode of OUT/24 ciphertext at positions 2-7 (OUT/24 pt header = 00 00 00 00 00 00).
  M3: K[i] = 0 for i >= 8 (payload plaintext).
  M4: Same K for both directions and all families.

Validations:
  V1: decode IN/11, IN/12, IN/13, IN/24, IN/26-dom with K -> check pt[3] == len+2 (IN/11-13),
      pt[2..4] == 00 00 00 (IN/24), cross-session pt stability.
  V2: hits: raw tail 00 00 + zone in {1,2,3,9} at some position -> proves K=0 there
      (cross-session: two sessions with different K both show raw 00 00 / small ints).
  V3: single-byte-diff checksum identification on IN/26 (is p8 = f(p9..p25)? which f?).
  V4: per-session IN/26 entity-key position + payload stability profile (layout rotation doc).
"""
import sys, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

SESSIONS = [
    ('13:43', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_134332.txt'),
    ('14:50', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_145006.txt'),
    ('14:58', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_145845.txt'),
    ('15:19', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_151920.txt'),
    ('15:46', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_154602.txt'),
    ('16:10', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_161055.txt'),
]

def main():
    print("="*100)
    print("V1: K = OUT/24 mode[2..7]; decode small inbound families; expect pt[3]=len+2 for IN/11-13")
    print("="*100)
    for name, path in SESSIONS:
        rows = load(path)
        outs = [r for r in rows if r['dir'] == 'OUT']
        ins = [r for r in rows if r['dir'] == 'IN']
        out24 = [r for r in outs if r['ln'] == 24]
        K = {}
        for i in range(2, 8):
            c = collections.Counter(r['p'][i] for r in out24)
            v, cnt = c.most_common(1)[0]
            K[i] = v
        Kstr = ' '.join(f"{K[i]:02X}" for i in range(2, 8))
        print(f"\n{name}: K[2..7] = {Kstr}  (OUT/24 n={len(out24)})")
        for L in (11, 12, 13, 24):
            pk = [r for r in ins if r['ln'] == L]
            if len(pk) < 10:
                continue
            # decoded pt[2..7] mode
            decs = collections.Counter()
            for r in pk:
                d = bytes(r['p'][i] ^ K.get(i, 0) for i in range(2, min(8, L)))
                decs[d] += 1
            top = decs.most_common(2)
            s = ' / '.join(f"{k.hex().upper()}({v})" for k, v in top)
            expect = f"len+2={L+2:02X}" if L in (11, 12, 13) else ""
            print(f"  IN/{L:2d} n={len(pk):4d}: pt[2..7] = {s}   {expect}")
        # IN/26 dominant subtype
        in26 = [r for r in ins if r['ln'] == 26]
        if in26:
            sub = collections.Counter(r['p'][2] for r in in26).most_common(1)[0][0]
            subpk = [r for r in in26 if r['p'][2] == sub]
            decs = collections.Counter()
            for r in subpk:
                d = bytes(r['p'][i] ^ K.get(i, 0) for i in range(2, 8))
                decs[d] += 1
            top = decs.most_common(2)
            s = ' / '.join(f"{k.hex().upper()}({v})" for k, v in top)
            print(f"  IN/26 n={len(in26):4d} (subtype p2={sub:02X}, n={len(subpk)}): pt[2..7] = {s}")

    print()
    print("="*100)
    print("V2: hits — raw (undecoded) tail and zone across sessions (K=0 proof)")
    print("="*100)
    for name, path in SESSIONS:
        rows = load(path)
        ins = [r for r in rows if r['dir'] == 'IN']
        cand = [r for r in ins if 22 <= r['ln'] <= 26 and r['p'][-2:] == b'\x00\x00' and r['p'][-3] <= 130]
        if len(cand) < 20:
            print(f"{name}: too few hit candidates ({len(cand)})")
            continue
        bylen = collections.Counter(r['ln'] for r in cand)
        L = bylen.most_common(1)[0][0]
        sub = [r for r in cand if r['ln'] == L]
        # find zone position: byte in {1,2,3,9} for >=40%
        best = None
        for zp in range(10, L - 2):
            frac = sum(1 for r in sub if r['p'][zp] in (1, 2, 3, 9)) / len(sub)
            if best is None or frac > best[1]:
                best = (zp, frac)
        # raw tail constancy
        tail = collections.Counter(r['p'][-2:] for r in sub).most_common(1)[0]
        # raw pos9/10/13/14 constancy
        consts = {}
        for i in (9, 10, 13, 14):
            c = collections.Counter(r['p'][i] for r in sub)
            v, cnt = c.most_common(1)[0]
            consts[i] = (v, cnt / len(sub))
        cstr = ' '.join(f"p{i}={v:02X}@{sh:.0%}" for i, (v, sh) in consts.items())
        print(f"{name}: hits n={len(cand)} (dom len {L}, n={len(sub)}): zone@{best[0]}={best[1]:.0%} in {{1,2,3,9}}, "
              f"tail={tail[0].hex().upper()}@{tail[1]/len(sub):.0%}, {cstr}")

    print()
    print("="*100)
    print("V3: checksum identification — single-byte-diff pairs in IN/26 (same entity+subtype)")
    print("="*100)
    for name, path in SESSIONS[:3] + SESSIONS[5:]:
        rows = load(path)
        ins = [r for r in rows if r['dir'] == 'IN']
        in26 = [r for r in ins if r['ln'] == 26]
        groups = collections.defaultdict(list)
        for r in in26:
            groups[(r['p'][0], r['p'][2], r['p'][5], r['p'][6])].append(r)
        xor_hits = collections.Counter()
        add_hits = collections.Counter()
        npairs = 0
        for g in groups.values():
            if len(g) < 10:
                continue
            for a, b in zip(g, g[1:]):
                pa, pb = a['p'], b['p']
                diffs = [i for i in range(9, 26) if pa[i] != pb[i]]
                if len(diffs) == 1 and pa[8] != pb[8]:
                    j = diffs[0]
                    npairs += 1
                    if (pa[8] ^ pb[8]) == (pa[j] ^ pb[j]):
                        xor_hits[j] += 1
                    if (pb[8] - pa[8]) & 0xFF == (pb[j] - pa[j]) & 0xFF:
                        add_hits[j] += 1
        print(f"{name}: single-byte-diff pairs with p8 change: {npairs}; XOR-law matches: {sum(xor_hits.values())}, ADD-law matches: {sum(add_hits.values())}")

    print()
    print("="*100)
    print("V4: IN/26 layout profile per session (entity key pos + stable-block location)")
    print("="*100)
    for name, path in SESSIONS:
        rows = load(path)
        ins = [r for r in rows if r['dir'] == 'IN']
        in26 = [r for r in ins if r['ln'] == 26]
        if len(in26) < 200:
            continue
        # find the position whose value-set is small (10-25 uniq) = entity key
        keycand = []
        for i in range(0, 8):
            c = collections.Counter(r['p'][i] for r in in26)
            if 5 <= len(c) <= 30:
                v, cnt = c.most_common(1)[0]
                keycand.append((i, len(c), cnt / len(in26)))
        # dominant subtype consecutive-repeat profile
        sub = collections.Counter((r['p'][2], r['p'][5], r['p'][6]) for r in in26).most_common(1)[0][0]
        g = [r for r in in26 if (r['p'][2], r['p'][5], r['p'][6]) == sub]
        # group by entity key pos0
        byE = collections.defaultdict(list)
        for r in g:
            byE[r['p'][0]].append(r)
        big = max(byE.values(), key=len)
        prof = []
        for i in range(8, 26):
            z = sum(1 for a, b in zip(big, big[1:]) if a['p'][i] == b['p'][i])
            prof.append(int(100 * z / (len(big) - 1)))
        print(f"{name}: entity-key candidates (pos,uniq,share): {keycand}")
        print(f"   dominant subtype n={len(g)}, biggest entity n={len(big)}: consecutive-same% pos8-25:")
        print(f"   {' '.join(map(str, prof))}")

if __name__ == '__main__':
    main()
