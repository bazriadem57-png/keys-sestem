#!/usr/bin/env python3
"""Final multi-session verification suite.

V1: OUT/24 header (pos 2-7) extraction per session + pairwise XOR palindromicity.
V2: hit-family zone readability (is K[17]=0 this session?) + damage readability.
V3: IN/26 within-entity: duplicate payload analysis + small-delta (radar) analysis.
V4: cross-family K sharing test at positions 3,4,7 (IN/26 mode == OUT/24 mode).
"""
import sys, os, collections, itertools

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def out24_header(rows):
    out24 = [r for r in rows if r['dir'] == 'OUT' and r['ln'] == 24]
    if len(out24) < 100:
        return None, len(out24), None
    hdr = []
    uniq = []
    for i in range(2, 8):
        c = collections.Counter(r['p'][i] for r in out24)
        v, cnt = c.most_common(1)[0]
        hdr.append(v)
        uniq.append(len(c))
    return bytes(hdr), len(out24), uniq

def v2_hits(rows):
    ins = [r for r in rows if r['dir'] == 'IN']
    cand = [r for r in ins if 22 <= r['ln'] <= 26 and r['p'][-2:] == b'\x00\x00' and r['p'][-3] <= 130]
    if len(cand) < 20:
        return dict(n=len(cand))
    # zone readability: best position p in 14..20 where ct[p] in {1,2,3,9} for >=70%
    best = None
    for zp in range(14, 21):
        ok = sum(1 for r in cand if r['p'][zp] in (1, 2, 3, 9))
        frac = ok / len(cand)
        if best is None or frac > best[1]:
            best = (zp, frac)
    # damage readability: ct[plen-3] distribution — small values?
    dmgs = collections.Counter(r['p'][-3] for r in cand)
    small = sum(c for v, c in dmgs.items() if v <= 60) / len(cand)
    return dict(n=len(cand), zone_pos=best[0], zone_frac=best[1], dmg_small_frac=small)

def v3_entities(rows):
    ins = [r for r in rows if r['dir'] == 'IN']
    in26 = [r for r in ins if r['ln'] == 26]
    if len(in26) < 200:
        return
    byE = collections.defaultdict(list)
    for r in in26:
        byE[r['p'][0]].append(r)
    groups = [g for g in byE.values() if len(g) >= 100]
    if not groups:
        return
    print(f"    entities>=100pkts: {len(groups)}")
    for g in sorted(groups, key=len, reverse=True)[:3]:
        n = len(g)
        # duplicate payload (pos 9-25) analysis
        seen = collections.Counter(r['p'][9:] for r in g)
        dupes = sum(c - 1 for c in seen.values() if c > 1)
        top_dupe = seen.most_common(1)[0]
        # consecutive-pair changed-byte count among pos 10-25
        chg = collections.Counter()
        for a, b in zip(g, g[1:]):
            c = sum(1 for i in range(10, 26) if a['p'][i] != b['p'][i])
            chg[c] += 1
        few = sum(c for k, c in chg.items() if k <= 2)
        # median inter-packet gap
        gaps = sorted(b['ts'] - a['ts'] for a, b in zip(g, g[1:]))
        print(f"    entity {g[0]['p'][0]:02X} n={n}: dup-payload(9:)={dupes} (top x{top_dupe[1]}), "
              f"pairs<=2chg={100*few/(n-1):.0f}%, medgap={gaps[len(gaps)//2]}ms")
        # pos9-15 stability: fraction of consecutive pairs with identical 9-15
        same915 = sum(1 for a, b in zip(g, g[1:]) if a['p'][9:16] == b['p'][9:16])
        print(f"      pos9-15 identical consecutive: {100*same915/(n-1):.0f}%")

def main():
    files = sys.argv[1:]
    results = {}
    for path in files:
        rows = load(path)
        name = os.path.basename(path).replace('capture_raw_', '').replace('.txt', '')
        hdr, n24, uniq = out24_header(rows)
        print(f"\n=== {name} === OUT/24 n={n24}")
        if hdr:
            print(f"  header[2..7] = {hdr.hex().upper()}  uniq={uniq}")
            results[name] = hdr
        h = v2_hits(rows)
        print(f"  hits: n={h.get('n')}", end='')
        if h.get('n', 0) >= 20:
            print(f"  best-zone-pos={h['zone_pos']} readable={100*h['zone_frac']:.0f}%  dmg<=60: {100*h['dmg_small_frac']:.0f}%", end='')
        print()
        v3_entities(rows)

    # pairwise XOR palindromicity
    print("\n\n[V1] Pairwise header XOR (pos2-7) — palindromic means d[0]=d[5], d[1]=d[4], d[2]=d[3]:")
    keys = list(results)
    for a, b in itertools.combinations(keys, 2):
        d = bytes(x ^ y for x, y in zip(results[a], results[b]))
        pal = (d[0] == d[5] and d[1] == d[4] and d[2] == d[3])
        print(f"  {a} ^ {b} = {d.hex().upper()}  palindrome={pal}")

if __name__ == '__main__':
    main()
