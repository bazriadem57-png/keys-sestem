#!/usr/bin/env python3
"""Cross-family keystream comparison + time stability + known-plaintext tests."""
import sys, os, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def consts(pk, minshare=0.95):
    """positions where a single value dominates -> (pos, val, share)"""
    out = []
    if not pk: return out
    L = max(len(r['p']) for r in pk)
    for i in range(L):
        c = collections.Counter(r['p'][i] for r in pk if i < len(r['p']))
        tot = sum(c.values())
        if tot < len(pk) * 0.5:  # position must exist in most packets
            continue
        v, cnt = c.most_common(1)[0]
        if cnt / tot >= minshare:
            out.append((i, v, cnt / tot))
    return out

def main():
    for path in sys.argv[1:]:
        rows = load(path)
        name = os.path.basename(path)
        ins = [r for r in rows if r['dir'] == 'IN']
        outs = [r for r in rows if r['dir'] == 'OUT']
        print(f"\n{'='*90}\nFILE: {name} rows={len(rows)}")

        fams = {
            'OUT/24': [r for r in outs if r['ln'] == 24],
            'OUT/18': [r for r in outs if r['ln'] == 18],
            'OUT/62-63': [r for r in outs if r['ln'] in (62, 63)],
            'OUT/56-59': [r for r in outs if 56 <= r['ln'] <= 59],
            'IN/26': [r for r in ins if r['ln'] == 26],
            'IN/24': [r for r in ins if r['ln'] == 24],
            'IN/13': [r for r in ins if r['ln'] == 13],
            'IN/12': [r for r in ins if r['ln'] == 12],
            'IN/11': [r for r in ins if r['ln'] == 11],
        }
        print("\n[Constants per family] (pos:val@share) — candidate K[i] if plaintext fixed:")
        for fam, pk in fams.items():
            if len(pk) < 30:
                continue
            cs = consts(pk)
            s = ' '.join(f"{i}:{v:02X}@{sh:.0%}" for i, v, sh in cs)
            print(f"  {fam:10s} n={len(pk):5d}  {s}")

        # time stability: split IN/26 into 4 quartiles, compare constants
        in26 = fams['IN/26']
        if len(in26) > 400:
            print("\n[Time stability of IN/26 constants] (quartile modes at constant positions):")
            q = len(in26) // 4
            base = consts(in26)
            for i, v, sh in base:
                modes = []
                for k in range(4):
                    seg = in26[k*q:(k+1)*q] if k < 3 else in26[3*q:]
                    c = collections.Counter(r['p'][i] for r in seg)
                    mv, mc = c.most_common(1)[0]
                    modes.append(f"{mv:02X}({mc/len(seg):.0%})")
                print(f"  pos {i:2d}: base={v:02X}  quartiles: {' '.join(modes)}")

        # OUT/18 ammo counter: dump bytes 12-15 sequence over time
        out18 = fams['OUT/18']
        if len(out18) > 20:
            print(f"\n[OUT/18] n={len(out18)} first 30 packets, bytes 0-1 and 12-15:")
            for r in out18[:30]:
                p = r['p']
                print(f"  ts={r['ts']} b01={p[0]:02X}{p[1]:02X} b12_15={p[12]:02X} {p[13]:02X} {p[14]:02X} {p[15]:02X}  full={p.hex().upper()}")

        # IN/11,12,13 small packets: dump first 15 full
        for fam in ('IN/11', 'IN/12', 'IN/13'):
            pk = fams[fam]
            if len(pk) > 10:
                print(f"\n[{fam}] first 12 packets full hex:")
                for r in pk[:12]:
                    print(f"  {r['p'].hex().upper()}")

if __name__ == '__main__':
    main()
