#!/usr/bin/env python3
"""Position-recovery experiment: exploit byte-9 timer + known K[2..7] + structural model.

Model of IN/26 subtype S (e.g. p2=CD,p5=A4,p6=CF):
  pos 0: entity ID (session-constant per player)
  pos 1: checksum/seq (uniform)
  pos 2-7: header ^ K[2..7] (known)
  pos 8: uniform (seq? crc8?)
  pos 9: timer low byte (increments 1-2)
  pos 10-17: 8-byte block, 26% consecutive-same
  pos 18-25: 8-byte block, 5% consecutive-same

This script:
 P1: extracts timer high bytes (pos 10 carries the timer high nibble/byte)
 P2: recovers K[8] via majority vote on timer structure (find k8 s.t. many packets have
     low-entropy pattern at pos 8... unlikely; instead recover via byte9)
 P3: tracks per-entity sequences: decode timer fully, and examine pos 10-25 residual
     after removing timer bytes.
"""
import sys, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def main():
    path = sys.argv[1]
    rows = load(path)
    ins = [r for r in rows if r['dir'] == 'IN']
    in26 = [r for r in ins if r['ln'] == 26]
    # dominant subtype
    sub = collections.Counter((r['p'][2], r['p'][5], r['p'][6]) for r in in26)
    (s2, s5, s6), _ = sub.most_common(1)[0]
    g = [r for r in in26 if (r['p'][2], r['p'][5], r['p'][6]) == (s2, s5, s6)]
    print(f"subtype p2={s2:02X} p5={s5:02X} p6={s6:02X}: n={len(g)}")

    # P1: timer structure. pos9 ~ timer low byte; where is high part?
    # Look at per-entity pos9 sequence and pos10
    byE = collections.defaultdict(list)
    for r in g:
        byE[r['p'][0]].append(r)
    e, seq = max(byE.items(), key=lambda kv: len(kv[1]))
    print(f"\nentity {e:02X} n={len(seq)}")
    print("t(ms)   p8 p9 p10 p11 ... p17 | p18..p25")
    for r in seq[:40]:
        p = r['p']
        print(f"  {r['ts']-seq[0]['ts']:6d}  {p[8]:02X} {p[9]:02X} | {' '.join(f'{x:02X}' for x in p[10:18])} | {' '.join(f'{x:02X}' for x in p[18:26])}")

    # P2: check whether p10 upper nibble == p9 upper bits or similar timer-carry relation
    # correlation: p9 values over time vs t
    print("\np9 vs packet-index (first 60):")
    print(' '.join(f"{r['p'][9]:02X}" for r in seq[:60]))
    print("\np8 vs packet-index (first 60):")
    print(' '.join(f"{r['p'][8]:02X}" for r in seq[:60]))
    # p9 delta stats
    d9 = collections.Counter((b['p'][9] - a['p'][9]) & 0xFF for a, b in zip(seq, seq[1:]))
    print(f"\np9 delta distribution: {d9.most_common(8)}")
    # p10 delta stats (raw)
    d10 = collections.Counter((b['p'][10] - a['p'][10]) & 0xFF for a, b in zip(seq, seq[1:]))
    print(f"p10 delta distribution: {d10.most_common(8)}")

if __name__ == '__main__':
    main()
