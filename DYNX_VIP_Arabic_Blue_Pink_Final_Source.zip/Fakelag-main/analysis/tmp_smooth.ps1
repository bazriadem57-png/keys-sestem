param([string]$File)
# FINAL CONFIRMATION for keepalive: reconstruct position trajectory.
# Hypothesis: keepalive bytes 12..25 contain several 16-bit LE fields. Under constant mask they change smoothly.
# Take a long walking run; pick fields w12/w18 (they changed ~30%: maybe coordinates), w20/w22/w24.
# Actually from longrun: w12 rose steadily ~+1050/packet over 26 packets while w18 fell. w12 looks like a TIME/tick counter.
# w26 rose 4097->20481 (steps of 1536, 20481-18945...) hmm not smooth.
# Better: extract FULL hex (not truncated to 32) impossible; but bytes up to 31 available.
# Let's compute for the longrun: cumulative sum of signed byte deltas per byte offset — reconstruct relative trajectories.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapV {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static List<string> Phase = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len < 45 || len > 64) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw); Phase.Add(p[2]);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapV]::Parse($File)
$n = [CapV]::Ts.Count
Write-Host ("keepalive packets: " + $n)

# find all maximal runs of same-len, and within each run compute signed per-byte deltas;
# aggregate: for each offset, fraction of run-pairs where |delta|<=4 (smooth) vs big
$smooth = New-Object int[] 32
$total = New-Object int[] 32
for ($i=1; $i -lt $n; $i++) {
  if ([CapV]::Lens[$i] -ne [CapV]::Lens[$i-1]) { continue }
  $a = [CapV]::ToBytes([CapV]::Hex[$i-1]); $b = [CapV]::ToBytes([CapV]::Hex[$i])
  $m = [Math]::Min(32, [Math]::Min($a.Length, $b.Length))
  for ($k=12; $k -lt $m; $k++) {
    $d = $b[$k] - $a[$k]
    if ($d -gt 127) { $d -= 256 }
    $total[$k]++
    if ([Math]::Abs($d) -le 4) { $smooth[$k]++ }
  }
}
Write-Host "fraction of same-len pairs with |signed byte delta| <= 4 (per offset 12..31):"
for ($k=12; $k -lt 32; $k++) { Write-Host ("  byte {0,2}: {1,5}/{2,5} = {3,5:P1}" -f $k, $smooth[$k], $total[$k], ($smooth[$k]/[Math]::Max(1,$total[$k]))) }
