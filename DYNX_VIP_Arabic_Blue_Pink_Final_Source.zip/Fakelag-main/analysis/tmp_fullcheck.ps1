param([string]$File, [int]$LenMin = 45, [int]$LenMax = 64)
# Full-hex keepalive analysis: find packets whose hex is COMPLETE (hexlen == len*2 after trimming dots won't happen; check raw)
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class Cap7 {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static List<bool> Full = new List<bool>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len < 45 || len > 64) continue;
      string raw = p[p.Length-1];
      bool full = !raw.EndsWith("..") && raw.Length == len*2;
      string hex = raw.TrimEnd('.');
      bool ok = true;
      foreach (char c in hex) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(hex); Full.Add(full);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[Cap7]::Parse($File)
$n = [Cap7]::Ts.Count
$fullCount = 0
for ($i=0; $i -lt $n; $i++) { if ([Cap7]::Full[$i]) { $fullCount++ } }
Write-Host ("keepalive rows: {0}, full-hex: {1}" -f $n, $fullCount)

# Count how many capture rows have payload longer than 64 chars (i.e., >32 bytes)
$long = 0
for ($i=0; $i -lt $n; $i++) { if ([Cap7]::Hex[$i].Length -gt 64) { $long++ } }
Write-Host ("rows with >32 bytes of hex: " + $long)

# Distribution of hex lengths
$hlen = @{}
for ($i=0; $i -lt $n; $i++) { $k = [Cap7]::Hex[$i].Length; if (-not $hlen.ContainsKey($k)) { $hlen[$k]=0 }; $hlen[$k]++ }
foreach ($k in ($hlen.Keys | Sort-Object)) { Write-Host ("hexlen={0} count={1}" -f $k, $hlen[$k]) }
