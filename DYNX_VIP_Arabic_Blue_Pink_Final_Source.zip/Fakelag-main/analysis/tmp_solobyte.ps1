param([string]$Csv)
# VERY revealing: solo-w20 deltas are +/-512 (=0x0200), i.e. byte21 changes by 2 while byte20 unchanged.
# solo-w24 deltas are +/-2 or +/-1 (low byte only).
# So there are (at least) two fields: one stepping by ~2 in LOW byte (w24), one stepping by 2 in HIGH byte (w20).
# If mask byte at 21 is 0 and at 20 is something... hmm. OR: the fields overlap differently:
# maybe the actual fields are at offsets 20-21 and 24-25 as 16-bit with different scales.
# w20 stepping by 512 = high byte +-2: if the field were 24-25 style (low-byte steps), then w20's true steps are 512 units.
# Alternatively there is a 4-byte field at 20..23 (32-bit) and another at 24..27.
# Check 32-bit LE values at 20 and 24:
$rows = Import-Csv $Csv
function HexToBytes([string]$h) {
  $b = New-Object byte[] ($h.Length/2)
  for ($i=0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($h.Substring(2*$i,2),16) }
  return $b
}
$bytes = New-Object System.Collections.ArrayList
foreach ($r in $rows) { [void]$bytes.Add((HexToBytes $r.hex32)) }

# solo-change detection at BYTE level: which single bytes change alone?
$soloByte = @{}
for ($i=1; $i -lt $rows.Count; $i++) {
  if ($rows[$i].len -ne $rows[$i-1].len) { continue }
  $a = $bytes[$i-1]; $b = $bytes[$i]
  $changed = @()
  for ($k=12; $k -lt 32; $k++) { if ($a[$k] -ne $b[$k]) { $changed += $k } }
  if ($changed.Count -eq 1) {
    $k = $changed[0]
    if (-not $soloByte.ContainsKey($k)) { $soloByte[$k]=0 }
    $soloByte[$k]++
  }
}
Write-Host "single-byte-only changes by offset:"
foreach ($k in ($soloByte.Keys | Sort-Object)) { Write-Host ("  byte {0}: {1}" -f $k, $soloByte[$k]) }

# Show byte-level signed delta histogram for solo changes at the top offsets
foreach ($k in ($soloByte.Keys | Sort-Object)) {
  if ($soloByte[$k] -lt 5) { continue }
  $dh = @{}
  for ($i=1; $i -lt $rows.Count; $i++) {
    if ($rows[$i].len -ne $rows[$i-1].len) { continue }
    $a = $bytes[$i-1]; $b = $bytes[$i]
    $changed = @()
    for ($q=12; $q -lt 32; $q++) { if ($a[$q] -ne $b[$q]) { $changed += $q } }
    if ($changed.Count -eq 1 -and $changed[0] -eq $k) {
      $d = $b[$k] - $a[$k]
      if ($d -gt 127) { $d -= 256 }
      if (-not $dh.ContainsKey($d)) { $dh[$d]=0 }
      $dh[$d]++
    }
  }
  Write-Host ("byte {0} solo deltas: {1}" -f $k, (($dh.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 8 | ForEach-Object { "{0}x{1}" -f $_.Key, $_.Value }) -join ' '))
}
