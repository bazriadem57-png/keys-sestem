param([string]$File, [int]$Len = 60, [int]$Take = 400)
# Within a single keepalive header-group (same len), XOR consecutive payloads and analyze the XOR-diff byte statistics.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapF {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapF]::Parse($File)
$n = [CapF]::Ts.Count

# consecutive same-len pairs only; XOR stats per byte offset
$xorCnt = @{}    # off -> total nonzero
$xorVals = @{}   # off -> hashtable val->count
$pairTot = 0
for ($i=1; $i -lt $n; $i++) {
  if ([CapF]::Lens[$i] -ne $Len -or [CapF]::Lens[$i-1] -ne $Len) { continue }
  $a = [CapF]::ToBytes([CapF]::Hex[$i-1]); $b = [CapF]::ToBytes([CapF]::Hex[$i])
  $m = [Math]::Min($a.Length, $b.Length)
  $pairTot++
  for ($off=0; $off -lt $m; $off++) {
    $x = $a[$off] -bxor $b[$off]
    if ($x -ne 0) {
      if (-not $xorCnt.ContainsKey($off)) { $xorCnt[$off]=0; $xorVals[$off]=@{} }
      $xorCnt[$off]++
      if (-not $xorVals[$off].ContainsKey($x)) { $xorVals[$off][$x]=0 }
      $xorVals[$off][$x]++
    }
  }
}
Write-Host ("len={0} consecutive pairs: {1}" -f $Len, $pairTot)
for ($off=0; $off -lt [Math]::Min(32,$Len); $off++) {
  if (-not $xorCnt.ContainsKey($off)) { Write-Host ("byte {0,2}: never changes" -f $off); continue }
  $top = $xorVals[$off].GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 5
  $s = ($top | ForEach-Object { "0x{0:X2}x{1}" -f $_.Key, $_.Value }) -join ' '
  Write-Host ("byte {0,2}: changed {1,4}/{2} ({3,3}%) distinct={4,3} top: {5}" -f $off, $xorCnt[$off], $pairTot, [int](100*$xorCnt[$off]/[double]$pairTot), $xorVals[$off].Count, $s)
}
