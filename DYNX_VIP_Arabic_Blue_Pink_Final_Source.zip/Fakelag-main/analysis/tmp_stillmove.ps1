param([string]$File, [int]$Len = 60, [int]$MaxRuns = 6)
# Keepalive: split each header-group into temporal runs; classify runs STILL (whole run identical except b0/b1)
# vs MOVING (other bytes change). Then aggregate STILL vs MOVING volatility per offset (only runs of >=8 packets).
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapH {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      string raw = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapH]::Parse($File)
$n = [CapH]::Ts.Count
Write-Host ("rows: " + $n)

# runs of consecutive (in time, same len) keepalive packets
$runs = New-Object System.Collections.Generic.List[object]
$start = 0
for ($i=1; $i -le $n; $i++) {
  $brk = ($i -eq $n) -or ([CapH]::Lens[$i] -ne [CapH]::Lens[$i-1])
  if ($brk) {
    $len = $i - $start
    if ($len -ge 8) {
      $arr = New-Object int[] $len
      for ($j=0; $j -lt $len; $j++) { $arr[$j] = $start + $j }
      $runs.Add($arr)
    }
    $start = $i
  }
}
Write-Host ("runs>=8 same-len keepalives: " + $runs.Count)

$stillRuns = New-Object System.Collections.Generic.List[object]
$moveRuns = New-Object System.Collections.Generic.List[object]
foreach ($run in $runs) {
  # check if all bytes 2..end identical across run
  $still = $true
  $first = [CapH]::ToBytes([CapH]::Hex[$run[0]])
  foreach ($i in $run) {
    $b = [CapH]::ToBytes([CapH]::Hex[$i])
    for ($k=2; $k -lt [Math]::Min(32,$first.Length); $k++) { if ($b[$k] -ne $first[$k]) { $still = $false; break } }
    if (-not $still) { break }
  }
  if ($still) { $stillRuns.Add($run) } else { $moveRuns.Add($run) }
}
Write-Host ("STILL runs (bytes2-31 frozen): " + $stillRuns.Count + "   MOVING runs: " + $moveRuns.Count)

function ShowVol($runList, $label) {
  $chg = New-Object int[] 32; $pairs = 0
  foreach ($run in $runList) {
    for ($j=1; $j -lt $run.Count; $j++) {
      $a = [CapH]::ToBytes([CapH]::Hex[$run[$j-1]]); $b = [CapH]::ToBytes([CapH]::Hex[$run[$j]])
      $m = [Math]::Min(32, [Math]::Min($a.Length, $b.Length))
      for ($k=0; $k -lt $m; $k++) { if ($a[$k] -ne $b[$k]) { $chg[$k]++ } }
      $pairs++
    }
  }
  $line = ""
  for ($k=0; $k -lt 32; $k++) { $line += ("{0,3} " -f [int](100*$chg[$k]/[Math]::Max(1,$pairs))) }
  Write-Host ("{0} (pairs={1}): {2}" -f $label, $pairs, $line)
}
ShowVol $stillRuns "STILL  "
ShowVol $moveRuns  "MOVING "

# total packets in each class
$sp=0; foreach($r in $stillRuns){$sp+=$r.Count}; $mp=0; foreach($r in $moveRuns){$mp+=$r.Count}
Write-Host ("STILL packets: {0}  MOVING packets: {1}" -f $sp, $mp)

# Stillness analysis within MOVING runs: per-pair, compute number of changed bytes among 12-31; show time histogram
Write-Host "--- within MOVING runs, distribution of changed-byte-count (bytes 12-31) per consecutive pair:"
$hist = @{}
foreach ($run in $moveRuns) {
  for ($j=1; $j -lt $run.Count; $j++) {
    $a = [CapH]::ToBytes([CapH]::Hex[$run[$j-1]]); $b = [CapH]::ToBytes([CapH]::Hex[$run[$j]])
    $cnt = 0
    for ($k=12; $k -lt [Math]::Min(32, $a.Length); $k++) { if ($a[$k] -ne $b[$k]) { $cnt++ } }
    if (-not $hist.ContainsKey($cnt)) { $hist[$cnt]=0 }
    $hist[$cnt]++
  }
}
foreach ($k in ($hist.Keys | Sort-Object)) { Write-Host ("  changed {0,2} bytes: {1,5}" -f $k, $hist[$k]) }
