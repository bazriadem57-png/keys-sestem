param([string]$Csv)
# The "active" detection via nonzero tail was wrong for idle-but-nonzero tails. w30=48128 etc are junk from mask on zero bytes.
# Better activity signal: keepalive bytes 12-21 region changing. Let's define ACTIVE = any byte in 12..25 changed vs previous packet (same len).
# Then dump word values for the longest ACTIVE run.
$rows = Import-Csv $Csv
function HexToBytes([string]$h) {
  $b = New-Object byte[] ($h.Length/2)
  for ($i=0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($h.Substring(2*$i,2),16) }
  return $b
}
$bytes = New-Object System.Collections.ArrayList
foreach ($r in $rows) { [void]$bytes.Add((HexToBytes $r.hex32)) }
# active flags
$act = New-Object bool[] $rows.Count
for ($i=1; $i -lt $rows.Count; $i++) {
  if ($rows[$i].len -ne $rows[$i-1].len) { $act[$i] = $false; continue }
  $a = $bytes[$i-1]; $b = $bytes[$i]
  $ch = $false
  for ($k=12; $k -lt 26; $k++) { if ($a[$k] -ne $b[$k]) { $ch = $true; break } }
  $act[$i] = $ch
}
# longest run of consecutive same-len + act[i] true (include the anchor i-1)
$bestStart = -1; $bestLen = 0
$curStart = -1; $curLen = 0
for ($i=1; $i -lt $rows.Count; $i++) {
  if ($rows[$i].len -eq $rows[$i-1].len -and $act[$i]) {
    if ($curStart -lt 0) { $curStart = $i-1; $curLen = 2 } else { $curLen++ }
  } else {
    if ($curLen -gt $bestLen) { $bestLen = $curLen; $bestStart = $curStart }
    $curStart = -1; $curLen = 0
  }
}
if ($curLen -gt $bestLen) { $bestLen = $curLen; $bestStart = $curStart }
Write-Host ("longest same-len changing run: start={0} len={1}" -f $bestStart, $bestLen)
for ($i=$bestStart; $i -lt ($bestStart + [Math]::Min($bestLen, 40)); $i++) {
  $b = $bytes[$i]
  $w12=$b[12]+256*$b[13]; $w14=$b[14]+256*$b[15]; $w16=$b[16]+256*$b[17]; $w18=$b[18]+256*$b[19]; $w20=$b[20]+256*$b[21]; $w22=$b[22]+256*$b[23]; $w24=$b[24]+256*$b[25]; $w26=$b[26]+256*$b[27]; $w28=$b[28]+256*$b[29]; $w30=$b[30]+256*$b[31]
  Write-Host ("ts={0} L{1} w12={2,6} w14={3,6} w16={4,6} w18={5,6} w20={6,6} w22={7,6} w24={8,6} w26={9,6} w28={10,6} w30={11,6}" -f $rows[$i].ts, $rows[$i].len, $w12,$w14,$w16,$w18,$w20,$w22,$w24,$w26,$w28,$w30)
}
