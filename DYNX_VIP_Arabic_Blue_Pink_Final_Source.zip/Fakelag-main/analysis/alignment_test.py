#!/usr/bin/env python3
"""Resolve the K-alignment ambiguity: for the 3 'odd' sessions, test rotated/permuted K
on inbound families. Also single-byte-K model test (M-B) for completeness."""
import sys, collections

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

SESSIONS = [
    ('13:43', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_134332.txt'),
    ('14:50', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_145006.txt'),
    ('14:58', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_145845.txt'),
    ('15:19', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_151920.txt'),
    ('15:46', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_154602.txt'),
    ('16:10', r'C:\Users\Tonyt\Documents\GitHub\Fakelag\captures\phone_pull5\capture_raw_20260907_161055.txt'),
]

# known-clean inbound plaintext headers (from sessions where OUT-derived K decoded cleanly)
KNOWN = {
    '00 15 00 01 00 01', '00 13 00 D2 07 01', '00 14 00 D2 07 01',
    '00 05 00 6E 07 00',  # IN/26 subtype header pt
    '00 00 00 00 00 00',
}

def main():
    for name, path in SESSIONS:
        rows = load(path)
        ins = [r for r in rows if r['dir'] == 'IN']
        outs = [r for r in rows if r['dir'] == 'OUT']
        out24 = [r for r in outs if r['ln'] == 24]
        K0 = [collections.Counter(r['p'][i] for r in out24).most_common(1)[0][0] for i in range(2, 8)]
        in13 = [r for r in ins if r['ln'] == 13]
        in26 = [r for r in ins if r['ln'] == 26]
        sub26 = collections.Counter(r['p'][2] for r in in26).most_common(1)[0][0] if in26 else None
        g26 = [r for r in in26 if r['p'][2] == sub26] if sub26 is not None else []

        print(f"\n=== {name} === OUT-K[2..7] = {' '.join(f'{x:02X}' for x in K0)}")
        if not in13:
            print("  no IN/13")
            continue
        ct13 = [collections.Counter(r['p'][i] for r in in13).most_common(1)[0][0] for i in range(2, 8)]
        print(f"  IN/13 ct[2..7] = {' '.join(f'{x:02X}' for x in ct13)}")

        # try K variants: identity, rotations, and byte-reversal
        def rot(k, r):
            return [k[(i + r) % 6] for i in range(6)]
        best = None
        for r in range(-3, 4):
            Kv = rot(K0, r)
            pt = [ct13[i] ^ Kv[i] for i in range(6)]
            tag = ' '.join(f'{x:02X}' for x in pt)
            clean = tag in KNOWN or (pt[0] == 0 and pt[2] == 0 and pt[4] in (0, 7) )
            print(f"   rot{r:+d}: pt13 = {tag}  {'<== CLEAN' if tag in KNOWN else ''}")
        # also single-byte model: s = K0[2] etc
        for s in set(K0):
            pt = [ct13[i] ^ s for i in range(6)]
            print(f"   single-byte s={s:02X}: pt13 = {' '.join(f'{x:02X}' for x in pt)}")

        # IN/26 subtype header under OUT-K
        if g26:
            ct26 = [collections.Counter(r['p'][i] for r in g26).most_common(1)[0][0] for i in range(2, 8)]
            pt26 = [ct26[i] ^ K0[i] for i in range(6)]
            print(f"  IN/26 ct[2..7] = {' '.join(f'{x:02X}' for x in ct26)}  pt(OUT-K) = {' '.join(f'{x:02X}' for x in pt26)}")
            # pt under single-byte
            for s in set(K0):
                pt = [ct26[i] ^ s for i in range(6)]
                print(f"    single-byte s={s:02X}: pt26 = {' '.join(f'{x:02X}' for x in pt)}")

if __name__ == '__main__':
    main()
