param([string]$File, [int]$Sample = 300000)
# Re-examine: maybe the 24B volatile region is encrypted with a STREAM cipher (changes every packet),
# or it's compressed/bit-packed input. Check autocorrelation: for pairs with dt small (same 30Hz tick?),
# and look at RAW pairwise equal bytes fraction vs Hamming distance distribution.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapT {
  public static List<long> Ts = new List<long>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len != 24) continue;
      string raw = p[p.Length-1];
      if (raw.Length != 48) continue;
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapT]::Parse($File)
$n = [CapT]::Ts.Count
Write-Host ("24B OUT packets: " + $n)
$bytes = New-Object System.Collections.ArrayList
foreach ($i in 0..($n-1)) { [void]$bytes.Add([CapT]::ToBytes([CapT]::Hex[$i])) }

# Hamming distance (bits) between consecutive packets over bytes 8-23
$hd = New-Object System.Collections.Generic.List[int]
for ($i=1; $i -lt [Math]::Min($Sample, $n); $i++) {
  $a = $bytes[$i-1]; $b = $bytes[$i]
  $bits = 0
  for ($k=8; $k -lt 24; $k++) {
    $x = $a[$k] -bxor $b[$k]
    while ($x -ne 0) { $bits += ($x -band 1); $x = $x -shr 1 }
  }
  $hd.Add($bits)
}
$hist = @{}
foreach ($d in $hd) { if (-not $hist.ContainsKey($d)) { $hist[$d]=0 }; $hist[$d]++ }
Write-Host "Hamming-bit distance (bytes 8-23, 128 bits max) distribution:"
foreach ($k in ($hist.Keys | Sort-Object)) { Write-Host ("  {0,3} bits: {1}" -f $k, $hist[$k]) }
$mean = ($hd | Measure-Object -Average).Average
Write-Host ("mean HD = {0:N1} bits of 128 (random would be 64)" -f $mean)
