param([string]$File)
# 24B stream: check per-byte value distributions in bytes 8-23. If XOR mask is constant and plaintext is mostly-zero
# for idle input, the mode of each byte = mask byte. Then plaintext = value XOR mode. Check bimodality.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class CapS {
  public static List<long> Ts = new List<long>();
  public static List<string> Hex = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len != 24) continue;
      string raw = p[p.Length-1];
      if (raw.Length != 48) continue;
      bool ok = true;
      foreach (char c in raw) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Hex.Add(raw);
    }
  }
  public static byte[] ToBytes(string h) {
    byte[] b = new byte[h.Length/2];
    for (int i=0;i<b.Length;i++) b[i]=Convert.ToByte(h.Substring(2*i,2),16);
    return b;
  }
}
"@
Add-Type -TypeDefinition $src
[CapS]::Parse($File)
$n = [CapS]::Ts.Count
Write-Host ("24B OUT packets: " + $n)
$bytes = New-Object System.Collections.ArrayList
foreach ($i in 0..($n-1)) { [void]$bytes.Add([CapS]::ToBytes([CapS]::Hex[$i])) }

# per-byte histograms for offsets 8..23: find mode (most common value) and its frequency
for ($k=8; $k -lt 24; $k++) {
  $hh = @{}
  for ($i=0; $i -lt $n; $i++) {
    $v = $bytes[$i][$k]
    if (-not $hh.ContainsKey($v)) { $hh[$v]=0 }
    $hh[$v]++
  }
  $top = $hh.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 3
  $s = ($top | ForEach-Object { "0x{0:X2}({1:P1})" -f $_.Key, ($_.Value/[double]$n) }) -join ' '
  Write-Host ("byte {0,2}: distinct={1,3} top: {2}" -f $k, $hh.Count, $s)
}
