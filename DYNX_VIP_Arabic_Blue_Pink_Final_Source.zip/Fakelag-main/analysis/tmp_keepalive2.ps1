param([string]$File, [int]$MinLen = 45, [int]$MaxLen = 64)
# Keepalive analysis using FIRST 32 HEX CHARS (hexLimit=32) so truncated rows are still usable for header analysis,
# but full-hex rows are used when available. For deep byte analysis we only use full rows.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class Cap4 {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();   // may be truncated
  public static List<bool> Full = new List<bool>();
  public static List<string> Dir = new List<string>();
  public static List<string> Typ = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      string hex = p[p.Length-1];
      hex = hex.TrimEnd('.');
      bool full = (hex.Length == len*2);
      bool ok = true;
      foreach (char c in hex) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      if (hex.Length < 2) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(hex); Full.Add(full); Dir.Add(p[3]); Typ.Add(p[9]);
    }
  }
}
"@
Add-Type -TypeDefinition $src
[Cap4]::Parse($File)
$n = [Cap4]::Ts.Count
Write-Host ("parsed rows: {0}" -f $n)

# histogram of lengths 45-64 regardless of fullness
$lenHist = @{}
for ($i=0; $i -lt $n; $i++) {
  if ([Cap4]::Dir[$i] -ne 'OUT') { continue }
  $l = [Cap4]::Lens[$i]
  if ($l -lt $MinLen -or $l -gt $MaxLen) { continue }
  if (-not $lenHist.ContainsKey($l)) { $lenHist[$l] = @() }
  $lenHist[$l] += $i
}
Write-Host "--- OUT lengths in [$MinLen, $MaxLen] (all rows incl. truncated):"
foreach ($k in ($lenHist.Keys | Sort-Object)) { Write-Host ("len={0} count={1} full={2}" -f $k, $lenHist[$k].Count, (@($lenHist[$k] | Where-Object { [Cap4]::Full[$_] })).Count) }

# Global keepalive stream: ALL OUT packets 45-64B sorted by time, truncated rows included (header only)
$all = New-Object System.Collections.Generic.List[int]
for ($i=0; $i -lt $n; $i++) {
  if ([Cap4]::Dir[$i] -eq 'OUT') { $l = [Cap4]::Lens[$i]; if ($l -ge $MinLen -and $l -le $MaxLen) { $all.Add($i) } }
}
Write-Host ("`ntotal keepalive-range packets: {0}" -f $all.Count)
$dts = New-Object System.Collections.Generic.List[double]
for ($j=1; $j -lt $all.Count; $j++) { $dts.Add([Cap4]::Ts[$all[$j]] - [Cap4]::Ts[$all[$j-1]]) }
$srt = $dts | Sort-Object
Write-Host ("cadence: median={0}ms mean={1:N1}ms" -f $srt[[int]($srt.Count/2)], ($dts | Measure-Object -Average).Average)

# The per-length analysis with full rows
foreach ($L in ($lenHist.Keys | Sort-Object)) {
  $fullIdx = @($lenHist[$L] | Where-Object { [Cap4]::Full[$_] })
  if ($fullIdx.Count -lt 50) { Write-Host ("`n=== len={0} (full rows only {1} - too few for volatility)" -f $L, $fullIdx.Count); continue }
  $chg = New-Object double[] $L
  $pairs = $fullIdx.Count - 1
  for ($j=1; $j -lt $fullIdx.Count; $j++) {
    $a = [Cap4]::Hex[$fullIdx[$j-1]]; $b = [Cap4]::Hex[$fullIdx[$j]]
    for ($k=0; $k -lt $L; $k++) {
      if ($a[2*$k] -ne $b[2*$k] -or $a[2*$k+1] -ne $b[2*$k+1]) { $chg[$k]++ }
    }
  }
  $d2 = New-Object System.Collections.Generic.List[double]
  for ($j=1; $j -lt $fullIdx.Count; $j++) { $d2.Add([Cap4]::Ts[$fullIdx[$j]] - [Cap4]::Ts[$fullIdx[$j-1]]) }
  $s2 = $d2 | Sort-Object
  Write-Host ("`n=== len={0} fullrows={1} median_dt={2}ms" -f $L, $fullIdx.Count, $s2[[int]($s2.Count/2)])
  $line = ""
  for ($k=0; $k -lt $L; $k++) { $line += ("{0,3} " -f [int](100*$chg[$k]/[Math]::Max(1,$pairs))) }
  Write-Host ("change%: " + $line)
}
