param([string]$File, [string]$OutCsv)
# Fast C#-style parse with compiled inline C# for speed.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class Cap {
  public static List<int[]> Seqs = new List<int[]>();
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static List<string> Dir = new List<string>();
  public static List<string> Kind = new List<string>();
  public static List<string> Fam = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      // cols: seq ts phase dir decision dip sp dp len type family kind payload_hex
      int len;
      if (!int.TryParse(p[9], out len)) continue;
      string hex = p[11];
      if (hex.Length != len * 2) continue;
      bool ok = true;
      foreach (char c in hex) { if (!Uri.IsHexDigit(c)) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Seqs.Add(new[]{int.Parse(p[0])});
      Ts.Add(ts); Lens.Add(len); Hex.Add(hex); Dir.Add(p[3]); Kind.Add(p[10]); Fam.Add(p[9 - 1]);
    }
  }
}
"@
Add-Type -TypeDefinition $src
[Cap]::Parse($File)
Write-Host ("usable rows: {0}" -f [Cap]::Seqs.Count)
$byLen = @{}
for ($i=0; $i -lt [Cap]::Seqs.Count; $i++) {
  if ([Cap]::Dir[$i] -ne 'OUT') { continue }
  $l = [Cap]::Lens[$i]
  if (-not $byLen.ContainsKey($l)) { $byLen[$l] = 0 }
  $byLen[$l]++
}
foreach ($k in ($byLen.Keys | Sort-Object)) { Write-Host ("len={0} count={1}" -f $k, $byLen[$k]) }
