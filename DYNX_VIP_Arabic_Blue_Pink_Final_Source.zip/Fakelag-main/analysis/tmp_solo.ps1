param([string]$Csv)
# IDLE keepalives: everything frozen except b0/b1 (counter). So the ENTIRE 45-64B keepalive carries position-ish state that
# only changes when the player moves. When still -> fully frozen. This IS the position channel.
# Now: extract the CHANGING region (bytes 12-25) across movement windows and try to find coordinate structure.
# Approach: pick windows where exactly one 16-bit word changes monotonically (player walking in a straight line).
$rows = Import-Csv $Csv
function HexToBytes([string]$h) {
  $b = New-Object byte[] ($h.Length/2)
  for ($i=0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($h.Substring(2*$i,2),16) }
  return $b
}
$bytes = New-Object System.Collections.ArrayList
foreach ($r in $rows) { [void]$bytes.Add((HexToBytes $r.hex32)) }

# For each pair (same len), list which of words w12,w14,w16,w18,w20,w22,w24 changed
$chgCount = @{}
foreach ($w in @(12,14,16,18,20,22,24)) { $chgCount[$w] = 0 }
$pairs = 0
$solo = @{}
foreach ($w in @(12,14,16,18,20,22,24)) { $solo[$w] = 0 }
for ($i=1; $i -lt $rows.Count; $i++) {
  if ($rows[$i].len -ne $rows[$i-1].len) { continue }
  $a = $bytes[$i-1]; $b = $bytes[$i]
  $changed = @()
  foreach ($w in @(12,14,16,18,20,22,24)) {
    if ($a[$w] -ne $b[$w] -or $a[$w+1] -ne $b[$w+1]) { $changed += $w }
  }
  $pairs++
  foreach ($w in $changed) { $chgCount[$w]++ }
  if ($changed.Count -eq 1) { $solo[$changed[0]]++ }
}
Write-Host ("pairs={0}" -f $pairs)
foreach ($w in @(12,14,16,18,20,22,24)) { Write-Host ("w{0}: changed {1} ({2:P0}) solo {3}" -f $w, $chgCount[$w], ($chgCount[$w]/[double]$pairs), $solo[$w]) }
