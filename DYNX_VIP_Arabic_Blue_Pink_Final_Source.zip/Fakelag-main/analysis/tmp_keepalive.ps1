param([string]$File, [int]$MinLen = 45, [int]$MaxLen = 64)
# Analyze the keepalive family (OUT 45-64B at ~100ms). Identify R vs S families and per-byte volatility.
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class Cap3 {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static List<string> Dir = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      string hex = p[p.Length-1];
      if (hex.Length != len * 2) continue;
      bool ok = true;
      foreach (char c in hex) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(hex); Dir.Add(p[3]);
    }
  }
}
"@
Add-Type -TypeDefinition $src
[Cap3]::Parse($File)
$n = [Cap3]::Ts.Count

# Build histogram of RAW byte2 (obfuscated) values for keepalive len range, to see which lens are keepalive
$lenHist = @{}
for ($i=0; $i -lt $n; $i++) {
  if ([Cap3]::Dir[$i] -ne 'OUT') { continue }
  $l = [Cap3]::Lens[$i]
  if ($l -lt $MinLen -or $l -gt $MaxLen) { continue }
  if (-not $lenHist.ContainsKey($l)) { $lenHist[$l] = 0 }
  $lenHist[$l]++
}
Write-Host "--- OUT lengths in [$MinLen, $MaxLen]:"
foreach ($k in ($lenHist.Keys | Sort-Object)) { Write-Host ("len={0} count={1}" -f $k, $lenHist[$k]) }

# For each keepalive length, per-byte change rate over consecutive packets OF THE SAME LENGTH
foreach ($L in ($lenHist.Keys | Sort-Object)) {
  $idx = New-Object System.Collections.Generic.List[int]
  for ($i=0; $i -lt $n; $i++) {
    if ([Cap3]::Dir[$i] -eq 'OUT' -and [Cap3]::Lens[$i] -eq $L) { $idx.Add($i) }
  }
  if ($idx.Count -lt 50) { continue }
  $chg = New-Object double[] $L
  $pairs = $idx.Count - 1
  for ($j=1; $j -lt $idx.Count; $j++) {
    $a = [Cap3]::Hex[$idx[$j-1]]; $b = [Cap3]::Hex[$idx[$j]]
    for ($k=0; $k -lt $L; $k++) {
      if ($a[2*$k] -ne $b[2*$k] -or $a[2*$k+1] -ne $b[2*$k+1]) { $chg[$k]++ }
    }
  }
  # cadence
  $dts = New-Object System.Collections.Generic.List[double]
  for ($j=1; $j -lt $idx.Count; $j++) { $dts.Add([Cap3]::Ts[$idx[$j]] - [Cap3]::Ts[$idx[$j-1]]) }
  $srt = $dts | Sort-Object
  $med = $srt[[int]($srt.Count/2)]
  Write-Host ("`n=== len={0} count={1} median_dt={2}ms" -f $L, $idx.Count, $med)
  $line = ""
  for ($k=0; $k -lt $L; $k++) { $line += ("{0,3} " -f [int](100*$chg[$k]/[Math]::Max(1,$pairs))) }
  Write-Host ("change%: " + $line)
  # show 5 sample packets
  for ($j=0; $j -lt 5 -and $j -lt $idx.Count; $j++) { Write-Host ("  " + [Cap3]::Hex[$idx[$j]]) }
}
