param([string]$Csv)
# The high bytes of w26 etc change by +/-1 (i.e. 512, 1024, 1536 = high byte deltas *256).
# The LOW bytes change by small amounts (2,4,6,8,10). This is consistent with:
# plaintext 16-bit value changing smoothly by small steps, XOR mask constant.
# e.g. low byte delta 2 = actual delta 2; occasionally carry/borrow flips high byte by 256.
# => bytes 26-27 ARE a 16-bit LE quantity changing by ~2-10 per 100ms while active.
# BUT high-byte deltas of exactly 512/1024 = 2*256/4*256 suggests these might be two separate fields (byte26, byte27)
# or the value changes by 258, 514 etc.
# Let's separate: per-byte deltas for bytes 26..31 during ACTIVE windows.
$rows = Import-Csv $Csv
function HexToBytes([string]$h) {
  $b = New-Object byte[] ($h.Length/2)
  for ($i=0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($h.Substring(2*$i,2),16) }
  return $b
}
$dh = @{}
for ($k=26; $k -lt 32; $k++) { $dh[$k] = @{} }
for ($i=1; $i -lt $rows.Count; $i++) {
  $ra = $rows[$i-1]; $rb = $rows[$i]
  if ($ra.len -ne $rb.len) { continue }
  $bb = HexToBytes $rb.hex32
  $nz = 0
  for ($k=26; $k -lt 32; $k++) { if ($bb[$k] -ne 0) { $nz++ } }
  if ($nz -eq 0) { continue }  # only active
  $a = HexToBytes $ra.hex32; $b = $bb
  for ($k=26; $k -lt 32; $k++) {
    $d = ($b[$k] - $a[$k] + 256) % 256
    if ($d -eq 0) { continue }
    if (-not $dh[$k].ContainsKey($d)) { $dh[$k][$d]=0 }
    $dh[$k][$d]++
  }
}
foreach ($k in (26..31)) {
  $top = $dh[$k].GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 10
  $s = ($top | ForEach-Object { "{0}x{1}" -f $_.Key, $_.Value }) -join ' '
  Write-Host ("byte {0} nonzero deltas top10: {1}" -f $k, $s)
}
