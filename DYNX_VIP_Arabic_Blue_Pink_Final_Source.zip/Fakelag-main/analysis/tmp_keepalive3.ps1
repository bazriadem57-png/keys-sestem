param([string]$File)
# Keepalive: use first 32 bytes of every keepalive packet (truncation-safe). 100ms cadence confirmed.
# Analyze bytes 0..31 volatility over consecutive keepalive packets (all lengths mixed, sorted by ts).
$src = @"
using System;
using System.Collections.Generic;
using System.IO;
public static class Cap5 {
  public static List<long> Ts = new List<long>();
  public static List<int> Lens = new List<int>();
  public static List<string> Hex = new List<string>();
  public static List<string> Dir = new List<string>();
  public static List<string> Typ = new List<string>();
  public static void Parse(string file) {
    foreach (var line in File.ReadLines(file)) {
      if (line.Length == 0 || line[0] == '#') continue;
      var p = line.Split(' ');
      if (p.Length < 12) continue;
      if (p[3] != "OUT") continue;
      int len;
      if (!int.TryParse(p[8], out len)) continue;
      if (len < 45 || len > 64) continue;
      string hex = p[p.Length-1].TrimEnd('.');
      bool ok = true;
      foreach (char c in hex) { if (!(c>='0'&&c<='9') && !(c>='A'&&c<='F')) { ok = false; break; } }
      if (!ok) continue;
      long ts; long.TryParse(p[1], out ts);
      Ts.Add(ts); Lens.Add(len); Hex.Add(hex); Dir.Add(p[3]); Typ.Add(p[9]);
    }
  }
}
"@
Add-Type -TypeDefinition $src
[Cap5]::Parse($File)
$n = [Cap5]::Ts.Count
Write-Host ("keepalive packets (45-64B OUT): {0}" -f $n)

# family check on raw byte2: constant in this capture?
$b2counts = @{}
$b3counts = @{}
for ($i=0; $i -lt $n; $i++) {
  $h = [Cap5]::Hex[$i]
  $b2 = $h.Substring(4,2); $b3 = $h.Substring(6,2)
  if (-not $b2counts.ContainsKey($b2)) { $b2counts[$b2]=0 }; $b2counts[$b2]++
  if (-not $b3counts.ContainsKey($b3)) { $b3counts[$b3]=0 }; $b3counts[$b3]++
}
Write-Host "raw byte2 value counts (top 10):"
$b2counts.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 10 | ForEach-Object { Write-Host ("  byte2=0x{0} count={1}" -f $_.Key, $_.Value) }
Write-Host "raw byte3 value counts (top 10):"
$b3counts.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 10 | ForEach-Object { Write-Host ("  byte3=0x{0} count={1}" -f $_.Key, $_.Value) }

# per-byte volatility over consecutive keepalives (all lengths mixed; compare only same-length adjacents? no -- XOR mask is positional, so mixing lengths misaligns mask if keystream; but if constant mask per session, mixing is fine)
# We compute volatility for consecutive same-length pairs AND all pairs.
function VolTable([int[]]$idxList, [string]$label) {
  $maxL = 0
  foreach ($i in $idxList) { if ([Cap5]::Lens[$i] -gt $maxL) { $maxL = [Cap5]::Lens[$i] } }
  $chg = New-Object int[] 32
  $pairs = 0
  for ($j=1; $j -lt $idxList.Count; $j++) {
    $a = [Cap5]::Hex[$idxList[$j-1]]; $b = [Cap5]::Hex[$idxList[$j]]
    $L = [Math]::Min(32, [Math]::Min($a.Length, $b.Length)/2)
    for ($k=0; $k -lt $L; $k++) {
      if ($a[2*$k] -ne $b[2*$k] -or $a[2*$k+1] -ne $b[2*$k+1]) { $chg[$k]++ }
    }
    $pairs++
  }
  $line = ""
  for ($k=0; $k -lt 32; $k++) { $line += ("{0,3} " -f [int](100*$chg[$k]/[Math]::Max(1,$pairs))) }
  Write-Host ("{0} (pairs={1}): {2}" -f $label, $pairs, $line)
}

# all consecutive
$allIdx = New-Object System.Collections.Generic.List[int]
for ($i=0; $i -lt $n; $i++) { $allIdx.Add($i) }
VolTable ($allIdx.ToArray()) "ALL-cons  "

# per-length consecutive
foreach ($L in (53,57,58,59,60)) {
  $idxL = New-Object System.Collections.Generic.List[int]
  for ($i=0; $i -lt $n; $i++) { if ([Cap5]::Lens[$i] -eq $L) { $idxL.Add($i) } }
  if ($idxL.Count -gt 100) { VolTable ($idxL.ToArray()) ("len={0}    " -f $L) }
}
