#!/usr/bin/env python3
"""Absolute-position decoding feasibility test.

Given: K[2..7] known (mode of OUT/24). Assume M3: K[i]=0 for i>=8.
Then IN/26 plaintext payload = raw ciphertext bytes 8-25.

This script examines decoded IN/26 payloads for coordinate plausibility:
  - LE/BE 16/32-bit value ranges, quantization patterns (e.g. /1000 fixed point),
  - correlation between same-entity packets over time (smooth position curves),
  - cross-entity separation (distinct players at distinct locations).
"""
import sys, collections, statistics

def load(path):
    rows = []
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('#') or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 11:
                continue
            try:
                ts = int(parts[1]); d = parts[3]
                ln = int(parts[8])
            except ValueError:
                continue
            hx = parts[-1]
            if len(hx) != ln * 2:
                continue
            try:
                payload = bytes.fromhex(hx)
            except ValueError:
                continue
            rows.append(dict(ts=ts, dir=d, ln=ln, p=payload))
    return rows

def main():
    path = sys.argv[1]
    rows = load(path)
    ins = [r for r in rows if r['dir'] == 'IN']
    in26 = [r for r in ins if r['ln'] == 26]
    sub = collections.Counter((r['p'][2], r['p'][5], r['p'][6]) for r in in26).most_common(1)[0][0]
    g = [r for r in in26 if (r['p'][2], r['p'][5], r['p'][6]) == sub]
    byE = collections.defaultdict(list)
    for r in g:
        byE[r['p'][0]].append(r)
    print(f"IN/26 subtype {tuple(f'{x:02X}' for x in sub)} n={len(g)}, entities={len(byE)}")

    # For each 16-bit pair interpretation, compute temporal smoothness per entity:
    # fraction of consecutive pairs where |delta| is small (< 100 units) — a coordinate
    # sampled at 2-5Hz should move smoothly.
    print("\nPair-wise smoothness (fraction of consecutive pairs with |wrap-delta| < 100):")
    header = "pair:"
    for lo in (10, 12, 14, 16, 18, 20, 22, 24):
        header += f"  ({lo},{lo+1})"
    print(header)
    for e, seq in sorted(byE.items(), key=lambda kv: -len(kv[1]))[:5]:
        line = f"  {e:02X} n={len(seq):3d}:"
        for lo in (10, 12, 14, 16, 18, 20, 22, 24):
            if lo + 1 > 25:
                line += "      -"
                continue
            vals = [(r['p'][lo] | r['p'][lo+1] << 8) for r in seq]
            def wd(a, b):
                d0 = (b - a) & 0xFFFF
                return d0 if d0 < 0x8000 else d0 - 0x10000
            small = sum(1 for a, b in zip(vals, vals[1:]) if abs(wd(a, b)) < 100)
            line += f"  {100*small/(len(vals)-1):5.1f}%"
        print(line)

    # per-byte change profile within entity (already known) — now print byte-pair values for a window
    e, seq = max(byE.items(), key=lambda kv: len(kv[1]))
    print(f"\nEntity {e:02X} (n={len(seq)}) payload bytes 9-25 over time (every 5th packet):")
    for r in seq[::5][:24]:
        p = r['p']
        print(f"  t+{(r['ts']-seq[0]['ts'])/1000:7.1f}s  {p[9]:02X} | {' '.join(f'{x:02X}' for x in p[10:26])}")

    # Cross-entity distinctness: at t=middle, compare payload blocks of all entities
    print("\nCross-entity payload blocks at ~middle of session (distinct positions?):")
    mid = rows[len(rows)//2]['ts']
    for e, seq in sorted(byE.items(), key=lambda kv: -len(kv[1]))[:10]:
        near = min(seq, key=lambda r: abs(r['ts'] - mid))
        p = near['p']
        print(f"  {e:02X} t={near['ts']}: {p[10:26].hex().upper()}")

if __name__ == '__main__':
    main()
