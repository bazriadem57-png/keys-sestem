# -*- coding: utf-8 -*-
"""Removes EspEngine's write-only fields.

Each is assigned on a packet path and read by nothing, anywhere. Most were
orphaned this session: ownSourceLine() was rewritten to report ownPosSrc /
ownDirSrc, which left vehicleMs / vehicleCmd / vehicleAim with no reader, and
the own-state precedence ladder added ownMsEcho and mountWireMs as bookkeeping
that the ladder then never consulted.

Kept deliberately: nothing here. Per SOURCE_MAP invariant 7 these were each
checked in context first -- a dead timestamp can mean "a reader was meant to
use this", and none of these has a plausible intended reader that is missing.
"""
import io, re

P = (r'C:\Users\Tonyt\Documents\GitHub\Fakelag\fakelag\fakelag-beta'
     r'\app\src\main\java\com\fakelag\cryhard8\esp\EspEngine.java')
s = io.open(P, encoding='utf-8').read()
before = len(s.splitlines())

# Whole lines to drop: the declaration and every assignment.
DROP = [
    'private volatile long ownEchoMs = 0L;',
    'ownEchoMs = now;',
    'private volatile long mountWireMs = 0L;',
    'mountWireMs = System.currentTimeMillis();',
    'mountWireMs = 0L;',
    'private volatile long ownMsEcho = 0L;',
    'ownMsEcho = now;',
    'ownMsEcho = 0L;',
    'private volatile long vehicleMs = 0L;',
    'vehicleMs = now;',
    'private volatile int vehicleCmd = 0;',
    'vehicleCmd = cmd;',
    'private volatile boolean vehicleAim = false;',
    'vehicleAim = true;',
    'vehicleAim = false;',
    'private static final double SELF_UNITS = 5.0 * UNITS_PER_METRE;',
]

out, dropped = [], 0
for line in s.split('\n'):
    t = line.strip()
    if t in DROP:
        dropped += 1
        continue
    out.append(line)
s = '\n'.join(out)

# Tidy the javadoc that documented the removed fields.
s = re.sub(r'\n[ \t]*/\*\*[^*]*\*/(?=\n[ \t]*\n)', '', s)

io.open(P, 'w', encoding='utf-8').write(s)
print('EspEngine: %d -> %d lines (%d statements dropped)'
      % (before, len(s.splitlines()), dropped))
