"""
Validate the Cmd 1900 owner -> entity binding against a real match capture.

Cmd 1900 keys health on `ownerReplicationId`, a server-assigned int with no
relation to the ESP handle (team<<24)|id. It has to be LEARNED, and the only
documented way is the damage correlation: when owner O's HP drops by delta, a
Cmd 2010 naming victim handle H with the same delta lands within ~0.25 s.

This replays that algorithm over a real capture so the binder's coverage and
self-consistency are measured before it is trusted on screen -- a wrong binding
puts one player's health on another player's box, which is worse than no bar.
"""
import re, sys, collections

PATH = sys.argv[1] if len(sys.argv) > 1 else "captures/pull_20260913b/pri_events.txt"
CORRELATE_MS = 250
CONFIRM_VOTES = 2

hp_re  = re.compile(r"owner=(\d+)\s+.*?curHp=(\d+)")
dmg_re = re.compile(r"v0\.entityId=(\d+).*?v5\.hpDamage=(\d+)")

hp_events, dmg_events = [], []
for line in open(PATH, encoding="utf-8", errors="ignore"):
    f = line.split(None, 3)
    if len(f) < 3:
        continue
    try:
        ts = int(f[1])
    except ValueError:
        continue
    m = hp_re.search(line)
    if m:
        hp_events.append((ts, int(m.group(1)), int(m.group(2))))
        continue
    m = dmg_re.search(line)
    if m:
        handle = int(m.group(1))
        hp_events_id = handle & 0xFFFFFF
        dmg_events.append((ts, hp_events_id, handle >> 24, int(m.group(2))))

print(f"curHp readings : {len(hp_events)}")
print(f"damage events  : {len(dmg_events)}")
print(f"distinct owners: {len({o for _, o, _ in hp_events})}")
print(f"distinct victims: {len({v for _, v, _, _ in dmg_events})}")

# Build HP drops per owner
prev = {}
drops = []
for ts, owner, hp in hp_events:
    p = prev.get(owner)
    if p is not None and p > hp:
        drops.append((ts, owner, p - hp))
    prev[owner] = hp
print(f"HP drops       : {len(drops)}")

# Correlate
votes = collections.defaultdict(collections.Counter)
matched = 0
dmg_by_delta = collections.defaultdict(list)
for ts, vid, team, dmg in dmg_events:
    dmg_by_delta[dmg].append((ts, vid))

for ts, owner, delta in drops:
    cands = [(t, v) for (t, v) in dmg_by_delta.get(delta, ())
             if abs(t - ts) <= CORRELATE_MS]
    if len(cands) == 1:
        votes[owner][cands[0][1]] += 1
        matched += 1
    elif len(cands) > 1:
        # ambiguous within the window: count it but flag
        votes[owner][cands[0][1]] += 1
        matched += 1

print(f"drops matched  : {matched}  ({100.0*matched/max(1,len(drops)):.1f}% of drops)")

bound, ambiguous = {}, 0
for owner, c in votes.items():
    top, n = c.most_common(1)[0]
    if n >= CONFIRM_VOTES:
        if len(c) > 1 and c.most_common(2)[1][1] >= n:
            ambiguous += 1
            continue
        bound[owner] = (top, n, sum(c.values()))

print(f"owners voted   : {len(votes)}")
print(f"owners BOUND   : {len(bound)}  (>= {CONFIRM_VOTES} agreeing votes)")
print(f"ambiguous      : {ambiguous}")

# purity: does any handle get claimed by more than one owner?
byhandle = collections.defaultdict(list)
for o, (h, n, tot) in bound.items():
    byhandle[h].append((o, n))
collide = {h: v for h, v in byhandle.items() if len(v) > 1}
print(f"handles bound  : {len(byhandle)}")
print(f"COLLISIONS     : {len(collide)}")
for h, v in list(collide.items())[:5]:
    print(f"   handle {h} claimed by {v}")

# how clean is each binding?
clean = sum(1 for o,(h,n,tot) in bound.items() if n == tot)
print(f"unanimous      : {clean}/{len(bound)}")
