# -*- coding: utf-8 -*-
"""Appends the page/tab helpers to gen_layout.py and rewrites its page body.

Split from gen_layout.py so the escaping stays readable; run gen_layout.py
afterwards. Written as files rather than heredocs because quoting inside a
bash heredoc has broken this twice (CLAUDE.md).
"""
import io

P = r'C:\Users\Tonyt\Documents\GitHub\Fakelag\tools\gen_layout.py'
s = io.open(P, encoding='utf-8').read()

HELPERS = '''

# ===================== PAGES =====================
#
# The bottom bar. Deliberately at the BOTTOM: this is a one-handed tool used
# in the seconds before a match, and the top of a 2340px screen cannot be
# reached without shifting grip. Navigation at the top is navigation that
# needs two hands.

BAR_OPEN = """
    <View
        android:layout_width="match_parent"
        android:layout_height="1dp"
        android:background="@color/nv_line" />

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:background="@color/nv_ground"
        android:orientation="horizontal"
        android:paddingTop="@dimen/nv_space_2"
        android:paddingBottom="@dimen/nv_space_3">
"""

BAR_CLOSE = """    </LinearLayout>
</LinearLayout>
"""

PAGE_CLOSE = "        </LinearLayout>\\n"


def tab(tid, label):
    return ('\\n        <TextView\\n'
            '            android:id="@+id/%s"\\n'
            '            android:layout_width="0dp"\\n'
            '            android:layout_height="@dimen/nv_touch_min"\\n'
            '            android:layout_weight="1"\\n'
            '            android:clickable="true"\\n'
            '            android:focusable="true"\\n'
            '            android:gravity="center"\\n'
            '            android:text="%s"\\n'
            '            android:textColor="@color/nv_text_3"\\n'
            '            android:textSize="12sp" />\\n' % (tid, label))


def page_open(pid, visible):
    return ('\\n        <LinearLayout\\n'
            '            android:id="@+id/%s"\\n'
            '            android:layout_width="match_parent"\\n'
            '            android:layout_height="wrap_content"\\n'
            '            android:orientation="vertical"\\n'
            '            android:visibility="%s">\\n'
            % (pid, "visible" if visible else "gone"))


def perm_row(cb, dot, status, label):
    """A permission. NOT a toggle: you cannot revoke one by tapping it, and a
    switch that reads OFF looks like a feature you declined rather than
    something blocking you. PermissionController hides the button entirely
    once granted, so a quiet row means nothing is wrong."""
    return ('\\n            <LinearLayout\\n'
            '                android:layout_width="match_parent"\\n'
            '                android:layout_height="wrap_content"\\n'
            '                android:minHeight="@dimen/nv_touch_min"\\n'
            '                android:gravity="center_vertical"\\n'
            '                android:orientation="horizontal"\\n'
            '                android:paddingLeft="@dimen/nv_space_4"\\n'
            '                android:paddingRight="@dimen/nv_space_4"\\n'
            '                android:paddingTop="@dimen/nv_space_3"\\n'
            '                android:paddingBottom="@dimen/nv_space_3">\\n'
            '\\n'
            '                <View\\n'
            '                    android:id="@+id/%s"\\n'
            '                    android:layout_width="8dp"\\n'
            '                    android:layout_height="8dp"\\n'
            '                    android:background="@drawable/dot_off" />\\n'
            '\\n'
            '                <LinearLayout\\n'
            '                    android:layout_width="0dp"\\n'
            '                    android:layout_height="wrap_content"\\n'
            '                    android:layout_weight="1"\\n'
            '                    android:layout_marginLeft="@dimen/nv_space_3"\\n'
            '                    android:orientation="vertical">\\n'
            '\\n'
            '                    <TextView\\n'
            '                        android:layout_width="wrap_content"\\n'
            '                        android:layout_height="wrap_content"\\n'
            '                        android:text="%s"\\n'
            '                        android:textColor="@color/nv_text"\\n'
            '                        android:textSize="15sp" />\\n'
            '\\n'
            '                    <TextView\\n'
            '                        android:id="@+id/%s"\\n'
            '                        android:layout_width="wrap_content"\\n'
            '                        android:layout_height="wrap_content"\\n'
            '                        android:layout_marginTop="3dp"\\n'
            '                        android:text="@string/checking"\\n'
            '                        android:textColor="@color/nv_text_3"\\n'
            '                        android:textSize="12sp" />\\n'
            '                </LinearLayout>\\n'
            '\\n'
            '                <TextView\\n'
            '                    android:id="@+id/%s"\\n'
            '                    android:layout_width="wrap_content"\\n'
            '                    android:layout_height="40dp"\\n'
            '                    android:minWidth="88dp"\\n'
            '                    android:gravity="center"\\n'
            '                    android:background="@drawable/nv_btn_primary"\\n'
            '                    android:text="@string/nv_grant"\\n'
            '                    android:textColor="@color/nv_on_brand"\\n'
            '                    android:textSize="12sp"\\n'
            '                    android:textStyle="bold" />\\n'
            '            </LinearLayout>\\n' % (dot, label, status, cb))
'''

marker = "\np = [HEAD, HERO, ENGINE]"
assert marker in s, "body marker not found"
head, body = s.split(marker, 1)

NEW_BODY = '''
p = [HEAD]

# ---------------- PAGE 1: HOME ----------------
# What you came for. Engine, target, and nothing else that can be scrolled
# past: starting the tunnel used to be the thing you scrolled AWAY from.
p.append(page_open("page_home", True))
p.append(HERO)
p.append(ENGINE)
p.append(section("EFFECT BUTTONS"))
p.append(card_open())
p.append(toggle("cb_float_ghost", "tv_float_ghost_status", "@string/ghost"))
p.append(toggle("cb_float_freeze", "tv_float_freeze_status", "@string/freeze"))
p.append(toggle("cb_float_tele", "tv_float_tele_status", "@string/tele"))
p.append(CARD_CLOSE)
p.append(card_open("group_tele_options", hidden=True))
p.append(toggle("cb_auto_stop_tele", "tv_auto_stop_tele_status", "Auto-stop teleport"))
p.append(seek("seek_tele_replay_delay", "tv_tele_replay_delay_value",
              "Replay delay", "How long withheld packets wait before replay."))
p.append(CARD_CLOSE)
p.append(PAGE_CLOSE)

# ---------------- PAGE 2: OVERLAY ----------------
p.append(page_open("page_overlay", False))
p.append(section("SHOW"))
p.append(card_open())
p.append(toggle("cb_esp", "tv_esp_status", "ESP boxes"))
p.append(toggle("cb_radar", "tv_radar_status", "Radar"))
p.append(toggle("cb_esptune", "tv_esptune_status", "Tune panel"))
p.append(toggle("cb_espdebug", "tv_espdebug_status", "Debug readout"))
p.append(toggle("cb_crosshair", "tv_crosshair_status", "Crosshair"))
p.append(CARD_CLOSE)
p.append(section("FLOATING BUTTONS"))
p.append(card_open())
p.append(seek("seek_float_size", "tv_float_size_value",
              "@string/floating_size", "@string/floating_size_hint"))
p.append(seek("seek_float_alpha", "tv_float_alpha_value",
              "@string/floating_alpha", "@string/floating_alpha_hint"))
p.append(CARD_CLOSE)
p.append(section("CROSSHAIR"))
p.append(card_open())
p.append(seek("seek_crosshair_size", "tv_crosshair_size_value",
              "Size", "Crosshair size, applied live."))
p.append(seek("seek_crosshair_alpha", "tv_crosshair_alpha_value",
              "Opacity", "Crosshair opacity, applied live."))
p.append(CARD_CLOSE)
p.append(section("MATCH ID MASK"))
p.append(card_open("group_mask_options", hidden=False))
p.append(seek("seek_mask_bar_thickness", "tv_mask_bar_thickness_value",
              "@string/match_mask_thickness", "@string/match_mask_thickness_hint"))
p.append(seek("seek_mask_bar_length", "tv_mask_bar_length_value",
              "@string/match_mask_length", "@string/match_mask_length_hint"))
p.append(CARD_CLOSE)
p.append(PAGE_CLOSE)

# ---------------- PAGE 3: AIM ----------------
p.append(page_open("page_aim", False))
p.append(section("AIM ASSIST"))
p.append(card_open())
p.append(toggle("cb_aim", "tv_aim_status", "Aim assist"))
p.append(toggle("cb_aimbtn", "tv_aimbtn_status", "Aim button"))
p.append(toggle("cb_zoombtn", "tv_zoombtn_status", "Zoom button"))
p.append(CARD_CLOSE)
p.append(PAGE_CLOSE)

# ---------------- PAGE 4: SYSTEM ----------------
p.append(page_open("page_system", False))
p.append(section("@string/nv_permissions"))
p.append(card_open())
p.append(perm_row("cb_vpn", "dot_vpn", "tv_vpn_status", "VPN"))
p.append(perm_row("cb_display", "dot_display", "tv_display_status",
                  "Display over other apps"))
p.append(CARD_CLOSE)
p.append(section("DEVELOPER"))
p.append(card_open())
p.append(toggle("cb_dev_mode", "tv_dev_mode_status", "Developer mode"))
p.append(CARD_CLOSE)
p.append(PAGE_CLOSE)

p.append(TAIL)

# ---------------- BOTTOM BAR ----------------
p.append(BAR_OPEN)
p.append(tab("tab_home", "Home"))
p.append(tab("tab_overlay", "Overlay"))
p.append(tab("tab_aim", "Aim"))
p.append(tab("tab_system", "System"))
p.append(BAR_CLOSE)
'''

# everything after the body build is the write+verify block; keep it
verify_marker = "\nxml = \"\".join(p)"
assert verify_marker in body, "verify marker not found"
_, verify = body.split(verify_marker, 1)

# notification + storage rows are gone from the UI entirely
NEED_DROP = ['cb_notif', 'dot_notif', 'tv_notif_status',
             'cb_storage', 'dot_storage', 'tv_storage_status']
head = head.replace('cb_dev_mode cb_display cb_esp cb_espdebug cb_esptune cb_float_freeze\ncb_float_ghost cb_float_tele cb_notif cb_radar cb_storage cb_vpn cb_zoombtn',
                    'cb_dev_mode cb_display cb_esp cb_espdebug cb_esptune cb_float_freeze\ncb_float_ghost cb_float_tele cb_radar cb_vpn cb_zoombtn')
head = head.replace('dot_app dot_display dot_engine dot_notif dot_storage dot_vpn group_mask_options',
                    'dot_app dot_display dot_engine dot_vpn group_mask_options')
head = head.replace('tv_notif_status tv_radar_status tv_selected_app tv_status tv_storage_status\ntv_vpn_status tv_zoombtn_status',
                    'tv_radar_status tv_selected_app tv_status\ntv_vpn_status tv_zoombtn_status')

out = head + HELPERS + NEW_BODY + verify_marker + verify
io.open(P, 'w', encoding='utf-8').write(out)
print("gen_layout.py rewritten for 4 pages + bottom bar")
