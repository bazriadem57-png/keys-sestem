"""
Aim drag-controller simulator, driven by REAL capture timing.

Why this exists
---------------
The touch-injection aim is a closed loop with a large, *variable* dead time:
we drag the view, and only find out whether it worked when the client next
emits an outbound Cmd 2001 self/camera report. Tuning that loop by feel on a
phone costs a match per experiment and cannot separate "wrong gain" from
"wrong latency model". So the loop is reproduced here against the actual Cmd
2001 arrival timestamps from a capture, and the controller variants are scored
on the same input.

What it answers
---------------
1. What IS the sampling delay, measured rather than assumed?
2. Is the shipped controller (exponential-decay lag compensator) stable, and
   where is its gain margin?
3. Does a ring-buffer predictor using the exact sample age do better, and by
   how much -- i.e. is it worth the code?
4. What gain should we actually ship, for Y and for X?

Run:  python tools/aim_control_sim.py
"""

import csv
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DEFAULT_CAP = os.path.join(
    ROOT, "captures", "device_pull_20260910", "dev_logs", "own_20260910_200050.csv"
)


# ----------------------------------------------------------------------
# 1. Measure the real Cmd 2001 sampling behaviour
# ----------------------------------------------------------------------
def load_capture(path):
    """Sample times (ms) plus the real yaw/pitch trace from a capture.

    DecodedDumper writes rel_ms (capture-relative) and the decoded camera
    direction per outbound self report, so this gives both the true sampling
    cadence AND a real motion profile to use as the disturbance -- far more
    honest than a synthetic ramp."""
    ts, yaw, pitch = [], [], []
    with open(path, newline="") as fh:
        for row in csv.DictReader(fh):
            try:
                t = float(row.get("rel_ms") or row.get("ts"))
                y = float(row.get("yaw_deg", "nan"))
                p = float(row.get("pitch_deg", "nan"))
            except (TypeError, ValueError):
                continue
            ts.append(t)
            yaw.append(y)
            pitch.append(p)
    return (
        np.asarray(ts, dtype=np.float64),
        np.asarray(yaw, dtype=np.float64),
        np.asarray(pitch, dtype=np.float64),
    )


def describe_sampling(ts):
    d = np.diff(ts)
    d = d[(d > 0) & (d < 1000)]          # drop match gaps / clock resets
    return {
        "n": int(d.size),
        "mean": float(d.mean()),
        "median": float(np.median(d)),
        "p90": float(np.percentile(d, 90)),
        "p99": float(np.percentile(d, 99)),
        "max": float(d.max()),
    }


# ----------------------------------------------------------------------
# 2. The plant + sensor
# ----------------------------------------------------------------------
class Sim:
    """
    Plant: the game camera. Dragging the look finger by dy px rotates the
    pitch by dy * DEG_PER_PX. It is a pure integrator -- position accumulates,
    holding still rotates nothing -- which is how mobile look controls behave.

    Sensor: our ESP. The camera angle is only observable when an outbound
    Cmd 2001 lands, so the measurement is a zero-order hold sampled at the
    capture's real timestamps, plus a fixed transport delay for
    VPN -> decode -> render.
    """

    TICK_MS = 8.0                 # controller period (125 Hz), matches AimInjector
    TRANSPORT_MS = 25.0           # inject->game + VPN decode->render, fixed part

    def __init__(self, deg_per_px, sample_times_ms, target_deg_fn,
                 noise_deg=0.0, seed=7):
        self.deg_per_px = deg_per_px
        self.sample_times = sample_times_ms
        self.target_deg_fn = target_deg_fn
        # Measurement noise. The target's screen position is dead-reckoned
        # between 5 Hz entity updates, so the error we read is genuinely noisy;
        # without modelling it the deadzone alone suppresses all chatter and
        # every controller looks equally good. This is the term that actually
        # decides whether a gain oscillates in a real match.
        self.noise_deg = noise_deg
        self.rng = np.random.default_rng(seed)
        self.reset()

    def reset(self):
        self.t = 0.0
        self.cam_deg = 0.0            # true camera pitch
        self.history = []             # (t, cam_deg) for delayed sampling
        self.last_meas = None         # (sample_wallclock_t, measured_err)
        self._next_sample_i = 0

    def step_plant(self, dy_px):
        self.cam_deg += dy_px * self.deg_per_px
        self.history.append((self.t, self.cam_deg))
        if len(self.history) > 4000:
            self.history.pop(0)

    def _cam_at(self, when):
        for t, v in reversed(self.history):
            if t <= when:
                return v
        return 0.0

    def maybe_sample(self):
        """Emit a new measurement if a Cmd 2001 boundary has passed."""
        fired = False
        while (
            self._next_sample_i < len(self.sample_times)
            and self.sample_times[self._next_sample_i] <= self.t - self.TRANSPORT_MS
        ):
            st = float(self.sample_times[self._next_sample_i])
            cam_then = self._cam_at(st)
            err = self.target_deg_fn(st) - cam_then
            if self.noise_deg > 0:
                err += self.rng.normal(0.0, self.noise_deg)
            self.last_meas = (st, err)
            self._next_sample_i += 1
            fired = True
        return fired


# ----------------------------------------------------------------------
# 3. Controllers
# ----------------------------------------------------------------------
class ExpDecayController:
    """What ships today: proportional + rate cap + deadzone, with the lag
    compensator as an exponential decay of injected pixels."""

    name = "exp-decay (shipped)"

    def __init__(self, gain, speed_cap, deadzone_px, lag_ms, deg_per_px):
        self.gain = gain
        self.cap = speed_cap
        self.dz = deadzone_px
        self.lag = lag_ms
        self.deg_per_px = deg_per_px
        self.accum = 0.0
        self.correcting = False

    def step(self, sim, dt_ms):
        if sim.last_meas is None:
            return 0.0
        err_px = sim.last_meas[1] / self.deg_per_px
        if self.lag > 1:
            self.accum *= math.exp(-dt_ms / self.lag)
        else:
            self.accum = 0.0
        lim = abs(err_px)
        self.accum = max(-lim, min(lim, self.accum))
        e = err_px - self.accum
        if self.correcting:
            if abs(e) < self.dz:
                self.correcting = False
        elif abs(e) > self.dz * 2.5:
            self.correcting = True
        if not self.correcting:
            return 0.0
        v = max(-self.cap, min(self.cap, e * self.gain))
        step = v * dt_ms / 1000.0
        if abs(step) < 1.0:
            step = 1.0 if e > 0 else -1.0
        self.accum += step
        return step


class PredictController:
    """Proposed: a ring buffer of timestamped injected pixels. The measurement
    describes the camera as of its own sample time, so everything injected
    AFTER that instant is in flight and must be subtracted. No decay constant
    to guess -- the sample's real age does the work."""

    name = "ring-buffer predictor"

    def __init__(self, gain, speed_cap, deadzone_px, deg_per_px):
        self.gain = gain
        self.cap = speed_cap
        self.dz = deadzone_px
        self.deg_per_px = deg_per_px
        self.ring = []                # (t_ms, px)
        self.correcting = False

    def step(self, sim, dt_ms):
        if sim.last_meas is None:
            return 0.0
        sample_t, err_deg = sim.last_meas
        err_px = err_deg / self.deg_per_px
        horizon = sample_t + Sim.TRANSPORT_MS
        in_flight = sum(px for t, px in self.ring if t > horizon)
        e = err_px - in_flight
        if self.correcting:
            if abs(e) < self.dz:
                self.correcting = False
        elif abs(e) > self.dz * 2.5:
            self.correcting = True
        if not self.correcting:
            return 0.0
        v = max(-self.cap, min(self.cap, e * self.gain))
        step = v * dt_ms / 1000.0
        if abs(step) < 1.0:
            step = 1.0 if e > 0 else -1.0
        self.ring.append((sim.t, step))
        if len(self.ring) > 600:
            self.ring.pop(0)
        return step


class JavaShippedController:
    """Literal port of AimInjector.tick() as shipped, so the simulator scores
    the code that actually runs rather than an idealised version of it.

    Differences from PredictController that matter: the ring is finite (256
    entries), the horizon uses transportMs, and the 1 px floor is applied after
    the speed cap."""

    name = "java (shipped)"
    RING = 256

    def __init__(self, gain, speed_cap, deadzone_px, transport_ms, deg_per_px):
        self.gain = gain
        self.cap = speed_cap
        self.dz = deadzone_px
        self.transport = transport_ms
        self.deg_per_px = deg_per_px
        self.ring_t = [0.0] * self.RING
        self.ring_y = [0.0] * self.RING
        self.head = 0
        self.correcting = False

    def _record(self, t, dy):
        self.head = (self.head + 1) % self.RING
        self.ring_t[self.head] = t
        self.ring_y[self.head] = dy

    def step(self, sim, dt_ms):
        if sim.last_meas is None:
            return 0.0
        sample_t, err_deg = sim.last_meas
        horizon = sample_t + self.transport
        in_flight = 0.0
        for i in range(self.RING):
            if self.ring_t[i] > horizon:
                in_flight += self.ring_y[i]
        err = err_deg / self.deg_per_px - in_flight
        dz = max(0.5, self.dz)
        if self.correcting:
            if abs(err) < dz:
                self.correcting = False
        elif abs(err) > dz * 2.5:
            self.correcting = True
        if not self.correcting:
            return 0.0
        want = err * max(0.1, self.gain)
        cap = max(20.0, self.cap)
        want = max(-cap, min(cap, want))
        step = want * dt_ms / 1000.0
        if abs(step) < 1.0:
            step = 1.0 if err > 0 else -1.0
        self._record(sim.t, step)
        return step


class NoCompController:
    name = "no compensator"

    def __init__(self, gain, speed_cap, deadzone_px, deg_per_px):
        self.gain = gain
        self.cap = speed_cap
        self.dz = deadzone_px
        self.deg_per_px = deg_per_px
        self.correcting = False

    def step(self, sim, dt_ms):
        if sim.last_meas is None:
            return 0.0
        e = sim.last_meas[1] / self.deg_per_px
        if self.correcting:
            if abs(e) < self.dz:
                self.correcting = False
        elif abs(e) > self.dz * 2.5:
            self.correcting = True
        if not self.correcting:
            return 0.0
        v = max(-self.cap, min(self.cap, e * self.gain))
        step = v * dt_ms / 1000.0
        if abs(step) < 1.0:
            step = 1.0 if e > 0 else -1.0
        return step


# ----------------------------------------------------------------------
# 4. Scoring
# ----------------------------------------------------------------------
def run(sim, ctrl, duration_ms, settle_deg=1.0):
    sim.reset()
    n = int(duration_ms / Sim.TICK_MS)
    errs = np.empty(n)
    steps = np.empty(n)
    for i in range(n):
        sim.maybe_sample()
        dy = ctrl.step(sim, Sim.TICK_MS)
        sim.step_plant(dy)
        sim.t += Sim.TICK_MS
        errs[i] = sim.target_deg_fn(sim.t) - sim.cam_deg
        steps[i] = dy

    # settle time: first moment after which |err| stays inside the band
    inside = np.abs(errs) <= settle_deg
    settle = None
    for i in range(n):
        if inside[i:].all():
            settle = i * Sim.TICK_MS
            break

    e0 = errs[0] if errs[0] != 0 else 1e-9
    overshoot = max(0.0, -errs.min() / e0 * 100.0) if e0 > 0 else max(
        0.0, -errs.max() / e0 * 100.0
    )
    # Score the TAIL, not the whole run: the opening transient is dominated by
    # the rate cap and is the same for every controller, so averaging over it
    # hides the thing we care about -- what the loop does once it has arrived.
    tail = errs[int(n * 0.55):]
    tstep = steps[int(n * 0.55):]
    sgn = np.sign(tstep[np.abs(tstep) > 0])
    reversals = int(np.sum(sgn[1:] != sgn[:-1])) if sgn.size > 1 else 0
    return {
        "settle_ms": settle,
        "overshoot_pct": overshoot,
        "reversals": reversals,
        "tail_rms": float(np.sqrt(np.mean(tail ** 2))),
        "tail_pp": float(tail.max() - tail.min()),
        "rms_deg": float(np.sqrt(np.mean(errs ** 2))),
        "final_deg": float(errs[-1]),
        "travel_px": float(np.abs(steps).sum()),
    }


def fmt(r):
    s = "  n/a " if r["settle_ms"] is None else f"{r['settle_ms']:6.0f}"
    return (
        f"settle {s}ms  over {r['overshoot_pct']:5.1f}%  "
        f"judder {r['reversals']:4d}  tail-rms {r['tail_rms']:5.2f}deg  "
        f"tail-pp {r['tail_pp']:5.2f}deg  travel {r['travel_px']:6.0f}px"
    )


def main():
    cap = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_CAP
    ts, yaw, pitch = load_capture(cap)
    st = describe_sampling(ts)
    print(f"capture: {os.path.basename(cap)}")
    print(
        "Cmd 2001 sampling: n=%d  mean=%.1fms  median=%.1fms  p90=%.1fms  "
        "p99=%.1fms  max=%.1fms"
        % (st["n"], st["mean"], st["median"], st["p90"], st["p99"], st["max"])
    )

    mean_dt = st["median"]
    L = Sim.TRANSPORT_MS + mean_dt / 2.0
    print(
        f"=> effective dead time L ~= {Sim.TRANSPORT_MS:.0f} (transport) + "
        f"{mean_dt/2:.0f} (half a sample) = {L:.0f} ms"
    )
    print(f"   stability limit K < pi/2/L = {math.pi/2/(L/1000.0):.1f} /s")
    print(f"   well-damped   K ~ 0.5/L    = {0.5/(L/1000.0):.1f} /s")

    d = np.diff(ts)
    d = d[(d > 0) & (d < 1000)][:500]
    grid = np.cumsum(d)
    if grid.size < 50:
        grid = np.arange(0, 4000, mean_dt)

    DEG_PER_PX = 0.10
    DURATION = 4000.0
    NOISE = 0.30          # deg, ESP extrapolation jitter on the head point

    # A REAL aiming burst from the capture, resampled onto sim time, used as
    # the moving-target disturbance. Nothing synthetic can reproduce the way a
    # human actually swings a view.
    fp = pitch[np.isfinite(pitch)]
    rt = ts[: fp.size] - ts[0]
    if fp.size > 200:
        seg0 = int(fp.size * 0.35)
        seg = fp[seg0 : seg0 + 60]
        segt = rt[seg0 : seg0 + 60] - rt[seg0]
        seg = seg - seg[0] + 8.0
        real_tgt = lambda t: float(np.interp(t, segt, seg))
        swing = float(np.abs(np.diff(seg)).sum() / max(1e-9, segt[-1] / 1000.0))
        print(f"   real target trace: {seg.size} samples, "
              f"{segt[-1]:.0f}ms, mean |rate| {swing:.1f} deg/s")
    else:
        real_tgt = lambda t: 8.0 + 12.0 * (t / 1000.0)
    print()

    static = lambda t: 8.0

    cases = (("static 8deg + noise", static), ("REAL capture trace", real_tgt))
    for label, tgt in cases:
        print(f"--- {label} (noise {NOISE} deg) ---")
        sim = Sim(DEG_PER_PX, grid, tgt, noise_deg=NOISE)
        for g in (3.0, 4.5, 6.0):
            print(f"  no-comp     K={g:4.1f}  "
                  + fmt(run(sim, NoCompController(g, 900, 6, DEG_PER_PX), DURATION)))
        for g in (4.5, 6.0):
            print(f"  exp-decay   K={g:4.1f}  "
                  + fmt(run(sim, ExpDecayController(g, 900, 6, 120, DEG_PER_PX),
                            DURATION)))
        for g in (6.0, 10.0, 16.0, 24.0):
            print(f"  predictor   K={g:4.1f}  "
                  + fmt(run(sim, PredictController(g, 900, 6, DEG_PER_PX), DURATION)))
        for g in (10.0, 16.0, 24.0):
            print(f"  JAVA ship   K={g:4.1f}  "
                  + fmt(run(sim, JavaShippedController(g, 700, 6, 25, DEG_PER_PX),
                            DURATION)))
        print()

    print("--- gain margin: tail peak-to-peak (deg), static + noise ---")
    print("      K    no-comp  exp-decay  predictor")
    sim = Sim(DEG_PER_PX, grid, static, noise_deg=NOISE)
    for g in (2, 3, 4.5, 6, 8, 12, 16, 24, 32, 48):
        row = []
        for ctor in (
            lambda k: NoCompController(k, 900, 6, DEG_PER_PX),
            lambda k: ExpDecayController(k, 900, 6, 120, DEG_PER_PX),
            lambda k: PredictController(k, 900, 6, DEG_PER_PX),
        ):
            r = run(sim, ctor(g), DURATION)
            row.append(f"{r['tail_pp']:8.2f}")
        print(f"  {g:5.1f}  " + " ".join(row))
    print()

    print("--- deadzone sweep, predictor K=10, static + noise ---")
    print("   dz(px)  dz(deg)   settle   tail-rms  tail-pp  judder  travel")
    for dz in (2, 4, 6, 10, 16, 24):
        r = run(sim, PredictController(10.0, 900, dz, DEG_PER_PX), DURATION)
        s_ = " n/a" if r["settle_ms"] is None else f"{r['settle_ms']:4.0f}"
        print(f"   {dz:5d}   {dz*DEG_PER_PX:6.2f}   {s_}ms   "
              f"{r['tail_rms']:7.2f}  {r['tail_pp']:7.2f}  {r['reversals']:5d}  "
              f"{r['travel_px']:6.0f}")
    print()

    print("--- speed cap sweep, predictor K=10, REAL trace + noise ---")
    print("   cap(px/s)  settle   tail-rms  tail-pp  judder  travel")
    sim2 = Sim(DEG_PER_PX, grid, real_tgt, noise_deg=NOISE)
    for cap_ in (200, 400, 700, 900, 1500, 3000):
        r = run(sim2, PredictController(10.0, cap_, 6, DEG_PER_PX), DURATION)
        s_ = " n/a" if r["settle_ms"] is None else f"{r['settle_ms']:4.0f}"
        print(f"   {cap_:8d}   {s_}ms   {r['tail_rms']:7.2f}  "
              f"{r['tail_pp']:7.2f}  {r['reversals']:5d}  {r['travel_px']:6.0f}")


if __name__ == "__main__":
    main()
