#!/usr/bin/env python3
"""fftest — self-tests for the offline tooling.  No capture files required.

Covers the things that silently corrupt an analysis rather than crashing it:

* the crypto primitives round-trip (CRC-7, QQ-TEA);
* the catalogue reader reproduces ``CmdCatalogue.COUNT`` / ``INBOUND_COUNT``
  exactly, so a drifted Java file is caught rather than absorbed;
* the header solver recovers a mask and permutation from synthetic packets;
* the body decoder honours the two traps — ``ReadByte``/``ReadBoolean`` are one
  RAW byte and ``ReadFixUInt16`` is two RAW little-endian bytes;
* the NEW capture format parses with every quirk the writer actually emits:
  the ``PHASE/EFFECT|EFFECT`` token, ``-`` for an empty payload or note, a
  compound ``note`` with spaces, rotated multi-part files whose footer is on
  the last part only, a payload containing every byte value, and a final line
  killed mid-write;
* both OLD formats still parse, and the fields they cannot supply come back as
  ``None`` rather than as a default that would be mistaken for data.

    python fftest.py            # run everything
    python fftest.py -v         # print each check
"""

from __future__ import annotations

import argparse
import io
import os
import shutil
import struct
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ffproto import (analyze, capture, catalogue, crypto, decode, framing,  # noqa: E402
                     schema)

FAILED = []
PASSED = []
VERBOSE = False


def check(name, cond, detail=""):
    if cond:
        PASSED.append(name)
        if VERBOSE:
            print("  ok   %-52s %s" % (name, detail))
    else:
        FAILED.append("%s %s" % (name, detail))
        print("  FAIL %-52s %s" % (name, detail))


# ---------------------------------------------------------------- crypto

def test_crypto():
    key = bytes(range(16))
    n_ok = 0
    for n in (0, 1, 5, 7, 8, 23, 64, 255):
        msg = bytes((i * 37 + 11) & 0xFF for i in range(n))
        ct = crypto.qqtea_encrypt(msg, key)
        pt, ok = crypto.qqtea_decrypt(ct, key)
        if ok and pt == msg and len(ct) == crypto.qqtea_encrypt_len(n):
            n_ok += 1
    check("qqtea round trip", n_ok == 8, "%d/8" % n_ok)

    wrong = bytes(range(1, 17))
    ct = crypto.qqtea_encrypt(b"hello world", key)
    pt, ok = crypto.qqtea_decrypt(ct, wrong)
    check("qqtea rejects a wrong key", pt is None and not ok)

    pkt = bytearray(b"\x5a\x00" + bytes(range(40)))
    pkt[1] = crypto.crc7_of_packet(pkt)
    check("crc7 verifies", crypto.crc7_verify(pkt))
    pkt[9] ^= 1
    check("crc7 catches a flipped byte", not crypto.crc7_verify(pkt))


# ---------------------------------------------------------------- catalogue

def test_catalogue():
    path = catalogue.java_path()
    if not os.path.exists(path):
        check("catalogue source present", False, path)
        return
    text = io.open(path, encoding="utf-8", errors="replace").read()
    want_count = want_in = None
    for line in text.splitlines():
        if "int COUNT =" in line:
            want_count = int(line.split("=")[1].strip().rstrip(";"))
        if "int INBOUND_COUNT =" in line:
            want_in = int(line.split("=")[1].strip().rstrip(";"))
    check("catalogue COUNT matches the Java constant",
          catalogue.count() == want_count,
          "%s vs %s" % (catalogue.count(), want_count))
    check("catalogue INBOUND_COUNT matches the Java constant",
          catalogue.inbound_count() == want_in,
          "%s vs %s" % (catalogue.inbound_count(), want_in))
    check("catalogue names a known id", catalogue.name(106) == "RUDP_TAKE_DAMAGE",
          str(catalogue.name(106)))
    check("catalogue falls back for an unknown id",
          catalogue.name_or(999999) == "CMD_999999")


# ---------------------------------------------------------------- decode

class _W(object):
    """Minimal FastBinaryWriter, only what the tests need."""

    def __init__(self):
        self.b = bytearray()

    def varint(self, v):
        v &= (1 << 64) - 1
        while True:
            c = v & 0x7F
            v >>= 7
            self.b.append(c | (0x80 if v else 0))
            if not v:
                break
        return self

    def zigzag(self, v):
        return self.varint((v << 1) ^ (v >> 63) if v < 0 else (v << 1))

    def f32(self, x):
        return self.varint(struct.unpack("<I", struct.pack("<f", x))[0])

    def raw1(self, v):
        self.b.append(v & 0xFF)
        return self

    def fix16(self, v):
        self.b += struct.pack("<H", v & 0xFFFF)
        return self


def test_decode_primitives():
    r = decode.Reader(_W().varint(300).zigzag(-5).f32(1.5).raw1(200).b)
    check("varint", r.varint() == 300)
    check("zigzag", r.zigzag() == -5)
    check("float32 from varint bits", abs(r.f32() - 1.5) < 1e-9)
    check("ReadByte is one RAW byte (200, high bit set)", r.raw1() == 200)
    check("reader consumed exactly", r.remaining == 0)

    # The trap: a raw byte >= 128 desyncs a naive varint walk.
    body = _W().raw1(200).varint(7).b
    _d, slots = decode.decode_untyped(body)
    check("naive varint walk desyncs on a raw byte >= 128",
          len(slots) == 1 and slots[0].raw != 200,
          "slots=%s" % [s.raw for s in slots])

    r = decode.Reader(_W().fix16(0xBEEF).b)
    check("ReadFixUInt16 is two RAW LE bytes", r.fix16() == 0xBEEF)


def test_decode_typed():
    s = schema.default_schema()
    lay = s.layout(106, schema.IN)
    if lay is None:
        check("cmd 106 IN layout available", False)
        return
    check("cmd 106 IN class is GMDJLCGLDCH", lay.cls == "GMDJLCGLDCH", lay.cls)
    # attacker, victim, damage, shieldDamage, weapon(zz), buff(zz),
    # specialHit(zz), hitBodyPart(RAW byte)
    body = (_W().varint(16777217).varint(33554435).varint(120).varint(0)
            .zigzag(181).zigzag(0).zigzag(1).raw1(1).b)
    d = decode.decode_typed(lay, body)
    check("cmd 106 IN decodes exactly", d.ok, str(d))
    vals = d.values()
    check("106 v2 is the HP damage", vals[2] == 120, str(vals))
    check("106 v7 is the hit zone and is a RAW byte", vals[7] == 1, str(vals))

    # A trailing byte must be a failure, not a pass: a decoder that stops early
    # would silently accept a desynced walk.
    d2 = decode.decode_typed(lay, bytes(body) + b"\x00")
    check("a trailing byte fails the decode", not d2.ok, str(d2))


def test_schema_directions():
    s = schema.default_schema()
    a = s.class_for(106, schema.IN)
    b = s.class_for(106, schema.OUT)
    check("106 has different classes per direction", a != b and a and b,
          "%s vs %s" % (a, b))
    cov = s.coverage()
    check("inbound registry resolves most layouts",
          cov[schema.IN]["ids_with_layout"] > 1300,
          str(cov[schema.IN]))


# ---------------------------------------------------------------- framing

def _make_packet(layout, cmd, body, reliable, order_id=0, send_option=None,
                 flags=0, msg_key=None):
    hdr = framing.HDR_RELIABLE if reliable else framing.HDR_NON_RELIABLE
    pkt = bytearray(hdr + len(body))
    if msg_key is None:
        msg_key = 92 if reliable else 104
    pkt[0] = msg_key
    offs = layout.offsets(reliable)
    if send_option is None:
        send_option = 2 if reliable else 0
    values = {framing.SENDOPTION: send_option, framing.CMD: cmd,
              framing.FLAGS: flags, framing.DATALEN: len(body)}
    if reliable:
        values[framing.ORDERID] = order_id
    for field, off in offs.items():
        v = values[field]
        if framing.FIELD_W[field] == 1:
            pkt[off] = (v & 0xFF) ^ layout.mask
        else:
            pkt[off] = (v & 0xFF) ^ layout.mask
            pkt[off + 1] = ((v >> 8) & 0xFF) ^ layout.mask
    pkt[hdr:] = body
    pkt[1] = crypto.crc7(pkt, 2, len(pkt) - 2)
    return bytes(pkt)


def _synthetic_session(mask=0x5C, order=(framing.SENDOPTION, framing.DATALEN,
                                         framing.CMD, framing.FLAGS,
                                         framing.ORDERID), n=400):
    layout = framing.HeaderLayout(mask, order)
    out = []
    for i in range(n):
        # A real cmd 106 inbound body: GMDJLCGLDCH is
        # attacker, victim, damage, shieldDamage, weapon(zz), buff(zz),
        # specialHit(zz), hitBodyPart(RAW byte).
        body = (_W().varint(16777217).varint(33554435).varint(50 + i)
                .varint(0).zigzag(181).zigzag(0).zigzag(1).raw1(2).b)
        out.append(("OUT", _make_packet(layout, 2000, _W().varint(i).b, False)))
        out.append(("IN", _make_packet(layout, 106, body, True,
                                       order_id=9000 + i)))
    return layout, out


def test_framing():
    want, pkts = _synthetic_session()
    got, hits, tested = framing.solve_layout([(d, b) for d, b in pkts])
    check("solver recovers the mask", got and got.mask == want.mask,
          "0x%02X vs 0x%02X" % (got.mask if got else -1, want.mask))
    check("solver recovers HEAD_SECRET", got and got.order == want.order,
          "%s vs %s" % (framing.order_str(got.order) if got else "?",
                        framing.order_str(want.order)))
    ok = sum(1 for _d, b in pkts if crypto.crc7_verify(b))
    check("crc7 over synthetic packets", ok == len(pkts),
          "%d/%d" % (ok, len(pkts)))
    good = 0
    for d, b in pkts:
        p = framing.parse(b, want)
        if p and p.len_match and p.cmd in (106, 2000):
            good += 1
    check("parse reads cmd and Length back", good == len(pkts),
          "%d/%d" % (good, len(pkts)))
    # The ambiguity the header alone cannot settle, kept as a live check.
    cands = framing.solve_candidates([(d, b) for d, b in pkts])
    check("solver exposes its candidate set", len(cands) >= 2,
          "%d candidates" % len(cands))


# ---------------------------------------------------------------- capture IO

NEW_HEADER = [
    "# FakeLag packet capture",
    "# started=2026-09-12 10:00:00.000",
    "# secret_key=000102030405060708090a0b0c0d0e0f",
    "# key_endpoint=10.0.0.1:10013",
    "# columns: seq ts_ms dt_us src dir decision phase match cmd cmdname flags "
    "peer sp dp len hexlen payload_hex note",
]


def _new_row(seq, ts, dt, src, direction, decision, phase, match, cmd, name,
             flags, peer, sp, dp, payload, note):
    hx = payload.hex().upper() if payload else "-"
    return " ".join(str(x) for x in (
        seq, ts, dt, src, direction, decision, phase, match, cmd, name,
        "%X" % flags, peer, sp, dp, len(payload), len(payload), hx, note))


def _write_new_capture(directory):
    """Two rotated parts: header on both, footer on the last, killed tail."""
    all_bytes = bytes(range(256))
    rows_a = [
        _new_row(0, 1789000000000, 0, 0, "OUT", "PASS", "UNKNOWN", -1, 2001,
                 "UDP_PLAYER_STATE_SYNC", 0x41, "10.0.0.1", 40000, 10013,
                 b"\x01\x02\x03", "kind=MOVE ord=12 pos=1,2,3 aim=0.5"),
        _new_row(1, 1789000000099, 99000, 0, "IN", "DROP",
                 "MATCH/FREEZE|GHOST", 3, 106, "RUDP_TAKE_DAMAGE", 0x47,
                 "10.0.0.1", 10013, 40000, all_bytes, "kind=HURT dmg=42 zone=Head"),
        _new_row(2, 1789000000198, 99000, 1, "OUT", "PASS", "LOBBY", 0, -1,
                 "-", 0x0, "10.0.0.9", 41000, 443, b"", "-"),
    ]
    a = os.path.join(directory, "capture_raw_20260912_100000_001.txt")
    with io.open(a, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(NEW_HEADER) + "\n")
        fh.write("\n".join(rows_a) + "\n")
        fh.write("# MATCH mode=CS_RANKED srv=10.0.0.1:10013 round=3 t+184s\n")

    rows_b = [
        _new_row(3, 1789000000297, 99000, 0, "IN", "REWRITE",
                 "MATCH/FREEZE|GHOST|JITTER", 3, 2012,
                 "UDP_PLAYER_STATE_SYNC_V2", 0x45, "10.0.0.1", 10013, 40000,
                 b"\x7f\x80\x81", "kind=STATE tele=1 note with several spaces"),
    ]
    b = os.path.join(directory, "capture_raw_20260912_100000_002.txt")
    with io.open(b, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(NEW_HEADER) + "\n")
        fh.write("\n".join(rows_b) + "\n")
        fh.write("# drops cap=0 filter=0\n")
        fh.write("# by_src udp=4 tcp=1 ctrl=0\n")
        fh.write("# coverage decoded=3 total=4\n")
        # A capture killed mid-write ends mid-line, on the last part only.
        fh.write("4 1789000000396 99000 0 OUT PASS MATCH 3 2001 "
                 "UDP_PLAYER_STATE_SYNC 41 10.0.0.1 40000 10013 12 12 0102030")
    return a, b


def test_new_format():
    tmp = tempfile.mkdtemp(prefix="fftest_")
    try:
        _write_new_capture(tmp)
        cs = capture.load([tmp])
        check("new format detected", cs.formats == [capture.FMT_NEW],
              str(cs.formats))
        check("rotated parts concatenate in order", len(cs.files) == 2,
              "%d files" % len(cs.files))
        pkts = list(cs)
        check("every complete record parsed, plus the killed tail",
              len(pkts) == 5, "%d packets" % len(pkts))
        if len(pkts) < 5:
            return

        p0, p1, p2, p3, p4 = pkts
        check("seq order preserved across parts",
              [p.seq for p in pkts] == [0, 1, 2, 3, 4],
              str([p.seq for p in pkts]))
        check("phase without an effect suffix",
              p0.phase == "UNKNOWN" and p0.effects == (),
              "%s %s" % (p0.phase, p0.effects))
        check("phase with an effect suffix splits",
              p1.phase == "MATCH" and p1.effects == ("FREEZE", "GHOST"),
              "%s %s" % (p1.phase, p1.effects))
        check("three-effect mask splits",
              p3.effects == ("FREEZE", "GHOST", "JITTER"), str(p3.effects))
        check("payload with every byte value survives",
              p1.payload == bytes(range(256)), "%d bytes" % len(p1.payload))
        check("'-' payload_hex means empty, not a shifted column",
              p2.payload == b"" and p2.length == 0 and p2.dp == 443,
              "len=%s dp=%s" % (p2.length, p2.dp))
        check("'-' note means empty", p2.note is None, str(p2.note))
        check("compound note: leading tokens lifted out",
              p0.note_kind == "MOVE" and p0.note_ord == "12",
              "%s %s" % (p0.note_kind, p0.note_ord))
        check("compound note: free text keeps its spaces",
              p0.note_text == "pos=1,2,3 aim=0.5", repr(p0.note_text))
        check("note tele token", p3.note_tele == "1", str(p3.note_tele))
        check("note free text with spaces after tokens",
              p3.note_text == "note with several spaces", repr(p3.note_text))
        check("flags parse as hex",
              p1.flags == 0x47 and p1.has(capture.F_CRC_OK), hex(p1.flags or 0))
        check("src column read", p2.src == 1 and p2.src_name == "TCP",
              str(p2.src))
        check("dt_us == 0 on a retro record is kept, not nulled",
              p0.dt_us == 0, str(p0.dt_us))
        check("killed tail line still parses up to the break",
              p4.seq == 4 and p4.partial and len(p4.payload) == 3,
              "partial=%s bytes=%d" % (p4.partial, len(p4.payload)))
        check("killed tail is flagged as truncated payload",
              p4.payload_truncated, str(p4.payload_truncated))
        check("no line was thrown away",
              sum(cf.bad_lines for cf in cs.files) == 0,
              str([cf.bad_lines for cf in cs.files]))
        check("footer only on the last part",
              len(cs.files[0].footer) == 0 and len(cs.files[1].footer) == 3,
              str([len(cf.footer) for cf in cs.files]))
        check("a missing footer is not read as truncation",
              not cs.files[0].truncated_tail and cs.files[1].truncated_tail,
              str([cf.truncated_tail for cf in cs.files]))
        check("lifecycle '#' line kept as an event, not as a header pair",
              any("MATCH mode=CS_RANKED" in e.text for e in cs.events),
              str([e.text for e in cs.events]))
        check("secret_key read from a part header",
              cs.secret_key == bytes(range(16)),
              cs.secret_key.hex() if cs.secret_key else "none")
        check("header value containing a space stays whole",
              cs.header("started") == "2026-09-12 10:00:00.000",
              str(cs.header("started")))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


OLD13 = [
    "# SunnyMod packet capture",
    "# started=2026-09-10 17:52:08.990",
    "# records=3 dropped_by_cap=0",
    "# columns: seq ts phase dir decision dip sp dp len type family kind payload_hex",
    "",
    "0 1789098728990 BEFORE IN PASS 148.222.80.111 10014 38144 4 FIRE R ACK_SMALL 6C4E6500",
    "1 1789098728990 BEFORE OUT PASS 148.222.80.111 38144 10014 8 FIRE R ACK 6C26650001020304",
    "2 1789098729020 FREEZE OUT DROP 148.222.80.111 38144 10014 40 MOVE C MOVEMENT 6559650001..",
]

OLD11 = [
    "# SunnyMod packet capture",
    "# columns: seq ts phase dir decision dip sp dp len type payload_hex",
    "",
    "0 1788824470733 BEFORE IN PASS 148.222.88.69 10014 49960 4 FIRE 62513412",
]


def test_old_formats():
    tmp = tempfile.mkdtemp(prefix="fftest_old_")
    try:
        a = os.path.join(tmp, "capture_raw_a.txt")
        io.open(a, "w", encoding="utf-8", newline="\n").write("\n".join(OLD13) + "\n")
        cf = capture.CaptureFile(a)
        check("old13 detected", cf.fmt == capture.FMT_OLD13, str(cf.fmt))
        check("old13 packets", len(cf) == 3, str(len(cf)))
        p = cf.packets[0]
        check("old13 payload", p.payload == bytes.fromhex("6C4E6500"),
              p.payload.hex())
        check("old13 legacy columns kept",
              p.legacy_family == "R" and p.legacy_kind == "ACK_SMALL",
              "%s/%s" % (p.legacy_family, p.legacy_kind))
        check("old13 freeze phase is exposed as legacy_phase, not phase",
              p.phase is None and p.legacy_phase == "BEFORE",
              "%s/%s" % (p.phase, p.legacy_phase))
        check("old format supplies no cmd/flags/note",
              p.cmd is None and p.flags is None and p.note is None)
        check("old13 '..' marks a hexLimit cut (defect D3)",
              cf.packets[2].payload_truncated, "")

        b = os.path.join(tmp, "capture_raw_b.txt")
        io.open(b, "w", encoding="utf-8", newline="\n").write("\n".join(OLD11) + "\n")
        cf2 = capture.CaptureFile(b)
        check("old11 detected", cf2.fmt == capture.FMT_OLD11, str(cf2.fmt))
        check("old11 packet parsed",
              len(cf2) == 1 and cf2.packets[0].payload.hex() == "62513412",
              str(len(cf2)))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_end_to_end():
    """A synthetic session written in the NEW format and analysed."""
    tmp = tempfile.mkdtemp(prefix="fftest_e2e_")
    try:
        want, pkts = _synthetic_session(n=120)
        path = os.path.join(tmp, "capture_raw_20260912_120000_001.txt")
        with io.open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write("# columns: seq ts_ms dt_us src dir decision phase match "
                     "cmd cmdname flags peer sp dp len hexlen payload_hex note\n")
            ts = 1789000000000
            for i, (d, b) in enumerate(pkts):
                sp, dp = (40000, 10013) if d == "OUT" else (10013, 40000)
                fh.write(_new_row(i, ts + i * 50, 50000, 0, d, "PASS", "MATCH",
                                  1, -1, "-", 0, "10.0.0.1", sp, dp, b, "-")
                         + "\n")
        a = analyze.Analysis([path])
        ok, decodable, total = a.coverage()
        check("end-to-end packets", total == len(pkts),
              "%d/%d" % (total, len(pkts)))
        s = list(a.sessions.values())[0]
        check("end-to-end header solved",
              s.layout and s.layout.mask == want.mask
              and s.layout.order == want.order,
              s.layout.describe() if s.layout else "none")
        check("end-to-end crc7 100%", s.crc_ok == s.crc_total,
              "%d/%d" % (s.crc_ok, s.crc_total))
        check("end-to-end decode coverage 100%", ok == decodable and ok > 0,
              "%d/%d" % (ok, decodable))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main(argv=None):
    global VERBOSE
    p = argparse.ArgumentParser(prog="fftest", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("-v", "--verbose", action="store_true")
    args = p.parse_args(argv)
    VERBOSE = args.verbose

    for name, fn in (("crypto", test_crypto),
                     ("catalogue", test_catalogue),
                     ("decode primitives", test_decode_primitives),
                     ("typed decode", test_decode_typed),
                     ("schema directions", test_schema_directions),
                     ("framing solver", test_framing),
                     ("new capture format", test_new_format),
                     ("old capture formats", test_old_formats),
                     ("end to end", test_end_to_end)):
        print("-- %s" % name)
        fn()
    print("")
    print("%d checks passed, %d failed" % (len(PASSED), len(FAILED)))
    for f in FAILED:
        print("  FAILED: %s" % f)
    return 1 if FAILED else 0


if __name__ == "__main__":
    sys.exit(main())
