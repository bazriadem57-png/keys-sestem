# -*- coding: utf-8 -*-
"""Gives every toggle row a permanent description, and every slider a range.

Audit B11: the sublabel was a state echo ("Showing"/"Hidden") on all 24 rows
 - redundant where it was right, and wrong wherever the setting was not
visual. Audit B12: sliders showed "100%" next to a bar 12% full, because the
track's zero is the range floor and nothing on screen said so.
"""
import io

P = r'C:\Users\Tonyt\Documents\GitHub\Fakelag\tools\gen_layout.py'
s = io.open(P, encoding='utf-8').read()

DESCS = {
    'cb_esp':          'A box, name and health bar on each enemy',
    'cb_radar':        'Bearing dial, scales itself to what it can see',
    'cb_esptune':      'In-match calibration panel',
    'cb_espdebug':     'Frame counters and DIAG slots',
    'cb_crosshair':    'A fixed crosshair at screen centre',
    'cb_aim':          'Needs Shizuku',
    'cb_aimbtn':       'A hold-to-aim button in the overlay',
    'cb_zoombtn':      'A zoom button in the overlay',
    'cb_float_ghost':  'Stop being streamed to other players',
    'cb_float_freeze': 'Hold the world still',
    'cb_float_tele':   'Rewrite the position you report',
    'cb_auto_stop_tele': 'End the effect by itself after the replay',
    'cb_dev_mode':     'Extra readouts and the packet dumper controls',
}

n = 0
for cb, desc in DESCS.items():
    old = 'toggle("%s", ' % cb
    i = s.find(old)
    if i < 0:
        print("  !! no row for", cb)
        continue
    j = s.find(')', i)
    call = s[i:j]
    if 'desc=' in call:
        continue
    s = s[:j] + ', "%s"' % desc + s[j:]
    n += 1
print("descriptions applied:", n)

# B12: state the range under every slider, so "100%" next to a 12%-full bar
# stops reading as broken. The floor is the real confusion: BUTTON SIZE runs
# 80-260, so 100% genuinely is near the left end.
OLD_SEEK_TAIL = """            '                    android:splitTrack="false" />\\n'
            '            </LinearLayout>\\n' % (label, vid, hint, sid))"""
NEW_SEEK_TAIL = """            '                    android:splitTrack="false" />\\n'
            '\\n'
            '                <LinearLayout\\n'
            '                    android:layout_width="match_parent"\\n'
            '                    android:layout_height="wrap_content"\\n'
            '                    android:orientation="horizontal">\\n'
            '\\n'
            '                    <TextView\\n'
            '                        android:layout_width="0dp"\\n'
            '                        android:layout_height="wrap_content"\\n'
            '                        android:layout_weight="1"\\n'
            '                        android:text="%s"\\n'
            '                        android:fontFamily="@font/nv_mono"\\n'
            '                        android:textColor="@color/nv_text_4"\\n'
            '                        android:textSize="10sp" />\\n'
            '\\n'
            '                    <TextView\\n'
            '                        android:layout_width="wrap_content"\\n'
            '                        android:layout_height="wrap_content"\\n'
            '                        android:text="%s"\\n'
            '                        android:fontFamily="@font/nv_mono"\\n'
            '                        android:textColor="@color/nv_text_4"\\n'
            '                        android:textSize="10sp" />\\n'
            '                </LinearLayout>\\n'
            '            </LinearLayout>\\n' % (label, vid, hint, sid, lo, hi))"""
assert OLD_SEEK_TAIL in s, "seek tail"
s = s.replace(OLD_SEEK_TAIL, NEW_SEEK_TAIL, 1)
s = s.replace("def seek(sid, vid, label, hint):",
              "def seek(sid, vid, label, hint, lo='', hi=''):")
print("slider range labels: applied")

# The real ranges, from AppearanceBroadcaster / EspTuning.
RANGES = {
    'seek_float_size':          ('80%', '260%'),
    'seek_float_alpha':         ('35%', '100%'),
    'seek_crosshair_size':      ('20dp', '96dp'),
    'seek_crosshair_alpha':     ('35%', '100%'),
    'seek_mask_bar_thickness':  ('10sp', '40sp'),
    'seek_mask_bar_length':     ('80dp', '400dp'),
    'seek_tele_replay_delay':   ('0ms', '2000ms'),
}
m = 0
for sid, (lo, hi) in RANGES.items():
    old = 'seek("%s", ' % sid
    i = s.find(old)
    if i < 0:
        print("  !! no slider for", sid)
        continue
    j = s.find('))', i)
    if j < 0:
        j = s.find(')', i)
    seg = s[i:j]
    if 'lo=' in seg:
        continue
    s = s[:j] + ', "%s", "%s"' % (lo, hi) + s[j:]
    m += 1
print("ranges applied:", m)

io.open(P, 'w', encoding='utf-8').write(s)
print("gen_layout.py updated")
