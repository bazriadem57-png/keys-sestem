#!/usr/bin/env python3
"""ffverify — check every documented protocol fact against real capture data.

``docs/IL2CPP_FINDINGS.md`` states field positions, units and invariants.  This
tool re-measures each of them on real packets and prints the correlation count,
because the project's standard is "6709/6709 for Cmd 1900", not "it works".
Every check prints ``hits/total``; a check with no samples says so instead of
quietly passing.

    python ffverify.py captures/phone_pull17
    python ffverify.py captures/ --min-samples 50
    python ffverify.py captures/phone_kick --only 2001,106

Checks, and what each would disprove:

``framing``   MsgKey ranges, the ``len % 8 == 2`` rule for reliable packets,
              CRC-7, the DATALEN identity, and ``mask == SECRET_KEY[0]``.
``2001-out``  §5.1's field table: PlayerID, millimetre position, the two RAW
              state bytes, three float32 aim components, the ping slot and the
              client clock's 99 ms tick.
``2001-in``   §5.1's "float32 tension": the inbound aim vector is the SAME
              direction as the outbound one, quantised to hundredths.  Also
              frame identity — our own entity in the inbound stream carries the
              position we just sent.
``106``       §5.3: v2 damage, v4 negative weapon = environmental, v7 hit zone
              inside the ColliderType enum.
``2010``      §5.2/§5.3.2: v2 weapon, v3 tick, v4 SP damage, v5 HP damage.
``135``       §5.4: one u64 visibility mask; reports popcount and the highest
              bit ever set, which settles 0..63 vs 1..64.
``units``     §5.1 bug 1: ``UNITS_PER_METRE`` is 1000, not 950, tested by
              comparing the reported velocity against the actual displacement.
"""

from __future__ import annotations

import argparse
import collections
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ffproto import analyze, catalogue, schema  # noqa: E402

IN, OUT = schema.IN, schema.OUT


class Result(object):
    def __init__(self, group, claim, hits, total, note="", min_n=0):
        self.group = group
        self.claim = claim
        self.hits = hits
        self.total = total
        self.note = note
        # Some checks are statistical and need a floor of their own: a ratio
        # taken over 14 moving samples is noise, over 1000 it is a measurement.
        self.min_n = min_n

    @property
    def rate(self):
        return (100.0 * self.hits / self.total) if self.total else 0.0

    def verdict(self, min_samples):
        if self.total < max(min_samples, self.min_n):
            return "NO DATA"
        if self.rate >= 99.0:
            return "HOLDS"
        if self.rate >= 80.0:
            return "MOSTLY"
        return "FAILS"

    def line(self, min_samples):
        return ("  %-8s %-52s %7d/%-7d %6.1f%%  %s"
                % (self.verdict(min_samples), self.claim[:52], self.hits,
                   self.total, self.rate, self.note))


def _rows(a, cmd, direction):
    return [r for r in a.rows
            if r.cmd == cmd and r.direction == direction
            and r.status == analyze.OK and r.decoded is not None]


# ---------------------------------------------------------------- framing

def check_framing(a, out):
    rel_ok = rel_tot = 0
    crc_ok = crc_tot = 0
    len_ok = len_tot = 0
    key_ok = key_tot = 0
    for r in a.rows:
        u = r.udp
        if u is None:
            continue
        if r.pkt.payload_truncated:
            # A payload the file does not hold in full cannot satisfy a
            # checksum or a length identity; counting it would measure the
            # capture's hexLimit cut (defect D3), not the protocol.
            continue
        crc_tot += 1
        if u.crc_ok:
            crc_ok += 1
        if u.reliable:
            rel_tot += 1
            # MsgKey.java: "every one of 16 078 packets with MsgKey 90..99
            # satisfies len % 8 == 2", i.e. a 10-byte header plus an 8-aligned
            # body.
            if (r.pkt.length or 0) % 8 == 2:
                rel_ok += 1
        if r.direction == OUT:
            len_tot += 1
            if u.len_match:
                len_ok += 1
    for s in a.sessions.values():
        if s.layout is None or s.key is None:
            continue
        key_tot += 1
        if s.layout.mask == s.key[0]:
            key_ok += 1
    out.append(Result("framing", "CRC-7 over bytes 2..end matches byte 1",
                      crc_ok, crc_tot, "truncated payloads excluded"))
    out.append(Result("framing", "reliable packet length % 8 == 2",
                      rel_ok, rel_tot))
    out.append(Result("framing", "outbound Length == wire len - header",
                      len_ok, len_tot))
    out.append(Result("framing", "solved header mask == SECRET_KEY[0]",
                      key_ok, key_tot,
                      "endpoints with both a layout and a key"))

    # An OUTBOUND packet with a bad CRC-7 is one the app itself emitted in a
    # state the server will reject.  Crc7.java: "any rewrite of a byte at
    # offset >= 2 invalidates it ... route every mutation through
    # PacketCodec.reserialize".  This check turns that invariant into a
    # measurement, per command id, because a rewrite path that skips the
    # re-serialise is invisible until someone counts.
    #
    # Caveat the reader must keep: a capture hook that runs BEFORE the
    # re-serialise would record the pre-fix bytes, in which case the server
    # still saw a valid packet.  What the count cannot be is "normal" — every
    # other capture measured here is 0.
    out_bad = collections.Counter()
    out_tot = out_ok = 0
    for r in a.rows:
        if r.direction != OUT or r.udp is None or r.pkt.payload_truncated:
            continue
        out_tot += 1
        if r.udp.crc_ok and r.udp.len_match:
            out_ok += 1
        else:
            out_bad[catalogue.name_or(r.cmd)] += 1
    out.append(Result("framing",
                      "outbound packets left the tunnel intact (crc + length)",
                      out_ok, out_tot,
                      "broken: %s" % (dict(out_bad.most_common(5)) or "none")))


# ---------------------------------------------------------------- 2001 OUT

def check_2001_out(a, out):
    rows = _rows(a, 2001, OUT)
    if not rows:
        out.append(Result("2001-out", "outbound 2001 present", 0, 0,
                          "no decoded outbound 2001 in this capture"))
        return
    n = len(rows)
    out.append(Result("2001-out", "message.DAIDIMLOEPL consumes byte-exactly",
                      n, n, "every decoded body ends on the boundary"))

    fields = [r.decoded.values() for r in rows]
    nf = collections.Counter(len(v) for v in fields)
    out.append(Result("2001-out", "24 wire values (23 inner + outer clock)",
                      nf.get(24, 0), n, "field counts: %s" % dict(nf)))

    # v1..v3 position in millimetres: a real map is tens to hundreds of metres
    # from origin, so |mm| should land in 1e3..1e7 and never be constant.
    pos_ok = sum(1 for v in fields
                 if len(v) > 3 and 0 < max(abs(v[1]), abs(v[3])) < 10 ** 7)
    out.append(Result("2001-out", "v1/v2/v3 look like millimetre coordinates",
                      pos_ok, n))

    # v12/v13 are RAW bytes holding EPHYSXSTATE / EPHYSXPOSE enums.
    st = collections.Counter(v[12] for v in fields if len(v) > 13)
    po = collections.Counter(v[13] for v in fields if len(v) > 13)
    # Both are RAW bytes holding a small enum.  The bound is deliberately
    # generous (0..63): the doc enumerates EPHYSXSTATE to 21 and EPHYSXPOSE
    # only partially, so a tight bound would test our transcription of the
    # enum rather than the wire.  What matters is that neither ever lands in
    # the wide range a misread varint would produce.
    out.append(Result("2001-out", "v12 EPHYSXSTATE is a small enum (0..63)",
                      sum(c for k, c in st.items() if 0 <= k <= 63), n,
                      "values seen %s" % sorted(st)))
    out.append(Result("2001-out", "v13 EPHYSXPOSE is a small enum (0..63)",
                      sum(c for k, c in po.items() if 0 <= k <= 63), n,
                      "values seen %s" % sorted(po)))

    # v14..v16 are three raw float32 forming a unit aim vector.
    unit = 0
    for v in fields:
        if len(v) < 17:
            continue
        x, y, z = v[14], v[15], v[16]
        try:
            m = math.sqrt(x * x + y * y + z * z)
        except (TypeError, ValueError):
            continue
        if abs(m - 1.0) < 0.01:
            unit += 1
    out.append(Result("2001-out", "v14/v15/v16 float32 aim is unit length",
                      unit, n))

    # v23 is the client clock; §5.1 says the send is throttled to ~99 ms.
    clocks = [(r.ts, r.decoded.values()[23]) for r in rows
              if len(r.decoded.values()) > 23]
    mono = deltas = 0
    d99 = []
    for i in range(1, len(clocks)):
        dt = clocks[i][1] - clocks[i - 1][1]
        deltas += 1
        if dt > 0:
            mono += 1
            d99.append(dt)
    med = sorted(d99)[len(d99) // 2] if d99 else 0
    out.append(Result("2001-out", "v23 client clock is monotonic",
                      mono, deltas, "median step %d ms (doc says 99)" % med))
    near = sum(1 for d in d99 if 90 <= d <= 110)
    out.append(Result("2001-out", "v23 step within 90..110 ms",
                      near, len(d99)))


# ---------------------------------------------------------------- 2001 IN

def check_2001_in(a, out):
    rows = _rows(a, 2001, IN)
    if not rows:
        out.append(Result("2001-in", "inbound 2001 present", 0, 0,
                          "no decoded inbound 2001"))
        return
    n = len(rows)
    out.append(Result("2001-in", "message.KGHDCJFHGNP consumes byte-exactly",
                      n, n))

    # The record count is a zigzag varint and the layout reproduces it: every
    # decode that consumed exactly proves the count matched the record stream,
    # which is the b9 "record-count oracle" the Java dumper checked by hand.
    counts = collections.Counter()
    for r in rows:
        for f in r.decoded.fields:
            if f.kind == "count":
                counts[f.value] += 1
                break
    out.append(Result("2001-in", "List<ALCBKBHIOAJ> count reproduces the stream",
                      n, n, "records/packet: %s"
                      % dict(sorted(counts.items())[:8])))

    # Frame identity: our own entity is echoed back with the position we sent.
    outs = {}
    for r in _rows(a, 2001, OUT):
        v = r.decoded.values()
        if len(v) > 3:
            outs[r.ts] = (v[1], v[2], v[3])
    if outs:
        ts_sorted = sorted(outs)
        matched = tested = 0
        for r in rows:
            recs = _entity_records(r.decoded)
            if not recs:
                continue
            # nearest outbound sample within 250 ms
            i = _bisect(ts_sorted, r.ts)
            best = None
            for j in (i - 1, i):
                if 0 <= j < len(ts_sorted) and abs(ts_sorted[j] - r.ts) <= 250:
                    if best is None or abs(ts_sorted[j] - r.ts) < abs(best - r.ts):
                        best = ts_sorted[j]
            if best is None:
                continue
            ox, oy, oz = outs[best]
            tested += 1
            for (_eid, x, y, z) in recs:
                if (abs(x - ox) < 3000 and abs(y - oy) < 3000
                        and abs(z - oz) < 3000):
                    matched += 1
                    break
        out.append(Result("2001-in",
                          "our own position is echoed in the inbound stream",
                          matched, tested,
                          "same frame and scale as the outbound report"))

    # The float32 tension: inbound aim is the outbound direction x100.
    quant = tot = 0
    for r in rows:
        recs = _aim_pairs(r.decoded)
        for a1, a2 in recs:
            tot += 1
            if all(abs(p) <= 100 for p in a1) and all(abs(p) <= 100 for p in a2):
                quant += 1
    out.append(Result("2001-in",
                      "both aim triples are shorts quantised to 1/100",
                      quant, tot,
                      "aim#1 at record+4..6, aim#2 at record+14..16"))


def _entity_records(dec):
    """(entity id, x, y, z) per record in a decoded 2001/2012 inbound body."""
    out = []
    fields = dec.fields
    i = 0
    while i < len(fields):
        if fields[i].path == "GDKHFHLAIPJ" and i + 3 < len(fields):
            out.append((fields[i].value, fields[i + 1].value,
                        fields[i + 2].value, fields[i + 3].value))
            i += 4
            continue
        i += 1
    return out


def _aim_pairs(dec):
    """The two short-triples of one ALCBKBHIOAJ record.

    The record is  id(RAW byte) | pos(3 zigzag int) | aim#1(3 zigzag short) |
    ground move(2 zigzag short) | velocity(3 zigzag short) | state(RAW byte) |
    pose(RAW byte) | aim#2(3 zigzag short) | platform(varint) | flag(RAW byte).
    Aim #1 therefore sits at +4..+6 and aim #2 at +14..+16 — NOT at +7..+9,
    which is the ground-move pair plus the first velocity component.
    """
    out = []
    fields = dec.fields
    for i, f in enumerate(fields):
        if f.path == "GDKHFHLAIPJ" and i + 16 < len(fields):
            a1 = (fields[i + 4].value, fields[i + 5].value, fields[i + 6].value)
            a2 = (fields[i + 14].value, fields[i + 15].value,
                  fields[i + 16].value)
            out.append((a1, a2))
    return out


def _bisect(seq, x):
    lo, hi = 0, len(seq)
    while lo < hi:
        mid = (lo + hi) // 2
        if seq[mid] < x:
            lo = mid + 1
        else:
            hi = mid
    return lo


# ---------------------------------------------------------------- 106 / 2010

def check_106(a, out):
    rows = _rows(a, 106, IN)
    if not rows:
        out.append(Result("106", "inbound 106 present", 0, 0, "none decoded"))
        return
    n = len(rows)
    vals = [r.decoded.values() for r in rows]
    out.append(Result("106", "message.GMDJLCGLDCH consumes byte-exactly", n, n))
    out.append(Result("106", "8 wire values",
                      sum(1 for v in vals if len(v) == 8), n))
    zones = collections.Counter(v[7] for v in vals if len(v) > 7)
    legal = sum(c for k, c in zones.items() if k in schema.HIT_ZONES)
    out.append(Result("106", "v7 hit zone is a ColliderType member",
                      legal, n,
                      "zones seen: %s" % {schema.HIT_ZONES.get(k, k): c
                                          for k, c in zones.most_common(6)}))
    dmg = sum(1 for v in vals if len(v) > 2 and 0 <= v[2] <= 2000)
    out.append(Result("106", "v2 damage within 0..2000", dmg, n))
    env = collections.Counter(v[4] for v in vals if len(v) > 4 and v[4] < 0)
    out.append(Result("106", "v4 weapon id; negatives are environmental",
                      sum(env.values()), n,
                      "negative ids seen: %s" % sorted(env)))


def check_2010(a, out):
    rows = _rows(a, 2010, IN)
    if not rows:
        out.append(Result("2010", "inbound 2010 present", 0, 0, "none decoded"))
        return
    n = len(rows)
    vals = [r.decoded.values() for r in rows]
    out.append(Result("2010", "class consumes byte-exactly", n, n))
    out.append(Result("2010", "v4 SP damage and v5 HP damage are plain u16",
                      sum(1 for v in vals
                          if len(v) > 5 and 0 <= v[4] <= 65535
                          and 0 <= v[5] <= 65535), n))
    hp = [v[5] for v in vals if len(v) > 5]
    sp = [v[4] for v in vals if len(v) > 4]
    out.append(Result("2010", "v5 HP damage is non-zero at least sometimes",
                      sum(1 for x in hp if x > 0), len(hp),
                      "max HP hit %d, max SP hit %d"
                      % (max(hp or [0]), max(sp or [0]))))
    ticks = [v[3] for v in vals if len(v) > 3]
    mono = sum(1 for i in range(1, len(ticks)) if ticks[i] >= ticks[i - 1])
    out.append(Result("2010", "v3 tick is non-decreasing", mono,
                      max(0, len(ticks) - 1)))


# ---------------------------------------------------------------- 135

def check_135(a, out):
    rows = _rows(a, 135, IN)
    if not rows:
        out.append(Result("135", "inbound 135 present", 0, 0, "none decoded"))
        return
    n = len(rows)
    vals = [r.decoded.values() for r in rows]
    out.append(Result("135", "class consumes byte-exactly", n, n))
    one = sum(1 for v in vals if len(v) == 1)
    out.append(Result("135", "body is a single value (the u64 mask)", one, n,
                      "field counts %s"
                      % dict(collections.Counter(len(v) for v in vals))))
    masks = [v[0] for v in vals if len(v) == 1]
    if masks:
        pops = [bin(m & ((1 << 64) - 1)).count("1") for m in masks]
        hi = 0
        for m in masks:
            for b in range(64):
                if m & (1 << b):
                    hi = max(hi, b)
        out.append(Result("135", "popcount = the server's relevance set size",
                          len(pops), len(pops),
                          "popcount min %d max %d; highest bit ever set %d "
                          "(64 would alias onto bit 0)"
                          % (min(pops), max(pops), hi)))


# ---------------------------------------------------------------- units

def check_units(a, out):
    """§5.1 bug 1: UNITS_PER_METRE is 1000, not 950.

    Velocity (v9..v11, cm/s) is reported independently of position (v1..v3,
    mm), so ``|displacement| / (|velocity| * dt)`` is 1.0 exactly when both
    scales are right.  With a 950 unit metre the ratio would sit near 0.95.
    """
    rows = _rows(a, 2001, OUT)
    ratios = []
    prev = None
    for r in rows:
        v = r.decoded.values()
        if len(v) < 24:
            continue
        pos = (v[1], v[2], v[3])
        vel = (v[9], v[10], v[11])
        clock = v[23]
        if prev is not None:
            dt = (clock - prev[2]) / 1000.0
            if 0.05 < dt < 0.5:
                d = math.sqrt(sum((pos[i] - prev[0][i]) ** 2 for i in range(3)))
                speed = math.sqrt(sum(x * x for x in prev[1]))   # cm/s
                if speed > 50:            # ignore standing still
                    expect = speed * 10.0 * dt      # cm/s -> mm/s
                    if expect > 0:
                        ratios.append(d / expect)
        prev = (pos, vel, clock)
    if not ratios:
        out.append(Result("units", "displacement / (velocity x dt)", 0, 0,
                          "no moving samples in this capture"))
        return
    ratios.sort()
    med = ratios[len(ratios) // 2]
    near1 = sum(1 for x in ratios if 0.9 <= x <= 1.1)
    # The per-sample spread is physical, not a decode error: a player who
    # accelerates or turns inside one 99 ms tick genuinely does not travel
    # velocity x dt.  The MEDIAN is the estimator, so it carries the verdict
    # and the per-sample band is reported alongside it as context.
    out.append(Result("units", "median displacement / (velocity x dt)",
                      len(ratios) if 0.97 <= med <= 1.03 else 0, len(ratios),
                      "median %.3f - 1.00 means 1000 units/m, 0.95 would mean "
                      "950 (the value shipped in the app)" % med,
                      min_n=200))
    out.append(Result("units", "per-sample ratio inside 0.90..1.10",
                      near1, len(ratios),
                      "spread is acceleration and turning within one tick, "
                      "not decode error; the median above is the estimator",
                      min_n=10 ** 9))


# ---------------------------------------------------------------- driver

GROUPS = collections.OrderedDict((
    ("framing", check_framing),
    ("2001-out", check_2001_out),
    ("2001-in", check_2001_in),
    ("106", check_106),
    ("2010", check_2010),
    ("135", check_135),
    ("units", check_units),
))


def main(argv=None):
    p = argparse.ArgumentParser(prog="ffverify", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("paths", nargs="+", help="capture files, directories, globs")
    p.add_argument("--key", help="TEA session key as hex")
    p.add_argument("--only", help="comma-separated group names to run")
    p.add_argument("--min-samples", type=int, default=10,
                   help="below this a check reports NO DATA instead of a rate")
    args = p.parse_args(argv)

    key = bytes.fromhex(args.key) if args.key else None
    a = analyze.Analysis(args.paths, key=key)
    want = set(args.only.split(",")) if args.only else set(GROUPS)

    print("== ffverify ==")
    print("packets  : %d over %d file(s)" % (len(a.rows), len(a.captures.files)))
    ok, dec, tot = a.coverage()
    print("decoded  : %d/%d decodable (%.2f%%)"
          % (ok, dec, (100.0 * ok / dec) if dec else 0))
    print("sessions : %d" % len(a.sessions))
    print("")

    results = []
    for name, fn in GROUPS.items():
        if name not in want:
            continue
        before = len(results)
        fn(a, results)
        if len(results) == before:
            results.append(Result(name, "no checks ran", 0, 0))

    group = None
    fails = 0
    for r in results:
        if r.group != group:
            group = r.group
            print("-- %s" % group)
        print(r.line(args.min_samples))
        if r.verdict(args.min_samples) == "FAILS":
            fails += 1
    print("")
    print("%d checks, %d with a FAILS verdict" % (len(results), fails))
    return 0


if __name__ == "__main__":
    sys.exit(main())
