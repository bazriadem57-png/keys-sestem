# -*- coding: utf-8 -*-
"""Applies the audit fixes to gen_layout.py, then it is re-run.

Everything here traces to a numbered finding in the on-device audit; the
comment on each edit names it.
"""
import io

P = r'C:\Users\Tonyt\Documents\GitHub\Fakelag\tools\gen_layout.py'
s = io.open(P, encoding='utf-8').read()


def sub(old, new, why):
    global s
    if old not in s:
        if new in s:
            print("  -- already applied:", why)
        else:
            print("  !! NOT FOUND:", why)
        return
    s = s.replace(old, new, 1)
    print("  ok:", why)


# ---- B3: the whole row is the target, and the switch clears 48dp ----------
# Measured: switches were 52x28dp (58% of the 48dp floor) and the row itself
# was not clickable, so 314dp of row width was dead and the only live area
# was the far right - the hardest place to reach with a left thumb.
sub('''            '                android:minHeight="@dimen/nv_touch_min"\\n'
            '                android:gravity="center_vertical"\\n'
            '                android:orientation="horizontal"\\n'
            '                android:paddingLeft="@dimen/nv_space_4"\\n'
            '                android:paddingRight="@dimen/nv_space_3"\\n'
            '                android:paddingTop="@dimen/nv_space_2"\\n'
            '                android:paddingBottom="@dimen/nv_space_2">\\n'
            '\\n'
            '                <LinearLayout\\n'
            '                    android:layout_width="0dp"\\n'
            '                    android:layout_height="wrap_content"\\n'
            '                    android:layout_weight="1"\\n'
            '                    android:orientation="vertical">\\n'
            '\\n'
            '                    <TextView\\n'
            '                        android:layout_width="wrap_content"\\n'
            '                        android:layout_height="wrap_content"\\n'
            '                        android:text="%s"\\n'
            '                        android:textColor="@color/nv_text"\\n'
            '                        android:textSize="14sp" />%s\\n'
            '                </LinearLayout>\\n'
            '\\n'
            '                <TextView\\n'
            '                    android:id="@+id/%s"\\n'
            '                    android:layout_width="52dp"\\n'
            '                    android:layout_height="28dp"\\n'
            '                    android:background="@drawable/bg_switch_custom_off" />\\n'
            '            </LinearLayout>\\n' % (label, sub, cb))''',
'''            '                android:minHeight="56dp"\\n'
            '                android:gravity="center_vertical"\\n'
            '                android:orientation="horizontal"\\n'
            '                android:clickable="true"\\n'
            '                android:focusable="true"\\n'
            '                android:background="?android:attr/selectableItemBackground"\\n'
            '                android:paddingLeft="@dimen/nv_space_4"\\n'
            '                android:paddingRight="@dimen/nv_space_4"\\n'
            '                android:paddingTop="@dimen/nv_space_2"\\n'
            '                android:paddingBottom="@dimen/nv_space_2">\\n'
            '\\n'
            '                <LinearLayout\\n'
            '                    android:layout_width="0dp"\\n'
            '                    android:layout_height="wrap_content"\\n'
            '                    android:layout_weight="1"\\n'
            '                    android:orientation="vertical">\\n'
            '\\n'
            '                    <TextView\\n'
            '                        android:layout_width="wrap_content"\\n'
            '                        android:layout_height="wrap_content"\\n'
            '                        android:text="%s"\\n'
            '                        android:textAppearance="@style/TextAppearance.Nv.Body" />%s\\n'
            '                </LinearLayout>\\n'
            '\\n'
            '                <TextView\\n'
            '                    android:id="@+id/%s"\\n'
            '                    android:layout_width="52dp"\\n'
            '                    android:layout_height="28dp"\\n'
            '                    android:layout_marginLeft="@dimen/nv_space_3"\\n'
            '                    android:duplicateParentState="true"\\n'
            '                    android:background="@drawable/bg_switch_custom_off" />\\n'
            '            </LinearLayout>\\n' % (label, sub, cb))''',
    "B3 row is the touch target, 56dp, textAppearance")

# ---- B8/B11: the sublabel says what the setting DOES, in the middle tone ---
sub('''            '                        android:text="@string/floating_hidden"\\n'
            '                        android:textColor="@color/nv_text_3"\\n'
            '                        android:textSize="11sp" />' % status)''',
'''            '                        android:text="@string/floating_hidden"\\n'
            '                        android:textAppearance="@style/TextAppearance.Nv.Label" />' % status)''',
    "B8/B11 sublabel uses Label (13sp, nv_text_2)")

# ---- B9: one left edge. Headings sit over the row labels they introduce ----
sub('''            \'            android:layout_marginLeft="@dimen/nv_space_6"\\n\'
            \'            android:layout_marginTop="@dimen/nv_space_6"\\n\'
            \'            android:layout_marginBottom="@dimen/nv_space_2"\\n\'''',
'''            \'            android:layout_marginLeft="36dp"\\n\'
            \'            android:layout_marginTop="@dimen/nv_space_6"\\n\'
            \'            android:layout_marginBottom="@dimen/nv_space_2"\\n\'''',
    "B9 heading left edge 24dp -> 36dp, over the row labels")

# ---- B6: the one literal hex in the layout, and the tightest contrast -----
sub('''                        android:text="@string/creator"
                        android:textColor="#C9FFFFFF"
                        android:textSize="12sp" />''',
'''                        android:text="@string/creator"
                        android:textColor="@color/nv_on_brand_2"
                        android:textSize="12sp" />''',
    "B6 Protocol engine: literal hex -> token")

# ---- B5: dot_engine was a CHIP drawable at 9dp = 1.21:1 when connected ----
sub('''                <View
                    android:id="@+id/dot_engine"
                    android:layout_width="9dp"
                    android:layout_height="9dp"
                    android:background="@drawable/nv_pill_on" />''',
'''                <View
                    android:id="@+id/dot_engine"
                    android:layout_width="10dp"
                    android:layout_height="10dp"
                    android:background="@drawable/dot_off" />''',
    "B5 dot_engine: chip drawable -> solid dot")

# ---- B7: the gradient belongs on the PRIMARY action -----------------------
sub('''            android:background="@drawable/nv_card"
            android:clickable="true"
            android:focusable="true"
            android:gravity="center_vertical"
            android:minHeight="72dp"''',
'''            android:background="@drawable/nv_card_hero"
            android:clickable="true"
            android:focusable="true"
            android:gravity="center_vertical"
            android:minHeight="76dp"''',
    "B7 engine card takes the gradient")

# ...and Change gives it up, which also clears its 3.35:1 contrast failure.
sub('''                android:background="@drawable/nv_btn_primary"
                android:text="@string/nv_change"
                android:textColor="@color/nv_on_brand"''',
'''                android:background="@drawable/nv_btn_secondary"
                android:text="@string/nv_change"
                android:textColor="@color/nv_text"''',
    "B6/B7 Change -> secondary (fixes 3.35:1 white-on-teal)")

# ---- B5: dot_app was solid teal in EVERY state, including disconnected ----
sub('''            <View
                android:id="@+id/dot_app"
                android:layout_width="9dp"
                android:layout_height="9dp"
                android:background="@drawable/nv_pill_off" />''',
'''            <View
                android:id="@+id/dot_app"
                android:layout_width="10dp"
                android:layout_height="10dp"
                android:background="@drawable/dot_off" />''',
    "B5 dot_app: solid dot, honest off state")

# ---- C: rebalance. Float sliders are app chrome, not in-match overlay -----
# Measured: page_overlay was 1.47 viewports (still scrolled) while aim and
# system were ~70% empty. Moving these two sliders (582px) to System and
# making the crosshair/mask sliders conditional takes the worst page to 0.61.
sub('''p.append(section("FLOATING BUTTONS"))
p.append(card_open())
p.append(seek("seek_float_size", "tv_float_size_value",
              "@string/floating_size", "@string/floating_size_hint"))
p.append(seek("seek_float_alpha", "tv_float_alpha_value",
              "@string/floating_alpha", "@string/floating_alpha_hint"))
p.append(CARD_CLOSE)
p.append(section("CROSSHAIR"))''',
'''p.append(section("CROSSHAIR"))''',
    "C float sliders leave the Overlay page")

sub('''p.append(section("DEVELOPER"))
p.append(card_open())
p.append(toggle("cb_dev_mode", "tv_dev_mode_status", "Developer mode"))
p.append(CARD_CLOSE)
p.append(PAGE_CLOSE)''',
'''p.append(section("FLOATING BUTTONS"))
p.append(card_open())
p.append(seek("seek_float_size", "tv_float_size_value",
              "@string/floating_size", "@string/floating_size_hint"))
p.append(seek("seek_float_alpha", "tv_float_alpha_value",
              "@string/floating_alpha", "@string/floating_alpha_hint"))
p.append(CARD_CLOSE)
p.append(section("DEVELOPER"))
p.append(card_open())
p.append(toggle("cb_dev_mode", "tv_dev_mode_status", "Developer mode"))
p.append(CARD_CLOSE)
p.append(PAGE_CLOSE)''',
    "C float sliders land on System")

# ---- B10: sentence case for row labels; ALL CAPS only for headings --------
for old, new, why in [
        ('toggle("cb_float_ghost", "tv_float_ghost_status", "@string/ghost")',
         'toggle("cb_float_ghost", "tv_float_ghost_status", "Ghost")', "Ghost"),
        ('toggle("cb_float_freeze", "tv_float_freeze_status", "@string/freeze")',
         'toggle("cb_float_freeze", "tv_float_freeze_status", "Freeze")', "Freeze"),
        ('toggle("cb_float_tele", "tv_float_tele_status", "@string/tele")',
         'toggle("cb_float_tele", "tv_float_tele_status", "Teleport")', "Teleport"),
        ('"@string/floating_size", "@string/floating_size_hint"',
         '"Button size", "@string/floating_size_hint"', "Button size"),
        ('"@string/floating_alpha", "@string/floating_alpha_hint"',
         '"Button opacity", "@string/floating_alpha_hint"', "Button opacity"),
        ('"@string/match_mask_thickness", "@string/match_mask_thickness_hint"',
         '"Text size", "@string/match_mask_thickness_hint"', "Text size"),
        ('"@string/match_mask_length", "@string/match_mask_length_hint"',
         '"Width", "@string/match_mask_length_hint"', "Width")]:
    sub(old, new, "B10 sentence case: " + why)

# ---- B13: the track renders at 18.9dp against a declared 5dp -------------
sub('''            '                    android:progressDrawable="@drawable/nv_seek_track"\\n'
            '                    android:thumb="@drawable/nv_seek_thumb"\\n'
            '                    android:splitTrack="false" />\\n' ''',
'''            '                    android:progressDrawable="@drawable/nv_seek_track"\\n'
            '                    android:thumb="@drawable/nv_seek_thumb"\\n'
            '                    android:maxHeight="5dp"\\n'
            '                    android:minHeight="5dp"\\n'
            '                    android:splitTrack="false" />\\n' ''',
    "B13 SeekBar track pinned to 5dp")

io.open(P, 'w', encoding='utf-8').write(s)
print("gen_layout.py patched")
