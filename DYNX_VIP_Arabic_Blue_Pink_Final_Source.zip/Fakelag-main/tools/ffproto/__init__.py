"""Offline analysis package for the Free Fire Max match protocol.

Modules
-------
catalogue : reads ``net/CmdCatalogue.java`` — 1974 command ids, no duplication.
crypto    : CRC-7/MMC and QQ-TEA, ported from ``net/Crc7.java`` / ``net/Tea.java``.
framing   : MsgKey ranges, the XOR mask + HEAD_SECRET permutation, and the solver.
capture    : readers for the new streamed capture format and both old formats.
schema    : message-class field layouts (``FastBinaryReader`` wire order).
decode    : the ``FastBinaryReader`` walk — typed and untyped.
reports   : timeline, histogram, coverage, unknown inventory, capture diff.

Everything is standard library only.
"""

__all__ = [
    "catalogue", "crypto", "framing", "capture", "schema", "decode", "reports",
]
