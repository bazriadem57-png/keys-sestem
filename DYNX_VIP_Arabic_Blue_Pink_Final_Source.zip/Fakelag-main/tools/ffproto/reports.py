"""Reports over an :class:`ffproto.analyze.Analysis`.

Five reports, all of them answering a question the old Java-side analysis could
not:

``timeline``    lobby -> match -> rounds -> end, from the capture's ``phase`` /
                ``match`` columns and ``#`` lifecycle lines when it has them,
                and from the protocol itself when it does not.
``histogram``   every command id by volume, with real names, size distribution,
                channel and decode rate.  The map of what actually flows.
``coverage``    decoded ``n/total`` per id and the total unknown surface as a
                number.  The headline metric of the dumper rewrite.
``unknown``     for undecoded ids: field-count distribution and per-position
                value ranges, i.e. the raw material for the next round of
                reverse engineering.
``diff``        two captures side by side.  Replaces ``FreezeDiffAnalyzer``,
                which split on ``CaptureRecord.phase`` — a field whose setter
                (``setFreezePhase``) has zero callers, so every record in a
                freeze-off capture is ``BEFORE`` and the split never happened
                (brief §2 defect D2).  This one splits on whatever the caller
                asks for and always prints the size of each side, so a
                degenerate split is visible instead of silent.
"""

from __future__ import annotations

import collections

from . import analyze, catalogue, decode, schema

# ---------------------------------------------------------------- helpers

def _pct(a, b):
    return (100.0 * a / b) if b else 0.0


def _hms(ms):
    if ms is None:
        return "?"
    s = ms / 1000.0
    return "%d:%05.2f" % (int(s // 60), s % 60)


def _quantiles(counter):
    """min / p50 / p95 / max of a Counter of lengths."""
    if not counter:
        return (0, 0, 0, 0)
    items = sorted(counter.items())
    total = sum(counter.values())
    out, seen, want = [], 0, [0.5, 0.95]
    picks = []
    for value, n in items:
        seen += n
        while want and seen >= want[0] * total:
            picks.append(value)
            want.pop(0)
    while len(picks) < 2:
        picks.append(items[-1][0])
    return (items[0][0], picks[0], picks[1], items[-1][0])


# ---------------------------------------------------------------- timeline

#: Command ids that mark a session milestone.  Names are the game's own.
LIFECYCLE = {
    1: "transport hello",
    4: "transport byebye",
    100: "JOIN MATCH",
    130: "JOIN MATCH FINISHED",
    447: "JOIN MATCH PREPARE",
    448: "JOIN MATCH POST",
    110: "BATTLE START",
    103: "MATCH END",
    116: "SCENE INFO",
    899: "LOADING END",
    101: "player join",
    102: "player quit",
    117: "safe zone change",
    330: "safe zone rect change",
    415: "CS round result",
    416: "CS round result (spectator)",
    463: "CSSO round result",
    719: "LWSO round result",
    389: "PVE round notify",
}

#: Milestones that start or end a phase, in the order a session visits them.
PHASE_MARKS = (447, 100, 130, 448, 116, 899, 110, 103, 4)


def timeline(a, out=None):
    """Session timeline: phases, matches, endpoints, rounds, lifecycle events."""
    w = _Writer(out)
    w("== SESSION TIMELINE ==")
    w("capture files        : %d  (%s)" % (len(a.captures.files),
                                           ", ".join(a.captures.formats) or "?"))
    w("packets              : %d over %s" % (len(a.rows), _hms(a.span_ms())))

    has_phase = any(r.pkt.phase not in (None, "-") for r in a.rows)
    has_match = any(r.pkt.match not in (None, -1) for r in a.rows)
    w("phase column         : %s" % ("present" if has_phase else
                                     "ABSENT - old format has no SessionTimeline; "
                                     "the phases below are derived from the protocol"))
    w("match column         : %s" % ("present" if has_match else "ABSENT"))

    effects = collections.Counter()
    for r in a.rows:
        for e in (r.pkt.effects or ()):
            effects[e] += 1
    if effects:
        w("filter effects       : %s"
          % ", ".join("%s x%d" % (k, v) for k, v in effects.most_common()))
    else:
        w("filter effects       : none recorded (the phase column carries no "
          "/EFFECT suffix in this capture)")

    w("")
    w("-- endpoints (one solved header layout each) --")
    for ep, s in a.sessions.items():
        w("  %s" % s.describe())
        if s.layout:
            w("      DATALEN identity %d/%d, crc7 %d/%d = %.1f%%"
              % (s.hits, s.tested, s.crc_ok, s.crc_total,
                 _pct(s.crc_ok, s.crc_total)))

    if a.captures.events:
        w("")
        w("-- lifecycle events from the capture file --")
        for ev in a.captures.events[:200]:
            w("  @seq %-8s %s" % (ev.after_seq, ev.text))

    w("")
    w("-- phase / match transitions --")
    last = (None, None, None)
    shown = 0
    t0 = min((r.ts for r in a.rows if r.ts), default=0)
    for r in a.rows:
        cur = (r.pkt.phase, r.pkt.match, r.pkt.effects)
        if cur != last and (cur[0] not in (None, "-") or cur[1] not in (None, -1)):
            w("  +%-9s phase=%-12s match=%-4s effects=%s"
              % (_hms((r.ts or t0) - t0), cur[0], cur[1], r.pkt.effect_str))
            last = cur
            shown += 1
    if not shown:
        w("  (none in the file)")

    w("")
    w("-- protocol-derived milestones --")
    hits = 0
    for r in a.rows:
        if r.cmd in LIFECYCLE and r.status != analyze.UNPARSED:
            w("  +%-9s %-3s %-5d %-28s %s"
              % (_hms((r.ts or t0) - t0), r.direction, r.cmd,
                 catalogue.name_or(r.cmd), LIFECYCLE[r.cmd]))
            hits += 1
            if hits >= 400:
                w("  ... (more suppressed)")
                break
    if not hits:
        w("  (no lifecycle command ids in this capture — a pure in-match slice)")

    w("")
    w("-- endpoint changes over time --")
    prev = None
    for r in a.rows:
        if r.session and r.session != prev:
            w("  +%-9s %s" % (_hms((r.ts or t0) - t0), r.session))
            prev = r.session
    return w.text()


# ---------------------------------------------------------------- histogram

def histogram(a, out=None, limit=0):
    """Per-command histogram, sorted by volume."""
    w = _Writer(out)
    total = len(a.rows)
    w("== PER-COMMAND HISTOGRAM ==")
    w("%d packets, %d distinct (cmd, direction) pairs" % (total, len(a.cmd_stats)))
    w("")
    w("%-6s %-3s %-38s %7s %6s %-7s %5s %5s %5s %5s %-7s %s"
      % ("cmd", "dir", "name", "count", "%", "channel", "min", "p50", "p95",
         "max", "enc%", "decoded"))
    rows = sorted(a.cmd_stats.values(), key=lambda s: (-s.n, s.cmd))
    if limit:
        rows = rows[:limit]
    for s in rows:
        lo, p50, p95, hi = _quantiles(s.lens)
        w("%-6d %-3s %-38s %7d %5.1f%% %-7s %5d %5d %5d %5d %6.0f%% %d/%d %s"
          % (s.cmd, s.direction, s.name[:38], s.n, _pct(s.n, total),
             s.channel(), lo, p50, p95, hi, _pct(s.encrypted, s.n),
             s.ok, s.decodable,
             "" if s.decodable == 0 else "(%.0f%%)" % (100 * s.rate)))
    return w.text()


# ---------------------------------------------------------------- coverage

def coverage(a, out=None, worst=25):
    """Decode coverage — the headline metric."""
    w = _Writer(out)
    ok, decodable, total = a.coverage()
    ident = sum(1 for r in a.rows if r.cmd is not None)
    ids = len({c for c, _d in a.cmd_stats})
    known = sum(1 for r in a.rows if r.cmd is not None and catalogue.is_known(r.cmd))
    w("== DECODE COVERAGE ==")
    w("packets                 : %d" % total)
    w("header parsed           : %d/%d = %.2f%%" % (ident, total, _pct(ident, total)))
    w("command identified      : %d/%d = %.2f%%  (%d distinct ids, %d in the "
      "game's own catalogue)" % (known, total, _pct(known, total), ids,
                                 len({c for c, _d in a.cmd_stats
                                      if catalogue.is_known(c)})))
    w("decoded                 : %d/%d decodable = %.2f%%  (%.2f%% of all packets)"
      % (ok, decodable, _pct(ok, decodable), _pct(ok, total)))
    if a.inferred:
        w("inferred layouts        : %d (SHAPE ONLY - other direction's class, "
          "byte-exact on every sample)" % len(a.inferred))
        for (cmd, d), (cls, n) in sorted(a.inferred.items()):
            w("    %-6d %-3s %-20s %d/%d exact" % (cmd, d, cls, n, n))
    w("")
    w("-- where every packet went --")
    for st in analyze.STATUSES:
        n = a.status_counts[st]
        if not n:
            continue
        w("  %-12s %8d  %5.1f%%  %10d bytes" %
          (st, n, _pct(n, total), a.status_bytes[st]))
    w("")
    pk, by = 0, 0
    for st, (n, b) in a.unknown_surface().items():
        pk += n
        by += b
    w("UNKNOWN SURFACE         : %d packets, %d bytes (%.1f%% of packets)"
      % (pk, by, _pct(pk, total)))
    reasons = a.unknown_surface()
    w("  no layout             : %d pkts / %d B" % reasons[analyze.NO_LAYOUT])
    w("  decode failed         : %d pkts / %d B" % reasons[analyze.DECODE_FAIL])
    w("  encrypted, no key     : %d pkts / %d B" % reasons[analyze.NO_KEY])
    w("  encrypted, wrong key  : %d pkts / %d B" % reasons[analyze.TEA_FAIL])
    w("  zipped (needs key)    : %d pkts / %d B" % reasons[analyze.ZIPPED])
    w("  payload truncated     : %d pkts / %d B" % reasons[analyze.TRUNCATED])
    w("  not match traffic     : %d pkts / %d B" % reasons[analyze.UNPARSED])

    if a.column_cmd_checked:
        w("")
        w("-- cross-check against the capture's own cmd column --")
        w("  checked %d, agree %d, DISAGREE %d (%.2f%%)"
          % (a.column_cmd_checked, a.column_cmd_agree, a.column_cmd_disagree,
             _pct(a.column_cmd_disagree, a.column_cmd_checked)))

    w("")
    w("-- per (cmd, direction), worst decode rate first --")
    w("%-6s %-3s %-38s %8s %8s  %s" % ("cmd", "dir", "name", "decoded",
                                       "of", "top failure"))
    rows = [s for s in a.cmd_stats.values() if s.decodable]
    rows.sort(key=lambda s: (s.rate, -s.n))
    for s in rows[:worst]:
        top = ""
        if s.errors:
            e, n = s.errors.most_common(1)[0]
            top = "%s x%d" % (e, n)
        elif s.no_layout:
            top = "no layout for this (cmd, direction)"
        w("%-6d %-3s %-38s %8d %8d  %s"
          % (s.cmd, s.direction, s.name[:38], s.ok, s.decodable, top))

    w("")
    w("-- schema reach --")
    cov = a.schema.coverage()
    w("  classes indexed       : %d   enums indexed: %d"
      % (cov["classes_indexed"], cov["enums_indexed"]))
    for d in (schema.IN, schema.OUT):
        c = cov[d]
        w("  %-3s ids with a class  : %d, layout resolves for %d, fully typed %d"
          % (d, c["ids_with_class"], c["ids_with_layout"],
             c["ids_fully_resolved"]))
    return w.text()


# ---------------------------------------------------------------- unknown

def unknown_inventory(a, out=None, top=40, samples=6, max_positions=24):
    """Field-shape inventory for everything that did not decode.

    For each undecoded ``(cmd, direction)`` this runs the untyped positional
    walk over its bodies and reports the field-count distribution plus the
    value range at each position — the raw material for identifying the layout.
    A walk that does not land exactly on the body boundary is counted
    separately, because that is the signature of a ``ReadByte`` /
    ``ReadBoolean`` / ``ReadFixUInt16`` field breaking the varint stream, and
    it tells you *where* to look.
    """
    w = _Writer(out)
    w("== UNKNOWN-FIELD INVENTORY ==")
    buckets = collections.OrderedDict()
    for r in a.rows:
        if r.status not in (analyze.NO_LAYOUT, analyze.DECODE_FAIL):
            continue
        if r.body is None:
            continue
        buckets.setdefault((r.cmd, r.direction), []).append(r)
    if not buckets:
        w("(nothing undecoded that has a readable body)")
        return w.text()
    order = sorted(buckets.items(), key=lambda kv: -len(kv[1]))
    w("%d undecoded (cmd, direction) pairs with readable bodies, %d packets"
      % (len(order), sum(len(v) for _k, v in order)))
    for (cmd, direction), rows in order[:top]:
        st = a.cmd_stats.get((cmd, direction))
        lay = a.schema.layout(cmd, direction)
        w("")
        w("-- %d %s %s   n=%d  len %d..%d" %
          (cmd, direction, catalogue.name_or(cmd), len(rows),
           st.min_len if st else 0, st.max_len if st else 0))
        cls = a.schema.class_for(cmd, direction)
        w("   class: %s   layout: %s" %
          (cls or "(none in the registry)",
           "resolved but the walk failed" if lay else "none"))
        if st and st.errors:
            for e, n in st.errors.most_common(3):
                w("   failure: %s  x%d" % (e, n))

        counts = collections.Counter()
        clean = 0
        pos = collections.defaultdict(lambda: [None, None, collections.Counter()])
        for r in rows:
            d, slots = decode.decode_untyped(r.body, limit=max_positions * 2)
            counts[len(slots)] += 1
            if d.clean:
                clean += 1
            for s in slots[:max_positions]:
                p = pos[s.index]
                p[0] = s.raw if p[0] is None else min(p[0], s.raw)
                p[1] = s.raw if p[1] is None else max(p[1], s.raw)
                if len(p[2]) < 64:
                    p[2][s.raw] += 1
        w("   clean varint walk: %d/%d (%.0f%%) - a low rate means a RAW byte "
          "or fix16 field breaks the stream" % (clean, len(rows),
                                                _pct(clean, len(rows))))
        w("   field counts: %s" % ", ".join(
            "%d fields x%d" % (k, v) for k, v in counts.most_common(6)))
        w("   position  %-12s %-14s %-7s  common values" % ("min", "max", "distinct"))
        for idx in sorted(pos)[:max_positions]:
            lo, hi, c = pos[idx]
            common = ", ".join("%d" % v for v, _n in c.most_common(4))
            w("     v%-6d %-12d %-14d %-7s  %s"
              % (idx, lo, hi, len(c) if len(c) < 64 else "64+", common))
        for r in rows[:samples]:
            w("   sample len=%d %s" % (len(r.body), r.body[:48].hex()))
    if len(order) > top:
        w("")
        w("... %d more undecoded pairs not shown" % (len(order) - top))
    return w.text()


# ---------------------------------------------------------------- diff

def diff(a, b, out=None, label_a="A", label_b="B", top=40):
    """Compare two analyses — freeze on/off, two game modes, two builds."""
    w = _Writer(out)
    w("== CAPTURE DIFF: %s vs %s ==" % (label_a, label_b))
    sa, sb = a.span_ms() / 1000.0 or 1.0, b.span_ms() / 1000.0 or 1.0
    w("%-24s %14s %14s" % ("", label_a, label_b))
    w("%-24s %14d %14d" % ("packets", len(a.rows), len(b.rows)))
    w("%-24s %14.1f %14.1f" % ("span (s)", sa, sb))
    w("%-24s %14.1f %14.1f" % ("packets/s", len(a.rows) / sa, len(b.rows) / sb))
    for d in ("IN", "OUT"):
        na = sum(1 for r in a.rows if r.direction == d)
        nb = sum(1 for r in b.rows if r.direction == d)
        w("%-24s %14.1f %14.1f" % ("%s packets/s" % d, na / sa, nb / sb))
    for d in ("IN", "OUT"):
        ba = sum(r.pkt.length or 0 for r in a.rows if r.direction == d)
        bb = sum(r.pkt.length or 0 for r in b.rows if r.direction == d)
        w("%-24s %14.0f %14.0f" % ("%s bytes/s" % d, ba / sa, bb / sb))

    w("")
    w("-- decisions (what the app did to each packet) --")
    da = collections.Counter(r.pkt.decision for r in a.rows)
    db = collections.Counter(r.pkt.decision for r in b.rows)
    for k in sorted(set(da) | set(db), key=lambda x: str(x)):
        w("  %-20s %8d %8d" % (k, da[k], db[k]))
    if len(da) <= 1 and len(db) <= 1:
        w("  NOTE: the decision column never varies in either capture, so a "
          "split on it would be degenerate.")

    w("")
    w("-- decode coverage --")
    oka, deca, tota = a.coverage()
    okb, decb, totb = b.coverage()
    w("  %-20s %8s %8s" % ("", label_a, label_b))
    w("  %-20s %7.2f%% %7.2f%%" % ("decoded/decodable", _pct(oka, deca),
                                   _pct(okb, decb)))
    for st in analyze.STATUSES:
        if a.status_counts[st] or b.status_counts[st]:
            w("  %-20s %8d %8d" % (st, a.status_counts[st], b.status_counts[st]))

    w("")
    w("-- per-command rate, biggest change first --")
    keys = set(a.cmd_stats) | set(b.cmd_stats)
    rows = []
    for k in keys:
        ra = (a.cmd_stats[k].n / sa) if k in a.cmd_stats else 0.0
        rb = (b.cmd_stats[k].n / sb) if k in b.cmd_stats else 0.0
        rows.append((abs(rb - ra), k, ra, rb))
    rows.sort(reverse=True)
    w("  %-6s %-3s %-34s %10s %10s %10s" %
      ("cmd", "dir", "name", label_a + "/s", label_b + "/s", "delta%"))
    for _mag, (cmd, d), ra, rb in rows[:top]:
        delta = _pct(rb - ra, ra) if ra else (float("inf") if rb else 0.0)
        w("  %-6d %-3s %-34s %10.2f %10.2f %10s"
          % (cmd, d, catalogue.name_or(cmd)[:34], ra, rb,
             "new" if ra == 0 else ("gone" if rb == 0 else "%+.0f%%" % delta)))

    only_a = sorted(set(a.cmd_stats) - set(b.cmd_stats))
    only_b = sorted(set(b.cmd_stats) - set(a.cmd_stats))
    w("")
    w("-- present only in %s (%d) --" % (label_a, len(only_a)))
    for cmd, d in only_a[:top]:
        w("  %-6d %-3s %s" % (cmd, d, catalogue.name_or(cmd)))
    w("-- present only in %s (%d) --" % (label_b, len(only_b)))
    for cmd, d in only_b[:top]:
        w("  %-6d %-3s %s" % (cmd, d, catalogue.name_or(cmd)))
    return w.text()


# ---------------------------------------------------------------- summary

def summary(a, out=None):
    parts = [timeline(a), "", coverage(a), "", histogram(a, limit=60)]
    text = "\n".join(parts)
    if out:
        out.write(text + "\n")
    return text


class _Writer(object):
    """Collects lines and optionally streams them."""

    def __init__(self, out=None):
        self.lines = []
        self.out = out

    def __call__(self, line=""):
        self.lines.append(line)
        if self.out:
            self.out.write(line + "\n")

    def text(self):
        return "\n".join(self.lines)
