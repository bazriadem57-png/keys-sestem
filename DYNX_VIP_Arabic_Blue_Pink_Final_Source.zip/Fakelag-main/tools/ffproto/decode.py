"""The body decoder — a Python ``FastBinaryReader``.

Two modes.

**Typed** (:func:`decode_typed`) walks a :class:`ffproto.schema.Layout`, so it
consumes ``byte``/``bool`` as **1 RAW byte** and ``ReadFixUInt16`` as **2 RAW
little-endian bytes** instead of varints.  Those two are the traps that break a
naive varint walk (``IL2CPP_FINDINGS.md`` §3) and they are the whole reason a
layout is worth having.  Success is defined strictly: no overrun **and**
``consumed == len(body)``.  Anything looser would let a desynced walk report
success.

**Untyped** (:func:`decode_untyped`) is the fallback for the ~1900 ids with no
layout: a positional LEB128 walk that reports every value in all of its
plausible readings — raw varint, zigzag-signed, and float32-from-bits.  It is
honest about what it is: a naive varint walk desyncs at the first raw byte with
the high bit set, so the walk reports whether it landed exactly on the body
boundary (``clean``) and consumers must treat a non-clean walk as noise.
"""

from __future__ import annotations

import struct

from . import schema

MASK64 = (1 << 64) - 1


class Overrun(Exception):
    """The body ran out mid-field."""


# ---------------------------------------------------------------- reader

class Reader(object):
    """``FastBinaryReader`` over a plaintext body."""

    __slots__ = ("data", "pos", "end")

    def __init__(self, data, off=0, end=None):
        self.data = data
        self.pos = off
        self.end = len(data) if end is None else end

    @property
    def remaining(self):
        return self.end - self.pos

    def varint(self):
        """Plain LEB128 — ``ReadUInt16/32/64``."""
        v = 0
        shift = 0
        while True:
            if self.pos >= self.end:
                raise Overrun("varint ran off the end at %d" % self.pos)
            c = self.data[self.pos]
            self.pos += 1
            v |= (c & 0x7F) << shift
            if not (c & 0x80):
                return v & MASK64
            shift += 7
            if shift > 63:
                raise Overrun("varint longer than 10 bytes at %d" % self.pos)

    def zigzag(self):
        """``ReadInt16/32/64`` — varint then zigzag."""
        return zz(self.varint())

    def f32(self):
        """``ReadSingle`` — one varint whose bits ARE the float32."""
        return struct.unpack("<f", struct.pack("<I", self.varint() & 0xFFFFFFFF))[0]

    def f64(self):
        return struct.unpack("<d", struct.pack("<Q", self.varint() & MASK64))[0]

    def raw1(self):
        """``ReadByte`` / ``ReadBoolean`` — 1 RAW byte, never a varint."""
        if self.pos >= self.end:
            raise Overrun("raw byte ran off the end at %d" % self.pos)
        b = self.data[self.pos]
        self.pos += 1
        return b

    def fix16(self):
        """``ReadFixUInt16`` — 2 RAW little-endian bytes, never a varint."""
        if self.pos + 2 > self.end:
            raise Overrun("fix16 ran off the end at %d" % self.pos)
        v = self.data[self.pos] | (self.data[self.pos + 1] << 8)
        self.pos += 2
        return v

    def string(self):
        """``[zigzag varint length][UTF-8]``."""
        n = self.zigzag()
        if n < 0 or self.pos + n > self.end:
            raise Overrun("string length %d at %d" % (n, self.pos))
        s = self.data[self.pos:self.pos + n]
        self.pos += n
        try:
            return s.decode("utf-8")
        except UnicodeDecodeError:
            return s.decode("latin-1")

    def count(self):
        """``List<T>`` element count — a zigzag varint."""
        return self.zigzag()


def zz(v):
    """Zigzag decode (protobuf ``sint``)."""
    v &= MASK64
    out = (v >> 1) ^ -(v & 1)
    if out >= (1 << 63):
        out -= (1 << 64)
    return out


def f32_of(v):
    return struct.unpack("<f", struct.pack("<I", v & 0xFFFFFFFF))[0]


# ---------------------------------------------------------------- results

class Field(object):
    """One decoded value."""

    __slots__ = ("index", "path", "kind", "ctype", "value", "label", "offset")

    def __init__(self, index, path, kind, ctype, value, offset, label=None):
        self.index = index
        self.path = path
        self.kind = kind
        self.ctype = ctype
        self.value = value
        self.offset = offset
        self.label = label

    def __repr__(self):
        return "%s=%r" % (self.path, self.value)


class Decoded(object):
    """The result of one body decode."""

    __slots__ = ("ok", "mode", "cls", "fields", "consumed", "body_len",
                 "error", "clean", "note")

    def __init__(self, ok, mode, cls, fields, consumed, body_len,
                 error=None, clean=False, note=None):
        self.ok = ok
        self.mode = mode              # 'typed' | 'untyped'
        self.cls = cls
        self.fields = fields
        self.consumed = consumed
        self.body_len = body_len
        self.error = error
        self.clean = clean
        self.note = note

    @property
    def leftover(self):
        return self.body_len - self.consumed

    def values(self):
        return [f.value for f in self.fields]

    def __repr__(self):
        return ("Decoded(%s %s %s %d/%d fields=%d%s)"
                % (self.mode, self.cls or "-", "OK" if self.ok else "FAIL",
                   self.consumed, self.body_len, len(self.fields),
                   "" if not self.error else " err=" + str(self.error)))

    def format(self, max_fields=64):
        out = []
        for f in self.fields[:max_fields]:
            v = f.value
            if isinstance(v, float):
                txt = "%.6g" % v
            elif isinstance(v, bytes):
                txt = v[:16].hex()
            else:
                txt = str(v)
            bit = "%s=%s" % (f.path, txt)
            if f.label:
                bit += "(%s)" % f.label
            out.append(bit)
        if len(self.fields) > max_fields:
            out.append("...+%d" % (len(self.fields) - max_fields))
        return " ".join(out)


# ---------------------------------------------------------------- typed

_PRIM_READ = {
    schema.KIND_RAW1: "raw1",
    schema.KIND_FIX16: "fix16",
    schema.KIND_VARINT: "varint",
    schema.KIND_ZIGZAG: "zigzag",
    schema.KIND_F32: "f32",
    schema.KIND_F64: "f64",
    schema.KIND_STRING: "string",
}

MAX_LIST = 4096


def decode_typed(layout, body, notes=None):
    """Decode ``body`` against ``layout``.  Never raises."""
    if layout is None or body is None:
        return Decoded(False, "typed", None, [], 0, len(body or b""),
                       error="no layout")
    r = Reader(body)
    fields = []
    state = {"n": 0}
    try:
        _walk(layout.root, r, fields, state, layout.cls, notes)
        ok = (r.pos == r.end)
        err = None if ok else "%d trailing byte(s)" % (r.end - r.pos)
    except Overrun as exc:
        ok, err = False, str(exc)
    except RecursionError:
        ok, err = False, "layout recursion"
    return Decoded(ok, "typed", layout.cls, fields, r.pos, len(body), error=err)


def _walk(node, r, fields, state, prefix, notes):
    kind = node.kind
    if kind == "struct":
        for child in node.children:
            _walk(child, r, fields, state, prefix, notes)
        return
    if kind == "list":
        n = r.count()
        if n < 0 or n > MAX_LIST:
            raise Overrun("list count %d at %d" % (n, r.pos))
        fields.append(Field(state["n"], "%s#n" % node.name, "count",
                            node.ctype, n, r.pos))
        state["n"] += 1
        for i in range(n):
            elem = node.elem
            saved = elem.name
            elem.name = "%s[%d]" % (node.name, i)
            try:
                _walk(elem, r, fields, state, prefix, notes)
            finally:
                elem.name = saved
        return
    if kind == "opaque":
        raise Overrun("opaque type %s (%s)" % (node.ctype, node.name))

    method = _PRIM_READ.get(kind)
    if method is None:
        raise Overrun("unknown kind %s" % kind)
    off = r.pos
    value = getattr(r, method)()
    label = None
    if node.enum:
        label = node.enum.get(str(value)) or node.enum.get(value)
    idx = state["n"]
    if notes:
        label = notes.get(idx, label)
    fields.append(Field(idx, node.name, kind, node.ctype, value, off, label))
    state["n"] += 1


# ---------------------------------------------------------------- untyped

class Slot(object):
    """One position in an untyped walk, with every plausible reading."""

    __slots__ = ("index", "offset", "nbytes", "raw", "signed", "f32")

    def __init__(self, index, offset, nbytes, raw):
        self.index = index
        self.offset = offset
        self.nbytes = nbytes
        self.raw = raw
        self.signed = zz(raw)
        self.f32 = f32_of(raw) if raw <= 0xFFFFFFFF else None

    def __repr__(self):
        return "v%d=%d" % (self.index, self.raw)

    def describe(self):
        bits = ["v%d=%d" % (self.index, self.raw)]
        if self.signed != self.raw:
            bits.append("zz=%d" % self.signed)
        if self.f32 is not None and _interesting_float(self.f32):
            bits.append("f32=%.6g" % self.f32)
        return "/".join(bits)


def _interesting_float(x):
    if x != x or x in (float("inf"), float("-inf")):
        return False
    a = abs(x)
    return a == 0.0 or (1e-4 < a < 1e6)


def decode_untyped(body, limit=256):
    """Naive positional LEB128 walk with all plausible readings.

    ``clean`` is True only when the walk ends exactly on the body boundary.  A
    non-clean walk has desynced — almost always on a ``ReadByte`` /
    ``ReadBoolean`` whose value was >= 128, or on a ``ReadFixUInt16``.
    """
    slots = []
    r = Reader(body)
    try:
        while r.pos < r.end and len(slots) < limit:
            off = r.pos
            v = r.varint()
            slots.append(Slot(len(slots), off, r.pos - off, v))
        clean = (r.pos == r.end)
        err = None if clean else "desynced or truncated"
    except Overrun as exc:
        clean, err = False, str(exc)
    fields = [Field(s.index, "v%d" % s.index, "varint?", "?", s.raw, s.offset)
              for s in slots]
    d = Decoded(clean, "untyped", None, fields, r.pos, len(body),
                error=err, clean=clean,
                note="naive varint walk; raw bytes and fix16 fields desync it")
    return d, slots


def untyped_line(body, limit=48):
    """One-line positional dump with interpretations, for the ``note`` column."""
    _d, slots = decode_untyped(body, limit)
    return " ".join(s.describe() for s in slots)


# ---------------------------------------------------------------- driver

class BodyDecoder(object):
    """Decodes bodies for a capture, keyed on ``(cmd, direction)``.

    Tracks per-key success counts so a run can report decode coverage as
    ``n/total`` — the headline metric of the dumper rewrite.
    """

    def __init__(self, sch=None):
        self.schema = sch or schema.default_schema()
        self.stats = {}        # (cmd, dir) -> [ok, total, bytes_ok, bytes_tot]
        self.errors = {}       # (cmd, dir) -> Counter of error strings

    def decode(self, cmd, direction, body):
        """Typed decode when a layout exists, else ``None``.  Counts the try."""
        key = (cmd, direction)
        st = self.stats.get(key)
        if st is None:
            st = self.stats[key] = [0, 0, 0, 0]
        lay = self.schema.layout(cmd, direction)
        st[1] += 1
        st[3] += len(body)
        if lay is None:
            self._err(key, "no layout")
            return None
        notes = schema.VERIFIED_NOTES.get(key)
        d = decode_typed(lay, body, notes)
        if d.ok:
            st[0] += 1
            st[2] += len(body)
        else:
            self._err(key, d.error or "fail")
        return d

    def _err(self, key, msg):
        import collections
        c = self.errors.get(key)
        if c is None:
            c = self.errors[key] = collections.Counter()
        c[msg] += 1

    def coverage(self):
        """``{(cmd, dir): (ok, total)}`` plus overall totals."""
        ok = sum(v[0] for v in self.stats.values())
        tot = sum(v[1] for v in self.stats.values())
        return ok, tot

    def unknown_surface(self):
        """Packets whose body we could not decode, and their byte volume."""
        pk = by = 0
        for (_cmd, _d), v in self.stats.items():
            pk += v[1] - v[0]
            by += v[3] - v[2]
        return pk, by
