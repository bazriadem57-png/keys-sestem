"""CRC-7/MMC and QQ-TEA — direct ports of ``net/Crc7.java`` and ``net/Tea.java``.

CRC-7
-----
``packet[1] == crc7(packet[2:])`` with seed 0.  The table is the Linux
``crc7_syndrome_table`` shifted right by one; it is generated rather than
transcribed so there is nothing to mistype.

QQ-TEA
------
16 rounds, little-endian words, ``DELTA=0x9E3779B9``, ``SALT_LEN=2``,
``ZERO_LEN=7``, CBC-chained over 8-byte blocks::

    [padCount byte][padCount zeros][2 salt zeros][plaintext][7 zeros]
    encLen = align8(plainLen + 10)

``rand()`` is stubbed to ``return 0`` in the shipped binary, so the salt bytes
are always zero and the seven-zero tail is a free decryption oracle.  A decrypt
whose tail is not seven zeros is rejected rather than returned as garbage.
"""

from __future__ import annotations

import struct

# ---------------------------------------------------------------- constants

DELTA = 0x9E3779B9
ROUNDS = 16
SALT_LEN = 2
ZERO_LEN = 7
BLOCK_BYTES = 8
KEY_BYTES = 16
FRAME_OVERHEAD = 1 + SALT_LEN + ZERO_LEN
MIN_CIPHERTEXT = 16
MASK32 = 0xFFFFFFFF


# ---------------------------------------------------------------- CRC-7/MMC

def _build_crc7_table():
    table = []
    for i in range(256):
        c = i
        for _ in range(8):
            c = ((c << 1) ^ 0x12) if (c & 0x80) else (c << 1)
            c &= 0xFF
        table.append(c >> 1)
    return table


CRC7_TABLE = _build_crc7_table()


def crc7(buf, off=0, length=None, seed=0):
    """CRC-7/MMC over ``buf[off:off+length]``."""
    if length is None:
        length = len(buf) - off
    crc = seed & 0x7F
    for i in range(off, off + length):
        crc = CRC7_TABLE[(buf[i] ^ ((crc << 1) & 0xFF)) & 0xFF]
    return crc


def crc7_of_packet(pkt, off=0, length=None):
    """The checksum a packet should carry: CRC-7 over byte 2 to the end."""
    if length is None:
        length = len(pkt) - off
    if length < 3:
        return -1
    return crc7(pkt, off + 2, length - 2)


def crc7_verify(pkt, off=0, length=None):
    if length is None:
        length = len(pkt) - off
    if length < 3 or off + length > len(pkt):
        return False
    return pkt[off + 1] == crc7_of_packet(pkt, off, length)


# ---------------------------------------------------------------- TEA core

def key_schedule(key):
    """The four little-endian key words, or ``None`` when the key is short."""
    if key is None or len(key) < KEY_BYTES:
        return None
    return struct.unpack_from("<4I", key, 0)


def _decrypt_words(v0, v1, k):
    k0, k1, k2, k3 = k
    s = (DELTA * ROUNDS) & MASK32
    for _ in range(ROUNDS):
        v1 = (v1 - ((((v0 << 4) & MASK32) + k2) ^ ((v0 + s) & MASK32)
                    ^ ((v0 >> 5) + k3))) & MASK32
        v0 = (v0 - ((((v1 << 4) & MASK32) + k0) ^ ((v1 + s) & MASK32)
                    ^ ((v1 >> 5) + k1))) & MASK32
        s = (s - DELTA) & MASK32
    return v0, v1


def _encrypt_words(v0, v1, k):
    k0, k1, k2, k3 = k
    s = 0
    for _ in range(ROUNDS):
        s = (s + DELTA) & MASK32
        v0 = (v0 + ((((v1 << 4) & MASK32) + k0) ^ ((v1 + s) & MASK32)
                    ^ ((v1 >> 5) + k1))) & MASK32
        v1 = (v1 + ((((v0 << 4) & MASK32) + k2) ^ ((v0 + s) & MASK32)
                    ^ ((v0 >> 5) + k3))) & MASK32
    return v0, v1


def tea_decrypt_block(blk, k):
    v0, v1 = struct.unpack("<2I", blk)
    return struct.pack("<2I", *_decrypt_words(v0, v1, k))


def tea_encrypt_block(blk, k):
    v0, v1 = struct.unpack("<2I", blk)
    return struct.pack("<2I", *_encrypt_words(v0, v1, k))


# ---------------------------------------------------------------- QQ-TEA

def qqtea_encrypt_len(plain_len):
    """``align8(plainLen + 10)``."""
    n = plain_len + FRAME_OVERHEAD
    r = n & 7
    return n if r == 0 else n + (8 - r)


def qqtea_decrypt(data, key, strict=True):
    """Decrypt a QQ-TEA payload.

    Returns ``(plaintext, tail_ok)``.  With ``strict`` the plaintext is
    ``None`` unless the seven-zero tail verifies — that is the oracle that
    tells a right key from a wrong one, and it measured 138/138 and 339/339 on
    live captures.  With ``strict=False`` the best-effort plaintext is returned
    alongside the tail flag, for probing.
    """
    k = key_schedule(key) if not isinstance(key, tuple) else key
    if k is None or data is None:
        return None, False
    n = len(data)
    if n < MIN_CIPHERTEXT or (n & 7):
        return None, False

    v0, v1 = struct.unpack_from("<2I", data, 0)
    p0, p1 = _decrypt_words(v0, v1, k)
    out = bytearray(n)
    struct.pack_into("<2I", out, 0, p0, p1)
    pc0, pc1 = v0, v1
    for i in range(BLOCK_BYTES, n, BLOCK_BYTES):
        c0, c1 = struct.unpack_from("<2I", data, i)
        d0, d1 = _decrypt_words(c0 ^ p0, c1 ^ p1, k)
        struct.pack_into("<2I", out, i, d0 ^ pc0, d1 ^ pc1)
        p0, p1, pc0, pc1 = d0, d1, c0, c1

    pad = out[0] & 7
    plain_len = n - pad - FRAME_OVERHEAD
    if plain_len < 0:
        return None, False
    start = 1 + pad + SALT_LEN
    plain = bytes(out[start:start + plain_len])
    tail = out[start + plain_len:start + plain_len + ZERO_LEN]
    ok = len(tail) == ZERO_LEN and not any(tail)
    if strict and not ok:
        return None, False
    return plain, ok


def qqtea_encrypt(plain, key):
    """Inverse of :func:`qqtea_decrypt`; returns the ciphertext bytes."""
    k = key_schedule(key) if not isinstance(key, tuple) else key
    if k is None or plain is None:
        return None
    enc_len = qqtea_encrypt_len(len(plain))
    pad = enc_len - len(plain) - FRAME_OVERHEAD
    buf = bytearray(enc_len)
    buf[0] = pad                       # rand() is stubbed to 0
    buf[1 + pad + SALT_LEN:1 + pad + SALT_LEN + len(plain)] = plain

    pd0, pd1 = struct.unpack_from("<2I", buf, 0)
    c0, c1 = _encrypt_words(pd0, pd1, k)
    struct.pack_into("<2I", buf, 0, c0, c1)
    pc0, pc1 = c0, c1
    for i in range(BLOCK_BYTES, enc_len, BLOCK_BYTES):
        s0, s1 = struct.unpack_from("<2I", buf, i)
        d0, d1 = s0 ^ pc0, s1 ^ pc1
        e0, e1 = _encrypt_words(d0, d1, k)
        c0, c1 = e0 ^ pd0, e1 ^ pd1
        struct.pack_into("<2I", buf, i, c0, c1)
        pd0, pd1, pc0, pc1 = d0, d1, c0, c1
    return bytes(buf)


if __name__ == "__main__":
    # Round-trip self-test; no capture or key needed.
    key = bytes(range(16))
    for n in (0, 1, 5, 6, 7, 8, 23, 64, 200):
        msg = bytes((i * 37 + 11) & 0xFF for i in range(n))
        ct = qqtea_encrypt(msg, key)
        assert len(ct) == qqtea_encrypt_len(n), (n, len(ct))
        pt, ok = qqtea_decrypt(ct, key)
        assert ok and pt == msg, (n, pt, msg)
    pkt = bytearray(b"\x5a\x00" + bytes(range(30)))
    pkt[1] = crc7_of_packet(pkt)
    assert crc7_verify(pkt)
    print("crypto self-test OK (qqtea round trip 9/9, crc7 1/1)")
