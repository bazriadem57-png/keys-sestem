"""Capture-file readers.

Three on-disk formats are understood.

NEW — ``docs/DUMPER_REWRITE_BRIEF.md`` §4.4 as the writer actually emits it::

    seq ts_ms dt_us src dir decision phase match cmd cmdname flags peer sp dp
        len hexlen payload_hex note

18 positional columns; ``note`` is free text and always last.  ``#`` lines are
header/comment/lifecycle/footer lines and may appear between records.

Four details of the real writer that the brief's column list does not show, and
that each silently shift every later column if mishandled:

* **``phase`` is ``PHASE[/EFFECT|EFFECT]`` as one whitespace-free token** —
  ``MATCH``, ``UNKNOWN/FREEZE``, ``MATCH/FREEZE|GHOST|JITTER``.  The active
  filter-effect mask did not get a column of its own, it is suffixed here.
  Split on ``/``: left is the :class:`SessionTimeline` phase (``Packet.phase``),
  right is the effect list (``Packet.effects``).
* **An empty ``payload_hex`` or ``note`` is written as ``-``, never blank** —
  a blank would shift the columns after it.  A lone ``-`` means empty.
* **``note`` is compound**: zero or more whitespace-free ``kind=`` / ``tele=``
  / ``ord=`` tokens, then free decode text from the annotator which may contain
  spaces.  It is always last, so the rest of the line is consumed verbatim; the
  leading tokens are also lifted out into ``note_kind`` / ``note_tele`` /
  ``note_ord`` and the remainder into ``note_text``.
* **``dt_us == 0`` on retro (pre-press) records is by design**, not a missing
  value — those records predate the press and any delta would be invented.

Rotation: one session becomes ``capture_raw_<stamp>_001.txt``, ``_002.txt``, …
at 32 MB each.  Every part repeats the column header and its ``# secret_key=``
line, so each part is independently decodable; the footer (``# drops``,
``# by_src``, ``# coverage``) appears only on the last part.  Parts are ordered
numerically and a missing footer is NOT treated as truncation — only a missing
final newline is.

OLD-13 — ``seq ts phase dir decision dip sp dp len type family kind payload_hex``
OLD-11 — ``seq ts phase dir decision dip sp dp len type payload_hex``

What the old formats CANNOT supply, and why every consumer must treat these as
``None`` rather than defaulting them:

======================  ==========================================================
field                   why it is missing
======================  ==========================================================
``cmd`` / ``cmdname``   never parsed; the old dumper classified by byte shape
``flags``               ``F_PARSED/CRC_OK/RELIABLE/ENCRYPTED/...`` did not exist
``src``                 UDP only — ``TcpProxy`` had no capture call (defect D1)
``dt_us``               only millisecond wall-clock timestamps were written
``phase`` / ``match``   no ``SessionTimeline``; the old ``phase`` column is the
                        freeze phase, exposed here as ``legacy_phase``, and
                        defect D2 means it is constant in most files
``note``                no decoded field dump existed
======================  ==========================================================

``legacy_type`` / ``legacy_family`` / ``legacy_kind`` carry the old byte-shape
classification, which is exactly what the rewrite replaces; they are kept only
so old captures stay comparable.

Truncation is a feature, not corruption: the writer streams to disk, so a
capture killed mid-session ends mid-line.  The reader parses every complete
line and, when the tail line still carries all fixed columns, emits it with
``partial=True``.
"""

from __future__ import annotations

import glob as _glob
import io
import os

# ---------------------------------------------------------------- constants

FMT_NEW = "new"
FMT_OLD13 = "old13"
FMT_OLD11 = "old11"

NEW_COLUMNS = ("seq ts_ms dt_us src dir decision phase match cmd cmdname flags "
               "peer sp dp len hexlen payload_hex note").split()
OLD13_COLUMNS = ("seq ts phase dir decision dip sp dp len type family kind "
                 "payload_hex").split()
OLD11_COLUMNS = "seq ts phase dir decision dip sp dp len type payload_hex".split()

# CaptureEvent.F_* — brief §4.1
F_PARSED = 1 << 0
F_CRC_OK = 1 << 1
F_RELIABLE = 1 << 2
F_ENCRYPTED = 1 << 3
F_DECRYPTED = 1 << 4
F_ZIPPED = 1 << 5
F_LEN_MATCH = 1 << 6
F_PRESOLVER = 1 << 7

FLAG_NAMES = [(F_PARSED, "PARSED"), (F_CRC_OK, "CRC_OK"), (F_RELIABLE, "RELIABLE"),
              (F_ENCRYPTED, "ENCRYPTED"), (F_DECRYPTED, "DECRYPTED"),
              (F_ZIPPED, "ZIPPED"), (F_LEN_MATCH, "LEN_MATCH"),
              (F_PRESOLVER, "PRESOLVER")]

SRC_NAMES = {0: "UDP", 1: "TCP", 2: "CTRL"}


def flag_str(flags):
    if flags is None:
        return "-"
    hits = [n for bit, n in FLAG_NAMES if flags & bit]
    return "|".join(hits) if hits else "0"


_HEXDIGITS = frozenset("0123456789abcdefABCDEF")


def _unhex(text):
    """Bytes from a hex string, tolerating an odd/garbage tail.

    Returns ``(data, clean)``.  ``clean`` is False when the string had to be
    cut — an odd final nibble or a non-hex character, which is what a
    mid-write kill leaves behind.
    """
    if not text or text == "-":
        return b"", True
    clean = True
    cut = len(text)
    for i, ch in enumerate(text):
        if ch not in _HEXDIGITS:
            cut = i
            clean = False
            break
    if cut & 1:
        cut -= 1
        clean = False
    try:
        return bytes.fromhex(text[:cut]), clean
    except ValueError:
        return b"", False


def _kv_pairs(body):
    """Header ``key=value`` pairs from a ``#`` line, or ``None``.

    A header line always starts with ``key=``; a lifecycle line does not (it
    reads like ``MATCH mode=CS_RANKED srv=1.2.3.4:9001 round=3``), so the first
    token decides.  When *every* token carries an ``=`` the line holds several
    pairs (``records=723 dropped_by_cap=0``); otherwise the value itself
    contains spaces (``started=2026-09-10 17:52:08.990``) and the whole line is
    one pair.
    """
    tokens = body.split()
    if not tokens or "=" not in tokens[0]:
        return None
    if all("=" in t for t in tokens):
        out = {}
        for t in tokens:
            k, v = t.split("=", 1)
            out[k.strip()] = v.strip()
        return out
    k, v = body.split("=", 1)
    return {k.strip(): v.strip()}


#: Whitespace-free tokens the writer may put at the front of ``note`` before
#: the annotator's free decode text.
NOTE_TOKENS = ("kind", "tele", "ord")


def _parse_note(p, note):
    """Split ``note`` into its leading ``key=value`` tokens and the free text."""
    note = note.strip()
    if not note or note == "-":
        p.note = None
        p.note_text = None
        return
    p.note = note
    rest = note
    while True:
        head, _sep, tail = rest.partition(" ")
        key, eq, val = head.partition("=")
        if not eq or key not in NOTE_TOKENS:
            break
        if key == "kind":
            p.note_kind = val
        elif key == "tele":
            p.note_tele = val
        else:
            p.note_ord = val
        rest = tail.lstrip()
        if not rest:
            break
    p.note_text = rest or None


#: Footer keys the writer emits on the LAST rotated part only.  Their absence
#: from an earlier part is normal and must not be read as truncation.
FOOTER_KEYS = ("drops", "by_src", "coverage", "by_decision", "by_phase")


def _int(tok, base=10):
    if tok is None or tok in ("-", "", "?"):
        return None
    try:
        return int(tok, base)
    except ValueError:
        return None


# ---------------------------------------------------------------- record

class Packet(object):
    """One captured datagram (or TCP segment) with its capture-time context."""

    __slots__ = (
        "seq", "ts_ms", "dt_us", "src", "dir", "decision", "phase", "match",
        "cmd", "cmdname", "flags", "peer", "sp", "dp", "length", "hexlen",
        "payload", "note",
        "effects", "note_kind", "note_tele", "note_ord", "note_text",
        "legacy_phase", "legacy_type", "legacy_family", "legacy_kind",
        "fmt", "file", "lineno", "partial", "payload_truncated",
    )

    def __init__(self):
        for s in Packet.__slots__:
            setattr(self, s, None)
        self.payload = b""
        self.partial = False
        self.payload_truncated = False
        self.effects = ()

    # -- convenience ----------------------------------------------------
    @property
    def outbound(self):
        return self.dir == "OUT"

    @property
    def src_name(self):
        if isinstance(self.src, int):
            return SRC_NAMES.get(self.src, str(self.src))
        return self.src or "UDP"

    @property
    def whole(self):
        """True when the full on-wire payload is present in the file."""
        return self.length is not None and len(self.payload) >= self.length

    @property
    def effect_str(self):
        return "|".join(self.effects) if self.effects else "-"

    def has_effect(self, name):
        return name in (self.effects or ())

    def has(self, bit):
        return self.flags is not None and bool(self.flags & bit)

    def __repr__(self):
        return ("Packet(seq=%s %s %s len=%s cmd=%s/%s)"
                % (self.seq, self.src_name, self.dir, self.length,
                   self.cmd, self.cmdname))


class Event(object):
    """A ``#`` lifecycle line, positioned in the record stream."""

    __slots__ = ("text", "after_seq", "ts_ms", "file", "lineno")

    def __init__(self, text, after_seq, ts_ms, path, lineno):
        self.text = text
        self.after_seq = after_seq
        self.ts_ms = ts_ms
        self.file = path
        self.lineno = lineno

    def __repr__(self):
        return "Event(@%s %r)" % (self.after_seq, self.text)


# ---------------------------------------------------------------- file

class CaptureFile(object):
    """A parsed capture.  Iterating yields :class:`Packet` in file order."""

    def __init__(self, path):
        self.path = path
        self.fmt = None
        self.header = {}          # key=value from '#' lines
        self.footer = []          # last-part-only '# drops/by_src/coverage'
        self.comments = []        # raw '#' text, in order
        self.events = []          # lifecycle '#' lines seen between records
        self.packets = []
        self.bad_lines = 0
        self.truncated_tail = False
        self.parse()

    # -- format detection ------------------------------------------------
    @staticmethod
    def _fmt_from_columns(spec):
        cols = spec.replace(",", " ").split()
        if cols == NEW_COLUMNS:
            return FMT_NEW
        if cols == OLD13_COLUMNS:
            return FMT_OLD13
        if cols == OLD11_COLUMNS:
            return FMT_OLD11
        # Unknown header: fall back to width, which is what actually matters.
        return {18: FMT_NEW, 13: FMT_OLD13, 11: FMT_OLD11}.get(len(cols))

    @staticmethod
    def _fmt_from_row(fields):
        n = len(fields)
        if n >= 18:
            return FMT_NEW
        if n == 13:
            return FMT_OLD13
        if n == 11:
            return FMT_OLD11
        # 12 columns: OLD11 whose payload was cut, or OLD13 missing kind.
        return FMT_OLD13 if n == 12 else None

    # -- parsing ---------------------------------------------------------
    def parse(self):
        last_seq = -1
        last_ts = None
        with io.open(self.path, "r", encoding="utf-8", errors="replace",
                     newline="") as fh:
            raw = fh.read()
        if not raw:
            return
        lines = raw.split("\n")
        tail_incomplete = not raw.endswith("\n")
        for i, line in enumerate(lines):
            is_last = (i == len(lines) - 1)
            if is_last and line == "":
                continue
            line = line.rstrip("\r")
            if not line.strip():
                continue
            if line.startswith("#"):
                body = line[1:].strip()
                self.comments.append(body)
                low = body.lower()
                if low.startswith("columns") or low.startswith("column"):
                    self.fmt = self._fmt_from_columns(body.split(":", 1)[-1])
                elif body.split(" ", 1)[0].split("=", 1)[0] in FOOTER_KEYS:
                    # Footer lines land only on the last rotated part; keep
                    # them, and never read their absence as truncation.
                    self.footer.append(body)
                elif _kv_pairs(body) is not None:
                    self.header.update(_kv_pairs(body))
                else:
                    self.events.append(Event(body, last_seq, last_ts,
                                             self.path, i + 1))
                continue
            partial = is_last and tail_incomplete
            pkt = self._parse_row(line, i + 1, partial)
            if pkt is None:
                self.bad_lines += 1
                if partial:
                    self.truncated_tail = True
                continue
            if partial:
                self.truncated_tail = True
            self.packets.append(pkt)
            last_seq = pkt.seq
            last_ts = pkt.ts_ms

    def _parse_row(self, line, lineno, partial):
        fields = line.split()
        fmt = self.fmt or self._fmt_from_row(fields)
        if fmt is None:
            return None
        if fmt == FMT_NEW:
            # 17 fixed columns then the rest of the line verbatim: `note` is
            # compound and may contain spaces, so it must never be re-split.
            pkt = self._parse_new(line.split(None, 17))
        elif fmt == FMT_OLD13:
            pkt = self._parse_old(fields, 13)
        else:
            pkt = self._parse_old(fields, 11)
        if pkt is None:
            return None
        pkt.fmt = fmt
        pkt.file = self.path
        pkt.lineno = lineno
        if partial:
            pkt.partial = True
        if self.fmt is None:
            self.fmt = fmt
        return pkt

    @staticmethod
    def _parse_new(f):
        if len(f) < 17:
            return None
        p = Packet()
        p.seq = _int(f[0])
        p.ts_ms = _int(f[1])
        p.dt_us = _int(f[2])          # 0 is legitimate on retro records
        p.src = _int(f[3])
        if p.src is None:
            p.src = f[3]
        p.dir = f[4]
        p.decision = f[5]
        # PHASE[/EFFECT|EFFECT] — the filter-effect mask is suffixed onto the
        # phase token rather than carrying a column of its own.
        phase, sep, effects = f[6].partition("/")
        p.phase = None if phase in ("-", "") else phase
        p.effects = tuple(e for e in effects.split("|") if e) if sep else ()
        p.match = _int(f[7])
        p.cmd = _int(f[8])
        p.cmdname = None if f[9] == "-" else f[9]
        p.flags = _int(f[10], 16)
        p.peer = f[11]
        p.sp = _int(f[12])
        p.dp = _int(f[13])
        p.length = _int(f[14])
        p.hexlen = _int(f[15])
        data, clean = _unhex(f[16])   # '-' means empty, handled by _unhex
        p.payload = data
        if not clean:
            p.partial = True
        if len(f) > 17:
            _parse_note(p, f[17])
        if p.length is not None and len(data) < p.length:
            p.payload_truncated = True
        if p.seq is None or p.length is None:
            return None
        return p

    @staticmethod
    def _parse_old(f, width):
        if len(f) < 9:
            return None
        p = Packet()
        p.seq = _int(f[0])
        p.ts_ms = _int(f[1])
        p.legacy_phase = f[2]
        p.dir = f[3]
        p.decision = f[4]
        p.peer = f[5]
        p.sp = _int(f[6])
        p.dp = _int(f[7])
        p.length = _int(f[8])
        p.src = 0                         # every old record is UDP (defect D1)
        hexcol = 12 if width == 13 else 10
        if width == 13:
            p.legacy_type = f[9] if len(f) > 9 else None
            p.legacy_family = f[10] if len(f) > 10 else None
            p.legacy_kind = f[11] if len(f) > 11 else None
        else:
            p.legacy_type = f[9] if len(f) > 9 else None
        hx = f[hexcol] if len(f) > hexcol else ""
        # The old writer marked a hexLimit cut with a literal '..' suffix.
        if hx.endswith(".."):
            hx = hx[:-2]
            p.payload_truncated = True
        data, clean = _unhex(hx)
        p.payload = data
        p.hexlen = len(data)
        if not clean:
            p.partial = True
        if p.length is not None and len(data) < p.length:
            p.payload_truncated = True
        if p.seq is None or p.length is None:
            return None
        return p

    # -- accessors -------------------------------------------------------
    def __iter__(self):
        return iter(self.packets)

    def __len__(self):
        return len(self.packets)

    @property
    def secret_key(self):
        """The 16-byte TEA session key from the file header, or ``None``."""
        hexkey = (self.header.get("secret_key")
                  or self.header.get("session_key")
                  or self.header.get("key"))
        if not hexkey:
            return None
        hexkey = hexkey.strip()
        try:
            k = bytes.fromhex(hexkey)
        except ValueError:
            return None
        return k if len(k) >= 16 else None

    def stats(self):
        return {
            "path": self.path,
            "format": self.fmt,
            "packets": len(self.packets),
            "bad_lines": self.bad_lines,
            "truncated_tail": self.truncated_tail,
            "payload_truncated": sum(1 for p in self.packets if p.payload_truncated),
            "events": len(self.events),
            "footer": len(self.footer),
            "has_key": self.secret_key is not None,
        }


# ---------------------------------------------------------------- sets

class CaptureSet(object):
    """One or more capture files read as a single stream.

    Accepts files, directories (recursively scanned for ``*.txt``) and globs,
    which is what a rotated multi-file capture looks like on disk.  Files are
    ordered by name, which is the rotation order the writer produces.
    """

    def __init__(self, paths):
        if isinstance(paths, str):
            paths = [paths]
        self.files = []
        for path in _expand(paths):
            try:
                cf = CaptureFile(path)
            except OSError:
                continue
            # A directory sweep also finds summary/report .txt siblings; keep
            # only files that actually hold records or declare a column spec.
            if cf.packets or cf.fmt is not None:
                self.files.append(cf)
        # Rotated parts are capture_raw_<stamp>_001.txt, _002.txt, ...  Sort
        # them numerically rather than lexically so a session that ever runs
        # past part 999 still concatenates in order.
        self.files.sort(key=lambda c: _natural_key(c.path))

    def __iter__(self):
        for cf in self.files:
            for p in cf.packets:
                yield p

    def __len__(self):
        return sum(len(cf) for cf in self.files)

    @property
    def events(self):
        out = []
        for cf in self.files:
            out.extend(cf.events)
        return out

    @property
    def secret_key(self):
        """Any key declared by any part — every rotated part repeats it."""
        for cf in self.files:
            k = cf.secret_key
            if k:
                return k
        return None

    @property
    def footer(self):
        out = []
        for cf in self.files:
            out.extend(cf.footer)
        return out

    @property
    def formats(self):
        return sorted({cf.fmt for cf in self.files if cf.fmt})

    def header(self, key, default=None):
        for cf in self.files:
            if key in cf.header:
                return cf.header[key]
        return default

    def stats(self):
        s = {
            "files": len(self.files),
            "formats": self.formats,
            "packets": len(self),
            "bad_lines": sum(cf.bad_lines for cf in self.files),
            "truncated_tails": sum(1 for cf in self.files if cf.truncated_tail),
            "payload_truncated": sum(
                sum(1 for p in cf.packets if p.payload_truncated)
                for cf in self.files),
            "events": len(self.events),
            "footer": len(self.footer),
            "has_key": self.secret_key is not None,
        }
        return s


_DIGITS = None


def _natural_key(path):
    """Sort key that orders embedded numbers numerically."""
    global _DIGITS
    if _DIGITS is None:
        import re
        _DIGITS = re.compile(r"(\d+)")
    parts = _DIGITS.split(os.path.normcase(path))
    return tuple((1, int(p)) if p.isdigit() else (0, p) for p in parts)


def _expand(paths):
    out = []
    for path in paths:
        if os.path.isdir(path):
            for root, _dirs, names in os.walk(path):
                for n in sorted(names, key=_natural_key):
                    if n.lower().endswith((".txt", ".log", ".cap")):
                        out.append(os.path.join(root, n))
        elif any(ch in path for ch in "*?["):
            out.extend(sorted(_glob.glob(path, recursive=True),
                              key=_natural_key))
        else:
            out.append(path)
    seen, uniq = set(), []
    for p in out:
        rp = os.path.abspath(p)
        if rp not in seen:
            seen.add(rp)
            uniq.append(p)
    return uniq


def load(paths):
    """Read one or more captures into a :class:`CaptureSet`."""
    return CaptureSet(paths)
