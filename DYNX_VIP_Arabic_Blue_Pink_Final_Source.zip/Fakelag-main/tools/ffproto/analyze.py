"""The analysis pipeline: capture file(s) in, decoded rows plus statistics out.

One capture can hold more than one match session — the mask and the
``HEAD_SECRET`` permutation are per session, so a single global solve is wrong
the moment the player requeues.  Sessions are therefore split by remote
endpoint (``peer:port``) and each gets its own solved layout and its own key.
That is also why a mid-capture endpoint change is worth reporting: on
``captures/phone_kick`` it is exactly what made 46 of 202 encrypted bodies
undecryptable with the one key in the header.

Every packet ends up in exactly one status bucket, so "what we could not
decode" is a number rather than a silence:

==============  =========================================================
status          meaning
==============  =========================================================
``OK``          body decoded, consumed exactly
``NO_LAYOUT``   plaintext body, but no class for this ``(cmd, direction)``
``DECODE_FAIL`` layout exists and the walk did not consume exactly
``NO_KEY``      ``Flags & 1`` and no session key for this endpoint
``TEA_FAIL``    key present, QQ-TEA zero-tail check failed (wrong session)
``ZIPPED``      ``Flags & 2`` — gzip under an XOR'd header, needs SECRET_KEY
``TRUNCATED``   the file does not hold the whole on-wire payload
``UNPARSED``    not match traffic, or the header layout could not be solved
==============  =========================================================
"""

from __future__ import annotations

import collections

from . import capture, catalogue, crypto, decode, framing, schema

OK = "OK"
NO_LAYOUT = "NO_LAYOUT"
DECODE_FAIL = "DECODE_FAIL"
NO_KEY = "NO_KEY"
TEA_FAIL = "TEA_FAIL"
ZIPPED = "ZIPPED"
TRUNCATED = "TRUNCATED"
UNPARSED = "UNPARSED"

STATUSES = (OK, NO_LAYOUT, DECODE_FAIL, NO_KEY, TEA_FAIL, ZIPPED, TRUNCATED,
            UNPARSED)


class Row(object):
    """One analysed packet."""

    __slots__ = ("pkt", "udp", "cmd", "direction", "status", "decoded",
                 "body", "session")

    def __init__(self, pkt):
        self.pkt = pkt
        self.udp = None
        self.cmd = None
        self.direction = pkt.dir
        self.status = UNPARSED
        self.decoded = None
        self.body = None
        self.session = None

    @property
    def name(self):
        return catalogue.name_or(self.cmd) if self.cmd is not None else "-"

    @property
    def ts(self):
        return self.pkt.ts_ms

    def __repr__(self):
        return "Row(seq=%s %s cmd=%s %s)" % (self.pkt.seq, self.direction,
                                             self.cmd, self.status)


class Session(object):
    """One remote endpoint: its own header layout and its own key."""

    __slots__ = ("endpoint", "layout", "hits", "tested", "key", "packets",
                 "crc_ok", "crc_total", "first_ts", "last_ts")

    def __init__(self, endpoint):
        self.endpoint = endpoint
        self.layout = None
        self.hits = self.tested = 0
        self.key = None
        self.packets = 0
        self.crc_ok = self.crc_total = 0
        self.first_ts = self.last_ts = None

    def describe(self):
        lay = self.layout.describe() if self.layout else "UNSOLVED"
        return "%s  %s  pkts=%d crc7=%d/%d key=%s" % (
            self.endpoint, lay, self.packets, self.crc_ok, self.crc_total,
            "yes" if self.key else "no")


def endpoint_of(pkt):
    """The remote ``ip:port`` a packet belongs to, direction-independent."""
    peer = pkt.peer if pkt.peer is not None else "?"
    port = pkt.dp if pkt.dir == "OUT" else pkt.sp
    return "%s:%s" % (peer, port)


class Analysis(object):
    """Decode a capture set and keep every number a report might want."""

    def __init__(self, paths, key=None, sch=None, solve_per_endpoint=True,
                 max_packets=None, infer=False, infer_min=3):
        self.captures = capture.load(paths)
        self.schema = sch or schema.default_schema()
        self.explicit_key = key
        self.solve_per_endpoint = solve_per_endpoint
        self.max_packets = max_packets
        self.infer = infer
        self.infer_min = infer_min
        self.inferred = {}        # (cmd, dir) -> (class, n_exact)
        self.label = None

        self.rows = []
        self.sessions = collections.OrderedDict()
        self.status_counts = collections.Counter()
        self.status_bytes = collections.Counter()
        self.cmd_stats = {}          # (cmd, dir) -> CmdStat
        self.column_cmd_agree = 0
        self.column_cmd_disagree = 0
        self.column_cmd_checked = 0
        self.run()

    # -- session solving --------------------------------------------------
    def _sessions_for(self):
        groups = collections.OrderedDict()
        for pkt in self.captures:
            if not framing.is_match_traffic(pkt.payload):
                continue
            ep = endpoint_of(pkt) if self.solve_per_endpoint else "*"
            groups.setdefault(ep, []).append(pkt)
        return groups

    def _collect_keys(self):
        """Every session key the capture set declares, by endpoint.

        A rotated capture holds one key per file, each tagged with the endpoint
        it belongs to, so a set-wide "the key" is wrong the moment there are
        two.  Keys with no endpoint tag go in the untagged pool and are matched
        by trial decryption — the QQ-TEA seven-zero tail makes that free and
        unambiguous.
        """
        by_ep, pool = {}, []
        if self.explicit_key:
            pool.append(self.explicit_key)
        for cf in self.captures.files:
            k = cf.secret_key
            if not k:
                continue
            ep = cf.header.get("key_endpoint")
            if ep:
                by_ep[ep] = k
            if k not in pool:
                pool.append(k)
        return by_ep, pool

    def _score_layout(self, layout, key, pkts, tries=400):
        """How many of this endpoint's bodies actually decode under a layout.

        This is the strongest oracle available and it is the only one that can
        finish the header solve.  Two orders that differ only by swapping
        ``Flags`` with ``OrderID`` are indistinguishable from the header alone
        whenever the real OrderID's high byte happens to fall inside
        ``{0..3}``: both then satisfy the DATALEN identity, both yield known
        command ids, and both yield legal-looking flags.  Measured on
        ``captures/phone_kick`` endpoint 148.222.88.180:10013, the two tie at a
        perfect header score and split 584/598 against 440/598 once bodies are
        decoded — a wrong ``Flags`` marks plaintext packets as encrypted and
        the decoder then walks TEA noise.

        Returns ``(decoded, attempted, tea_ok)``.
        """
        ok = tried = tea = 0
        for p in pkts:
            if not p.whole or p.payload_truncated:
                continue
            q = framing.decode(p.payload, layout, key)
            if q is None:
                continue
            if q.encrypted and q.plain is not None:
                tea += 1
            if q.plain is None:
                continue
            lay = self.schema.layout(q.cmd, p.dir)
            if lay is None:
                continue
            tried += 1
            if decode.decode_typed(lay, q.plain).ok:
                ok += 1
            if tried >= tries:
                break
        return ok, tried, tea

    def run(self):
        groups = self._sessions_for()
        keys_by_ep, key_pool = self._collect_keys()

        for ep, pkts in groups.items():
            s = Session(ep)
            s.packets = len(pkts)
            # Solve from EVERY packet whose header is present, not only the
            # ones whose payload survived: the capture records the true wire
            # length even when it stored a clipped payload, and that is all
            # the DATALEN identity needs.  Requiring a whole payload lost the
            # solve outright on heavily-truncated archived captures, and an
            # unsolved endpoint reports every one of its packets as unparsed.
            rows = [(p.dir, p.payload, p.length) for p in pkts
                    if p.payload and len(p.payload) >= framing.HDR_RELIABLE]
            if len(rows) >= 8:
                cands = framing.solve_candidates(rows, k=8)
                if cands:
                    s.hits = cands[0][3]
                    s.tested = len(rows)
                    # Joint search over (header order, session key): the key
                    # choice changes which bodies are readable and the order
                    # changes which packets look encrypted, so neither can be
                    # settled before the other.
                    keys = [keys_by_ep.get(ep)] + \
                           [k for k in key_pool if k is not keys_by_ep.get(ep)]
                    keys = [k for i, k in enumerate(keys) if k or i == 0]
                    if None not in keys:
                        keys.append(None)
                    best = None
                    for rank, (_score, m, order, _h) in enumerate(cands):
                        layout = framing.HeaderLayout(m, order)
                        for k in keys:
                            ok, tried, tea = self._score_layout(layout, k, pkts)
                            cand = (ok, tea, -rank, layout, k)
                            if best is None or cand[:3] > best[:3]:
                                best = cand
                    if best is not None:
                        s.layout, s.key = best[3], best[4]
                    else:
                        s.layout = framing.HeaderLayout(cands[0][1], cands[0][2])
            self.sessions[ep] = s

        n = 0
        for pkt in self.captures:
            if self.max_packets and n >= self.max_packets:
                break
            n += 1
            self.rows.append(self._analyse(pkt))
        if self.infer:
            self._infer_missing()
        self._tally()

    # -- opt-in shape inference ------------------------------------------
    def _infer_missing(self):
        """For ids with a class in ONE direction only, test the other one.

        **This proves a SHAPE, never a meaning.**  ``IL2CPP_FINDINGS.md`` §2:
        messages are bidirectional with different classes per direction, and
        assuming otherwise has already produced one wrong conclusion in this
        project.  A class with n varint fields consumes exactly the same bytes
        as any other class with n varint fields, so an exact-length match says
        the field *widths* line up and says nothing about what the fields mean.

        A candidate is only accepted when it consumes byte-exactly on every
        sample and there are at least ``infer_min`` of them, and every accepted
        layout is tagged ``inferred-other-direction`` so a report can separate
        it from a registry-backed one.  Off by default.
        """
        pending = collections.defaultdict(list)
        for row in self.rows:
            if row.status == NO_LAYOUT and row.body is not None:
                pending[(row.cmd, row.direction)].append(row)
        for (cmd, direction), rows in pending.items():
            other = schema.IN if direction == schema.OUT else schema.OUT
            cls = self.schema.class_for(cmd, other)
            if not cls or len(rows) < self.infer_min:
                continue
            lay = self.schema.layout(cmd, other)
            if lay is None:
                continue
            hits = 0
            for r in rows:
                if decode.decode_typed(lay, r.body).ok:
                    hits += 1
            if hits != len(rows):
                continue
            probe = schema.Layout(
                cmd, direction, cls, lay.root,
                "inferred-other-direction (SHAPE ONLY: field names and "
                "semantics are NOT verified for this direction)",
                lay.complete, lay.unresolved)
            self.inferred[(cmd, direction)] = (cls, hits)
            for r in rows:
                d = decode.decode_typed(probe, r.body)
                r.decoded = d
                r.status = OK if d.ok else NO_LAYOUT

    # -- per-packet -------------------------------------------------------
    def _analyse(self, pkt):
        row = Row(pkt)
        if not framing.is_match_traffic(pkt.payload):
            row.status = UNPARSED
            return row
        ep = endpoint_of(pkt) if self.solve_per_endpoint else "*"
        s = self.sessions.get(ep)
        row.session = ep
        if s is None or s.layout is None:
            row.status = UNPARSED
            return row
        b = pkt.payload
        s.crc_total += 1
        if crypto.crc7(b, 2, len(b) - 2) == b[1]:
            s.crc_ok += 1
        if s.first_ts is None:
            s.first_ts = pkt.ts_ms
        s.last_ts = pkt.ts_ms

        udp = framing.decode(b, s.layout, s.key)
        row.udp = udp
        if udp is None:
            row.status = UNPARSED
            return row
        row.cmd = udp.cmd

        # Cross-check the app's own cmd column when the capture supplies one.
        if pkt.cmd is not None and pkt.cmd >= 0:
            self.column_cmd_checked += 1
            if pkt.cmd == udp.cmd:
                self.column_cmd_agree += 1
            else:
                self.column_cmd_disagree += 1

        if pkt.payload_truncated:
            row.status = TRUNCATED
            return row
        if udp.zipped:
            row.status = ZIPPED
            return row
        if udp.encrypted and udp.plain is None:
            row.status = NO_KEY if not s.key else TEA_FAIL
            return row
        body = udp.plain
        row.body = body
        lay = self.schema.layout(udp.cmd, pkt.dir)
        if lay is None:
            row.status = NO_LAYOUT
            return row
        notes = schema.VERIFIED_NOTES.get((udp.cmd, pkt.dir))
        d = decode.decode_typed(lay, body, notes)
        row.decoded = d
        row.status = OK if d.ok else DECODE_FAIL
        return row

    # -- aggregation ------------------------------------------------------
    def _tally(self):
        for row in self.rows:
            self.status_counts[row.status] += 1
            self.status_bytes[row.status] += row.pkt.length or 0
            if row.cmd is None:
                continue
            key = (row.cmd, row.direction)
            st = self.cmd_stats.get(key)
            if st is None:
                st = self.cmd_stats[key] = CmdStat(row.cmd, row.direction)
            st.add(row)

    # -- views ------------------------------------------------------------
    def view(self, pred, label=None):
        """A re-tallied analysis over the subset of rows matching ``pred``.

        This is how one capture is split in two for :func:`ffproto.reports.diff`
        — freeze on vs off, one match vs the next — without re-reading or
        re-solving anything.  ``FreezeDiffAnalyzer`` could only split on
        ``CaptureRecord.phase``, whose setter had no callers, so its split was
        always degenerate; splitting on an arbitrary predicate is the fix.
        """
        v = Analysis.__new__(Analysis)
        v.captures = self.captures
        v.schema = self.schema
        v.explicit_key = self.explicit_key
        v.solve_per_endpoint = self.solve_per_endpoint
        v.max_packets = self.max_packets
        v.infer = self.infer
        v.infer_min = self.infer_min
        v.inferred = self.inferred
        v.sessions = self.sessions
        v.label = label
        v.rows = [r for r in self.rows if pred(r)]
        v.status_counts = collections.Counter()
        v.status_bytes = collections.Counter()
        v.cmd_stats = {}
        v.column_cmd_agree = v.column_cmd_disagree = v.column_cmd_checked = 0
        v._tally()
        return v

    # -- accessors --------------------------------------------------------
    def coverage(self):
        """``(decoded, decodable, total)`` plus the per-status split.

        ``decodable`` excludes packets whose body we could never read without
        the session key or a gzip header — counting those as decode failures
        would blame the decoder for missing crypto.
        """
        c = self.status_counts
        total = sum(c.values())
        decodable = c[OK] + c[NO_LAYOUT] + c[DECODE_FAIL]
        return c[OK], decodable, total

    def unknown_surface(self):
        """Packets and bytes we cannot read, split by why."""
        out = collections.OrderedDict()
        for s in (NO_LAYOUT, DECODE_FAIL, NO_KEY, TEA_FAIL, ZIPPED,
                  TRUNCATED, UNPARSED):
            out[s] = (self.status_counts[s], self.status_bytes[s])
        return out

    def span_ms(self):
        ts = [r.ts for r in self.rows if r.ts]
        return (max(ts) - min(ts)) if len(ts) > 1 else 0


class CmdStat(object):
    """Per-``(cmd, direction)`` counters for the histogram and coverage table."""

    __slots__ = ("cmd", "direction", "n", "ok", "fail", "no_layout",
                 "encrypted", "reliable", "bytes", "min_len", "max_len",
                 "lens", "errors", "field_counts", "first_ts", "last_ts")

    def __init__(self, cmd, direction):
        self.cmd = cmd
        self.direction = direction
        self.n = self.ok = self.fail = self.no_layout = 0
        self.encrypted = self.reliable = 0
        self.bytes = 0
        self.min_len = None
        self.max_len = 0
        self.lens = collections.Counter()
        self.errors = collections.Counter()
        self.field_counts = collections.Counter()
        self.first_ts = self.last_ts = None

    def add(self, row):
        self.n += 1
        ln = row.pkt.length or 0
        self.bytes += ln
        self.lens[ln] += 1
        self.min_len = ln if self.min_len is None else min(self.min_len, ln)
        self.max_len = max(self.max_len, ln)
        if row.udp is not None:
            if row.udp.encrypted:
                self.encrypted += 1
            if row.udp.reliable:
                self.reliable += 1
        if self.first_ts is None:
            self.first_ts = row.ts
        self.last_ts = row.ts
        if row.status == OK:
            self.ok += 1
            if row.decoded:
                self.field_counts[len(row.decoded.fields)] += 1
        elif row.status == NO_LAYOUT:
            self.no_layout += 1
        elif row.status == DECODE_FAIL:
            self.fail += 1
            if row.decoded and row.decoded.error:
                self.errors[row.decoded.error] += 1

    @property
    def name(self):
        return catalogue.name_or(self.cmd)

    @property
    def decodable(self):
        return self.ok + self.fail + self.no_layout

    @property
    def rate(self):
        d = self.decodable
        return (self.ok / d) if d else 0.0

    def channel(self):
        if self.reliable == self.n:
            return "REL"
        if self.reliable == 0:
            return "NONREL"
        return "MIXED"
