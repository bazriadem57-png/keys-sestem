"""Command-id catalogue — read straight out of ``net/CmdCatalogue.java``.

The Java class packs all 1974 ids into three constant-pool strings as
``id:NAME`` entries joined by ``|``, each prefixed ``<`` when the client
registers an inbound handler for it.  This module parses that same data rather
than keeping a second copy, because a second copy drifts: the file is
regenerated from ``tools/ff_cmd_catalogue.txt`` plus the il2cpp registry and any
Python-side duplicate would silently fall behind.

Usage::

    from ffproto import catalogue
    catalogue.name(1900)          -> 'RUDP_SYNC_PROPERTY'  (or None)
    catalogue.name_or(1900)       -> name, else 'CMD_1900'
    catalogue.is_receivable(1900) -> True when the client registers a handler
"""

from __future__ import annotations

import io
import os
import re

# ---------------------------------------------------------------- location

_HERE = os.path.dirname(os.path.abspath(__file__))
_REPO = os.path.dirname(os.path.dirname(_HERE))

DEFAULT_JAVA = os.path.join(
    _REPO, "fakelag", "fakelag-beta", "app", "src", "main", "java",
    "com", "fakelag", "cryhard8", "net", "CmdCatalogue.java")

# Fallback: the flat text the Java file was generated from.
DEFAULT_TXT = os.path.join(_REPO, "tools", "ff_cmd_catalogue.txt")


def java_path() -> str:
    """Path to ``CmdCatalogue.java``; honours ``$FF_CMD_CATALOGUE``."""
    return os.environ.get("FF_CMD_CATALOGUE", DEFAULT_JAVA)


# ---------------------------------------------------------------- parsing

_PACKED_RE = re.compile(
    r"String\[\]\s+PACKED\s*=\s*\{(.*?)\}\s*;", re.S)
# Java string literals, no escapes are used by the generator but tolerate them.
_STR_RE = re.compile(r'"((?:[^"\\]|\\.)*)"')


def _parse_java(text: str):
    m = _PACKED_RE.search(text)
    if not m:
        raise ValueError("CmdCatalogue.java: PACKED array not found")
    # Each array element is a self-contained chunk of "|"-joined entries; join
    # with "|" so the chunk boundary does not fuse two entries into one.  A
    # plain "".join() silently loses one id and corrupts one name per boundary.
    blob = "|".join(_STR_RE.findall(m.group(1)))
    return _parse_blob(blob)


def _parse_blob(blob: str):
    names = {}
    inbound = set()
    for entry in blob.split("|"):
        if not entry:
            continue
        receivable = entry[0] == "<"
        if receivable:
            entry = entry[1:]
        head, sep, name = entry.partition(":")
        if not sep or not head.isdigit():
            continue
        cid = int(head)
        names[cid] = name
        if receivable:
            inbound.add(cid)
    return names, inbound


def _parse_txt(text: str):
    """``tools/ff_cmd_catalogue.txt`` fallback: ``<id> <NAME>`` per line."""
    names, inbound = {}, set()
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.replace("\t", " ").split()
        if len(parts) < 2:
            continue
        head = parts[0].lstrip("<")
        if not head.isdigit():
            continue
        names[int(head)] = parts[1]
    return names, inbound


# ---------------------------------------------------------------- lazy load

_names = None
_inbound = None
_source = None


def _ensure():
    global _names, _inbound, _source
    if _names is not None:
        return
    path = java_path()
    if os.path.exists(path):
        with io.open(path, encoding="utf-8", errors="replace") as fh:
            _names, _inbound = _parse_java(fh.read())
        _source = path
        return
    if os.path.exists(DEFAULT_TXT):
        with io.open(DEFAULT_TXT, encoding="utf-8", errors="replace") as fh:
            _names, _inbound = _parse_txt(fh.read())
        _source = DEFAULT_TXT
        return
    _names, _inbound, _source = {}, set(), "(none)"


def reload(path=None):
    """Force a reload, optionally from an explicit ``CmdCatalogue.java``."""
    global _names, _inbound, _source
    _names = _inbound = _source = None
    if path:
        os.environ["FF_CMD_CATALOGUE"] = path
    _ensure()


def source() -> str:
    _ensure()
    return _source


def count() -> int:
    _ensure()
    return len(_names)


def inbound_count() -> int:
    _ensure()
    return len(_inbound)


def name(cmd: int):
    """The game's own name for a command id, or ``None``."""
    _ensure()
    return _names.get(cmd)


def name_or(cmd: int) -> str:
    _ensure()
    return _names.get(cmd) or ("CMD_%d" % cmd)


def is_known(cmd: int) -> bool:
    _ensure()
    return cmd in _names


def is_receivable(cmd: int) -> bool:
    """True when the client registers an inbound handler for this id."""
    _ensure()
    return cmd in _inbound


def is_transport(cmd: int) -> bool:
    """Reserved transport range 1..99 — hello/ack/ping/byebye/fragments."""
    return 1 <= cmd <= 99


def is_reliable_channel(cmd: int) -> bool:
    n = name(cmd)
    return bool(n) and n.startswith("RUDP_")


def is_unreliable_channel(cmd: int) -> bool:
    n = name(cmd)
    return bool(n) and n.startswith("UDP_")


def all_ids():
    _ensure()
    return sorted(_names)


def describe(cmd: int) -> str:
    n = name(cmd)
    if n is None:
        return "%d (unknown)" % cmd
    return "%d %s%s" % (cmd, n, "" if is_receivable(cmd) else " [send-only]")


if __name__ == "__main__":  # tiny self-check
    _ensure()
    print("source        :", source())
    print("COUNT         :", count())
    print("INBOUND_COUNT :", inbound_count())
    for cid in (1, 106, 135, 1900, 2001, 2012, 3586):
        print("  %-6d %s" % (cid, describe(cid)))
