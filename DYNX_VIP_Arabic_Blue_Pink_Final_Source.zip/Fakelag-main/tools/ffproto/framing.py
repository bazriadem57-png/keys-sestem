"""UDP match framing: MsgKey, the XOR mask, the HEAD_SECRET permutation.

Mirrors ``net/MsgKey.java``, ``net/HeaderField.java``, ``net/HeaderLayout.java``
and ``net/SessionKeySolver.java``.

    byte 0            MsgKey.  90..99 reliable (10-byte header),
                      100..110 non-reliable (8-byte header).  The *value* is
                      re-randomised per packet; only the range is meaningful.
    byte 1            CRC-7 over bytes 2..end.
    bytes 2..hdr-1    five fields — SendOption(1) Cmd(2) OrderID(2) Flags(1)
                      Length(2) — permuted by HEAD_SECRET and XOR-masked with
                      SECRET_KEY[0].  OrderID is absent on non-reliable packets.

Both unknowns (mask, order) are solvable from a capture alone, which is why an
offline capture is readable even without the TEA key: only ``Flags & 1``
bodies need it.
"""

from __future__ import annotations

import collections
import itertools

from . import crypto

# ---------------------------------------------------------------- constants

SENDOPTION, CMD, ORDERID, FLAGS, DATALEN = 0, 1, 2, 3, 4
FIELD_W = {SENDOPTION: 1, CMD: 2, ORDERID: 2, FLAGS: 1, DATALEN: 2}
FIELD_NAME = {SENDOPTION: "SendOption", CMD: "Cmd", ORDERID: "OrderID",
              FLAGS: "Flags", DATALEN: "Length"}
DEFAULT_ORDER = (SENDOPTION, CMD, ORDERID, FLAGS, DATALEN)

MSG_KEY_MIN, MSG_KEY_MID, MSG_KEY_MAX = 90, 100, 110
HDR_RELIABLE, HDR_NON_RELIABLE = 10, 8

FLAG_ENCRYPTION, FLAG_ZIP = 1, 2

# Highest id in the game's own enum (message.KLINFKFBIKB tops out at 3586);
# anything above is a misread field, not a real command.
MAX_CMD = 3586
RELIABLE_SEND_OPTIONS = frozenset((1, 2, 5))


def header_size(msg_key):
    if MSG_KEY_MIN <= msg_key < MSG_KEY_MID:
        return HDR_RELIABLE
    if MSG_KEY_MID <= msg_key <= MSG_KEY_MAX:
        return HDR_NON_RELIABLE
    return None


def is_match_traffic(payload):
    return bool(payload) and header_size(payload[0]) is not None


def field_offsets(order, reliable):
    """Byte offset of each field under a HEAD_SECRET order."""
    off, out = 2, {}
    for f in order:
        if f == ORDERID and not reliable:
            continue
        out[f] = off
        off += FIELD_W[f]
    return out, off


def order_str(order):
    return "[" + ", ".join(FIELD_NAME[f] for f in order) + "]"


# ---------------------------------------------------------------- layout

class HeaderLayout(object):
    """A solved (mask, HEAD_SECRET) pair with the offsets precomputed."""

    __slots__ = ("mask", "order", "_rel", "_non")

    def __init__(self, mask, order=DEFAULT_ORDER):
        self.mask = mask & 0xFF
        self.order = tuple(order)
        self._rel, rend = field_offsets(self.order, True)
        self._non, nend = field_offsets(self.order, False)
        if rend != HDR_RELIABLE or nend != HDR_NON_RELIABLE:
            raise ValueError("HEAD_SECRET must be a permutation of the five fields")

    def offsets(self, reliable):
        return self._rel if reliable else self._non

    def describe(self):
        return "mask=0x%02X HEAD_SECRET=%s" % (self.mask, order_str(self.order))

    def __repr__(self):
        return "HeaderLayout(%s)" % self.describe()


DEFAULT_LAYOUT = HeaderLayout(0, DEFAULT_ORDER)


# ---------------------------------------------------------------- parsing

class UdpPacket(object):
    """One parsed match datagram."""

    __slots__ = ("msg_key", "crc", "crc_ok", "reliable", "hdr_len",
                 "send_option", "cmd", "order_id", "flags", "length",
                 "body", "encrypted", "zipped", "plain", "tea_ok",
                 "len_match")

    def __init__(self):
        self.msg_key = self.crc = -1
        self.crc_ok = False
        self.reliable = False
        self.hdr_len = 0
        self.send_option = self.cmd = self.flags = self.length = -1
        self.order_id = None
        self.body = b""
        self.encrypted = self.zipped = False
        self.plain = None
        self.tea_ok = False
        self.len_match = False

    def __repr__(self):
        return ("UdpPacket(cmd=%d %s len=%d body=%d%s%s)"
                % (self.cmd, "REL" if self.reliable else "NONREL", self.length,
                   len(self.body), " ENC" if self.encrypted else "",
                   " ZIP" if self.zipped else ""))


def parse(pkt, layout=DEFAULT_LAYOUT):
    """Parse header fields.  Returns a :class:`UdpPacket` or ``None``."""
    n = len(pkt)
    if n < HDR_NON_RELIABLE:
        return None
    mk = pkt[0]
    hdr = header_size(mk)
    if hdr is None or n < hdr:
        return None
    m = layout.mask
    reliable = (hdr == HDR_RELIABLE)
    offs = layout.offsets(reliable)

    def rd(f):
        o = offs.get(f)
        if o is None:
            return None
        if FIELD_W[f] == 1:
            return pkt[o] ^ m
        return (pkt[o] ^ m) | ((pkt[o + 1] ^ m) << 8)

    p = UdpPacket()
    p.msg_key = mk
    p.crc = pkt[1]
    p.reliable = reliable
    p.hdr_len = hdr
    p.send_option = rd(SENDOPTION)
    p.cmd = rd(CMD)
    p.order_id = rd(ORDERID)
    p.flags = rd(FLAGS)
    p.length = rd(DATALEN)
    p.body = bytes(pkt[hdr:])
    p.crc_ok = (crypto.crc7(pkt, 2, n - 2) == pkt[1])
    p.encrypted = bool(p.flags & FLAG_ENCRYPTION)
    p.zipped = bool(p.flags & FLAG_ZIP)
    p.len_match = (p.length == n - hdr)
    return p


def decode(pkt, layout=DEFAULT_LAYOUT, key=None):
    """Parse, then recover the plaintext body when possible.

    ``plain`` is the decodable body: the payload itself when the packet is not
    encrypted, the TEA plaintext when it is and the key is right, else ``None``.
    Zipped bodies need ``SECRET_KEY`` for the XOR'd gzip header and stay
    ``None``.
    """
    p = parse(pkt, layout)
    if p is None:
        return None
    if p.zipped:
        p.plain = None
    elif p.encrypted:
        if key:
            p.plain, p.tea_ok = crypto.qqtea_decrypt(p.body, key)
    else:
        p.plain = p.body
    return p



def _normalise(packets):
    """Accept ``(dir, payload)`` or ``(dir, payload, wire_len)``.

    The third element is the TRUE on-wire length, which a capture knows even
    when it stored only part of the payload.  Passing it lets the DATALEN
    identity be solved from truncated records — on the archived captures that
    is most of the file, and without it a whole endpoint can fail to solve and
    every one of its packets is reported as unparsed.
    """
    out = []
    for row in packets:
        if len(row) == 3:
            d, b, n = row
        else:
            d, b = row
            n = len(b) if b else 0
        if not b or header_size(b[0]) is None:
            continue
        if n is None or n < len(b):
            n = len(b)
        out.append((d, b, n))
    return out


# ---------------------------------------------------------------- solver

def solve(packets, direction="OUT"):
    """Recover ``(mask, order)`` from raw datagrams.

    ``packets`` is an iterable of ``(direction, bytes)``.  Uses the DATALEN
    identity ``Length == len - hdr``, which only holds outbound: an inbound
    ``Length`` is the PRE-COMPRESSION size when ``FLAG_ZIP`` is set.

    The identity alone is UNDER-DETERMINED — on one real capture twelve
    permutations fit it at 100 % and only six decoded to sane commands, because
    OrderID contributes no bytes on non-reliable packets (most traffic) so its
    position is unobservable there.  Every tying candidate is therefore scored
    on whether the fields it implies are plausible, and the best kept.

    Returns ``(mask, order, hits, tested)``; ``(None, None, 0, tested)`` on
    failure.
    """
    rows = _normalise(packets)
    cand = [r for r in rows if r[0] == direction] or rows
    # Scoring must see BOTH directions.  Outbound OrderIDs are small integers
    # that pass for command ids, so an OUT-only score cannot tell the true
    # order from the one with Cmd and OrderID swapped; inbound OrderIDs run
    # into the thousands and blow straight past MAX_CMD.  Scoring on OUT alone
    # is what made this solver read OrderID as Cmd on every reliable inbound
    # packet — 2666 of 15422 in one session.
    score_rows = rows
    votes = collections.Counter()
    tested = 0
    for _, b, wire in cand[:6000]:
        hdr = header_size(b[0])
        if hdr is None or len(b) < hdr:
            continue
        reliable = (hdr == HDR_RELIABLE)
        pay = wire - hdr
        tested += 1
        for order in itertools.permutations(DEFAULT_ORDER):
            offs, end = field_offsets(order, reliable)
            if end != hdr:
                continue
            o = offs[DATALEN]
            m = b[o] ^ (pay & 0xFF)
            if (b[o + 1] ^ m) == ((pay >> 8) & 0xFF):
                votes[(m, order)] += 1
    if not votes:
        return None, None, 0, tested

    ranked = _rank(votes, score_rows)
    if not ranked:
        (m, order), hits = votes.most_common(1)[0]
        return m, order, hits, tested
    score, m, order, hits = ranked[0]
    return m, order, hits, tested


def solve_candidates(packets, direction="OUT", k=6):
    """The top ``k`` ``(score, mask, order, hits)`` candidates, best first.

    Exposed because the header solve is genuinely under-determined from the
    header alone: a caller that can also decode bodies has a much stronger
    oracle and should re-rank these.  See
    :meth:`ffproto.analyze.Analysis._refine_layout`.
    """
    rows = _normalise(packets)
    cand = [r for r in rows if r[0] == direction] or rows
    votes = collections.Counter()
    for _, b, wire in cand[:6000]:
        hdr = header_size(b[0])
        if hdr is None or len(b) < hdr:
            continue
        reliable = (hdr == HDR_RELIABLE)
        pay = wire - hdr
        for order in itertools.permutations(DEFAULT_ORDER):
            offs, end = field_offsets(order, reliable)
            if end != hdr:
                continue
            o = offs[DATALEN]
            m = b[o] ^ (pay & 0xFF)
            if (b[o + 1] ^ m) == ((pay >> 8) & 0xFF):
                votes[(m, order)] += 1
    if not votes:
        return []
    return _rank(votes, rows)[:k]


def _rank(votes, score_rows):
    """Score every candidate that ties on the DATALEN identity.

    The tie set is large — 24 orders on one real session — because OrderID
    contributes no bytes to a non-reliable packet and most traffic is
    non-reliable, so its slot is invisible there.  Each candidate is scored
    together with its SendOption/Flags swap, since those two are both one byte
    wide and swapping them moves no offset at all.

    Scoring the swap *alongside* the original rather than substituting it
    matters: an earlier version replaced each candidate with whichever of the
    pair won a narrower test, which could turn a correct order into a wrong
    one before the real scoring ever saw it.
    """
    top = votes.most_common(240)
    if not top:
        return []
    ceiling = top[0][1]
    seen = set()
    out = []
    for (mm, oo), hh in top:
        if hh < ceiling:
            break
        for cand in (oo, _swap_one_byte(oo)):
            if (mm, cand) in seen:
                continue
            seen.add((mm, cand))
            out.append((_plausibility(score_rows, mm, cand), mm, cand, hh))
    out.sort(key=lambda t: -t[0])
    return out


def _swap_one_byte(order):
    """The same order with SendOption and Flags exchanged."""
    o = list(order)
    i, j = o.index(SENDOPTION), o.index(FLAGS)
    o[i], o[j] = o[j], o[i]
    return tuple(o)


def _plausibility(rows, m, order, limit=6000):
    """Score a candidate layout on whether the fields it implies are legal.

    Three independent terms, all on the same packets:

    * ``Cmd`` is an id the game's own catalogue defines — the strongest signal
      available, because we have all 1974 of them;
    * ``Flags`` stays inside ``{0..3}``;
    * ``SendOption``'s reliability agrees with the MsgKey range.

    Returns a fraction in ``[0, 1]``; the catalogue term dominates because it
    is the one that cannot be satisfied by accident.
    """
    layout = HeaderLayout(m, order)
    known = legal = tot = 0
    for row in rows[:limit]:
        p = parse(row[1], layout)
        if p is None:
            continue
        tot += 1
        if _catalogue_knows(p.cmd):
            known += 1
        if (p.cmd <= MAX_CMD and (p.flags & ~0x03) == 0
                and (p.send_option in RELIABLE_SEND_OPTIONS) == p.reliable):
            legal += 1
    if not tot:
        return 0.0
    return 2.0 * (known / tot) + (legal / tot)


_KNOWN = None


def _catalogue_knows(cmd):
    """``CmdCatalogue.isKnown`` without importing it on every call."""
    global _KNOWN
    if _KNOWN is None:
        try:
            from . import catalogue
            _KNOWN = frozenset(catalogue.all_ids())
        except Exception:
            _KNOWN = frozenset()
    return cmd in _KNOWN


def solve_layout(packets, direction="OUT"):
    """:func:`solve` wrapped into a :class:`HeaderLayout`; ``None`` on failure."""
    m, order, hits, tested = solve(packets, direction)
    if m is None:
        return None, 0, tested
    return HeaderLayout(m, order), hits, tested
