"""Message-class field layouts, keyed on ``(cmd, direction)``.

Why ``(cmd, direction)`` and never ``cmd``
-----------------------------------------
``IL2CPP_FINDINGS.md`` §2: **messages are bidirectional with DIFFERENT classes
per direction.**  Cmd 106 is ``GMDJLCGLDCH`` (8 fields) inbound and
``MMJPICCOJOM`` (22 fields) outbound.  A single-layout decoder is wrong in one
direction, and that has already produced one wrong conclusion in this project,
so every lookup here takes a direction and there is no ``cmd``-only accessor.

Where the layouts come from
---------------------------
* **outbound** — ``tools/il2cpp/ff_outbound_registry.txt`` (cmd → class) plus
  ``tools/il2cpp/ff_outbound_classes.json`` (288 class bodies), both committed.
* **inbound** — ``tools/il2cpp/ff_inbound_registry.tsv`` (1384 cmd → class)
  plus a class-body index built once from ``dump.cs``.

``dump.cs`` is a **DIFFERENT BUILD** (``IL2CPP_FINDINGS.md`` §0 TRAP 2).  It is
used here for **structure only** — declared field order and types — which is
build-stable and was verified on 11 independent classes across two builds.  No
RVA from it is ever used.  Every layout carries a ``source`` tag so a report can
say where a field position came from, and layouts whose class body also exists
in the committed outbound artifact are cross-checked field-for-field at build
time.

Wire encoding (``FastBinaryReader``, findings §3)
-------------------------------------------------
======================  ===========================================
C# declared type        wire form
======================  ===========================================
``byte`` ``sbyte``      **1 RAW byte**
``bool``                **1 RAW byte**
``ushort`` ``uint``     LEB128 varint
``ulong``               LEB128 varint
``short`` ``int``       LEB128 varint then zigzag
``long``                LEB128 varint then zigzag
``float``               one varint whose bits ARE the float32
``string``              ``[zigzag varint length][UTF-8]``
``List<T>``             ``[zigzag varint count]`` then T, count times
enum                    its ``value__`` underlying type
nested message class    its own fields, inline
======================  ===========================================

``ReadFixUInt16`` (2 RAW little-endian bytes) is a *reader method*, not a type,
so a declared ``ushort`` cannot be told apart from a varint one by structure
alone.  :data:`FIX16_OVERRIDES` names the fields known to use it; everything
else defaults to varint and the length check in :mod:`ffproto.decode` is what
catches a mistake.
"""

from __future__ import annotations

import csv
import io
import json
import os
import re

_HERE = os.path.dirname(os.path.abspath(__file__))
_REPO = os.path.dirname(os.path.dirname(_HERE))
IL2CPP_DIR = os.path.join(_REPO, "tools", "il2cpp")

INBOUND_REGISTRY = os.path.join(IL2CPP_DIR, "ff_inbound_registry.tsv")
OUTBOUND_REGISTRY = os.path.join(IL2CPP_DIR, "ff_outbound_registry.txt")
OUTBOUND_CLASSES = os.path.join(IL2CPP_DIR, "ff_outbound_classes.json")
DEOBFUSCATION_MAP = os.path.join(IL2CPP_DIR, "ff_deobfuscation_map.json")
LAYOUT_INDEX = os.path.join(IL2CPP_DIR, "ff_message_layouts.json")

DEFAULT_DUMP_CS = r"C:\Users\Tonyt\Videos\ZRT-Toolbox\Dump\dump.cs"

IN, OUT = "IN", "OUT"

# ---------------------------------------------------------------- encodings

KIND_RAW1 = "raw1"        # byte / sbyte / bool — 1 RAW byte
KIND_FIX16 = "fix16"      # ReadFixUInt16 — 2 RAW little-endian bytes
KIND_VARINT = "varint"    # LEB128
KIND_ZIGZAG = "zigzag"    # LEB128 then zigzag
KIND_F32 = "f32"          # LEB128 whose bits are the float32
KIND_F64 = "f64"          # LEB128 whose bits are the float64 (unverified)
KIND_STRING = "string"

_PRIMITIVES = {
    "byte": KIND_RAW1, "sbyte": KIND_RAW1, "bool": KIND_RAW1,
    "ushort": KIND_VARINT, "uint": KIND_VARINT, "ulong": KIND_VARINT,
    "short": KIND_ZIGZAG, "int": KIND_ZIGZAG, "long": KIND_ZIGZAG,
    "float": KIND_F32, "double": KIND_F64,
    "string": KIND_STRING,
    "UInt16": KIND_VARINT, "UInt32": KIND_VARINT, "UInt64": KIND_VARINT,
    "Int16": KIND_ZIGZAG, "Int32": KIND_ZIGZAG, "Int64": KIND_ZIGZAG,
    "Byte": KIND_RAW1, "SByte": KIND_RAW1, "Boolean": KIND_RAW1,
    "Single": KIND_F32, "Double": KIND_F64, "String": KIND_STRING,
}

# Fields the serializer reads with ReadFixUInt16 rather than the varint path.
# Keyed "ClassName.fieldName".  Empty until a field is proven; the decoder's
# exact-length check is what surfaces a candidate.
FIX16_OVERRIDES = {}

_LIST_RE = re.compile(r"^List<(.+)>$")
_ARRAY_RE = re.compile(r"^(.+)\[\]$")
_NULLABLE_RE = re.compile(r"^Nullable<(.+)>$")


# ---------------------------------------------------------------- nodes

class Node(object):
    """One entry in a message layout tree."""

    __slots__ = ("kind", "name", "ctype", "children", "elem", "enum")

    def __init__(self, kind, name, ctype, children=None, elem=None, enum=None):
        self.kind = kind          # a KIND_*, or 'struct' / 'list' / 'opaque'
        self.name = name
        self.ctype = ctype
        self.children = children or []
        self.elem = elem
        self.enum = enum

    def __repr__(self):
        return "Node(%s %s:%s)" % (self.kind, self.name, self.ctype)


class Layout(object):
    """A resolved message layout for one ``(cmd, direction)``."""

    __slots__ = ("cmd", "direction", "cls", "root", "source", "complete",
                 "unresolved")

    def __init__(self, cmd, direction, cls, root, source, complete, unresolved):
        self.cmd = cmd
        self.direction = direction
        self.cls = cls
        self.root = root
        self.source = source
        self.complete = complete            # no opaque node anywhere
        self.unresolved = unresolved        # type names that could not resolve

    def __repr__(self):
        return ("Layout(cmd=%d %s %s src=%s %s)"
                % (self.cmd, self.direction, self.cls, self.source,
                   "complete" if self.complete else
                   "partial:" + ",".join(sorted(self.unresolved))))


# ---------------------------------------------------------------- dump.cs

_CLASS_RE = re.compile(
    r"^(?:public |internal |private |protected |sealed |abstract |static |partial )*"
    r"(class|struct)\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?::\s*([^/{]+?))?\s*(?://.*)?$")
_ENUM_RE = re.compile(
    r"^(?:public |internal |private |protected )*enum\s+"
    r"([A-Za-z_][A-Za-z0-9_]*)\s*(?://.*)?$")
_FIELD_RE = re.compile(
    r"^\s*public\s+(?:readonly\s+)?([A-Za-z_][\w.<>,\[\] ]*?)\s+"
    r"([A-Za-z_]\w*)\s*;\s*//\s*(0x[0-9A-Fa-f]+)\s*$")
_ENUM_MEMBER_RE = re.compile(
    r"^\s*public\s+const\s+\w+\s+([A-Za-z_]\w*)\s*=\s*(-?\d+)\s*;")
_NS_RE = re.compile(r"^//\s*Namespace:\s*(\S*)\s*$")


def build_index(dump_cs=None, out_path=None, verbose=True):
    """Index every message class and enum in ``dump.cs`` into a JSON file.

    Structure only — see the module docstring on TRAP 2.  Returns the index
    dict; also writes it to ``out_path`` (default
    ``tools/il2cpp/ff_message_layouts.json``).
    """
    dump_cs = dump_cs or os.environ.get("FF_DUMP_CS", DEFAULT_DUMP_CS)
    out_path = out_path or LAYOUT_INDEX
    classes, enums = {}, {}
    ns = ""
    cur = None          # (name, base, kind, fields)
    cur_enum = None     # (name, underlying, members)
    depth = 0
    scanned = 0

    with io.open(dump_cs, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            scanned += 1
            stripped = line.strip()
            m = _NS_RE.match(stripped)
            if m:
                ns = m.group(1)
                continue
            if cur is not None or cur_enum is not None:
                if stripped == "{":
                    depth += 1
                    continue
                if stripped == "}":
                    depth -= 1
                    if depth <= 0:
                        if cur is not None:
                            name, base, ckind, fields, cns = cur
                            if _keep(name, base, cns):
                                classes[name] = {
                                    "namespace": cns, "base": base,
                                    "kind": ckind, "fields": fields}
                            cur = None
                        else:
                            name, und, members, ens = cur_enum
                            enums[name] = {"namespace": ens,
                                           "underlying": und,
                                           "members": members}
                            cur_enum = None
                        depth = 0
                    continue
                if cur is not None:
                    fm = _FIELD_RE.match(line.rstrip("\n"))
                    if fm and depth == 1:
                        ctype = fm.group(1).strip()
                        if ctype.startswith("static ") or " const " in ctype:
                            continue
                        cur[3].append([ctype, fm.group(2), fm.group(3)])
                    continue
                em = _ENUM_MEMBER_RE.match(line)
                if em:
                    cur_enum[2][em.group(2)] = em.group(1)
                    continue
                fm = _FIELD_RE.match(line.rstrip("\n"))
                if fm and fm.group(2) == "value__":
                    cur_enum[1] = fm.group(1).strip()
                continue

            cm = _CLASS_RE.match(stripped)
            if cm:
                base = (cm.group(3) or "").strip()
                cur = [cm.group(2), base, cm.group(1), [], ns]
                cur = (cur[0], cur[1], cur[2], cur[3], cur[4])
                depth = 0
                continue
            em = _ENUM_RE.match(stripped)
            if em:
                cur_enum = [em.group(1), "uint", {}, ns]
                depth = 0
                continue

    index = {"classes": classes, "enums": enums,
             "source": os.path.abspath(dump_cs),
             "note": "STRUCTURE ONLY - dump.cs is a different build; no RVA "
                     "from it is valid against our image.",
             "lines_scanned": scanned}
    merged, conflicts = _merge_outbound_artifact(index)
    index["outbound_artifact_classes"] = merged
    index["outbound_artifact_conflicts"] = conflicts
    if out_path:
        with io.open(out_path, "w", encoding="utf-8") as fh:
            json.dump(index, fh, separators=(",", ":"))
    if verbose:
        print("indexed %d classes, %d enums from %d lines of %s"
              % (len(classes), len(enums), scanned, dump_cs))
        print("cross-checked against %s: %d classes present, %d field-order "
              "conflicts" % (os.path.basename(OUTBOUND_CLASSES), merged,
                             len(conflicts)))
        for c in conflicts[:10]:
            print("   conflict:", c)
    return index


def _keep(name, base, ns):
    """Message-carrying types only: the ``message`` namespace plus anything
    deriving ``UDPClientMessageBase``, which is what the wire uses."""
    if ns == "message":
        return True
    return "UDPClientMessageBase" in (base or "")


def _parse_class_body(lines):
    """Fields out of a dump.cs-style class body (the outbound artifact form)."""
    fields = []
    for line in lines:
        m = _FIELD_RE.match(line.rstrip("\n"))
        if m:
            fields.append([m.group(1).strip(), m.group(2), m.group(3)])
        if line.strip().startswith("// Methods"):
            break
    return fields


def _merge_outbound_artifact(index):
    """Fold ``ff_outbound_classes.json`` in and report field-order conflicts."""
    if not os.path.exists(OUTBOUND_CLASSES):
        return 0, []
    with io.open(OUTBOUND_CLASSES, encoding="utf-8") as fh:
        blobs = json.load(fh)
    conflicts, merged = [], 0
    for cls, lines in blobs.items():
        fields = _parse_class_body(lines)
        if not fields:
            continue
        merged += 1
        have = index["classes"].get(cls)
        if have is None:
            index["classes"][cls] = {"namespace": "message", "base": "",
                                     "kind": "class", "fields": fields}
            continue
        a = [(f[0], f[1]) for f in have["fields"]]
        b = [(f[0], f[1]) for f in fields]
        if a != b:
            conflicts.append("%s: artifact=%d dumpcs=%d" % (cls, len(b), len(a)))
    return merged, conflicts


# ---------------------------------------------------------------- registries

def load_inbound_registry(path=None):
    """``cmd -> inbound class name`` from the committed 1384-row TSV."""
    path = path or INBOUND_REGISTRY
    out = {}
    if not os.path.exists(path):
        return out
    with io.open(path, encoding="utf-8", errors="replace", newline="") as fh:
        for row in csv.reader(fh, delimiter="\t"):
            if len(row) < 3 or not row[0].isdigit():
                continue
            out[int(row[0])] = row[2].strip()
    return out


#: Outbound ``cmd -> class`` the automated send-site scan could not resolve
#: (its class column is ``?``) or never saw, recovered by hand in
#: ``docs/IL2CPP_FINDINGS.md``.  Each entry cites where it came from; nothing
#: here is a guess.
OUTBOUND_CLASS_OVERRIDES = {
    # §5.1: "of 461 GameFacade::Send sites, exactly one passes 2001 —
    # 0x078CF1D4", class message.DAIDIMLOEPL wrapping message.ACDHGKMPIDJ.
    2001: "DAIDIMLOEPL",
    # §1: the same hit-claim class is reused per victim type.  31 construction
    # sites, all inside TakeDamage overrides.
    127: "MMJPICCOJOM", 166: "MMJPICCOJOM", 222: "MMJPICCOJOM",
    240: "MMJPICCOJOM", 394: "MMJPICCOJOM", 865: "MMJPICCOJOM",
    # §7.3, send site COW.GamePlay.IHFFDJIDIAA::NMPDDOPCHBN+0x16c.
    413: "DAFMJPEBBHI", 607: "ODAFMPDAEIL", 608: "FDDGNOMMIGP",
    1492: "NNHMKOLHBCL",
}

#: ``(cmd, direction) -> class name`` for ids the send-site scan never covers
#: because the transport layer sends them, not ``GameFacade::Send``.  The class
#: names here survived obfuscation and were confirmed byte-exact on real wire
#: data; the sample count is recorded next to each.
TRANSPORT_CLASS_OVERRIDES = {
    # 217/217 bodies on capture_raw_20260910_175549 decode exactly.
    (3, OUT): "C2S_UDP_Ping_Req",
    # The fragment carrier; the class name kept both prefixes, so one class
    # serves both directions.
    (99, IN): "S2C_C2S_RUDP_SPLITTED_DATAGRAM",
    (99, OUT): "S2C_C2S_RUDP_SPLITTED_DATAGRAM",
}

#: Layouts derived from the wire rather than from a class body, for ids where
#: no class could be identified.  Each is ``[(ctype, field name), ...]`` in wire
#: order, with the evidence recorded in the comment.
SYNTHETIC_LAYOUTS = {
    # UDP_SYNC_SERVER_TIME outbound is one LEB128 uint: 112/112 bodies on
    # capture_raw_20260910_175549 are exactly that, and the matching inbound
    # class KAAKGAONPBH is uint+byte, i.e. the same clock plus one extra byte.
    (2000, OUT): [("uint", "clientTimeMs")],
    # UDP_ACK.  The body is QQ-TEA encrypted and decrypts to exactly two
    # bytes on 299/299 samples in captures/phone_kick, the first counting up
    # per ack.  IL2CPP_FINDINGS §6 predicted this ("the encrypted 24 B stream
    # decrypts with the session key and carries ~2 bytes, a counter") and this
    # is the measurement.  CAVEAT: with every observed value below 128 a
    # varint and a raw byte are indistinguishable here, so the two widths are
    # inferred from the shape, not proven.
    (2, IN): [("uint", "ackId"), ("byte", "tail")],
    (2, OUT): [("uint", "ackId"), ("byte", "tail")],
}

_OUT_ROW_RE = re.compile(r"^\s*(-?\d+)\s+([0-9a-fA-F]+)\s+(\S+)\s+(\S+)")


def load_outbound_registry(path=None):
    """``cmd -> outbound class name`` from the 461-row send-site list."""
    path = path or OUTBOUND_REGISTRY
    out = {}
    if not os.path.exists(path):
        return out
    with io.open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            m = _OUT_ROW_RE.match(line)
            if not m:
                continue
            cmd = int(m.group(1))
            cls = m.group(3)
            if cmd < 0 or cls in ("?", "-"):
                continue
            out.setdefault(cmd, cls)
    for cmd, cls in OUTBOUND_CLASS_OVERRIDES.items():
        out.setdefault(cmd, cls)
    return out


def load_deobfuscation_map(path=None):
    path = path or DEOBFUSCATION_MAP
    if not os.path.exists(path):
        return {}
    with io.open(path, encoding="utf-8") as fh:
        return json.load(fh)


# ---------------------------------------------------------------- schema

class Schema(object):
    """Resolved layouts for every ``(cmd, direction)`` we have a class for."""

    def __init__(self, index_path=None):
        self.index_path = index_path or LAYOUT_INDEX
        self.classes = {}
        self.enums = {}
        self.index_note = ""
        if os.path.exists(self.index_path):
            with io.open(self.index_path, encoding="utf-8") as fh:
                idx = json.load(fh)
            self.classes = idx.get("classes", {})
            self.enums = idx.get("enums", {})
            self.index_note = idx.get("note", "")
        else:
            # No dump.cs index yet — still serve the committed outbound bodies.
            stub = {"classes": {}, "enums": {}}
            _merge_outbound_artifact(stub)
            self.classes = stub["classes"]
        self.inbound = load_inbound_registry()
        self.outbound = load_outbound_registry()
        self.deob = load_deobfuscation_map()
        self._cache = {}

    # -- class lookup ---------------------------------------------------
    def class_for(self, cmd, direction):
        over = TRANSPORT_CLASS_OVERRIDES.get((cmd, direction))
        if over:
            return over
        reg = self.inbound if direction == IN else self.outbound
        return reg.get(cmd)

    def has_class(self, name):
        return name in self.classes

    def readable(self, obf):
        """The binary's own de-obfuscation table, when it knows the name."""
        return self.deob.get(obf)

    # -- layout resolution ----------------------------------------------
    def layout(self, cmd, direction):
        """The :class:`Layout` for ``(cmd, direction)``, or ``None``."""
        key = (cmd, direction)
        if key in self._cache:
            return self._cache[key]
        syn = SYNTHETIC_LAYOUTS.get(key)
        if syn is not None:
            children, unres = [], set()
            for ctype, fname in syn:
                node, u = self._field(ctype, fname, "<wire>", set(), 1)
                children.append(node)
                unres |= u
            root = Node("struct", "<wire:%d/%s>" % (cmd, direction),
                        "<wire>", children=children)
            lay = Layout(cmd, direction, "<wire:%d/%s>" % (cmd, direction),
                         root, "wire", not unres, unres)
            self._cache[key] = lay
            return lay
        cls = self.class_for(cmd, direction)
        lay = None
        if cls:
            root, unresolved = self._build(cls, set(), 0)
            if root is not None:
                if (cmd, direction) in TRANSPORT_CLASS_OVERRIDES:
                    src = "transport-override"
                elif cmd in OUTBOUND_CLASS_OVERRIDES and direction == OUT:
                    src = "findings-override"
                else:
                    src = "registry+dumpcs" if direction == IN else "registry+artifact"
                lay = Layout(cmd, direction, cls, root, src,
                             not unresolved, unresolved)
        self._cache[key] = lay
        return lay

    def _build(self, cls, seen, depth):
        """Layout tree for a class; returns ``(node, unresolved_type_names)``."""
        if depth > 12 or cls in seen:
            return Node("opaque", cls, cls), {cls}
        info = self.classes.get(cls)
        if info is None:
            return None, {cls}
        seen = seen | {cls}
        children, unresolved = [], set()
        for ctype, fname, _off in info["fields"]:
            node, unres = self._field(ctype, fname, cls, seen, depth + 1)
            children.append(node)
            unresolved |= unres
        return Node("struct", cls, cls, children=children), unresolved

    def _field(self, ctype, fname, owner, seen, depth):
        ctype = ctype.strip()
        m = _NULLABLE_RE.match(ctype)
        if m:
            ctype = m.group(1).strip()
        m = _LIST_RE.match(ctype) or _ARRAY_RE.match(ctype)
        if m:
            elem, unres = self._field(m.group(1).strip(), "item", owner,
                                      seen, depth + 1)
            return Node("list", fname, ctype, elem=elem), unres

        key = "%s.%s" % (owner, fname)
        if key in FIX16_OVERRIDES:
            return Node(KIND_FIX16, fname, ctype), set()

        prim = _PRIMITIVES.get(ctype)
        if prim:
            return Node(prim, fname, ctype), set()

        en = self.enums.get(ctype)
        if en:
            kind = _PRIMITIVES.get(en.get("underlying", "uint"), KIND_VARINT)
            return Node(kind, fname, ctype, enum=en.get("members") or {}), set()

        node, unres = self._build(ctype, seen, depth)
        if node is None:
            return Node("opaque", fname, ctype), {ctype}
        node.name = fname
        return node, unres

    # -- reporting -------------------------------------------------------
    def coverage(self):
        """How many ids have a class, and how many of those fully resolve."""
        out = {}
        for direction, reg in ((IN, self.inbound), (OUT, self.outbound)):
            have = complete = 0
            for cmd in reg:
                lay = self.layout(cmd, direction)
                if lay is not None:
                    have += 1
                    if lay.complete:
                        complete += 1
            out[direction] = {"ids_with_class": len(reg),
                              "ids_with_layout": have,
                              "ids_fully_resolved": complete}
        out["classes_indexed"] = len(self.classes)
        out["enums_indexed"] = len(self.enums)
        return out


_SCHEMA = None


def default_schema():
    global _SCHEMA
    if _SCHEMA is None:
        _SCHEMA = Schema()
    return _SCHEMA


# ---------------------------------------------------------------- annotations

#: Field semantics established by re-deriving from OUR OWN image and by wire
#: correlation, with the sample counts that back them.  Purely descriptive —
#: the decoder never reshapes a layout from this table, it only labels.
VERIFIED_NOTES = {
    (106, IN): {
        0: "attacker id", 1: "victim id", 2: "damage (HP)",
        3: "shield damage (SP) [PLAUSIBLE only for 106; CONFIRMED for 168.v12]",
        4: "weaponDataID (negative = environmental: -10 burning)",
        5: "buff id (>0 => this tick is a damage-over-time buff)",
        6: "ESpecialHitType bitmask", 7: "HitBodyPart (Head=1 Body=2 Limb=3)",
    },
    (2010, IN): {
        2: "weapon (zigzag)", 3: "tick",
        4: "damage absorbed by SP (plain u16 varint, not zigzag)",
        5: "damage to HP (plain u16 varint, not zigzag)",
    },
    (2001, OUT): {
        0: "PlayerID",
        1: "pos X mm", 2: "pos UP mm", 3: "pos Z mm",
        4: "aim#1 x*100", 5: "aim#1 y*100", 6: "aim#1 z*100",
        7: "move dir X*100", 8: "move dir Z*100",
        9: "velocity X cm/s", 10: "velocity Y cm/s", 11: "velocity Z cm/s",
        12: "EPHYSXSTATE (RAW byte)", 13: "EPHYSXPOSE (RAW byte)",
        14: "aim#2 x (float32)", 15: "aim#2 y", 16: "aim#2 z",
        17: "moving-platform id (position becomes platform-relative when != 0)",
        18: "low-gravity area (RAW byte)", 19: "ping ms (garbage before "
            "m_StartShowTime: the game sends Random.Range(0,100))",
        20: "UGC only (RAW byte)", 21: "bezier path pos | slideId<<24",
        22: "snowslide side / lobby voice (RAW byte, CAN EXCEED 127)",
        23: "client ms clock (outer wrapper field)",
    },
    (135, IN): {0: "visibility bitmask; SET bit = that player IS VISIBLE to "
                   "you; bit i = entity id i, bit = id mod 64"},
}

#: Position scale.  ``IL2CPP_FINDINGS.md`` §5.1 bug 1: the shipped app's
#: ``UNITS_PER_METRE = 950`` is wrong — ``KANJBNIANHC::COGCJKJPPHI`` multiplies
#: by a literal ``1000.0f``.  Offline tooling uses the code-derived value.
UNITS_PER_METRE = 1000.0

#: ``COW.GamePlay.LLEDPGIGCMO`` / ``message.FMGIHBIIMHL`` — the hit zone.
HIT_ZONES = {0: "None", 1: "Head", 2: "Body", 3: "Limb", 4: "Vehicle",
             5: "Protection", 6: "UAV", 7: "Shoal", 8: "OilDrum", 9: "IceWall",
             10: "Landmine", 11: "MiniSentry", 12: "Shield",
             71: "Glass", 72: "Fragment", 73: "WukongIllusion"}


if __name__ == "__main__":
    s = default_schema()
    print("index:", s.index_path, "exists" if os.path.exists(s.index_path) else "MISSING")
    print("coverage:", json.dumps(s.coverage(), indent=2))
    for cmd, d in ((106, IN), (106, OUT), (2001, OUT), (2001, IN), (135, IN)):
        print("  ", cmd, d, s.layout(cmd, d))
