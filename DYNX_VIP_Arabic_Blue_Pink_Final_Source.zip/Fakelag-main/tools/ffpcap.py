"""pcap -> decoded FF UDP messages, using tools/ffdecode.py."""
import sys, os, struct, collections
sys.path.insert(0, r"C:\Users\Tonyt\Documents\GitHub\Fakelag\tools")
import ffdecode as F

def read_pcap(path):
    """yields (ts_float, src, sport, dst, dport, udp_payload)"""
    with open(path,'rb') as f:
        gh = f.read(24)
        magic = struct.unpack('<I', gh[:4])[0]
        if magic == 0xa1b2c3d4: end, nano = '<', False
        elif magic == 0xd4c3b2a1: end, nano = '>', False
        elif magic == 0xa1b23c4d: end, nano = '<', True
        elif magic == 0x4d3cb2a1: end, nano = '>', True
        else: raise ValueError("not pcap: %08x" % magic)
        linktype = struct.unpack(end+'I', gh[20:24])[0]
        while True:
            ph = f.read(16)
            if len(ph) < 16: break
            ts, tus, caplen, wirelen = struct.unpack(end+'IIII', ph)
            data = f.read(caplen)
            if len(data) < caplen: break
            t = ts + (tus/1e9 if nano else tus/1e6)
            # link layer
            if linktype == 1:      # ethernet
                if len(data) < 14: continue
                et = struct.unpack('>H', data[12:14])[0]
                off = 14
                if et == 0x8100: et = struct.unpack('>H', data[16:18])[0]; off = 18
                if et != 0x0800: continue
            elif linktype == 101 or linktype == 12:   # raw ip
                off = 0
            elif linktype == 113:  # linux cooked v1
                if len(data) < 16: continue
                if struct.unpack('>H', data[14:16])[0] != 0x0800: continue
                off = 16
            elif linktype == 276:  # linux cooked v2
                if len(data) < 20: continue
                if struct.unpack('>H', data[0:2])[0] != 0x0800: continue
                off = 20
            else:
                off = 14
            ip = data[off:]
            if len(ip) < 20 or (ip[0] >> 4) != 4: continue
            ihl = (ip[0] & 0xF) * 4
            if ip[9] != 17: continue
            src = '.'.join(str(b) for b in ip[12:16])
            dst = '.'.join(str(b) for b in ip[16:20])
            udp = ip[ihl:]
            if len(udp) < 8: continue
            sport, dport, ulen = struct.unpack('>HHH', udp[:6])
            yield t, src, sport, dst, dport, udp[8:ulen]

def match_stream(path, local_prefixes=('10.0.2.','192.168.','172.16.','10.')):
    rows = []
    for t, s, sp, d, dp, pay in read_pcap(path):
        if not pay: continue
        if not (F.MSG_KEY_MIN <= pay[0] <= F.MSG_KEY_MAX): continue
        out = any(s.startswith(p) for p in local_prefixes)
        rows.append((t, 'OUT' if out else 'IN', dp if out else sp, pay))
    # pick dominant port
    c = collections.Counter(r[2] for r in rows)
    if not c: return None, []
    port = c.most_common(1)[0][0]
    return port, [(t,d,b) for t,d,p,b in rows if p == port]

def varints(buf):
    out, i = [], 0
    pos = []
    while i < len(buf):
        v = s = 0; ok=False; st=i
        while i < len(buf):
            c = buf[i]; v |= (c & 0x7f) << s; i += 1; s += 7
            if not (c & 0x80): ok=True; break
            if s > 70: return out, pos, False
        if not ok: return out, pos, False
        out.append(v); pos.append((st, i-st))
    return out, pos, True

def rdvar(buf, i):
    v = s = 0
    while i < len(buf):
        c = buf[i]; v |= (c & 0x7f) << s; i += 1; s += 7
        if not (c & 0x80): return v, i
        if s > 70: break
    return None, i

zz = lambda v: (v >> 1) ^ -(v & 1)
