# -*- coding: utf-8 -*-
"""Removes the body-decoder registry path, which decodes nothing.

Proven inert: BodyDecoderRegistry.register / registerCode / setFallback have
exactly one caller between them -- EspBodyDecoders.register -- and THAT has
zero callers, so the registry is never populated. PacketPipeline.setSessionKey
also has zero callers, so keySchedule is permanently null and every encrypted
body bails. dispatch() is called twice per packet and can only ever return
false.

EspBodyDecoders is additionally a verbatim copy of the live shape gates in
PacketLoop and UdpSessionManager, and its own javadoc says wiring it up would
double-feed EspEngine.
"""
import io, os, re

BASE = r'C:\Users\Tonyt\Documents\GitHub\Fakelag\fakelag\fakelag-beta\app\src\main\java\com\fakelag\cryhard8'

P = os.path.join(BASE, 'protocol', 'PacketPipeline.java')
s = io.open(P, encoding='utf-8').read()
before = len(s.splitlines())

# the whole dispatch() + scratchFor() tail
i = s.index('    /**\n     * Makes the body readable and offers it to the registry.')
j = s.rindex('}')
s = s[:i] + '''    // THE BODY-DECODER REGISTRY PATH WAS REMOVED, NOT DISABLED.
    //
    // dispatch() was called on every parsed packet in both directions and
    // could never do anything: nothing ever registered a decoder (the only
    // registrar, EspBodyDecoders, had zero callers) and setSessionKey had
    // zero callers too, so the key schedule was permanently null and every
    // encrypted body bailed at the first check.
    //
    // What actually decodes, and still does, is the hand-written command
    // switch in UdpSessionManager (inbound, with BodyCrypt.decrypt inline)
    // and the shape gates in PacketLoop (outbound). Moving those into
    // decoders would be a net-zero line change on a field-tested hot path
    // with a documented double-feed hazard, so this is a deletion rather
    // than a migration. The design is in docs/ if the seam is ever wanted.
}
'''
s = s.replace('''    public BodyDecoderRegistry registry() {
        return registry;
    }

''', '')
s = s.replace('''    /**
     * Supplies the 16-byte TEA session key, enabling encrypted bodies. Pass
     * null to forget it.
     */
    public void setSessionKey(byte[] key) {
        keySchedule = Tea.schedule(key);
    }

''', '')
s = s.replace('    private final BodyDecoderRegistry registry = new BodyDecoderRegistry();\n', '')
s = s.replace('import com.nuvola.app.decode.body.BodyDecoderRegistry;\n', '')
io.open(P, 'w', encoding='utf-8').write(s)
print('PacketPipeline: %d -> %d lines' % (before, len(s.splitlines())))

# the two call sites
for rel, needle in [(('tunnel', 'PacketLoop.java'),
                     '                pipeline.dispatch(parsed, Direction.OUTBOUND);\n'),
                    (('tunnel', 'UdpSessionManager.java'),
                     '                        pipeline.dispatch(parsed, Direction.INBOUND);\n')]:
    p = os.path.join(BASE, *rel)
    t = io.open(p, encoding='utf-8').read()
    if needle in t:
        t = t.replace(needle, '', 1)
        io.open(p, 'w', encoding='utf-8').write(t)
        print('call site removed:', rel[-1])
    else:
        print('  !! not found in', rel[-1])

for rel in [('decode', 'body', 'BodyDecoderRegistry.java'),
            ('decode', 'body', 'BodyDecoder.java'),
            ('esp', 'EspBodyDecoders.java')]:
    p = os.path.join(BASE, *rel)
    if os.path.exists(p):
        n = len(io.open(p, encoding='utf-8').read().splitlines())
        os.remove(p)
        print('deleted %-28s %4d lines' % (rel[-1], n))
