#!/usr/bin/env python3
"""Offline proof for the Cmd 106 hit-point (idx9) head-move + zone flip.

Mirrors filter/AimFilter.java and esp/EspEngine.headPointForVictim on a REAL
captured OUT 106, then re-decodes the rewritten datagram *independently* with
tools/ffproto and asserts it is well-formed. Proves the rewrite before it ever
goes live -- no device or match needed.

Run:  python tools/aim_hitmove_sim.py

Checks, per the task spec:
  (a) the datagram re-parses as a valid 106,
  (b) CRC-7 is valid,
  (c) idx9 reads back as the intended head point,
  (d) the zone fields (idx3-hi, idx7, idx15 low bits) read back as Head,
  (e) the header Length field is consistent with the payload length.
Plus the step-3 frame/units check: the real idx9 hit point vs the victim's ESP
position (up-axis residual must be a head-height offset; units/frame must match).
"""
import os, sys, struct
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
from ffproto import capture, framing, crypto

CAP = os.path.join(ROOT, "captures", "phone_aim3", "capture_raw_20260912_150936.txt")
KEY = bytes.fromhex("6a08f4c30e37e07a2b4b2c83f0c4a93f")
PROG = "UUUUUZUBUZZZZZZ(F)UFUZBB(B)FBU"

# ---- field indices (mirror AimFilter PC_* constants) ----
PC_IDX0, PC_IDX3, PC_IDX7, PC_IDX8 = 0, 3, 7, 8
PC_IDX9_X, PC_IDX9_UP, PC_IDX9_Z, PC_IDX15 = 9, 10, 11, 21
ZONE_HEAD, ZONE_BODY = 1, 2
UNITS_PER_METRE = 1000.0
# AimFilter.cfgHeadHeightM default is now 1.35 m (was EspRenderView.AIM_HEIGHT_M
# = 1.70 m, which overshot the head: our idx9 UP=10050 vs a real accepted
# headshot 9687 on the same victim). Exercises the new HEAD HEIGHT knob.
HEAD_HEIGHT_M = 1.35
HEAD_MM = round(HEAD_HEIGHT_M * UNITS_PER_METRE)   # 1350
CP_MATCH_EPS_M = 0.015                    # AimFilter.CP_MATCH_EPS_M


def f_to_bits(f):
    return struct.unpack("<I", struct.pack("<f", f))[0]


def bits_to_f(b):
    return struct.unpack("<f", struct.pack("<I", b & 0xFFFFFFFF))[0]

# ---- LEB128 / zigzag (mirror PositionSync) ----
def zz_dec(u): return (u >> 1) ^ -(u & 1)
def zz_enc(v): return (v << 1) ^ (v >> 63) if v < 0 else (v << 1)
def vwidth(u):
    n = 1
    while True:
        u >>= 7
        if u == 0: return n
        n += 1
def write_padded(buf, start, width, u):
    for k in range(width - 1):
        buf[start + k] = (u & 0x7F) | 0x80
        u >>= 7
    buf[start + width - 1] = u & 0x7F
def write_canonical(buf, u):
    out = bytearray()
    while True:
        c = u & 0x7F
        u >>= 7
        if u != 0: out.append(c | 0x80)
        else: out.append(c); return bytes(out)

def walk(body):
    """Return {pc:(start,width,raw)} for scalar ops, or None (mirror AimFilter.walk)."""
    end = len(body); i = 0; pc = 0; f = {}
    def rdvar(i):
        v = 0; sh = 0
        while i < end:
            c = body[i]; i += 1; v |= (c & 0x7F) << sh
            if not (c & 0x80): return v, i
            sh += 7
            if sh > 63: return None, -1
        return None, -1
    while pc < len(PROG):
        op = PROG[pc]
        if op == '(':
            close = PROG.index(')', pc); cnt, ni = rdvar(i)
            if cnt is None: return None
            cnt = zz_dec(cnt)
            if cnt < 0 or cnt > 4096: return None
            i = ni; inner = PROG[pc + 1:close]
            for _ in range(cnt):
                for ic in inner:
                    if ic in 'UFZ':
                        v, ni = rdvar(i)
                        if v is None: return None
                        i = ni
                    else:
                        if i >= end: return None
                        i += 1
            pc = close + 1; continue
        s = i
        if op in 'UFZ':
            v, ni = rdvar(i)
            if v is None: return None
            f[pc] = (s, ni - s, v); i = ni
        else:
            if i >= end: return None
            f[pc] = (s, 1, body[s]); i += 1
        pc += 1
    if i != end: return None
    return f

def walk_cp(body):
    """Locate the checkParams '(F)' list: (countStart, listEnd, [(start,width,bits)])
    mirroring AimFilter.walk's cp capture. Returns None on a bad parse."""
    end = len(body); i = 0; pc = 0
    cp = {'start': -1, 'end': -1, 'count': 0, 'ents': []}
    def rdvar(i):
        v = 0; sh = 0
        while i < end:
            c = body[i]; i += 1; v |= (c & 0x7F) << sh
            if not (c & 0x80): return v, i
            sh += 7
            if sh > 63: return None, -1
        return None, -1
    while pc < len(PROG):
        op = PROG[pc]
        if op == '(':
            close = PROG.index(')', pc)
            count_start = i
            cnt, ni = rdvar(i)
            if cnt is None: return None
            cnt = zz_dec(cnt)
            if cnt < 0 or cnt > 4096: return None
            i = ni; inner = PROG[pc + 1:close]; is_f = (inner == "F")
            if is_f:
                cp['start'] = count_start; cp['count'] = cnt
            for _ in range(cnt):
                for ic in inner:
                    s = i
                    if ic in 'UFZ':
                        v, ni = rdvar(i)
                        if v is None: return None
                        i = ni
                    else:
                        if i >= end: return None
                        i += 1
                    if is_f and ic == 'F':
                        cp['ents'].append((s, i - s, v))
            if is_f: cp['end'] = i
            pc = close + 1; continue
        if op in 'UFZ':
            v, ni = rdvar(i)
            if v is None: return None
            i = ni
        else:
            if i >= end: return None
            i += 1
        pc += 1
    if i != end: return None
    return cp

# ---- checkParams permutation (mirror docs/CHECKPARAMS_DECODE.md §3) ----
def xorshift32(s):
    s &= 0xFFFFFFFF
    s ^= (s << 13) & 0xFFFFFFFF
    s ^= (s >> 17)
    s ^= (s << 5) & 0xFFFFFFFF
    return s & 0xFFFFFFFF

def fisher_yates_idx(n, seed_raw_idx0):
    """Per-victim backward Fisher-Yates (docs/CHECKPARAMS_ZONE_FIELD.md §3).

    Returns ``idx`` where ``idx[j]`` is the WIRE slot holding canonical entry j
    (forward map ``wire[idx[j]] = canon[j]``), so canonical entry j is patched in
    place at wire slot ``idx[j]``. Seed = the RAW idx0 word (full 32 bits, high
    byte INCLUDED) XOR 0xA3B1C6D9 -- NOT the 24-bit victim id. Mirrors
    AimFilter.fisherYatesIdx.
    """
    idx = list(range(n))
    s = (seed_raw_idx0 ^ 0xA3B1C6D9) & 0xFFFFFFFF
    if s == 0:
        s = 1
    i = n
    while i >= 2:
        s = xorshift32(s)
        k = s % i
        idx[i - 1], idx[k] = idx[k], idx[i - 1]
        i -= 1
    return idx


# Canonical zone triple canon[31,32,33]; canon[33] separates all three zones.
# Victim-invariant HEAD bit-values (mirror AimFilter.CANON_HEAD_*).
CANON_HEAD = {31: 0x3E3916A6, 32: 0x3E4760A6, 33: 0x3E3874C0}
CANON_ZONE_MAX = 33
HEAD33_LO, HEAD33_HI = 0.179, 0.181   # canon[33] head range (docs §2)

# ============================================================ ESP victim map
def build_esp(cf, layout):
    own_id = None
    for p in cf.packets:
        if p.dir != "OUT" or not p.payload: continue
        up = framing.parse(p.payload, layout)
        if up is None or up.reliable or up.cmd != 2001 or up.encrypted: continue
        b = up.body; i = 0; v = 0; sh = 0
        while i < len(b):
            c = b[i]; i += 1; v |= (c & 0x7F) << sh
            if not (c & 0x80): break
            sh += 7
        own_id = v & 0xFFFFFF; break
    class Cur:
        __slots__ = ("d", "i", "end")
        def __init__(s, d, i, e): s.d = d; s.i = i; s.end = e
    def vi(c):
        v = 0; sh = 0
        while c.i < c.end:
            ch = c.d[c.i]; c.i += 1; v |= (ch & 0x7F) << sh
            if not (ch & 0x80): return v
            sh += 7
        c.i = c.end; return -1
    def ps(d, start, end, decl):
        c = Cur(d, start, end); recs = []
        for _ in range(decl):
            eid = vi(c)
            if eid < 1 or eid > 64: return None
            x = vi(c); zzz = vi(c); y = vi(c)
            if x < 500: return None
            if eid == own_id:
                for _ in range(16):
                    if vi(c) < 0 and c.i >= end: return None
                recs.append((eid, zz_dec(x), zz_dec(zzz), zz_dec(y))); continue
            vi(c); vi(c); vi(c)
            if c.i + 3 > end: return None
            c.i += 3; vi(c); vi(c); vi(c); vi(c)
            if c.i > end: return None
            recs.append((eid, zz_dec(x), zz_dec(zzz), zz_dec(y)))
        if not (1 <= end - c.i <= 3): return None
        return recs
    def skv(b, i, e, n):
        for _ in range(n):
            dn = False
            while i < e:
                ch = b[i]; i += 1
                if not (ch & 0x80): dn = True; break
            if not dn: return -1
        return i
    tracks = {}
    for p in cf.packets:
        if p.dir != "IN" or not p.payload: continue
        pl = p.payload; pn = len(pl)
        if pn < 20 or pn > 1400 or pl[8] != 0 or (pl[9] & 1): continue
        decl = pl[9] // 2
        if not (1 <= decl <= 64): continue
        rs = skv(pl, 8, pn, 2)
        if rs < 0: continue
        recs = ps(pl, rs, pn, decl)
        if recs is None: continue
        for eid, x, zup, y in recs:
            tracks.setdefault(eid, []).append((p.ts_ms, x, zup, y))
    return own_id, tracks

def head_point(tracks, vid, ts):
    """Victim head point [X, UP+head, Z] mm at nearest tick, or None."""
    lst = tracks.get(vid)
    if not lst: return None
    ts_, x, zup, y = min(lst, key=lambda r: abs(r[0] - ts))
    return [x, zup + HEAD_MM, y, ts_ - ts, (x, zup, y)]

# ============================================================ the rewrite
def rewrite(plain, f, head, force_body_input=False, force_small_idx9=False):
    """Mirror AimFilter: optional synthesize inputs, then zone-flip + head-move.

    Returns (new_plain, mode) where mode in {'inplace','rebuild'}.
    """
    plain = bytearray(plain)

    # -- optionally synthesize a captured *input* to exercise a path --
    if force_small_idx9:
        # Re-encode idx9 to tiny (1-byte) values so the head-move must grow it,
        # forcing the canonical-rebuild + Length-repair path.
        s9 = f[PC_IDX9_X][0]; e9 = f[PC_IDX9_Z][0] + f[PC_IDX9_Z][1]
        plain = bytearray(plain[:s9] + b"\x02\x02\x02" + plain[e9:])
        f = walk(bytes(plain))
    if force_body_input:
        # Make it look like a real Body hit before the filter sees it.
        s3, w3, r3 = f[PC_IDX3]
        v3 = (r3 & 0x00FFFFFF) | (ZONE_BODY << 24)
        write_padded(plain, s3, w3, v3)
        plain[f[PC_IDX7][0]] = ZONE_BODY
        s15, w15, r15 = f[PC_IDX15]
        s = (zz_dec(r15) & ~0x3) | ZONE_BODY
        write_padded(plain, s15, w15, zz_enc(s))
        f = walk(bytes(plain))

    # -- zone flip (Body/Limb -> Head), width-preserving --
    s3, w3, r3 = f[PC_IDX3]
    new_v3 = (r3 & 0x00FFFFFF) | (ZONE_HEAD << 24)
    assert vwidth(new_v3) <= w3
    write_padded(plain, s3, w3, new_v3)
    plain[f[PC_IDX7][0]] = ZONE_HEAD
    s15, w15, r15 = f[PC_IDX15]
    # idx15 default mode is HEAD_0: clear the hitType low 2 bits to 0 (the value a
    # server-ACCEPTED real headshot carries), preserving the colliderBodyId high
    # bits. Mirrors AimFilter.IDX15_HEAD0.
    new_s15 = zz_dec(r15) & ~0x3
    write_padded(plain, s15, w15, zz_enc(new_s15))

    if head is None:
        return bytes(plain), 'inplace-nomove'

    nr9, nr10, nr11 = zz_enc(head[0]), zz_enc(head[1]), zz_enc(head[2])
    w9, w10, w11 = f[PC_IDX9_X][1], f[PC_IDX9_UP][1], f[PC_IDX9_Z][1]
    fits = vwidth(nr9) <= w9 and vwidth(nr10) <= w10 and vwidth(nr11) <= w11
    if fits:
        write_padded(plain, f[PC_IDX9_X][0], w9, nr9)
        write_padded(plain, f[PC_IDX9_UP][0], w10, nr10)
        write_padded(plain, f[PC_IDX9_Z][0], w11, nr11)
        return bytes(plain), 'inplace'
    # canonical splice rebuild
    reg9 = f[PC_IDX9_X][0]; end9 = f[PC_IDX9_Z][0] + f[PC_IDX9_Z][1]
    np = plain[:reg9] + write_canonical(bytearray(), nr9) + \
         write_canonical(bytearray(), nr10) + write_canonical(bytearray(), nr11) + \
         plain[end9:]
    return bytes(np), 'rebuild'

def seal_datagram(orig_pkt, new_plain, layout, key=KEY):
    """Encrypt, repair Length, reseal CRC-7 -> full datagram bytes."""
    hdr = framing.header_size(orig_pkt[0])
    reliable = (hdr == framing.HDR_RELIABLE)
    cipher = crypto.qqtea_encrypt(new_plain, key)
    pkt = bytearray(orig_pkt[:hdr]) + cipher
    # repair Length field
    offs, _ = framing.field_offsets(layout.order, reliable)
    o = offs[framing.DATALEN]
    m = layout.mask
    plen = len(cipher)
    pkt[o] = (plen & 0xFF) ^ m
    pkt[o + 1] = ((plen >> 8) & 0xFF) ^ m
    # reseal CRC-7 over bytes[2:]
    pkt[1] = crypto.crc7_of_packet(pkt)
    return bytes(pkt)

def verify(pkt, layout, want_head, key=KEY):
    """Independent re-decode via ffproto; returns dict of check results."""
    up = framing.decode(pkt, layout, key)
    r = {}
    r['reparse_106'] = (up is not None and up.cmd == 106 and up.reliable)
    r['crc_ok'] = bool(up and up.crc_ok)
    r['len_match'] = bool(up and up.len_match)
    r['tea_ok'] = bool(up and up.tea_ok)
    r['len_field'] = up.length if up else None
    r['payload_len'] = (len(pkt) - up.hdr_len) if up else None
    if up and up.plain:
        f = walk(up.plain)
        if f:
            z3hi = (f[PC_IDX3][2] >> 24) & 0xFF
            z7 = f[PC_IDX7][2]
            z15lo = zz_dec(f[PC_IDX15][2]) & 0x3
            # HEAD_0 default: a head claim clears idx15 low bits to 0.
            r['zone_head'] = (z3hi == ZONE_HEAD and z7 == ZONE_HEAD and z15lo == 0)
            hp = (zz_dec(f[PC_IDX9_X][2]), zz_dec(f[PC_IDX9_UP][2]), zz_dec(f[PC_IDX9_Z][2]))
            r['idx9'] = hp
            r['idx9_ok'] = (list(hp) == list(want_head[:3])) if want_head else None
        else:
            r['zone_head'] = False; r['idx9_ok'] = False; r['idx9'] = None
    return r

# ============================================================ checkParams patch
def rebuild_body(plain, f, cp, idx9_head, cp_repl):
    """Canonically re-encode idx9 (optional) and the checkParams entries named in
    cp_repl (entry index -> new float bits). Mirrors AimFilter.rebuildBody. The
    caller has already applied the width-preserving zone flip to `plain`."""
    reg9 = f[PC_IDX9_X][0]; end9 = f[PC_IDX9_Z][0] + f[PC_IDX9_Z][1]
    out = bytearray(plain[:reg9])
    if idx9_head is not None:
        out += write_canonical(None, zz_enc(idx9_head[0]))
        out += write_canonical(None, zz_enc(idx9_head[1]))
        out += write_canonical(None, zz_enc(idx9_head[2]))
    else:
        out += plain[reg9:end9]
    out += plain[end9:cp['start']]                 # idx10 etc.
    first = cp['ents'][0][0]
    out += plain[cp['start']:first]                # count varint verbatim
    for e, (s, w, bits) in enumerate(cp['ents']):
        if e in cp_repl:
            out += write_canonical(None, cp_repl[e] & 0xFFFFFFFF)
        else:
            out += plain[s:s + w]
    out += plain[cp['end']:]                        # idx15 (flipped), token, trailer
    return bytes(out)


# The definitive canonical zone-triple patch uses phone_aim6 -- the SAME capture
# the doc's ground truth was derived from (docs/CHECKPARAMS_ZONE_FIELD.md §0).
AIM6_CAP = os.path.join(ROOT, "captures", "phone_aim6", "capture_raw_20260912_161312.txt")
AIM6_KEY = bytes.fromhex("27fd2864df6984c5f8436094c0e70def")


def perm_repro():
    """(d) Reproduce the idx0-keyed permutation and check it against the doc's
    PROVEN examples (docs/CHECKPARAMS_ZONE_FIELD.md §3): the wire slots holding
    canon[31,32,33] are vic3 (idx0=0x2000003)->[61,72,15], vic25 (idx0=0x7000019)
    ->[53,39,60]. Mirrors AimFilter.fisherYatesIdx (seed = RAW idx0, full 32 bits)."""
    print("\n=== (d) permutation reproduction vs doc's PROVEN example (§3) ===")
    proven = [(0x2000003, [61, 72, 15]), (0x7000019, [53, 39, 60])]
    ok = True
    for idx0, exp in proven:
        perm = fisher_yates_idx(79, idx0)
        got = [perm[31], perm[32], perm[33]]
        good = (got == exp)
        ok = ok and good
        print(f"  idx0=0x{idx0:07x}: canon[31,32,33] -> wire {got}  expected {exp}  "
              f"{'OK' if good else 'MISMATCH'}")
    print(f"  perm_repro OK={ok}")
    return ok


def cp_zone_patch_test():
    """Definitive #7 test: take a REAL BODY 106 from phone_aim6, overwrite the
    canonical zone triple canon[31,32,33] with the head bits at that victim's
    permuted wire slots (idx0-keyed), reseal, independently re-decode, and
    un-permute. Mirrors AimFilter CP_ZONE. Verifies (a) re-parses 106, (b) CRC +
    DATA_LEN, (c) canon[31,32,33] read back == head bits with canon[33] in the
    head range [0.179,0.181], (d) zone fields read back as Head."""
    print("\n=== checkParams canonical zone-triple patch (#7): real BODY -> Head ===")
    if not os.path.exists(AIM6_CAP):
        print("  phone_aim6 capture missing; skipped"); return None
    cf = capture.CaptureFile(AIM6_CAP)
    if cf.secret_key != AIM6_KEY:
        print(f"  key mismatch cap={cf.secret_key.hex() if cf.secret_key else None}"); return None
    rows = [(p.dir, p.payload, p.length) for p in cf.packets if p.payload]
    layout, _, _ = framing.solve_layout(rows, "OUT")
    print("  layout:", layout.describe(), "| key:", AIM6_KEY.hex())

    # find a real BODY hit with a full (>=34) checkParams list
    target = None
    for p in cf.packets:
        if p.dir != "OUT" or not p.payload:
            continue
        up = framing.parse(p.payload, layout)
        if up is None or not up.reliable or up.cmd != 106 or not up.crc_ok or not up.encrypted:
            continue
        plain, ok = crypto.qqtea_decrypt(up.body, AIM6_KEY)
        if not ok:
            continue
        f = walk(plain); cp = walk_cp(plain)
        if f is None or cp is None or cp['start'] < 0:
            continue
        if f[PC_IDX7][2] != ZONE_BODY:
            continue
        if cp['count'] < CANON_ZONE_MAX + 1:
            continue
        target = (p, plain, f, cp); break
    if target is None:
        print("  no real BODY 106 with >=34 checkParams entries; skipped"); return None

    p, plain, f, cp = target
    idx0_raw = f[PC_IDX0][2] & 0xFFFFFFFF
    vic = idx0_raw & 0xFFFFFF
    n = cp['count']
    perm = fisher_yates_idx(n, idx0_raw)
    w = {c: perm[c] for c in (31, 32, 33)}
    before = {c: bits_to_f(cp['ents'][w[c]][2]) for c in (31, 32, 33)}
    print(f"  real BODY hit: seq={p.seq} vic={vic} idx0=0x{idx0_raw:x} cpCount={n}")
    print(f"    wire slots for canon[31,32,33] = [{w[31]},{w[32]},{w[33]}]")
    print(f"    BEFORE (body): canon31={before[31]:.4f} canon32={before[32]:.4f} "
          f"canon33={before[33]:.4f}")

    # apply: zone flip (idx3-hi / idx7 / idx15 low2->0) + canon zone triple -> head
    # bits. idx9 is left at the true body point -- exactly the doc §6 experiment
    # (the shipped AimFilter additionally moves idx9; that path is proven above).
    pl = bytearray(plain)
    s3, w3, r3 = f[PC_IDX3]; write_padded(pl, s3, w3, (r3 & 0x00FFFFFF) | (ZONE_HEAD << 24))
    pl[f[PC_IDX7][0]] = ZONE_HEAD
    s15, w15, r15 = f[PC_IDX15]; write_padded(pl, s15, w15, zz_enc(zz_dec(r15) & ~0x3))
    cp_repl = {w[c]: CANON_HEAD[c] for c in (31, 32, 33)}
    out_plain = rebuild_body(bytes(pl), f, cp, None, cp_repl)
    out_pkt = seal_datagram(p.payload, out_plain, layout, key=AIM6_KEY)

    # independent re-decode + un-permute the patched checkParams
    r = verify(out_pkt, layout, None, key=AIM6_KEY)
    oup = framing.decode(out_pkt, layout, AIM6_KEY)
    ocp = walk_cp(oup.plain) if oup and oup.plain else None
    after = {}
    cp_ok = ocp is not None and ocp['count'] == n
    if cp_ok:
        for c in (31, 32, 33):
            raw = ocp['ents'][w[c]][2] & 0xFFFFFFFF
            after[c] = bits_to_f(raw)
            cp_ok = cp_ok and (raw == CANON_HEAD[c])
    head33_ok = cp_ok and (HEAD33_LO <= after[33] <= HEAD33_HI)
    allok = (r['reparse_106'] and r['crc_ok'] and r['len_match'] and r['tea_ok']
             and r['zone_head'] and cp_ok and head33_ok)
    print(f"    AFTER  (head): canon31={after.get(31)} canon32={after.get(32)} "
          f"canon33={after.get(33)}")
    print(f"    (a) re-parses 106 : {r['reparse_106']}")
    print(f"    (b) CRC valid     : {r['crc_ok']}   DATA_LEN {r['len_field']}=="
          f"{r['payload_len']} -> {r['len_match']}   tea_ok={r['tea_ok']}")
    print(f"    (c) canon triple == head bits: {cp_ok}   "
          f"canon[33] in head range [{HEAD33_LO},{HEAD33_HI}]: {head33_ok}")
    print(f"    (d) zone fields == Head: {r['zone_head']}")
    print(f"    outLen {len(out_pkt)} (in {len(p.payload)})   ALL OK: {allok}")
    return allok

# ============================================================ main
def main():
    cf = capture.CaptureFile(CAP)
    assert cf.secret_key == KEY, "capture key mismatch"
    rows = [(p.dir, p.payload, p.length) for p in cf.packets if p.payload]
    layout, hits, _ = framing.solve_layout(rows, "OUT")
    print("layout:", layout.describe(), "| key:", KEY.hex())
    own_id, tracks = build_esp(cf, layout)
    print("own entity id:", own_id, "| tracked entities:", sorted(tracks))

    # collect the real 106s
    real = []
    for p in cf.packets:
        if p.dir != "OUT" or not p.payload: continue
        up = framing.parse(p.payload, layout)
        if up is None or not up.reliable or up.cmd != 106 or not up.crc_ok or not up.encrypted:
            continue
        plain, ok = crypto.qqtea_decrypt(up.body, KEY)
        if not ok: continue
        f = walk(plain)
        if f is None: continue
        real.append((p, plain, f))
    print("decodable real OUT 106:", len(real))

    # ---------- STEP-3 FRAME / UNITS CHECK ----------
    print("\n=== frame/units check: real idx9 hit point vs victim ESP position ===")
    up_res = []
    frame_ok = True
    for p, plain, f in real:
        vid = f[PC_IDX0][2] & 0xFFFFFF
        att = f[4][2] & 0xFFFFFF
        hx = zz_dec(f[PC_IDX9_X][2]); hu = zz_dec(f[PC_IDX9_UP][2]); hz = zz_dec(f[PC_IDX9_Z][2])
        hp = head_point(tracks, vid, p.ts_ms)
        if hp is None: continue
        feet = hp[4]
        d_up = hu - feet[1]           # up-axis residual vs streamed feet
        # is the victim the nearest ESP entity to the hit point?
        st = {}
        for eid, lst in tracks.items():
            st[eid] = min(lst, key=lambda r: abs(r[0] - p.ts_ms))
        nearest = min(st, key=lambda e: (hx - st[e][1]) ** 2 + (hz - st[e][3]) ** 2)
        up_res.append(d_up)
        if nearest != vid:
            print(f"  seq {p.seq}: nearest entity {nearest} != victim {vid} (still ok if close)")
        print(f"  seq {p.seq} vic={vid} att={att} upResidual(head)={d_up:+d}mm "
              f"({d_up/1000:.2f}m) nearestEnt={nearest}")
    lo, hi = min(up_res), max(up_res)
    print(f"up-axis residual range: {lo}..{hi} mm  ({lo/1000:.2f}..{hi/1000:.2f} m)")
    # A head-height stature (~0.9-1.9 m above feet) confirms up axis + mm units.
    frame_ok = all(700 <= r <= 2000 for r in up_res)
    print(f"FRAME/UNITS VERIFIED (up residual is a head stature, mm frame): {frame_ok}")

    # ---------- REWRITE CORRECTNESS on real packets ----------
    def run(title, plain, f, orig_pkt, head, **kw):
        new_plain, mode = rewrite(plain, f, head, **kw)
        pkt = seal_datagram(orig_pkt, new_plain, layout)
        r = verify(pkt, layout, head)
        allok = (r['reparse_106'] and r['crc_ok'] and r['len_match'] and r['tea_ok']
                 and r.get('zone_head') and (head is None or r.get('idx9_ok')))
        print(f"\n[{title}] mode={mode} origLen={len(orig_pkt)} newLen={len(pkt)}")
        print(f"   (a) re-parses 106 : {r['reparse_106']}")
        print(f"   (b) CRC valid     : {r['crc_ok']}   tea_ok={r['tea_ok']}")
        print(f"   (c) idx9 head      : {r.get('idx9')} intended={head[:3] if head else None} ok={r.get('idx9_ok')}")
        print(f"   (d) zone == Head   : {r.get('zone_head')}")
        print(f"   (e) Length field   : {r['len_field']} == payload {r['payload_len']} -> {r['len_match']}")
        print(f"   ALL OK: {allok}")
        return allok

    print("\n=== rewrite correctness (independent ffproto re-decode) ===")
    passed = total = 0
    # Test A: full shipped path -- synthesize a Body input, flip to Head + move hit point.
    for p, plain, f in real:
        vid = f[PC_IDX0][2] & 0xFFFFFF
        hp = head_point(tracks, vid, p.ts_ms)
        if hp is None: continue
        total += 1
        if run(f"Body->Head + move  seq {p.seq} vic {vid}", plain, f, p.payload,
               hp, force_body_input=True):
            passed += 1
        if total >= 4: break
    # Test B: pure hit-point move machinery on a real Head packet (in-place path).
    p, plain, f = real[0]
    vid = f[PC_IDX0][2] & 0xFFFFFF
    hp = head_point(tracks, vid, p.ts_ms)
    total += 1
    if run(f"move-only (in-place)  seq {p.seq} vic {vid}", plain, f, p.payload, hp):
        passed += 1
    # Test C: genuine length change. Build a *small-hit-point* input datagram
    # (idx9 = 1-byte coords), then rewrite it, growing idx9 to the full head
    # point -> the plaintext, ciphertext and header Length all change, proving
    # the canonical-rebuild + Length-repair path across a real size change.
    s9 = f[PC_IDX9_X][0]; e9 = f[PC_IDX9_Z][0] + f[PC_IDX9_Z][1]
    small_plain = bytes(plain[:s9]) + b"\x02\x02\x02" + bytes(plain[e9:])
    small_pkt = seal_datagram(p.payload, small_plain, layout)   # a valid, smaller 106
    small_up = framing.decode(small_pkt, layout, KEY)
    small_f = walk(small_up.plain)
    # Target coords near the 32-bit int limit (5-byte varints each) so idx9 goes
    # from 3 bytes to 15 -- a +12-byte plaintext delta that must cross a TEA
    # 8-byte block boundary, forcing a genuine ciphertext-length change and Length
    # repair. (Values are within the accessor's 32-bit range; realistic head
    # points stay 3 bytes and take the in-place path above.)
    big = [2000000000, 2000000000, 2000000000]
    total += 1
    new_plain, mode = rewrite(small_up.plain, small_f, big)     # grows idx9 -> rebuild
    out_pkt = seal_datagram(small_pkt, new_plain, layout)
    r = verify(out_pkt, layout, big)
    hp = big  # for the printout below
    grew = len(out_pkt) > len(small_pkt)
    allok = (mode == 'rebuild' and grew and r['reparse_106'] and r['crc_ok']
             and r['len_match'] and r['tea_ok'] and r['zone_head'] and r['idx9_ok'])
    print(f"\n[move + REBUILD genuine-grow  seq {p.seq} vic {vid}] mode={mode}")
    print(f"   input(smallHP) len={len(small_pkt)} -> output len={len(out_pkt)}  grew={grew}")
    print(f"   (a) re-parses 106 : {r['reparse_106']}")
    print(f"   (b) CRC valid     : {r['crc_ok']}   tea_ok={r['tea_ok']}")
    print(f"   (c) idx9 head      : {r.get('idx9')} intended={hp[:3]} ok={r.get('idx9_ok')}")
    print(f"   (d) zone == Head   : {r.get('zone_head')}")
    print(f"   (e) Length field   : {r['len_field']} == payload {r['payload_len']} -> {r['len_match']}")
    print(f"   ALL OK: {allok}")
    if allok: passed += 1

    print(f"\n(HEAD HEIGHT knob under test = {HEAD_HEIGHT_M:.2f} m -> {HEAD_MM} mm idx9 up-offset)")

    # ---------- canonical zone-triple patch (#7) + permutation reproduction ----
    perm_ok = perm_repro()             # (d) doc's PROVEN vic3/vic25 wire mapping
    zone_ok = cp_zone_patch_test()     # (a-d) real BODY -> head triple, phone_aim6

    zone_line = ("skipped(no data)" if zone_ok is None else ("pass" if zone_ok else "FAIL"))
    print(f"\n==== SUMMARY: frame_ok={frame_ok}  rewrite {passed}/{total} tests passed"
          f"  perm_repro={'pass' if perm_ok else 'FAIL'}  cp_zone_patch={zone_line} ====")
    core_ok = frame_ok and passed == total and perm_ok
    zone_bad = (zone_ok is False)   # a present-but-failing zone test is a hard failure
    return 0 if (core_ok and not zone_bad) else 1

if __name__ == "__main__":
    sys.exit(main())
