import ffpcap as P

def parse_pri(b, has_owner=True):
    """RUDP_VAR_SYNC_PRI_DATA (1900) / GRI (1901).
    returns (groups, ok) ; groups = [(ownerId, [(varId, rawvalue, nbytes)])]"""
    i = 0; groups = []
    while i < len(b):
        owner = None
        if has_owner:
            owner, i = P.rdvar(b, i)
            if owner is None: return groups, False
        if i + 2 > len(b): return groups, False
        blen = b[i] | (b[i+1] << 8); i += 2
        end = i + blen
        if end > len(b): return groups, False
        recs = []
        while i < end:
            vid = b[i]; i += 1
            st = i
            val, i = P.rdvar(b, i)
            if val is None or i > end: return groups, False
            recs.append((vid, val, i-st))
        if i != end: return groups, False
        groups.append((owner, recs))
    return groups, True
