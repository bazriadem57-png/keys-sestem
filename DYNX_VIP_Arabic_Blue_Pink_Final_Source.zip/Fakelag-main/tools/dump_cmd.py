"""Dump the Free Fire UDP Cmd catalogue from IL2CPP metadata."""
import io
from il2cpp_meta import Meta
m = Meta()
byname = {m.full_name(t): t for t in m.types}
CMD = "message.KLINFKFBIKB"
cmd = m.enum_members(byname[CMD])
res = m.enum_members(byname["GCommon.UDPMessageIDReserved"])
pri = m.enum_members(byname["message.NIPHKJAOKGI"])

out = io.StringIO()
out.write("// GCommon.UDPMessageIDReserved : uint  (transport, Cmd 1..99)\n")
for k, v in res: out.write(f"    {k} = {v}\n")
out.write("\n// GCommon.UDPMsgPacket constants\n")
for n, tn, v in m.const_fields(byname["GCommon.UDPMsgPacket"]):
    out.write(f"    const {tn} {n} = {v}\n")
out.write(f"\n// {CMD} : uint  -- the application Cmd enum ({len(cmd)} members)\n")
for k, v in cmd: out.write(f"    {k} = {v}\n")
out.write(f"\n// message.NIPHKJAOKGI : uint -- PRI property ids ({len(pri)} members)\n")
for k, v in pri: out.write(f"    {k} = {v}\n")
open("ff_cmd_catalogue.txt", "w").write(out.getvalue())

d = {}
for k, v in cmd: d.setdefault(v, []).append(k)
rd = {v: k for k, v in res}
OBS = [2,3,104,105,106,107,108,111,112,113,115,117,118,121,124,131,132,133,134,135,136,154,168,170,204,221,222,224,229,230,231,322,
       751,752,753,855,872,984,1094,1109,1565,1715,1900,1901,3053,2000,2001,2002,2003,2010,2012,2068]
print("| Cmd | member name | source enum |")
print("|----:|-------------|-------------|")
for v in OBS:
    if v in rd:   print(f"| {v} | {rd[v]} | GCommon.UDPMessageIDReserved |")
    elif v in d:  print(f"| {v} | {', '.join(d[v])} | {CMD} |")
    else:         print(f"| {v} | NOT FOUND | - |")
vs = sorted(d)
print(f"\ncmd enum: {len(cmd)} members, values {vs[0]}..{vs[-1]}")
print("UDP_-prefixed (unreliable) members:", sum(1 for k,_ in cmd if k.startswith("UDP_")))
print("RUDP_-prefixed (reliable) members:", sum(1 for k,_ in cmd if k.startswith("RUDP_")))
print("min value of a UDP_-prefixed member:", min(v for k,v in cmd if k.startswith("UDP_")))
print("max value of a RUDP_-prefixed member:", max(v for k,v in cmd if k.startswith("RUDP_")))
