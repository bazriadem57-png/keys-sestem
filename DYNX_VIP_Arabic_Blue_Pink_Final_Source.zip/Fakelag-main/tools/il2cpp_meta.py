"""
IL2CPP global-metadata.dat parser (metadata version 31, 256-byte header).
Purpose: enumerate every enum type and its members (name = value).

Header is a flat array of int32 (offset,size) pairs after sanity+version.
Verified layout for v31 by: typeDefinitionsSize/88 == 45736 == type count
reported by the external dumper, and all table offsets being contiguous.
"""
import struct, sys, io, os

META = r"C:\Users\Tonyt\Documents\FF-RE\bin\global-metadata.dat"

HDR_FIELDS = [
    "stringLiteral", "stringLiteralData", "string", "events", "properties",
    "methods", "parameterDefaultValues", "fieldDefaultValues",
    "fieldAndParameterDefaultValueData", "fieldMarshaledSizes", "parameters",
    "fields", "genericParameters", "genericParameterConstraints",
    "genericContainers", "nestedTypes", "interfaces", "vtableMethods",
    "interfaceOffsets", "typeDefinitions", "images", "assemblies",
    "fieldRefs", "referencedAssemblies", "attributeData", "attributeDataRange",
    "unresolvedVirtualCallParameterTypes", "unresolvedVirtualCallParameterRanges",
    "windowsRuntimeTypeNames", "windowsRuntimeStrings", "exportedTypeDefinitions",
]


# Underlying-type groups, identified from mscorlib marker enums
# (System.UInt32Enum, System.ByteEnum, System.Int64Enum, ... all present in this image).
# key = the Il2CppType index of the enum's "value__" field.
UNDERLYING = {
    43488: ("System.Int32",  True,  4),
    75358: ("System.UInt32", False, 4),
    28405: ("System.Byte",   False, 1),
    75335: ("System.UInt16", False, 2),
    43516: ("System.Int64",  False, 8),
    75381: ("System.UInt64", False, 8),
    53726: ("System.SByte",  False, 1),
    43457: ("System.Int16",  False, 2),
}

# Il2CppType indices for primitive FIELD types (same primitive appears under
# several indices because Il2CppType.attrs differs per field-attribute combo).
# Anchored on mscorlib marker enums + Wwise AK_INVALID_* consts (=0xFFFFFFFF).
PRIM_FIELD_TYPE = {
    43488: ("int", True), 43470: ("int", True),
    75358: ("uint", False), 75343: ("uint", False),
    75362: ("uint", False), 75371: ("uint", False),
    28405: ("byte", False), 28395: ("byte", False), 28409: ("byte", False),
    75335: ("ushort", False), 75329: ("ushort", False), 75325: ("ushort", False),
    43516: ("long", True), 75381: ("ulong", False),
    53726: ("sbyte", False), 43457: ("short", False),
    28098: ("bool", False), 34544: ("float", True),
}


def read_compressed_uint(b, base):
    """il2cpp::utils::ReadCompressedUInt32"""
    b0 = b[base]
    if (b0 & 0x80) == 0:
        return b0, 1
    if (b0 & 0xC0) == 0x80:
        return ((b0 & 0x7F) << 8) | b[base+1], 2
    if (b0 & 0xE0) == 0xC0:
        return (((b0 & 0x1F) << 24) | (b[base+1] << 16) |
                (b[base+2] << 8) | b[base+3]), 4
    if b0 == 0xF0:
        return int.from_bytes(b[base+1:base+5], "little"), 5
    if b0 == 0xFE:
        return 0xFFFFFFFE, 1
    return 0xFFFFFFFF, 1

class Meta:
    def __init__(self, path=META):
        self.d = open(path, "rb").read()
        sanity, self.version = struct.unpack_from("<Ii", self.d, 0)
        assert sanity == 0xFAB11BAF, hex(sanity)
        self.h = {}
        for i, n in enumerate(HDR_FIELDS):
            off, size = struct.unpack_from("<ii", self.d, 8 + i * 8)
            self.h[n] = (off, size)
        self._strcache = {}
        self._load()

    # ---- metadata identifier strings (NUL separated C strings) ----
    def s(self, idx):
        if idx < 0:
            return ""
        v = self._strcache.get(idx)
        if v is None:
            base = self.h["string"][0] + idx
            end = self.d.index(b"\x00", base)
            v = self.d[base:end].decode("utf-8", "replace")
            self._strcache[idx] = v
        return v

    def _load(self):
        d = self.d
        # ---- fields: {nameIndex, typeIndex, token} = 12 bytes ----
        foff, fsize = self.h["fields"]
        self.nfields = fsize // 12
        self.fields = [None] * self.nfields
        for i in range(self.nfields):
            self.fields[i] = struct.unpack_from("<iiI", d, foff + i * 12)

        # ---- fieldDefaultValues: {fieldIndex, typeIndex, dataIndex} = 12 ----
        off, size = self.h["fieldDefaultValues"]
        self.fdv = {}          # fieldIndex -> (typeIndex, dataIndex)
        dataidx = set()
        for i in range(size // 12):
            fi, ti, di = struct.unpack_from("<iii", d, off + i * 12)
            self.fdv[fi] = (ti, di)
            if di >= 0:
                dataidx.add(di)
        # blob entries are written sequentially: next boundary bounds the width
        self.blob_off, self.blob_size = self.h["fieldAndParameterDefaultValueData"]
        # also fold in parameter default values so boundaries are correct
        poff, psize = self.h["parameterDefaultValues"]
        for i in range(psize // 12):
            pi, ti, di = struct.unpack_from("<iii", d, poff + i * 12)
            if di >= 0:
                dataidx.add(di)
        self.bounds = sorted(dataidx)

        # ---- typeDefinitions: 88 bytes in v31 ----
        toff, tsize = self.h["typeDefinitions"]
        assert tsize % 88 == 0, tsize
        self.ntypes = tsize // 88
        self.types = []
        for i in range(self.ntypes):
            b = toff + i * 88
            (nameIdx, nsIdx, byval, declaring, parent, elem, gencont, flags,
             fieldStart, methodStart, eventStart, propStart, nestedStart,
             ifaceStart, vtStart, ifaceOffStart) = struct.unpack_from("<16i", d, b)
            (mcount, pcount, fcount, ecount, ncount, vcount, icount,
             iocount) = struct.unpack_from("<8H", d, b + 64)
            bitfield, token = struct.unpack_from("<II", d, b + 80)
            self.types.append(dict(
                idx=i, name=self.s(nameIdx), ns=self.s(nsIdx),
                declaring=declaring, parent=parent, elem=elem, flags=flags,
                fieldStart=fieldStart, fieldCount=fcount, bitfield=bitfield,
                token=token, methodStart=methodStart, methodCount=mcount))

    def blob_width(self, di):
        import bisect
        j = bisect.bisect_right(self.bounds, di)
        nxt = self.bounds[j] if j < len(self.bounds) else self.blob_size
        return nxt - di

    def blob_int(self, di, signed=True):
        """Default-value blob stores il2cpp compressed ints.
        Signed underlying types are zigzag-encoded (ReadCompressedInt32);
        unsigned types are plain ReadCompressedUInt32."""
        u, w = read_compressed_uint(self.d, self.blob_off + di)
        if not signed:
            return u, w
        if u == 0xFFFFFFFF:
            return -2147483648, w
        return ((u >> 1) ^ -(u & 1)), w

    def is_enum(self, t):
        return bool((t["bitfield"] >> 1) & 1)

    def full_name(self, t):
        n = t["name"]
        if t["declaring"] >= 0 and t["declaring"] < self.ntypes:
            n = self.full_name(self.types[t["declaring"]]) + "/" + n
            return n
        return (t["ns"] + "." + n) if t["ns"] else n

    def underlying(self, t):
        """(name, signed, width) of the enum's underlying integer type"""
        for k in range(t["fieldCount"]):
            fi = t["fieldStart"] + k
            if self.s(self.fields[fi][0]) == "value__":
                return UNDERLYING.get(self.fields[fi][1],
                                      ("?%d" % self.fields[fi][1], True, 4))
        return ("System.Int32", True, 4)

    def const_fields(self, t):
        """(name, type, value) for every field of a NON-enum type that has a
        default value (i.e. C# `const`)."""
        out = []
        for k in range(t["fieldCount"]):
            fi = t["fieldStart"] + k
            dv = self.fdv.get(fi)
            if dv is None:
                continue
            ti = self.fields[fi][1]
            tn, signed = PRIM_FIELD_TYPE.get(ti, ("typeIdx%d" % ti, False))
            v, w = self.blob_int(dv[1], signed)
            out.append((self.s(self.fields[fi][0]), tn, v))
        return out

    def enum_members(self, t):
        """returns list of (name, value) for a type's static literal fields"""
        signed = self.underlying(t)[1]
        out = []
        for k in range(t["fieldCount"]):
            fi = t["fieldStart"] + k
            if fi < 0 or fi >= self.nfields:
                continue
            nameIdx, typeIdx, token = self.fields[fi]
            name = self.s(nameIdx)
            if name == "value__":
                continue
            dv = self.fdv.get(fi)
            if dv is None:
                out.append((name, None))
                continue
            val, w = self.blob_int(dv[1], signed)
            out.append((name, val))
        return out

if __name__ == "__main__":
    m = Meta()
    print("version", m.version, "types", m.ntypes, "fields", m.nfields,
          "fdv", len(m.fdv), "blob", m.blob_size, file=sys.stderr)
    enums = [t for t in m.types if m.is_enum(t)]
    print("enums", len(enums), file=sys.stderr)
    for t in enums[:5]:
        print(m.full_name(t), m.enum_members(t)[:6], file=sys.stderr)
