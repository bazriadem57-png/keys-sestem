#!/usr/bin/env python3
"""
Free Fire Max UDP match-protocol decoder.

Implements the framing recovered from libil2cpp.so (GCommon.UDPMsgPacket,
UDPParameters, UDPChecksum, NetworkCryptologyUtil) and validated against real
captures. See docs/PROTOCOL_CIPHER.md.

Two things vary per session and are BOTH solvable from a capture alone:
  * m            = SECRET_KEY[0], the single-byte XOR mask over the header
  * HEAD_SECRET  = int[5] permutation of the header field order

The TEA body key (SECRET_KEY, 16 bytes) is NOT on the wire. Plaintext packets
(Flags & 1 == 0) decode fully without it.

usage:
  python ffdecode.py solve   <capture.txt>
  python ffdecode.py decode  <capture.txt> [--key HEX32] [--limit N]
"""
import sys, io, struct, collections, itertools

# ---------------------------------------------------------------- constants
SENDOPTION, CMD, ORDERID, FLAGS, DATALEN = 0, 1, 2, 3, 4
FIELD_W   = {SENDOPTION: 1, CMD: 2, ORDERID: 2, FLAGS: 1, DATALEN: 2}
FIELD_NAME = {SENDOPTION: "SendOption", CMD: "Cmd", ORDERID: "OrderID",
              FLAGS: "Flags", DATALEN: "Length"}
DEFAULT_ORDER = (SENDOPTION, CMD, ORDERID, FLAGS, DATALEN)

MSG_KEY_MIN, MSG_KEY_MID, MSG_KEY_MAX = 90, 100, 110
HDR_RELIABLE, HDR_NONRELIABLE = 10, 8
FLAG_ENCRYPTION, FLAG_ZIP = 1, 2

DELTA, ROUNDS, SALT_LEN, ZERO_LEN = 0x9E3779B9, 16, 2, 7
MASK32 = 0xFFFFFFFF

# CRC-7/MMC (poly 0x09), 7-bit -- Linux crc7_syndrome_table >> 1
def _mk_crc7():
    t = []
    for i in range(256):
        c = i
        for _ in range(8):
            c = ((c << 1) ^ 0x12) if (c & 0x80) else (c << 1)
            c &= 0xFF
        t.append(c >> 1)
    return t
CRC7TAB = _mk_crc7()

def crc7(buf, crc=0):
    for b in buf:
        crc = CRC7TAB[(b ^ ((crc << 1) & 0xFF)) & 0xFF]
    return crc

# ---------------------------------------------------------------- TEA / QQ-TEA
def _kwords(key):
    return struct.unpack('<4I', key[:16])

def tea_decrypt_block(blk, k):
    v0, v1 = struct.unpack('<2I', blk)
    k0, k1, k2, k3 = k
    s = (DELTA * ROUNDS) & MASK32
    for _ in range(ROUNDS):
        v1 = (v1 - ((((v0 << 4) & MASK32) + k2) ^ ((v0 + s) & MASK32) ^ ((v0 >> 5) + k3))) & MASK32
        v0 = (v0 - ((((v1 << 4) & MASK32) + k0) ^ ((v1 + s) & MASK32) ^ ((v1 >> 5) + k1))) & MASK32
        s = (s - DELTA) & MASK32
    return struct.pack('<2I', v0, v1)

def tea_encrypt_block(blk, k):
    v0, v1 = struct.unpack('<2I', blk)
    k0, k1, k2, k3 = k
    s = 0
    for _ in range(ROUNDS):
        s = (s + DELTA) & MASK32
        v0 = (v0 + ((((v1 << 4) & MASK32) + k0) ^ ((v1 + s) & MASK32) ^ ((v1 >> 5) + k1))) & MASK32
        v1 = (v1 + ((((v0 << 4) & MASK32) + k2) ^ ((v0 + s) & MASK32) ^ ((v0 >> 5) + k3))) & MASK32
    return struct.pack('<2I', v0, v1)

def _x8(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

def tea_encrypt_len(plain_len):
    """align8(plainLen + SALT_LEN + ZERO_LEN + 1)"""
    n = plain_len + SALT_LEN + ZERO_LEN + 1
    r = n % 8
    return n + (0 if r == 0 else 8 - r)

def qqtea_decrypt(data, key):
    """Returns (plaintext, zero_tail_ok). CBC-chained TEA, Tencent oi_symmetry."""
    n = len(data)
    if n < 16 or n % 8:
        return None, False
    k = _kwords(key)
    prev_plain = tea_decrypt_block(data[0:8], k)
    stream = bytearray(prev_plain)
    prev_cipher = data[0:8]
    for i in range(8, n, 8):
        cb = data[i:i + 8]
        d = tea_decrypt_block(_x8(cb, prev_plain), k)
        stream += _x8(d, prev_cipher)
        prev_plain, prev_cipher = d, cb
    body = bytes(stream)
    pad = body[0] & 7
    out_len = n - pad - 1 - SALT_LEN - ZERO_LEN
    if out_len < 0:
        return None, False
    start = 1 + pad + SALT_LEN
    plain = body[start:start + out_len]
    tail = body[start + out_len:start + out_len + ZERO_LEN]
    return plain, (len(tail) == ZERO_LEN and all(t == 0 for t in tail))

# ---------------------------------------------------------------- framing
def header_size(msgkey):
    if MSG_KEY_MIN <= msgkey < MSG_KEY_MID:
        return HDR_RELIABLE
    if MSG_KEY_MID <= msgkey <= MSG_KEY_MAX:
        return HDR_NONRELIABLE
    return None

def field_offsets(order, reliable):
    """byte offset of each field given a HEAD_SECRET order."""
    off, out = 2, {}
    for f in order:
        if f == ORDERID and not reliable:
            continue
        out[f] = off
        off += FIELD_W[f]
    return out, off

def parse(pkt, m, order=DEFAULT_ORDER):
    ln = len(pkt)
    if ln < 10:
        return None
    mk = pkt[0]
    hdr = header_size(mk)
    if hdr is None or ln < hdr:
        return None
    reliable = (hdr == HDR_RELIABLE)
    offs, end = field_offsets(order, reliable)
    if end != hdr:
        return None
    def rd(f):
        o, w = offs[f], FIELD_W[f]
        if w == 1:
            return pkt[o] ^ m
        return (pkt[o] ^ m) | ((pkt[o + 1] ^ m) << 8)
    r = {
        "MsgKey": mk, "CRC7": pkt[1], "reliable": reliable, "hdr": hdr,
        "SendOption": rd(SENDOPTION), "Cmd": rd(CMD),
        "Flags": rd(FLAGS), "Length": rd(DATALEN),
        "OrderID": rd(ORDERID) if reliable else None,
        "payload": pkt[hdr:],
        "crc_ok": (crc7(pkt[2:]) == pkt[1]),
    }
    return r

def decode(pkt, m, order=DEFAULT_ORDER, key=None):
    r = parse(pkt, m, order)
    if r is None:
        return None
    pl = r["payload"]
    r["encrypted"] = bool(r["Flags"] & FLAG_ENCRYPTION)
    r["zipped"] = bool(r["Flags"] & FLAG_ZIP)
    r["plain"] = None
    if r["zipped"]:
        r["plain"] = None            # gzip-with-XOR'd-header; needs SECRET_KEY
    elif r["encrypted"]:
        if key:
            p, ok = qqtea_decrypt(pl, key)
            r["plain"], r["tea_ok"] = p, ok
    else:
        r["plain"] = pl
    return r

# ---------------------------------------------------------------- capture I/O
def read_capture(path):
    """Yields (ts, dir, port, payload_bytes). Handles the SunnyMod raw format."""
    for line in io.open(path, encoding='utf-8', errors='replace'):
        if line.startswith('#') or not line.strip():
            continue
        f = line.split()
        if len(f) < 13:
            continue
        ts, d, sp, dp, ln, hx = f[1], f[3], f[6], f[7], f[8], f[12]
        if hx.endswith('..'):
            continue                  # truncated record
        try:
            b = bytes.fromhex(hx)
            ln = int(ln)
        except ValueError:
            continue
        if len(b) != ln:
            continue
        yield int(ts), d, (dp if d == 'OUT' else sp), b

def match_packets(path):
    rows = list(read_capture(path))
    score = collections.Counter(p for _, _, p, b in rows
                                if b and MSG_KEY_MIN <= b[0] <= MSG_KEY_MAX)
    if not score:
        return None, []
    port = score.most_common(1)[0][0]
    out = [(ts, d, b) for ts, d, p, b in rows
           if p == port and b and header_size(b[0]) is not None]
    return port, out

# ---------------------------------------------------------------- solver
def solve(pkts, direction='OUT'):
    """Recover (m, order). Uses the DATALEN identity: Length == len - hdr.

    Only the OUT direction is reliable for this: inbound Length is the
    PRE-COMPRESSION size when FLAG_ZIP is set, so it will not match the wire
    length. Returns (m, order, hits, tested)."""
    cand = [p for p in pkts if p[1] == direction]
    if not cand:
        cand = pkts
    votes = collections.Counter()
    tested = 0
    for _, _, b in cand[:6000]:
        hdr = header_size(b[0])
        if hdr is None or len(b) < hdr:
            continue
        reliable = (hdr == HDR_RELIABLE)
        pay = len(b) - hdr
        tested += 1
        for order in itertools.permutations(DEFAULT_ORDER):
            offs, end = field_offsets(order, reliable)
            if end != hdr:
                continue
            o = offs[DATALEN]
            m = b[o] ^ (pay & 0xFF)
            if (b[o + 1] ^ m) == ((pay >> 8) & 0xFF):
                votes[(m, order)] += 1
    if not votes:
        return None, None, 0, tested
    # The DATALEN identity alone is UNDER-DETERMINED: on one real capture TWELVE
    # permutations fit it at 100%, and only six decoded to sane commands. The
    # blind spot is OrderID -- it contributes no bytes on non-reliable packets,
    # which is most traffic, so its position is unobservable there. Picking the
    # top-voted candidate therefore had a coin-flip chance of reading Cmd (and
    # Flags) from the wrong offset.
    #
    # Score every mask/order that ties on the identity by whether the fields it
    # implies are actually plausible, and keep the best.
    best_m, best_order, best_hits, best_score = None, None, 0, -1.0
    top = votes.most_common(24)
    if top:
        ceiling = top[0][1]
        for (mm, oo), hh in top:
            if hh < ceiling:
                break
            oo2 = _fix_1byte_ambiguity(cand, mm, oo)
            sc = _plausibility(cand, mm, oo2)
            if sc > best_score:
                best_m, best_order, best_hits, best_score = mm, oo2, hh, sc
    if best_order is None:
        (m, order), hits = votes.most_common(1)[0]
        return m, _fix_1byte_ambiguity(cand, m, order), hits, tested
    return best_m, best_order, best_hits, tested


# Highest message id in the game's own enum (message.KLINFKFBIKB tops out at
# 3586); anything above that is a misread field, not a real command.
MAX_CMD = 3586
RELIABLE_SEND_OPTIONS = {1, 2, 5}


def _plausibility(pkts, m, order):
    """Fraction of packets whose decoded header fields are all legal."""
    ok = tot = 0
    for _, _, b in pkts[:1500]:
        r = parse(b, m, order)
        if r is None:
            continue
        tot += 1
        if r["Cmd"] > MAX_CMD:
            continue
        if (r["Flags"] & ~0x03) != 0:
            continue
        if (r["SendOption"] in RELIABLE_SEND_OPTIONS) != r["reliable"]:
            continue
        ok += 1
    return (ok / tot) if tot else 0.0


# SendOption and Flags are BOTH 1 byte wide, so swapping them leaves every byte
# offset unchanged and the DATALEN identity cannot distinguish the two. Break the
# tie with the reliability rule: IsReliable() is true iff
# SendOption in {HELLO=1, RELIABLE=2, VAR_RELIABLE=5}, and MsgKey already tells us
# whether the packet is reliable. Flags must also stay within {0..3}.
def _fix_1byte_ambiguity(pkts, m, order):
    RELIABLE_OPTS = {1, 2, 5}
    cands = [order]
    o = list(order)
    i, j = o.index(SENDOPTION), o.index(FLAGS)
    sw = o[:]; sw[i], sw[j] = sw[j], sw[i]
    cands.append(tuple(sw))
    best, best_score = order, -1
    for cand in cands:
        good = 0
        for _, _, b in pkts[:3000]:
            r = parse(b, m, cand)
            if not r:
                continue
            so_ok = (r["SendOption"] in RELIABLE_OPTS) == r["reliable"]
            fl_ok = (r["Flags"] & ~0x03) == 0
            if so_ok and fl_ok:
                good += 1
        if good > best_score:
            best, best_score = cand, good
    return best

def order_str(order):
    return "[" + ", ".join(FIELD_NAME[f] for f in order) + "]"

# ---------------------------------------------------------------- cli
def cmd_solve(path):
    port, pkts = match_packets(path)
    if not pkts:
        print("no match-server traffic found")
        return
    m, order, hits, tested = solve(pkts)
    print("port            : %s" % port)
    print("match packets   : %d" % len(pkts))
    if m is None:
        print("FAILED to solve mask/order")
        return
    print("mask m          : 0x%02X   (= SECRET_KEY[0])" % m)
    print("HEAD_SECRET     : %s" % order_str(order))
    print("DATALEN fit     : %d/%d = %.1f%%" % (hits, tested, 100.0 * hits / max(tested, 1)))
    ok = sum(1 for _, _, b in pkts if crc7(b[2:]) == b[1])
    print("CRC7 valid      : %d/%d = %.1f%%" % (ok, len(pkts), 100.0 * ok / len(pkts)))
    st = collections.Counter()
    for _, d, b in pkts:
        r = parse(b, m, order)
        if r:
            st[(("REL" if r["reliable"] else "NONREL"), d,
                "enc" if r["Flags"] & 1 else "plain")] += 1
    print("\nclasses:")
    for k, v in sorted(st.items()):
        print("   %-24s %d" % (str(k), v))

def cmd_decode(path, key=None, limit=20):
    port, pkts = match_packets(path)
    if not pkts:
        print("no match traffic")
        return
    m, order, hits, tested = solve(pkts)
    if m is None:
        print("could not solve mask/order")
        return
    print("port=%s  mask=0x%02X  order=%s\n" % (port, m, order_str(order)))
    shown = 0
    for ts, d, b in pkts:
        r = decode(b, m, order, key)
        if not r:
            continue
        print("%s len=%-4d MsgKey=%-3d %-6s Cmd=%-5d Flags=%d Len=%-4d %s%s crc=%s"
              % (d, len(b), r["MsgKey"], "REL" if r["reliable"] else "NONREL",
                 r["Cmd"], r["Flags"], r["Length"],
                 ("Order=%d " % r["OrderID"]) if r["reliable"] else "",
                 "ENC" if r["encrypted"] else ("ZIP" if r["zipped"] else "plain"),
                 "ok" if r["crc_ok"] else "BAD"))
        if r["plain"] is not None:
            print("      plain: %s" % r["plain"][:40].hex(' '))
        shown += 1
        if shown >= limit:
            break

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    cmd, path = sys.argv[1], sys.argv[2]
    key = None
    if "--key" in sys.argv:
        key = bytes.fromhex(sys.argv[sys.argv.index("--key") + 1])
    lim = 20
    if "--limit" in sys.argv:
        lim = int(sys.argv[sys.argv.index("--limit") + 1])
    if cmd == "solve":
        cmd_solve(path)
    elif cmd == "decode":
        cmd_decode(path, key, lim)
    else:
        print(__doc__)
