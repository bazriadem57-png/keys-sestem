import struct, bisect, io, sys
from capstone import *
from capstone.arm64 import *
import os
SO=os.environ.get('FFSO', r'C:\Users\Tonyt\Documents\FF-RE\bin\libil2cpp_dec.so')
RVA=r'C:\Users\Tonyt\Documents\FF-RE\bin\rva_map.txt'
data=open(SO,'rb').read()
_ph=struct.unpack_from('<Q',data,0x20)[0]; _pe=struct.unpack_from('<H',data,0x36)[0]; _pn=struct.unpack_from('<H',data,0x38)[0]
segs=[]
for i in range(_pn):
    o=_ph+i*_pe
    if struct.unpack_from('<I',data,o)[0]!=1: continue
    segs.append((struct.unpack_from('<Q',data,o+0x10)[0], struct.unpack_from('<Q',data,o+0x08)[0],
                 struct.unpack_from('<Q',data,o+0x20)[0], struct.unpack_from('<I',data,o+0x04)[0]))
syms={}
for line in io.open(RVA,encoding='utf-8',errors='replace'):
    p=line.rstrip('\n').split('\t')
    if len(p)<2: continue
    try: a=int(p[0],16)
    except: continue
    syms[a]=p[1]
addrs=sorted(syms)
def v2o(va):
    for vaddr,off,filesz,flags in segs:
        if vaddr<=va<vaddr+filesz: return off+(va-vaddr)
    return None
def sym(a):
    i=bisect.bisect_right(addrs,a)-1
    if i<0: return "?"
    return syms[addrs[i]] if a==addrs[i] else "%s+0x%x"%(syms[addrs[i]],a-addrs[i])
def nextsym(a):
    i=bisect.bisect_right(addrs,a)
    return addrs[i] if i<len(addrs) else a+0x400
md=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN); md.detail=True
def dis(start,n=120,ret=False):
    off=v2o(start)
    if off is None: print("no map %#x"%start); return
    buf=data[off:off+n*4]; adrp={}; i=0
    while i<len(buf):
        got=False
        for ins in md.disasm(buf[i:i+4],start+i):
            got=True
            s="%08x  %-9s %s"%(ins.address,ins.mnemonic,ins.op_str)
            if ins.mnemonic in ('bl','b') and ins.operands and ins.operands[0].type==ARM64_OP_IMM:
                t=ins.operands[0].imm
                d=t-addrs[max(0,bisect.bisect_right(addrs,t)-1)]
                if d<0x8000: s+="   ; -> %s"%sym(t)
            if ins.mnemonic=='adrp': adrp[ins.operands[0].reg]=ins.operands[1].imm
            if len(ins.operands)>=2:
                op=ins.operands[-1]
                if op.type==ARM64_OP_MEM and op.mem.base in adrp:
                    s+="   ; &0x%x"%(adrp[op.mem.base]+op.mem.disp)
                elif ins.mnemonic=='add' and op.type==ARM64_OP_IMM and ins.operands[1].type==ARM64_OP_REG and ins.operands[1].reg in adrp:
                    s+="   ; &0x%x"%(adrp[ins.operands[1].reg]+op.imm)
            print(s)
        if not got:
            print("%08x  .word     0x%08x"%(start+i,struct.unpack_from('<I',buf,i)[0]))
        i+=4
def func(a, limit=400):
    end=min(nextsym(a), a+limit*4)
    print("=== %#x  %s   (len %#x)"%(a,sym(a),end-a)); dis(a,(end-a)//4)
def bl_callers(target):
    res=[]
    for vaddr,off,filesz,flags in segs:
        if not (flags & 1): continue
        for i in range(0,filesz-3,4):
            w=struct.unpack_from('<I',data,off+i)[0]
            if (w & 0xFC000000)==0x94000000:
                imm=w & 0x03FFFFFF
                if imm & 0x02000000: imm-=0x04000000
                if vaddr+i+imm*4==target: res.append(vaddr+i)
    return res
def regimm(pc,reg,back=40):
    val=0; seen=False
    for k in range(1,back+1):
        a=pc-4*k; off=v2o(a)
        if off is None: return None
        w=struct.unpack_from('<I',data,off)[0]; rd=w&0x1f
        if (w&0x7F800000)==0x52800000 and rd==reg:
            hw=(w>>21)&3; return (((w>>5)&0xFFFF)<<(16*hw)) | val
        if (w&0x7F800000)==0x72800000 and rd==reg:
            hw=(w>>21)&3; val |= ((w>>5)&0xFFFF)<<(16*hw); continue
        if (w&0x7FE0FFE0)==0x2A0003E0 and rd==reg: return None
    return None
def validity(a,n):
    off=v2o(a)
    if off is None: return 0.0
    ok=0
    for i in range(n):
        if len(list(md.disasm(data[off+i*4:off+i*4+4],a+i*4))): ok+=1
    return ok/float(n)
