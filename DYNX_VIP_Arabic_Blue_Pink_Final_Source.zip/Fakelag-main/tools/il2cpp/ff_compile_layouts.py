# Part of the ff_wire_layouts.json pipeline (AGENT 2, dumper rewrite).
# Order: ff_dumpcs_extract.py -> ff_compile_layouts.py -> ff_gen_wire_table.py
#        -> ff_emit_bodydecodertable.py (writes net/BodyDecoderTable.java).
# dump.cs is a DIFFERENT BUILD: STRUCTURE ONLY. No RVA from it is used here.
# NOTE: tools/** is AGENT 4 territory; ff_dumpcs_extract.py duplicates the
# extraction behind ff_message_layouts.json and can be folded into it.
# -*- coding: utf-8 -*-
"""Compile message classes -> FastBinaryReader wire programs.

Encoding (docs/IL2CPP_FINDINGS.md s3):
  U  LEB128 varint, unsigned
  Z  LEB128 varint, zigzag-decoded signed
  B  ONE RAW BYTE        (byte / bool -- ReadByte / ReadBoolean)
  F  varint whose 32 bits ARE the float32
  S  [zigzag varint length][UTF-8]
  ( )  List<T>: zigzag varint count, then the enclosed program that many times
  ?  unmodellable from here on -- decoder bails to a positional dump
"""
import json, csv, re, sys, os

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = r'C:\Users\Tonyt\Documents\GitHub\Fakelag'
T = json.load(open(os.path.join(HERE, 'dumpcs_types.json')))
DEOBF = json.load(open(os.path.join(REPO, 'tools', 'il2cpp', 'ff_deobfuscation_map.json')))

PRIM = {
    'uint': 'U', 'ushort': 'U', 'ulong': 'U', 'char': 'U',
    'int': 'Z', 'short': 'Z', 'long': 'Z',
    'byte': 'B', 'bool': 'B', 'sbyte': 'B',
    'float': 'F',
    'string': 'S',
}
LIST = re.compile(r'^List<(.+)>$')


def deob(n):
    v = DEOBF.get(n)
    return v if v else None


def compile_type(ty, path, prog, names, depth, seen):
    """Append wire codes for one declared type."""
    if depth > 6:
        prog.append('?'); names.append(path); return False
    p = PRIM.get(ty)
    if p:
        prog.append(p); names.append(path); return True
    m = LIST.match(ty)
    if m:
        prog.append('(')
        ok = compile_type(m.group(1), path + '[]', prog, names, depth + 1, seen)
        prog.append(')')
        return ok
    t = T.get(ty)
    if t is None:
        prog.append('?'); names.append(path); return False
    if t['k'] == 'enum':
        prog.append(PRIM.get(t['u'] or 'int', 'Z')); names.append(path); return True
    if t['k'] in ('class', 'struct'):
        if ty in seen:
            prog.append('?'); names.append(path); return False
        if not t['f']:
            prog.append('?'); names.append(path); return False
        seen = seen | {ty}
        ok = True
        for fty, fnm, foff in t['f']:
            d = deob(fnm)
            sub = path + '.' + (d if d else fnm)
            if not compile_type(fty, sub, prog, names, depth + 1, seen):
                ok = False
                break
        return ok
    prog.append('?'); names.append(path); return False


def compile_class(cls):
    t = T.get(cls)
    if t is None:
        return None
    prog, names = [], []
    ok = True
    for fty, fnm, foff in t['f']:
        if not compile_type(fty, fnm, prog, names, 0, {cls}):
            ok = False
            break
    return {'class': cls, 'prog': ''.join(prog), 'names': names,
            'complete': ok, 'nfields': len(t['f']),
            'decl': [[f[0], f[1], deob(f[1])] for f in t['f']]}


# ---- inbound ----
inbound = {}
rows = list(csv.DictReader(open(os.path.join(REPO, 'tools', 'il2cpp', 'ff_inbound_registry.tsv'),
                                encoding='utf-8'), delimiter='\t'))
for r in rows:
    cid = int(r['cmd_id']); cls = r['inbound_message_class']
    if cls in ('?', '', None):
        continue
    c = compile_class(cls)
    if c:
        c['cmd_name'] = r['cmd_name']
        c['handler'] = r['handler_method']
        inbound[cid] = c

# ---- outbound ----
outbound = {}
orx = re.compile(r'^\s*(\d+)\s+(\S+)\s+(\S+)')
obreg = open(os.path.join(REPO, 'tools', 'il2cpp', 'ff_outbound_registry.txt'), encoding='utf-8').read().splitlines()
print('outbound registry sample:', obreg[:4], file=sys.stderr)
json.dump({'inbound': inbound}, open('layouts_in.json', 'w'), separators=(',', ':'))
print('inbound compiled:', len(inbound), file=sys.stderr)
print('complete:', sum(1 for v in inbound.values() if v['complete']), file=sys.stderr)

# ---- outbound (msgid  rva  class  site) ----
out2 = {}
seen_cls = {}
for line in obreg:
    m = re.match(r'^\s*(-?\d+)\s+([0-9a-fA-F]+)\s+(\S+)\s+(.*)$', line)
    if not m:
        continue
    cid = int(m.group(1)); cls = m.group(3)
    if cid < 0 or cls == '?':
        continue
    seen_cls.setdefault(cid, set()).add(cls)
# Cmd 2001 outbound: the registry row reads '?' because the send site passes the
# class indirectly. docs/IL2CPP_FINDINGS.md 5.1 solved it -- message.DAIDIMLOEPL
# wrapping message.ACDHGKMPIDJ, sole sender proven at 0x078CF1D4.
seen_cls[2001] = {'DAIDIMLOEPL'}
for cid, cs in seen_cls.items():
    if len(cs) != 1:
        continue          # ambiguous send site; skip rather than guess
    cls = next(iter(cs))
    c = compile_class(cls)
    if c:
        out2[cid] = c
json.dump({'inbound': inbound, 'outbound': out2}, open('layouts.json', 'w'), separators=(',', ':'))
print('outbound compiled:', len(out2), 'complete:',
      sum(1 for v in out2.values() if v['complete']), file=sys.stderr)
print('ambiguous outbound ids skipped:',
      sum(1 for v in seen_cls.values() if len(v) != 1), file=sys.stderr)
for cid in (106, 107, 168, 1900, 2010, 2001, 2012, 135, 412, 931, 1205, 1577, 1578, 957, 104, 2000):
    v = inbound.get(cid)
    if v:
        print('IN ', cid, v['cmd_name'], v['class'], v['prog'], v['names'][:26], file=sys.stderr)
for cid in (106, 104, 2001, 413):
    v = out2.get(cid)
    if v:
        print('OUT', cid, v['class'], v['prog'], v['names'][:26], file=sys.stderr)
