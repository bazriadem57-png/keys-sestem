# Part of the ff_wire_layouts.json pipeline (AGENT 2, dumper rewrite).
# Order: ff_dumpcs_extract.py -> ff_compile_layouts.py -> ff_gen_wire_table.py
#        -> ff_emit_bodydecodertable.py (writes net/BodyDecoderTable.java).
# dump.cs is a DIFFERENT BUILD: STRUCTURE ONLY. No RVA from it is used here.
# NOTE: tools/** is AGENT 4 territory; ff_dumpcs_extract.py duplicates the
# extraction behind ff_message_layouts.json and can be folded into it.
# -*- coding: utf-8 -*-
"""Emit the packed wire-layout table + tools/il2cpp/ff_wire_layouts.json."""
import json, re, os, collections

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = r'C:\Users\Tonyt\Documents\GitHub\Fakelag'
T = json.load(open(os.path.join(HERE, 'dumpcs_types.json')))
L = json.load(open(os.path.join(HERE, 'layouts.json')))
DEOBF = json.load(open(os.path.join(REPO, 'tools', 'il2cpp', 'ff_deobfuscation_map.json')))
OBF = re.compile(r'^[A-Z]{9,12}$')

CURATED = {
    'LJFHDBEHHJG': 'attacker',
    'DPJANIEAKHC': 'victim',
    'CACFKDEFAGE': 'killer',
    'BKCDOJHADJF': 'killerName',
    'GMNGCBJMDLB': 'damage',
    'LJIIDMHPFEH': 'spDamageP',
    'DNBCDKBENBM': 'weaponId',
    'PCNJCJIMBGM': 'buffId',
    'LNOIFBAFGOK': 'specialHit',
    'EJJFPFENMBP': 'weaponId',
    'DNNFOOGPFHO': 'tick',
    'MNLCCJOLFGL': 'spDamage',
    'NEMMGLPGNJK': 'hpDamage',
    'FCMEFOJDHNP': 'hitZone',
    'IIFDBDCDMJN': 'icon',
    'BHGGAEEHJCO': 'entityId',
    'GDKHFHLAIPJ': 'entityId',
    'LOPEMDKABFO': 'visMask',
    'MOEFFAIDCBP': 'pos',
    'LFCNHAJBHEE': 'aim',
    'CCLCIJGALBH': 'moveDir',
    'AAPGPMPKMBD': 'vel',
    'DIPPKFBIILG': 'aimAux',
    'BGDMAEFKAFK': 'physState',
    'LADGDMGAMBG': 'pose',
    'LPKKPCBKEBA': 'platformId',
    'AFHGLCCBKCP': 'pingMs',
    'FFBJAEPHNDP': 'lowGravity',
    'AEDOFFHONGM': 'ugcOnly',
    'LFDOAGEFMGF': 'slidePath',
    'HMKGHANBCNJ': 'clientMs',
    'DJOGCAJNMNC': 'x',
    'IKOAGHHEHNL': 'y',
    'HDAKKOIKINN': 'z',
    'BCAEBLEEEOD': 'w',
    'JPOBFBNAMHM': 'shopCtx',
    'KIJJKKOEEMB': 'itemIds',
    'LGKOKLCLEGN': 'buyType',
}

fieldTypes = collections.defaultdict(collections.Counter)
for tn, t in T.items():
    for ty, nm, off in t['f']:
        fieldTypes[nm][ty] += 1

PRIMS = ('uint', 'int', 'ushort', 'short', 'byte', 'bool', 'sbyte', 'float',
         'string', 'ulong', 'long', 'double', 'char', 'object')


def readable_type(nm):
    for ty, _c in fieldTypes[nm].most_common():
        base = re.sub(r'^List<|>$', '', ty).split('.')[-1].replace('[]', '')
        if base in PRIMS or OBF.match(base):
            continue
        return base
    return None


def enum_prefix(ty):
    t = T.get(re.sub(r'^List<|>$', '', ty or ''))
    if not t or t['k'] != 'enum' or not t['e']:
        return None
    p = os.path.commonprefix([e[0] for e in t['e']])
    if '_' in p:
        p = p[:p.rindex('_')]
    p = re.sub(r'[^A-Za-z0-9_]', '', p)
    return p if len(p) >= 3 else None


STATS = collections.Counter()


AXES = ('x', 'y', 'z', 'w')


def name_for(obf):
    """(name, source) or (None, None). 'weak' sources never name a slot alone."""
    if obf in CURATED:
        STATS['curated'] += 1
        return CURATED[obf], 'curated'
    d = DEOBF.get(obf)
    if d and d != 'None':
        STATS['nametable'] += 1
        return d, 'nametable'
    mc = fieldTypes[obf].most_common(1) if obf in fieldTypes else []
    ty = mc[0][0] if mc else ''
    e = enum_prefix(ty)
    if e:
        STATS['enum'] += 1
        return e, 'enum'
    r = readable_type(obf)
    if r:
        STATS['typehint'] += 1
        return r, 'typehint'
    return None, None


def slot_names(entry):
    """Name a slot only from segments that actually resolved; drop the rest.

    A bare axis (x/y/z/w) with no named parent carries no information, so it is
    dropped rather than emitted as a misleading label.
    """
    res = []
    for path in entry['names']:
        segs = path.replace('[]', '').split('.')
        kept = []
        for s in segs:
            n, src = name_for(s)
            if n is None:
                continue
            if src == 'typehint' and n in ('Vector3', 'Vector2', 'Quaternion'):
                continue
            kept.append(n)
        while kept and kept[0] in AXES:
            kept.pop(0)
        if not kept or all(k in AXES for k in kept):
            res.append(None)
            continue
        nm = '.'.join(kept[-3:])
        res.append(nm[:40])
    return res


PROG_OK = set('UZBFS()')
records = {}
for kind, tag in (('inbound', '<'), ('outbound', '>')):
    for cid, v in L[kind].items():
        if not v['complete'] or not v['prog']:
            continue
        if not set(v['prog']) <= PROG_OK:
            continue
        records[(tag, int(cid))] = {'prog': v['prog'], 'names': slot_names(v)}

progs, names = [], []
namedFields = 0
for (tag, cid), r in sorted(records.items(), key=lambda kv: (kv[0][0], kv[0][1])):
    progs.append(tag + str(cid) + ':' + r['prog'])
    ns = [(i, n) for i, n in enumerate(r['names']) if n]
    namedFields += len(ns)
    if ns:
        names.append(tag + str(cid) + ':' + ','.join(str(i) + '=' + n for i, n in ns))

P = '|'.join(progs)
N = '|'.join(names)
print('entries', len(records), 'prog chars', len(P), 'name chars', len(N),
      'named slots', namedFields, dict(STATS))


def chunks(s, n=24000):
    out, cur, ln = [], [], 0
    for part in s.split('|'):
        if ln + len(part) + 1 > n and cur:
            out.append('|'.join(cur))
            cur, ln = [], 0
        cur.append(part)
        ln += len(part) + 1
    if cur:
        out.append('|'.join(cur))
    return out


PC, NC = chunks(P), chunks(N)
print('prog chunks', len(PC), 'name chunks', len(NC))
json.dump({'progs': PC, 'names': NC, 'count': len(records)},
          open(os.path.join(HERE, 'table_payload.json'), 'w'))

art = {
    '_note': ('Wire layouts for the Free Fire Max UDP protocol, keyed by (cmd, direction). '
              'Generated by joining tools/il2cpp/ff_inbound_registry.tsv and '
              'ff_outbound_registry.txt against Il2CppDumper STRUCTURE ONLY (declared field '
              'order + declared types). RVAs from that dump belong to a DIFFERENT BUILD and are '
              'deliberately absent from this file. Field names come from '
              'ff_deobfuscation_map.json, from surviving enum member-name prefixes, from a '
              'readable declared type seen elsewhere in the dump, and from a curated table '
              'backed by docs/COMBAT_AND_HEALTH.md and docs/IL2CPP_FINDINGS.md.'),
    '_wire_codes': {
        'U': 'LEB128 varint, unsigned',
        'Z': 'LEB128 varint, zigzag-decoded signed',
        'B': 'ONE RAW BYTE (ReadByte / ReadBoolean) - breaks a naive varint walk',
        'F': 'LEB128 varint whose 32 bits ARE the float32',
        'S': '[zigzag varint byte length][UTF-8]',
        '()': 'List<T>: zigzag varint count, then the enclosed program that many times',
        '?': 'not modellable - a decoder must fall back to a positional dump here',
    },
    'inbound': {}, 'outbound': {},
}
for kind, tag in (('inbound', '<'), ('outbound', '>')):
    for cid, v in L[kind].items():
        e = {'class': v['class'], 'prog': v['prog'], 'complete': v['complete'],
             'paths': v['names'], 'named': slot_names(v),
             'decl': [{'type': t, 'obf': n, 'name': d} for t, n, d in v['decl']]}
        if kind == 'inbound':
            e['cmd_name'] = v.get('cmd_name')
            e['handler'] = v.get('handler')
        art[kind][str(cid)] = e
json.dump(art, open(os.path.join(REPO, 'tools', 'il2cpp', 'ff_wire_layouts.json'), 'w'),
          indent=0, sort_keys=True)
print('artifact written')
