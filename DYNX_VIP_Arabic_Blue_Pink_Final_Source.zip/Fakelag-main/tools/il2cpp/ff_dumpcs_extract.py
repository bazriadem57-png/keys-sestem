# Part of the ff_wire_layouts.json pipeline (AGENT 2, dumper rewrite).
# Order: ff_dumpcs_extract.py -> ff_compile_layouts.py -> ff_gen_wire_table.py
#        -> ff_emit_bodydecodertable.py (writes net/BodyDecoderTable.java).
# dump.cs is a DIFFERENT BUILD: STRUCTURE ONLY. No RVA from it is used here.
# NOTE: tools/** is AGENT 4 territory; ff_dumpcs_extract.py duplicates the
# extraction behind ff_message_layouts.json and can be folded into it.
# Pass 1 over dump.cs: STRUCTURE ONLY (field order + declared types + enum members).
# dump.cs is a DIFFERENT BUILD -- its RVAs are deliberately discarded here.
import re, json, sys, io

DUMP = r'C:\Users\Tonyt\Videos\ZRT-Toolbox\Dump\dump.cs'
CLS = re.compile(r'^(?:public|internal)\s+(?:sealed\s+|abstract\s+|static\s+)*'
                 r'(class|struct|enum|interface)\s+([A-Za-z_][A-Za-z0-9_]*)'
                 r'(?:\s*:\s*([^/\r\n{]+?))?\s*(?://.*)?$')
FIELD = re.compile(r'^\s*(?:\[[^\]]*\]\s*)*public\s+'
                   r'(?:(static|const|readonly)\s+)*'
                   r'([A-Za-z_][A-Za-z0-9_.<>,\[\]]*)\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?:=\s*([^;]*))?;')

out = {}
cur = None
depth = 0
in_methods = False
with io.open(DUMP, encoding='utf-8', errors='replace') as f:
    for line in f:
        s = line.rstrip('\n')
        if cur is None:
            m = CLS.match(s)
            if m:
                cur = {'k': m.group(1), 'n': m.group(2), 'b': (m.group(3) or '').strip(),
                       'f': [], 'c': {}, 'e': [], 'u': None}
                depth = s.count('{') - s.count('}')
                in_methods = False
            continue
        if s.strip() in ('// Methods', '// Properties'):
            in_methods = True
        depth += s.count('{') - s.count('}')
        if not in_methods:
            fm = FIELD.match(s)
            if fm:
                mod, ty, nm, val = fm.group(1), fm.group(2), fm.group(3), fm.group(4)
                if nm == 'value__':
                    cur['u'] = ty
                elif mod == 'const':
                    if val is not None:
                        sv = re.match(r'^\s*"(.*)"\s*$', val)
                        if sv:
                            cur['c'][nm] = sv.group(1)
                        else:
                            iv = re.match(r'^\s*(-?\d+)\s*$', val)
                            if iv and cur['k'] == 'enum':
                                cur['e'].append([nm, int(iv.group(1))])
                elif mod is None:
                    off = None
                    om = re.search(r'//\s*(0x[0-9A-Fa-f]+)\s*$', s)
                    if om: off = om.group(1)
                    cur['f'].append([ty, nm, off])
        if depth <= 0:
            out[cur['n']] = cur
            cur = None

print('types captured:', len(out), file=sys.stderr)
json.dump(out, open('dumpcs_types.json', 'w'), separators=(',', ':'))
