#!/usr/bin/env python3
"""ffdump — offline analysis for Free Fire Max packet captures.

Reads the streamed capture format from ``docs/DUMPER_REWRITE_BRIEF.md`` §4.4 as
well as both older formats, solves the per-session header encoding, decrypts
QQ-TEA bodies when the capture carries the session key, decodes bodies against
the game's own message classes, and reports what flowed and what we still
cannot read.

Subcommands
-----------
  info       what a capture file contains, per file
  timeline   lobby -> match -> rounds -> end, plus endpoints and key state
  hist       per-command histogram, sorted by volume
  coverage   decode coverage n/total and the total unknown surface
  unknown    field-shape inventory for everything that did not decode
  diff       compare two captures (replaces FreezeDiffAnalyzer)
  decode     print decoded packets, optionally filtered by cmd/direction
  summary    timeline + coverage + histogram in one pass
  schema     what layouts we have, and the layout of one (cmd, direction)
  solve      just the header solve, per endpoint

Examples
--------
  python ffdump.py coverage captures/phone_pull17
  python ffdump.py hist captures/phone_kick --top 40
  python ffdump.py decode captures/phone_pull17 --cmd 2001 --dir OUT -n 3
  python ffdump.py unknown captures/phone_pull16 --top 10
  python ffdump.py diff captures/before.txt captures/after.txt
  python ffdump.py schema --cmd 106 --dir IN
  python ffdump.py schema --build          # re-index dump.cs (structure only)
"""

from __future__ import annotations

import argparse
import io
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ffproto import analyze, capture, catalogue, decode, framing, reports, schema  # noqa: E402


def _key(text):
    if not text:
        return None
    try:
        k = bytes.fromhex(text.strip())
    except ValueError:
        raise SystemExit("--key must be hex; got %r" % text)
    if len(k) < 16:
        raise SystemExit("--key must be at least 16 bytes (32 hex chars)")
    return k


def _open_out(path):
    if not path:
        return None
    return io.open(path, "w", encoding="utf-8")


def _analysis(args):
    return analyze.Analysis(args.paths, key=_key(getattr(args, "key", None)),
                            solve_per_endpoint=not getattr(args, "one_session", False),
                            max_packets=getattr(args, "max_packets", None),
                            infer=getattr(args, "infer", False))


# ---------------------------------------------------------------- commands

def cmd_info(args):
    cs = capture.load(args.paths)
    print("files: %d   formats: %s" % (len(cs.files), ", ".join(cs.formats) or "?"))
    for cf in cs.files:
        st = cf.stats()
        print("  %s" % cf.path)
        print("     format=%s packets=%d bad_lines=%d truncated_tail=%s "
              "payload_truncated=%d events=%d"
              % (st["format"], st["packets"], st["bad_lines"],
                 st["truncated_tail"], st["payload_truncated"], st["events"]))
        if cf.header:
            for k, v in cf.header.items():
                print("     %-16s %s" % (k, v))
    print("")
    print("totals: %s" % cs.stats())
    if cs.formats and all(f != capture.FMT_NEW for f in cs.formats):
        print("")
        print("NOTE: old capture format. It cannot supply cmd, cmdname, flags,")
        print("      src (TCP was never captured), dt_us, SessionTimeline phase,")
        print("      match index or a decoded note. Command ids below are")
        print("      RE-DERIVED here from the header, not read from the file.")
    return 0


def cmd_solve(args):
    a = _analysis(args)
    for ep, s in a.sessions.items():
        print(s.describe())
        if s.layout:
            print("    DATALEN identity %d/%d   crc7 %d/%d"
                  % (s.hits, s.tested, s.crc_ok, s.crc_total))
    return 0


def cmd_timeline(args):
    out = _open_out(args.out)
    print(reports.timeline(_analysis(args), out))
    return 0


def cmd_hist(args):
    out = _open_out(args.out)
    print(reports.histogram(_analysis(args), out, limit=args.top))
    return 0


def cmd_coverage(args):
    out = _open_out(args.out)
    print(reports.coverage(_analysis(args), out, worst=args.top))
    return 0


def cmd_unknown(args):
    out = _open_out(args.out)
    print(reports.unknown_inventory(_analysis(args), out, top=args.top,
                                    samples=args.samples))
    return 0


def cmd_summary(args):
    out = _open_out(args.out)
    print(reports.summary(_analysis(args), out))
    return 0


def cmd_diff(args):
    out = _open_out(args.out)
    if args.split_effect:
        eff = args.split_effect
        whole = analyze.Analysis([args.a], key=_key(args.key))
        off = whole.view(lambda r: eff not in (r.pkt.effects or ()))
        on = whole.view(lambda r: eff in (r.pkt.effects or ()))
        if not on.rows or not off.rows:
            print("WARNING: splitting on effect %r is degenerate — %d packets "
                  "with it, %d without. The capture's phase column carries no "
                  "/EFFECT suffix, or the effect never toggled."
                  % (eff, len(on.rows), len(off.rows)))
        print(reports.diff(off, on, out,
                           label_a=args.label_a or ("no-" + eff),
                           label_b=args.label_b or eff, top=args.top))
        return 0
    if not args.b:
        raise SystemExit("diff needs two captures, or --split-effect NAME")
    a = analyze.Analysis([args.a], key=_key(args.key))
    b = analyze.Analysis([args.b], key=_key(args.key_b or args.key))
    print(reports.diff(a, b, out,
                       label_a=args.label_a or os.path.basename(str(args.a)),
                       label_b=args.label_b or os.path.basename(str(args.b)),
                       top=args.top))
    return 0


def cmd_decode(args):
    a = _analysis(args)
    shown = 0
    for r in a.rows:
        if args.cmd is not None and r.cmd != args.cmd:
            continue
        if args.dir and r.direction != args.dir:
            continue
        if args.status and r.status != args.status:
            continue
        u = r.udp
        head = ("seq=%-7s %-3s cmd=%-5s %-34s %-6s len=%-5s %s"
                % (r.pkt.seq, r.direction, r.cmd, r.name[:34],
                   ("REL" if u and u.reliable else "NONREL"),
                   r.pkt.length, r.status))
        print(head)
        if u is not None:
            print("    MsgKey=%d crc=%s flags=0x%X order=%s Length=%d body=%d"
                  % (u.msg_key, "ok" if u.crc_ok else "BAD", u.flags,
                     u.order_id, u.length, len(u.body)))
        if r.decoded is not None:
            print("    %s" % r.decoded.format(args.fields))
        elif r.body is not None:
            _d, slots = decode.decode_untyped(r.body, limit=args.fields)
            print("    untyped: %s" % " ".join(s.describe() for s in slots))
        if args.hex and r.pkt.payload:
            print("    hex: %s" % r.pkt.payload.hex())
        shown += 1
        if args.n and shown >= args.n:
            break
    if not shown:
        print("(no packets matched)")
    return 0


def cmd_schema(args):
    if args.build:
        schema.build_index(args.dump_cs)
        return 0
    s = schema.default_schema()
    if args.cmd is None:
        import json
        print(json.dumps(s.coverage(), indent=2))
        print("index: %s" % s.index_path)
        print(s.index_note)
        return 0
    direction = args.dir or schema.IN
    lay = s.layout(args.cmd, direction)
    print("cmd %d %s  %s" % (args.cmd, direction, catalogue.describe(args.cmd)))
    print("class : %s" % (s.class_for(args.cmd, direction) or "(none)"))
    if lay is None:
        print("layout: NONE")
        return 1
    print("layout: %s (%s)" % ("complete" if lay.complete else
                               "partial, unresolved=" + ",".join(sorted(lay.unresolved)),
                               lay.source))
    notes = schema.VERIFIED_NOTES.get((args.cmd, direction), {})
    idx = [0]

    def dump(node, depth):
        pad = "  " * depth
        if node.kind == "struct":
            print("%s%s : %s" % (pad, node.name, node.ctype))
            for c in node.children:
                dump(c, depth + 1)
        elif node.kind == "list":
            print("%s%s : %s  [zigzag varint count, then each element]"
                  % (pad, node.name, node.ctype))
            dump(node.elem, depth + 1)
        else:
            i = idx[0]
            idx[0] += 1
            readable = s.readable(node.name)
            note = notes.get(i)
            extra = ""
            if readable:
                extra += "  <- %s" % readable
            if note:
                extra += "   # %s" % note
            print("%sv%-3d %-16s %-14s %s%s"
                  % (pad, i, node.name, node.ctype, node.kind, extra))
    dump(lay.root, 0)
    return 0


# ---------------------------------------------------------------- argparse

def build_parser():
    p = argparse.ArgumentParser(
        prog="ffdump", description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="command")

    def add_paths(sp, key=True):
        sp.add_argument("paths", nargs="+",
                        help="capture files, directories or globs")
        if key:
            sp.add_argument("--key", help="16-byte TEA session key as hex; "
                                          "overrides the one in the file header")
            sp.add_argument("--one-session", action="store_true",
                            help="solve one header layout for the whole capture "
                                 "instead of one per remote endpoint")
            sp.add_argument("--max-packets", type=int, default=None,
                            help="stop after N packets")
            sp.add_argument("--infer", action="store_true",
                            help="for ids with a class in only one direction, "
                                 "test the other direction's class and accept "
                                 "it only when it consumes byte-exactly on "
                                 "every sample. Proves a SHAPE, not a meaning "
                                 "- field names stay unverified.")
        sp.add_argument("-o", "--out", help="also write the report to this file")

    sp = sub.add_parser("info", help="what a capture file contains")
    add_paths(sp, key=False)
    sp.set_defaults(func=cmd_info)

    sp = sub.add_parser("solve", help="solve the header encoding per endpoint")
    add_paths(sp)
    sp.set_defaults(func=cmd_solve)

    sp = sub.add_parser("timeline", help="session timeline")
    add_paths(sp)
    sp.set_defaults(func=cmd_timeline)

    sp = sub.add_parser("hist", help="per-command histogram")
    add_paths(sp)
    sp.add_argument("--top", type=int, default=0, help="only the top N rows")
    sp.set_defaults(func=cmd_hist)

    sp = sub.add_parser("coverage", help="decode coverage and unknown surface")
    add_paths(sp)
    sp.add_argument("--top", type=int, default=25,
                    help="how many worst-decoding ids to list")
    sp.set_defaults(func=cmd_coverage)

    sp = sub.add_parser("unknown", help="field inventory for undecoded commands")
    add_paths(sp)
    sp.add_argument("--top", type=int, default=40)
    sp.add_argument("--samples", type=int, default=6)
    sp.set_defaults(func=cmd_unknown)

    sp = sub.add_parser("summary", help="timeline + coverage + histogram")
    add_paths(sp)
    sp.set_defaults(func=cmd_summary)

    sp = sub.add_parser("decode", help="print decoded packets")
    add_paths(sp)
    sp.add_argument("--cmd", type=int, help="only this command id")
    sp.add_argument("--dir", choices=("IN", "OUT"))
    sp.add_argument("--status", choices=analyze.STATUSES)
    sp.add_argument("-n", type=int, default=20, help="stop after N packets")
    sp.add_argument("--fields", type=int, default=64,
                    help="max fields printed per packet")
    sp.add_argument("--hex", action="store_true", help="also print raw hex")
    sp.set_defaults(func=cmd_decode)

    sp = sub.add_parser("diff", help="compare two captures, or split one")
    sp.add_argument("a")
    sp.add_argument("b", nargs="?",
                    help="omit when using --split-effect")
    sp.add_argument("--split-effect", metavar="NAME",
                    help="split ONE capture on whether NAME (e.g. FREEZE, "
                         "GHOST, JITTER) is in the phase column's /EFFECT "
                         "suffix. This is the FreezeDiffAnalyzer replacement; "
                         "it prints both side sizes so a degenerate split is "
                         "visible instead of silent.")
    sp.add_argument("--key")
    sp.add_argument("--key-b", help="a different key for the second capture")
    sp.add_argument("--label-a")
    sp.add_argument("--label-b")
    sp.add_argument("--top", type=int, default=40)
    sp.add_argument("-o", "--out")
    sp.set_defaults(func=cmd_diff)

    sp = sub.add_parser("schema", help="message layouts")
    sp.add_argument("--cmd", type=int)
    sp.add_argument("--dir", choices=("IN", "OUT"), default="IN")
    sp.add_argument("--build", action="store_true",
                    help="re-index dump.cs (structure only; never its RVAs)")
    sp.add_argument("--dump-cs", help="path to dump.cs for --build")
    sp.set_defaults(func=cmd_schema)
    return p


def main(argv=None):
    p = build_parser()
    args = p.parse_args(argv)
    if not getattr(args, "func", None):
        p.print_help()
        return 1
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
