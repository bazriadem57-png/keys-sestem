"""Offline proof of the aim-vector bias rewrite, against a real capture."""
import sys, struct, math
sys.path.insert(0, r"C:\Users\Tonyt\Documents\GitHub\Fakelag\tools")
import ffdecode as F

def rd_varint(b, i):
    v = 0; s = 0
    while i < len(b):
        c = b[i]; i += 1; v |= (c & 0x7f) << s
        if not (c & 0x80): return v, i
        s += 7
    return None, i

def wr_varint(v):
    out = bytearray()
    while True:
        c = v & 0x7f; v >>= 7
        if v: out.append(c | 0x80)
        else: out.append(c); break
    return bytes(out)

def split_varints(b):
    out = []; i = 0
    while i < len(b):
        v, i = rd_varint(b, i)
        if v is None: break
        out.append(v)
    return out

def f2u(f): return struct.unpack('<I', struct.pack('<f', f))[0]
def u2f(u): return struct.unpack('<f', struct.pack('<I', u & 0xFFFFFFFF))[0]

def find_aim_triple(vals):
    """Locate the unit vector by length, never by hardcoded index."""
    for i in range(len(vals) - 2):
        x, y, z = u2f(vals[i]), u2f(vals[i+1]), u2f(vals[i+2])
        L = x*x + y*y + z*z
        if 0.98 < L < 1.02: return i
    return -1

def bias_pitch(x, y, z, d_rad):
    """Rotate the unit vector up by d_rad, preserving azimuth."""
    p = math.asin(max(-1.0, min(1.0, y)))
    h = math.sqrt(x*x + z*z)
    p2 = max(-math.pi/2 + 1e-4, min(math.pi/2 - 1e-4, p + d_rad))
    h2 = math.cos(p2)
    if h > 1e-9:
        x, z = x * (h2 / h), z * (h2 / h)
    return x, math.sin(p2), z

def rewrite(pkt, layout_order, mask, d_rad):
    """Returns a NEW packet with the aim vector biased, Length fixed, CRC resealed."""
    r = F.parse(pkt, mask, layout_order)
    if r is None or r['Cmd'] != 2001 or (r['Flags'] & 1): return None
    hdr = r['hdr']; payload = pkt[hdr:]
    vals = split_varints(payload)
    if len(vals) < 17: return None
    i = find_aim_triple(vals)
    if i < 0: return None
    x, y, z = (u2f(vals[i]), u2f(vals[i+1]), u2f(vals[i+2]))
    nx, ny, nz = bias_pitch(x, y, z, d_rad)
    vals[i], vals[i+1], vals[i+2] = f2u(nx), f2u(ny), f2u(nz)
    newpay = b''.join(wr_varint(v) for v in vals)
    out = bytearray(pkt[:hdr] + newpay)
    # Length field must follow the payload size
    offs, _ = F.field_offsets(layout_order, r['reliable'])
    lo = offs[F.DATALEN]
    n = len(newpay)
    out[lo]   = (n & 0xFF) ^ mask
    out[lo+1] = ((n >> 8) & 0xFF) ^ mask
    out[1] = F.crc7(bytes(out[2:]))      # reseal
    return bytes(out), i, math.degrees(math.asin(y)), math.degrees(math.asin(ny))
