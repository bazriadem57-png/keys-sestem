#!/usr/bin/env python3
"""ffsweep — run the decoder over many captures and aggregate the numbers.

This is the regression harness for the offline tooling: point it at a tree of
captures and it reports, in one table, how many packets parsed, how many
command ids were identified, decode coverage as ``n/total``, and the size of
the unknown surface.  Per-file rows make a regression obvious; the totals are
the number to quote.

    python ffsweep.py captures/
    python ffsweep.py captures/ --min-packets 500 --csv sweep.csv
    python ffsweep.py captures/ --per-cmd            # aggregate per command id

Files are deduplicated by content hash, because the same capture appears under
several directories in this repo and counting it twice would inflate every
total.
"""

from __future__ import annotations

import argparse
import collections
import hashlib
import io
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ffproto import analyze, capture, catalogue  # noqa: E402


def find_captures(roots):
    out = []
    for root in roots:
        if os.path.isfile(root):
            out.append(root)
            continue
        for base, _dirs, names in os.walk(root):
            for n in sorted(names):
                if n.lower().endswith(".txt"):
                    out.append(os.path.join(base, n))
    return out


def digest(path):
    h = hashlib.sha1()
    with io.open(path, "rb") as fh:
        while True:
            chunk = fh.read(1 << 20)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def main(argv=None):
    p = argparse.ArgumentParser(prog="ffsweep", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("roots", nargs="+", help="capture files or directories")
    p.add_argument("--min-packets", type=int, default=200,
                   help="skip files with fewer packets (default 200)")
    p.add_argument("--limit", type=int, default=0, help="stop after N files")
    p.add_argument("--max-packets", type=int, default=0,
                   help="analyse at most N packets per file")
    p.add_argument("--csv", help="write the per-file table here")
    p.add_argument("--per-cmd", action="store_true",
                   help="also print an aggregate per (cmd, direction)")
    p.add_argument("--infer", action="store_true",
                   help="allow other-direction shape inference (see ffdump)")
    p.add_argument("--key", help="TEA session key as hex, applied to every file")
    p.add_argument("-q", "--quiet", action="store_true")
    args = p.parse_args(argv)

    key = bytes.fromhex(args.key) if args.key else None
    paths = find_captures(args.roots)
    seen = set()
    rows = []
    totals = collections.Counter()
    per_cmd = {}
    cmds_seen = set()
    t0 = time.time()

    for path in paths:
        if args.limit and len(rows) >= args.limit:
            break
        try:
            cf = capture.CaptureFile(path)
        except OSError:
            continue
        if len(cf) < args.min_packets:
            continue
        d = digest(path)
        if d in seen:
            continue
        seen.add(d)
        try:
            a = analyze.Analysis([path], key=key, infer=args.infer,
                                 max_packets=args.max_packets or None)
        except Exception as exc:                       # never lose the sweep
            rows.append((path, len(cf), 0, 0, 0, 0, "ERROR " + str(exc)[:60]))
            continue
        ok, decodable, total = a.coverage()
        ids = len({c for c, _d in a.cmd_stats})
        cmds_seen |= set(a.cmd_stats)
        unknown = sum(n for n, _b in a.unknown_surface().values())
        rows.append((path, total, ids, ok, decodable, unknown, cf.fmt))
        totals["files"] += 1
        totals["packets"] += total
        totals["ok"] += ok
        totals["decodable"] += decodable
        totals["unknown"] += unknown
        totals["bytes"] += sum(r.pkt.length or 0 for r in a.rows)
        for st in analyze.STATUSES:
            totals[st] += a.status_counts[st]
        for k, s in a.cmd_stats.items():
            agg = per_cmd.get(k)
            if agg is None:
                agg = per_cmd[k] = [0, 0, 0]      # n, ok, decodable
            agg[0] += s.n
            agg[1] += s.ok
            agg[2] += s.decodable
        if not args.quiet:
            print("%-70s %7d pkts  %4d ids  decoded %6d/%-6d  unknown %6d"
                  % (os.path.basename(path)[:70], total, ids, ok, decodable,
                     unknown))

    print("")
    print("=" * 96)
    print("SWEEP TOTALS over %d distinct capture files (%.1fs)"
          % (totals["files"], time.time() - t0))
    print("  packets parsed        : %d" % totals["packets"])
    print("  bytes                 : %d" % totals["bytes"])
    print("  distinct (cmd, dir)   : %d   distinct command ids: %d"
          % (len(cmds_seen), len({c for c, _d in cmds_seen})))
    print("  catalogue coverage    : %d of %d known ids ever seen on the wire"
          % (len({c for c, _d in cmds_seen} & set(catalogue.all_ids())),
             catalogue.count()))
    pct = (100.0 * totals["ok"] / totals["decodable"]) if totals["decodable"] else 0
    print("  DECODE COVERAGE       : %d/%d decodable = %.2f%%"
          % (totals["ok"], totals["decodable"], pct))
    print("  UNKNOWN SURFACE       : %d packets (%.2f%% of all)"
          % (totals["unknown"],
             100.0 * totals["unknown"] / max(1, totals["packets"])))
    print("  status split:")
    for st in analyze.STATUSES:
        if totals[st]:
            print("    %-12s %9d  %5.2f%%"
                  % (st, totals[st], 100.0 * totals[st] / max(1, totals["packets"])))

    if args.per_cmd:
        print("")
        print("-- per (cmd, direction), by volume --")
        print("%-6s %-3s %-40s %9s %9s %9s" %
              ("cmd", "dir", "name", "packets", "decoded", "rate"))
        for (cmd, d), (n, ok, dec) in sorted(per_cmd.items(),
                                             key=lambda kv: -kv[1][0]):
            print("%-6d %-3s %-40s %9d %9d %8.1f%%"
                  % (cmd, d, catalogue.name_or(cmd)[:40], n, ok,
                     100.0 * ok / dec if dec else 0.0))

    if args.csv:
        with io.open(args.csv, "w", encoding="utf-8") as fh:
            fh.write("path,packets,cmd_ids,decoded,decodable,unknown,format\n")
            for r in rows:
                fh.write("%s,%d,%d,%d,%d,%d,%s\n"
                         % (r[0].replace(",", ";"), r[1], r[2], r[3], r[4],
                            r[5], r[6]))
        print("")
        print("per-file table written to %s" % args.csv)
    return 0


if __name__ == "__main__":
    sys.exit(main())
