# -*- coding: utf-8 -*-
"""Generates res/layout/activity_main.xml for the Nuvola redesign.

Written as a file rather than a heredoc: CLAUDE.md records that quoting inside
a bash heredoc has broken this twice already.
"""
import io, os, re, sys

OUT = r'C:\Users\Tonyt\Documents\GitHub\Fakelag\fakelag\fakelag-beta\app\src\main\res\layout\activity_main.xml'

NEED = """btn_engine btn_shizuku btn_show_floating cb_aim cb_aimbtn cb_crosshair
cb_dev_mode cb_display cb_esp cb_espdebug cb_esptune cb_float_freeze
cb_float_ghost cb_float_tele cb_radar cb_vpn cb_zoombtn
dot_app dot_display dot_engine dot_vpn group_mask_options
group_tele_options iv_engine_power main_content seek_crosshair_alpha
seek_crosshair_size seek_float_alpha seek_float_size seek_mask_bar_length
seek_mask_bar_thickness tv_aim_status tv_aimbtn_status tv_crosshair_alpha_value
tv_crosshair_size_value tv_crosshair_status tv_dev_mode_status tv_display_status
tv_esp_status tv_espdebug_status tv_esptune_status tv_float_alpha_value
tv_float_freeze_status tv_float_ghost_status tv_float_size_value
tv_float_tele_status tv_mask_bar_length_value tv_mask_bar_thickness_value
tv_radar_status tv_selected_app tv_status
tv_vpn_status tv_zoombtn_status""".split()

HEAD = '''<?xml version="1.0" encoding="utf-8"?>
<!--
  Nuvola main screen.

  MAXIMALIST BY DESIGN. This surface never sits over live gameplay, so it can
  afford the gradient header, depth and generous type; the in-game overlay is
  the opposite and stays flat. See docs/NUVOLA_DESIGN.md.

  THE ID CONTRACT. MainActivity, UiBindings and PermissionController bind 59
  ids out of this file with findViewById and CAST them. Every id below keeps
  its original Java-side type:
      cb_*    TextView  - a clickable switch GRAPHIC whose background is
                          swapped by UiBindings.applyToggleState. NOT a
                          CheckBox and not a Switch.
      tv_*    TextView
      seek_*  SeekBar
      btn_shizuku, btn_show_floating   Button
      iv_engine_power                  ImageView
      dot_*, group_*, btn_engine, main_content   plain View / ViewGroup
  Renaming or retyping any of them is a null findViewById and a crash on a
  screen that otherwise looks completely fine.

  btn_show_floating opens the APP PICKER despite its name (MainActivity:126).
  The id is load-bearing; the label is not.
-->
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/nv_ground"
    android:orientation="vertical">

    <ScrollView
        android:id="@+id/nv_scroll"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_weight="1"
        android:fillViewport="true"
        android:scrollbars="none">

    <LinearLayout
        android:id="@+id/main_content"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical">
'''

HERO = '''
        <!-- ==================== HERO ==================== -->
        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical"
            android:background="@drawable/nv_hero"
            android:paddingLeft="@dimen/nv_space_6"
            android:paddingRight="@dimen/nv_space_6"
            android:paddingTop="52dp"
            android:paddingBottom="@dimen/nv_space_6">

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="horizontal"
                android:gravity="center_vertical">

                <ImageView
                    android:layout_width="46dp"
                    android:layout_height="46dp"
                    android:src="@mipmap/ic_launcher_foreground"
                    android:contentDescription="@string/app_name" />

                <LinearLayout
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:layout_marginLeft="@dimen/nv_space_2"
                    android:orientation="vertical">

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:text="@string/app_name"
                        android:textColor="@color/nv_on_brand"
                        android:fontFamily="@font/nv_display"
                        android:textSize="27sp"
                        android:textStyle="bold" />

                    <TextView
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_marginTop="2dp"
                        android:text="@string/creator"
                        android:textColor="@color/nv_on_brand_2"
                        android:textSize="12sp" />
                </LinearLayout>

                <Button
                    android:id="@+id/btn_shizuku"
                    android:layout_width="wrap_content"
                    android:layout_height="@dimen/nv_touch_min"
                    android:minWidth="0dp"
                    android:paddingLeft="@dimen/nv_space_4"
                    android:paddingRight="@dimen/nv_space_4"
                    android:background="@drawable/nv_btn_secondary"
                    android:text="@string/aim"
                    android:textColor="@color/nv_text"
                    android:textSize="12sp"
                    android:textStyle="bold"
                    android:textAllCaps="false" />
            </LinearLayout>

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginTop="@dimen/nv_space_6"
                android:orientation="horizontal"
                android:gravity="center_vertical">

                <View
                    android:id="@+id/dot_engine"
                    android:layout_width="10dp"
                    android:layout_height="10dp"
                    android:background="@drawable/dot_off" />

                <TextView
                    android:id="@+id/tv_status"
                    android:layout_width="0dp"
                    android:layout_height="wrap_content"
                    android:layout_weight="1"
                    android:layout_marginLeft="@dimen/nv_space_2"
                    android:text="@string/engine_status_disconnected"
                    android:textColor="@color/nv_on_brand"
                    android:fontFamily="@font/nv_display"
                    android:textSize="20sp"
                    android:textStyle="bold" />
            </LinearLayout>
        </LinearLayout>
'''

ENGINE = '''
        <!-- ==================== ENGINE ==================== -->
        <LinearLayout
            android:id="@+id/btn_engine"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginLeft="@dimen/nv_space_5"
            android:layout_marginRight="@dimen/nv_space_5"
            android:layout_marginTop="@dimen/nv_space_5"
            android:background="@drawable/nv_card_hero"
            android:clickable="true"
            android:focusable="true"
            android:gravity="center_vertical"
            android:minHeight="76dp"
            android:orientation="horizontal"
            android:padding="@dimen/nv_space_4">

            <ImageView
                android:id="@+id/iv_engine_power"
                android:layout_width="44dp"
                android:layout_height="44dp"
                android:background="@drawable/nv_icon_tile"
                android:padding="@dimen/nv_space_3"
                android:src="@android:drawable/ic_lock_power_off"
                android:contentDescription="@string/activate_engine" />

            <TextView
                android:id="@+id/tv_engine_label"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:layout_marginLeft="@dimen/nv_space_3"
                android:text="@string/activate_engine"
                android:textColor="@color/nv_text"
                android:fontFamily="@font/nv_display"
                android:textSize="16sp"
                android:textStyle="bold" />

            <View
                android:id="@+id/dot_app"
                android:layout_width="10dp"
                android:layout_height="10dp"
                android:background="@drawable/dot_off" />
        </LinearLayout>

        <!-- ==================== TARGET ==================== -->
        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginLeft="@dimen/nv_space_5"
            android:layout_marginRight="@dimen/nv_space_5"
            android:layout_marginTop="@dimen/nv_space_3"
            android:background="@drawable/nv_card"
            android:gravity="center_vertical"
            android:orientation="horizontal"
            android:padding="@dimen/nv_space_4">

            <LinearLayout
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:orientation="vertical">

                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="@string/nv_target"
                    android:textColor="@color/nv_text_3"
                    android:textSize="11sp"
                    android:textStyle="bold" />

                <TextView
                    android:id="@+id/tv_selected_app"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="3dp"
                    android:text="@string/target_awaiting"
                    android:textColor="@color/nv_text"
                    android:textSize="15sp"
                    android:textStyle="bold" />
            </LinearLayout>

            <Button
                android:id="@+id/btn_show_floating"
                android:layout_width="wrap_content"
                android:layout_height="@dimen/nv_touch_min"
                android:minWidth="0dp"
                android:paddingLeft="@dimen/nv_space_4"
                android:paddingRight="@dimen/nv_space_4"
                android:background="@drawable/nv_btn_secondary"
                android:text="@string/nv_change"
                android:textColor="@color/nv_text"
                android:textSize="13sp"
                android:textStyle="bold"
                android:textAllCaps="false" />
        </LinearLayout>
'''

TAIL = '''
        <View
            android:layout_width="match_parent"
            android:layout_height="@dimen/nv_space_8" />

    </LinearLayout>
    </ScrollView>
'''

CARD_CLOSE = "        </LinearLayout>\n"


def section(title):
    return ('\n        <TextView\n'
            '            android:layout_width="wrap_content"\n'
            '            android:layout_height="wrap_content"\n'
            '            android:layout_marginLeft="36dp"\n'
            '            android:layout_marginTop="@dimen/nv_space_6"\n'
            '            android:layout_marginBottom="@dimen/nv_space_2"\n'
            '            android:text="%s"\n'
            '            android:textColor="@color/nv_text_3"\n'
            '            android:textSize="11sp"\n'
            '            android:textStyle="bold"\n'
            '            android:letterSpacing="0.12" />\n' % title)


def card_open(vid=None, hidden=False):
    s = '\n        <LinearLayout\n'
    if vid:
        s += '            android:id="@+id/%s"\n' % vid
    s += ('            android:layout_width="match_parent"\n'
          '            android:layout_height="wrap_content"\n'
          '            android:layout_marginLeft="@dimen/nv_space_5"\n'
          '            android:layout_marginRight="@dimen/nv_space_5"\n')
    if vid:
        s += '            android:layout_marginTop="@dimen/nv_space_3"\n'
    s += ('            android:background="@drawable/nv_card"\n'
          '            android:orientation="vertical"\n'
          '            android:paddingTop="@dimen/nv_space_2"\n'
          '            android:paddingBottom="@dimen/nv_space_2"')
    if hidden:
        s += '\n            android:visibility="gone"'
    s += '>\n'
    return s


def toggle(cb, status, label, desc=None):
    """A toggle row.

    `desc` is a PERMANENT description of what the setting does, not a state
    echo. The sublabel used to be overwritten with "Showing"/"Hidden" on
    every row, which restated the switch and read as nonsense on anything
    non-visual ("Aim assist - Hidden"). UiBindings no longer touches it.
    """
    sub = ''
    if status:
        sub = ('\n                    <TextView\n'
               '                        android:id="@+id/%s"\n'
               '                        android:layout_width="wrap_content"\n'
               '                        android:layout_height="wrap_content"\n'
               '                        android:layout_marginTop="2dp"\n'
               '                        android:text="%s"\n'
               '                        android:textAppearance="@style/TextAppearance.Nv.Label" />'
               % (status, desc if desc else ""))
    return ('\n            <LinearLayout\n'
            '                android:layout_width="match_parent"\n'
            '                android:layout_height="wrap_content"\n'
            '                android:minHeight="56dp"\n'
            '                android:gravity="center_vertical"\n'
            '                android:orientation="horizontal"\n'
            '                android:clickable="true"\n'
            '                android:focusable="true"\n'
            '                android:background="?android:attr/selectableItemBackground"\n'
            '                android:paddingLeft="@dimen/nv_space_4"\n'
            '                android:paddingRight="@dimen/nv_space_4"\n'
            '                android:paddingTop="@dimen/nv_space_2"\n'
            '                android:paddingBottom="@dimen/nv_space_2">\n'
            '\n'
            '                <LinearLayout\n'
            '                    android:layout_width="0dp"\n'
            '                    android:layout_height="wrap_content"\n'
            '                    android:layout_weight="1"\n'
            '                    android:orientation="vertical">\n'
            '\n'
            '                    <TextView\n'
            '                        android:layout_width="wrap_content"\n'
            '                        android:layout_height="wrap_content"\n'
            '                        android:text="%s"\n'
            '                        android:textAppearance="@style/TextAppearance.Nv.Body" />%s\n'
            '                </LinearLayout>\n'
            '\n'
            '                <TextView\n'
            '                    android:id="@+id/%s"\n'
            '                    android:layout_width="52dp"\n'
            '                    android:layout_height="28dp"\n'
            '                    android:layout_marginLeft="@dimen/nv_space_3"\n'
            '                    android:duplicateParentState="true"\n'
            '                    android:background="@drawable/bg_switch_custom_off" />\n'
            '            </LinearLayout>\n' % (label, sub, cb))


def perm(cb, dot, status, label):
    return ('\n            <LinearLayout\n'
            '                android:layout_width="match_parent"\n'
            '                android:layout_height="wrap_content"\n'
            '                android:minHeight="@dimen/nv_touch_min"\n'
            '                android:gravity="center_vertical"\n'
            '                android:orientation="horizontal"\n'
            '                android:paddingLeft="@dimen/nv_space_4"\n'
            '                android:paddingRight="@dimen/nv_space_3"\n'
            '                android:paddingTop="@dimen/nv_space_2"\n'
            '                android:paddingBottom="@dimen/nv_space_2">\n'
            '\n'
            '                <View\n'
            '                    android:id="@+id/%s"\n'
            '                    android:layout_width="8dp"\n'
            '                    android:layout_height="8dp"\n'
            '                    android:background="@drawable/nv_pill_off" />\n'
            '\n'
            '                <LinearLayout\n'
            '                    android:layout_width="0dp"\n'
            '                    android:layout_height="wrap_content"\n'
            '                    android:layout_weight="1"\n'
            '                    android:layout_marginLeft="@dimen/nv_space_3"\n'
            '                    android:orientation="vertical">\n'
            '\n'
            '                    <TextView\n'
            '                        android:layout_width="wrap_content"\n'
            '                        android:layout_height="wrap_content"\n'
            '                        android:text="%s"\n'
            '                        android:textColor="@color/nv_text"\n'
            '                        android:textSize="14sp" />\n'
            '\n'
            '                    <TextView\n'
            '                        android:id="@+id/%s"\n'
            '                        android:layout_width="wrap_content"\n'
            '                        android:layout_height="wrap_content"\n'
            '                        android:layout_marginTop="2dp"\n'
            '                        android:text="@string/checking"\n'
            '                        android:textColor="@color/nv_text_3"\n'
            '                        android:textSize="11sp" />\n'
            '                </LinearLayout>\n'
            '\n'
            '                <TextView\n'
            '                    android:id="@+id/%s"\n'
            '                    android:layout_width="wrap_content"\n'
            '                    android:layout_height="@dimen/nv_touch_min"\n'
            '                    android:minWidth="80dp"\n'
            '                    android:gravity="center"\n'
            '                    android:background="@drawable/nv_btn_secondary"\n'
            '                    android:text="@string/nv_settings"\n'
            '                    android:textColor="@color/nv_text"\n'
            '                    android:textSize="12sp"\n'
            '                    android:textStyle="bold" />\n'
            '            </LinearLayout>\n' % (dot, label, status, cb))


def seek(sid, vid, label, hint, lo='', hi=''):
    return ('\n            <LinearLayout\n'
            '                android:layout_width="match_parent"\n'
            '                android:layout_height="wrap_content"\n'
            '                android:orientation="vertical"\n'
            '                android:paddingLeft="@dimen/nv_space_4"\n'
            '                android:paddingRight="@dimen/nv_space_4"\n'
            '                android:paddingTop="@dimen/nv_space_3"\n'
            '                android:paddingBottom="@dimen/nv_space_2">\n'
            '\n'
            '                <LinearLayout\n'
            '                    android:layout_width="match_parent"\n'
            '                    android:layout_height="wrap_content"\n'
            '                    android:orientation="horizontal">\n'
            '\n'
            '                    <TextView\n'
            '                        android:layout_width="0dp"\n'
            '                        android:layout_height="wrap_content"\n'
            '                        android:layout_weight="1"\n'
            '                        android:text="%s"\n'
            '                        android:textColor="@color/nv_text"\n'
            '                        android:textSize="14sp" />\n'
            '\n'
            '                    <TextView\n'
            '                        android:id="@+id/%s"\n'
            '                        android:layout_width="wrap_content"\n'
            '                        android:layout_height="wrap_content"\n'
            '                        android:text="-"\n'
            '                        android:fontFamily="@font/nv_mono"\n'
            '                        android:textColor="@color/nv_teal"\n'
            '                        android:textSize="12sp" />\n'
            '                </LinearLayout>\n'
            '\n'
            '                <TextView\n'
            '                    android:layout_width="match_parent"\n'
            '                    android:layout_height="wrap_content"\n'
            '                    android:layout_marginTop="2dp"\n'
            '                    android:text="%s"\n'
            '                    android:textColor="@color/nv_text_3"\n'
            '                    android:textSize="11sp" />\n'
            '\n'
            '                <SeekBar\n'
            '                    android:id="@+id/%s"\n'
            '                    android:layout_width="match_parent"\n'
            '                    android:layout_height="@dimen/nv_touch_min"\n'
            '                    android:layout_marginTop="@dimen/nv_space_1"\n'
            '                    android:progressDrawable="@drawable/nv_seek_track"\n'
            '                    android:thumb="@drawable/nv_seek_thumb"\n'
            '                    android:maxHeight="5dp"\n'
            '                    android:minHeight="5dp"\n'
            '                    android:splitTrack="false" />\n'
            '\n'
            '                <LinearLayout\n'
            '                    android:layout_width="match_parent"\n'
            '                    android:layout_height="wrap_content"\n'
            '                    android:orientation="horizontal">\n'
            '\n'
            '                    <TextView\n'
            '                        android:layout_width="0dp"\n'
            '                        android:layout_height="wrap_content"\n'
            '                        android:layout_weight="1"\n'
            '                        android:text="%s"\n'
            '                        android:fontFamily="@font/nv_mono"\n'
            '                        android:textColor="@color/nv_text_4"\n'
            '                        android:textSize="10sp" />\n'
            '\n'
            '                    <TextView\n'
            '                        android:layout_width="wrap_content"\n'
            '                        android:layout_height="wrap_content"\n'
            '                        android:text="%s"\n'
            '                        android:fontFamily="@font/nv_mono"\n'
            '                        android:textColor="@color/nv_text_4"\n'
            '                        android:textSize="10sp" />\n'
            '                </LinearLayout>\n'
            '            </LinearLayout>\n' % (label, vid, hint, sid, lo, hi))



# ===================== PAGES =====================
#
# The bottom bar. Deliberately at the BOTTOM: this is a one-handed tool used
# in the seconds before a match, and the top of a 2340px screen cannot be
# reached without shifting grip. Navigation at the top is navigation that
# needs two hands.

BAR_OPEN = """
    <View
        android:layout_width="match_parent"
        android:layout_height="1dp"
        android:background="@color/nv_line" />

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:background="@color/nv_ground"
        android:orientation="horizontal"
        android:paddingTop="@dimen/nv_space_2"
        android:paddingBottom="@dimen/nv_space_3">
"""

BAR_CLOSE = """    </LinearLayout>
</LinearLayout>
"""

PAGE_CLOSE = "        </LinearLayout>\n"


def tab(tid, ind, label, icon):
    """One bottom-bar tab: a 3dp active bar flush to the TOP edge, then an icon
    over the label. The bar is what names the live tab at a glance; the colour
    change alone was measured at about 3.5:1 once the old inactive alpha was
    applied, which is under the 4.5:1 floor.

    The icon is a drawableTop on the SAME TextView rather than a second view,
    so Pager keeps addressing one view per tab. Pager.paintTab has to tint it:
    a compound drawable does NOT follow setTextColor, so without that every
    icon would stay white and the selected tab would say two different things
    at once."""
    return ('\n        <LinearLayout\n'
            '            android:layout_width="0dp"\n'
            '            android:layout_height="wrap_content"\n'
            '            android:layout_weight="1"\n'
            '            android:orientation="vertical"\n'
            '            android:clickable="true"\n'
            '            android:focusable="true"\n'
            '            android:background="?android:attr/selectableItemBackground">\n'
            '\n'
            '            <View\n'
            '                android:id="@+id/%s"\n'
            '                android:layout_width="24dp"\n'
            '                android:layout_height="3dp"\n'
            '                android:layout_gravity="center_horizontal"\n'
            '                android:background="@color/nv_teal"\n'
            '                android:visibility="invisible" />\n'
            '\n'
            '            <TextView\n'
            '                android:id="@+id/%s"\n'
            '                android:layout_width="match_parent"\n'
            '                android:layout_height="64dp"\n'
            '                android:clickable="true"\n'
            '                android:focusable="true"\n'
            '                android:gravity="center"\n'
            '                android:text="%s"\n'
            '                android:drawableTop="@drawable/%s"\n'
            '                android:drawablePadding="3dp"\n'
            '                android:paddingTop="7dp"\n'
            '                android:paddingBottom="5dp"\n'
            '                android:textColor="@color/nv_text_3"\n'
            '                android:textSize="11sp" />\n'
            '        </LinearLayout>\n' % (ind, tid, label, icon))


# The engine strip, pinned above the tabs on EVERY page.
#
# With tabs, ACTIVATE ENGINE lives only on page 1, so three of four pages had
# no way to start the thing. This puts the primary action at the single most
# reachable point on a 2340px screen, from anywhere in the app - so the
# one-handed pre-match flow is "tap a toggle, tap start".
STRIP = '''
    <View
        android:layout_width="match_parent"
        android:layout_height="1dp"
        android:background="@color/nv_line" />

    <LinearLayout
        android:id="@+id/engine_strip"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:background="@color/nv_surface"
        android:gravity="center_vertical"
        android:orientation="horizontal"
        android:paddingLeft="@dimen/nv_space_5"
        android:paddingRight="@dimen/nv_space_4"
        android:paddingTop="@dimen/nv_space_2"
        android:paddingBottom="@dimen/nv_space_2">

        <View
            android:id="@+id/dot_strip"
            android:layout_width="10dp"
            android:layout_height="10dp"
            android:background="@drawable/dot_off" />

        <TextView
            android:id="@+id/tv_strip_status"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:layout_marginLeft="@dimen/nv_space_3"
            android:text="@string/engine_status_disconnected"
            android:textAppearance="@style/TextAppearance.Nv.Body"
            android:textStyle="bold" />

        <TextView
            android:id="@+id/btn_strip_engine"
            android:layout_width="wrap_content"
            android:layout_height="44dp"
            android:minWidth="96dp"
            android:gravity="center"
            android:background="@drawable/nv_btn_primary"
            android:text="@string/nv_start"
            android:textColor="@color/nv_on_brand"
            android:textSize="13sp"
            android:textStyle="bold" />
    </LinearLayout>
'''


def page_open(pid, visible):
    return ('\n        <LinearLayout\n'
            '            android:id="@+id/%s"\n'
            '            android:layout_width="match_parent"\n'
            '            android:layout_height="wrap_content"\n'
            '            android:orientation="vertical"\n'
            '            android:visibility="%s">\n'
            % (pid, "visible" if visible else "gone"))


def perm_row(cb, dot, status, label):
    """A permission. NOT a toggle: you cannot revoke one by tapping it, and a
    switch that reads OFF looks like a feature you declined rather than
    something blocking you. PermissionController hides the button entirely
    once granted, so a quiet row means nothing is wrong."""
    return ('\n            <LinearLayout\n'
            '                android:layout_width="match_parent"\n'
            '                android:layout_height="wrap_content"\n'
            '                android:minHeight="@dimen/nv_touch_min"\n'
            '                android:gravity="center_vertical"\n'
            '                android:orientation="horizontal"\n'
            '                android:paddingLeft="@dimen/nv_space_4"\n'
            '                android:paddingRight="@dimen/nv_space_4"\n'
            '                android:paddingTop="@dimen/nv_space_3"\n'
            '                android:paddingBottom="@dimen/nv_space_3">\n'
            '\n'
            '                <View\n'
            '                    android:id="@+id/%s"\n'
            '                    android:layout_width="8dp"\n'
            '                    android:layout_height="8dp"\n'
            '                    android:background="@drawable/dot_off" />\n'
            '\n'
            '                <LinearLayout\n'
            '                    android:layout_width="0dp"\n'
            '                    android:layout_height="wrap_content"\n'
            '                    android:layout_weight="1"\n'
            '                    android:layout_marginLeft="@dimen/nv_space_3"\n'
            '                    android:orientation="vertical">\n'
            '\n'
            '                    <TextView\n'
            '                        android:layout_width="wrap_content"\n'
            '                        android:layout_height="wrap_content"\n'
            '                        android:text="%s"\n'
            '                        android:textColor="@color/nv_text"\n'
            '                        android:textSize="15sp" />\n'
            '\n'
            '                    <TextView\n'
            '                        android:id="@+id/%s"\n'
            '                        android:layout_width="wrap_content"\n'
            '                        android:layout_height="wrap_content"\n'
            '                        android:layout_marginTop="3dp"\n'
            '                        android:text="@string/checking"\n'
            '                        android:textColor="@color/nv_text_3"\n'
            '                        android:textSize="12sp" />\n'
            '                </LinearLayout>\n'
            '\n'
            '                <TextView\n'
            '                    android:id="@+id/%s"\n'
            '                    android:layout_width="wrap_content"\n'
            '                    android:layout_height="40dp"\n'
            '                    android:minWidth="88dp"\n'
            '                    android:gravity="center"\n'
            '                    android:background="@drawable/nv_btn_primary"\n'
            '                    android:text="@string/nv_grant"\n'
            '                    android:textColor="@color/nv_on_brand"\n'
            '                    android:textSize="12sp"\n'
            '                    android:textStyle="bold" />\n'
            '            </LinearLayout>\n' % (dot, label, status, cb))

p = [HEAD]

# ---------------- PAGE 1: HOME ----------------
# What you came for. Engine, target, and nothing else that can be scrolled
# past: starting the tunnel used to be the thing you scrolled AWAY from.
p.append(page_open("page_home", True))
p.append(HERO)
p.append(ENGINE)
p.append(section("EFFECT BUTTONS"))
p.append(card_open())
p.append(toggle("cb_float_ghost", "tv_float_ghost_status", "Ghost", "Stop being streamed to other players"))
p.append(toggle("cb_float_freeze", "tv_float_freeze_status", "Freeze", "Hold the world still"))
p.append(toggle("cb_float_tele", "tv_float_tele_status", "Teleport", "Rewrite the position you report"))
p.append(CARD_CLOSE)
p.append(card_open("group_tele_options", hidden=True))
p.append(toggle("cb_auto_stop_tele", "tv_auto_stop_tele_status", "Auto-stop teleport", "End the effect by itself after the replay"))
p.append(seek("seek_tele_replay_delay", "tv_tele_replay_delay_value",
              "Replay delay", "How long withheld packets wait before replay.", "0ms", "2000ms"))
p.append(CARD_CLOSE)
p.append(PAGE_CLOSE)

# ---------------- PAGE 2: OVERLAY ----------------
p.append(page_open("page_overlay", False))
p.append(section("SHOW"))
p.append(card_open())
p.append(toggle("cb_esp", "tv_esp_status", "ESP boxes", "A box, name and health bar on each enemy"))
p.append(toggle("cb_radar", "tv_radar_status", "Radar", "Bearing dial, scales itself to what it can see"))
p.append(toggle("cb_esptune", "tv_esptune_status", "Tune panel", "In-match calibration panel"))
p.append(toggle("cb_espdebug", "tv_espdebug_status", "Debug readout", "Frame counters and DIAG slots"))
p.append(toggle("cb_crosshair", "tv_crosshair_status", "Crosshair", "A fixed crosshair at screen centre"))
p.append(CARD_CLOSE)
p.append(section("CROSSHAIR"))
p.append(card_open())
p.append(seek("seek_crosshair_size", "tv_crosshair_size_value",
              "Size", "Crosshair size, applied live.", "20dp", "96dp"))
p.append(seek("seek_crosshair_alpha", "tv_crosshair_alpha_value",
              "Opacity", "Crosshair opacity, applied live.", "35%", "100%"))
p.append(CARD_CLOSE)
p.append(section("MATCH ID MASK"))
p.append(card_open("group_mask_options", hidden=False))
p.append(seek("seek_mask_bar_thickness", "tv_mask_bar_thickness_value",
              "Text size", "@string/match_mask_thickness_hint", "10sp", "40sp"))
p.append(seek("seek_mask_bar_length", "tv_mask_bar_length_value",
              "Width", "@string/match_mask_length_hint", "80dp", "400dp"))
p.append(CARD_CLOSE)
p.append(PAGE_CLOSE)

# ---------------- PAGE 3: AIM ----------------
p.append(page_open("page_aim", False))
p.append(section("AIM ASSIST"))
p.append(card_open())
p.append(toggle("cb_aim", "tv_aim_status", "Aim assist", "Needs Shizuku"))
p.append(toggle("cb_aimbtn", "tv_aimbtn_status", "Aim button", "A hold-to-aim button in the overlay"))
p.append(toggle("cb_zoombtn", "tv_zoombtn_status", "Zoom button", "A zoom button in the overlay"))
p.append(CARD_CLOSE)
p.append(PAGE_CLOSE)

# ---------------- PAGE 4: SYSTEM ----------------
p.append(page_open("page_system", False))
p.append(section("@string/nv_permissions"))
p.append(card_open())
p.append(perm_row("cb_vpn", "dot_vpn", "tv_vpn_status", "VPN"))
p.append(perm_row("cb_display", "dot_display", "tv_display_status",
                  "Display over other apps"))
p.append(CARD_CLOSE)
p.append(section("FLOATING BUTTONS"))
p.append(card_open())
p.append(seek("seek_float_size", "tv_float_size_value",
              "Button size", "@string/floating_size_hint", "80%", "260%"))
p.append(seek("seek_float_alpha", "tv_float_alpha_value",
              "Button opacity", "@string/floating_alpha_hint", "35%", "100%"))
p.append(CARD_CLOSE)
p.append(section("DEVELOPER"))
p.append(card_open())
p.append(toggle("cb_dev_mode", "tv_dev_mode_status", "Developer mode", "Extra readouts and the packet dumper controls"))
p.append(CARD_CLOSE)
p.append(PAGE_CLOSE)

p.append(TAIL)

# ---------------- BOTTOM BAR ----------------
p.append(STRIP)
p.append(BAR_OPEN)
p.append(tab("tab_home", "ind_home", "Engine", "ic_tab_engine"))
p.append(tab("tab_overlay", "ind_overlay", "Overlay", "ic_tab_overlay"))
p.append(tab("tab_aim", "ind_aim", "Aim", "ic_tab_aim"))
p.append(tab("tab_system", "ind_system", "System", "ic_tab_system"))
p.append(BAR_CLOSE)

xml = "".join(p)
io.open(OUT, 'w', encoding='utf-8').write(xml)

ids = set(re.findall(r'android:id="@\+id/(\w+)"', xml))
missing = sorted(set(NEED) - ids)
dupes = [i for i in set(re.findall(r'android:id="@\+id/(\w+)"', xml))
         if xml.count('@+id/%s"' % i) > 1]
print("written  : %s" % OUT)
print("ids       : %d" % len(ids))
print("MISSING   : %s" % (missing if missing else "none"))
print("DUPLICATE : %s" % (dupes if dupes else "none"))
sys.exit(1 if missing or dupes else 0)
