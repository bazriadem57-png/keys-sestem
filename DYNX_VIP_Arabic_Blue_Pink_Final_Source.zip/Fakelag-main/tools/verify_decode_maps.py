#!/usr/bin/env python3
"""
Parity guard: the server-owned decode maps (server/app/config_blob.py) MUST equal
the baked constants still in the client/native decoders, field-for-field.

Why this exists (docs/CONTINUOUS_AUTH_AND_DECODE_PLAN.md stage C/D): the field-
semantic maps were moved server-side so a cracked offline client that has the
walker code but not the maps decodes garbage. Until every consumer is switched to
READ its map (and the baked constant removed), the two copies coexist — and if
they ever drift (someone tunes a baked constant without updating the server map,
or vice versa) the server-gated path would silently decode wrong the moment
DECODE_LEASH is flipped on. This check makes that drift a build failure instead of
a silent in-game corruption. It is the "measure, don't assume" gate for the swap:
once green, sourcing a consumer from its map is provably behavior-preserving.

Run: python tools/verify_decode_maps.py   (exit 0 = parity holds, 1 = drift)
No third-party deps; parses the Python literals and greps the source constants.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG_BLOB = ROOT / "server" / "app" / "config_blob.py"
ESP = ROOT / "fakelag" / "fakelag-beta" / "app" / "src" / "main" / "java" / "com" / "nuvola" / "app" / "esp" / "EspEngine.java"
PRISYNC = ROOT / "fakelag" / "fakelag-beta" / "app" / "src" / "main" / "java" / "com" / "nuvola" / "app" / "decode" / "body" / "PriSync.java"
CMD = ROOT / "fakelag" / "fakelag-beta" / "app" / "src" / "main" / "java" / "com" / "nuvola" / "app" / "decode" / "body" / "Cmd.java"
ESPTUNING = ROOT / "fakelag" / "fakelag-beta" / "app" / "src" / "main" / "java" / "com" / "nuvola" / "app" / "config" / "EspTuning.java"
MARK = ROOT / "fakelag" / "fakelag-beta" / "app" / "src" / "main" / "java" / "com" / "nuvola" / "app" / "filter" / "MarkFilter.java"
CHAIN_RS = ROOT / "native" / "nuvola-core" / "src" / "chain.rs"

failures: list[str] = []


def _server_maps() -> dict:
    """Exec config_blob.py's literal blocks in isolation (no imports needed)."""
    src = CONFIG_BLOB.read_text(encoding="utf-8")
    ns: dict = {}
    # Pull each `_NAME = { ... }` top-level dict literal and eval it.
    for name in ("_CHAIN_DECODE_PARAMS", "_KEEPALIVE_V_MAP",
                 "_PRI_KEY_LAYOUT", "_MARK148_LAYOUT", "_VEHICLE_LAYOUT",
                 "_DECODE_GATES", "_CALIBRATION"):
        m = re.search(rf"^{name}\s*=\s*(\{{.*?\n\}})", src, re.S | re.M)
        if not m:
            failures.append(f"config_blob.py: {name} literal not found")
            continue
        ns[name] = eval(m.group(1), {"__builtins__": {}})  # noqa: S307 - trusted repo file
    return ns


def _java_int(path: Path, pattern: str) -> int | None:
    m = re.search(pattern, path.read_text(encoding="utf-8"))
    return int(m.group(1)) if m else None


def _java_float(path: Path, pattern: str) -> float | None:
    m = re.search(pattern, path.read_text(encoding="utf-8"))
    return float(m.group(1)) if m else None


def _java_switch_ids(path: Path, method: str) -> list[int] | None:
    """The baked `case N:` id-set inside a `boolean method(int code)` body, as a
    sorted list. Slices from the method signature to the next method so a `case`
    elsewhere in the file can't leak in."""
    src = path.read_text(encoding="utf-8")
    m = re.search(rf"boolean {re.escape(method)}\(int code\)\s*\{{", src)
    if not m:
        return None
    tail = src[m.end():]
    nxt = re.search(r"\n    (?:public|private|static)", tail)
    body = tail[: nxt.start()] if nxt else tail
    return sorted(int(x) for x in re.findall(r"case (\d+):", body))


def check(label: str, server, baked) -> None:
    if server == baked:
        print(f"  ok    {label}: {server}")
    else:
        failures.append(f"{label}: server={server!r} != baked={baked!r}")
        print(f"  DRIFT {label}: server={server!r} baked={baked!r}")


def main() -> int:
    s = _server_maps()
    print("=== chain scalars (config_blob vs EspEngine.java) ===")
    cp = s.get("_CHAIN_DECODE_PARAMS", {})
    check("min_record_x", cp.get("min_record_x"), _java_int(ESP, r"MIN_RECORD_X\s*=\s*(\d+)L"))
    check("max_entity_id", cp.get("max_entity_id"), _java_int(ESP, r"MAX_ENTITY_ID\s*=\s*(\d+)"))
    check("min_record_bytes", cp.get("min_record_bytes"), _java_int(ESP, r"MIN_RECORD_BYTES\s*=\s*(\d+)"))
    check("max_records", cp.get("max_records"), _java_int(ESP, r"MAX_CHAIN_RECORDS\s*=\s*(\d+)"))
    check("max_len", cp.get("max_len"), _java_int(ESP, r"CHAIN_MAX_LEN\s*=\s*(\d+)"))

    print("=== EPRI ids (config_blob vs PriSync.java) ===")
    pri = s.get("_PRI_KEY_LAYOUT", {})
    for key, jconst in (("cur_hp", "EPRI_CUR_HP"), ("max_hp", "EPRI_MAX_HP"),
                        ("vest", "EPRI_VEST"), ("helmet", "EPRI_HELMET"),
                        ("on_hand", "EPRI_ON_HAND"), ("cur_ep", "EPRI_CUR_EP"),
                        ("max_ep", "EPRI_MAX_EP"), ("firing", "EPRI_FIRING"),
                        ("total_dmg", "EPRI_TOTAL_DMG")):
        check(f"pri.{key}", pri.get(key), _java_int(PRISYNC, rf"{jconst}\s*=\s*(\d+)"))

    print("=== keepalive v-map (config_blob vs EspEngine baked defaults) ===")
    # EspEngine.observeKeepalive uses these as the leash-off baked defaults and
    # reads the same indices from the server map when armed. They must match or the
    # armed path would decode the wrong varints. (Baked values are inline literals
    # in the resolver, so this asserts the SERVER map equals the canonical set.)
    ka = s.get("_KEEPALIVE_V_MAP", {})
    check("ka.pos", ka.get("pos"), [0, 1, 2])
    check("ka.phys_state", ka.get("phys_state"), 11)
    check("ka.pose", ka.get("pose"), 12)
    check("ka.cam_dir", ka.get("cam_dir"), [13, 14, 15])
    check("ka.rtt", ka.get("rtt"), 18)
    check("ka.tick", ka.get("tick"), 22)
    check("ka.body_varints", ka.get("body_varints"), 23)

    print("=== decode gates (config_blob vs Cmd.java baked switches) ===")
    gt = s.get("_DECODE_GATES", {})
    check("gates.own_pos_carriers", sorted(gt.get("own_pos_carriers", [])),
          _java_switch_ids(CMD, "isOwnPositionCarrier"))
    check("gates.world_state_stream", sorted(gt.get("world_state_stream", [])),
          _java_switch_ids(CMD, "isWorldStateStream"))
    # mounted = own minus 2001 (isMountedPositionCarrier derives from own); assert
    # the server's explicit mounted set stays consistent with that derivation.
    own = set(gt.get("own_pos_carriers", []))
    check("gates.mounted_carriers", sorted(gt.get("mounted_carriers", [])),
          sorted(own - {2001}))

    print("=== calibration (config_blob vs EspTuning.java DEF_*) ===")
    cal = s.get("_CALIBRATION", {})
    check("cal.fov_x_deg", cal.get("fov_x_deg"),
          _java_float(ESPTUNING, r"DEF_FOV\s*=\s*(-?\d+\.?\d*)f"))
    check("cal.boom_m", cal.get("boom_m"),
          _java_float(ESPTUNING, r"DEF_BOOM\s*=\s*(-?\d+\.?\d*)f"))
    check("cal.shoulder_m", cal.get("shoulder_m"),
          _java_float(ESPTUNING, r"DEF_SHOULDER\s*=\s*(-?\d+\.?\d*)f"))

    print("=== mark148 (config_blob vs MarkFilter.java) ===")
    mk = s.get("_MARK148_LAYOUT", {})
    check("mark.type_notice_enemy", mk.get("type_notice_enemy"),
          _java_int(MARK, r"TYPE_NOTICE_ENEMY\s*=\s*(\d+)"))

    print("=== chain min_record_x also matches the native chain.rs floor ===")
    # chain.rs gates raw x on the profile's min_record_x; its CHAIN_MIN_LEN etc. are
    # framing caps, but the min-x default in the selftest must not drift from 500.
    rs = CHAIN_RS.read_text(encoding="utf-8")
    # (informational) confirm chain.rs still takes min_record_x from the profile.
    if "min_record_x" not in rs:
        failures.append("chain.rs no longer references profile.min_record_x")

    print()
    if failures:
        print(f"FAIL: {len(failures)} drift(s):")
        for f in failures:
            print("  - " + f)
        return 1
    print("PASS: server decode maps match the baked constants (swap is safe).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
