#!/usr/bin/env python3
"""Instance + subset the three bundled Nuvola faces.

WHY
---
res/font held three FULL VARIABLE fonts: 463 KB in a 979 KB debug APK, i.e.
just under half the app, to render about 115 distinct characters of fixed UI
text.

Two separate wins, and they are worth keeping straight:

1. The variable machinery (fvar + gvar) is DEAD WEIGHT HERE.
   Nothing in the app calls setFontVariationSettings, and there is no font
   family XML declaring per-weight files - the layouts reference the raw .ttf
   as @font/nv_body. A resource-loaded .ttf with no <font-family> wrapper is
   loaded at its DEFAULT INSTANCE and `android:textStyle="bold"` is satisfied
   with synthetic bold. So the axes were never reachable. Pinning every axis at
   its own default is therefore byte-for-byte what already rendered, and drops
   gvar entirely. That is where most of the saving comes from.

2. The character coverage was 678 / 378 / 976 codepoints for 115 in use.

THE WEIGHTS ARE A CHOICE NOW, NOT AN ACCIDENT
---------------------------------------------
nv_body's wght axis is (200, default 200, 800) - Manrope's variable default is
its MINIMUM, ExtraLight - so every body string in this app was rendering
ExtraLight, thin on a dark surface, purely because nobody had looked. Checked
on the device 2026-09-16 and pinned deliberately (see WEIGHTS below):

    nv_body     200 -> 500   body text and row titles; the actual fix
    nv_display  400 -> 600   the wordmark and screen titles
    nv_mono     400 -> 400   unchanged; diagnostics read fine

DO NOT drop back to the fvar defaults on a re-run. That is what WEIGHTS is for.

THE ONLY SAFETY RULE
--------------------
A character the app displays AND the original font could render must still
render. Characters the original never had (the app uses a gear, a check and
three triangles that are in none of these faces) already come from the system
fallback chain and are unaffected - do not "fix" them by widening the subset.

The pre-subset originals are in git history; `git log --follow` the .ttf paths.

    python tools/subset_fonts.py            # report only
    python tools/subset_fonts.py --apply    # rewrite res/font/*.ttf
"""
import io, os, re, sys, shutil

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
MAIN = os.path.join(ROOT, 'fakelag', 'fakelag-beta', 'app', 'src', 'main')
FACES = ('nv_body', 'nv_display', 'nv_mono')

# Deliberately WIDER than the 115 characters shipped today: installed-app
# labels are runtime text and reach the same TextViews, so the Latin blocks
# stay whole. Latin Extended Additional covers the Vietnamese already in
# strings.xml.
UNICODES = ("U+0020-007E,U+00A0-00FF,U+0100-017F,U+1EA0-1EF9,"
            "U+2010-2027,U+2030-205E,U+2070,U+207F,U+20A0-20BF,"
            "U+2190-21BB,U+2212,U+25A0-25FF,U+2600-26FF,U+2700-27BF,U+FEFF")

FEATURES = 'calt,ccmp,liga,locl,mark,mkmk,rlig,kern,tnum'

# The wght each face is pinned at, clamped to its own axis range. A face with
# no fvar (i.e. one this script already processed) is left alone, so re-running
# is idempotent rather than destructive.
WEIGHTS = {'nv_body': 500, 'nv_display': 600, 'nv_mono': 400}


def app_characters():
    """Every character the app can put on screen from its own resources."""
    chars = set()
    p = os.path.join(MAIN, 'res', 'values', 'strings.xml')
    t = io.open(p, encoding='utf-8').read()
    for m in re.finditer(r'<string[^>]*>(.*?)</string>', t, re.S):
        chars |= set(m.group(1))
    for m in re.finditer(r'<item>(.*?)</item>', t, re.S):
        chars |= set(m.group(1))
    # The UI builds a great deal of its text in code, not in strings.xml.
    for root, _, fs in os.walk(os.path.join(MAIN, 'java')):
        for f in fs:
            if not f.endswith('.java'):
                continue
            s = io.open(os.path.join(root, f), encoding='utf-8', errors='ignore').read()
            for m in re.finditer(r'"((?:[^"\\n]|\.)*)"', s):
                chars |= set(m.group(1))
    for root, _, fs in os.walk(os.path.join(MAIN, 'res', 'layout')):
        for f in fs:
            s = io.open(os.path.join(root, f), encoding='utf-8', errors='ignore').read()
            for m in re.finditer(r'android:text="([^"]*)"', s):
                chars |= set(m.group(1))
    return {c for c in chars if ord(c) >= 0x20}


def cmap_of(path):
    from fontTools.ttLib import TTFont
    f = TTFont(path, lazy=True)
    s = set()
    for t in f['cmap'].tables:
        if t.isUnicode():
            s |= set(t.cmap.keys())
    f.close()
    return s


def main():
    from fontTools.ttLib import TTFont
    from fontTools.varLib import instancer
    from fontTools import subset

    apply = '--apply' in sys.argv
    need = app_characters()
    text = ''.join(sorted(need))
    tmp = os.environ.get('TEMP') or '/tmp'
    total_before = total_after = 0
    built = []
    failed = False

    for name in FACES:
        src = os.path.join(MAIN, 'res', 'font', name + '.ttf')
        font = TTFont(src)
        if 'fvar' in font:
            axes = {a.axisTag: a.defaultValue for a in font['fvar'].axes}
            want = WEIGHTS.get(name)
            if want is not None and 'wght' in axes:
                ax = [x for x in font['fvar'].axes if x.axisTag == 'wght'][0]
                axes['wght'] = max(ax.minValue, min(ax.maxValue, want))
            sys.stdout.write("%-11s pinning %s\n" % (name, axes))
            instancer.instantiateVariableFont(font, axes, inplace=True,
                                              updateFontNames=False)
        # An already-processed face has no fvar, so a re-run only re-subsets
        # and cannot silently drop the weight back to the axis default.
        inst = os.path.join(tmp, name + '.inst.ttf')
        font.save(inst)
        font.close()

        dst = os.path.join(tmp, name + '.final.ttf')
        subset.main([inst, '--output-file=' + dst, '--unicodes=' + UNICODES,
                     '--text=' + text, '--layout-features=' + FEATURES,
                     '--name-IDs=*', '--drop-tables+=DSIG', '--no-hinting',
                     '--recalc-bounds'])

        orig, sub = cmap_of(src), cmap_of(dst)
        lost = sorted(c for c in need if ord(c) in orig and ord(c) not in sub)
        b, a = os.path.getsize(src), os.path.getsize(dst)
        total_before += b
        total_after += a
        sys.stdout.write("%-11s %7d -> %7d  (-%d%%)  lost=%d\n"
                         % (name, b, a, 100 - a * 100 // b, len(lost)))
        if lost:
            failed = True
            sys.stdout.write("    LOST: %s\n"
                             % ' '.join('U+%04X' % ord(c) for c in lost))
        built.append((dst, src))

    sys.stdout.write("TOTAL %d -> %d bytes (saves %d)\n"
                     % (total_before, total_after, total_before - total_after))
    if failed:
        sys.exit("REFUSING: a character the original could render would be lost")
    if apply:
        for dst, src in built:
            shutil.copyfile(dst, src)
        sys.stdout.write("applied to res/font/\n")
    else:
        sys.stdout.write("(report only; pass --apply to rewrite res/font/)\n")


if __name__ == '__main__':
    main()
