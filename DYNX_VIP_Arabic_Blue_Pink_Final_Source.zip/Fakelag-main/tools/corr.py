import ffpcap as P, pri, collections
def load(path,keyhex,order,m):
    port,pkts=P.match_stream(path); seen=set(); out=[]
    for t,d,b in pkts:
        if b in seen: continue
        seen.add(b)
        r=P.F.decode(b,m,tuple(order),bytes.fromhex(keyhex))
        if r and r['plain'] is not None: out.append((t,d,r))
    return out

def hp_series(ms):
    hp=collections.defaultdict(list)
    for t,d,r in ms:
        if r['Cmd']==1900:
            g,o=pri.parse_pri(r['plain'],True)
            if not o: continue
            for own,recs in g:
                for vid,val,n in recs:
                    if vid==0: hp[own].append((t,val))
    for v in hp.values(): v.sort()
    return hp

def drops(hp):
    out=[]
    for own,v in hp.items():
        for k in range(1,len(v)):
            d=v[k-1][1]-v[k][1]
            if d>0: out.append((v[k][0],own,d))
    return out

def repmap(ms, hp=None):
    """replicationId -> handle via exact 2010 damage matching"""
    if hp is None: hp=hp_series(ms)
    dr=drops(hp)
    ev=[]
    for t,d,r in ms:
        if r['Cmd']==2010:
            vs,_,ok=P.varints(r['plain'])
            if ok and len(vs)==8: ev.append((t,vs))
    pair=collections.defaultdict(collections.Counter)
    for t,own,dd in dr:
        for tt,vs in ev:
            if abs(tt-t)<0.25 and vs[5]==dd: pair[own][vs[0]]+=1
    m={}
    for own,c in pair.items():
        h,n=c.most_common(1)[0]
        if n>=3 and n/sum(c.values())>=0.7: m[own]=h
    return m
