# Decode-leash adversarial test — 2026-09-18

**Question (owner):** *"What if they patch it like before — it's just one line? Does
the server just authenticate once and then end?"*

This is an adversarial test of our **own** server-gated decode leash, run on the
owner's rooted LD emulator + a local `DECODE_LEASH=true` build. Purpose: decide
whether the leash is worth flipping on for release, and what an attacker can still
do after the flip. Defensive only — no third-party target.

## Method
1. Flipped `NativeBridge.DECODE_LEASH=true` locally (uncommitted), built the debug
   APK.
2. Decompiled the built APK with jadx (attacker's-eye view of the shipped bytecode).
3. Traced the two attacker patch points and what each achieves.
4. Reverted the flip; tree + output restored to committed state.

Note: the debug build keeps symbol names, so the decompiler output reads cleanly.
The **release** build is R8 full-mode, so an attacker sees renamed
methods/fields — but the *logic* below is byte-for-byte the same, just obfuscated.

## Findings

### F-L1 — the leash DEFEATS the prior login-bypass crack ✅
The prior crack (`docs/CRACK_ANALYSIS_2026-09-18.md`) flipped
`SessionManager.authorized`/`leaseAuthorized` false→true + a fake `alg:none` JWT.
Under the leash that no longer restores decode:

- The runtime leash is `decodeArmed(now) = decodeValidUntil != 0 && now <
  decodeValidUntil` (`ConfigStore`), and `decodeValidUntil` is set **only** when a
  profile is parsed out of the authenticated AES-GCM `/config` envelope.
- `authorized` is decoupled from `decodeValidUntil`. A flipped login boolean
  produces **no** server profile (the offline/repackaged client never completes
  the X25519+GCM handshake the server gates on a real license), so
  `decodeArmed=false` and every decode path fail-closes.

**Answer to "does the server authenticate once and end?":** no. The profile has a
short `valid_until`, and `/auth/heartbeat` re-arms a rolling monotonic lease every
few minutes (`armRolling`, `elapsedRealtime`-based, rollback-proof, epoch-gated
against replay). A session that stops talking to the server goes dark within one
lease window. Authentication is continuous, not one-shot.

### F-L2 — a one-line patch on `decodeArmed()` still wins, via BAKED FALLBACKS ❌
The attacker simply moves their one-liner from the login gate to the decode gate:
force `decodeArmed()` to `return true`. Decompiled proof from the `true` build:

```java
// ConfigStore.decodeArmed — the one-line target
return decodeValidUntil != 0 && nowSec < decodeValidUntil;   // -> patch to: return true;

// EspEngine.observeKeepalive — what runs once the gate is cleared
boolean kaSrv = ConfigStore.keepaliveMapArmed();      // false (no profile)
int vPosX = kaSrv ? ConfigStore.kaPosX() : 0;         // <- BAKED 0
int vPosZ = kaSrv ? ConfigStore.kaPosZ() : 1;         // <- BAKED 1
int vPosY = kaSrv ? ConfigStore.kaPosY() : 2;         // <- BAKED 2
...                                       : 11,12,13,14,15,18   // all baked, in the shipped bytecode
```

Because every field-gate keeps a **baked fallback** (needed so the current
`DECODE_LEASH=false` release behaves identically), forcing the function-level gate
open resurrects full decode from constants that ship inside the APK. The leash, as
currently staged, raises the attacker's cost from *one line* to *one line* — a
different line.

**Dynamically confirmed on-device (2026-09-18, Frida, rooted emulator, live app,
`DECODE_LEASH=true` test build):**
```
BEFORE: decodeArmed(now)   = false   ← leash holds offline (no license/profile)
BEFORE: calibrationArmed() = false   ← the staged calibration also fail-closes
BEFORE: gatesArmed()       = false
AFTER 1-line runtime patch (CS.decodeArmed.implementation = () => true):
        decodeArmed(now)   = true    ← the gate flips
```
So the leash's *enforcement* is proven live (everything fail-closes with no
license), and the F-L2 weakness is proven live (a one-line runtime hook clears it).
Tooling notes for repro (Git Bash on Windows): `adb push` silently no-ops unless
you set `MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'` AND give the LOCAL path in
Windows form (`C:/...`) with the REMOTE path unix (`/data/local/tmp/fs`) — MSYS was
mangling the remote path, so the push "succeeded" to nowhere. frida 17 externalized
the `Java` bridge, so a raw `create_script` fails with "'Java' is not defined" —
drive it through the `frida-tools` REPL (`python -m frida_tools.repl -U -f
com.nuvola.app -l hook.js`), which bundles the bridge. frida-server must be started
detached (`su -c '/data/local/tmp/fs -D'`).

### F-L3 — the NATIVE chain path resists F-L2 but is only MODERATE against a binary patcher (corrected 2026-09-18, IDA red-team)
`NativeBridge.chainDecode(...)` takes `decodeValidUntil`/`now` and re-checks expiry
**inside the Rust `.so`**, which patching the Java `decodeArmed()` does not touch and
the `.so` is not DEX-patchable. My first draft called this "robust"; an IDA red-team
of `libnuvola_native.so` (arm64) corrects that to **MODERATE — hours, not days**:

- The leash is **two data-boolean checks inside the control-flow-flattened core**
  (Hex-Rays fully fails there): `validUntil == 0` @ `0xB5414`/`CSET` `0xB5418`, and
  `now >= validUntil` @ `0xB54AC`/`CSET` `0xB54B0`. Both `CMP`+`CSET` results become
  the flattened dispatcher's **state selector** (`W23`), so there is **no `B.cond`
  to NOP** — better than trivial.
- **But** it is ordinary OLLVM flattening, **not** the `VM_VIRTUALIZE` that protects
  the TEA Feistel cores. Operands are deterministically traceable from the JNI
  boundary (`now` = JNI arg → X6; `validUntil` = profile+0x28). There is **no native
  clock** in the PLT (no `clock_gettime`/`time`) — the native trusts whatever `now`
  Java passes — and **no `.text` self-check/CRC**. It is a **single choke point**
  (absent + expired fold into the same dispatcher var), no defense in depth.
- Defeat = ~1-instruction data patch at **each** of the two sites (e.g. `CSET
  W10,CS` → `MOV W10,WZR`), plus deducing the post-patch state polarity.

Also: today the native call is on the **shadow-compare** path (`shadowIn/shadowOut`),
not the live decode — the live Java chain decode still uses baked `MAX_ENTITY_ID=64
/ MIN_RECORD_X=500 / MAX_CHAIN_RECORDS=64`. So the native leash only becomes the
enforced path once `NATIVE_DECODE` is promoted (owner/physical).

**Empirical (2026-09-18): the native path cannot be exercised on the x86_64
emulator at all** — only an `arm64-v8a` `libnuvola_native.so` ships (no x86_64
variant), and under houdini translation the lib loads but its RegisterNatives-bound
`chainDecode` is not surfaced (`UnsatisfiedLinkError: No implementation found for
… chainDecode`). Confirmed by driving `chainDecode` via Frida on the emulator with
a synthetic chain rebuilt from `nuvola-core/tests/chain.rs`. So ANY native-path
device test — a fail-closed enforcement call OR a byte-patch — requires the real
arm64 phone. A wait-for-phone harness is armed to run the enforcement test
(`chainDecode` valid vs expired/absent → expect 1 / −1 / −1 / 1) on reconnect.

Ranked native-hardening to push MODERATE → HARD (do these when promoting native):
1. Move the expiry compare into the `VM_VIRTUALIZE` region (same crate-split lever
   as `nuvola-vmp`/TEA) so there is no plain `CMP`/`CSET` to patch.
2. Read a real monotonic clock natively and cross-check, + a `.text` integrity
   self-check over the core bytes, so patching the Java-`now` compare alone loses.
3. Diversify: different success polarities + duplicate the expiry test at N
   data-dependent sites so a 2-instruction patch is insufficient.

Not proven dynamically: "force both CSETs to 0 ⇒ decode succeeds" is *likely* (the
downstream `W23` states weren't emulated). Confirm with a Frida/emulator run of the
core on a valid vs expired profile before relying on any single-patch assumption.

## What this means for the flip
Flipping `DECODE_LEASH=true` **is worth it** — it kills the exact crack that shipped
and makes the client continuously server-dependent. But on its own it does **not**
make a determined attacker's job hard, because of F-L2. The changes that close it,
in priority order (2026-09-18, after an independent leash-survey subagent + the IDA
red-team above):

1. **Encrypt the baked fallback maps at rest, under the rolling heartbeat key**
   (survey finding #2 — the cheapest keyed transform). Ship the fallback field-maps
   as an encrypted asset whose key is the per-session secret already delivered by
   `/auth/heartbeat`; with a live key they decrypt into the existing RAM fields,
   without one they stay ciphertext → null → the consumers fail-closed. This closes
   F-L2's one-liner (no plaintext left to fall back to) and, unlike "delete the
   fallbacks," the *same* APK works in both modes so it is **not hard-coupled to the
   flip**. Ceiling: once decrypted in a live session the maps sit in RAM and can be
   frozen — beats the one-liner, not a determined RE. **This is the recommended
   phase-3.**
2. **Promote native decode to the live path** (`NATIVE_DECODE=true`) so the native
   expiry check in F-L3 is what actually runs — then apply the F-L3 native-hardening
   ranking (VMP the compare, native monotonic clock + `.text` self-check) to take it
   from MODERATE to HARD. Needs the in-game `NATIVE_SHADOW` parity confirmation first
   (owner/physical).
3. **Delete the baked fallbacks outright** (`? server : fail-closed`) — the blunt
   form of #1; makes an offline client non-functional but *breaks* the
   `DECODE_LEASH=false` release, so it must land **coupled with the flip**. #1 is
   strictly preferable unless you also want the code simplification.

### Done since (staged, not flip-dependent)
- **Calibration ported server-side** (survey finding #1, commit `79bbc31`): the
  camera/projection rig (FOV/boom/shoulder) — the ONE decode-knowledge set that is
  NOT wire-rediscoverable, since it came from the *decrypted* il2cpp image — now
  ships in the decode profile, consumed as the `EspTuning` default when armed, baked
  `DEF_*` fallback, parity-guarded. When the owner later swaps the baked side to a
  deliberately-**offset** placeholder (coupled with the flip), an offline client gets
  visibly-wrong ESP out of the box instead of pixel-accurate ESP for free.

## What CANNOT be leashed (confirmed by the survey, with evidence)
The header field-permutation+XOR mask and the 16-byte TEA session key arrive in
**plaintext** over the lobby TCP before the first UDP packet (`LobbyKeySniffer`;
the mask is even independently re-solvable from traffic by `SessionKeySolver` /
`EspEngine.evaluateMask`). The reliable-channel native leash (`bodycrypt.rs`) is a
validity gate only — once armed it decrypts with the wire key — so folding a server
secret into the game's TEA decrypt is impossible (the ciphertext is keyed by
Garena's key). Friend/foe is per-match stateful correlation over wire-derived
inputs; nothing portable. These are hard ceilings, not backlog.

## Reproduce
`NativeBridge.DECODE_LEASH=true` → `assembleDebug` → jadx the APK → read
`ConfigStore.decodeArmed` + `EspEngine.observeKeepalive`. Revert the flag after.
