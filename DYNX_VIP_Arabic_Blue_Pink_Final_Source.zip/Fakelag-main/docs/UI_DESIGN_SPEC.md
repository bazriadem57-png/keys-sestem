# UI Design Specification — Fakelag Beta

**Module:** `fakelag/fakelag-beta/app`
**Direction (decided, not open for debate):** dark gaming / neon accent. Near-black surfaces, one bright accent (cyan), monospace for telemetry, chunky touch targets, legible as an overlay on top of live gameplay.
**Scope:** presentation only. No behaviour, permission, VPN or Shizuku flow changes.

This document is written to be implemented directly. Every hex value, sp size and dp value below is final; there is no "pick one" left in it.

---

## 0. Verified build constraints

Read from `app/build.gradle` — these are facts, not assumptions.

| Constraint | Value | Consequence |
|---|---|---|
| `minSdk` | 21 | No `android:lineHeight`, no `android:textFontWeight`, no `autoSizeTextType`. See §2.3. |
| `compileSdk` / `targetSdk` | 35 / 34 | Fine. |
| `sourceCompatibility` | `VERSION_1_8` | No lambdas in a style helper API that must stay Java 8-safe. Anonymous classes only, matching the existing code. |
| `buildFeatures.viewBinding` | **absent** | **View binding is NOT enabled.** Keep `findViewById`. Do not introduce binding classes. |
| `com.google.android.material` | **absent** | No `MaterialButton`, `MaterialSwitch`, `TextInputLayout`, `TabLayout`, `Theme.Material3.*`, `?attr/colorSurface`. |
| `androidx.appcompat` | **absent** | `MainActivity extends android.app.Activity`. No `AppCompatActivity`, no `AppCompatDelegate`, no `Theme.AppCompat.*`. |
| `androidx.constraintlayout` | **absent** | No `ConstraintLayout`. Layouts must use `LinearLayout` / `FrameLayout` / `ScrollView` / `RelativeLayout`. |
| Declared deps | Shizuku api+provider, hiddenapibypass | That is all. |

### 0.1 Decision: do NOT add Material Components

Adding `com.google.android.material` would drag in `androidx.appcompat`, force `MainActivity` to become an `AppCompatActivity`, re-theme every framework `AlertDialog` (`AppPicker` uses `android.app.AlertDialog`), and re-tint every `SeekBar` and `Button` in a 955-line layout. That is a behavioural and regression risk for a purely cosmetic change, and the design below needs nothing Material provides — the app already hand-draws all its controls (the "switches" are `TextView`s with a layer-list background).

**Specify with plain framework/AndroidX-free widgets.** Framework `Theme.Material` (API 21+) supplies everything the theme needs.

---

## 1. Colour system — `res/values/colors.xml`

Replace all inline hex in layouts and Java with these. Full file, paste as-is.

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>

    <!-- ===== Surfaces ===== -->
    <color name="fl_bg_base">#FF05070A</color>          <!-- window background -->
    <color name="fl_bg_surface">#FF0D1117</color>       <!-- cards, panels -->
    <color name="fl_bg_surface_elevated">#FF161B22</color> <!-- rows inside cards, sheet headers -->
    <color name="fl_bg_surface_high">#FF1F252E</color>  <!-- secondary buttons, pressed rows -->
    <color name="fl_bg_scrim">#F20B0F14</color>         <!-- 95% — overlay panel body -->
    <color name="fl_bg_scrim_hud">#E60B0F14</color>     <!-- 90% — HUD readouts -->

    <!-- ===== Outlines ===== -->
    <color name="fl_outline">#FF2C333D</color>          <!-- hairline dividers ONLY (1.49:1) -->
    <color name="fl_outline_strong">#FF5E6978</color>   <!-- control boundaries (3.40:1) -->
    <color name="fl_outline_focus">#FF22D3EE</color>    <!-- focus / selected ring -->

    <!-- ===== Accent (cyan) ===== -->
    <color name="fl_accent">#FF22D3EE</color>
    <color name="fl_accent_bright">#FF67E8F9</color>    <!-- pressed / active thumb -->
    <color name="fl_accent_dim">#FF0E7490</color>       <!-- filled containers, track-on -->
    <color name="fl_accent_muted">#FF0B3D4C</color>     <!-- low-emphasis fill -->
    <color name="fl_on_accent">#FF03181C</color>        <!-- text/icon on a cyan fill -->

    <!-- ===== Text ===== -->
    <color name="fl_text_primary">#FFE6EDF3</color>
    <color name="fl_text_secondary">#FFA8B3C1</color>
    <color name="fl_text_tertiary">#FF7D8899</color>
    <color name="fl_text_disabled">#FF5A6472</color>

    <!-- ===== Status / semantic ===== -->
    <color name="fl_success">#FF3DDC84</color>
    <color name="fl_success_container">#FF0F3D24</color>
    <color name="fl_warning">#FFFFB020</color>
    <color name="fl_warning_container">#FF4A3208</color>
    <color name="fl_error">#FFFF5C5C</color>
    <color name="fl_error_container">#FF4A1520</color>
    <color name="fl_on_error_container">#FFFFD9DD</color>

    <!-- ===== ESP entity classes ===== -->
    <color name="fl_esp_enemy">#FFFF4D6A</color>
    <color name="fl_esp_team">#FF4DA3FF</color>
    <color name="fl_esp_unknown">#FFFFC83D</color>
    <color name="fl_esp_halo">#CC000000</color>         <!-- mandatory under-stroke, see §7.4 -->

    <!-- ===== Health ===== -->
    <color name="fl_hp_high">#FF3DDC84</color>          <!-- >60% -->
    <color name="fl_hp_mid">#FFFFD43B</color>           <!-- 25–60% -->
    <color name="fl_hp_low">#FFFF5252</color>           <!-- <25% -->
    <color name="fl_hp_track">#B3000000</color>         <!-- bar background -->

    <!-- ===== Overlay button states ===== -->
    <color name="fl_btn_off_fill">#FF1A2029</color>
    <color name="fl_btn_off_stroke">#FF5E6978</color>
    <color name="fl_btn_on_fill">#FF0E7490</color>
    <color name="fl_btn_on_stroke">#FF67E8F9</color>

    <!-- ===== Mono telemetry ===== -->
    <color name="fl_mono_label">#FFA8B3C1</color>
    <color name="fl_mono_value">#FF67E8F9</color>
    <color name="fl_mono_ok">#FF3DDC84</color>
    <color name="fl_mono_warn">#FFFFB020</color>
    <color name="fl_mono_err">#FFFF5C5C</color>

</resources>
```

### 1.1 Contrast ratios — every text-on-surface pair

Computed with the WCAG 2.x relative-luminance formula. **Body text must be ≥ 4.5:1. Large text (≥ 18sp, or ≥ 14sp bold) and non-text boundaries must be ≥ 3.0:1.**

**Text on surfaces**

| Token | on `fl_bg_base` | on `fl_bg_surface` | on `fl_bg_surface_elevated` | on `fl_bg_surface_high` | Verdict |
|---|---|---|---|---|---|
| `fl_text_primary` #E6EDF3 | 17.07 | 16.02 | 14.64 | 13.05 | body OK everywhere |
| `fl_text_secondary` #A8B3C1 | 9.49 | 8.91 | 8.14 | 7.25 | body OK everywhere |
| `fl_text_tertiary` #7D8899 | 5.62 | 5.28 | 4.82 | 4.30 | body OK on base/surface/elevated; **on `surface_high` = 4.30, large-text only** |
| `fl_text_disabled` #5A6472 | 3.36 | 3.15 | 2.88 | 2.57 | **disabled state only** (WCAG exempts inactive controls). Never for readable copy. |

**Accent and semantic colours as text**

| Token | base | surface | elevated | Verdict |
|---|---|---|---|---|
| `fl_accent` #22D3EE | 11.16 | 10.47 | 9.57 | body OK |
| `fl_accent_bright` #67E8F9 | 13.91 | 13.06 | 11.93 | body OK |
| `fl_accent_dim` #0E7490 | 3.76 | 3.53 | 3.23 | **fills and strokes only — never text** |
| `fl_success` #3DDC84 | 11.30 | 10.61 | 9.69 | body OK |
| `fl_warning` #FFB020 | 11.03 | 10.35 | 9.46 | body OK |
| `fl_error` #FF5C5C | 6.66 | 6.25 | 5.71 | body OK |
| `fl_esp_enemy` #FF4D6A | 6.26 | 5.88 | 5.37 | body OK |
| `fl_esp_team` #4DA3FF | 7.68 | 7.21 | 6.59 | body OK |
| `fl_esp_unknown` #FFC83D | 13.04 | 12.24 | 11.19 | body OK |
| `fl_hp_high` #3DDC84 | 11.30 | 10.61 | 9.69 | body OK |
| `fl_hp_mid` #FFD43B | 14.15 | 13.28 | 12.14 | body OK |
| `fl_hp_low` #FF5252 | 6.32 | 5.93 | 5.42 | body OK |

**Text on filled controls**

| Pair | Ratio |
|---|---|
| `fl_on_accent` #03181C on `fl_accent` #22D3EE | 10.09 |
| `fl_on_accent` #03181C on `fl_accent_bright` #67E8F9 | 12.58 |
| `fl_text_primary` #E6EDF3 on `fl_accent_dim` #0E7490 | 4.53 |
| `#061309` on `fl_success` #3DDC84 | 10.65 |
| `fl_text_primary` on `fl_bg_surface_high` #1F252E (secondary button) | 13.05 |
| `fl_on_error_container` #FFD9DD on `fl_error_container` #4A1520 | 11.43 |

**Non-text boundaries (WCAG 1.4.11, ≥ 3.0)**

| Pair | Ratio | Verdict |
|---|---|---|
| `fl_outline` #2C333D on surface | 1.49 | **decorative hairline only** — never the sole boundary of a control |
| `fl_outline_strong` #5E6978 on surface | 3.40 | OK — use for every control boundary |
| `fl_outline_strong` #5E6978 on elevated | 3.10 | OK |
| `fl_outline_focus` #22D3EE on elevated | 9.57 | OK |
| switch track-off #2C333D vs track-on stroke #22D3EE | 7.05 | OK — state is carried by the **stroke**, see §5.3 |
| switch thumb-off #7D8899 on track-off #2C333D | 3.55 | OK |
| switch thumb-on #67E8F9 on track-on #0E7490 | 3.70 | OK |
| overlay button OFF fill vs ON fill | 3.06 | OK (old pair was 2.00, see §1.2) |

### 1.2 Audit of what is there today

Measured against the real backgrounds in the current code. These are the defects the new palette fixes.

| Where | Colour | Background | Ratio | |
|---|---|---|---|---|
| `activity_main.xml:137` `tv_status` OFF | `#6D7286` | card `#111118` | **3.94** | FAIL |
| `activity_main.xml:147` `tv_selected_app` | `#555B71` | card `#111118` | **2.79** | FAIL |
| `EspTunePanel.java:743` section header | `#6C7A96` | panel over bright scene | **3.69** | FAIL |
| `EspOverlay.java:128` debug text | `#9BE8FF` | `argb(150,8,18,30)` over bright scene | **3.46** | **FAIL — worst defect in the app** |
| `OverlayButton` OFF vs ON fill separation | `#851414` / `#0d820d` | — | **2.00** | FAIL (state is nearly indistinguishable) |
| `OverlayButton` OFF stroke on OFF fill | `#de0909` on `#851414` | — | **1.97** | FAIL |
| `OverlayButton` ON stroke on ON fill | `#04db04` on `#0d820d` | — | **2.64** | FAIL |

The debug panel is the headline. `EspOverlay.java:129` sets `tv.setBackgroundColor(Color.argb(150, 8, 18, 30))` — 59 % opacity. Over a dark scene the effective background is `#050B12` and the text reads at 14.47:1; over a bright scene (sky, snow, a muzzle flash) it composites to `#6D737A` and the same text collapses to **3.46:1**. The panel is legible exactly when you do not need it.

**Fix:** `fl_bg_scrim` is `#F20B0F14` — 95 % opaque. Worst case over pure white it composites to `#12161B`, where `fl_text_primary` reads **15.37:1**, `fl_text_secondary` **8.55:1**, and `fl_accent` **10.05:1**. Scene-independent legibility, which is the whole requirement.

| Scrim | Worst-case effective bg (over white) | primary | secondary | accent |
|---|---|---|---|---|
| `fl_bg_scrim` #0B0F14 @ 95 % | `#12161B` | 15.37 | 8.55 | 10.05 |
| `fl_bg_scrim_hud` #0B0F14 @ 90 % | `#23272B` | 12.73 | 7.08 | 8.32 |
| *old* `argb(150,8,18,30)` @ 59 % | `#6D737A` | 4.05 | 2.25 | **2.65** |

---

## 2. Theme — `res/values/themes.xml` (new file)

The project has **no `themes.xml`**. `res/values/styles.xml` (1.1 KB) declares `AppTheme` with `parent="@android:style/Theme.Holo"` — a theme deprecated since API 21, which is why the framework `AlertDialog` in `AppPicker` and every stock `Button` look a decade old.

Create `res/values/themes.xml`. Leave `styles.xml` for widget styles (§5).

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>

    <!-- Base app theme. Framework Material (API 21+), NOT Material Components. -->
    <style name="AppTheme" parent="@android:style/Theme.Material.NoActionBar">

        <!-- Surfaces -->
        <item name="android:colorBackground">@color/fl_bg_base</item>
        <item name="android:windowBackground">@color/fl_bg_base</item>
        <item name="android:colorBackgroundCacheHint">@null</item>

        <!-- Accent -->
        <item name="android:colorPrimary">@color/fl_bg_surface</item>
        <item name="android:colorPrimaryDark">@color/fl_bg_base</item>
        <item name="android:colorAccent">@color/fl_accent</item>
        <item name="android:colorControlNormal">@color/fl_text_tertiary</item>
        <item name="android:colorControlActivated">@color/fl_accent</item>
        <item name="android:colorControlHighlight">#3322D3EE</item>

        <!-- Text -->
        <item name="android:textColorPrimary">@color/fl_text_primary</item>
        <item name="android:textColorSecondary">@color/fl_text_secondary</item>
        <item name="android:textColorTertiary">@color/fl_text_tertiary</item>
        <item name="android:textColorHint">@color/fl_text_disabled</item>
        <item name="android:textColorLink">@color/fl_accent</item>

        <!-- System bars (API 21) -->
        <item name="android:statusBarColor">@color/fl_bg_base</item>
        <item name="android:navigationBarColor">@color/fl_bg_base</item>

        <!-- Dialogs: AppPicker uses android.app.AlertDialog and inherits this. -->
        <item name="android:alertDialogTheme">@style/AppTheme.Dialog</item>

        <!-- Default widget styles -->
        <item name="android:seekBarStyle">@style/Widget.FL.SeekBar</item>
        <item name="android:buttonStyle">@style/Widget.FL.Button.Secondary</item>
    </style>

    <!-- Dark dialog for the app picker. -->
    <style name="AppTheme.Dialog" parent="@android:style/Theme.Material.Dialog.Alert">
        <item name="android:colorAccent">@color/fl_accent</item>
        <item name="android:colorControlActivated">@color/fl_accent</item>
        <item name="android:windowBackground">@drawable/bg_dialog_surface</item>
        <item name="android:textColorPrimary">@color/fl_text_primary</item>
        <item name="android:textColorSecondary">@color/fl_text_secondary</item>
        <item name="android:textColorAlertDialogListItem">@color/fl_text_primary</item>
    </style>

    <!-- Theme applied to the overlay panels built in Java (see §5.6). -->
    <style name="AppTheme.Overlay" parent="AppTheme">
        <item name="android:colorBackground">@android:color/transparent</item>
        <item name="android:windowBackground">@android:color/transparent</item>
    </style>

</resources>
```

`colorControlHighlight` is `#3322D3EE` — 20 % cyan, the ripple tint on every framework control.

**Manifest:** `android:theme="@style/AppTheme"` already points at this name, so no manifest edit is needed. The `AppTheme` block currently in `styles.xml` must be **deleted** when `themes.xml` lands, or the build will fail on a duplicate resource.

`MainActivity.onCreate` has a `try { if (getActionBar() != null) getActionBar().hide(); }` block. With `Theme.Material.NoActionBar` there is no action bar; the block becomes a harmless no-op. Leave it — removing it is a behaviour edit, not a presentation edit.

### 2.1 Required new drawable

```xml
<!-- res/drawable/bg_dialog_surface.xml -->
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <solid android:color="@color/fl_bg_surface_elevated" />
    <corners android:radius="16dp" />
    <stroke android:width="1dp" android:color="@color/fl_outline_strong" />
</shape>
```

### 2.2 What minSdk 21 rules out, and the fallback

| Wanted | Blocked because | Use instead |
|---|---|---|
| `Theme.Material3.*`, `?attr/colorSurface`, `?attr/colorOnSurface` | needs `com.google.android.material` (not a dep) | `@android:style/Theme.Material.NoActionBar` + literal `@color/fl_*` |
| `Theme.AppCompat.*`, `AppCompatActivity` | needs `androidx.appcompat` (not a dep) | framework `Theme.Material` |
| `android:lineHeight` | **API 28** | `android:lineSpacingExtra` (dp) or `android:lineSpacingMultiplier` — both API 1. §3 gives explicit values. |
| `android:textFontWeight` | **API 28** | `android:fontFamily` variants: `sans-serif-light` / `sans-serif` / `sans-serif-medium` / `sans-serif-black` (all API 21) + `android:textStyle="bold"` |
| `android:autoSizeTextType` | **API 26** | fixed sp from the §3 scale; `ellipsize="end"` + `maxLines` |
| `android:foreground` on a non-`FrameLayout` | **API 23** | put the ripple in `android:background`, or wrap in a `FrameLayout` |
| `MaterialSwitch` / `SwitchMaterial` | not a dep | keep the existing `TextView` + layer-list switch pattern, restyled (§5.3) |
| `TabLayout` / `ViewPager2` | not deps | segmented `TextView` tab strip + `View.setVisibility` on sibling `ScrollView`s (§6.1) |
| `ConstraintLayout` | not a dep | `LinearLayout` with `layout_weight` |
| `<ripple>` drawable | API 21 — **available** | use it directly in `res/drawable/` (no `-v21` folder needed; minSdk already is 21) |
| `android:elevation`, `stateListAnimator`, `letterSpacing`, `statusBarColor` | API 21 — **available** | use directly |

---

## 3. Type scale

Telemetry and hex dumps are monospace. Labels are not. Current code uses 9–11 sp almost everywhere (`EspTunePanel` section headers are `setTextSize(9f)`; the `EspOverlay` debug panel is `setTextSize(10f)`); that is the second half of why these panels "look ass". **11 sp is the absolute floor and only for monospace HUD readouts.**

```xml
<!-- res/values/dimens.xml (new) -->
<resources>
    <dimen name="fl_text_display">28sp</dimen>
    <dimen name="fl_text_title_l">20sp</dimen>
    <dimen name="fl_text_title_m">17sp</dimen>
    <dimen name="fl_text_section">13sp</dimen>
    <dimen name="fl_text_body">15sp</dimen>
    <dimen name="fl_text_body_s">14sp</dimen>
    <dimen name="fl_text_caption">12sp</dimen>
    <dimen name="fl_text_overline">11sp</dimen>
    <dimen name="fl_text_mono_l">14sp</dimen>
    <dimen name="fl_text_mono_m">13sp</dimen>
    <dimen name="fl_text_mono_s">11sp</dimen>
</resources>
```

| Role | Size | `fontFamily` | `textStyle` | `letterSpacing` | `lineSpacingExtra` | Caps | Used for |
|---|---|---|---|---|---|---|---|
| Display | 28sp | `sans-serif-black` | `bold` | 0.01 | 2dp | no | app name in header |
| Title L | 20sp | `sans-serif-medium` | normal | 0.00 | 2dp | no | engine state (`tv_status`) |
| Title M | 17sp | `sans-serif-medium` | normal | 0.00 | 2dp | no | card titles |
| Section | 13sp | `sans-serif-medium` | `bold` | 0.10 | 0dp | **yes** | section headers, tab labels |
| Body | 15sp | `sans-serif` | normal | 0.00 | 4dp | no | main-screen row labels |
| Body S | 14sp | `sans-serif-medium` | normal | 0.00 | 3dp | no | overlay-panel row labels |
| Caption | 12sp | `sans-serif` | normal | 0.01 | 2dp | no | helper text, target-app line |
| Overline | 11sp | `sans-serif-medium` | `bold` | 0.14 | 0dp | **yes** | status pill text, "EDITION" tagline |
| Mono L | 14sp | `monospace` | `bold` | 0.00 | 2dp | no | primary telemetry value |
| Mono M | 13sp | `monospace` | normal | 0.00 | 2dp | no | HUD debug lines, tune-panel values |
| Mono S | 11sp | `monospace` | normal | 0.00 | 1dp | no | hex dumps only |

Caps is achieved with `android:textAllCaps="true"` (API 14) — **not** by upper-casing the string, which would break the Vietnamese strings in `strings.xml`.

---

## 4. Spacing, radius, touch targets

4dp grid. Add to `dimens.xml`:

```xml
    <!-- spacing: 4dp grid -->
    <dimen name="fl_space_1">4dp</dimen>
    <dimen name="fl_space_2">8dp</dimen>
    <dimen name="fl_space_3">12dp</dimen>
    <dimen name="fl_space_4">16dp</dimen>
    <dimen name="fl_space_5">20dp</dimen>
    <dimen name="fl_space_6">24dp</dimen>
    <dimen name="fl_space_8">32dp</dimen>
    <dimen name="fl_space_10">40dp</dimen>

    <!-- radius -->
    <dimen name="fl_radius_xs">4dp</dimen>
    <dimen name="fl_radius_sm">8dp</dimen>
    <dimen name="fl_radius_md">12dp</dimen>
    <dimen name="fl_radius_lg">16dp</dimen>
    <dimen name="fl_radius_xl">24dp</dimen>
    <dimen name="fl_radius_pill">999dp</dimen>

    <!-- strokes -->
    <dimen name="fl_stroke_hairline">1dp</dimen>
    <dimen name="fl_stroke_border">1dp</dimen>
    <dimen name="fl_stroke_focus">2dp</dimen>

    <!-- touch targets -->
    <dimen name="fl_touch_min">48dp</dimen>
    <dimen name="fl_touch_row">56dp</dimen>
    <dimen name="fl_touch_overlay">52dp</dimen>
    <dimen name="fl_float_button">72dp</dimen>
    <dimen name="fl_float_button_min">56dp</dimen>
```

### 4.1 Touch-target rules

48dp is a **floor, not a target**. These controls are used mid-match with a thumb, one-handed, while the other hand is on a movement stick.

| Control | Minimum | Spec |
|---|---|---|
| Main-screen list row (whole row is the hit target) | 48dp | **56dp** (`fl_touch_row`) |
| Main-screen primary/secondary button | 48dp | **56dp** height |
| Overlay tune-panel `−` / `+` stepper | 48dp | **52dp × 52dp** (`fl_touch_overlay`) |
| Overlay tune-panel toggle row | 48dp | **52dp** height, full row clickable |
| Floating round button | 48dp | **72dp** at 100 % scale, **hard floor 56dp** at any scale |
| Panel drag handle / header | 48dp | **52dp** height |
| Gap between adjacent overlay hit targets | 8dp | **12dp** (`fl_space_3`) |

**Current violations to fix:**

- `EspTunePanel.java:1224` — `miniButton` is `new LinearLayout.LayoutParams(dp(34), dp(28))`. The `−`/`+` steppers the user taps during a match are **34dp × 28dp**. Both axes fail; the short axis is 58 % of the minimum. Raise to `dp(52) × dp(52)`.
- `OverlayButton.java:88` — `int sizePx = Math.max(72, Math.round(160 * scale));` The numbers are **raw pixels, not dp**. On a 3.0-density phone the 100 %-scale button is 160 px ≈ **53dp**, and the `Math.max(72, …)` floor is 72 px ≈ **24dp** — half the minimum. On a 4.0-density (1440p) device it is 40dp and 18dp. Convert to dp: `int sizePx = dpToPx(Math.max(56, Math.round(72 * scale)));`
- `EspOverlay.java:130` — `tv.setPadding(12, 8, 12, 8)` is also raw pixels: 4dp / 2.7dp on a 3× screen. Use `dp(12), dp(8), dp(12), dp(8)`.

### 4.2 Elevation

No `elevation` on overlay windows (a `TYPE_APPLICATION_OVERLAY` window casts a shadow onto the game, which reads as a smear). Depth on overlays comes from the surface ramp plus a 1dp `fl_outline_strong` border. On the main screen, cards get `android:elevation="2dp"`.

---

## 5. Reusable widget styles — `res/values/styles.xml`

Rewrite `styles.xml`. `AppTheme` moves to `themes.xml`; `ModernSwitch` / `ModernSwitchSmall` are superseded by §5.3.

### 5.1 The XML-only vs Java-usable split — read this first

Overlay panels are built in Java at runtime (`EspTunePanel`, `DevPopup`, `MaskBar`, the `EspOverlay` debug `TextView`), so a style is only useful to them if it can be applied from code. At **minSdk 21 the four-argument view constructor is available**:

```java
new TextView(context, null, 0, R.style.Widget_FL_Mono_Value);
```

This applies the style's view attributes without any theme plumbing. That is the primary mechanism, and it means one `styles.xml` serves both paths.

**The trap:** the four-arg constructor applies *view* attributes only. Every `android:layout_*` attribute in a style is a `LayoutParams` attribute, resolved by the **parent** during inflation, and is **silently ignored** when the view is constructed in Java. So:

| Attribute class | XML | Java (4-arg ctor) |
|---|---|---|
| `textSize`, `textColor`, `fontFamily`, `textStyle`, `letterSpacing`, `textAllCaps`, `gravity`, `padding*`, `background`, `minHeight`, `minWidth`, `maxLines`, `ellipsize`, `lineSpacingExtra`, `alpha`, `elevation` | ✔ | ✔ |
| `layout_width`, `layout_height`, `layout_margin*`, `layout_weight`, `layout_gravity` | ✔ | ✘ — set via `LayoutParams` in code |

Each style below is therefore tagged **[BOTH]** (no `layout_*`; usable from XML and Java) or **[XML-ONLY]** (contains `layout_*`). Every style intended for the overlay panels is **[BOTH]** by construction; sizing for those comes from `StyleKit` (§5.6).

### 5.2 `styles.xml` — full file

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>

    <!-- ==================== TYPE ==================== -->
    <!-- All [BOTH]. -->

    <style name="Text.FL.Display">
        <item name="android:textSize">@dimen/fl_text_display</item>
        <item name="android:fontFamily">sans-serif-black</item>
        <item name="android:textStyle">bold</item>
        <item name="android:letterSpacing">0.01</item>
        <item name="android:lineSpacingExtra">2dp</item>
        <item name="android:textColor">@color/fl_text_primary</item>
        <item name="android:includeFontPadding">false</item>
    </style>

    <style name="Text.FL.TitleL">
        <item name="android:textSize">@dimen/fl_text_title_l</item>
        <item name="android:fontFamily">sans-serif-medium</item>
        <item name="android:lineSpacingExtra">2dp</item>
        <item name="android:textColor">@color/fl_text_primary</item>
    </style>

    <style name="Text.FL.TitleM">
        <item name="android:textSize">@dimen/fl_text_title_m</item>
        <item name="android:fontFamily">sans-serif-medium</item>
        <item name="android:lineSpacingExtra">2dp</item>
        <item name="android:textColor">@color/fl_text_primary</item>
    </style>

    <style name="Text.FL.Section">
        <item name="android:textSize">@dimen/fl_text_section</item>
        <item name="android:fontFamily">sans-serif-medium</item>
        <item name="android:textStyle">bold</item>
        <item name="android:letterSpacing">0.10</item>
        <item name="android:textAllCaps">true</item>
        <item name="android:textColor">@color/fl_accent</item>
    </style>

    <style name="Text.FL.Body">
        <item name="android:textSize">@dimen/fl_text_body</item>
        <item name="android:fontFamily">sans-serif</item>
        <item name="android:lineSpacingExtra">4dp</item>
        <item name="android:textColor">@color/fl_text_primary</item>
    </style>

    <style name="Text.FL.BodyS">
        <item name="android:textSize">@dimen/fl_text_body_s</item>
        <item name="android:fontFamily">sans-serif-medium</item>
        <item name="android:lineSpacingExtra">3dp</item>
        <item name="android:textColor">@color/fl_text_primary</item>
    </style>

    <style name="Text.FL.Caption">
        <item name="android:textSize">@dimen/fl_text_caption</item>
        <item name="android:fontFamily">sans-serif</item>
        <item name="android:letterSpacing">0.01</item>
        <item name="android:lineSpacingExtra">2dp</item>
        <item name="android:textColor">@color/fl_text_secondary</item>
    </style>

    <style name="Text.FL.Overline">
        <item name="android:textSize">@dimen/fl_text_overline</item>
        <item name="android:fontFamily">sans-serif-medium</item>
        <item name="android:textStyle">bold</item>
        <item name="android:letterSpacing">0.14</item>
        <item name="android:textAllCaps">true</item>
        <item name="android:textColor">@color/fl_text_tertiary</item>
    </style>

    <style name="Text.FL.Mono">
        <item name="android:textSize">@dimen/fl_text_mono_m</item>
        <item name="android:fontFamily">monospace</item>
        <item name="android:lineSpacingExtra">2dp</item>
        <item name="android:textColor">@color/fl_mono_label</item>
        <item name="android:includeFontPadding">false</item>
    </style>

    <style name="Text.FL.Mono.Value">
        <item name="android:textSize">@dimen/fl_text_mono_l</item>
        <item name="android:textStyle">bold</item>
        <item name="android:textColor">@color/fl_mono_value</item>
    </style>

    <style name="Text.FL.Mono.Small">
        <item name="android:textSize">@dimen/fl_text_mono_s</item>
        <item name="android:lineSpacingExtra">1dp</item>
    </style>

    <!-- ==================== BUTTONS ==================== -->

    <!-- [BOTH] Primary: filled cyan. -->
    <style name="Widget.FL.Button.Primary" parent="Text.FL.Section">
        <item name="android:background">@drawable/ripple_btn_primary</item>
        <item name="android:textColor">@color/fl_on_accent</item>
        <item name="android:minHeight">@dimen/fl_touch_row</item>
        <item name="android:minWidth">@dimen/fl_touch_min</item>
        <item name="android:gravity">center</item>
        <item name="android:paddingLeft">@dimen/fl_space_5</item>
        <item name="android:paddingRight">@dimen/fl_space_5</item>
        <item name="android:stateListAnimator">@null</item>
    </style>

    <!-- [BOTH] Secondary: outlined. -->
    <style name="Widget.FL.Button.Secondary" parent="Text.FL.Section">
        <item name="android:background">@drawable/ripple_btn_secondary</item>
        <item name="android:textColor">@color/fl_accent</item>
        <item name="android:minHeight">@dimen/fl_touch_row</item>
        <item name="android:minWidth">@dimen/fl_touch_min</item>
        <item name="android:gravity">center</item>
        <item name="android:paddingLeft">@dimen/fl_space_5</item>
        <item name="android:paddingRight">@dimen/fl_space_5</item>
        <item name="android:stateListAnimator">@null</item>
    </style>

    <!-- [BOTH] Destructive / stop. -->
    <style name="Widget.FL.Button.Danger" parent="Widget.FL.Button.Secondary">
        <item name="android:background">@drawable/ripple_btn_danger</item>
        <item name="android:textColor">@color/fl_error</item>
    </style>

    <!-- [BOTH] Square icon/stepper button for the overlay panels. 52x52. -->
    <style name="Widget.FL.Button.Step">
        <item name="android:background">@drawable/ripple_btn_step</item>
        <item name="android:textColor">@color/fl_text_primary</item>
        <item name="android:textSize">18sp</item>
        <item name="android:fontFamily">sans-serif-medium</item>
        <item name="android:textStyle">bold</item>
        <item name="android:gravity">center</item>
        <item name="android:minWidth">@dimen/fl_touch_overlay</item>
        <item name="android:minHeight">@dimen/fl_touch_overlay</item>
        <item name="android:includeFontPadding">false</item>
    </style>

    <!-- ==================== ROWS ==================== -->

    <!-- [BOTH] Container for "label ......... control". -->
    <style name="Widget.FL.Row">
        <item name="android:background">@drawable/ripple_row</item>
        <item name="android:minHeight">@dimen/fl_touch_row</item>
        <item name="android:gravity">center_vertical</item>
        <item name="android:orientation">horizontal</item>
        <item name="android:paddingLeft">@dimen/fl_space_4</item>
        <item name="android:paddingRight">@dimen/fl_space_4</item>
        <item name="android:clickable">true</item>
        <item name="android:focusable">true</item>
    </style>

    <!-- [BOTH] Denser variant for the overlay tune panel. -->
    <style name="Widget.FL.Row.Overlay">
        <item name="android:minHeight">@dimen/fl_touch_overlay</item>
        <item name="android:paddingLeft">@dimen/fl_space_3</item>
        <item name="android:paddingRight">@dimen/fl_space_2</item>
    </style>

    <!-- [XML-ONLY] The label inside a row (needs layout_weight). -->
    <style name="Widget.FL.Row.Label" parent="Text.FL.Body">
        <item name="android:layout_width">0dp</item>
        <item name="android:layout_height">wrap_content</item>
        <item name="android:layout_weight">1</item>
        <item name="android:maxLines">2</item>
        <item name="android:ellipsize">end</item>
    </style>

    <!-- [BOTH] Right-aligned live value in a row. -->
    <style name="Widget.FL.Row.Value" parent="Text.FL.Mono.Value">
        <item name="android:gravity">end|center_vertical</item>
        <item name="android:minWidth">72dp</item>
        <item name="android:maxLines">1</item>
        <item name="android:ellipsize">end</item>
    </style>

    <!-- [XML-ONLY] Slider row: label, SeekBar (weighted), value. -->
    <style name="Widget.FL.SliderRow" parent="Widget.FL.Row">
        <item name="android:minHeight">64dp</item>
        <item name="android:clickable">false</item>
        <item name="android:focusable">false</item>
        <item name="android:background">@null</item>
    </style>

    <!-- [BOTH] -->
    <style name="Widget.FL.SeekBar" parent="@android:style/Widget.Material.SeekBar">
        <item name="android:progressDrawable">@drawable/seekbar_fl_progress</item>
        <item name="android:thumb">@drawable/seekbar_fl_thumb</item>
        <item name="android:minHeight">@dimen/fl_touch_min</item>
        <item name="android:maxHeight">6dp</item>
        <item name="android:paddingLeft">@dimen/fl_space_2</item>
        <item name="android:paddingRight">@dimen/fl_space_2</item>
        <item name="android:splitTrack">false</item>
    </style>

    <!-- ==================== SECTION HEADER ==================== -->

    <!-- [BOTH] -->
    <style name="Widget.FL.SectionHeader" parent="Text.FL.Section">
        <item name="android:paddingLeft">@dimen/fl_space_4</item>
        <item name="android:paddingRight">@dimen/fl_space_4</item>
        <item name="android:paddingTop">@dimen/fl_space_5</item>
        <item name="android:paddingBottom">@dimen/fl_space_2</item>
        <item name="android:minHeight">@dimen/fl_touch_min</item>
        <item name="android:gravity">center_vertical</item>
    </style>

    <!-- [BOTH] Collapsible section header in the overlay panel. -->
    <style name="Widget.FL.SectionHeader.Overlay">
        <item name="android:background">@drawable/ripple_section_overlay</item>
        <item name="android:paddingLeft">@dimen/fl_space_3</item>
        <item name="android:paddingRight">@dimen/fl_space_3</item>
        <item name="android:paddingTop">@dimen/fl_space_2</item>
        <item name="android:paddingBottom">@dimen/fl_space_2</item>
        <item name="android:minHeight">@dimen/fl_touch_overlay</item>
        <item name="android:clickable">true</item>
        <item name="android:focusable">true</item>
    </style>

    <!-- ==================== STATUS PILL ==================== -->

    <!-- [BOTH] Base = neutral/off. -->
    <style name="Widget.FL.Pill" parent="Text.FL.Overline">
        <item name="android:background">@drawable/bg_pill_neutral</item>
        <item name="android:textColor">@color/fl_text_secondary</item>
        <item name="android:gravity">center</item>
        <item name="android:minWidth">56dp</item>
        <item name="android:minHeight">28dp</item>
        <item name="android:paddingLeft">@dimen/fl_space_3</item>
        <item name="android:paddingRight">@dimen/fl_space_3</item>
        <item name="android:includeFontPadding">false</item>
    </style>

    <style name="Widget.FL.Pill.On">
        <item name="android:background">@drawable/bg_pill_on</item>
        <item name="android:textColor">@color/fl_on_accent</item>
    </style>

    <style name="Widget.FL.Pill.Warn">
        <item name="android:background">@drawable/bg_pill_warn</item>
        <item name="android:textColor">@color/fl_warning</item>
    </style>

    <style name="Widget.FL.Pill.Error">
        <item name="android:background">@drawable/bg_pill_error</item>
        <item name="android:textColor">@color/fl_on_error_container</item>
    </style>

    <!-- ==================== TOGGLE (switch) ==================== -->

    <!-- [BOTH] 56x32 track. Replaces ModernSwitch / ModernSwitchSmall. -->
    <style name="Widget.FL.Toggle">
        <item name="android:background">@drawable/bg_toggle_off</item>
        <item name="android:minWidth">56dp</item>
        <item name="android:minHeight">32dp</item>
        <item name="android:padding">0dp</item>
        <item name="android:clickable">true</item>
        <item name="android:focusable">true</item>
        <item name="android:duplicateParentState">true</item>
    </style>

    <!-- ==================== CARDS / PANELS ==================== -->

    <!-- [BOTH] -->
    <style name="Widget.FL.Card">
        <item name="android:background">@drawable/bg_card_surface</item>
        <item name="android:orientation">vertical</item>
        <item name="android:paddingTop">@dimen/fl_space_2</item>
        <item name="android:paddingBottom">@dimen/fl_space_2</item>
        <item name="android:elevation">2dp</item>
    </style>

    <!-- [BOTH] Overlay panel body — 95% scrim, no elevation. -->
    <style name="Widget.FL.Panel">
        <item name="android:background">@drawable/bg_panel_scrim</item>
        <item name="android:orientation">vertical</item>
        <item name="android:elevation">0dp</item>
    </style>

    <!-- [BOTH] Overlay panel drag header. -->
    <style name="Widget.FL.Panel.Header" parent="Text.FL.Section">
        <item name="android:background">@drawable/bg_panel_header</item>
        <item name="android:textColor">@color/fl_accent</item>
        <item name="android:minHeight">@dimen/fl_touch_overlay</item>
        <item name="android:gravity">center_vertical</item>
        <item name="android:paddingLeft">@dimen/fl_space_4</item>
        <item name="android:paddingRight">@dimen/fl_space_4</item>
    </style>

    <!-- [BOTH] HUD readout (ESP debug text). 90% scrim. -->
    <style name="Widget.FL.Hud" parent="Text.FL.Mono">
        <item name="android:background">@drawable/bg_hud_scrim</item>
        <item name="android:textColor">@color/fl_text_primary</item>
        <item name="android:paddingLeft">@dimen/fl_space_3</item>
        <item name="android:paddingRight">@dimen/fl_space_3</item>
        <item name="android:paddingTop">@dimen/fl_space_2</item>
        <item name="android:paddingBottom">@dimen/fl_space_2</item>
        <item name="android:includeFontPadding">false</item>
    </style>

    <!-- [XML-ONLY] Hairline divider. -->
    <style name="Widget.FL.Divider">
        <item name="android:layout_width">match_parent</item>
        <item name="android:layout_height">1dp</item>
        <item name="android:layout_marginLeft">@dimen/fl_space_4</item>
        <item name="android:layout_marginRight">@dimen/fl_space_4</item>
        <item name="android:background">@color/fl_outline</item>
    </style>

    <!-- ==================== TABS ==================== -->

    <!-- [XML-ONLY] One segment of the main-screen tab strip. -->
    <style name="Widget.FL.Tab" parent="Text.FL.Section">
        <item name="android:layout_width">0dp</item>
        <item name="android:layout_height">@dimen/fl_touch_row</item>
        <item name="android:layout_weight">1</item>
        <item name="android:background">@drawable/bg_tab_selector</item>
        <item name="android:textColor">@color/fl_tab_text</item>
        <item name="android:gravity">center</item>
        <item name="android:clickable">true</item>
        <item name="android:focusable">true</item>
    </style>

</resources>
```

### 5.3 Required drawables

All new; place in `res/drawable/` (no `-v21` variant needed — minSdk is already 21).

```xml
<!-- bg_card_surface.xml -->
<shape android:shape="rectangle" xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="@color/fl_bg_surface" />
    <corners android:radius="@dimen/fl_radius_lg" />
    <stroke android:width="1dp" android:color="@color/fl_outline" />
</shape>

<!-- bg_panel_scrim.xml   95% opaque; the overlay panel body -->
<shape android:shape="rectangle" xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="@color/fl_bg_scrim" />
    <corners android:radius="@dimen/fl_radius_md" />
    <stroke android:width="1dp" android:color="@color/fl_outline_strong" />
</shape>

<!-- bg_panel_header.xml -->
<shape android:shape="rectangle" xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="@color/fl_bg_surface_elevated" />
    <corners android:topLeftRadius="@dimen/fl_radius_md"
             android:topRightRadius="@dimen/fl_radius_md" />
</shape>

<!-- bg_hud_scrim.xml   90% opaque; the ESP debug readout -->
<shape android:shape="rectangle" xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="@color/fl_bg_scrim_hud" />
    <corners android:radius="@dimen/fl_radius_sm" />
    <stroke android:width="1dp" android:color="@color/fl_outline_strong" />
</shape>

<!-- bg_btn_primary.xml -->
<shape android:shape="rectangle" xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="@color/fl_accent" />
    <corners android:radius="@dimen/fl_radius_md" />
</shape>

<!-- bg_btn_secondary.xml -->
<shape android:shape="rectangle" xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="@color/fl_bg_surface_high" />
    <corners android:radius="@dimen/fl_radius_md" />
    <stroke android:width="1dp" android:color="@color/fl_outline_strong" />
</shape>

<!-- bg_btn_danger.xml -->
<shape android:shape="rectangle" xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="@color/fl_error_container" />
    <corners android:radius="@dimen/fl_radius_md" />
    <stroke android:width="1dp" android:color="@color/fl_error" />
</shape>

<!-- bg_btn_step.xml -->
<shape android:shape="rectangle" xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="@color/fl_bg_surface_high" />
    <corners android:radius="@dimen/fl_radius_sm" />
    <stroke android:width="1dp" android:color="@color/fl_outline_strong" />
</shape>

<!-- ripple_btn_primary.xml  (same shape for _secondary / _danger / _step / _row) -->
<ripple android:color="#5903181C" xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="@drawable/bg_btn_primary" />
</ripple>

<!-- ripple_row.xml / ripple_section_overlay.xml -->
<ripple android:color="#3322D3EE" xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="@android:color/transparent" />
</ripple>
```

**Toggle (switch) — state carried by the stroke, not the fill.** The measured fill-to-fill contrast is only 2.38:1, which is why the current switch reads as ambiguous; the 2dp stroke supplies 7.05:1 and the thumb position supplies a non-colour cue.

```xml
<!-- bg_toggle_off.xml -->
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item>
        <shape android:shape="rectangle">
            <solid android:color="@color/fl_outline" />
            <corners android:radius="@dimen/fl_radius_pill" />
            <stroke android:width="2dp" android:color="@color/fl_outline_strong" />
        </shape>
    </item>
    <item android:left="5dp" android:right="27dp" android:top="5dp" android:bottom="5dp">
        <shape android:shape="oval"><solid android:color="@color/fl_text_tertiary" /></shape>
    </item>
</layer-list>

<!-- bg_toggle_on.xml -->
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item>
        <shape android:shape="rectangle">
            <solid android:color="@color/fl_accent_dim" />
            <corners android:radius="@dimen/fl_radius_pill" />
            <stroke android:width="2dp" android:color="@color/fl_accent" />
        </shape>
    </item>
    <item android:left="27dp" android:right="5dp" android:top="5dp" android:bottom="5dp">
        <shape android:shape="oval"><solid android:color="@color/fl_accent_bright" /></shape>
    </item>
</layer-list>
```

**Pills**

```xml
<!-- bg_pill_neutral.xml -->
<shape android:shape="rectangle" xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="@color/fl_bg_surface_high" />
    <corners android:radius="@dimen/fl_radius_pill" />
    <stroke android:width="1dp" android:color="@color/fl_outline_strong" />
</shape>
<!-- bg_pill_on.xml      solid @color/fl_accent,           no stroke -->
<!-- bg_pill_warn.xml    solid @color/fl_warning_container, stroke @color/fl_warning -->
<!-- bg_pill_error.xml   solid @color/fl_error_container,   stroke @color/fl_error -->
```

**SeekBar**

```xml
<!-- seekbar_fl_progress.xml -->
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:id="@android:id/background">
        <shape android:shape="rectangle">
            <size android:height="6dp" />
            <corners android:radius="@dimen/fl_radius_pill" />
            <solid android:color="@color/fl_outline" />
        </shape>
    </item>
    <item android:id="@android:id/progress">
        <clip>
            <shape android:shape="rectangle">
                <size android:height="6dp" />
                <corners android:radius="@dimen/fl_radius_pill" />
                <solid android:color="@color/fl_accent" />
            </shape>
        </clip>
    </item>
</layer-list>

<!-- seekbar_fl_thumb.xml -->
<shape android:shape="oval" xmlns:android="http://schemas.android.com/apk/res/android">
    <size android:width="24dp" android:height="24dp" />
    <solid android:color="@color/fl_accent_bright" />
    <stroke android:width="4dp" android:color="@color/fl_bg_base" />
</shape>
```

**Tab selector** — needs `res/color/fl_tab_text.xml`:

```xml
<!-- res/drawable/bg_tab_selector.xml -->
<selector xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:state_selected="true">
        <shape android:shape="rectangle">
            <solid android:color="@color/fl_accent_muted" />
            <corners android:radius="@dimen/fl_radius_sm" />
            <stroke android:width="1dp" android:color="@color/fl_accent" />
        </shape>
    </item>
    <item><shape android:shape="rectangle">
        <solid android:color="@android:color/transparent" />
        <corners android:radius="@dimen/fl_radius_sm" />
    </shape></item>
</selector>

<!-- res/color/fl_tab_text.xml -->
<selector xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:state_selected="true" android:color="@color/fl_accent" />
    <item android:color="@color/fl_text_tertiary" />
</selector>
```

### 5.4 Status dots

`dot_on.xml` / `dot_off.xml` are inconsistent today — `dot_on` is an `oval`, `dot_off` is a `selector` of **rectangles** with a 12dp corner radius. Replace both with ovals of the same size so the indicator does not change shape when it changes state.

```xml
<!-- dot_on.xml -->
<shape android:shape="oval" xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="@color/fl_success" />
    <stroke android:width="3dp" android:color="#333DDC84" />
</shape>
<!-- dot_off.xml -->
<shape android:shape="oval" xmlns:android="http://schemas.android.com/apk/res/android">
    <solid android:color="@color/fl_text_disabled" />
    <stroke android:width="3dp" android:color="#22000000" />
</shape>
```

Dot size everywhere: **10dp** (`dot_engine` is 10dp today; the four permission dots are 7dp — unify at 10dp).

### 5.5 Status-pill semantics

A pill replaces the current bare status `TextView`s (`tv_esp_status`, `tv_vpn_status`, …), which today just say "Đang hiển thị" / "Đang ẩn" in `#778094`.

| State | Style | Text |
|---|---|---|
| Feature on | `Widget.FL.Pill.On` | `ON` |
| Feature off | `Widget.FL.Pill` | `OFF` |
| Permission granted | `Widget.FL.Pill.On` | `R.string.permission_granted` |
| Permission missing | `Widget.FL.Pill.Warn` | `R.string.permission_not_granted` |
| Blocked / error | `Widget.FL.Pill.Error` | short cause |
| Checking | `Widget.FL.Pill` | `R.string.checking` |

### 5.6 `StyleKit` — the Java helper (new file)

Path: `app/src/main/java/com/fakelag/cryhard8/ui/StyleKit.java`

The four-arg constructor covers view attributes. `StyleKit` covers the three things it cannot: dp conversion, `LayoutParams`, and the state-dependent `GradientDrawable`s the overlay code builds at runtime. Java 8, no lambdas, no new dependencies.

```java
package com.fakelag.cryhard8.ui;

public final class StyleKit {

    private StyleKit() {}

    // ---- units ----
    /** dp -> px, rounded, never 0. */
    public static int dp(android.content.Context c, float dp);
    /** sp -> px, for Paint.setTextSize on Canvas renderers. */
    public static float sp(android.content.Context c, float sp);

    // ---- styled view factories (4-arg ctor, API 21) ----
    /** new TextView(ctx, null, 0, styleRes). */
    public static android.widget.TextView text(android.content.Context c, int styleRes);
    public static android.widget.TextView text(android.content.Context c, int styleRes, CharSequence s);
    /** new LinearLayout(ctx, null, 0, styleRes), orientation from the style. */
    public static android.widget.LinearLayout row(android.content.Context c, int styleRes);

    // ---- LayoutParams (styles cannot carry layout_* from Java) ----
    /** MATCH_PARENT x WRAP_CONTENT with an optional top margin in dp. */
    public static android.widget.LinearLayout.LayoutParams lpRow(
            android.content.Context c, int topMarginDp);
    /** 0 x WRAP_CONTENT, weight 1 — the stretching label in a row. */
    public static android.widget.LinearLayout.LayoutParams lpFill();
    /** Fixed square in dp with an optional left margin — stepper buttons. */
    public static android.widget.LinearLayout.LayoutParams lpSquare(
            android.content.Context c, int sizeDp, int leftMarginDp);

    // ---- state drawables the overlay builds at runtime ----
    /** Round floating-button background for the given on/off state. */
    public static android.graphics.drawable.GradientDrawable floatButton(
            android.content.Context c, boolean on);
    /** Rounded panel/pill background: fill + stroke + radius, all in dp. */
    public static android.graphics.drawable.GradientDrawable surface(
            android.content.Context c, int fillColor, int strokeColor,
            int strokeDp, int radiusDp);
    /** Toggle track for the given state (bg_toggle_on / _off). */
    public static android.graphics.drawable.Drawable toggle(
            android.content.Context c, boolean on);

    // ---- semantic colour lookups for Canvas renderers ----
    /** fl_esp_enemy / fl_esp_team / fl_esp_unknown. */
    public static int espColor(android.content.Context c, int entityClass);
    /** fl_hp_high / _mid / _low from a 0..1 fraction (>0.6 / >0.25 / else). */
    public static int hpColor(android.content.Context c, float fraction);
    /** Mandatory ESP halo colour (fl_esp_halo). */
    public static int espHalo(android.content.Context c);
}
```

**Usage — `EspTunePanel.num()` goes from 14 setters to 4 lines:**

```java
// before (EspTunePanel.java:749-766) — a dozen setters per row
final TextView value = new TextView(context);
value.setTextSize(10f);
value.setTypeface(Typeface.MONOSPACE);
value.setTextColor(COL_VALUE);
value.setGravity(Gravity.END);
value.setMinWidth(dp(52));

// after
final TextView value = StyleKit.text(context, R.style.Widget_FL_Row_Value);
```

```java
// before (EspTunePanel.java:1213-1226) — miniButton, 34x28dp
// after
TextView b = StyleKit.text(context, R.style.Widget_FL_Button_Step, glyph);
b.setLayoutParams(StyleKit.lpSquare(context, 52, 8));
```

Note the resource-name mangling: a style named `Widget.FL.Row.Value` in XML is referenced from Java as `R.style.Widget_FL_Row_Value`.

The nine `private static final int COL_*` constants at `EspTunePanel.java:92-100` and the four `FLOAT_BUTTON_*` strings at `OverlayButton.java:23-26` are all deleted and replaced by `colors.xml` lookups through `StyleKit`.

---

## 6. Per-surface layout specs

### 6.1 Main app / VPN service screen

**Files:** `res/layout/activity_main.xml` (955 lines, 37.7 KB), `MainActivity.java`, `app/UiBindings.java`.

#### What it actually contains today

One `ScrollView` → one `LinearLayout` (`@id/main_content`) → nine stacked blocks, top to bottom:

1. **Header** (58dp) — 36dp avatar frame, `"ThuyLinh"` at 22sp `sans-serif-black`, `"Meow EDITION"` at **9sp**.
2. **`btn_show_floating`** (42dp) — `"Chọn Tự Do"`, opens the app picker.
3. **`btn_shizuku`** (42dp) — `"AIM: install Shizuku"`, text is rewritten by `AimInjector.stateLabel()`.
4. **Engine card** — 72dp power circle (`btn_engine` + `iv_engine_power`), `tv_status`, `tv_selected_app`, `dot_engine`, plus a 0×0 `dot_app`.
5. **"NÚT NỔI" card** (`bg_card_gold`) — FREEZE / GHOST / TELE toggle rows at 44dp, each followed by a 0×0 status `TextView`; then four more 0×0 views.
6. **Crosshair card** — `"SIZE & ĐỘ MỜ TÂM ẢO"`, two slider rows, `"HIỂN THỊ TÂM ẢO"` toggle.
7. **Feature toggles** (same card) — ESP BOXES, ESP RADAR, ESP DEBUG PANEL, ESP TUNE PANEL, AIM, AIM BUTTON, SCOPE ZOOM BUTTON. Seven 40dp rows.
8. **"ĐIỀU CHỈNH NÚT NỔI" card** — `Cỡ:` slider, `Mờ:` slider, `group_mask_options` (CHE MÃ TRẬN toggle + thickness + length sliders), then four 0×0 views.
9. **"QUYỀN TRUY CẬP" card** — four rows (VPN / display / notif / storage), each a 7dp dot + label + switch.

67 `android:id` declarations in total.

#### Cut list — verified against every Java reference

**Eleven views are declared `layout_width="0dp" layout_height="0dp"`**, i.e. present in the tree, measured, and invisible. They exist only so `findViewById` does not return null.

| id | Java refs | Action |
|---|---|---|
| `tv_tele_replay_delay_value` | **0** | **Delete.** No Java change needed. |
| `seek_tele_replay_delay` | **0** | **Delete.** No Java change needed. |
| `cb_auto_stop_tele` | **0** | **Delete.** No Java change needed. |
| `tv_auto_stop_tele_status` | **0** | **Delete.** No Java change needed. |
| `tv_float_freeze_status` | 1 (`UiBindings:52`) | **Delete the view.** Replace with a real `Widget.FL.Pill` in the FREEZE row (§5.5) — `setupFloatingToggle` already writes ON/OFF text into it. |
| `tv_float_ghost_status` | 1 (`UiBindings:53`) | same |
| `tv_float_tele_status` | 1 (`UiBindings:54`) | same |
| `group_tele_options` | 1 (`UiBindings:83`) | **Delete.** `setOptionalGroupVisible` is null-safe (`if (group == null) return;`); drop the field. |
| `dot_app` | 1 (`MainActivity:88`) | **Restore as a real 10dp dot** next to `tv_selected_app`. `updateAppSummary` already drives it; it is currently 0×0, so the app-selected indicator has never been visible. |
| `cb_dev_mode` | 1 (`UiBindings:50`) | **Restore as a real row.** See below. |
| `tv_dev_mode_status` | 1 (`UiBindings:51`) | **Restore** as the pill for that row. |

**Two live bugs this audit turned up, both presentation-level:**

- **`cb_dev_mode` is wired but unreachable.** `UiBindings.setupAll()` calls `setupFloatingToggle(cbDevMode, tvDevModeStatus, Prefs.KEY_DEV_MODE)`, but the view is 0×0 and `visibility="gone"`. Dev mode — which gates `DevPopup` — cannot be switched on from the UI at all. Restore it as a real row in the new **DEBUG** section.
- **`cb_mask_bar` is rendered but not wired.** It is a full-size toggle inside `group_mask_options` (`activity_main.xml:739`) with **zero** `R.id.cb_mask_bar` references anywhere in Java. Tapping it does nothing. Compounding this, `UiBindings.updateConditionalGroups` hard-codes `boolean maskEnabled = true;` so the group is always shown. Either wire it to `Prefs.KEY_MASK_BAR` (a behaviour change — out of scope here) or **cut the row and the mask sliders entirely** along with the `MaskBar` overlay (§6.4). Recommendation: cut.

**Also cut:**

- `bg_card_gold` — it differs from `bg_card` only by a warm `#5A3A2A1D` stroke, which contradicts the single-accent direction. Delete the drawable; use `Widget.FL.Card` for every card.
- `"♙"` as a section icon (`activity_main.xml:196`) — a white chess pawn glyph rendered at 20sp in a 42dp circle. Font-dependent and meaningless. Replace with a 24dp vector, or drop the icon frame and rely on the section header.
- The `"Meow EDITION"` 9sp tagline — below the type floor. Either promote to `Text.FL.Overline` (11sp) or cut.

#### Proposed structure — four tabs

A single 955-line scroll is the core problem. Split it into four tabs. With no `TabLayout` available, implement as a segmented strip of four `TextView`s styled `Widget.FL.Tab` over a `FrameLayout` holding four sibling `ScrollView`s toggled with `setVisibility`, and `setSelected(true)` on the active tab (the `bg_tab_selector` and `fl_tab_text` selectors in §5.3 do the rest).

```
ScrollView is REMOVED from the root.

FrameLayout (root, @drawable/bg_main_gradient)
└── LinearLayout vertical, padding 16dp horizontal
    ├── Header  (64dp)
    │     avatar 40dp  |  "ThuyLinh" Text.FL.Display  |  dot_engine 10dp
    │     subtitle Text.FL.Overline
    ├── Engine hero card  (Widget.FL.Card, always visible above the tabs)
    │     ├── btn_engine  96dp power circle   (was 72dp)
    │     ├── tv_status        Text.FL.TitleL
    │     ├── tv_selected_app  Text.FL.Caption  + dot_app 10dp
    │     └── btn_show_floating  Widget.FL.Button.Secondary, 56dp, full width
    ├── Tab strip (56dp) — 4 x Widget.FL.Tab, 4dp gaps
    │     [ ENGINE ] [ VISUAL ] [ AIM ] [ SETUP ]
    └── FrameLayout (weight 1)
          ├── ScrollView @id/tab_engine
          ├── ScrollView @id/tab_visual
          ├── ScrollView @id/tab_aim
          └── ScrollView @id/tab_setup
```

Tab contents:

| Tab | Section headers | Rows (existing ids) |
|---|---|---|
| **ENGINE** | PACKET FILTERS | `cb_float_freeze`, `cb_float_ghost`, `cb_float_tele` |
| **VISUAL** | ESP · CROSSHAIR | `cb_esp`, `cb_radar`, `cb_crosshair`, `seek_crosshair_size`, `seek_crosshair_alpha` |
| **AIM** | AIM · CONTROLS | `cb_aim`, `cb_aimbtn`, `cb_zoombtn`, `btn_shizuku` (moves here — it is an aim prerequisite, not a top-level action) |
| **SETUP** | FLOATING BUTTONS · PERMISSIONS · DEBUG | `seek_float_size`, `seek_float_alpha`; `dot_vpn`+`cb_vpn`, `dot_display`+`cb_display`, `dot_notif`+`cb_notif`, `dot_storage`+`cb_storage`; `cb_espdebug`, `cb_esptune`, `cb_dev_mode` (restored) |

Row anatomy, identical everywhere:

```
LinearLayout style="@style/Widget.FL.Row"        (56dp, whole row clickable)
├── TextView  style="@style/Widget.FL.Row.Label" (weight 1, 15sp)
├── TextView  style="@style/Widget.FL.Pill"      (status, marginEnd 12dp)
└── TextView  style="@style/Widget.FL.Toggle"    (56x32dp)
```

Slider row:

```
LinearLayout style="@style/Widget.FL.SliderRow"  (64dp)
├── TextView  style="@style/Widget.FL.Row.Label"  (weight 1)
└── TextView  style="@style/Widget.FL.Row.Value"  (mono, 72dp min)
LinearLayout (below, full width)
└── SeekBar   style="@style/Widget.FL.SeekBar"    (48dp min height)
```

The label and value sit on one line with the track beneath, so the track spans the full card width instead of the current `48dp label | weighted track | 58dp value` squeeze.

Estimated result: `activity_main.xml` drops from 955 lines to roughly 450–500, with no `findViewById` in `UiBindings` or `MainActivity` needing a signature change — only `group_tele_options` and the three `tv_float_*_status` fields change what they point at.

#### Entrance animation

`UiBindings.animateMainEntrance()` staggers every child of `main_content` by `45ms * i` over 260ms. With tabs the visible child count drops to about 6, so the last item now lands at ~485ms instead of ~1.1s. Keep the animation; it now applies to the active tab's `ScrollView` children.

### 6.2 Floating overlay button

**Files:** `overlay/OverlayButton.java`, `overlay/OverlayAnimations.java`.

**What is there:** `makeBtn` builds an `android.widget.Button`, `setBackground(getButtonStyle(false))` → an oval `GradientDrawable`, fill `#851414` (dark red) / `#0d820d` (dark green), 3**px** stroke `#de0909` / `#04db04`, white text. Six buttons: FREEZE(2), GHOST(3), TELE(4), CAPTURE(8), AIM(9), ZOOM(10), laid out at fixed dp positions `(18,110) (156,110) (18,248) (156,248) (18,386) (156,386)`.

**Defects:**

1. **State is nearly invisible.** OFF fill vs ON fill measures **2.00:1**; each stroke against its own fill is **1.97:1** and **2.64:1**. Over a game scene the red and green ovals read as the same dark blob.
2. **Red/green is the one pair ~8 % of men cannot separate.** Nothing else distinguishes the states.
3. **The size floor is in pixels.** `Math.max(72, Math.round(160 * scale))` — 72 px is 24dp at density 3, 18dp at density 4.
4. **The custom font never loads.** `FloatingOverlayService.java:107` does `Typeface.createFromAsset(getAssets(), "fonts/chudep.ttf")`, and **`assets/fonts/chudep.ttf` is 0 bytes.** Every button silently falls through to the `catch` and uses `Typeface.DEFAULT_BOLD`. Delete the asset and the load, and pass `null` (`OverlayButton` already handles null with `font != null ? font : Typeface.DEFAULT_BOLD`).
5. **`BtnTouchListener` (`OverlayButton.java:290-372`) is dead code** — declared, never instantiated. Only `SrcVipButtonTouchListener` is used. 83 lines. Delete. Note that the long-press-to-lock behaviour and the `pos_locked` / `pos_unlocked` strings live only in that dead class, so that feature is already gone; do not "restore" it as part of a visual pass.

**Spec:**

| Property | Value |
|---|---|
| Shape | circle |
| Diameter | `dp(72)` at 100 % scale; `dp(round(72 * scale))` clamped to **min `dp(56)`**, max `dp(104)` |
| Fill OFF | `fl_btn_off_fill` #1A2029 |
| Stroke OFF | `fl_btn_off_stroke` #5E6978, **`dp(2)`** |
| Label OFF | `fl_text_secondary` #A8B3C1 — 7.71:1 on the fill |
| Fill ON | `fl_btn_on_fill` #0E7490 |
| Stroke ON | `fl_btn_on_stroke` #67E8F9, **`dp(3)`** |
| Label ON | `fl_text_primary` #E6EDF3 — 4.53:1 on the fill |
| Fill-to-fill separation | **3.06:1** (was 2.00) |
| Stroke-to-stroke separation | **3.85:1** |
| Label | `Text.FL.Overline` — 11sp, `sans-serif-medium` bold, caps, `letterSpacing 0.14`; max 2 lines |
| Text halo | `setShadowLayer(dp(3), 0, dp(1), 0xCC000000)` — mandatory, so the label survives a bright scene |
| Idle alpha | `floatAlphaPercent / 100f`, default 0.85 |
| Press feedback | keep the existing `scaleX/Y 0.94` over 40ms (`OverlayButton.java:232`) |

**Second, non-colour state cue (required, because colour alone fails for colour-blind users):** stroke width changes 2dp → 3dp, and the ON state adds an inner ring — draw with `GradientDrawable.setStroke` plus an inset second ring in a `LayerDrawable`. Do **not** use the label text to carry state; the labels are feature names.

**Layout:** keep the existing spawn positions but enforce a 12dp minimum gap after scaling — at 140 % the 72dp buttons become ~100dp and the current 138dp pitch leaves only 38dp, which is fine, but the 18dp left inset must grow to `max(18dp, 12dp)` from the screen edge.

**`OverlayAnimations` — cut the top banner.** `makeTopBanner` adds a seventh always-on overlay window reading `"Meow Cheater"` at 14sp in `#68FFF2` with an 18px cyan glow, animated between two cyan-greens on a 2.6 s loop forever. It conveys nothing, occupies the top-centre of the screen where game HUD lives, and burns a `ValueAnimator` continuously. Delete `makeTopBanner`, `startBannerAnimation`, and the `topBanner`/`bannerAnimator` fields. Keep `AnimatedCircleDrawable` and the ring rainbow/pulse animators only if they are actually attached to the floating buttons; if `ringDrawables` is empty in practice, both animators early-return and the whole class can go.

### 6.3 ESP tune panel

**File:** `overlay/EspTunePanel.java` — 1298 lines, entirely Java, no XML.

**What is there:** a collapsible panel; header `"⚙ ESP TUNE ▼"` / `"⚙ ESP"` at 11sp; body is a `ScrollView` fixed at **`dp(268) × dp(330)`** holding, across 8 sections, **83 rows**: 39 `num` (label + mono value + `−`/`+`), 31 `bool`, 5 `info`, 3 `action`, 2 `stepRow`, plus `zoomRow`, `viewModeRow`, `resetRow`.

Sections, in order: `PROJECTION`, `3RD-PERSON CAMERA`, `PREDICTION (lag)`, `AIM`, `HANDEDNESS (discrete)`, `DISPLAY`, `TELEPORT`, `AIM / HIT REWRITE (Cmd 106)`.

**Defects:**

1. **83 rows in a 330dp window.** At the current ~28dp row height that is a 2300dp scroll inside a 330dp viewport — a 7-screen scroll with no landmarks and no way to collapse a section.
2. **`−`/`+` are 34×28dp** (`miniButton`, line 1224) — the primary interaction, used mid-match, at 58 % of the minimum on the short axis.
3. **Everything is 9–10sp.** Labels 10sp, values 10sp, section headers 9sp, hint 9sp.
4. **Section headers measure 3.69:1 over a bright scene** (`#6C7A96`) — below the 4.5 floor.
5. Every row is built with ten-plus individual setters; there is no style to change.

**Spec:**

*Window*

| Property | Value |
|---|---|
| Width | `dp(340)` collapsed and expanded (was 268) |
| Expanded body height | `min(dp(480), 0.60 × display height)` — replaces the fixed `dp(330)` |
| Background | `Widget.FL.Panel` → `bg_panel_scrim` (95 %, radius 12dp, 1dp `fl_outline_strong`) |
| Header | `Widget.FL.Panel.Header`, **52dp**, drag handle, `Text.FL.Section` in `fl_accent` |
| Header collapsed text | `ESP TUNE` + a `Widget.FL.Pill` showing the active section count |
| Flags | unchanged — `FLAG_NOT_FOCUSABLE \| FLAG_NOT_TOUCH_MODAL \| FLAG_LAYOUT_IN_SCREEN \| FLAG_SPLIT_TOUCH` |

*Structure — collapsible accordion, one section open at a time*

```
LinearLayout  Widget.FL.Panel
├── TextView  Widget.FL.Panel.Header          52dp, drag
├── TextView  Widget.FL.Hud                   live hint, mono 13sp  (was 9sp)
└── ScrollView                                height = min(480dp, 0.6*screen)
    └── LinearLayout vertical
        ├── TextView Widget.FL.SectionHeader.Overlay  "PROJECTION"  ▸/▾  52dp
        ├── LinearLayout (section body, visibility toggled)
        │     └── rows…
        ├── TextView Widget.FL.SectionHeader.Overlay  "3RD-PERSON CAMERA"
        └── …
```

Only the open section's body is `VISIBLE`; the others are `GONE`. With 8 headers at 52dp, the collapsed panel is ~416dp of headers — it fits, and the user reaches any knob in two taps instead of a seven-screen scroll.

*Row anatomy*

```
num  →  Widget.FL.Row.Overlay (52dp)
        ├─ label  Text.FL.BodyS          weight 1        14sp
        ├─ value  Widget.FL.Row.Value    minWidth 72dp   mono 14sp, fl_mono_value
        ├─ "−"    Widget.FL.Button.Step  52x52dp
        └─ "+"    Widget.FL.Button.Step  52x52dp
```

Panel width check: 12 + label + 72 + 52 + 8 + 52 + 8 = the label gets ~136dp at 340dp width, enough for `"AIM SWIPE PX/DEG"` at 14sp on two lines. Set `maxLines=2`, `ellipsize=end`.

```
bool →  Widget.FL.Row.Overlay (52dp, whole row clickable — keep the existing behaviour)
        ├─ label  Text.FL.BodyS   weight 1
        └─ pill   Widget.FL.Pill / Widget.FL.Pill.On   "ON" / "OFF"
```

Replaces the current `state` `TextView` with `card(COL_BTN_ON)` / `card(COL_BTN_OFF)` backgrounds, whose fills measure 2.38:1 apart.

```
info →  Widget.FL.Row.Overlay (min 52dp, wrap for long text)
        ├─ label  Text.FL.BodyS  weight 1
        └─ value  Text.FL.Mono   fl_mono_label, maxLines 3
```

Colour the `info` value by state where the provider can say so: `fl_mono_ok` / `fl_mono_warn` / `fl_mono_err`. This is the row that exists because "armed but not injecting" had no way to show itself — give it the colour to say which it is.

```
action → Widget.FL.Row.Overlay
         ├─ label  Text.FL.BodyS  weight 1
         └─ btn    Widget.FL.Button.Secondary, minHeight 48dp, minWidth 88dp
```

*Section headers* use `Widget.FL.SectionHeader.Overlay` — 13sp, `fl_accent` (10.05:1 over a bright scene, vs 3.69:1 today), with a `▸`/`▾` chevron on the right at 13sp.

*Keep unchanged:* the hold-to-repeat stepper logic (`REPEAT_DELAY_MS 340`, `REPEAT_PERIOD_MS 70`, `ACCEL_AFTER 12`), the `refreshers` list, the 250 ms hint ticker, and `DragTapListener`. The press-feedback `v.setAlpha(0.6f)` on `ACTION_DOWN` stays.

### 6.4 Debug panels

Three separate surfaces.

#### (a) ESP debug readout — `EspOverlay.java:124-142`

**What is there:** a `TextView`, `textSize 10f`, `Typeface.MONOSPACE`, `alpha 0.92`, `setPadding(12, 8, 12, 8)` (**raw px**), text `#FF9BE8FF`, background `Color.argb(150, 8, 18, 30)`. It renders 11+ labelled lines (`KEY`, `TGT`, `PARSE`, `SRV`, `GHOST`, `TELE`, `FRZ`, `AIM`, `INJ`, `HP`, `VIS`) plus `stateText()` and `renderView.statusLine()`, repainted every 500 ms.

**This is the single worst-measuring surface in the app: 3.46:1 over a bright scene.**

**Spec:**

| Property | Now | New |
|---|---|---|
| Background | `argb(150, 8, 18, 30)` = 59 % | `bg_hud_scrim` = **`fl_bg_scrim_hud` 90 %** |
| View alpha | `0.92` | **`1.0`** — the scrim already carries the transparency; stacking view alpha on a translucent background is what produced the 59 %×92 % ≈ 54 % effective opacity |
| Text size | `10f` | **13sp** (`fl_text_mono_m`) |
| Padding | `12, 8, 12, 8` **px** | `dp(12), dp(8), dp(12), dp(8)` |
| Label colour | `#9BE8FF` for everything | label prefix `fl_mono_label`, value `fl_mono_value` |
| Position | `x=8, y=120` px | `dp(8), dp(96)` |
| Corner | none | `fl_radius_sm` 8dp |
| Max width | none | `0.55 × display width`, `ellipsize=end` per line |

**Line colouring.** `buildDebugText` already emits a fixed 6-character label column (`"KEY   "`, `"PARSE "`, `"GHOST "`). Build a `SpannableStringBuilder` instead of a `String`: label column in `fl_mono_label`, value in `fl_mono_value`, and any line whose value starts with `waiting`, `not learned`, `no tunnel`, `engine off` in `fl_mono_warn`. This is a presentation change to the same text — no new data, no behaviour change.

**Window flags are load-bearing — do not touch.** See §7.2.

#### (b) DevPopup — `overlay/DevPopup.java`

**What is there:** a 112dp square, text `"DEV\nLOG"` at 13sp bold, `#FF071007` on a solid `#FF5DFF84` (bright mint) background, alpha 0.92, draggable.

Its own contrast is fine (14.82:1), but it is a **112dp solid neon-green block permanently over the game** that says two words and shows no log. It is a button that looks like a panel.

**Spec:** convert to a collapsed HUD chip that expands into a readout.

| State | Spec |
|---|---|
| Collapsed | 52dp pill, `Widget.FL.Pill`, label `"DEV"` in `Text.FL.Overline`, `fl_accent` text on `bg_pill_neutral` |
| Expanded | `Widget.FL.Panel`, width `dp(300)`, height `min(dp(360), 0.45 × screen)`, a `ScrollView` of `Text.FL.Mono.Small` (11sp) lines from `DevLoggerImpl`, newest last, auto-scrolled to bottom |
| Header | `Widget.FL.Panel.Header` 52dp, drag handle + a `▾` collapse chevron |
| Background | `bg_panel_scrim` 95 % |
| Tap | toggles collapsed/expanded (mirror `EspTunePanel.setExpanded`) |
| Drag | keep `OverlayTouchListener.MaskBarTouchListener` unchanged |

If wiring `DevLoggerImpl` into the expanded view counts as behaviour, ship the collapsed pill only and leave it as a 52dp chip — that alone removes a 112dp neon block from the play area.

#### (c) MaskBar — `overlay/MaskBar.java`

**What is there:** a bottom-left `TextView` reading the hard-coded `"Yeu ThuyLinh VCL"`, white rounded-rect background, with a `ValueAnimator` running a 13-stop full-saturation HSV rainbow `LinearGradient` across the text, forever, at 2.8 s per cycle, rebuilding the shader and calling `invalidate()` on **every animation frame**.

This is a watermark, not a debug panel. It contradicts the stated direction in every respect: a white background is the one surface that cannot be legible over both bright and dark scenes, and a rotating full-spectrum rainbow is the opposite of a single accent.

**Recommendation: cut it.** Delete `MaskBar.java`, the `cb_mask_bar` / `tv_mask_bar_status` rows, `seek_mask_bar_thickness`, `seek_mask_bar_length`, `group_mask_options`, `R.string.match_mask*`, `Prefs.KEY_MASK_BAR*`, and `AppearanceBroadcaster.MASK_BAR_*`. Note `cb_mask_bar` has **zero** Java references already — the toggle does nothing today.

**If it must stay** (it is the user's own branding), restyle to:

| Property | Value |
|---|---|
| Background | `bg_hud_scrim` (90 % `#0B0F14`), radius `fl_radius_sm` |
| Text | `Text.FL.Overline` 11sp caps, **static `fl_accent`** — no shader, no animator |
| Shadow | `setShadowLayer(dp(3), 0, dp(1), 0xCC000000)` |
| Padding | `dp(12), dp(6), dp(12), dp(6)` |
| Animator | **deleted** — `startMaskTextAnimation` / `stopMaskTextAnimation` removed; it allocates two arrays and a `LinearGradient` per frame for a decorative effect |

---

## 7. Overlay-specific constraints

All overlay windows are `TYPE_APPLICATION_OVERLAY` (`TYPE_PHONE` below API 26) drawn over a live game.

### 7.1 Opacity and scrim

| Surface | Background | Opacity | Worst-case text contrast (over white) |
|---|---|---|---|
| Panel body (`EspTunePanel`, `DevPopup` expanded) | `fl_bg_scrim` #0B0F14 | **95 %** | primary 15.37, secondary 8.55, accent 10.05 |
| HUD readout (`EspOverlay` debug, `MaskBar` if kept) | `fl_bg_scrim_hud` #0B0F14 | **90 %** | primary 12.73, secondary 7.08, accent 8.32 |
| Floating button | opaque `GradientDrawable` + view alpha 0.85 | — | label carries its own shadow halo |
| ESP render window | **fully transparent** | 0 % | n/a — strokes carry halos (§7.4) |

**Rule: never stack view alpha on a translucent background.** The current debug panel does exactly this (`setAlpha(0.92f)` on an `argb(150,…)` background) and lands at ~54 % effective opacity. Put the transparency in the colour or in the view alpha, never both. Panels use the colour; floating buttons use the view alpha (they have an opaque fill).

### 7.2 What must never steal touch input

| Window | Flags today | Change |
|---|---|---|
| **ESP render** (`EspOverlay:99-109`) | `FLAG_NOT_FOCUSABLE \| FLAG_NOT_TOUCHABLE \| FLAG_LAYOUT_IN_SCREEN \| FLAG_LAYOUT_NO_LIMITS` + cutout mode | **NONE. Do not touch. See §7.3.** |
| **ESP debug readout** (`EspOverlay:132-138`) | `FLAG_NOT_FOCUSABLE \| FLAG_NOT_TOUCHABLE \| FLAG_LAYOUT_IN_SCREEN` | **Keep `FLAG_NOT_TOUCHABLE`.** It is a readout; it must never intercept a shot. If the redesign makes it tappable, that is a behaviour change — out of scope. |
| **Tune panel** (`EspTunePanel:179-183`) | `FLAG_NOT_FOCUSABLE \| FLAG_NOT_TOUCH_MODAL \| FLAG_LAYOUT_IN_SCREEN \| FLAG_SPLIT_TOUCH` | Keep exactly. Touchable but not modal, so taps outside still reach the game. |
| **Floating buttons** (`OverlayButton:103-107`) | `FLAG_NOT_FOCUSABLE \| FLAG_NOT_TOUCH_MODAL \| FLAG_WATCH_OUTSIDE_TOUCH \| FLAG_SPLIT_TOUCH` | Keep exactly. `FLAG_SPLIT_TOUCH` is what lets the user hold a movement stick and tap a button at once. |
| **MaskBar / DevPopup** | same as floating buttons | Keep. |

**Never add `FLAG_DIM_BEHIND` to any of these windows.** Dimming the game to make a panel readable is the wrong trade in a match, and it changes what the player sees. The 95 % scrim gives full legibility with zero effect outside the panel's own bounds. **No overlay panel dims the game.**

**Never add `FLAG_NOT_TOUCH_MODAL`'s opposite** (i.e. never remove it) on a touchable window — without it the panel swallows every touch on the screen.

### 7.3 The ESP render window — hard constraint, do not regress

`EspOverlay.java:85-113` carries a comment that is the record of a real debugging cycle. Reproducing the operative part:

> `FLAG_LAYOUT_IN_SCREEN` alone is not enough: without `FLAG_LAYOUT_NO_LIMITS` and an explicit cutout mode, Android keeps an overlay clear of the display cutout and the nav bar. The game runs immersive and renders into both, so our window came out smaller than its viewport and offset inside it — and because the projection was built from our own `getWidth()/getHeight()`, that inset behaved exactly like a wrong FOV: no error at the crosshair, growing error with angle from it.

**Any design change to this window MUST preserve, verbatim:**

```java
WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT
FLAG_NOT_FOCUSABLE | FLAG_NOT_TOUCHABLE | FLAG_LAYOUT_IN_SCREEN | FLAG_LAYOUT_NO_LIMITS
rp.gravity = Gravity.TOP | Gravity.START;  rp.x = 0;  rp.y = 0;
// API >= 30: LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
// API 28-29: LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
```

Specifically **forbidden** on this window, because each silently reintroduces the inset that mimics an FOV error:

- any padding, margin, or inset on the window or on `EspRenderView`
- `fitsSystemWindows="true"`
- any `WindowInsets` consumption or `setOnApplyWindowInsetsListener`
- dropping `FLAG_LAYOUT_NO_LIMITS`
- dropping or weakening `layoutInDisplayCutoutMode`
- a non-zero `rp.x` / `rp.y` or a gravity other than `TOP|START`
- wrapping `EspRenderView` in any parent `ViewGroup`

This window has **no background and no styling**. Everything it shows is drawn on `Canvas` inside `EspRenderView`; it takes its colours from `colors.xml` via `StyleKit.espColor` / `StyleKit.hpColor`, never from a theme attribute.

### 7.4 Staying legible over both bright and dark scenes

A game frame can be any colour. Luminance contrast against "the scene" is therefore undefined, and the measured numbers prove the problem: `fl_esp_unknown` #FFC83D reads **13.58:1 on black** and **1.55:1 on white**. `fl_hp_mid` is 14.73 / 1.43. No single colour solves this.

**Rule: every mark drawn directly on the game — with no scrim behind it — carries a black halo.**

| Mark | Halo |
|---|---|
| ESP box stroke | draw the box twice: first `fl_esp_halo` #CC000000 at `strokeWidth + dp(2)`, then the entity colour at `strokeWidth` |
| ESP text (names, distance) | `Paint.setShadowLayer(dp(3), 0, dp(1), 0xCC000000)`, or a `Paint.Style.STROKE` pass in `fl_esp_halo` at `dp(3)` before the `FILL` pass |
| Health bar | 1dp `fl_esp_halo` border around the whole bar; track is `fl_hp_track` #B3000000 |
| Radar | a `bg_hud_scrim` disc behind the blips, so the blips never sit on raw scene |
| Crosshair | `fl_esp_halo` under-stroke at `strokeWidth + dp(1)` |
| Floating-button label | `setShadowLayer(dp(3), 0, dp(1), 0xCC000000)` |

With the halo, the worst case becomes the colour against **black** — the "on black" column above — which is 6.52:1 or better for every ESP and health colour.

**Hue, not luminance, separates the entity classes.** Measured pairwise: enemy↔teammate 1.23:1, enemy↔unknown 2.08:1, teammate↔unknown 1.70:1. That is expected and acceptable for a hue-coded overlay, but it means colour must not be the *only* differentiator. Give each class a second cue:

| Class | Colour | Second cue |
|---|---|---|
| Enemy | `fl_esp_enemy` #FF4D6A | solid box stroke, `dp(2)` |
| Teammate | `fl_esp_team` #4DA3FF | dashed box stroke (`DashPathEffect{dp(6), dp(4)}`), `dp(1.5)` |
| Unknown | `fl_esp_unknown` #FFC83D | corner-bracket box (corners only, no full rectangle), `dp(2)` |

### 7.5 Overlay-specific don'ts

- **No elevation/shadow on an overlay window** — the shadow lands on the game and reads as a smear.
- **No entrance/exit animation over 150 ms** on a panel shown mid-match.
- **No continuously running `ValueAnimator`** on an overlay window. `MaskBar.startMaskTextAnimation` rebuilds a 13-stop `LinearGradient` and calls `invalidate()` every frame, forever, for decoration. `OverlayAnimations.startBannerAnimation`/`startRainbowAnimation`/`startPulseAnimation` likewise. Only `EspOverlay`'s `Choreographer` loop is legitimate — it is the ESP renderer.
- **No `WRAP_CONTENT` width on a panel whose content length varies** — the panel jumps as text changes. `EspTunePanel` currently uses `WRAP_CONTENT`; pin it to `dp(340)`.
- **Never use the theme for overlay views.** A `Service` `Context` has no activity theme. Use `StyleKit.text(ctx, R.style.X)` (the 4-arg constructor), or wrap in `new ContextThemeWrapper(ctx, R.style.AppTheme_Overlay)`.

---

## 8. Migration map

Mechanical. Old → new, per view.

### 8.1 Resources

| Old | New | Note |
|---|---|---|
| `styles.xml` `AppTheme` (parent `Theme.Holo`) | `themes.xml` `AppTheme` (parent `Theme.Material.NoActionBar`) | **Delete from `styles.xml`** or the build fails on a duplicate |
| `styles.xml` `ModernSwitch` | `Widget.FL.Toggle` | 54×28dp → 56×32dp |
| `styles.xml` `ModernSwitchSmall` | `Widget.FL.Toggle` | the small variant is dropped; one size only |
| `@drawable/bg_card` | `@drawable/bg_card_surface` | radius 8dp → 16dp, stroke `fl_outline` |
| `@drawable/bg_card_gold` | `@drawable/bg_card_surface` | **delete** — warm stroke contradicts the single accent |
| `@drawable/bg_card_inner` | `@drawable/bg_card_surface` | |
| `@drawable/bg_top_action` | `@drawable/ripple_btn_secondary` | |
| `@drawable/bg_btn_green` | `@drawable/ripple_btn_primary` | |
| `@drawable/bg_btn_red`, `bg_btn_cancel` | `@drawable/ripple_btn_danger` | |
| `@drawable/bg_power_circle` | `@drawable/bg_power_off` — oval, `fl_bg_surface_high` fill, `dp(2)` `fl_outline_strong` | |
| `@drawable/bg_power_circle_on` | `@drawable/bg_power_on` — oval, `fl_accent_dim` fill, `dp(3)` `fl_accent_bright` | |
| `@drawable/bg_switch_custom_on` | `@drawable/bg_toggle_on` | |
| `@drawable/bg_switch_custom_off` | `@drawable/bg_toggle_off` | |
| `@drawable/seekbar_float_progress` / `_purple_progress` | `@drawable/seekbar_fl_progress` | one track, height 4dp → 6dp |
| `@drawable/seekbar_float_thumb` / `_purple_thumb` | `@drawable/seekbar_fl_thumb` | 18dp → 24dp |
| `@drawable/dot_on` | `dot_on.xml` (oval, `fl_success`) | 7dp/10dp → **10dp everywhere** |
| `@drawable/dot_off` | `dot_off.xml` (oval, `fl_text_disabled`) | was a rounded **rectangle** selector |
| `@drawable/bg_main_gradient` | keep the file, restate stops as `fl_bg_base` → `#FF080B10` → `fl_bg_base` | |
| `@drawable/bg_feature_icon`, `bg_feature_icon_green`, `bg_engine_button_on/off`, `bg_flow_button`, `bg_header_chip`, `bg_hero_card`, `bg_section_marker`, `bg_size_value`, `bg_chip_teal`, `btn_gray_stroke*`, `btn_green_stroke`, `dot_green`, `dot_grey`, `dot_red`, `bg_hue_slider` | audit and **delete if unreferenced** | ~16 drawables; several are Holo-era leftovers |
| `assets/fonts/chudep.ttf` | **delete** | 0 bytes; the load at `FloatingOverlayService.java:107` always throws into the `catch` |

### 8.2 `activity_main.xml` view mapping

| Current | New style | Change |
|---|---|---|
| header `"ThuyLinh"` 22sp `sans-serif-black` | `Text.FL.Display` | 22sp → 28sp |
| header `"Meow EDITION"` 9sp `#7A8395` | `Text.FL.Overline` | 9sp → 11sp, `fl_text_tertiary` |
| `btn_show_floating` `Button` 42dp, `#50FFC5` | `Widget.FL.Button.Secondary` | 42dp → 56dp; moves into the engine card |
| `btn_shizuku` `Button` 42dp | `Widget.FL.Button.Secondary` | 42dp → 56dp; moves to the **AIM** tab |
| `btn_engine` `FrameLayout` 72dp | unchanged type, `bg_power_off`/`bg_power_on` | 72dp → 96dp |
| `iv_engine_power` `ImageView` `tint #E6E8F2` | keep; tint `fl_text_primary` off / `fl_on_accent` on | `MainActivity.setUI` hex → `getColor` |
| `tv_status` 19sp `#6D7286`/`#4DFFB2` | `Text.FL.TitleL`, `fl_text_tertiary` / `fl_success` | fixes **3.94:1** |
| `tv_selected_app` 11sp `#555B71` | `Text.FL.Caption`, `fl_text_secondary` | fixes **2.79:1** |
| `dot_engine` `View` 10dp | unchanged size, new `dot_on`/`dot_off` | |
| `dot_app` `View` 0×0 | real `View` 10dp beside `tv_selected_app` | was invisible |
| `dot_vpn`, `dot_display`, `dot_notif`, `dot_storage` 7dp | 10dp | |
| every 40dp/44dp toggle `LinearLayout` | `Widget.FL.Row` | 40/44dp → 56dp; whole row clickable |
| every row label (`"ESP BOXES"` etc.) 11sp `#C4CAE0` | `Widget.FL.Row.Label` | 11sp → 15sp |
| `"● FREEZE"` `#40F5D0`, `"● GHOST"` `#9B66FF`, `"● DỊCH CHUYỂN"` `#FFE66D` | `Widget.FL.Row.Label`, `fl_text_primary` | **drop the per-row colours and the `●`** — three arbitrary hues fight the single accent; the pill carries state |
| `tv_*_status` 10sp `#778094` | `Widget.FL.Pill` | see §5.5 |
| `cb_*` `style="@style/ModernSwitchSmall"` | `style="@style/Widget.FL.Toggle"` | |
| section titles `"QUYỀN TRUY CẬP"` etc. 12sp `#51F3A8` | `Widget.FL.SectionHeader` | 12sp → 13sp, `fl_accent` |
| card title `"ĐIỀU CHỈNH NÚT NỔI"` 13sp `#F7F7FB` | `Text.FL.TitleM` | 13sp → 17sp |
| slider label `"Cỡ:"`/`"Mờ:"` 48dp wide, 11sp | `Widget.FL.Row.Label` | full-width row, track beneath |
| `tv_*_value` 58dp, 11sp `#40F5D0` | `Widget.FL.Row.Value` | mono 14sp, `fl_mono_value` |
| all `SeekBar` | `style="@style/Widget.FL.SeekBar"` | 48dp min height |
| 1dp dividers `#102F3341` | `Widget.FL.Divider` | `fl_outline` |
| `"♙"` icon `TextView` in a 42dp circle | **delete** | |
| 11 zero-sized views | see the §6.1 cut table | 4 deleted outright, 7 restored or rebound |

### 8.3 Java mapping

| File:line | Now | New |
|---|---|---|
| `MainActivity:252,256` | `Color.parseColor("#FF05110B")` / `"#FFE6E8F2"` | `getResources().getColor(R.color.fl_on_accent)` / `fl_text_primary` |
| `MainActivity:259` | `Color.parseColor("#FF4DFFB2")` | `R.color.fl_success` |
| `MainActivity:264` | `Color.parseColor("#FF6D7286")` | `R.color.fl_text_tertiary` |
| `MainActivity:254,262` | `R.drawable.bg_power_circle_on` / `bg_power_circle` | `bg_power_on` / `bg_power_off` |
| `UiBindings:230` | `applyToggleState` → `bg_switch_custom_on/off` | `StyleKit.toggle(activity, isOn)`; also set the pill style |
| `UiBindings:83` | `groupTeleOptions` field | delete (view is gone; `setOptionalGroupVisible` is already null-safe) |
| `UiBindings:52-54` | `tvFloat*Status` → 0×0 views | now point at real `Widget.FL.Pill` views |
| `UiBindings:263` | `boolean maskEnabled = true;` | delete with the mask-bar cut (§6.4c) |
| `OverlayButton:23-26` | 4 `FLOAT_BUTTON_*` hex strings | delete → `StyleKit.floatButton(ctx, on)` |
| `OverlayButton:88,166` | `Math.max(72, Math.round(160 * scale))` **px** | `dpToPx(Math.max(56, Math.round(72 * scale)))` |
| `OverlayButton:151` | `g.setStroke(3, …)` **px** | `g.setStroke(StyleKit.dp(ctx, on ? 3 : 2), …)` |
| `OverlayButton:140,83` | `tv.setTextColor(Color.WHITE)` | `fl_text_primary` on, `fl_text_secondary` off |
| `OverlayButton:290-372` | `BtnTouchListener` | **delete** — 83 lines, never instantiated |
| `OverlayAnimations:36-75` | `makeTopBanner` + `startBannerAnimation` | **delete** |
| `EspTunePanel:92-100` | 9 `COL_*` constants | delete → `colors.xml` |
| `EspTunePanel:145,160,741,753,762,795,1194,1216` | `setTextSize(9f/10f/11f/13f)` | `StyleKit.text(ctx, R.style.*)` from §3 |
| `EspTunePanel:1224` | `LayoutParams(dp(34), dp(28))` | `StyleKit.lpSquare(ctx, 52, 8)` |
| `EspTunePanel:170` | `LinearLayout.LayoutParams(dp(268), dp(330))` | `dp(340) × min(dp(480), 0.6 × screen)` |
| `EspTunePanel:1233-1238` | `card(int color)` helper | `StyleKit.surface(ctx, fill, stroke, 1, 8)` |
| `EspOverlay:126-130` | `setTextSize(10f)`, `setAlpha(0.92f)`, `setPadding(12,8,12,8)` px, `argb(150,8,18,30)` | `StyleKit.text(ctx, R.style.Widget_FL_Hud)`, alpha **1.0** |
| `EspOverlay:128` | `Color.parseColor("#FF9BE8FF")` | spanned: `fl_mono_label` + `fl_mono_value` |
| `EspOverlay:140-141` | `dp.x = 8; dp.y = 120;` px | `StyleKit.dp(ctx, 8)` / `StyleKit.dp(ctx, 96)` |
| `EspOverlay:95-113` | render-window params | **UNCHANGED — see §7.3** |
| `DevPopup:36-40` | `#FF5DFF84` bg, `#FF071007` text, 112dp | `Widget.FL.Pill` 52dp collapsed / `Widget.FL.Panel` expanded |
| `MaskBar` (whole file) | rainbow-shader watermark | **delete**, or the static restyle in §6.4c |
| `FloatingOverlayService:107` | `Typeface.createFromAsset(…, "fonts/chudep.ttf")` | delete; pass `null` (`OverlayButton` already falls back to `DEFAULT_BOLD`) |
| `EspRenderView` (Canvas colours) | inline hex | `StyleKit.espColor` / `hpColor` / `espHalo`; add the halo passes from §7.4 |

### 8.4 Suggested order

1. `colors.xml`, `dimens.xml`, `themes.xml`, new drawables, `styles.xml`. Delete `AppTheme` from `styles.xml` in the same commit.
2. `StyleKit.java`.
3. Overlay surfaces, worst-first: `EspOverlay` debug readout (the 3.46:1 fix) → `OverlayButton` (the px-vs-dp and 2.00:1 fixes) → `EspTunePanel` (the 34×28dp fix) → `DevPopup` → `MaskBar` decision.
4. `activity_main.xml` rewrite + the tab strip; update `UiBindings` / `MainActivity` per §8.3.
5. Delete the unreferenced drawables and `assets/fonts/chudep.ttf`.

Steps 1–3 are independently shippable and address the user's complaint about the overlay surfaces without touching the 955-line layout.

---

## Appendix — method

Every ratio in this document was computed with the WCAG 2.x relative-luminance formula (sRGB linearisation, `L = 0.2126R + 0.7152G + 0.0722B`, ratio `(L₁+0.05)/(L₂+0.05)`). Translucent backgrounds were composited against both `#000000` and `#FFFFFF` and the **worse** of the two is reported, because the background is a live game frame of unknown colour.
