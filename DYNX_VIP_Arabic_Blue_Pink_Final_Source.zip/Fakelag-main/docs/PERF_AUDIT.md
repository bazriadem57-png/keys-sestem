# Performance audit — CPU, allocation, battery, latency

**Method:** static analysis only. No device was attached, nothing was profiled, no
allocation tracker was run. Every claim below is either *derived from the code* (the
allocation is literally there, the loop rate is literally there) or *inferred* (the
rate depends on traffic or on an Android implementation detail). Each finding says
which.

**Path root** for every `file:line` below:
`fakelag/fakelag-beta/app/src/main/java/com/fakelag/cryhard8/`

## Rates used throughout

| Path | Rate | Source |
|---|---|---|
| ESP render (`update()` + `onDraw()`) | **120 Hz** | `Choreographer` per display frame — `overlay/EspOverlay.java:165-176` |
| Aim controller tick | **125 Hz** while engaged | `TICK_MS = 8` — `overlay/AimInjector.java:137` |
| Tun read loop / recv threads | **193–1007 pps measured, ~1100 pps ceiling** | the repo's own measurement, `dev/capture/CaptureRing.java:44-48` |
| Outbound position reports | ~10 Hz | brief |
| Chain packets (entity stream) | ~5 Hz per entity; all 8 players per tick in Clash Squad | `esp/EspEngine.java:906-915` |
| Debug text panel | 2 Hz, **and only while visible** | `overlay/EspOverlay.java:37,179-191` |

A single allocation at 5 Hz is nothing. The same allocation at 120 Hz is 600/sec, and
at 1000 pps it is 1000/sec. Findings are ranked on that basis, not on how ugly they
look.

---

# Tier 1 — always-on cost, large, and buys nothing

## 1. The banner animator re-blurs a text shadow 120 times a second, forever

`FloatingOverlayService.java:238` → `overlay/OverlayAnimations.java:117-147`

`startBannerAnimation()` creates an `INFINITE` `ValueAnimator` that is never cancelled
except in `onDestroy`. Its update listener runs **once per display frame for the life of
the overlay**, and per frame it:

- calls `Color.parseColor("#FF62FFF1")` and `Color.parseColor("#FF92FF6F")`
  (`OverlayAnimations.java:130-131`) — two string parses that could be two
  `static final int` constants. **240 string parses/sec.**
- calls `topBanner.setTextColor(...)` → `invalidate()`.
- calls `topBanner.setShadowLayer(18f + (6f * progress), 0f, 0f, ...)`
  (`OverlayAnimations.java:135-144`). **The radius changes every frame.**

The shadow radius is the problem. HWUI caches blurred text layers keyed on the paint's
shadow parameters; a radius that changes every frame misses that cache every frame, so a
Gaussian blur of the banner text is regenerated at 120 Hz — in a
`TYPE_APPLICATION_OVERLAY` window sitting on top of a game, which also forces
SurfaceFlinger to recomposite that layer every frame.

The two sibling animators started alongside it, `startRainbowAnimation()` (`:78-95`) and
`startPulseAnimation()` (`:97-115`), both bail immediately at `:79` / `:98` because
`ringDrawables` (`:23`) is **never populated** — nothing anywhere adds to that list. So
only the banner animator actually runs. Worth saying, because the rainbow/pulse listeners
look far worse than the banner one (each would call `AnimatedCircleDrawable.setPulse` →
`updatePaints` → a fresh `RadialGradient` and a fresh 9-stop `SweepGradient` with nine
`Color.parseColor` calls, per drawable per frame — `overlay/AnimatedCircleDrawable.java:50-54, 92-136`).
That code is dormant today and would be a severe regression if the list were ever filled.

- **Certain from the code:** the animator is infinite, is started unconditionally at
  `FloatingOverlayService.java:238`, the listener body runs per frame, the radius is a
  function of `progress`, and `ringDrawables` is never populated.
- **Suspected, needs a device:** the size of the blur-cache miss. Settle it with
  `adb shell dumpsys gfxinfo <pkg> framestats` on the overlay process with the banner
  animation on vs. commented out, plus `simpleperf` on RenderThread.

**Fix (touches no ESP constant and no packet):** hoist the two colours to
`static final int`; hold the shadow radius constant and let the already-present colour
blend carry the animation, so the blur cache hits. If a pulsing radius is genuinely
wanted, drive it from a low-rate timer rather than per display frame.

## 2. The crosshair spins forever at display refresh

`overlay/CrosshairView.java:64` → `overlay/CrosshairView.java:73-81`

`makeCrosshairView()` unconditionally calls `startCrosshairRotation()`, which starts an
`INFINITE` `ObjectAnimator` on the `"rotation"` property, 1 s per revolution. The
crosshair is on by default (`FloatingOverlayService.java:171` reads `Prefs.KEY_CROSSHAIR`
with default `true`; shown at `:204`). So an overlay window is damaged and recomposited
every frame for the whole session.

A `View.rotation` animation is a RenderThread property animation, so it is far cheaper
than finding 1 — no relayout, no re-record. But it still keeps a window dirty at 120 Hz
on top of a game, which is exactly the composition load you do not want while the GPU is
busy.

- **Certain from the code:** infinite animator, started from `makeCrosshairView`.
- **Suspected:** how much of the frame budget it costs. `dumpsys SurfaceFlinger --latency`
  on that layer settles it.

**Fix:** make the rotation opt-in (the teardown path `hideCrosshair()` at `:83-90`
already exists), or give the animator a finite repeat count. Purely cosmetic.

## 3. `CaptureRing` holds ~10.6 MB resident and memcpys every packet even with capture off

`dev/capture/PacketCapture.java:302-315` — in particular **line 307 runs before line 308**:

```java
ring.add(now, src, dir, len, peerIp, sp, dp, decision, mask, buf, off);
if (!running) return;
```

`CaptureRing` (`dev/capture/CaptureRing.java:64-77`) allocates at construction:

- `byte[] arena` = 8 MiB (`ARENA_BYTES = 1 << 23`, line 52)
- 8 parallel metadata arrays × `SLOTS = 66000` = `2×long[] + 6×int[]` ≈ **2.6 MB**

≈ **10.6 MB permanently resident inside a `VpnService`**, allocated whether or not a
capture is ever started. The class javadoc (lines 13-21) is explicit that 135 MB was the
*previous* number and that resident size in a VpnService is itself a kill risk — the
current number is far better, but it still exists on every run.

Per packet, with capture **off**, `CaptureRing.add` (lines 96-123) still does: two
`AtomicLong.getAndAdd` on globally shared counters, a `System.arraycopy` of the whole
payload into the arena, and 8 array stores. At the repo's own measured 193–1007 pps that
is ~1000 payload memcpys/sec plus ~2000 contended atomic RMWs/sec, on the tun thread and
on every recv thread simultaneously.

The two atomics (`byteCursor`, `writeIdx`, lines 65-66) are adjacent instance fields and
will almost certainly share a cache line, so the tun thread and N recv threads ping-pong
that line on every single packet.

- **Certain from the code:** the unconditional `ring.add` before the `running` check; the
  resident sizes; the two shared atomics on adjacent fields.
- **Suspected:** the cache-line contention cost. `simpleperf stat -e cache-misses` across
  the tun + recv threads settles it.

**Fix, in two halves.** The free half: pad the two `AtomicLong`s apart (or pack both
cursors into one `AtomicLong`) to kill the false sharing — invisible to every caller. The
half with a trade-off: gate the ring on a separate `retroEnabled` flag (default off,
flipped when the user arms retro-capture) and allocate the arena lazily on first enable.
That changes the behaviour of a debug feature — retro-capture would reach back only to
arming, not to app start — so it is a product decision. **Flagged as behaviour-changing.**

---

# Tier 2 — the 120 Hz render loop

Good news first, since the brief asked: **`onDraw` really is allocation-free.** Verified
by reading `overlay/EspRenderView.java:1319-1600`. Every `Paint` is a preallocated field
(`:814-841`), the label is built into a reused `StringBuilder` (`labelBuf`, `:844`), the
`canvas.drawText(labelBuf, 0, len, ...)` call at `:1493` uses Android's pooled
`TemporaryBuffer` path, and there is no `String.format`, no `new`, no autoboxing and no
`Map.Entry` iteration anywhere in the method. `refreshViewport()` is rate-limited to 1 Hz
(`:758-760`), so its `new Point()` (`:773`) fires ~1/sec. The `String.format` calls at
`:1250-1290` and `:1779-1782` live in `statusLine()` / `calibHint()`, which are reached
only from the 2 Hz debug ticker and only when the panel is visible
(`overlay/EspOverlay.java:183-187`). The claim in the class javadoc holds.

The violations are in `update()`, which runs on the same 120 Hz callback.

## 4. `ConcurrentHashMap.entrySet()` iteration allocates a `MapEntry` per entity per frame

`overlay/EspRenderView.java:1122`

```java
for (Map.Entry<Integer, Track> e : esp.entities().entrySet()) {
```

`entities` is a `ConcurrentHashMap<Integer, Track>` (`esp/EspEngine.java:495`, exposed at
`:2097`). In the OpenJDK/libcore implementation Android ships, `EntryIterator.next()`
returns `new MapEntry<K,V>(k, v, map)` — **a fresh object per entry, per iteration** —
plus one `EntryIterator` per frame.

At 120 Hz with 10 live entities that is ~1200 `MapEntry` + 120 iterators ≈ **1320
objects/sec, ~40 KB/s**. Over a 20-minute match, ~48 MB of pure garbage. On ART that is a
steady stream of young-gen collections whose pauses land on the UI thread — the one
thread with an 8.3 ms budget.

- **Certain from the code:** the iteration is there, the map is a `ConcurrentHashMap`, the
  loop runs at display refresh.
- **Implementation detail, verify on device:** that `EntryIterator.next()` allocates. This
  is true of every JDK/libcore `ConcurrentHashMap` I know of, but it is not an API
  guarantee. **Settle it** with Android Studio's allocation tracker during a match — you
  want `ConcurrentHashMap$MapEntry` visible in the top allocation sites.

**Fix (no behaviour change):** iterate `keySet()` and `get()`. `KeyIterator.next()`
returns the key directly and allocates nothing, leaving one iterator per frame:

```java
for (Integer id : esp.entities().keySet()) {
    Track t = esp.entities().get(id);
    if (t == null) continue;
    ...
}
```

Entity ids are bounded to 64 (`esp/EspEngine.java:791`, `MAX_ENTITY_ID = 64`), so the
`Integer` keys come from the JDK's `Integer` cache and the `get(id)` boxing is free — see
finding 19. Iteration order over a `ConcurrentHashMap` is unspecified either way, so
nothing observable changes. Do **not** reach for `forEach(BiConsumer)`: that is a Java 8
API on a core-library type, needing desugaring or API 24, and minSdk here is 21.

## 5. Five map lookups per entity per frame for data that changes at ≤5 Hz

`overlay/EspRenderView.java:1219-1221`

```java
enemyName[n]   = esp.roster().name(e.getKey());      // 1 CHM get
enemyRealHp[n] = esp.pri().hpFor(e.getKey(), now);   // 2 CHM gets (byHandle -> owners)
enemyMaxHp[n]  = esp.pri().maxHpFor(e.getKey());     // 2 CHM gets (the same pair again)
```

(`esp/MatchRoster.java:52-53`, `esp/PriTracker.java:441-454`.) Five
`ConcurrentHashMap.get` per entity per frame ≈ **6000 lookups/sec at 120 Hz × 10
entities**. Names change on join/kill/quit; HP changes at the Cmd 1900 rate. Nothing here
changes at 120 Hz.

`hpFor` and `maxHpFor` do the *same* `byHandle.get(handle)` → `owners.get(id)` walk back
to back, so two of the five are literally duplicate work in adjacent statements.

- **Certain from the code:** the call count and the duplicated lookup pair.
- **Honest sizing:** a `ConcurrentHashMap.get` on a small map is tens of nanoseconds; 6000
  of them is perhaps 0.2 ms/sec in total. This is **not** a frame-budget problem. It is
  listed because the duplicate half is free to remove and because it sits on the same
  lines as finding 4.

**Fix (no behaviour change):** add a `PriTracker` accessor that returns hp and maxHp from
a single `Owner` lookup — the `Owner` object already holds both — and call it once. The
values are identical.

---

# Tier 3 — per-packet cost in the tunnel

At 193–1007 pps, anything here runs hundreds to a thousand times a second on the tun
thread or a recv thread.

## 6. A full payload-sized `byte[]` is allocated and copied for every inbound packet

`core/UdpSessionManager.java:350` → `core/PacketBuilder.java:22-46`

```java
byte[] ip = PacketBuilder.buildPkt(pkt, sip, dp, sp, engine.tunIP);
synchronized (out) { out.write(ip); }
```

`buildPkt` does `new byte[plen + 0x1c]` (`PacketBuilder.java:25`) plus
`ByteBuffer.wrap(buf)` (`:26`) — **two allocations and a full payload copy per inbound
packet**, discarded immediately after the write. This is the largest per-packet
allocation in the codebase. At 1000 pps with ~100 B payloads that is ~128 KB/s of
short-lived garbage on the recv threads, on top of the `CaptureRing` copy from finding 3
— so **every inbound packet is copied at least twice** before it reaches the game.

`PacketBuilder.RNG` (`:17`) is a shared `java.util.Random`, whose `nextInt` is a CAS loop
on an internal `AtomicLong`; every recv thread contends on it once per inbound packet
(`:30`). Minor next to the allocation, but it is the same function.

- **Certain from the code:** the allocation, the copy, the shared RNG.
- **Suspected:** the GC impact. Settle with `adb shell dumpsys meminfo` deltas and
  `logcat -s art` GC lines across a match.

**Fix (no behaviour change):** give `RecvRunnable` a per-thread reusable output buffer (it
already owns a per-thread `rbuf` at `:192`) and add a `buildPktInto(byte[] dst, ...)` that
writes the header and copies the payload into it, returning the length; then
`out.write(dst, 0, len)`. The bytes on the wire are identical. For the RNG, give each
thread its own `Random` instance rather than changing the generator — the IP ID field is
not load-bearing here (there is no fragmentation path), but a per-thread instance keeps
behaviour identical in kind while removing the contention.

## 7. `new DatagramPacket` inside the receive loop

`core/UdpSessionManager.java:195`

```java
while (engine.isRun && engine.isActive) {
    DatagramPacket pkt = new DatagramPacket(rbuf, rbuf.length);
    ...
    fe.s.receive(pkt);
```

One object per received packet. The standard form is to allocate the `DatagramPacket`
once outside the loop and call `pkt.setLength(rbuf.length)` before each `receive` — the
length is the only field `receive` clobbers. **Certain from the code.** Behaviour
identical.

## 8. `InetAddress.getByAddress(tb(dip))` on every outbound send

`core/UdpSessionManager.java:139-140`, and again at `:97-98` and `:110-111` on the replay
path

```java
DatagramPacket pkt = new DatagramPacket(ctx.buf, ctx.off, sendLen,
        InetAddress.getByAddress(PacketBuilder.tb(ctx.dip)), ctx.dp);
```

Per outbound packet: `PacketBuilder.tb()` allocates a `byte[4]`
(`core/PacketBuilder.java:135-137`), `InetAddress.getByAddress` allocates an
`Inet4Address` **and** its internal `InetAddressHolder`, and `new DatagramPacket` is a
fourth object. Four allocations for a destination that is constant for the lifetime of
the session.

- **Certain from the code.**

**Fix (no behaviour change):** cache the `InetAddress` and the `DatagramPacket` on the
`SE` session object (`:35-47`) — the 5-tuple *is* the map key, so the destination cannot
change for a given `SE`. The send path becomes
`pkt.setData(ctx.buf, ctx.off, sendLen); se.s.send(pkt);`. The replay path at `send(TelePacket)`
(`:91-125`) uses a different buffer and can cache its own address the same way. Same
bytes, same destination, same ordering.

## 9. `Long` boxing on the UDP session map, twice per outbound packet

`core/UdpSessionManager.java:52` (`ConcurrentHashMap<Long, SE>`), used at `:93-94`,
`:129-130`, `:151`, `:162`, `:361`

```java
long key = ((long)(ctx.sp & 0xffff) << 48) | ((long)(ctx.dp & 0xffff) << 32) | (ctx.dip & 0xFFFFFFFFL);
SE se = getOrCreate(key, ...);   // -> udpMap.get(key)
```

The key packs a full 5-tuple, so it is far outside the `Long` cache (−128..127) and every
`udpMap.get(key)` autoboxes a fresh `Long`. `send()` boxes once at `:130` and
`getOrCreate` boxes again at `:151` for the same packet — **two `Long` allocations per
outbound packet**, ~2000/sec at peak.

- **Certain from the code:** the key misses the cache by construction.

**Fix (no behaviour change):** pass the `SE` already looked up in `send()` into
`getOrCreate()` so only one boxing happens per packet. The complete fix would be a
primitive-keyed `long -> SE` map, **but `android.util.LongSparseArray` is not thread-safe
and this map is touched from the tun thread and from every recv thread** (`:361` removes
from a recv thread), so a drop-in swap would be a correctness regression. Do the
one-lookup fix; treat a primitive concurrent map as a separate, carefully-reviewed change.

## 10. `parseStructured` allocates 14 arrays per chain packet

`esp/EspEngine.java:1050-1056`

```java
int[] pos = { start };
int[] ids = new int[declared];
long[] xs = ..., zs = ..., ys = ...;
long[] vxs = ..., vzs = ..., vys = ...;
int[] by = ..., ay = ..., ap = ...;
int[] md = ..., st = ...;
boolean[] full = new boolean[declared];
```

Fourteen allocations for every chain packet that reaches the structured parser — and the
structured parser is the *preferred* path, hit on 99.77–100% of chain packets per the
comment at `:938-941`. In Clash Squad all eight players are replicated every tick
(`:906-915`), so this fires at the world-state tick rate.

It is called from `core/UdpSessionManager.java:326`, on a **recv thread** — and there is
one recv thread per UDP session, so `EspEngine` is genuinely multi-threaded.

- **Certain from the code:** the 14 allocations.
- **Suspected:** the actual rate. Count how many `observeChainPacket` calls reach
  `parseStructured` per second from an existing capture — the repo already has the
  tooling for that.

**Fix:** preallocate the arrays at `MAX_CHAIN_RECORDS = 64` (`:797`) once. **They must be
per-thread** — `ThreadLocal<Scratch>` holding a small struct of the 13 arrays — because
multiple recv threads call in concurrently. Plain fields would be a data race and a
correctness regression. Parsed values are unchanged.

## 11. `FreezeFilter` builds its log note before checking whether logging is on

`filter/FreezeFilter.java:169-172`

```java
logger.logPacket("BLOCK_FREEZE", "IN", ctx.buf, ctx.off, ctx.plen,
        ctx.sp, ctx.dp, ctx.dip,
        exact ? "freeze=true cmd=" + com.fakelag.cryhard8.net.CmdCatalogue.describe(ctx.cmd)
              : "freeze=true shape");
```

`DevLoggerImpl.logPacket` begins with `if (!devMode) return;` (`dev/DevLoggerImpl.java:139`)
— but Java evaluates arguments first. So on the `exact` branch, **every dropped
world-state packet** builds a `StringBuilder`, calls `CmdCatalogue.describe(cmd)` (itself
`cmd + " " + nameOr(cmd)` — another String, `net/CmdCatalogue.java:140-142`), and
concatenates, then throws it all away when dev mode is off. Dev mode off is the normal
state: `PacketVpnService.java:101` calls `devLogger.setEnabled(false)` at startup.

Freeze drops the world-state stream, which is the bulk of inbound — 3–4 allocations per
dropped packet at whatever that rate is.

The same pattern on much rarer paths:

- `core/PacketLoop.java:49-50` — `"version=" + version + " ip_len=" + len + " route=" + engine.activeRouteModeName()` before `logProtocolDrop`.
- `core/PacketLoop.java:78-81` — `"proto=" + PacketBuilder.protoName(proto) + ...`; `protoName` allocates for unknown protocols (`core/PacketBuilder.java:150`).
- `filter/TeleportFilter.java:271` and `:370` — `"tele=" + s.label() + " parse=fail"`, drop paths only.
- `filter/JitterFilter.java:70,74` — `"DELAY_TELE_" + TelePacket.typeName(...)` per held packet. **`JitterFilter` appears to be dead**: `DefaultFilterEngine` instantiates `FreezeFilter`, `GhostFilter`, `TeleportFilter`, `AimFilter` and `MarkFilter` (`filter/DefaultFilterEngine.java:45-49`) and never `JitterFilter`. Zero cost today.

`filter/GhostFilter.java:249`, `:256` and `:266-268` get this right — constant String
literals on every branch, no allocation. That is the pattern to copy.

- **Certain from the code:** argument evaluation precedes the `devMode` check.

**Fix (no behaviour change):** guard the call site —
`if (logger.isEnabled()) { logger.logPacket(...); }`. `isEnabled()` is a single volatile
read (`dev/DevLoggerImpl.java:97-100`). Logged output is byte-identical when dev mode is
on, and nothing is built when it is off.

## 12. Encrypted bodies are TEA-decrypted into an empty registry — and twice for seven commands

`net/PacketPipeline.java:244-264` and `core/UdpSessionManager.java:241-271`

`pipeline.dispatch(parsed, direction)` is called on every packet in both directions
(`core/PacketLoop.java:165`, `core/UdpSessionManager.java:273`). For an encrypted packet
with a session key it runs `Tea.qqTeaDecrypt` over the whole body
(`net/PacketPipeline.java:256`) and then calls `registry.dispatch(...)`.

**The registry is empty.** Nothing anywhere in the source tree calls
`register`/`registerCode`. `codes` and `decoders` stay at `NO_CODES`/`NO_DECODERS`
(`net/BodyDecoderRegistry.java:35-39`) and `fallback` stays null, so `dispatch` always
returns false (`:108-116`). Every one of those TEA decryptions is discarded.

Separately, `core/UdpSessionManager.java:247-257` runs its **own** `BodyCrypt.decrypt` for
Cmd 1900/121/118/101/107/139/102, and that happens *before* the `pipeline.dispatch` call
at `:273`. Those seven commands are therefore decrypted twice per packet.

This costs nothing until `LobbyKeySniffer` captures a key
(`net/PacketPipeline.java:103-105`); before that, `keySchedule` is null and dispatch bails
at `:246-249`.

- **Certain from the code:** the registry is empty; the second decrypt exists.
- **Honest sizing:** QQ-TEA is 16 rounds per 8-byte block, so a 200-byte body is ~25
  blocks — low single-digit microseconds. At the reliable-channel rate this is fractions
  of a millisecond per second. Real, but small. It is listed because the brief asked about
  redundant parsing and this is the clearest instance.
- **Also checked, and clean:** the warning at `core/VpnEngine.java:97-98` about routing the
  ESP feed through a second parser and delivering every position twice — **that
  duplication does not exist.** `EspBodyDecoders` is never registered, so the shape-gated
  feeds in `PacketLoop` and `UdpSessionManager` remain the only ESP path. The warning is
  being honoured.

**Fix (no behaviour change):** in `PacketPipeline.dispatch`, insert an early
`return false;` immediately *before* the `Tea.qqTeaDecrypt` call at `:256` when the
registry has no decoders and no fallback — i.e. **after** the `isZipped()` branch and
**after** the `k == null` branch, so `undecodable` is still incremented exactly as today.
Counters, return value and every caller's behaviour are identical; only the discarded
crypto disappears. Requires adding an `isEmpty()` accessor to `BodyDecoderRegistry`.

---

# Tier 4 — battery and wakeups

## 13. `TouchWatcher` reads every event from every input device and allocates a String per line

`overlay/TouchWatcher.java:124`

```java
proc = newProcess(new String[]{"sh", "-c", "getevent -l"});
```

`getevent -l` with no device argument dumps **every event from every `/dev/input/event*`
node**, symbolically. On a touchscreen that is `ABS_MT_SLOT`, `ABS_MT_POSITION_X`,
`ABS_MT_POSITION_Y`, `ABS_MT_PRESSURE`, `SYN_REPORT`… per pointer per report — roughly
6–10 lines per report — plus every other evdev device on the phone.

The Java side (`:135-162`) calls `in.readLine()` on all of them: **one `String`
allocation per line**, then two `String.indexOf` scans, when the watcher cares about
exactly two line kinds. For lines that do match, `deviceOf(line)` (`:173-179`) allocates
two or three more Strings (`substring`, `trim`, `substring`) — and it is called on every
matching line even though the device never changes.

At a 120–240 Hz digitizer with two fingers down that is **~1500–2400 `String`
allocations/sec while the user is touching the screen**, which in a shooter is most of
the time — plus the `getevent` subprocess itself burning CPU formatting text that is
immediately discarded.

The subprocess is started from the Shizuku binder-received listener
(`overlay/AimInjector.java:310`, `:381`) and lives for the whole session.

- **Certain from the code:** unfiltered `getevent -l`; one `readLine` String per line;
  `deviceOf` allocating per matching line.
- **Suspected:** the exact line rate, which is panel-dependent. Settle it by running
  `getevent -l | wc -l` for 10 s with a finger moving.

**Fix (no behaviour change to the parser):** filter in the C process so only the two line
kinds ever cross into Java:

```java
"getevent -l | grep -E 'ABS_MT_TRACKING_ID|BTN_TOUCH'"
```

The exact same lines reach the existing parsing code; everything else is dropped before
it becomes a `String`. **Caveat to verify on device:** toybox `grep` block-buffers when
stdout is not a tty, which would add latency to the touch state — pass `--line-buffered`
(toybox supports it) and confirm manually that `userTouching()` still flips promptly. If
that proves unreliable, the fallback is to resolve the touchscreen node once with
`getevent -pl` and run `getevent -l /dev/input/eventN`, which removes other devices
though not the position spam.

Second, cache the device: `deviceOf` only needs to run while `device` is still `"-"`.

**Separate correctness note, not performance.** `userTouching()` at `:67-74`:

```java
if (activePointers <= 0) return false;
return SystemClock.uptimeMillis() - lastEventMs < 2000L || activePointers > 0;
```

The second disjunct is always true given the guard above, so the 2 s sticky window the
comment describes can never expire; a drifted `slotCount` parks the aim permanently.
Flagged because a reader will otherwise assume the timeout works. Fixing it **would**
change behaviour, so it is a decision, not a cleanup.

## 14. A stats broadcast every 1.5 s, forever, whether or not anything changed or is listening

`core/VpnEngine.java:672-706`

```java
while (isRun && !stopped) {
    Thread.sleep(1500);
    ...
    Intent i = new Intent(VpnActions.ACTION_STATS);
    ... 6 extras ...
    context.sendBroadcast(i);
    broadcastState();
}
```

Two broadcasts every 1.5 s for the life of the tunnel — **~80 broadcast dispatches per
minute**, each a binder transaction into ActivityManager plus intent and `Bundle`
marshalling, regardless of whether the UI is in memory or whether a single counter moved.
It runs with the screen off. Broadcast dispatch is one of the more expensive IPC paths on
Android and is exactly the kind of periodic wakeup that surfaces in a battery blame
report.

- **Certain from the code:** the loop, the rate, the two sends, the absence of any
  change detection.
- **Suspected:** the measured battery cost. `adb shell dumpsys batterystats --charged <pkg>`
  across a 20-minute match, before/after, settles it.

**Fix — this one has a behaviour trade-off, flagged deliberately.** The obvious fix is to
skip the send when nothing changed since the last tick, but the comment at `:699-701`
states that the unconditional `broadcastState()` is what makes a late-subscribing UI
converge. Preserving that while cutting the cost: send on change, plus an unconditional
send every Nth tick (say every 8th, a 12 s heartbeat). A late subscriber then converges
within 12 s instead of 1.5 s. That is a product call. The strictly-free half is to hoist
the `Intent` out of the loop and reuse it with `putExtra` — same broadcast, one fewer
allocation per tick.

## 15. Overlay teardown can leave the 125 Hz aim ticker running for the life of the process

`FloatingOverlayService.java:256-278` (`onDestroy`)

The brief asked whether the "forever-ticker burning 125 binder pings/sec" is really
fixed. **The fix is real.** `overlay/AimInjector.java:589-600`:

```java
boolean idle = !hasTarget && !gestureOn
        && (SystemClock.uptimeMillis() - targetAtMs) > LOOP_IDLE_MS;   // 1500 ms
if (idle) { synchronized (AimInjector.class) { loopRunning = false; } return; }
```

and `available()` is cached behind a 500 ms TTL (`:390-411`), so even a running tick costs
2 binder pings/sec rather than 125. Both the parking and the ping cache are genuinely in
place.

**But there is a hole.** `hasTarget` is cleared only by `aimRelease()` (`:568-570`), which
is called exclusively from the renderer's `onDraw` (`overlay/EspRenderView.java:1598`,
`:1712`) and from the calibrator (`overlay/AimCalibrator.java:100`). `onDestroy` tears
down the renderer (`FloatingOverlayService.java:267` → `EspOverlay.hide()` at
`overlay/EspOverlay.java:313-337`) and **never calls `AimInjector.aimRelease()`**. If the
overlay is destroyed on a frame where a target was locked, `hasTarget` stays `true`, the
`idle` test never passes, and the `TICKER` re-posts at 8 ms on the `aim-inject`
`HandlerThread` **for the life of the process** — 125 Handler wakeups/sec plus 2 binder
pings/sec. The exact bug that was fixed, reachable through a different door.

`onDestroy` also never calls `TouchWatcher.stop()` (`overlay/TouchWatcher.java:109-118`),
so the `getevent` subprocess from finding 13 survives overlay teardown too.

- **Certain from the code:** `onDestroy` calls neither; `hasTarget` has no other clear path.
- **Suspected:** how often a destroy lands on a locked frame. Trivially settled on device:
  lock a target, kill the overlay, then check `adb shell ps -T -p <pid> | grep aim-inject`
  plus `dumpsys cpuinfo`.

**Fix (no behaviour change):** add `AimInjector.aimRelease();` and `TouchWatcher.stop();`
to `FloatingOverlayService.onDestroy`, alongside `animations.cancelAll()` at `:273`. More
robustly, add an `AimInjector.shutdown()` that clears `hasTarget`, ends any gesture and
lets the ticker park.

## 16. Four allocations per injected touch event, plus a reflective invoke

`overlay/AimInjector.java:864-878` (`send`) and `:519-528` (`inject`)

```java
MotionEvent.PointerProperties p = new MotionEvent.PointerProperties();
MotionEvent.PointerProperties[] props = {p};
MotionEvent.PointerCoords c = new MotionEvent.PointerCoords();
MotionEvent.PointerCoords[] coords = {c};
MotionEvent ev = MotionEvent.obtain(...);   // pooled, and ev.recycle() IS called - good
```

Four allocations per event. While the controller is actively correcting, `sendMove` runs
on every 8 ms tick → **125 events/sec → 500 allocations/sec**. `MotionEvent.obtain` is
pooled and `recycle()` is correctly called at `:877`, so that part is already right.

`inject` at `:521` does `injectMethod.invoke(inputManager, ev, INJECT_ASYNC)` — reflective
invocation allocates an `Object[2]` varargs array per call (the `INJECT_ASYNC` boxing is
free: it is 0, inside the `Integer` cache). Another ~125 arrays/sec.

- **Certain from the code.**

**Fix (no behaviour change):** `send` runs only on the injector's own `HandlerThread`
(`:94`, `:349-351`) plus `rawDrag`/`selfTest`, which the class doc at `:900-906` states
must not overlap with the controller. So the `PointerProperties`/`PointerCoords` objects
and their 1-element arrays can be `private static final` fields mutated in place before
each `obtain` — `MotionEvent.obtain` copies out of them, so reuse is safe. For the
reflection, hoist a `private static final Object[] INJECT_ARGS = new Object[2]` on the
same thread and set `INJECT_ARGS[0] = ev` per call. Identical events, identical timing.

## 17. `THREAD_PRIORITY_URGENT_AUDIO` is set on a shared, unbounded, recycling thread pool

`core/UdpSessionManager.java:191` and `PacketVpnService.java:89`

```java
threadPool = Executors.newCachedThreadPool();     // PacketVpnService:89
...
public void run() {                                // UdpSessionManager:190-191
    Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
```

Three problems in one:

1. **The priority is never restored.** `newCachedThreadPool` recycles idle threads for
   60 s. A thread that finishes a `RecvRunnable` keeps nice −19 and is then handed to
   whatever runs next — and the *same pool* is handed to `TcpProxy`
   (`core/VpnEngine.java:140`), which spawns up to three runnables per TCP connection
   (`core/TcpProxy.java:206`, `:239`, `:268`). So lobby/voice relay threads, including the
   `Thread.sleep(50)` drain loop at `core/TcpProxy.java:305`, end up running at audio
   priority. That is both a scheduler and a battery concern: −19 threads are
   preferentially scheduled and resist being parked.
2. **The pool is unbounded.** One `RecvRunnable` per UDP 5-tuple
   (`core/UdpSessionManager.java:167`), plus three per TCP connection. Each recv thread
   allocates a 32 KB `rbuf` (`:192`). A burst of new flows through the tunnel — or a game
   that rotates source ports — creates threads with no ceiling.
3. Recv threads do exit reasonably: `SO_TO = 30000` ms socket timeout and `IDLE = 45000` ms
   (`:32-33`, `:354-356`), so a dead session is reclaimed within ~45 s. That part is fine.

- **Certain from the code:** the shared pool, the unrestored priority, the unboundedness.
- **Suspected:** how many threads actually exist during a match.
  `adb shell ps -T -p <pid> | wc -l` settles it in one command.

**Fix (no behaviour change to packet handling):** restore the priority in a `finally` at
the end of `RecvRunnable.run()`, or give the UDP sessions a pool of their own separate
from `TcpProxy`'s. Bounding the pool would change failure behaviour under a flow burst
(rejection instead of a new thread) — **flagged as behaviour-changing**; do it only with
a deliberate rejection policy.

## 18. The capture writer polls at 2 ms when its queue is empty

`dev/capture/CaptureWriter.java:345-360`

```java
CaptureEvent e = queue.poll();
if (e == null) { ...; Thread.sleep(2); continue; }
```

500 wakeups/sec on the writer thread whenever the queue drains — which is most of the
time between packet bursts. It only costs anything while a capture is running, so it is
not an always-on item, but a ten-minute capture (the 27 MB figure in the brief) pays it
for ten minutes.

- **Certain from the code.**

**Fix:** back off progressively (2 ms → 10 ms → 25 ms, reset on the first event), or add a
`LockSupport.park`/`unpark` handshake to the `EventRing` (`:91-120`). Latency to disk is
irrelevant — the stream is flushed on a 500 ms interval anyway (`:61`). Bounded backoff
changes no output.

---

# Tier 5 — small, conditional, or theoretically ugly but practically free

## 19. `Integer` boxing for entity ids costs nothing — ids are capped at 64

`esp/EspEngine.java:791` (`MAX_ENTITY_ID = 64`), `esp/MatchRoster.java:52`,
`esp/PriTracker.java:441`, `overlay/EspRenderView.java:1191, 1219-1221`

Every entity-keyed map in the ESP is `ConcurrentHashMap<Integer, …>`, and every `get(int)`
autoboxes. But ids are validated to 1..64 (`esp/EspEngine.java:1060`) or 1..127 (`:1529`,
`:1571`), which is inside the JDK's `Integer` cache (−128..127) — so `Integer.valueOf`
returns a shared instance and **allocates nothing**. Listed explicitly because it looks
like the classic autoboxing bug and is not one. Do not "fix" it.

## 20. `updateCalibReadout()` runs `String.format` on the tun read loop

`esp/EspEngine.java:736` → `:2117-2160`

```java
if (ownSamples % 10 == 0) updateCalibReadout();
```

Called from `observeKeepalive`, which runs on the tun read loop via
`core/PacketLoop.java:126`. The keepalive stream is ~10 Hz, so this fires **~1/sec**, and
it builds a `StringBuilder`, makes five `String.format` calls, walks
`entities.values()` twice (`:2103`, `:2133`) and `entities.entrySet()` once (`:2141` —
which allocates a `MapEntry` per entry, same mechanism as finding 4). It runs whether or
not the debug panel is visible, and whether or not the overlay is shown at all.

This is the textbook "work done unconditionally that is only needed when a feature is on"
— but at 1 Hz. Honest sizing: `String.format` is tens of microseconds; the whole call is
perhaps 100–300 µs. That is a ~0.03% duty cycle on the tun loop and a sub-millisecond
hiccup once a second, well inside the 230 ms staleness budget. **Real but not worth
risking a regression over.**

**Fix if you want it (no behaviour change):** gate on a volatile `readoutWanted` flag the
overlay sets when the debug panel becomes visible. The consumer chain is already
`FloatingOverlayService.java:150-156` → `EspOverlay.buildDebugText`
(`overlay/EspOverlay.java:290-291`), which only runs when `debugVisible`.

## 21. `GamePacketTaxonomy.observeOutbound` boxes an `Integer` per keepalive-sized packet

`filter/GamePacketTaxonomy.java:220-221, 252-271`

`outTuples` is `ConcurrentHashMap<Integer, TupleTrack>` keyed on `tupleKey(b2,b4,b5)`
(`:229`) — a 24-bit value, outside the `Integer` cache, so `outTuples.get(key)` at `:256`
allocates. `outTuples.size()` at `:253` is a `sumCount()` walk over the counter cells on
every packet, and there is a `synchronized (t)` monitor per packet at `:262`.

`learnMovement` (`:413-455`) boxes a `Long` (`moveCands.get(ep)`, `:441`) and an `Integer`
(`cands.get(key)`, `:449`) — but only during the learning window: once the movement stream
is confirmed it early-returns at `:419-422` or `:428-438` with no boxing at all. That part
is well designed.

Rate: gated to `KEEPALIVE_LEN_MIN..MAX`, so tens of allocations/sec, not thousands.
**Small.** Worth a primitive-keyed map only if you are already editing this file.

## 22. `observeSmallInbound` allocates a 6-element array per packet

`esp/EspEngine.java:656`

```java
int[] kk = {k2, k3, k4, k5, k6, k7};
```

One `int[6]` per inbound 11–13 byte packet. It cannot be hoisted to a shared field — the
method runs on multiple recv threads and the mask fields are themselves mutable, so a
shared array would be racy. The clean fix is to unroll the loop at `:657-660` against the
six fields directly, which allocates nothing and needs no shared state. **Small, and the
fix is free.**

## 23. `MaskBar` allocates ~16 objects per frame — but is off by default

`overlay/MaskBar.java:97-130`

The mask-bar text animation is `INFINITE` and its per-frame listener allocates `int[13]`,
`float[13]`, thirteen `new float[3]` for `Color.HSVToColor`, and a fresh `LinearGradient`
— **~16 allocations per frame, ~1900/sec at 120 Hz**. It is gated on `showMaskBar`, which
defaults to `false` (`FloatingOverlayService.java:171`), so it costs nothing today. But it
is the worst per-frame allocator in the app if anyone turns it on. Same fix shape as
finding 1: hoist the arrays and the colour table, which are constant except for `phase`.

## 24. A thread pool that is created and never used

`filter/DefaultFilterEngine.java:28`

```java
private final ExecutorService executor = Executors.newCachedThreadPool();
```

Referenced only by `shutdown()` at `:190`. A cached pool creates no threads until
something is submitted, so the runtime cost is zero — it is a dead field. Delete it, or
wire it if it was meant to own the replay work (`ReplayEngine` is constructed at `:39`
and takes no executor).

## 25. `TcpProxy` copies every segment in both directions

`core/TcpProxy.java:157` (`new byte[diff]` per client→remote segment) and `:291`
(`copyOf(buf, n)` per remote→client segment), plus three pool threads per connection
(`:206`, `:239`, `:268`).

This is the lobby/login/voice path, not the game's position stream, so the rate is orders
of magnitude below the UDP path. The copies are also structurally necessary — the bytes
are queued across threads. **Correct as written; listed so it is not mistaken for an
oversight.**

---

# Latency

The brief's concern is delay between a packet arriving and the ESP seeing it, against a
~230 ms staleness budget.

**The ESP feed has no queue and no thread hop.** In `RecvRunnable.run()`
(`core/UdpSessionManager.java:190-353`) everything is inline and synchronous, in this
order: `receive` → header parse → `filterEngine.onInbound` → telemetry →
`esp.observe*` (`:326`, `:333`, `:338`) → `capture.recordInbound` (`:340`) → `buildPkt`
plus the write to tun (`:350-353`). The ESP reads the bytes microseconds after `recv`
returns. **This is the right design and there is nothing to fix.**

Two observations follow from that ordering:

- **Everything is in front of the game's own packet.** The parse, the filter, the ESP
  decode, the capture-ring memcpy and the capture-queue submit all execute before
  `out.write(ip)`. Straight-line, that is microseconds. The risk is not the work — it is a
  GC pause landing in the middle of it, which is the real argument for findings 6, 7, 10
  and 3. **Suspected, needs a device:** measure with Perfetto on the recv threads and
  correlate ART GC events against inter-packet gaps.
- **`synchronized (out)` at `:351`** serialises the tun write across every recv thread and
  the ICMP reply path (`core/PacketBuilder.java:89`). The critical section is a single
  `write()`, so contention should be low, but it scales with the number of concurrent UDP
  sessions. **Suspected:** measure lock contention with `simpleperf` if flow count is ever
  high.

On the render side, `Choreographer` at 120 Hz means the ESP sees new state within 8.3 ms
of it landing (`overlay/EspOverlay.java:165-176`), and the class comment's reasoning about
replacing the 33 ms `Handler` chain is sound. The remaining latency risk there is a GC
pause on the UI thread, which is finding 4.

The aim controller's lag compensator scans the full 256-entry ring on every 8 ms tick
(`overlay/AimInjector.java:651-658`) — 32 000 iterations/sec of three array reads, a few
tens of microseconds per second in total. **Free; do not touch it.** It is
correctness-critical and the comment at `:252-261` documents the measurement that
justifies the ring over the previous decay model.

---

# Checked and clean

Stated explicitly so nobody re-audits them:

- **`onDraw` is allocation-free as documented.** `overlay/EspRenderView.java:1319-1600`. No
  `new`, no `String.format`, no autoboxing, no `Map.Entry` iteration; reused `Paint`s
  (`:814-841`) and a reused `StringBuilder` (`:844`). The violations are in `update()`,
  not `onDraw`.
- **The aim "forever-ticker" is genuinely fixed.** `overlay/AimInjector.java:589-600` parks
  the loop after `LOOP_IDLE_MS`, and `available()` caches the binder ping for 500 ms
  (`:390-411`). See finding 15 for the one remaining hole.
- **Capture hex formatting never runs when capture is off.** `HEX` encoding lives in
  `CaptureWriter.encode` on the writer thread (`dev/capture/CaptureWriter.java:539-540`,
  `:674`), and the writer only exists while `running`
  (`dev/capture/PacketCapture.java:308-311`). The write path is a 64 KB
  `BufferedOutputStream` (`:700-701`) with interval and byte-threshold flushing and 32 MB
  rotation (`:59-66`), and encodes straight to bytes with no `String` or `StringBuilder`
  per record. This subsystem is well built. The only problem is the *ring*, a different
  class — finding 3.
- **`DecodedDumper` and `FreezeDiffAnalyzer` run only at capture stop**, from
  `core/VpnEngine.java:809-812`. Off the hot path entirely.
- **The double-ESP-feed hazard warned about at `core/VpnEngine.java:97-98` does not exist.**
  Nothing registers a `BodyDecoder`; `net/BodyDecoderRegistry.java:38-40` stays empty.
- **The debug text panel is properly gated** — built at 2 Hz and only when visible
  (`overlay/EspOverlay.java:183-187`), so `stateText()`, `debugLine()`, `calibHint()`,
  `teamLine()` and the ten `debugLine()` calls in `buildDebugText` (`:200-294`) cost
  nothing when the panel is off. The one exception is `updateCalibReadout` — finding 20.
- **`refreshViewport` is rate-limited to 1 Hz** (`overlay/EspRenderView.java:758-760`), so
  its `WindowMetrics`/`Point` allocations are ~1/sec.
- **No wake locks anywhere.** No `PowerManager.WakeLock`, no `WifiLock`. The foreground
  service is declared correctly with `FOREGROUND_SERVICE_TYPE_DATA_SYNC`
  (`PacketVpnService.java:119`).
- **The tun read loop blocks on `in.read(buf)`** (`core/PacketLoop.java:42`) with a single
  reused 64 KB buffer (`:39`) — no polling, no per-read allocation. Correct.
- **`GhostFilter`'s hot-path log notes are constant literals** (`filter/GhostFilter.java:249`,
  `:256`, `:266-268`) — no allocation. This is the pattern `FreezeFilter` should follow.

---

# Fixes that would change behaviour — decide, do not just do

Called out per the brief's rule.

| Change | What it alters | Finding |
|---|---|---|
| Gate `CaptureRing` on an explicit retro-arm flag | Retro-capture reaches back only to arming, not to app start | 3 |
| Bound the shared `newCachedThreadPool` | New flows rejected instead of spawning a thread | 17 |
| Skip unchanged stats broadcasts | A late-subscribing UI converges in 12 s instead of 1.5 s | 14 |
| Fix `TouchWatcher.userTouching()`'s dead sticky window | The aim would resume after 2 s of touch silence; today it never does | 13 |
| Swap `udpMap` to a primitive `long` map | `LongSparseArray` is not thread-safe; this map is cross-thread | 9 |
| Share `parseStructured` scratch arrays as plain fields | Data race across recv threads. Must be `ThreadLocal` | 10 |

Nothing else proposed in Tiers 1–4 alters an ESP numeric constant, a packet's bytes, the
order packets are sent or received in, or any timing the protocol depends on.
