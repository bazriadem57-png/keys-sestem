# Teleport on/off kick — root-cause analysis

Scope: why toggling teleport ON→OFF (and especially ON→OFF→ON) ends the live
match with a "network error" back to lobby. Traced against the committed
2026-09-11 design. All paths base package
`fakelag/fakelag-beta/app/src/main/java/com/fakelag/cryhard8`.

Constants used below: `MAX_STEP_M = 2.70`, `DEFAULT_STEP_M = 2.50`
(`filter/TeleportFilter.java:109,112`); `UNITS_PER_METRE = 1000.0`
(`esp/EspEngine.java:350`); server distance gate: largest accepted **2.77 m**,
smallest rejected **5.31 m** (`docs/TELEPORT.md:30`); small over-gate step =
snap-back (recoverable, 399-402 ms), large jump = protocol error that ends the
session (`docs/TELEPORT.md:31`, `filter/TeleportFilter.java:722-731`).

---

## 1. Verdict

**PROVEN.** The kick is caused by `TeleportFilter.replayAnchor()` re-sending the
**original** anchor packet — the one captured at position A on the first press —
from states in which the server's belief has already been walked away from A. The
prime trigger is the re-arm branch of `press()` (`TeleportFilter.java:666-678`,
the RAMP→ANCHOR transition of ON→OFF→ON): it moves the logical hold position
(`repX/Z/Y`) and the route cursor to C (where the ramp has walked the server to),
but it never rebuilds `anchorPacket`, which is assigned only once at line 304.
The re-armed ANCHOR hold then drops the live reports and, on the first tick,
replays the byte-for-byte packet that reports **A** (`replayAnchor()`,
lines 189-202, invoked at 331-335), while the server currently believes **C**.
That is a single-packet backward jump of `|C − A|` metres. Because the ramp
consumes ~2.5 m of belief per report, after only ~3 reports (~300 ms) between OFF
and the third press the jump exceeds 5.31 m, and after a ~0.5–2 s pause it is
12.5–50 m — squarely in "large jump = session ends" territory. The two "already
fixed" session-enders (stale-`Length` on rebuild, and snap-to-passthrough on
abort/shutdown) are genuinely closed (§4); this stale-replay path is the
remaining flaw and it is a *different* mechanism than either.

---

## 2. Ranked hypotheses

### H1 — Re-arm replays the stale original anchor (ON→OFF→ON). PROVEN. PRIME.

**Mechanism.** `anchorPacket` (the verbatim bytes re-sent by the ANCHOR hold) is
assigned **only** inside the first-anchor block, at
`TeleportFilter.java:304` (`anchorPacket = ctx.copyPayload()`), guarded by
`!anchored`. It captures the position report at A.

The re-arm branch, `press()` when `prev == RAMP` (`TeleportFilter.java:667-678`):

```
674  anchored = true;
675  repX = cursorX;      // C — where the ramp walked the server's belief
676  repZ = cursorZ;
677  repY = cursorY;
678  pathReset(cursorX, cursorZ, cursorY);
```

It updates `repX/Z/Y` and the cursor/path to C but **does not touch
`anchorPacket`** — grep confirms line 304 is the only assignment. `lastReplayMs`
is also not touched here, and is never touched on the RAMP path
(`onOutbound` 340-380); it was last set during the *pre-ramp* anchor phase
(line 309/333). So once the machine is back in ANCHOR, the hold block runs:

```
328  if (s == TeleportState.ANCHOR) {
329      pathAppend(realX, realZ, realY);
...
332      if (now - lastReplayMs >= REPLAY_INTERVAL_MS) {   // stale -> true immediately
333          lastReplayMs = now;
334          replayAnchor();                                // sends A
335      }
337      return FilterDecision.DROP;                        // live report withheld
```

`replayAnchor()` (189-202) sends `anchorPacket` = the A report, verbatim, through
`UdpSessionManager.send(TelePacket)` (`core/UdpSessionManager.java:90-92`), where
`PacketIntegrity.seal` finds it intact and forwards it unchanged. The server,
believing C, receives A: a backward step of `|C − A|` in one datagram.

**Sequence + metre-delta.**
- ON (press#1): first 2001 at A is PASSed as the anchor (`onOutbound` 296-312);
  server belief = A; live reports then dropped, A replayed (315-338). PROVEN.
- OFF (press#2): RAMP walks belief A→C at ≤ `stepM` **route-length** per report
  (`pathAdvance` budget = `stepM * UNITS_PER_METRE`, 353); each emitted 2001
  moves ≤ 2.5 m straight-line. Safe. PROVEN.
- ON (press#3) after N ramp reports: re-arm to C, then replay A →
  **backward jump ≈ N × 2.5 m.** N≥2 → ≥5.0 m (> 2.77, snap-back); N≥3 →
  ≥7.5 m (> 5.31, protocol-error kick); OFF→pause→ON with the ramp still
  running → 12.5–50 m → **guaranteed kick.** PROVEN from code + gate constants.

It also poisons the *next* press: after the stale A replay the server believes A,
but `repX = C`; press#4 (ANCHOR→RAMP) resumes the ramp reporting ≈C while the
server holds A → forward jump `|C − A|`. Second kick vector, same root.

**Fix (no code here).** Make the physical hold agree with the logical hold at C.
Cheapest correct option: in the re-arm branch, replace the verbatim-replay hold
with a **rewrite hold at C** — i.e. on re-arm set a flag so the re-armed ANCHOR
rewrites each live 2001 to `(repX,repZ,repY)` with zero velocity via
`writeState`/`PositionSync`, instead of calling `replayAnchor()`. A rewrite to C
is already known-accepted because the ramp emitted exactly such a packet at C one
tick earlier. Equivalent alternative: on re-arm, stash the **last emitted ramp
packet's bytes** (which already report ≈C and passed) as the new `anchorPacket`
so the verbatim replay holds at C. A safe stop-gap that removes the kick but
loses the hold's liveness feed: on re-arm, reset `lastReplayMs = now` and simply
DROP without replay (belief rests at C, the last ramp packet; liveness rides
other families per `docs/TELEPORT.md:171`). Do **not** keep the verbatim replay
of A on re-arm under any option.

**Confirm cheaply.** Add one dev counter: at every `replayAnchor()`, decode
`anchorPacket`'s v0-v2 and log `|decode(anchorPacket) − (repX,repZ,repY)| / 1000`
m. It is 0 during a normal hold and jumps to `|C − A|` the instant ON→OFF→ON
re-arms. In a capture: right after the third press, one outbound 2001 carries the
*original* A coordinates while the preceding ramp packets reported C; the
self-echo residual jumps to `|C − A|` and then either snaps back at +400 ms or
the session drops.

---

### H2 — Same stale replay, triggered by mounting / platform mid-ramp. PROVEN. SECONDARY.

The mounted-carrier branch (`onOutbound` 254-263) and the platform-relative
branch (281-290) also call `replayAnchor()`, and they run in **both** ANCHOR and
RAMP (they precede the state split). During RAMP `repX` = cursor ≠ A, so if a
2002/2006/2031 report (vehicle/passenger/cannon, `net/Cmd.java:371-386`) or a
platform-relative 2001 (`V_PLATFORM_ID != 0`, `PositionSync.java:77`) arrives
while the ramp is mid-flight, `replayAnchor()` sends A while the server believes
the cursor → backward jump `|cursor − A|`, same kick as H1.

**Sequence + delta.** ON, walk, OFF, then mount a vehicle (or step onto a moving
platform) while the release is still ramping → one A-report against a belief that
has moved `|cursor − A|` m; > 5.31 m once the ramp has covered ≥3 reports.

**Fix.** These branches must replay/hold the **currently believed** position
(`repX/Z/Y`), not the captured origin; or, while `state == RAMP`, DROP without
replaying at all (the ramp will resume on the next on-foot, non-platform report).

**Confirm.** Same counter as H1; trigger by mounting during a release. `dbgMounted`
/ `dbgPlatform` increment at the moment the echo jumps back to A.

---

### H3 — Ghost-takeover during a release desyncs the held position. INFERRED. LOW.

`toggle(GHOST)` on calls `teleport.abort()`
(`filter/DefaultFilterEngine.java:93`). If teleport is ANCHOR, abort→RAMP
(`TeleportFilter.java:733-737`), but ghost runs first in the pipeline and drops
the position channel (`DefaultFilterEngine.java:59-61`), starving the ramp; ghost
then holds *its own* captured anchor (the real position at ghost-start, not the
teleport cursor C). When ghost is turned off, teleport is still RAMP with
`repX = C` while the server believes ghost's anchor → jump. This is a
ghost/teleport interaction, not pure teleport on/off, and depends on
`GhostFilter` internals not read here — hence INFERRED and ranked low.

**Confirm.** Log teleport `repX` and ghost's held position at each ghost toggle;
a mismatch > 2.77 m at the ghost-off edge is the tell. Only pursue if the kick
reproduces with ghost involved.

---

## 3. Explicitly checked and NOT the cause (this on/off symptom)

- **Ramp step vs report cadence — SAFE. PROVEN.** The ramp is **per-packet**, not
  time-based: `pathAdvance(budget = stepM * UNITS_PER_METRE, …)` runs once per
  `onOutbound` position report (`TeleportFilter.java:353,552-588`) and caps
  `moved` at the budget. A stretched/coalesced report gap cannot make a single
  emitted step exceed `stepM` (≤ 2.70 m); straight-line displacement ≤ route
  length consumed ≤ budget. So sparse cadence does not trip the 2.77 m gate.
- **State collapse / skipped ramp — cannot happen. PROVEN.** `onPress`
  (`filter/TeleportState.java:75-81`) advances exactly one edge per press; RAMP is
  reachable only from ANCHOR, so there is no IDLE→RAMP path and no way two presses
  skip the ramp. The plain ON→OFF release is bounded and safe on its own.
- **Landing to IDLE — SAFE. PROVEN.** `land()` fires only when the cursor is
  within `LAND_EPS_M = 0.75` m of the real position (`pathAdvance` returns −1,
  573-587) and passes the real packet unmodified (`onOutbound` 355-357); residual
  ≤ 0.75 m < 2.77 m.

---

## 4. "Previously fixed" enders — verified genuinely closed

- **(a) Stale HeaderLayout → wrong `Length` on rebuild — CLOSED. PROVEN.**
  `PositionSync.rebuild` proves the layout decodes *this* packet before trusting
  it to encode: `declared = layout.readShort(…DATA_LEN…); if (declared != plen −
  hdrSize) return −1;` (`net/PositionSync.java:256-257`). A stale per-session XOR
  mask (`net/HeaderLayout.java:101-122`) makes `declared` mismatch → rebuild
  returns −1 → `writeState` returns −1 → `onOutbound` DROPs (364-373). No
  mis-`Length` datagram is emitted. The in-place path never changes `Length`.
- **CRC-7 reseal — CLOSED. PROVEN.** In-place: `PositionSync.seal` →
  `PacketCodec.reserialize` (`PositionSync.java:201-204`); rebuild reseals at 291;
  the replay/`TelePacket` exit reseals via `PacketIntegrity.seal`
  (`UdpSessionManager.java:92`, `filter/PacketIntegrity.java:58-71`,
  `net/Crc7.java`). No stale-CRC path. (Note: this means H1's replayed A packet is
  CRC-*valid* — it is rejected for distance, not corruption, consistent with the
  "network error, no ban" symptom.)
- **(b) Snap-to-passthrough while desynced — CLOSED for abort/shutdown/restart.
  PROVEN.** `abort()` releases ANCHOR into the ramp and leaves an in-flight ramp
  alone (`TeleportFilter.java:733-738`); `shutdown()` delegates to `abort()`
  (774-777); `onTunnelRestart()` is a no-op holding only integer coordinates
  (763-765); `disableAll`/`shutdown` route through these
  (`DefaultFilterEngine.java:121-152`). None snap the full outstanding distance
  into one passthrough report. The remaining full-distance jump is delivered by
  H1's stale *replay*, not by passthrough — which is why this looked fixed.

---

## 5. One-line repro to lock it in

Enter a match, ON, walk ~30 m, OFF, wait ~1 s (let the ramp run), ON. With the
H1 counter added you will see a single outbound 2001 reporting the original
anchor A against a server belief of ~C, `|C − A|` ≈ tens of metres, followed by
the session drop. Fixing the re-arm hold (H1) and the mounted/platform replay
(H2) to hold at the *current* belief closes every on/off ordering.
