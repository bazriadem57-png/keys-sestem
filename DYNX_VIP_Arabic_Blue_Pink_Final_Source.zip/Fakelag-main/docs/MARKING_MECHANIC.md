# The Moco / "Hacker's Eye" marking mechanic — end to end

**Target:** Free Fire MAX 2.131.1, Android ARM64, il2cpp/Unity.
**Image:** `C:\Users\Tonyt\Documents\FF-RE\bin\libil2cpp_dec.so` (decrypted).
Every RVA below is from **that** image via `rva_map.txt`, unless the line says
"dump.cs". Live base `0x400023200000`.

---

## 0. Verdict — one sentence

**(A) Server-authoritative.** The mark is decided entirely on the server and
pushed down as a dedicated reliable message, `Cmd 970
RUDP_S2C_Sync_Common_Mark_Info`; the client contains **no code that can produce
a Moco mark**, no trigger logic, no duration timer, and **no client→server
message that requests one** — the only local write path
(`Player::ClientMarkPlayer`) is wired to exactly two call sites and both pass a
different marker type.

It is *not* (B): the mark is **not** an EPRI property and in particular **not**
`EPRI_PLAYER_SIGHTING_ID` — in this codebase "Sighting" means **aim-down-sights**
(§7). It is *not* (C) either: the visual is not chosen locally from data the
client already has; the client only mirrors a bitmask the server sends.

---

## 1. Naming — how to find it

The skill has no class of its own. Its entire client-side footprint is:

| artefact | where |
|---|---|
| `message.BEAFJIDDDMB::EMarkerType_Skill_Moco = 1` | enum member, the identity of the mark |
| `COW.UIMapContentController::UpdateMocoMarkPoint2` | `0x0425b25c` — the renderer, literally named |
| `COW.ResourceIDDef::UIMAPMOCOMARKPOINTINMAPCONTENT` | the map-point prefab id |
| `COW.UIMapContentController::m_mocoMarkPointResID` | field holding it |
| `message.AOAKBDCLBBL::EBuffActionType_IcewallModuleBreakMarkEnemyMoco` | a *different* system reusing marker type 1 |

A case-insensitive `moco` sweep over `dump_names.txt` (56 MB, our build) returns
**nothing else** in gameplay — the remaining hits are the "Moco Month" event
(`proto.CSGetMocoMonthSettingRes` etc., lobby HTTP) and the coincidental
substring in `message.IKFMOCOKKGJ`. There is no `MocoSkill`, no
`SkillHackerEye`, no behaviour class. That absence *is* the finding.

> **Trap.** "Hacker" in this binary is 100 % anti-cheat vocabulary
> (`tcp.AccountHackerTagInfo`, `Proto_CDT_HACKER_NTF`, `ErrCode_HACKERSPECTATE`).
> Searching for "Hacker's Eye" leads nowhere.
>
> **Trap.** "Detective" is a *different, newer* character: a channelled scan with
> a read bar (`DetectiveScanReadBarState`, `UIHudDetectiveScanBeMarkedTipsController`,
> Cmd 351/352/669/1726). It shares the word "mark" but not the mechanism.
> Covered by the separate message-surface survey; not duplicated here.

### The internal name is **"CommonMark"**

Moco's tag is one member of a shared, engine-level marker system the game calls
*common mark*. 16 marker types share one 16-bit bitmask:

`message.BEAFJIDDDMB` (`EMarkerType`), confirmed in our build's `dump_names.txt`
and in dump.cs at line 91149 (values identical):

```
0  None                        8  PersonalUAV
1  Skill_Moco   <-- this one   9  OverHeight
2  Skill_Clu                  10  Skill_SantinoDummyDie
3  Skill_Shirou               11  Buff_IceWallModuleMark
4  Skill_Otho                 12  SensorBeaconXRay
5  Skill_Iris                 13  SFRoleplayPhantom
6  Skill_IrisBeMark           14  Skill_DreamlandBoyPetBreak
7  Pet_Dreki                  15  Skill_AuroraBoyXRay
```

---

## 2. The wire — Cmd 970, server → client, reliable

`ff_inbound_registry.tsv:662`

```
970  RUDP_S2C_Sync_Common_Mark_Info  message.DCNGPGPCDHG  COW.GamePlay.FFMOIGKIEPE.HEABPKIIPGG
```

* **Direction: S2C only.** `970` does **not** appear anywhere in
  `tools/il2cpp/ff_outbound_registry_full.txt` (731 `GameFacade::Send` sites,
  BL *and* tail-call B). There is no client-side sender.
* **`RUDP_` ⇒ reliable ⇒ TEA-encrypted body** on this link, per
  `docs/PROTOCOL_CIPHER.md` §"IsReliable". The tool's existing inbound decrypt
  path (`net/BodyCrypt.java`, the one that unlocked Cmd 1900) is what is needed
  to read it — no new crypto.

### Layout

Decoders (our image):

* `message.DCNGPGPCDHG::UnSerialize` @ **`0x04f6ebe4`**
* `message.DEIINJIGKAC::UnSerialize` @ **`0x04f6e960`**
* (encoders `message.DCNGPGPCDHG::Serialize` @ `0x04f6ea20` and
  `message.DEIINJIGKAC::Serialize` @ `0x04f6e8f4` exist but are S2C-only, so the
  client never runs them)

```
Cmd 970  DCNGPGPCDHG
  u32   viewerEntityId     ReadUInt32  -> +0x14  CCMIGEAPLPC
  i16   count              ReadInt16   (zigzag)
  count x DEIINJIGKAC {
     u32   markedEntityId  ReadUInt32  -> +0x14  AILHAJJELJP
     u8    markerType      ReadByte    -> +0x18  FGDCMNGILKE   (EMarkerType; 1 = Moco)
     u16   markerTypeMask  ReadUInt16  -> +0x1A  IAMOGEDNGPO   (bit N = EMarkerType N)
     u16   scannerMask     ReadUInt16  -> +0x1C  MDFLLLJNDAJ
  }
```

**Encoding.** These are *not* fixed-width. `GCommon.FastBinaryReader::ReadUInt32`
@ `0x0828fba4` and `::ReadUInt16` @ `0x0828fc6c` both tail into
`::ReadVariant` @ `0x0828fbb4` (LEB128); `::ReadInt16` @ `0x0828fc4c` and
`::ReadInt32` @ `0x0828fbfc` call `ReadVariant` then apply **zigzag**
(`and w8,w0,#1; neg; lsr x9,x0,#1; eor`) — the same decoding as
`::Zag` @ `0x0828fc1c`. The `ReadFix*` family (`0x08290870`+) is the fixed-width
one and is **not** used here. This matches
`docs/PROTOCOL_VARINT_DISCOVERY.md`: packet bodies are varint streams.
`ReadByte` @ `0x082902fc` is a vtable-dispatched single-byte read (slot `+0x2b8`),
not `ReadVariant`; for values 0–15 the distinction is invisible on the wire, but
confirm against a capture before assuming it for larger fields.

### There is no duration on the wire

No timestamp, no TTL, no end-time field. §5 shows the client passes
`endServerTime = 0x7FFFFFFF` into the HUD. **The mark expires only because the
server sends a new Cmd 970 with the bit cleared.** Duration therefore lives on
the server, influenced by server-side attributes the client also mirrors but
never authors (`PlayerAttributes::get_ReduceBeMarkedDurationRate`,
`get_ScanMarkDurationExtension`; pet skill
`EPetSkill_ReduceBeMarkedDuration`). The trigger condition and duration are
**data, not code** — `COWGameEntry::LoadGameVar` @ `0x06d1ab14` ends in
`ConfigDataManager::LoadCSVNoCache`, so anything tunable here ships as CSV /
hot-update, not in the binary.

### Companion message, victim side

`ff_inbound_registry.tsv:776`

```
1141  RUDP_S2C_Sync_Common_BeMark_Info  message.DEIINJIGKAC  COW.GamePlay.FFMOIGKIEPE.KMBLGNINOMM
```

Same record type as one list element of 970, sent standalone. Handler @
**`0x07a1ffa4`**: gated on a GameVar bool (§6), then straight to
`COW.UIInGameScene::OnSyncCommonBeMarkInfo` @ `0x07a0812c`. **UI only** — it
touches no gameplay state. This is the "you are being marked" warning.

So the split is: **970 = marks you can see; 1141 = you are marked.**

---

## 3. Where the state lives

### `Player::OLHNHFEKGPP` — `Dictionary<EntityId, CommonMarkInfo>` @ **`+0x15F0`**

Read straight out of `COW.GamePlay.Player::IsMarkTarget` @ **`0x07163b04`**:

```asm
0x07163b94  ldr   x0, [x19, #0x15f0]      ; this->commonMarkInfos
0x07163b98  cbz   x0, ...
0x07163bc4  bl    <Dictionary::ContainsKey>
```

(dump.cs, different build, calls the field `OLHNHFEKGPP` at `0x15D8` — use
**`0x15F0`** for 2.131.1.)

The dictionary hangs off the **viewer** — the player who is allowed to see these
marks — and is **keyed by the marked enemy's entity id**.

### `Player.BKIDLEFNNJA` — the per-enemy record

dump.cs line 1204712 (structure only; offsets verified against our image by the
loads/stores in §4):

```
+0x10  EntityId  CEHFOENKODO     the marked enemy
+0x28  byte      FGDCMNGILKE     last EMarkerType applied
+0x2A  ushort    IAMOGEDNGPO     EFFECTIVE marker-type bitmask   <-- the mark
+0x2C  ushort    MDFLLLJNDAJ     "scanner" mask (server only; 0 for local marks)
+0x2E  ushort    AAALPDMDOBN     CLIENT-OWNED bits (survive a server refresh)
```

`+0x2A` is proven to be a bitmask indexed by `EMarkerType`, not an enum value, by
the two accessors:

`BKIDLEFNNJA::DJOFEJBPMBA(int markerType)` @ **`0x071f8ae0`** — "has this type":

```asm
0x071f8b30  ldrh  w8, [x20, #0x2a]
0x071f8b34  lsr   w8, w8, w19          ; >> markerType
0x071f8b3c  and   w0, w8, #1
```

`BKIDLEFNNJA::HPMKAKMLBBO(int mask)` @ **`0x071f8b4c`** — "has any of these":

```asm
0x071f8b9c  ldrh  w8, [x20, #0x2a]
0x071f8ba0  tst   w8, w19
0x071f8ba8  cset  w0, ne
```

**Moco is bit 1, i.e. mask `0x0002`.**

---

## 4. The two — and only two — writers

### 4a. `Player::RefreshCommonMark(DCNGPGPCDHG msg)` @ **`0x071612ec`** (network)

Reached only from the Cmd 970 handler
`COW.GamePlay.FFMOIGKIEPE::HEABPKIIPGG` @ **`0x07a1fe08`**:

```
0x07a1fec0  bl  UIInGameScene::OnSyncCommonMarkInfo      ; HUD
0x07a1fed8  bl  GameFacade::CurrentMatch
0x07a1fee4  ldr w21, [x19, #0x14]                        ; msg.viewerEntityId
0x07a1ff0c  bl  BHGGAEEHJCO::LMCLIKOCCJM                 ; uint -> EntityId
0x07a1ff44  bl  EMKJHAJNPDH::ADNMDEDAEGN                 ; match.FindEntity
0x07a1ff8c  bl  Player::RefreshCommonMark
```

`RefreshCommonMark` re-checks the addressee and bails on mismatch —
`BHGGAEEHJCO::PDJKLNDADFO` @ `0x07c49d34` is **op_Inequality** (verified:
`cmp w8,w9 ; cset w0, ne` at `0x07c49dc4`, comparing only the leading `u32`):

```asm
0x071614a4  ldr  w21, [x20, #0x14]      ; msg.viewerEntityId
0x071614e0  bl   Player::get_PlayerID
0x07161510  bl   BHGGAEEHJCO::PDJKLNDADFO
0x07161514  tbnz w0, #0, <return>       ; != -> drop
```

The merge, at `0x07161f58`–`0x0716207c`, is the interesting part:

```asm
w22 = msg.entry.IAMOGEDNGPO   [+0x1a]    ; server's mask
w24 = rec.IAMOGEDNGPO         [+0x2a]    ; current effective mask
w8  = rec.AAALPDMDOBN         [+0x2e]    ; client-owned bits
0x07162014  and  w8, w8, w24
0x07162018  orr  w8, w8, w22
0x0716201c  strh w8, [x20, #0x2a]        ; effective = (clientOwned & cur) | server
0x07162074  ldrh w8, [x27, #0x1c]
0x07162078  strh w8, [x0,  #0x2c]        ; scannerMask = server's, verbatim
```

i.e. **the server's mask is authoritative for every bit it owns**; the client's
own bits (§4b) are preserved across a refresh. Byte `+0x28` is copied straight
from wire `+0x18` at `0x07161f00`/`0x07161f04`.

Sole consumer of the diff: `Player::LIDKCJCCLLH(Dictionary<EntityId,
Player.AKCKCJHBEKD>)` @ `0x07162660` (called from `0x07162228`), which raises the
change notifications.

### 4b. `Player::ClientMarkPlayer(EntityId, bool on, byte markerType)` @ **`0x071629d0`** (local)

This is the *only* way the client can set a mark bit by itself, and it is a real
mechanism — it exists precisely so a local mark survives a server refresh:

```asm
0x07162c0c  lsl  w26, w8, w22            ; bit = 1 << markerType
; add:
0x07162fc4  ldrh w8,[x0,#0x2a] ; orr w8,w8,w26      ; effective |= bit
0x07163090  ldrh w8,[x0,#0x2e] ; orr w8,w8,w26      ; clientOwned |= bit
; remove:
0x07163004/0x07163008  bic w8, w8, w26              ; effective &= ~bit
0x071630d0/0x071630d4  bic w8, w8, w26              ; clientOwned &= ~bit
; fresh record:
0x07162db8  strb w22, [x23, #0x28]       ; lastType
0x07162dbc  strh w26, [x23, #0x2a]
0x07162dc0  strh wzr, [x23, #0x2c]       ; scannerMask = 0
0x07162dcc  strh w26, [x23, #0x2e]
```

**Its complete call-site list** (BL-xref scan over the whole `.text` of the
decrypted image):

| site | caller | `w3` = markerType |
|---|---|---|
| `0x0767d074` | `LevelInfiniteAirDropInteract.AAOCHEPPHPL::AKCGOCDGMCG+0x1e8` | `#0xc` |
| `0x0767d548` | `…AAOCHEPPHPL::PICENDJAGPB+0x3ac` | `#0xc` |
| `0x0767d60c` | `…AAOCHEPPHPL::PICENDJAGPB+0x470` | `#0xc` |
| `0x07798194` | `COW.GamePlay.FIJKAGAHFJL::AKCGOCDGMCG+0x1e8` | `#0xc` |
| `0x07798728` | `COW.GamePlay.FIJKAGAHFJL::PICENDJAGPB+0x3ac` | `#0xc` |
| `0x07798800` | `COW.GamePlay.FIJKAGAHFJL::PICENDJAGPB+0x484` | `#0xc` |

`0xC` = **`EMarkerType_SensorBeaconXRay`**, the airdrop sensor beacon. **No call
site anywhere passes `1`.** That is the negative proof that kills hypothesis (C)
for Moco.

### Nothing else touches the dictionary

Full xref set for the private accessor `Player::OMALDCHELHM` @ `0x071610f0`
(the dictionary getter): 26 sites inside `RefreshCommonMark`, 11 inside
`ClientMarkPlayer`, 1 inside `GetCurCommonMarkInfos`. Plus
`Player::ClearCommonMark` @ `0x07161204`, whose single caller is
`COW.GamePlay.EMKJHAJNPDH::AJHEEFGLACI+0xe94` (match/entity teardown).
That is the entire write surface.

---

## 5. The trigger — and why it cannot be seen from the client

Moco's skill is passive: shoot an enemy, that enemy is tagged. The client-side
evidence for where that decision is made is entirely negative, and complete:

1. **No local trigger.** The only local writer is `ClientMarkPlayer`, wired to
   six airdrop call sites, all marker type `0xC` (above).
2. **No request message.** `970` and `1141` have no outbound counterpart. A
   sweep of `ff_outbound_registry_full.txt` for `mark|xray|detective|sighting`
   returns only the *map-ping* system (`148 RUDP_MAPMARK_CHANGED`,
   `551`, `957` — `UIBigMapController::SendMapMarkChanged`,
   `UIHudItemMarkShowController::OnMarkBtnClick`) and
   `1268 LevelObjectMapScanMachine::DoAction`. None of these is a skill mark.
3. **The active-skill messages carry no target.** `248 RUDP_USE_ACTIVE_SKILL`
   (`message.FJKNMFDDMMI`, sender sites `0x07c8d22c`, `0x07cabc4c`,
   `0x07cc2a38`, `0x07cd546c`, `0x07cdc1ec`, `0x07d262f0`) serialises
   (`Serialize` @ `0x04cac15c`):

   ```
   u32  casterEntityId      +0x14
   u32  skillId             +0x18
   PMFGOGFPDHM (3 fields)   +0x20   ; Vector3 — position
   BDOPLCJODBN (3 fields)   +0x28   ; Vector3 — direction
   u32                      +0x30
   ```

   `249 RUDP_STOP_ACTIVE_SKILL` (`IKPEHEFGCGI`) = `{casterId, skillId}`;
   `1206 RUDP_START_ACTIVE_SKILL_CHARGE` (`LLDCAJFKFGM`) = `{skillId}`.
   **No target-entity field in any of the three.** Moco is passive anyway and
   emits none of them.
4. **Hit claims stay hit claims.** The Cmd 106 builder
   (`docs/HIT_REWRITE_SPEC.md`) carries hit point, zone and `checkParams`; it has
   no mark field, and `docs/HIT_REWRITE_SPEC.md` already establishes the server
   geometry-validates it.

**Conclusion:** the "shot → tagged" rule, its duration, and its team-sharing all
execute server-side on the validated hit. **The mark depends on a hit the server
accepted.** Per the standing scope decision, forging that hit is out of scope and
no recipe for it appears here.

The client does *consume* the mark for one piece of local combat math —
`PlayerAttributes::GetSkillDamageScale` @ `0x07c43224` calls
`attacker.IsMarkTarget(victim.PlayerID)` at `0x07c43600` and, if true, adds a
scale from `FFEMIECMNBK::KFJOFOFFIPF` — but that is a mirror of a server value,
not a source of one. (Second `IsMarkTarget` caller: `FFEMIECMNBK::FKIGJMNFKNA`
@ `0x07cdae44`, at `0x07cdafec`.)

---

## 6. Rendering — what the mark actually draws

Two independent consumers, both fed only from the dictionary / the message.

### 6a. Map + minimap point — `UIMapContentController::UpdateMocoMarkPoint2` @ **`0x0425b25c`**

Called from `UIMapContentController::Update+0xafc` (`0x0425645c`) and
`::EnableBigMap+0xe8` (`0x04295ed8`).

```asm
0x0425b3e8  ldrb w9, [x8, #0x303d]       ; GameVarDef +0x303D : enabled?
0x0425b3ec  cbz  w9, <return>
0x0425b408  ldr  w8, [x8, #0x3038]       ; GameVarDef +0x3038 : frame interval
0x0425b45c  bl   GameFacade::GetLocalPlayerOrObServer
0x0425b4c4  bl   Player::GetCurCommonMarkInfos          ; 0x071611b4
; for each record:
0x0425b578  ldr  w1, [x8, #0x3184]       ; GameVarDef +0x3184 : marker-type mask
0x0425b57c  bl   BKIDLEFNNJA::HPMKAKMLBBO              ; (rec.mask & gvMask) != 0 ?
0x0425b5d4  bl   ResourceManager::PoolGetRes            ; m_mocoMarkPointResID
0x0425b6e0  bl   EMKJHAJNPDH::ADNMDEDAEGN               ; rec.CEHFOENKODO -> entity
0x0425b740  bl   GCommon.Entity::get_Position
0x0425b784  bl   COW.UIMapUtil::ProjectToMapOffset
```

So: **for every entity in the local player's mark dictionary whose type mask
intersects a server-configured bitmask, fetch that entity's live world position
and plot it on the map.** This is a live position feed, not a last-seen ping.

**The GameVar defaults confirm the identification independently.** The class
behind `[0xafd0000+0x228]` is `COW.GameVarDef` (same pointer used by
`GameVarDef::GetCatapultSpeed` @ `0x06f0fcfc`). Reading its `.cctor` @
**`0x06e183b4`**:

| static | init site | default | meaning |
|---|---|---|---|
| `+0x303D` | `0x06e1e24c` `strh w23,[x9,#0x1c]`, x9 = base+0x3020, w23 = `0x0101` | **1** | renderer enabled |
| `+0x3038` | `0x06e1e248` `str w22,[x8,#0x3038]`, w22 = `1` | **1** | frame interval |
| `+0x3184` | `0x06e1e4e0` `str x10,[x9,#0x38]`, x9 = base+0x3148, x10 = `0x00001c1a_01010000` | **`0x1C1A`** | marker-type mask |
| `+0x293B` | `0x06e1d518` `str w12,[x10,#0x2938]`, w12 = `0x00010101` | **0** | Cmd 1141 BeMark tips |

`0x1C1A` = bits **1, 3, 4, 10, 11, 12** =
`Skill_Moco`, `Skill_Shirou`, `Skill_Otho`, `Skill_SantinoDummyDie`,
`Buff_IceWallModuleMark`, `SensorBeaconXRay`.
**Bit 1 — Moco — is in the default set.** A function named
`UpdateMocoMarkPoint2` whose gate mask defaults to a set containing exactly
`EMarkerType_Skill_Moco` settles the identification.

> These are `GameVarDef` statics, so the shipped values come from CSV /
> hot-update, not the binary (`docs/GAME_CLIENT_CONSTANTS.md` §"Config caveat").
> The numbers above are the compiled-in fallbacks.

### 6b. On-screen enemy point — `UIInGameScene::OnSyncCommonMarkInfo` @ **`0x07a08590`**

Driven directly from the Cmd 970 handler (`0x07a1fec0`), reading the **message**,
not the dictionary. Per entry:

```asm
0x07a088f4  ldrb w1, [x22, #0x18]        ; entry.markerType
0x07a088f8  bl   UIInGameScene::GetMarkType          ; 0x07a084b4
0x07a08900  ldrh w9, [x22, #0x1c]        ; entry.scannerMask
0x07a0890c  ldrb w5, [x22, #0x18]
0x07a08910  cmp  w9, #0
0x07a08918  cset w4, ne                  ; isScannerMark = scannerMask != 0
0x07a08920  mov  w2, #0x7fffffff         ; endServerTime  <-- no expiry
0x07a08934  bl   COW.HUD.UIHudEnermyPointController::RefreshMark
```

Signature (dump.cs 1133760, structure only — matches the register usage exactly):

```csharp
RefreshMark(EntityId pID, int endServerTime, MarkEnemyType markType,
            bool isScannerMark = false, EMarkerType commonMarkerType = 0)
```

Also reached in the same function: `::BindEnermy` @ `0x06b7bbc4` and
`::UnBindEnermy` @ `0x06b7bfd4`. The controller binds to the enemy's **entity
id**, so the on-screen indicator tracks the enemy live.

`GetMarkType` @ `0x07a084b4` is a jump table at `.rodata` **`0x0192d5b4`**
(13 × `int32`; `.rodata` is file-offset-identity in this image, do **not** apply
the `.text −0x4000` rule):

```
EMarkerType  2 Skill_Clu                  -> MarkEnemyType 7  ScannerMarker
             3 Skill_Shirou               -> 2  DeliveryMarkEnemy
             4 Skill_Otho                 -> 6  SlowdownMarkEnemy
             5 Skill_Iris                 -> 4  MarkIceWallNearbyEnemy
             6 Skill_IrisBeMark           -> 4  MarkIceWallNearbyEnemy
             7 Pet_Dreki                  -> 3  MarkCuringEnemy
             8 PersonalUAV                -> 7  ScannerMarker
             9 OverHeight                 -> 8  BanHighZone
            10 Skill_SantinoDummyDie      -> 9  SantinoDummyDie
            11 Buff_IceWallModuleMark     -> 10 IceWallModuleBuffMark
            12 SensorBeaconXRay           -> 0  Hint
            13 SFRoleplayPhantom          -> 11 SFRolePlayPhantom
            14 Skill_DreamlandBoyPetBreak -> 12 DreamlandBoyPetBreak
```

Out-of-range (`w8 = m − 2`, `cmp #0xc`, `b.hi`) → `0`. So **Moco (1) maps to
`MarkEnemyType.Hint`**, the generic marker sprite; the Moco-specific art is the
map point in §6a, not the HUD point.

### 6c. Not an X-ray

X-ray / see-through-walls is a **separate** subsystem: `message.PHPPOOPDMCD`
(`EXRayUID_AuroraBoy`, `_SensorBeacon`, `_EclipseMan`, …), `CKMIIAEOOKD::XRayShader`,
`Player::get_m_XRayFlushedPlayerIds`, `GameModeSetting::XRay_ColorMinAlpha`.
`EMarkerType_Skill_Moco` is not an `EXRayUID`. **Moco's mark does not render a
silhouette through geometry** — it is a map dot plus a HUD hint. That matches the
live game.

---

## 7. `EPRI_PLAYER_SIGHTING_ID` is a red herring — do not chase it

`message.NIPHKJAOKGI::EPRI_PLAYER_SIGHTING_ID` (`dump_names.txt:37849`) is **not**
"this player has been sighted/revealed". In this codebase **"Sighting" means
aim-down-sights**, and the property carries the scope/sight in use so remote
clients render the right ADS pose. Evidence:

* `COW.ItemUtil::IsSightingTelescope`
* `COW.GamePlay.Player::get_IsSighting` / `set_IsSighting` / `GetSightingState`
* `COW.UIHudCrosshairsController::TurnOffSighting`, `OnSightingFired`
* `COW.EAimAssist::OffOnSighting`, `EUIGroup::UIGroup_Sighting`
* `PlayerAttributes::get_SkillScatterRateSighting`
* `Player::RequestUnSightIfNeed` / `RequestBackToSightingIfNeed`
* `GameVarDef::ShowDashWhenSighting`, `FixSightingCameraWallPierce`

There is **no** EPRI property for being marked. Cmd 1900 will never tell you who
is tagged. Hypothesis (B) is dead.

---

## 8. Adjacent systems that are *not* this one

Listed so the next reader does not re-walk them. (The message-surface survey
covers these ids in depth; this is only the mechanism separation.)

| id | name | mechanism |
|---|---|---|
| **254** | `RUDP_SYNC_MARKED_ENERMIES` (`DHCNILPAODO`, 2 fields) | the **MarkState** family — handler `0x07a6828c` calls `PlayerAttributes::ClearMarkState` @ `0x07c42bc8`. Enum `PlayerAttributes.NHJPEJNGDHE` = `DeliveryMarkEnemy`, `SanitinoBombMarkEnemy`, `SlowDownMarkEnemy`. Writers `AddMarkState` @ `0x07c4291c`, `RemvoeMarkState` @ `0x07c42ae8`. Different storage, different consumers. |
| **351/352/669/1726** | `RUDP_DETECTIVE_*` | the Detective character's channelled scan. Handler 351 @ `0x07a7f020` → `Player::GetSkillByType` + a game-event dispatch; UI in `UIMapContentController::OnDetectiveMarkEnemy`, `UIHudSkillShowPanelController::*DetectiveScan*`. |
| **165** | `RUDP_UAV_REVEAL_PLAYERS` (`OHJJAMDGCGD`) | UAV reveal; `EMarkerType_PersonalUAV` (8) is the *common-mark* face of a related feature but 165 is its own handler `FFMOIGKIEPE.PBODLCIKJOG`. |
| **148/551/957** | map ping | player-placed map pins (`UIBigMapController::SendMapMarkChanged`). Only C2S mark-ish traffic that exists. |
| **1141** | `RUDP_S2C_Sync_Common_BeMark_Info` | same family as 970, victim side, UI only (§2). |

---

## 9. What this means for this tool

### Reading it: free, and already in reach

Cmd 970 is reliable/TEA — the same class of body the tool already decrypts for
Cmd 1900. Decoding it yields, for the local player, **the set of enemy entity
ids currently revealed to us, with the reason**. Cheap to add to the dumper and
to the ESP as a "confirmed-marked" flag.

Caveat on value: 970 only arrives when somebody actually marks. It is not a
general position source — but §6a proves the *game* treats it as a live position
feed, so the entity ids it names are worth cross-referencing against the
Cmd 2001/1900 state the tool already tracks.

### Producing it: the three options, honestly

1. **Local-only, zero network (cheapest, and what the brief hoped for).**
   Our overlay already draws its own ESP. Rendering a "marked" style on a chosen
   entity is a pure `EspRenderView` decision, needs no packet, and is invisible
   to the server. This is not the *game's* mark — it is our own overlay — but for
   "visible only to me" it is complete, free and risk-free. *(No Java was changed
   for this document.)*

2. **Make the game itself draw it: rewrite an inbound packet into a Cmd 970.**
   Architecturally within what this project has already cracked — inbound
   reliable bodies are TEA-decryptable with the relayed `SECRET_KEY`
   (`docs/PROTOCOL_CIPHER.md`, `ff-key-is-on-the-wire`), CRC7 is solved, and
   970's body is not covered by the `GFHPFJMGEKF` nonce
   (`docs/CHECKSUM_GFHPFJMGEKF.md`). It is a **rewrite, not an injection**: the
   server-minted OrderID is preserved, so the never-inject rule is respected.
   **Untested — no capture of Cmd 970 exists yet.** Known costs: it destroys
   whatever the carrier packet was delivering; and the effect is *cosmetic
   only* — the server's own mark state is untouched, so the `GetSkillDamageScale`
   bonus (§5) and teammate visibility do not follow.

3. **Whole squad: not reachable.** 970 is addressed to a single viewer and we
   only sit on our own link. Making teammates see a mark requires the server to
   decide it, which requires a hit the server accepted — out of scope.

There is **no** message the game already sends that could be rewritten into a
mark *request*: none exists in either direction.

---

## 10. Open questions, and the exact test that would settle each

| unknown | test |
|---|---|
| Is `CCMIGEAPLPC` really the **viewer**? The code is consistent with it, and the 970/1141 split plus §6a's use of the *local* player's dictionary make it near-certain, but the handler's own `!=` check is vacuous (it looks the player up *by* that field), so the binary cannot close it. | Capture a match with a Moco on the team. Every Cmd 970 should carry our own entity id in field 1. If it ever carries someone else's, 970 is broadcast and the marks of other players are readable too — which would be a much larger intel win. |
| Is Cmd 970 unicast or broadcast? | Same capture. Count 970s in a match with no Moco present: should be zero. |
| Exact meaning of `scannerMask` (+0x1C). Proven to be a mask whose non-zero-ness becomes `isScannerMark`; `Player::IsScannerMark` @ `0x07163d30` reads `+0x2C`, but has **no BL xref** in this build (IFix-patchable only), so its semantics are unconfirmed. | Capture with a Clu / PersonalUAV present and diff `+0x1A` against `+0x1C`. |
| Whether `ReadByte` is a raw byte or a varint on the wire. Values 0–15 make it unobservable here. | Any 970 capture: the marker-type byte should be exactly one byte. |
| Moco's actual trigger condition and duration (hit type? distance? seconds?). | **Not determinable from the binary at all** — it is server-side and/or CSV. Only in-game measurement or a server-config leak would give the numbers. |
| Whether `RUDP_C2S_AuroraBoyXRayedPlayer` (id enum `message.KLINFKFBIKB`) is actually sent. | It has **no send site** in `ff_outbound_registry_full.txt`. If it were live it would be the one precedent for a client naming whom it revealed — worth a targeted re-scan before believing it is dead. |

---

## Appendix — address index (our image, `libil2cpp_dec.so`)

| symbol | RVA |
|---|---|
| `message.DEIINJIGKAC::UnSerialize` | `0x04f6e960` |
| `message.DCNGPGPCDHG::Serialize` | `0x04f6ea20` |
| `message.DCNGPGPCDHG::UnSerialize` | `0x04f6ebe4` |
| `COW.GamePlay.FFMOIGKIEPE::HEABPKIIPGG` (Cmd 970 handler) | `0x07a1fe08` |
| `COW.GamePlay.FFMOIGKIEPE::KMBLGNINOMM` (Cmd 1141 handler) | `0x07a1ffa4` |
| `COW.GamePlay.FFMOIGKIEPE::CJCDICCKJKB` (Cmd 254 handler) | `0x07a6828c` |
| `COW.GamePlay.FFMOIGKIEPE::BABEJDGGJJC` (Cmd 351 handler) | `0x07a7f020` |
| `COW.GamePlay.Player::OMALDCHELHM` (dict getter) | `0x071610f0` |
| `COW.GamePlay.Player::GetCurCommonMarkInfos` | `0x071611b4` |
| `COW.GamePlay.Player::ClearCommonMark` | `0x07161204` |
| `COW.GamePlay.Player::RefreshCommonMark` | `0x071612ec` |
| `COW.GamePlay.Player::LIDKCJCCLLH` (change notify) | `0x07162660` |
| `COW.GamePlay.Player::ClientMarkPlayer` | `0x071629d0` |
| `COW.GamePlay.Player::IsMarkTarget` | `0x07163b04` |
| `COW.GamePlay.Player::HasMarkerType` | `0x07163be0` |
| `COW.GamePlay.Player::IsScannerMark` | `0x07163d30` |
| `Player.BKIDLEFNNJA::DJOFEJBPMBA` (has type) | `0x071f8ae0` |
| `Player.BKIDLEFNNJA::HPMKAKMLBBO` (has any of mask) | `0x071f8b4c` |
| `COW.UIMapContentController::UpdateMocoMarkPoint2` | `0x0425b25c` |
| `COW.UIMapContentController::Update` | `0x04255960` |
| `COW.UIMapContentController::EnableBigMap` | `0x04295df0` |
| `COW.UIInGameScene::GetMarkType` | `0x07a084b4` |
| `GetMarkType` jump table (`.rodata`) | `0x0192d5b4` |
| `COW.UIInGameScene::OnSyncCommonBeMarkInfo` | `0x07a0812c` |
| `COW.UIInGameScene::OnSyncCommonMarkInfo` (thunk / body) | `0x07a0852c` / `0x07a08590` |
| `COW.HUD.UIHudEnermyPointController::BindEnermy` | `0x06b7bbc4` |
| `COW.HUD.UIHudEnermyPointController::RefreshMark` | `0x06b7bcc8` |
| `COW.HUD.UIHudEnermyPointController::UnBindEnermy` | `0x06b7bfd4` |
| `COW.GamePlay.PlayerAttributes::AddMarkState` | `0x07c4291c` |
| `COW.GamePlay.PlayerAttributes::RemvoeMarkState` | `0x07c42ae8` |
| `COW.GamePlay.PlayerAttributes::ClearMarkState` | `0x07c42bc8` |
| `COW.GamePlay.PlayerAttributes::GetSkillDamageScale` | `0x07c43224` |
| `COW.GamePlay.BHGGAEEHJCO::LMCLIKOCCJM` (uint→EntityId) | `0x07c49ca4` |
| `COW.GamePlay.BHGGAEEHJCO::PDJKLNDADFO` (op_Inequality) | `0x07c49d34` |
| `COW.GamePlay.EMKJHAJNPDH::ADNMDEDAEGN` (find entity) | `0x0725ed14` |
| `COW.GamePlay.EMKJHAJNPDH::AJHEEFGLACI` (calls ClearCommonMark) | `0x07281af4` |
| `GCommon.FastBinaryReader::ReadUInt32` | `0x0828fba4` |
| `GCommon.FastBinaryReader::ReadVariant` | `0x0828fbb4` |
| `GCommon.FastBinaryReader::ReadInt16` (zigzag) | `0x0828fc4c` |
| `GCommon.FastBinaryReader::ReadUInt16` | `0x0828fc6c` |
| `GCommon.FastBinaryReader::ReadByte` | `0x082902fc` |
| `COW.GameVarDef::.cctor` | `0x06e183b4` |
| `message.FJKNMFDDMMI::Serialize` (Cmd 248) | `0x04cac15c` |
| `COW.GamePlay.AttackableBaseLevelObject::TakeDamage` (reference anchor) | `0x0703c2cc` |

**Player field:** `commonMarkInfos` (`OLHNHFEKGPP`) at **`+0x15F0`**
(dump.cs, other build, says `0x15D8` — do not use that value here).

**GameVarDef statics:** `+0x3038` interval, `+0x303D` enable, `+0x3184`
marker-type mask (default `0x1C1A`), `+0x293B` BeMark-tips enable (default 0).

### Provenance flags

Claims resting on `dump.cs` (**different build — structure only**) and not
independently confirmed in our image: the field *names* and declared C# types of
`DCNGPGPCDHG` / `DEIINJIGKAC` / `Player.BKIDLEFNNJA` / `Player.AKCKCJHBEKD`, and
the parameter names of `RefreshMark`, `BindEnermy`, `ClientMarkPlayer`,
`DJOFEJBPMBA`, `HPMKAKMLBBO`. Every **offset, order, width and control-flow
claim** above was read out of `libil2cpp_dec.so` directly. No `dump.cs` RVA is
used anywhere in this document.
