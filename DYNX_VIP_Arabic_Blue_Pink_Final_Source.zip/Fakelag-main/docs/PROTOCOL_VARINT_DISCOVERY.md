# Free Fire wire format — varint framing (verified 2026-09-10)

> **HISTORICAL — the varint finding itself still holds, the surrounding detail does not.**
> Read [`PROTOCOL_MASTER.md`](PROTOCOL_MASTER.md) for the current wire format.
>
> Specifically superseded here: the body offset is NOT fixed (it follows a 4- or
> 5-byte handle varint), entity records are NOT a pure varint run (bytes 7/8/9 are
> fixed-width pose fields), and the scale is 950 u/m, not the figures quoted below.


> **Supersedes the fixed-offset field maps in `docs/PROTOCOL_KNOWLEDGE.md` §4 and §5
> and the whole of `captures/REPORT_blob_grammar.md`.**
> Everything below was derived and cross-validated on
> `captures/phone_pull11/capture_raw_20260910_131508.txt` (347 s live match,
> 24 206 records) and re-confirmed on
> `captures/phone_pull9/capture_raw_20260909_223724.txt`.

---

## 0. The one-line summary

The game body is **not** a struct of 16-bit little-endian fields. It is a
**fixed-schema stream of LEB128 varints** (protobuf-style, but *untagged* —
field identity is positional). That single fact explains every anomaly the
earlier analysis hit:

| Old symptom | Real cause |
|---|---|
| "packet length varies with state (57 idle / 58-61 moving)" | varint width grows with the magnitude of the values — same 23 fields every time |
| "b30 airborne flag takes 200 distinct values in a real match" | fixed offsets drift as earlier varints change width |
| "facing pair folded to [0°,90°], sign bits missing" | the direction is a **float32 triple**, signs included; the old read was chopping varint bytes |
| "enemy blob record boundaries shift; scan for anchor bytes" | blob = repeated varint entity records, no fixed offsets exist |
| "b12-29 identity block frozen" | it *is* the first entity's position record, frozen when that entity stands still |

---

## 1. Frame layout (all UDP payloads)

```
b0        small rolling counter
b1        per-packet nonce (7-bit)
b2 .. b7  6-byte header window, XOR-masked with the per-session mask
b8 .. b11 connection/stream token (frozen per session+family)
b12 ..    BODY - untagged LEB128 varint stream (plaintext, no mask)
```

### 1.1 The mask (unchanged, still correct)

Per-session 6-byte XOR at b2-7, identical both directions and all families.
Recovered as the **mode of OUT/24 bytes 2-7**, because **OUT/24 decodes to
all zeros there** — that is *why* it is a perfect oracle, and it is also why
the mask is recovered correctly regardless of the rotation below.

### 1.2 CORRECTION — the header window rotates per session

The decoded b2-7 window holds three 16-bit LE fields:

```
[flags16] [length16] [channel16]
```

* **`length16` = UDP payload length + 8** (the UDP datagram length including
  the 8-byte UDP header) — *not* `plen + 2`.
* `channel16` observed values: `0x0001`, `0x07D2` (2002).
* The three fields are **cyclically rotated inside the 6-byte window by a
  per-session constant**. Measured positions of the length low byte:
  **b4** (`131508`), **b3** (`0908_105542`), **b5** (`0908_205830`),
  **b6** (`0908_083222`, `0908_084244`, `0908_090524`).

So `pt[3] == plen + 2` in `PROTOCOL_KNOWLEDGE.md` §2 is wrong on both the
offset and the constant. **Mask validation must scan b2-7 for `plen + 8`**,
not test one fixed index:

```python
for j in range(2, 8):
    if (wire[j] ^ mask[j-2]) == ((plen + 8) & 0xff):
        length_lo = j     # session constant; confirm over >100 packets
```

### 1.3 Varint reader

```python
def varints(buf):                 # None if the buffer is truncated mid-varint
    out, i = [], 0
    while i < len(buf):
        v = s = 0
        while i < len(buf):
            c = buf[i]; v |= (c & 0x7f) << s; i += 1; s += 7
            if not (c & 0x80): break
        else:
            return None
        out.append(v)
    return out
```

---

## 2. OUT keepalive 50-63 B — own state — **23 varints, 100 %**

`varints(payload[12:len])` yields **exactly 23 values for 3427 / 3430
keepalives** in `131508` (the 3 failures are packets clipped by the 64-byte
hex limit) and **1068 / 1069** in `223724`. Header `b8-11 = 81808008`.

| Field | Meaning | Evidence |
|---|---|---|
| **f0** | **World X** | 94 378 – 974 349; smooth, +132/100 ms while walking |
| **f1** | **World Z (height)** | 6 344 – 37 664; frozen on flat ground; rises 8566 -> 9728 through the parachute arc |
| **f2** | **World Y** | 152 – 786 734; smooth |
| f3-f7 | quantised 0-200 state values (stance / lean / health-ish) | hard-capped at 200 |
| f8, f9, f10 | 0-1560 / 0-3667 / 0-1358 — velocity or angle triple | all three swing together during the jump arc |
| **f11** | **airborne flag** | strictly {0,1}; = 1 for the whole parachute descent |
| f12 | state enum, 6 values, max 13 | = 11 during parachute, = 8 on foot |
| **f13, f14, f15** | **float32 unit direction vector (x, y, z)** | `|v| = 1.000000` for **100 %** of records in both captures |
| f16, f19, f20, f21 | always 0 | reserved |
| f17, f18 | 0/1 flag; 1-427 (44 values) | weapon / loadout-ish |
| **f22** | **millisecond tick** | +99 per packet; span / wall-clock ratio = **1.0000** over 347 s |

Read a float field with `struct.unpack('<f', struct.pack('<I', v))[0]`.

### 2.1 This closes Open Question #2

`PROTOCOL_KNOWLEDGE.md` §9.2 asked where the facing quadrant signs live.
They were never missing — **f13/f14/f15 are a signed, normalised 3-D view
vector**. No folding, no `atan2` reconstruction, no inference. Full yaw and
pitch are directly available (confirm axis order against a pitch-up test):

```
yaw   = atan2(f13, f15)
pitch = asin(f14)
```

The old claim that *"camera-only movement changes NOTHING in the keepalive"*
is also wrong: at t = 119.0-119.4 s the position triple is bit-frozen while
the direction vector sweeps `(-0.929,+0.274,+0.251)` -> `(-0.976,-0.045,+0.212)`.
The old fixed-offset decoder simply could not see it.

---

## 3. IN 100-170 B "slot blobs" — enemy state

The blob body is **a run of entity records in the same coordinate schema**:

```
b10        first entity id
then, repeating:
  [X varint][Z varint][Y varint][a][b][c][d] 00 00 00 00 00 00 [next entity id]
```

Worked example, blob at t ~ 990 ms, len 153:

```
... 03 | 93F531 FC76 BE8B16 A804 00 A704 5F 000000000000
    04 | F7F531 FC76 AEBA16 A804 00 A704 5F 000000000000
    05 | DBF631 FC76 9AE916 A804 00 A704 5F 000000000000
```

decodes to

| id | X | Z | Y |
|---|---|---|---|
| 3 | 817 811 | 15 228 | 361 918 |
| 4 | 817 911 | 15 228 | 367 918 |
| 5 | 818 011 | 15 228 | 373 914 |

— three entities on one ground plane, 100 units apart in X and ~6 000 in Y.

### 3.1 Cross-validation against own position

Parsing the first record of every blob in `131508` and comparing to the
time-aligned keepalive:

```
        X range          Z range        Y range
own     94378..974349    6344..37664    152..786734
ent2    61497..883931    6446..38172   31742..862145
ent3     8276..916231    6562..32598      51..864763
ent4    60141..913877    6446..33940   52478..862143
ent5    58349..887267    6344..39536   26188..866421
ent6       15..973001     256..39852    2578..788582
ent7      241..974571     934..41086    1041..810393
ent8        0..971933    6342..39032     269..779038
```

**Identical ranges in all three axes — same world frame, same units, no
transform needed.** Median enemy distance: ent6/7/8 sit at 17-26 ku
(~73-112 m at the 236 u/m estimate), ent2-5 at 127-154 ku. Plausible BR
geometry. Entity tracks are smooth: ent4 runs
821 599 -> 821 187 -> 819 003 -> 817 911 -> 817 623 over 2 s.

### 3.2 What this retires

`captures/REPORT_blob_grammar.md` is superseded. Specifically:

* "b12-13 BE = enemy X, b17-18 BE = Z, b23-24 BE = third axis" — those were
  byte windows that happened to straddle the real varints. The real X/Z/Y are
  the **first three varints after the entity-id byte**, LEB128, not BE16.
* "records at variable offsets, scan for doubled-byte flag anchors
  (B5B5, 3535, C1C1 …)" — those pairs are multi-byte varints seen through the
  wrong lens.
* "b11 = checksum over b12-29" — b11 is the first byte of the first entity's
  X varint.
* "Y (height) NOT FOUND" — **found**: the second varint, 6 342-39 852,
  exactly the own-height band.
* "byte 10 = slot index (7 multiplexed entities)" — b10 is the **first entity
  id in the chain**; each blob carries a run of them, so "7 slots" was really
  "7 entity ids seen".


### 3.3 The blob entities are players (7 concurrent tracks)

Per-entity step statistics over the 343 s match, first record of each blob:

```
 id    n    frozen%  step_p50  step_p90   total_path
 B2   210     45%       535     11325      3 073 508
 B3   289     37%      1923     15649     11 108 886
 B4   170     43%       962     19665      3 010 051
 B5   224     40%      1194      9722      3 006 513
 B6   216     23%      1801     14923      3 261 892
 B7   192     13%      2648     21876      3 622 904
 B8   202     33%      1984     17120      5 244 973
```

Seven ids, stable for the whole match, moving at walking pace between updates.
Refresh gap per entity: **p50 600-1200 ms, p90 2-4 s** (~1 Hz). That is a
periodic full-state sync; the high-rate movement almost certainly lives in the
encrypted IN/26 / IN/34 / IN/42 streams (3967 / 1721 / 1457 packets vs 1549
blobs). So a packet ESP sees enemies at roughly 1 Hz unless those streams are
broken or the positions are dead-reckoned between syncs.

---

## 4. IN 39 / 40 / 41 B — per-entity state stream — **20 varints, 100 %**

> **CENSUS CORRECTION (2026-09-10, captures\REPORT_entity_census.md — this
> section's header interpretation was OFF BY ONE and is superseded):**
> there is no `00 02 01 handle` header. These packets are CHAIN0001
> single-record chains: b8=00 (family), **b9=02 = 2×1 record (the count
> oracle)**, **b10 = the entity ID (= 01, the 8th enemy!)**, and b11 is
> the FIRST BYTE of the X varint (varints start at b11, not b12). The
> "20 varints from b12" read below was X's tail + everything else. The
> census's definitive parse: 8 entities ids 01-08; id 01 = this 38-46 B
> stream at 5.00 Hz (the richest entity), ids 2-8 in the multi-record
> chains at ~2 Hz. The "mostly frozen handles / world objects" reading
> below was an artifact of the off-by-one. Unified tracker grammar and
> the phantom filter: REPORT_entity_census.md §2/§7/§8 (implemented in
> EspEngine.observeChainPacket).

1260 / 1260 parse to exactly 20 varints from b12. Header `b8-11 = 0002 01 XX`
where **`XX` is the entity handle** (`AA`, `FD`, `DB`, `BC`, …).

Same leading schema as the keepalive: **g0 = X, g1 = Z, g2 = Y**, then state
fields, `g11` bool, `g12` the same 6-value enum, `g19` a tick (+6 per ~198 ms).
Cadence ~5 Hz per entity.

This is a second, independent position channel and is never truncated (39-41 B
fits inside the 64-byte hex limit). **It is mostly world objects, not players**:
the high-count handles are 94-99 % frozen (S170 217 samples / 99 % frozen,
S188 80 / 99 %, S253 103 / 94 %) with occasional teleports. A few handles do
move (S219, S187, S133 travel 1.2-1.4 Mu over the match) so it is a mixed
object/vehicle/player channel. **The blob channel is the reliable player
channel** — see §3.3.

---

## 5. What is genuinely encrypted (unchanged)

Families whose bodies fail varint parsing about half the time — real
per-packet keystream, matching the avalanche evidence in
`PROTOCOL_KNOWLEDGE.md` §6:

| Family | parse failures |
|---|---|
| OUT/24 input stream | 3435 / 7115 |
| IN/26 | 2045 / 3967 |
| IN/34 | 738 / 1721 |
| IN/42 | 656 / 1457 |
| IN/50 | 159 / 295 |

A ~50 % failure rate is what random bytes give (a random stream happens to
terminate on a byte boundary roughly half the time). These are not varints.

---

## 6. Immediate consequences

1. **Raise `hexLimit` from 64 to ~200.** Every 100-170 B blob in the current
   captures is still truncated (`1549 / 1549` in `131508`), so only the first
   1-3 entity records per blob are visible. `PacketCapture.MAX_PAYLOAD_BYTES`
   is already 2048, so only the dump limit needs changing.
2. **`EspEngine.observeKeepalive` / `observeBlob` read fixed byte offsets**
   (`le16(data, off+12)`, BE16 at b12-13 / b17-18 / b23-24). Those offsets are
   meaningless under varint framing — the live ESP numbers go wrong whenever a
   value crosses a varint width boundary, which in a real match is constant.
   Both need the varint reader.
3. **`DecodedDumper`'s `ka_*.csv` / `blob_*.csv` columns are misparsed** for
   the same reason; the `f*_b12`-style headers should become `f0..f22`.
4. **Nothing about the mask, the ghost filter, or the freeze logic changes** —
   those key off lengths and directions, not body fields.
5. `blob_20260910_131509.csv` was never pulled off the device (only `ka_` and
   `streams_` are in `captures/phone_pull11/`) even though the summary shows
   1503 slot blobs. Worth pulling.
6. Captures taken at `hexLimit = 32` (everything before pull9) cannot be
   varint-parsed for the 45-64 B keepalives at all — the body is cut off.
   Only pull9 / pull11 are usable for body work.

---

## 7. Minimal decoder

```python
import struct

def varints(buf):
    out, i = [], 0
    while i < len(buf):
        v = s = 0
        while i < len(buf):
            c = buf[i]; v |= (c & 0x7f) << s; i += 1; s += 7
            if not (c & 0x80): break
        else: return None
        out.append(v)
    return out

f32 = lambda v: struct.unpack('<f', struct.pack('<I', v & 0xffffffff))[0]

v = varints(payload[12:plen])            # OUT 50-63 B keepalive
assert len(v) == 23
x, z, y  = v[0], v[1], v[2]
dir_vec  = (f32(v[13]), f32(v[14]), f32(v[15]))   # |dir| == 1.0
airborne = bool(v[11])
tick_ms  = v[22]
```

---

# Addendum — capture 150701 (Clash Squad 4v4, 346 s, 25 892 packets)

Everything below is measured on
`captures/phone_pull12/capture_raw_20260910_150701.txt`.
Session mask `213020202220`; **header rotation put the length low byte at b3**
(it was b4 in capture 131508) — see §A1, this broke the live tracker.

## A1. The rotation bug (critical)

`EspEngine.observeChainPacket` identified the entity carrier with
`unmasked b2 == 0x00 && b3 == 0x01`. Those offsets are inside the **rotating**
header window, so the test only holds for one rotation. In this session it
matched **zero** packets and the entity tracker was silently dead.

**Fix:** key off `b8 == 0x00` and `b9` even (`b9 = 2 x record count`). Both sit
outside the mask window and are rotation-independent. With the fix the same
capture yields **12 161 entity records across 8 ids at 3.8-5.05 Hz each**.

Rule: never use b2-b7 for family identification. Use b8/b9, or de-rotate first.

## A2. Entity 1 is the local player — the frame question is settled

The server echoes your own state back as an entity record. At matched
timestamps entity 1's X/Z/Y are **byte-identical** to the keepalive
(e.g. `362522 / 30492 / 105572` on both sides); across 1746 paired samples the
median offset is 178 / 2 / 90 units and 86 % sit within 2000 u — the residual is
just the ~100 ms echo delay.

**Therefore enemy records share the own coordinate frame exactly: same axes,
same units, same origin. The identity mapping is correct; no transform.**
This refutes `REPORT_entity_census.md` §2's "scale/frame unresolved" — that
analysis never tested entity 1 against own position.

## A3. Units per metre = 1670

Two independent estimates, agreeing within 1 %:

| Method | Value |
|---|---|
| own horizontal speed p95 (10 812 u/s) / 6.5 m/s sprint | 1663 u/m |
| median airborne Z rise (1678 u) / a ~1 m hop | 1678 u/m |

The old **236 u/m was wrong by ~7x** (it came from the superseded fixed-offset
decode). Sanity check: at 1670 u/m the four enemies sit at median 62-90 m and
the three teammates at 7.5-16.2 m — correct for Clash Squad.

## A4. Camera forward = −(v13, v14, v15)

The decoded unit vector points **backward** along the view. Two independent
confirmations:

1. **Sustained runs** (945 samples > 3 m/s): the histogram of
   `movement heading − atan2(dirX, dirZ)` spikes at **180°** — 24 % of samples
   in the 170-190° band against a ~2 % flat background.
2. **Projection test** (2275 enemy sightings inside 60 m, full view matrix):

   | sign | in front of camera | on screen | near crosshair |
   |---|---|---|---|
   | **−1** | **71 %** | **53 %** | **36 %** |
   | +1 | 29 % | 22 % | 10 % |

   A 3.6x separation on the crosshair metric. Players face the fight.

So `yaw = atan2(−dirX, −dirZ)`, `pitch = asin(−dirY)`.

## A5. Friend/foe by sustained proximity

8 entities = Clash Squad 4v4. Distance to the local player over the match:

```
 id   n     p10     p50     p90    <10m   <25m   role
 1    1747  (self — byte-identical to own)             SELF
 5    1581   0.9 m   7.5 m  38.5 m  54 %   80 %   TEAM
 8    1707   1.5 m  11.9 m  41.6 m  47 %   75 %   TEAM
 7    1725   3.0 m  16.2 m  62.6 m  38 %   62 %   TEAM
 3    1466  23.0 m  87.4 m 145.4 m   5 %   12 %   ENEMY
 4    1261  27.6 m  61.7 m 123.7 m   2 %    7 %   ENEMY
 6    1287  33.0 m  90.0 m 122.8 m   2 %    5 %   ENEMY
 2    1387  33.3 m  77.3 m 155.9 m   0.4%   1 %   ENEMY
```

Clean separation. The shipped classifier (`EspEngine.classify`) uses
self < 3000 u on >50 % of samples, teammate < 25 m on >40 %, else enemy — and
reproduces this table exactly on replay.

## A6. Encryption — the complete picture

| Family | varint parse | consecutive byte-diff | Verdict |
|---|---|---|---|
| OUT b8=81 (own keepalive, 52-60 B) | 100 % | 0.05-0.41 | **plaintext** |
| IN b8=00 (entity chains, 39-167 B) | 100 % | 0.07-0.48 | **plaintext** |
| IN b8=4C len 26/34 | 46-53 % | **0.92-0.94** | per-packet keystream |
| IN b8=0D len 34 | 49 % | 0.95 | per-packet keystream |
| IN b8=5C / 59 len 42 | 53-58 % | 0.82 | keystream |
| OUT/24 input stream | ~48 % | — | hash-diffused |

So the "encryption" is two layers and neither protects what an ESP needs:

1. **A 6-byte session XOR mask on b2-7 only** — recovered free because OUT/24
   decodes to all zeros there, making the wire bytes *be* the mask. Plus a
   per-session cyclic **rotation** of the three header fields inside that
   window (obfuscation, not cryptography).
2. **A real per-packet keystream on the b8=4C/0D/5C/59 stream families**
   (~0.93 byte-diff = indistinguishable from random). Unbroken — but these
   carry no positions.

**Everything the ESP needs — own state and every entity position — is sent in
plaintext LEB128.** The only defence on it is the b2-7 mask, which is a
give-away.

## A7. Freeze verified server-side

During FREEZE phase: own position changed in only **10/188** keepalive
transitions, and the **server's own echo of us (entity 1) moved in just 4/96**
— direct proof the server believes you are standing still while you move.
