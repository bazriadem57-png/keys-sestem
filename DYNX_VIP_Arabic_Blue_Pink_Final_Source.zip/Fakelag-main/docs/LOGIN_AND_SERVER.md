# Login, server & config-delivery — protocol and client design

**2026-09-17.** The concrete design implementing `docs/SECURITY_MODEL.md`.
Backend ops live in `docs/SERVER_OPS.md`. This file is the contract between the
client and the server — change both sides together.

---

## 1. Shape at a glance

```
LoginActivity (launcher)
  └─ DeviceIdentity      Keystore keypair + device fingerprint
  └─ LicenseClient       POST /auth/activate | /auth/refresh | GET /version  (pinned OkHttp)
  └─ SessionManager      token lifecycle; refresh token Tink-encrypted on disk
  └─ ConfigStore         RAM-only Bucket-B blob (zeroizable), fed by /config
        └─ on success → launch MainActivity; engine refuses to start otherwise

VPS (FastAPI + SQLite behind Caddy/nginx, self-signed cert pinned by client)
  /auth/activate  /auth/refresh  /config  /version   + admin key-mint CLI (SSH-only)
```

Auth model: **license-key / redeem-code activation, device-bound,
online-required at launch.** Small paid userbase.

---

## 2. Identity & tokens

### Device fingerprint
On first launch the client generates an EC P-256 keypair in the Android Keystore
(`DeviceIdentity`; software fallback on API 21–22) and reads
`Settings.Secure.ANDROID_ID` (SSAID). The server computes and stores:

```
fingerprint = HMAC-SHA256(server_salt, SSAID ‖ device_pubkey_DER)
```

SSAID is per-(signing-key, device) since Android 8 and resets on factory reset;
root can spoof it. So the fingerprint is a **binding constraint AND an anomaly
signal**, never a hard guarantee. The audit log catches key-sharing (one license,
many fingerprints/IPs) and drives auto-throttle/suspend.

### Tokens
- **Access token** — JWT, Ed25519-signed, TTL ~10 min. Claims: `sub` (user/
  license), `lic` (license id), `tier`, `did` (device fingerprint id), `jti`,
  `exp`, `cfgv` (config version). Verified by signature + `exp` on each request;
  license status is **not** re-checked per call (kept cheap).
- **Refresh token** — opaque, random, stored **hashed** server-side with a
  `family_id`. Rotating: each refresh issues a new one and invalidates the old.
  Presenting an already-used refresh token = theft → revoke the whole family →
  force re-login (OWASP reuse-detection). License status **is** re-checked here,
  so revocation takes effect within one refresh cycle (≤10 min) — the kill switch.
- **Offline lease** — server-signed blob `{license_id, valid_until, status,
  lease_id}` verifiable with the server's *public* key. Lets the app start
  offline within the grace window (default 72 h) after a prior successful login.
  Clock-rollback on root can replay a lease inside its window; keep the window
  short and reconcile `lease_id` server-side on reconnect. This is the accepted
  residual risk of offline tolerance.

### Client token storage
Refresh token + lease stored **Tink-encrypted** (AEAD keyset under an Android
Keystore master key) in plain `SharedPreferences`/DataStore —
`EncryptedSharedPreferences` is deprecated (April 2025). Access token + decrypted
config live in RAM only. On a rooted device none of this defeats a memory dump;
it defeats offline APK+data extraction and non-root attackers, and the
short-lived + server-revocable design makes a stolen refresh token bounded and
detectable.

---

## 3. Endpoints

All over TLS to `https://66.154.107.27` (self-signed cert, SPKI pinned in the
client via OkHttp `CertificatePinner`). No domain yet; adding one later swaps the
pin and enables Cloudflare without a client rewrite.

### `POST /auth/activate`
Request: `{ license_key, fingerprint_inputs:{ssaid, device_pubkey}, app_version,
client_nonce }`
Server: hash-compare the key; check `status=active`, not expired; bind this
device if bound-count < `max_devices` (else `409 device_limit`); record device.
Response: `{ access_token, refresh_token, lease, tier, config_version }`.

### `POST /auth/refresh`
Request: `{ refresh_token, fingerprint_id }`
Server: validate + rotate (reuse-detection); re-check license status. Response:
new `{ access_token, refresh_token, lease, config_version }`, or `401` if revoked/
expired → client returns to login.

### `POST /config`  (Bucket-B delivery — see §4)
Request: `{ access_token, client_x25519_pub, client_nonce, section? }`
Response: `{ server_x25519_pub, wrapped_data_key, nonce, ciphertext,
config_version, expiry }`.

### `GET /version`
Response: `{ min_supported, latest, url? }`. Client below `min_supported` →
hard-block with an update prompt (forced-update / kill old builds).

### Admin (SSH/localhost only, not exposed)
A CLI: `mint --tier --devices --expiry`, `revoke <key|license>`,
`list [--devices]`, `rotate-config <version>`. Payments handled off-platform.

---

## 4. Config delivery (RAM-only, replay-proof, watermarked)

Per request:
1. Client sends a fresh **X25519 ephemeral pubkey** + nonce with its access token.
2. Server validates token + license, does **ECDH** (its own fresh ephemeral ×
   client pub) → **HKDF-SHA256** → per-session key.
3. Server builds the **per-user watermarked** Bucket-B blob for the caller's
   tier/version, generates a random **data key**, **AES-256-GCM**-encrypts the
   blob (fresh 96-bit nonce, AAD = `jti ‖ config_version ‖ expiry`), and **wraps
   the data key** with the session key.
4. Server records the one-time nonce/`jti`, returns the envelope.
5. Client derives the session key, unwraps the data key, decrypts into a
   **`byte[]` in RAM**, parses into `ConfigStore`, then **zeroizes** the buffer.
   Never written to disk, logs, or `onSaveInstanceState`. Re-fetched on resume;
   zeroed on background timeout and logout.

Replay dies: the client ephemeral private key is gone after the exchange and the
nonce/`jti` is spent. Ceiling: root+Frida can still hook the decrypt and dump
plaintext — hence the **watermark (traitor tracing)** + **versioned rotation**.

**Phase-1 blob contents:** `cmd_catalogue` (the 1974-id name table). Blob is JSON
`{config_version, wm, sections:{...}}` — encrypted end to end, so plaintext JSON
is fine. Sections are added independently as more knowledge is offloaded.

### Offload status (implemented + tested on-device 2026-09-17)

Two crown-jewel tables are withheld from the **release** APK via a per-variant
source set (full data in `src/debug`, EMPTY in `src/release`), so a jadx
decompile of the shipped build shows empty shells:

- **`CmdCatalogue`** (1974 ids) — extracted by `tools/offload_cmd_catalogue.py`
  into `server/bucket_b/cmd_catalogue.json` (served by `/config`) and
  `decode/body/CmdCatalogueData.java` (debug full / release empty). At login the
  blob is decrypted and pushed into `CmdCatalogue.loadServerNames`, which takes
  precedence over the variant fallback. **Verified:** debug dex contains the
  names, release dex contains 0.
- **`BodyDecoderTable`** (1604 wire layouts) — `tools/offload_body_layouts.py`
  → `decode/body/BodyDecoderTableData.java` (debug full / release empty). Its
  only consumer is the dev/capture annotator, which falls back to a positional
  decode when a layout is null, so release degrades gracefully. Not yet
  server-delivered (capture analysis is a debug-time activity); the section can
  be added to the blob later if release-build annotation is wanted.

**Release TODO before shipping:** fill `AuthConfig.SERVER_ED25519_PUB_HEX` (from
the VPS signing key, so the lease is actually verified) and `AuthConfig.CERT_PIN`
(the VPS cert SPKI). Until then a release build accepts the lease unverified and
does not pin.

---

## 5. Client packages (new)

- `auth/DeviceIdentity` — Keystore keypair, SSAID read, fingerprint inputs.
- `auth/LicenseClient` — activate/refresh/version over pinned OkHttp.
- `auth/SessionManager` — token + lease lifecycle, refresh scheduling, kill-switch
  handling; Tink-encrypted persistence. Exposes `isAuthorized()` + `tier()`.
- `auth/ConfigStore` — RAM-only Bucket-B holder; `byte[]` sections, zeroize().
- `net/Http` — OkHttp client with `CertificatePinner`.
- `net/Crypto` — Tink helpers: X25519 ECDH, HKDF, AES-256-GCM open, keyset mgmt.

`decode/body/CmdCatalogue` and `BodyDecoderTable`/`Text` lose their packed-string
constants and become thin accessors that read from `ConfigStore`; their
`dev/capture/*` consumers are unchanged behaviourally.

Deps added: `com.squareup.okhttp3:okhttp:4.12.0`,
`com.google.crypto.tink:tink-android:1.13.0` (verify current at build time).

---

## 6. Login screen (the "login design")

A gate before the main UI, in the **Nuvola design system** (`nv_*` tokens,
Sora/Manrope, dark, brand-gradient hero; plain `android.app.Activity`, no
AppCompat, no literal hex).

Layout `res/layout/activity_login.xml`:
- Brand-gradient **hero** (`nv_hero`/`nv_card_hero`) with the wordmark (Sora 600)
  and one-line tagline.
- A **license-key field** (paste-friendly, monospace `nv_mono` since it's a key)
  inside an `nv_card`, with a "this device" caption line under it.
- **Activate** primary button (`nv_btn_primary`, 48 dp+), disabled while a
  request is in flight.
- An **inline status row** (the four Nuvola state colours): teal = activated,
  amber = activating / device-limit-with-action, grey = idle, red = error.
  Never a Toast for the load-bearing states.

Flow: `LoginActivity` is the launcher. On start, if `SessionManager` has a valid
session or unexpired lease → launch `MainActivity` immediately (background
re-validate). Otherwise show the form. On successful activate → fetch config →
launch `MainActivity`. `MainActivity` and the VPN engine **refuse to start**
without `SessionManager.isAuthorized()` and a loaded `ConfigStore`.

Errors surface plainly: bad key, device limit (offer "deactivate another device"
where possible), network down (offer retry; fall through to a valid lease if one
exists), version too old (update prompt from `/version`).

---

## 7. Rollout flag

A build-time constant `AuthConfig.ENFORCE` (a `BuildConfig` field or a `static
final`). `false` during development runs the app in today's no-server mode so the
owner's phone keeps working; `true` enforces login + config. `/version` gives
forced-update / kill-switch from day one regardless.

---

## 8. Defaults (changeable — tracked in the plan's open-decisions list)

Devices/license **2** · lease grace **72 h** · access TTL **10 min** · one tier
to start · subscription expiry (kill-switch friendly) · license-key-only (no
email) with "lost key = contact owner" · watermark via per-user field-ordering +
embedded license token.
