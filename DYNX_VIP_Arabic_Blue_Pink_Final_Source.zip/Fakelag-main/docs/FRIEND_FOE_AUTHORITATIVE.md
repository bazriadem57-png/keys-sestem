# Friend / foe — the authoritative source, and why enemies render blue

> **PATHS IN THIS DOC PREDATE THE 2026-09-15 PACKAGE REORG.**
> `core/` is now `tunnel/`, `net/` split into `decode/{frame,crypt,body}` +
> `protocol/`, `overlay/` split into `ui/{render,overlay,panel,button,aim}`.
> See `docs/SOURCE_MAP.md` §2 for the full old-to-new table.

Research note, 2026-09-13. Written against a measured Battle Royale squad match
(`captures/pull_20260913b/`, 26+ players, 14 squads, 967 s, 31 360 chain
samples) with **Cmd 118 `RUDP_BIND_PRI` as ground truth**, plus a disassembly
pass over `C:\Users\Tonyt\Documents\FF-RE\bin\libil2cpp_dec.so`.

**No source file was changed.** This is a spec for the implementer.

---

## 0. The product decision this document assumes

The user has ruled: **an enemy must never be painted as a teammate. Red on a
friend is acceptable; blue on an enemy is not.**

This **inverts** the tradeoff currently documented in
`EspEngine.classify()` javadoc (`esp/EspEngine.java:1229-1234`) and in
`docs/PROTOCOL_MASTER.md` §5.1, both of which say *"a wrong colour is worse
than no colour"* and therefore allow a heuristic to promote to TEAM while
forbidding it from concluding ENEMY. That asymmetry is exactly backwards for
the new requirement, and it is the design decision that produced the bug.

It matters more than "a colour", because of
`overlay/EspRenderView.java:515` and `:1162`:

```java
public static volatile boolean SHOW_TEAM = false;      // default
...
if (role == EspEngine.ROLE_TEAM && !SHOW_TEAM) continue;   // not drawn AT ALL
```

and `overlay/EspRenderView.java:417` / `:1601`:

```java
public static volatile boolean AIM_TEAM_CHECK = true;  // default
...
if (AIM_TEAM_CHECK && role == EspEngine.ROLE_TEAM) continue;  // aim skips it
```

A false TEAM label therefore **deletes the box and makes the target
un-aimable**, not merely mis-tints it. `TEAM_STROKE_COLOR` is
`argb(225, 70, 190, 255)` — the blue the user reported
(`overlay/EspRenderView.java:651`).

---

## 1. Root cause

### 1.1 The verdict

**`classify()` rung 5 — the proximity promotion at `esp/EspEngine.java:1277` —
was calibrated on Clash Squad and Survival captures only, and its discriminator
is *inverted* in Battle Royale.** In the measured BR match it promoted **21
non-squad players to `ROLE_TEAM`**, permanently, accounting for **29.5 % of
every entity sample drawn on screen**.

```java
// 5. Proximity may only promote to TEAM. 22 entities promoted, 0 wrong.
if (t.updates >= 40 && t.closeSamples > TEAM_FRAC * t.updates) {
    t.role = ROLE_TEAM;
    return;
}
```
`TEAM_FRAC = 0.27` (`:455`), `TEAM_UNITS = 10 m` (`:451`).

### 1.2 The evidence

**Ground truth for the match.** Cmd 118 `RUDP_BIND_PRI` type-1 records give
`packedEntity = (squad << 24) | slot` for 26 players, squads 2..15, zero
conflicts (`captures/pull_20260913b/bind118.txt`).

**Own identity.** Chain entity **12** is the self-echo: its horizontal distance
to the Cmd 2001 keepalive position is < 5 m on **98.7 %** of 4 741 samples,
median 0.7 m. **Own squad is 9**, established three independent ways:

| evidence | detail |
|---|---|
| always-replicated set | exactly four entities stream continuously for the whole match: **12 (self), 37, 44, 51** |
| Cmd 118 | slots **37 and 44 are both squad 9** |
| cardinality | 4 members = one BR squad; the other two binds (12, 51) fell in the documented pre-key window (`docs/ESP_HEALTH_AND_NAMES.md` §4) |

**The measured discriminator, replayed against the real chain stream:**

| entity | Cmd 118 squad | truth | chain updates | fraction inside 10 m | rung 5 verdict |
|---|---|---|---|---|---|
| 12 | — (self) | SELF | 4 939 | 0.999 | self (correct) |
| **44** | **9** | **TEAMMATE** | 4 746 | **0.206** | would NOT promote |
| **51** | — | **TEAMMATE** | 3 884 | **0.183** | would NOT promote |
| **37** | **9** | **TEAMMATE** | 3 375 | **0.158** | would NOT promote |
| 11 | — | enemy | 329 | **0.888** | **-> BLUE** |
| 21 | — | enemy | 312 | **0.830** | **-> BLUE** |
| 9 | — | enemy | 328 | **0.771** | **-> BLUE** |
| 20 | — | enemy | 321 | **0.682** | **-> BLUE** |
| 1 | — | enemy | 334 | **0.686** | **-> BLUE** |
| 4 | — | enemy | 309 | **0.660** | **-> BLUE** |
| 13 | — | enemy | 320 | **0.641** | **-> BLUE** |
| **15** | **8** | **enemy (hard proof)** | 492 | **0.321** | **-> BLUE** |
| 48 | 13 | enemy | 199 | 0.417 | saved only by rung 4 |

**The three real teammates all score BELOW `TEAM_FRAC`; seventeen enemies score
above it.** The separation is not merely degraded in BR — it points the wrong
way. Entity 15 is the cleanest single item: Cmd 118 names it type 1, squad 8;
own squad is 9; the shipped rule paints it blue.

**Median horizontal separation from self** tells the same story, and directly
contradicts `docs/PROTOCOL_MASTER.md` §5.1's *"median same-team separation
15.7 m vs 67.1 m cross-team, AUC 0.889"*:

* real squadmates: **35.8 m / 43.0 m / 50.9 m**
* enemies 21, 4, 19, 1, 13, 20, 11, 9: **6.6 m – 9.8 m**

### 1.3 Why it inverts — the mechanism

Two BR-specific facts, both visible in the capture:

**(a) Interest management.** In BR the server replicates your own squad
continuously and everyone else only while they are in interest range. Measured
update rates (`captures/pull_20260913b/summary_20260913_145150.txt`, ENTITY
CENSUS):

| | rate | span | longest gap |
|---|---|---|---|
| self (12) | 5.11 Hz | 967 s | 0.9 s |
| squad (44 / 51 / 37) | 5.06 / 4.78 / 4.54 Hz | 938 / 813 / 744 s | 26.7 / 49.3 / 55.8 s |
| best non-squad (18, 26, 47) | 1.19 / 1.22 / 1.22 Hz | 952 / 819 / 727 s | 290 / 556 / 327 s |

So a teammate's sample set contains all the *far* samples; a non-teammate's
sample set is **filtered to the close ones**. The fraction-inside-10 m statistic
measures "is this entity interest-managed", and in BR that is the opposite of
"is this entity my teammate".

**(b) The aircraft and the drop.** Every player shares a few metres of airspace
for the first minute. Rung 5 needs only 40 updates = **8 s at the 5 Hz tick**.
Measured promotion times, relative to each entity's first sighting:

```
id  1  5.1s   id  5  5.3s   id  9  5.1s   id 15  9.9s   id 20  5.1s
id  2  5.1s   id  6  5.3s   id 10  5.1s   id 16  5.2s   id 21  5.1s
id  3  5.5s   id  7  5.1s   id 11  5.1s   id 18  5.2s   id 23 13.5s
id  4  8.4s   id  8  5.1s   id 13  7.1s   id 19  5.1s   id 26  9.9s
                            id 14 22.3s
```

**Median 5.2 s.** The entire plane cohort is blue before anybody lands.

### 1.4 Why it is permanent — the sticky-role defect

Rung 6 is a comment, not code (`esp/EspEngine.java:1282-1283`). When the
proximity condition later stops holding, `classify()` simply falls off the end
and **`t.role` keeps its last value**. There is no path that demotes a
`ROLE_TEAM` set by proximity:

* rung 2 (`teamKnown`) only fires if a handle later names the entity;
* rung 3 (squad closure) needs 4 own-squad ids, which in BR only arrive from
  handle events;
* rung 4 (late arrival) is skipped for anyone first seen within 20 s of the
  first chain packet — i.e. for the whole plane cohort.

So the wrong blue survives for the rest of the match. This is the "sometimes"
in the report: it hits every player who shared the plane window with you **and
never subsequently appeared in a damage event or a small handle event**.

### 1.5 Replay scores (BR match, 31 360 samples)

| classifier | decided | **enemy painted BLUE** | friend painted RED |
|---|---|---|---|
| shipped, no handle feed at all | 87.9 % | **9 242 (29.47 %)** | 0 |
| shipped + Cmd 118 squad wired in | 92.2 % | **8 826 (28.14 %)** | 0 |
| **self + Cmd 118 squad + default RED** | **100 %** | **0 (0.000 %)** | 3 899 (12.43 %) |

**Wiring the authoritative source in does not fix the bug on its own** — it only
moves 1.3 points, because rung 5 latches ~5 s after first sighting and the first
Cmd 118 player binds do not arrive until roughly the same instant. **Rung 5 must
be removed, not out-voted.**

Of the 3 899 friend-red samples in the proposed classifier, **3 884 (99.6 %)
are a single entity (51) that Cmd 118 never bound at all**, because its bind
fell inside the pre-key window. Teammates 37 and 44 are correct from their
first chain record onward (only 15 samples of 44 precede its bind).

### 1.6 Secondary defects found while confirming the above

These did not cause the reported symptom on this capture but can each produce a
false blue, and all are cheap to close.

**(a) `resetMatch()` does not clear `ownTeam`, `ownEntityId` or `matchHandle`**
(`esp/EspEngine.java:1517-1530`). Squad indices are reassigned per match. The
boundary is detected at `:842-849`:

```java
long ownHandleNow = ((long) ownTeam << 24) | (ownEntityId & 0xFFFFFFL);
boolean newByHandle = (matchHandle != 0 && ownHandleNow != 0 && ownHandleNow != matchHandle);
boolean newBySilence = (lastChainMs != 0 && now - lastChainMs > MATCH_GAP_MS);
if (newByHandle || newBySilence) resetMatch(now);
```

On the `newBySilence` path `ownTeam` still holds the **previous** match's squad
index. Any entity whose new squad happens to equal it is latched
`teamKnown = true, role = ROLE_TEAM` by `noteTeam()` (`:1486-1495`) and never
revisited. The window is short (the keepalive refreshes at ~10 Hz) but the
consequence is permanent — this is the exact inverse of the red-on-squadmate bug
the `resetMatch` javadoc documents at `:1501-1516`. That documented fix is
intact; this is its mirror image and is **not** fixed.

**(b) The `ownTeam` range guard is not derived from the binary.**
`esp/EspEngine.java:651`:

```java
int otm = (int) (handle >>> 24);
if (otm >= 1 && otm <= 63) ownTeam = otm;
```

The binary says the field is **8 bits wide**, not 6 —
`BHGGAEEHJCO::FIIHAENFFML(uint teamId, uint sub)` at RVA **`0x07c5e1a0`** in
`libil2cpp_dec.so` is `bfi w20, w21, #0x18, #8`, i.e. literally
`id = (teamId << 24) | (sub & 0x00FFFFFF)`. The `63` almost certainly came from
conflating the team field with the **64-slot player bitmask** built in the same
constructor (`BHGGAEEHJCO::.ctor(uint)` at **`0x07c5dccc`**, `lsl x8, x10, x1`
over `id & 63`) — that 63 masks the LOW six bits, the per-match slot, which is
the opposite end of the same word. Observed team ids top out at 15 in the
corpus, so the guard is not biting today, but it is wrong on principle and will
bite in a 50-player solo lobby where team indices are per-player.

**(c) Nothing rejects team 0 or team 255.** `MatchGame::IsSameTeam`
(RVA **`0x0764ea14`**) is a bare byte comparison with no sentinel check, so in
the game itself two entities both reading 0 (or both 255) compare **equal ->
teammate**. In our code `noteTeam()` guards `team < 1` but not `team == 255`.
255 is a reserved sentinel: `MCDLKHAOJJG.LBGFNOEOAPD = 255` is returned by the
dynamic-team lookup for "not present".

**(d) `observeDamage` silently drops entity ids 64..127.**
`esp/EspEngine.java:1413`: `if (h0 < 0x80 || h0 > 0xBF) return;`. `h0` is the
first LEB128 byte, `0x80 | (id & 0x7F)`, so the `0xBF` ceiling means
`id & 0x7F <= 0x3F`. The BR capture reaches chain id 63 and Cmd 118 slot 53, so
this is close to biting. `observeHandleEvent` has no such ceiling — the two
gates disagree.

**(e) `MatchRoster` already parses the squad byte and nothing reads it.**
`esp/MatchRoster.java:127` and `:136` store `squads[slot]`, and
`MatchRoster.squad(int)` at `:57` has **zero callers**. Likewise
`PriTracker.onBind` (`esp/PriTracker.java:319-322`) computes
`int squad = (int)((packedEntity >>> 24) & 0xFF)` and then throws it away —
it only keeps `isPlayer`. This is `docs/SESSION_2026-09-13.md` open item 6, and
it is a two-line hand-off.

---

## 2. The definitive friend/foe source

### 2.1 What the game itself does

From `libil2cpp_dec.so` (all RVAs are **our** image unless flagged):

```
COW.GameFacade::IsSameTeam(Player,Player)      0x07540a50
COW.GameFacade::IsSameTeam(PlayerID,PlayerID)  0x075427c4
COW.MatchGame::IsSameTeam(PlayerID,PlayerID)   0x0764ea14
COW.GamePlay.BHGGAEEHJCO::DDPFMJDFEDJ  = GetTeamId()   0x07c4c1d0
COW.GamePlay.Player::IsLocalTeammate (HUD path)         0x0709bcac
```

`GameFacade::IsSameTeam` decompiles to:

```csharp
if (IsTeammateOfSameFaction())          // 0x07547ecc -> IsUGCInfectionMode 0x07550ec4
    return IsSameFaction(p1, p2);       // faction, not team
MatchGame mg = GameFacade.Instance...;
if (mg != null) return mg.IsSameTeam(p1, p2);
return p1.PlayerID.GetTeamId() == p2.PlayerID.GetTeamId();
```

and the `MatchGame` base implementation at `0x0764ea14` is literally two
`GetTeamId()` calls and `cmp w20, w0, uxtb ; cset w0, eq`.

**The predicate is one byte compared for equality. That is all it is.**

### 2.2 Where that byte lives — and the answer to "how many team concepts?"

`PlayerID` (obfuscated `BHGGAEEHJCO`) is built from one `uint`
(`.ctor` at `0x07c5dccc`):

```
field@0x00 = raw id
field@0x04 = id & 0x00FFFFFF     ; the per-match slot
field@0x08 = id >> 24            ; THE TEAM BYTE
field@0x09 = id & 0xFF
field@0x10 = 1ULL << (id & 63)   ; 64-slot bitmask (NOT a team bound)
```

So `PlayerID = (teamByte << 24) | slot24` — **exactly the packing our decoders
already use** for the entity handle, for Cmd 118's `packedEntity`, and for
Cmd 101's `entityId`. They are the same quantity.

Every distinct team-ish field found:

| # | concept | where | used by the friend/foe predicate? |
|---|---|---|---|
| 1 | **team byte** = `PlayerID >> 24` | `PlayerID+0x8` | **YES — this is it** |
| 2 | `MatchTeam.TeamID` | `MatchTeam+0x7C`, set by `0x078caaa8` | no — roster object identity |
| 3 | `MatchTeam.MTeamIndex` | `MatchTeam+0x80`, set by `0x078ca288` | no — display index |
| 4 | `Player.TeamIndex` | `Player+0x3D0`, set by `0x0707cef4` | no — UI |
| 5 | `FactionId` (EPRI 34) | iface slot 11 on `Player+0x70`; `Player::OnPlayerFactionIDChanged 0x071aaffc` | **only in UGC / infection modes** |
| 6 | lobby party (account uids) | `UIModelGroup::IsTeammate 0x0607fe90` | only pre-match / training / social |

**The "CS side vs BR squad" hypothesis is refuted.** There is no separate
"side" field. Clash Squad's two sides *are* team bytes 1 and 2; BR's squads
*are* team bytes 1..n. Same field, same semantics, different cardinality — which
is why the predicate needs no mode branch, and it does not have one. The match
roster container is a `Dictionary<byte, MatchTeam>` at `Match+0x178`
(`EMKJHAJNPDH::CMHAJOCHEOK` at `0x07260b58` does
`TryGetValue(id.GetTeamId(), ...)`) — a dictionary, not an array, so **no fixed
team-count bound exists in the client**.

The corpus agrees: `docs/PROTOCOL_MASTER.md` §5.1 already recorded own-team
values of 1, 2, 6, 8, 13 across Clash Squad and Survival, and the BR match
measured here carries squads 2..15. Any absolute rule ("team 1 = friendly") is
inverted roughly half the time. **Friend/foe is relational: `friend <=> entity
team byte == own keepalive team byte`, and nothing else.**

### 2.3 The two exceptions the binary defines

**Dynamic team reassignment.** `GetTeamId()` is *not* a plain field read:

```csharp
byte GetTeamId() {
  var s = GameFacade.CurrentGameModeSetting();        // 0x0753969c
  if (s != null && s.EnableDynamicTeamID)             // bool @0x9CD  [dump.cs offset]
      if (currentMatchGame is MCDLKHAOJJG m)
          return m.HMGMKMPDKAM(this);                 // 0x07951028 -> Dictionary<PlayerID,byte> @+0x328
  return this.field@0x8;                              // = rawId >> 24
}
```

The override map is written by the handler for **Cmd 3077
`RUDP_S2C_CHANGE_TEAM`** (`COW.GamePlay.FFMOIGKIEPE::ONMNLLPHHLM` at
`0x07aeef88`, calling `MCDLKHAOJJG::BDFMNOIHFIL` at `0x07951114`).

**Measured: Cmd 3077 occurs exactly ONCE across 497 local capture files.** It is
not the cause of the reported bug and is not worth implementing now. It is
listed here so it is not re-discovered as a theory later. The field name
`EnableDynamicTeamID` at offset `0x9CD` is a **dump.cs** (different build)
offset; the string itself is confirmed present in our build's
`global-metadata.dat` at `0x354a02`.

**UGC / infection mode.** `IsUGCInfectionMode` (`0x07550ec4`) is
`GameServerGameMode == 58`; in that mode friend/foe is `FactionId` equality, and
`ICEGOFFPFMB::IsSameTeam` (`0x07b3bf08`) — the only `MatchGame` subclass in our
image that overrides the predicate — also uses `FactionId`. Irrelevant to
BR / CS. For reference the mode predicates are
`IsBattleRoyale 0x0754ce70` (`mode == 1 || mode == 99`) and
`IsCSMode 0x07549f10` -> `CheckGameModeIsCS 0x0754e038`
(`mode in {15, 41, 52, 78, 82}`).

**Bots are not a special case.** `Player::IsOnlineBotAgent` (`0x07085ad8`) is
`IsBotAgentDebug || IsHangUpBotAgent` — that is your *own* idle bot. Enemy bots
carry an ordinary `PlayerID` and therefore an ordinary team byte.
`get_IsSamoAI` (`0x0707ccc8`) and `IsClientBot` are flags on an otherwise
normal player. No special team value was found.

### 2.4 The key negative result: team identity is NOT an EPRI property

The player replication enum is `message.NIPHKJAOKGI`, **256 members**, verified
in *our* build's `global-metadata.dat` starting at `0x27d500` (member ordering
matches dump.cs, so the ordinals hold for our image).

Every team-ish member:

| id | name |
|---|---|
| 12 | `EPRI_PLAYER_SIGHTING_ID` |
| **34** | **`EPRI_PLAYER_FACTION_ID`** |
| 45 | `EPRI_PLAYER_OD_FACTION` |
| 69 | `EPRI_PLAYER_WEREWOLVES_ColorIndex` |
| 91 | `EPRI_PLAYER_DMM_FACTION_ID` |
| 121 | `EPRI_FOOTBALLGAME_TEAMID` |
| 185 | `EPRI_PLAYER_CS_TeamSpawnPointIndex` |
| 230 | `EPRI_PLAYER_FFWS_CS_OPPOTEAMFLAG` |
| 214 / 223 / 242 / 251 | `IS_TEAMMVP`, `USE_TEAMBUFFSUPPORTER`, `NEXT_USETEAMGATHERPONIT_TIME`, `BR_SHOPTOKENGUN_TEAMHIT_PROGRESS` |

**There is no `EPRI_PLAYER_TEAM_ID` and no `EPRI_PLAYER_SQUAD_ID`.** Base team
identity is carried in the entity handle itself and is never replicated as a
property. Cmd 1900 `RUDP_VAR_SYNC_PRI_DATA` — the channel we already decode —
**cannot** give us friend/foe in BR or Clash Squad. `FACTION_ID` (34) is the
only replicated team-ish property and it governs friend/foe only in UGC /
infection modes. This closes what looked like the cheapest avenue.

(Related enum, from **dump.cs**: `EFactionRelationType { Friendly = 0,
Hostile = 1, None = 2 }`, consumed by
`GameFacade::GetRelationWithTrackedPlayer` `0x07547f40` / `0x07548228`.)

### 2.5 The complete wire inventory of the team byte

Every message we can read that carries the team byte, ranked by authority. All
`RUDP_` are reliable and therefore TEA-encrypted (readable — we have the session
key); all `UDP_` are unreliable plaintext.

| cmd | name | dir | rel | where the team byte is | when it arrives | wired today? |
|---|---|---|---|---|---|---|
| **118** | `RUDP_BIND_PRI` | IN | REL | record `(U owner, B type, U packed)`, `type == 1`, `packed >> 24` | match start burst, within ~3 s; stragglers to +30 s | parsed, **squad discarded** (`PriTracker.java:321`) |
| **101** | `RUDP_PLAYER_JOIN` | IN | REL | field 2 `entityId >> 24` | match start burst | parsed, **squad stored and never read** (`MatchRoster.java:136`, `squad()` has 0 callers) |
| **107 / 139** | `RUDP_DEAD` / `RUDP_KNOCK_DOWN` | IN | REL | field 1 = **killer** handle `>> 24` | on each kill/knock | as above |
| 2001 | `UDP_PLAYER_STATE_SYNC` (OUT keepalive) | OUT | plain | leading handle `>> 24` = **own team** | ~10 Hz from match start | yes (`EspEngine.java:651`) |
| 2010 | `UDP_PLAYER_HURT` | IN | plain | `v0 >> 24` victim, `v1 >> 24` attacker | only fights involving us; median time-to-first ~20 s | yes (`observeDamage`) |
| 2013 / 2018 | `UDP_PLAYER_HEAL`, `UDP_SYNC_ASSISTANT_TRIGGER_INFO` | IN | plain | leading handle `>> 24` | sporadic | yes (`observeHandleEvent`) |
| 195 | `RUDP_TEAM_INFO` | IN | REL | unparsed | seen in 16 of 497 captures, 321 packets | no |
| 515 | `RUDP_S2C_NotifyPlayerCampInfo` | IN | REL | unparsed | 6 files, 230 packets | no |
| 3077 | `RUDP_S2C_CHANGE_TEAM` | IN | REL | dynamic override | **1 packet in 497 files** | no |
| — | entity chain (2012 / `observeChainPacket`) | IN | plain | **carries no team field at all** | — | n/a |

Capture-wide counts over 497 local raw captures:
Cmd 118 **12 285** records in 90 files; Cmd 139 **10 745** in 80;
Cmd 101 **7 631** in 78; Cmd 107 **1 701** in 53.
The authoritative sources are abundant.

`observeHandleEvent` was audited directly against raw bytes
(`captures/phone_aim6/capture_raw_20260912_161312.txt`, own handle
`(id 34, team 11)`): the gate accepts **79 events** from exactly two commands,
2018 and 2013, decoding to `(36,11) (41,15) (42,11) (47,11) (49,12) (55,12)`.
Every one agrees with the independent damage feed. **The handle-event path is
not producing false teams** — it is simply low-volume. Note that its javadoc
claim of *"own team in 355 of 356 cases (99.7 %)"* does **not** hold here: only
47 of 79 (59 %) named own-team ids. That does not matter, because the code uses
the relational rule rather than the claim.

**Serializer reminder for anyone touching these bodies**
(`GCommon.FastBinaryReader`, and `net/WireReader.java`): `U`/`Z`/float are **one
LEB128 varint**; `B` is **one RAW byte**; `S` is a **zigzag varint byte-length
then raw UTF-8**; `FixUInt16` is **two raw LE bytes**. Cmd 118's `type` is a `B`
and Cmd 1900's `blockLen` is a `FixUInt16` — both are the classic desync traps.

---

## 3. Classifier spec

Replaces `EspEngine.classify()` (`esp/EspEngine.java:1236-1284`).

### 3.1 State

```
ownTeam        byte 1..254, 0 = unknown      # from OUT 2001 keepalive handle >> 24
ownEntityId    slot 1..127, -1 = unknown     # from OUT 2001 keepalive handle & 0xFFFFFF
ownTeamSeenMs  wall-clock of the keepalive that set ownTeam
Track.team     byte, 0 = unknown
Track.teamSrc  enum { NONE, HANDLE_EVENT, DAMAGE, ROSTER, BIND_PRI }
Track.teamKnown
```

`teamSrc` exists so a weaker source can never overwrite a stronger one, and so
the HUD can say *why* a box is the colour it is.

### 3.2 Rungs, strict priority order

**Rung 0 — freshness gate (new).**
If `ownTeam == 0`, or `ownTeamSeenMs < lastMatchResetMs`, classify nothing:
return `ROLE_UNKNOWN` without writing `t.role`. Rationale: §1.6(a). Own team is
the denominator of every comparison below; using a stale one is how a friend
label is manufactured out of nothing.

**Rung 1 — SELF.**
`if (ownEntityId > 0 && t == entities.get(ownEntityId)) -> ROLE_SELF`.
Unchanged. Measured 98.7 % of 4 741 self samples inside 5 m of the keepalive
position on the BR capture; it works.

**Rung 2 — server-published team byte. The only rung that may conclude TEAM.**

```
if (t.teamKnown)
    role = (t.team == ownTeam) ? ROLE_TEAM : ROLE_ENEMY     # recompute, do not early-return
else if (isValidTeam(t.team) && isValidTeam(ownTeam))
    teamKnown = true; role = (t.team == ownTeam) ? ROLE_TEAM : ROLE_ENEMY
```

with

```
isValidTeam(b)  ==  b >= 1 && b <= 254        # 0 = unassigned, 255 = sentinel
```

Two changes from today:

* `if (t.teamKnown) return;` at `:1245` **must become a recompute**, not an
  early return. Today the latched role is frozen even if `ownTeam` is later
  corrected; recomputing costs one comparison and self-heals §1.6(a).
* The `1..63` bound becomes `1..254` (§1.6(b)), and `255` is explicitly
  rejected rather than treated as a team.

Feed `t.team` from, in descending precedence:

1. **Cmd 118 `RUDP_BIND_PRI`**, `type == 1`, `squad = packed >> 24`, `squad != 0`
   — the value `PriTracker.onBind` already computes at `esp/PriTracker.java:321`
   and discards. Hand it to `noteTeam(slot, squad, BIND_PRI)`.
2. **Cmd 101 `RUDP_PLAYER_JOIN`** and **Cmd 107 / 139** killer handle — the
   value `MatchRoster.put()` already stores at `esp/MatchRoster.java:136`.
   Hand it to `noteTeam(slot, squad, ROSTER)`.
3. **Cmd 2010 damage handles** — existing `observeDamage` path.
4. **Cmd 2013 / 2018 handle events** — existing `observeHandleEvent` path.

All four are the same physical quantity (§2.2), so they cannot disagree; the
ordering exists only so the earliest-and-most-complete source wins and so
`teamSrc` is meaningful. **This is where the coverage win is: 118 and 101 arrive
in the match-start burst, before anyone has been shot.**

**Rung 3 — squad closure -> ENEMY.**
`if (ownSquadKnown() >= MAX_SQUAD) -> ROLE_ENEMY`. Keep. Concludes ENEMY only,
which is now the safe direction. Note it is inert in solo BR and mostly inert in
BR until Cmd 118/101 are wired, because it needs four known own-squad ids.

**Rung 4 — late arrival -> ENEMY.**
`if (t.firstSeenMs - firstChainMs > LATE_ARRIVAL_MS) -> ROLE_ENEMY`. Keep at
20 s. Concludes ENEMY only. It is what saved entity 48 (squad 13, 0.417 close
fraction) from being painted blue in the measured match.

**Rung 5 — DELETE.**
The proximity promotion goes. Not re-tuned, not gated by mode — deleted. §1.2
shows the statistic is inverted in BR, and §1.5 shows the authoritative source
cannot out-vote it because it latches first. If it is kept behind a debug flag,
it must default off and must never be reachable when `SHOW_TEAM == false`.

**Rung 6 — default -> ENEMY (red).**
Everything undecided renders red.

### 3.3 Is defaulting UNKNOWN -> red safe? Measured: yes

The undecided remainder under the shipped ladder is **96.9 % enemies** in the BR
match (3 673 enemy samples vs 117 friend samples). The figure quoted in the
`classify()` javadoc at `esp/EspEngine.java:1233` — *"the undecided remainder is
64.1 % enemies"* — is a whole-corpus number dominated by Clash Squad and does
not describe BR. **Re-measured for BR: 96.9 %.**

Full cost of the proposed classifier on the BR match (§1.5):
**0 enemies blue, 12.43 % of samples friend-red**, of which 99.6 % is the single
teammate whose Cmd 118 bind was lost to the pre-key window. Wiring Cmd 101 and
Cmd 107/139 in alongside 118 should recover most of that: per
`docs/ESP_HEALTH_AND_NAMES.md` §4, Cmd 101 named 25 of 53 players and 107/139
recovered 17 more, **42/53 = 79 %** in this same capture, and the roster path is
independent of the 118 path.

### 3.4 Mode handling

The predicate needs **no mode branch** (§2.2) — one relational comparison is
correct in BR solo, BR duo, BR squad and Clash Squad alike. What differs by mode
is only *coverage*:

| mode | squads | authoritative coverage | note |
|---|---|---|---|
| Clash Squad | 2 sides of 4 | very high — 8 players, all bound at match start, damage feed dense | rung 3 (closure) arms reliably |
| BR squad / duo | up to ~13 | high once 118 + 101 are wired; ~35 % of samples from 118 alone in the measured match | rung 3 arms once all 4 squadmates are named |
| BR solo | up to 50 | 118 + 101 still give every player a byte | rung 3 **can never arm** (`ownSquadKnown()` tops out at 1); rung 4 and the red default carry it |

The one thing that *is* mode-specific is that **BR replication is
interest-managed and Clash Squad is not** — that is the whole of §1.3, and it is
the reason no geometric statistic may ever promote to TEAM.

### 3.5 Match boundaries

`resetMatch()` must additionally clear **`ownTeam = 0`, `ownEntityId = -1`,
`matchHandle = 0`**, and record `lastMatchResetMs` for rung 0. Ids *and* squad
indices are reassigned per match; carrying either across a boundary
manufactures a false label in one direction or the other. The existing
`entities.clear()` / `pri.reset()` / `roster.reset()` are correct and must stay.

### 3.6 What the classifier must never conclude

* **Never conclude TEAM from geometry, co-location, update rate, or any other
  derived statistic.** Only a server-published team byte may produce blue.
* **Never treat an absolute team value as meaningful.** No rule of the form
  "team 1 is friendly". `docs/PROTOCOL_MASTER.md` §5.1 records this inverting in
  4 of 10 sessions; the measured BR match has own team 9.
* **Never treat 0 or 255 as a team.** Both compare equal to themselves and
  would paint blue.
* **Never let a latched role outlive the `ownTeam` it was computed against**
  (rung 2 recompute + rung 0).
* **Never let a lower-priority rung silently keep a higher-priority verdict** —
  the current fall-off-the-end behaviour at `:1282` is what makes the bad blue
  permanent.

### 3.7 Diagnostic requirement

Per the recurring lesson in `docs/SESSION_2026-09-13.md` ("a silent no-op is
indistinguishable from a working feature"), the HUD should expose a `TEAM` row:

```
TEAM own=9 known=17/23 src=118:14/101:3/dmg:0/hnd:0 unk=6 reset=+41.5s
```

If `own=0` or `known` stays at 0, the authoritative path is dead and the ESP is
running on the red default — which is safe, but the operator should know.

---

## 4. Unknowns, and exactly what settles each

| # | unknown | what settles it |
|---|---|---|
| 1 | **Own squad in the measured match is inferred, not read.** Entity 12's own Cmd 118 bind was lost to the pre-key window, so "own squad = 9" rests on the always-replicated-set argument plus Cmd 118 on slots 37/44. | Any capture in which the **outbound Cmd 2001 keepalive handle** is logged alongside the chain. `own_*.csv` starts at varint `v0` and drops the leading handle — **add the raw handle to that CSV** and it is settled in one line. |
| 2 | **Does Cmd 101 / 107 / 139 recover teammate 51?** The proposed classifier's entire 12.43 % friend-red cost is that one entity. | Re-run the annotator on `capture_raw_20260913_143415.txt` (the raw for `pull_20260913b`) dumping Cmd 101/107/139 the way `bind118.txt` dumps Cmd 118, and check whether slot 51 gets a squad byte. **The raw for that session is not in the repo** — only the derived CSVs were pulled. Pull it from `/sdcard/Android/data/com.fakelag.cryhard8/files/dev_logs`. |
| 3 | **BR solo behaviour is entirely unmeasured.** Every BR capture in the corpus is squad/duo. In solo, team indices are per-player and may exceed the 63 guard; rung 3 can never arm. | One BR-solo capture with a session key. Check: the max team byte observed, and whether Cmd 118 still emits `type == 1` records for all ~50 players. |
| 4 | **Is the corpus's "SURV" the same replication regime as BR?** The 10-session validation behind rung 5 used CLASH and SURV only. SURV lobbies in that corpus are 16 players, not 50. | Re-run the §1.2 close-fraction measurement on a SURV capture. If SURV also inverts, the rung was never safe outside Clash Squad. |
| 5 | **Which `GameServerGameMode` values set `EnableDynamicTeamID`.** Lives in a config asset, not the binary. | Empirical: log Cmd 3077 per mode. Current evidence (1 packet in 497 files) says none of the modes the user plays. |
| 6 | **The EPRI-34 -> `Player::get_FactionId` binding is by name and ordinal, not traced.** `get_FactionId` (`0x0719811c`) makes an interface call at slot 11 on a component at `Player+0x70`. | Decompile that component's property dispatch table. Low value — §2.4 already shows EPRI carries no base team identity. |
| 7 | **Cmd 195 `RUDP_TEAM_INFO` and Cmd 515 `RUDP_S2C_NotifyPlayerCampInfo` are unparsed**, and both appear in real captures (321 / 230 packets). Either could be a complete roster that closes the pre-key gap. | Decode their bodies from an existing keyed capture; the layouts are in `tools/il2cpp/ff_message_layouts.json`. `docs/ESP_HEALTH_AND_NAMES.md` §3 says Cmd 195 *"never appeared"* — **that is wrong; it appears in 16 of 497 captures.** |
| 8 | **The pre-key window at match handover** (`docs/ESP_HEALTH_AND_NAMES.md` §4) is upstream of all of this. It costs ~50 % of Cmd 118 binds and ~50 % of Cmd 101 joins. | Already logged as the highest-value remaining protocol fix. It is now also the single largest contributor to friend-red under the proposed classifier. |
| 9 | **The device was unreachable during this work.** `adb mdns services` advertised `adb-R3GL10AHL7P-Udemho _adb-tls-connect._tcp 192.168.1.40:33519`, but connects to :5555, :33519 and :37000 were all actively refused. No fresh capture could be taken. | Re-enable wireless debugging on the handset, then `adb connect 192.168.1.40:<port>` and pull `dev_logs`. Unknowns 1, 2 and 3 all resolve from one new BR capture with a key. |

---

## 5. Retractions this note forces

Recorded loudly, per house style.

1. **`esp/EspEngine.java:1206-1218`** — *"Teammate: squadmates hold station near
   you... Lowest teammate 0.37, highest enemy 0.17."* True for the three Clash
   Squad captures cited (150701, 155351, 161940). **False in Battle Royale**,
   where the three real teammates measured 0.158 / 0.183 / 0.206 and seventeen
   enemies measured 0.27-0.89. The validation table should carry the mode.

2. **`esp/EspEngine.java:1229-1234`** — *"Proximity may promote to TEAM but must
   never conclude ENEMY... A wrong colour is worse than no colour."* The
   asymmetry is the bug, and the user has reversed the preference.

3. **`esp/EspEngine.java:1276`** — *"Proximity may only promote to TEAM. 22
   entities promoted, 0 wrong."* Measured on a BR match: **21 entities
   promoted, 21 wrong**, 29.47 % of all drawn samples.

4. **`esp/EspEngine.java:1233`** — *"the undecided remainder is 64.1 % enemies."*
   Corpus-wide figure. **In BR it is 96.9 %.**

5. **`docs/PROTOCOL_MASTER.md` §5.1** — *"squads derived from the handle travel
   together: median same-team separation 15.7 m vs 67.1 m cross-team, AUC
   0.889."* **Inverted in BR**: squadmates 35.8 / 43.0 / 50.9 m, several enemies
   6.6-9.8 m. The AUC was measured on Clash Squad and Survival only.

6. **`docs/ESP_HEALTH_AND_NAMES.md` §3** — *"Cmd 195 `RUDP_TEAM_INFO` also
   carries names but never appeared."* It appears in **16 of 497** capture files,
   321 packets.

7. **`esp/EspEngine.java:1378-1381`** — *"[small handle events] belong to our own
   team in 355 of 356 observed cases (99.7 %)."* On
   `capture_raw_20260912_161312.txt` only **47 of 79 (59 %)** were own-team.
   Harmless (the code is relational) but the claim is mode-specific.

8. **`esp/EspEngine.java:651`** — the `otm <= 63` bound. The team field is
   **8 bits** (`bfi w20, w21, #0x18, #8` at `0x07c5e1a0`); the 63 belongs to the
   64-slot player bitmask at the other end of the same word.

---

## 6. Reproduction

Everything in §1 is reproducible from files already in the repo:

```
captures/pull_20260913b/bind118.txt                  ground truth (Cmd 118 type-1)
captures/pull_20260913b/entities_20260913_145150.csv chain records, 31 449 rows
captures/pull_20260913b/own_20260913_145150.csv      keepalive, 9 399 rows (v0,v2 are zigzag X,Y)
captures/pull_20260913b/summary_20260913_145150.txt  ENTITY CENSUS: per-id rate and span
captures/phone_aim6/capture_raw_20260912_161312.txt  raw bytes for the handle-event audit
```

Method: zigzag-decode `own.v0` / `own.v2` for own X/Y; join each chain record to
the nearest keepalive within 300 ms; `dist = hypot(x_zz - ownX, y_zz - ownY)`;
`UNITS_PER_METRE = 1000`. Ground truth squad = `(v2 >> 24)` of Cmd 118 records
with `v1 == 1`.
