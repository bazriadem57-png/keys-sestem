# VpnService audit — correctness, robustness, lifecycle

Date: 2026-09-15
Scope: `PacketVpnService`, `core/VpnEngine`, `core/PacketLoop`, `core/UdpSessionManager`,
`core/TcpProxy`, `core/TunAddressPool`, `core/PacketBuilder`, `VpnActions`,
`app/PermissionController`, `AndroidManifest.xml`.
Build: Java 8, `minSdk 21`, `targetSdk 34`, `compileSdk 35` (`app/build.gradle:5-10`).
Target device: Samsung SM-S948U1 (arm64, Android 15+).

Paths below are relative to
`C:\Users\Tonyt\Documents\GitHub\Fakelag\fakelag\fakelag-beta\app\src\main\java\com\fakelag\cryhard8\`
unless a full path is given.

**Read-only audit. No source file was modified.**

---

## How to read this

Findings are ranked by what the player experiences:

* **S1 — crash or player-visible disconnect.**
* **S2 — silent data loss / the engine reports "running" while doing nothing.**
* **S3 — hygiene, leaks, lying diagnostics.**

Every finding is tagged:

* **[CERTAIN]** — provable from the code as written.
* **[DEVICE]** — the mechanism is in the code but the trigger or the blast radius
  needs a device to confirm. Each one names the test.

Two rules were held throughout:

* **No fix below changes what reaches the wire or when**, except where explicitly
  flagged `⚠ SEMANTICS` — three findings where the only real fix does, and those
  are written as decisions to make, not patches to apply.
* **No fix reinstates a mid-match `restartTunnel`.** `ff-route-fallback-kick`
  records that tearing the interface down mid-match dropped players out of live
  matches. Several findings below are *about* teardown, and every proposed fix is
  deliberately teardown-free. See "Rejected fixes" at the end.

---

## Summary table

| # | Sev | File:line | Failure |
|---|-----|-----------|---------|
| 1 | S1 | `PacketVpnService.java:108-124` | `startForeground()` unguarded in `onCreate()` — an uncaught `ForegroundServiceStartNotAllowedException` crashes the app on a background start |
| 2 | S1 | `core/VpnEngine.java:514`, `546-554` | STANDBY establishes a **route-less** tunnel that is still app-scoped: the game is scoped into a VPN with no route to anywhere |
| 3 | S1 | `core/VpnEngine.java:415`, `531`, `544` | Restart handoff race: the old thread's `finally` nulls the **new** session's `tunWriter`; the TCP relay then writes into a black hole forever |
| 4 | S1 | `core/UdpSessionManager.java:354-366` | One exception anywhere in the inbound pipeline silently kills the flow's socket; the next outbound packet re-NATs from a **new source port** mid-match |
| 5 | S1 | no `onRevoke()` anywhere in the repo | Revoke is unhandled: default `stopSelf()` only, no state broadcast, and every later Activate silently no-ops |
| 6 | S1 | `core/VpnEngine.java:437-440` + `860-885` | `stop()` racing `restartTunnel()` leaves `isRun == true` forever with no tunnel — the UI says ACTIVE, nothing runs |
| 7 | S2 | `core/UdpSessionManager.java:150-172` | `getOrCreate` leaves a reader-less socket in the map on any failure: that flow's inbound is lost permanently, silently |
| 8 | S2 | no `ConnectivityManager` awareness anywhere | Wi-Fi↔cellular handover kills every protected socket; `catch { // ignore send failure }` hides it for 45 s |
| 9 | S2 | `core/VpnEngine.java:502-514` | Zero allowed apps silently degrades an app-scoped tunnel to an unscoped narrow-route one, with no log and no UI signal |
| 10 | S2 | `core/TcpProxy.java:201-205`, `263-267` | `writerStarted`/`relayStarted` are latched *before* `pool.execute()`; a rejected execute hangs the connection forever with no error |
| 11 | S2 | `core/VpnEngine.java:469-470` + `core/PacketLoop.java:47-52` | An IPv6 address is advertised, no IPv6 route is installed, and any IPv6 packet that does arrive is dropped by a logger that is off by default |
| 12 | S2 | `PacketVpnService.java:172`, `195`, `208`, `253` | Mixed `START_STICKY`/`START_NOT_STICKY` + a null-intent recreate that posts a notification and starts nothing |
| 13 | S2 | `AndroidManifest.xml:48`, `56` | `foregroundServiceType="dataSync"` on a VPN — a 6-hour kill timer that arms the moment `targetSdk` goes to 35 |
| 14 | S2 | `core/TcpProxy.java:289-292` | `toClient` grows without bound while the client's window is shut — the exact scenario the class comment says it fixed |
| 15 | S3 | `core/VpnEngine.java:54-58`, `684-687` | Byte/loss counters are never reset: the HUD's loss % is a lifetime average that can never recover |
| 16 | S3 | `dev/capture/TelemetryCollector.java:85-91` (no callers) | The telemetry poller thread is never stopped — it outlives the destroyed Service and holds it alive |
| 17 | S3 | `core/VpnEngine.java:795` reached only via `stopCapture()` | Always-on capture is never stopped by `stop()`: writer thread + open file leak per engine cycle |
| 18 | S3 | `filter/DefaultFilterEngine.java:184-191` (no callers) | A **second** unbounded cached thread pool is never shut down |
| 19 | S3 | `core/UdpSessionManager.java:167`, `core/TcpProxy.java:206/239/268` | Unbounded thread creation per UDP flow (1) and per TCP connection (3) on a shared `newCachedThreadPool()` |
| 20 | S3 | `core/VpnEngine.java:426-435` vs `868` | `restartTunnel()` resets five learners but not `SessionTimeline` or the ESP — stale session state survives a restart |
| 21 | S3 | `core/VpnEngine.java:603`, `625-630` | `routesAppScoped` is only written on the ACTIVE path, so `activeRouteModeName()` reports the *previous* session's routes during STANDBY |
| 22 | S3 | `core/UdpSessionManager.java:196-198` | `rtt` measures how long the socket sat idle, not a round trip — the HUD "ping" is meaningless |
| 23 | S3 | `core/PacketBuilder.java:22-46` | No MTU or 16-bit bound check when wrapping an inbound datagram into an IP packet for a 1280-MTU tun |
| 24 | S3 | `core/TunAddressPool.java:54` | The tun address is allocated out of **public** IPv4 space (`26.0.0.0/8`) |
| 25 | S3 | `core/TcpProxy.java:343-345` | `if (inFlight < 0) inFlight += 0x100000000L;` is a compile-time no-op |
| 26 | S3 | `core/VpnEngine.java:332-334`, `349-351` | `loadLobbyRouteSetting` ignores prefs and hard-codes `true`; `setLobbyRouteFallbackFull` has zero callers |
| 27 | S3 | `core/VpnEngine.java:372-375`, `PacketVpnService.java:225-239` | Disk I/O (capture file open, `getExternalFilesDir`, `SharedPreferences` first load) on the main thread inside `onStartCommand` |
| 28 | S3 | `core/PacketLoop.java:85-88` | No IP fragment check — a non-first fragment is parsed as if its payload were a UDP header |

---

# S1 — crash or player-visible disconnect

## 1. `startForeground()` is unguarded inside `onCreate()` **[CERTAIN mechanism / DEVICE trigger]**

`PacketVpnService.java:100` calls `setupForeground()` from `onCreate()`, and
`setupForeground()` (`PacketVpnService.java:108-124`) has **no try/catch**:

```java
startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);   // :119
```

Every other risky call in this file is wrapped (`:143`, `:159`, `:165`, `:372`).
This one is not, and it is the one that throws:

* Android 12+ throws `ForegroundServiceStartNotAllowedException` from
  `startForeground()` when the app is in the background and no exemption applies.
* Android 14+ throws `SecurityException` if the type's permission is missing.
* Android 15+ throws `InvalidForegroundServiceTypeException` for a disallowed type.

An exception out of `onCreate()` is an uncaught crash, not a failed start.

The trigger is real, not theoretical: `FloatingOverlayService.java:584-593` sends
**every filter toggle** as `startForegroundService()` while the game is in the
foreground and this app is in the background. The caller side is wrapped
(`:593`); the service side is not. The app normally survives this only because
`SYSTEM_ALERT_WINDOW` with a visible overlay is an FGS background-start
exemption — so the crash path is "the overlay is not currently showing a window
when a toggle arrives" (overlay hidden, permission revoked, or the window
removed between `rm()` calls in `updateButtonLayout`).

Second defect in the same method: `if (Build.VERSION.SDK_INT >= 26)` at
`:109` means **on API 21-25 `startForeground()` is never called at all** and the
service is an ordinary background service the system can kill at will. `minSdk`
is 21.

**Fix** (no packet-path impact):

```java
private void setupForeground() {
    try {
        Notification n = buildNotification();      // build for all API levels
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);                 // API 21-28, incl. 21-25
        }
    } catch (Throwable t) {
        // Cannot go foreground right now (background-start restriction, missing
        // type permission). Report it instead of dying: the engine must not be
        // started behind an invisible, killable service.
        devLogger.logControl("FGS_START_DENIED", String.valueOf(t));
        engine.broadcastState();
        stopSelf();
    }
}
```

Note `buildNotification()` must use `NotificationChannel` only on API 26+ and the
two-arg `Notification.Builder(this)` below that. See finding 13 for the type.

**[DEVICE] Test:** grant overlay permission, start the engine, then revoke
"Display over other apps" in Settings while the engine runs (the overlay windows
are removed), then send a toggle via any remaining path. Expect the crash today;
expect an `FGS_START_DENIED` control log after the fix. Second test: run on an
API 22 emulator and confirm the service is not foreground today.

---

## 2. STANDBY establishes an app-scoped tunnel with **no routes** **[CERTAIN code / DEVICE blast radius]**

`core/VpnEngine.java:514`:

```java
if (isActive) addActiveRoutes(builder, scopedApps > 0);
tun = builder.establish();                                    // :516
```

and the STANDBY body, `core/VpnEngine.java:546-554`:

```java
} else {
    while (isRun && !isActive) {
        try { Thread.sleep(200); } catch (InterruptedException e) { break; }
    }
}
```

When `isActive == false` the builder still runs `addAddress()` (`:469-470`) and
the whole `addAllowedApplication` loop (`:503-512`) — but `addActiveRoutes()` is
skipped, so **not one route is installed**. `establish()` accepts this (only an
address is required). The resulting network has exactly the two on-link prefixes
implied by the addresses (`26.b.c.0/24` and `fd64:2534:1111::/64`) and nothing
else.

Android's VPN UID routing does not fall back to the underlying network for an
app that is inside `addAllowedApplication`: traffic from that UID is directed at
the VPN's routing table, and traffic with no matching route is dropped rather
than leaked. So in STANDBY **the game is scoped into a tunnel that can reach
nothing**, and the engine sits in a 200 ms sleep loop doing exactly that.

This is reachable from the UI: `VpnActions.ACTION_DEACTIVATE` →
`PacketVpnService.java:205-208` → `engine.toggle(false)` → `restartTunnel(false)`
→ `run()` with `isActive == false`.

**Fix** — STANDBY must not scope anyone. Two teardown-free options; both leave
the ACTIVE path byte-identical:

*(a) preferred — keep the VPN indicator, capture nobody.* Skip the allow-list in
standby, so the tunnel is unscoped **and** route-less, which matches nothing:

```java
int scopedApps = 0;
if (isActive) {
    for (String pkg : allow) { ... builder.addAllowedApplication(pkg); scopedApps++; ... }
} else {
    // STANDBY: an unscoped, route-less tunnel keeps the key icon up and
    // captures nothing. Scoping the game here would strand it with no route.
    builder.addDisallowedApplication(context.getPackageName());
}
if (isActive) addActiveRoutes(builder, scopedApps > 0);
```

*(b)* don't establish at all in standby — close the tun and idle. Simpler, but
drops the VPN key icon and re-prompts on the next activate on some OEM builds.

Either way this is a *standby*-only change: nothing here runs while a match is
live, so the `ff-route-fallback-kick` rule is untouched.

**[DEVICE] Test:** start the engine, join a match, press Deactivate on the
overlay, and watch the game. Today: expect "network error" / disconnect within
seconds. After the fix: expect the match to continue on the normal network.
`adb shell ip rule` + `ip route show table <vpn>` while in standby confirms the
route table is empty.

---

## 3. Restart handoff race nulls the live `tunWriter` **[CERTAIN]**

`core/VpnEngine.java:394-447` (`restartTunnel`) tears down and re-spawns:

```java
try { if (vpnT != null) vpnT.join(1000); } catch (Exception e) { }   // :415
...
vpnT = new Thread(VpnEngine.this, nextActive ? "VPN-A" : "VPN-S");    // :439
vpnT.start();                                                         // :440
```

The join has a **1000 ms timeout and its result is not checked**. If the old
thread has not exited — the common case when a blocking `read()` on a closed tun
fd does not return promptly (see finding 3b) — the new thread starts anyway and
reaches:

```java
FileOutputStream out = new FileOutputStream(tun.getFileDescriptor());
tunWriter = out;                                                      // :531
packetLoop.loop(in, out);
```

Later the **old** thread finally unwinds and runs its own `finally`:

```java
} finally {
    try { tcpProxy.closeAll(); } catch (Exception e) { }
    tunWriter = null;                                                 // :544
}
```

`tunWriter` is a single `volatile` field shared by both sessions
(`core/VpnEngine.java:65`). The dead thread nulls the live thread's writer.
Everything that writes to the tun off-loop then silently no-ops
(`core/VpnEngine.java:738-748`):

```java
public void writeToTun(byte[] pkt) {
    FileOutputStream out = tunWriter;
    if (out == null) return;                                          // :740
```

`TcpProxy` writes **only** through `writeToTun` (`:358`, `:363`, `:368`, `:373`).
So the consequence is: after a restart whose join timed out, the userspace TCP
relay accepts the client's SYN, ACKs its data, advances `ourNext`, relays
everything to the real server — and delivers nothing back to the game, forever,
for the whole life of that tunnel. That is lobby/login/matchmaking dead with no
error anywhere. There is no retransmit queue in `TcpProxy`, so nothing recovers.

Compounding it: the old thread also calls `tcpProxy.closeAll()` at `:540`, which
RSTs the **new** session's connections.

**Fix** — make the writer owned by the session that created it, so a stale thread
cannot clear it:

```java
// field
private final java.util.concurrent.atomic.AtomicReference<FileOutputStream> tunWriter
        = new java.util.concurrent.atomic.AtomicReference<>();

// in run()
FileOutputStream out = new FileOutputStream(tun.getFileDescriptor());
tunWriter.set(out);
...
} finally {
    tunWriter.compareAndSet(out, null);   // only clear MY writer
    ...
}
```

and guard the old thread's `closeAll()` the same way `stop()` is guarded at
`:561` — `if (vpnT == Thread.currentThread())`. Both are pure ownership checks;
no packet is added, removed, reordered or delayed.

Also: check the join result and record it, because a timed-out join is the
precondition for this whole class of bug:

```java
if (vpnT != null) {
    vpnT.join(1000);
    if (vpnT.isAlive()) logger.logControl("TUN_JOIN_TIMEOUT", "thread=" + vpnT.getName());
}
```

### 3b. Does closing the tun fd actually unblock the reader? **[DEVICE]**

`setBlocking(true)` at `core/VpnEngine.java:472`, and the reader blocks in
`in.read(buf)` at `core/PacketLoop.java:42`. `restartTunnel` closes the
`ParcelFileDescriptor` at `:409` and hopes the read throws. Whether a blocked
`read()` on a closed fd returns is **kernel- and device-dependent**; on the
devices where it does not, the reader stays parked until the next inbound packet
arrives on an interface that no longer exists, i.e. possibly never, and finding 3
fires every time.

There is a worse tail: the fd number is released by `close()` and can be reused by
another thread's `open()` (this process opens capture files, `/proc/*/cmdline`,
SharedPreferences), at which point the parked `read()` is reading an unrelated
file and feeding it to `PacketLoop`.

**Test:** add a temporary control log at `core/PacketLoop.java:43` and at the
`catch` in `core/VpnEngine.java:533`, then toggle the target app
(`ACTION_SET_APP`, which calls `restartTunnel(true)` at `PacketVpnService.java:190`)
20 times and count how often `TUN_JOIN_TIMEOUT` fires on the SM-S948U1. If it
fires at all, the reader needs an explicit wake: keep a reference to the
`FileInputStream`, and in `restartTunnel` close **the stream** before the PFD and
`vpnT.interrupt()` after the PFD, then re-join. Do not increase the join timeout;
that just lengthens the window.

*The loop's other exits are correct:* `len < 0 → break` (`PacketLoop.java:43`)
handles EOF without hot-spinning, and a tun `read()` cannot return 0, so there is
no EOF/EINTR spin. `buf` is 65535 (`:39`), far above the 1280 MTU, so no packet
is ever truncated on read.

---

## 4. One exception in the inbound pipeline silently re-NATs the flow **[CERTAIN code / DEVICE consequence]**

`core/UdpSessionManager.java:354-366`:

```java
} catch (java.net.SocketTimeoutException e) {
    if (!engine.isRun || !engine.isActive) break;
    if (System.currentTimeMillis() - fe.t > IDLE) break;
} catch (Exception e) {
    break;                                                            // :358
}
}
udpMap.remove(key, fe);                                               // :361
try { fe.s.close(); } catch (Exception e) { }
```

`catch (Exception) → break` covers the entire body of the receive loop, which is
**not** just I/O. Between `:213` and `:339` that body runs: the header solver
(`pipeline.observeAndParse`), `BodyCrypt.decrypt`, six ESP decoders
(`observePriSync`, `observeEquipment`, `observeBindPri`, `roster.observeJoin/
Kill/Quit`), `SessionTimeline`, `VisibilityMask`, the hit-confirmation taxonomy,
`observeChainPacket`, `observeDamage`, `observeHandleEvent`, the filter engine,
the capture, and the packet builder. Any `ArrayIndexOutOfBoundsException` or
`NullPointerException` from any of those — on one malformed or unexpected
datagram — silently kills the receive thread for that flow.

The socket is then closed and removed from the map. The next outbound packet for
the same 3-tuple calls `getOrCreate` (`:150`), which does
`new DatagramSocket()` (`:154`) — **a fresh ephemeral source port**.

From the server's point of view the client's UDP endpoint just changed mid-match.
That is the same fingerprint as the NAT break in `ff-ack-starvation-kicks`, and
the trigger is a single decoder bug on a single packet, logged nowhere.

The same `break` fires on the idle path (`:356`, `IDLE = 0xafc8 = 45 s`,
`SO_TO = 0x7530 = 30 s` at `:32-33`), so a flow that stays quiet for 45 s also
comes back on a new source port.

**Fix** — separate "this socket is dead" from "a decoder threw", and never let the
second close a socket. This changes no bytes and no timing:

```java
} catch (java.net.SocketTimeoutException e) {
    if (!engine.isRun || !engine.isActive) break;
    if (System.currentTimeMillis() - fe.t > IDLE) break;
} catch (java.io.IOException e) {
    break;                       // real socket death: closed, ENETUNREACH, ...
} catch (RuntimeException e) {
    // A decoder threw on one packet. Drop the packet, KEEP the socket:
    // closing it re-NATs us onto a new source port mid-match.
    engine.telemetry().event(TelemetryCollector.EV_RECV_DECODE_FAIL);
    logger.logControl("RECV_DECODE_FAIL", e.getClass().getSimpleName() + " len=" + rlen);
}
```

(`rlen` must be hoisted above the try for the log; or log without it.)

And move the cleanup into a `finally` so it cannot be skipped:

```java
} finally {
    udpMap.remove(key, fe);
    try { fe.s.close(); } catch (Exception ignored) { }
}
```

⚠ **Not proposed:** extending the idle timeout or pinning the source port.
Both change what the server sees. The idle reap is a real design decision; it is
flagged here only so it is a *decision* rather than an accident, and so that when
it fires it is visible.

**[DEVICE] Test:** instrument `getOrCreate` to log every socket creation with its
`getLocalPort()`. Play a full match. Any second creation for the same 3-tuple is
a mid-match re-NAT. Correlate with match drops.

---

## 5. `onRevoke()` is not handled anywhere **[CERTAIN]**

`grep -rn "onRevoke" ` over the whole source tree returns **nothing**.
`PacketVpnService` does not override it.

The platform default `VpnService.onRevoke()` calls `stopSelf()`, so the service
does eventually die — but:

* **No state broadcast.** `engine.broadcastState()` is never called on the revoke
  path, so the overlay and `MainActivity` keep showing ACTIVE until something else
  happens to broadcast. `PacketVpnService.snapshot()` (`:48-51`) returns null only
  once `instance` is cleared in `onDestroy` (`:369`), which is later.
* **No telemetry event and no log**, so a revoke is indistinguishable in the
  capture from any other stop.
* **`onRevoke` runs on a Binder thread**, not the main thread. The default
  `stopSelf()` is safe there; anything added must be too.
* **Every subsequent Activate silently no-ops.** After a revoke, a new service
  instance's `run()` reaches `builder.establish()` at `core/VpnEngine.java:516`,
  which returns `null` when consent is gone, and the code does:

  ```java
  if (tun == null) { stop(); return; }                          // :517-520
  ```

  `stop()` → `stopSelf()`. No toast, no log, no broadcast that distinguishes this
  from a normal stop. The user presses Activate, the button flickers, nothing
  happens, forever, until they re-grant VPN consent — which nothing tells them to
  do. This is a large part of "the VPN service is very scuffed".

**Fix:**

```java
@Override
public void onRevoke() {
    // Binder thread. Do not block.
    devLogger.logControl("VPN_REVOKED", "");
    if (engine != null) {
        engine.telemetry().event(TelemetryCollector.EV_VPN_REVOKED);
        engine.broadcastState();   // flip the UI off before we die
    }
    super.onRevoke();              // stopSelf()
}
```

and make the `establish() == null` path say why, at `core/VpnEngine.java:517`:

```java
if (tun == null) {
    logger.logControl("TUN_ESTABLISH_FAILED", "consent_revoked_or_other_vpn_active");
    telemetry.event(TelemetryCollector.EV_TUN_ESTABLISH_FAIL);
    stop();
    return;
}
```

`MainActivity` already re-checks `VpnService.prepare()` before starting
(`MainActivity.java:293-298`), so a distinguishable failure is all the UI needs to
route the user back to the consent dialog.

---

## 6. `stop()` racing `restartTunnel()` leaves `isRun == true` with no tunnel **[CERTAIN]**

The `stopped` flag is documented at `core/VpnEngine.java:43` as
*"set by stop(); restart must never respawn after this"*. The **thread body**
honours it: `run()` returns immediately at `:451`. The **flags do not**.

`restartTunnel` (`core/VpnEngine.java:394-447`) checks `stopped` at `:398`,
`:419` and `:437`, then:

```java
if (stopped) return;   // stop() raced us between checks               // :437
isRun = true;                                                          // :438
vpnT = new Thread(VpnEngine.this, ...);                                // :439
vpnT.start();                                                          // :440
```

`stop()` (`core/VpnEngine.java:860-885`) runs on the caller's thread — the main
thread, from `PacketVpnService.stop()` (`:379-382`) — and sets:

```java
stopped = true;                                                        // :862
isRun = false;                                                         // :863
```

Interleave `stop()` between `:437` and `:438` and the final state is
`stopped == true, isRun == true`. Nothing ever clears `isRun` again:

* `startStats()`'s loop condition is `while (isRun && !stopped)`
  (`:678`) — it exits immediately, so no stats tick ever corrects the flag.
* `snapshotState()` (`:269-279`) reports `engineRun = true`.
* `PacketVpnService.engineStopped()` (`:256-258`) returns **false**, so
  `enqueueOrApplyFilterToggle` (`:275-287`) stops short-circuiting and starts
  queueing taps into a queue nothing will ever drain (the drain is triggered only
  by `onEngineStateChanged` with `isRunnable()`, `PacketVpnService.java:94-98`).
* `MainActivity.startEngine()` (`MainActivity.java:306-315`) reads
  `snapshot().engineRun` and returns early with *"Engine already running"*.

So: press Stop at the wrong microsecond and the app is wedged into "already
running, nothing works" until the process is killed.

The same shape exists on the first-start path: `start()` (`:360-377`) does
`isRun = true; vpnT = new Thread(...)` with **no `stopped` check at all**, so
`ACTION_ACTIVATE` arriving on a service instance whose engine has already been
stopped (possible: `stopSelf()` is asynchronous and a `startService` in that
window is delivered to the live instance) produces exactly the same wedge, plus a
`Thread` that does nothing and a `startStats()` that `executeSafe` (`:385-392`)
silently rejects because `stopped` is set.

**Fix** — make the invariant cover the flags, not just the thread body, and make
`start()` refuse after `stop()`:

```java
public void start() {
    if (stopped) {                 // this engine instance is spent
        logger.logControl("START_AFTER_STOP", "ignored");
        notifyStateChanged();
        return;
    }
    isRun = true;
    ...
}
```

and in `restartTunnel`, publish `isRun` only after the thread is actually live,
then re-check:

```java
isRun = true;
vpnT = new Thread(VpnEngine.this, nextActive ? "VPN-A" : "VPN-S");
vpnT.start();
if (stopped) { isRun = false; }   // stop() won the race; do not claim to run
```

`stop()` should also be explicitly idempotent (it is called at least twice on
every shutdown — `PacketVpnService.stop()` → `engine.stop()` → `stopSelf()` →
`onDestroy()` → `stop()` → `engine.stop()`):

```java
public void stop() {
    if (!stopped) {        // first call does the work
        stopped = true;
        ...
    }
    vpnService.stopSelf();
}
```

Today the second pass re-runs `filterEngine.disableAll()`, `notifyStateChanged()`
(a `sendBroadcast` from inside `onDestroy`), `tcpProxy.closeAll()`,
`sessions.closeAll()` and a second `threadPool.shutdownNow()`. None of those
crash, but none of them should run either.

**⚠ Note on `stopped` being permanently latched:** that is *correct* as long as
the `VpnEngine` instance dies with the service, which it does
(`PacketVpnService.onCreate` builds a new one at `:93`). The bug is not the
latch; it is that the other flags are not latched with it.

---

# S2 — silent data loss / engine "running" while doing nothing

## 7. `getOrCreate` can leave a reader-less socket in the session map **[CERTAIN]**

`core/UdpSessionManager.java:150-172`:

```java
DatagramSocket sock = new DatagramSocket();
vpnService.protect(sock);
...
SE se = new SE(sock);
SE prev = udpMap.putIfAbsent(key, se);                                // :162
if (prev != null) { sock.close(); return prev; }
threadPool.execute(new RecvRunnable(se, sp, dip, dp, out, key));      // :167
return se;
} catch (Exception e) {
    return null;                                                      // :170
}
```

The socket is published into `udpMap` at `:162`, **before** the reader thread is
created at `:167`. If `threadPool.execute` throws — `RejectedExecutionException`
after `stop()`'s `shutdownNow()` (`core/VpnEngine.java:883`), or
`OutOfMemoryError`'s cousin when thread creation fails under the unbounded pool of
finding 19 — then:

1. The exception is swallowed by `catch (Exception)` at `:169`.
2. `getOrCreate` returns `null`, so `send()` returns at `:131` and the outbound
   packet is dropped **without incrementing `pDrop`** — it is invisible to the
   loss stat too.
3. The socket stays in `udpMap` with **no reader for the rest of the tunnel's
   life**. Every subsequent packet for that 3-tuple takes the `existing != null`
   fast path at `:151-152` and sends successfully, and every reply is received by
   the kernel and thrown away.

A flow in this state looks perfectly healthy outbound and is completely deaf
inbound. That is the single worst failure shape in this codebase's own idiom: a
silent no-op indistinguishable from a working feature.

The same `catch` also swallows `new DatagramSocket()` failing on fd exhaustion,
producing a silent total outbound blackout with no counter movement.

**Fix:**

```java
SE se = new SE(sock);
SE prev = udpMap.putIfAbsent(key, se);
if (prev != null) { sock.close(); return prev; }
try {
    threadPool.execute(new RecvRunnable(se, sp, dip, dp, out, key));
} catch (Throwable t) {
    // No reader means a deaf session. Never leave one in the map.
    udpMap.remove(key, se);
    try { sock.close(); } catch (Exception ignored) { }
    logger.logControl("SESSION_READER_REJECTED", "key=" + Long.toHexString(key));
    return null;
}
return se;
```

and make the outer failure loud rather than silent:

```java
} catch (Exception e) {
    logger.logControl("SESSION_CREATE_FAIL", e.getClass().getSimpleName());
    engine.telemetry().event(TelemetryCollector.EV_SESSION_CREATE_FAIL);
    return null;
}
```

Also count the drop in `send()` (`:131`) so it reaches the loss stat:
`if (se == null) { engine.pDrop.incrementAndGet(); return; }`

---

## 8. No network-change awareness at all **[CERTAIN absence / DEVICE behaviour]**

`grep -rn "ConnectivityManager\|NetworkCallback\|setUnderlyingNetworks"` over the
whole tree returns **nothing**. `ACCESS_NETWORK_STATE` is declared
(`AndroidManifest.xml:14`) and never used.

Consequences on a Wi-Fi↔cellular handover, or when the underlying network dies:

* Every per-flow `DatagramSocket` (`core/UdpSessionManager.java:154`) and every
  `TcpProxy` remote `Socket` (`core/TcpProxy.java:62`) was `protect()`ed and
  implicitly bound to the *old* default network's source address. They do not
  migrate. Sends fail with `ENETUNREACH`/`EHOSTUNREACH`.
* That failure is swallowed here — `core/UdpSessionManager.java:145-147`:

  ```java
  } catch (Exception e) {
      // ignore send failure
  }
  ```

  No counter, no log, no telemetry. `pSent` does not advance, `pDrop` does not
  advance. The stats broadcast keeps reporting the last loss figure.
* The receive thread is parked in `receive()` for up to `SO_TO` = 30 s, then
  needs `IDLE` = 45 s of quiet to break (`:354-356`). So the flow is dead for
  30-60 s before anything at all reacts, and what it then does is re-NAT onto a
  new source port (finding 4).
* `setUnderlyingNetworks()` is never called, so the VPN's reported capabilities
  and the system's "is this VPN validated" logic run on defaults.

**Fix** — observe, report, and let the existing reaper do the work. Do **not**
restart the tunnel (`ff-route-fallback-kick`):

```java
// VpnEngine, API 21+ safe
private ConnectivityManager.NetworkCallback netCb;

private void startNetworkWatch() {
    ConnectivityManager cm = (ConnectivityManager)
            context.getSystemService(Context.CONNECTIVITY_SERVICE);
    if (cm == null) return;
    netCb = new ConnectivityManager.NetworkCallback() {
        @Override public void onAvailable(android.net.Network n) {
            // Tell the platform what we ride on; NEVER rebuild the interface.
            if (Build.VERSION.SDK_INT >= 22) {
                vpnService.setUnderlyingNetworks(new android.net.Network[] { n });
            }
            logger.logControl("NET_CHANGED", "net=" + n);
            telemetry.event(TelemetryCollector.EV_NETWORK_CHANGED);
        }
        @Override public void onLost(android.net.Network n) {
            logger.logControl("NET_LOST", "net=" + n);
        }
    };
    NetworkRequest req = new NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build();
    cm.registerNetworkCallback(req, netCb);   // API 21; default-callback is 24
}
```

unregister it in `stop()`. Minimum viable version if even that is too much: make
the swallowed send failure visible —

```java
} catch (Exception e) {
    engine.pDrop.incrementAndGet();
    engine.noteSendFailure(e);     // rate-limited log + telemetry event
}
```

⚠ **SEMANTICS decision, not proposed here:** the *complete* fix is to close the
stale sessions on a network change so they re-open on the new network
immediately instead of 30-60 s later. That changes the client's source port at a
moment of the app's choosing, which is precisely the kind of thing that reads as
a disconnect to the server. It is also what already happens, just later and
invisibly. This needs a match-time A/B before anyone ships it.

**[DEVICE] Test:** join a match on Wi-Fi, walk out of range so the phone falls to
cellular, and time how long until the game recovers or errors. Instrument
`core/UdpSessionManager.java:145` with a counter first so the failure is visible
in the capture.

---

## 9. Zero allowed apps silently downgrades the tunnel **[CERTAIN]**

`core/VpnEngine.java:502-514`:

```java
int scopedApps = 0;
for (String pkg : allow) {
    if (pkg != null && !pkg.isEmpty()) {
        try { builder.addAllowedApplication(pkg); scopedApps++; }
        catch (Exception e) {
            // Not installed for this user; the others still apply.          // :509
        }
    }
}
if (isActive) addActiveRoutes(builder, scopedApps > 0);                      // :514
```

The question asked was: **what happens when no target package is installed?**
Answer: `scopedApps == 0`, so `addActiveRoutes(builder, false)`
(`:602-615`) takes the *unscoped* branch and installs the narrow pair
(`148.0.0.0/8` + `103.78.86.128/25`), **not** a default route. So the device is
not wholly tunnelled — good, and the design intent at `:596-600` holds.

But the failure is invisible, and it is exactly the failure mode
`app/GameTargets.java:18-37` exists to make impossible:

* `addAllowedApplication` throwing is swallowed per-package with no record
  (`:508-510`). A user whose selected package was uninstalled gets an unscoped
  tunnel and no signal.
* The `MODE_VPN_TUN_READY` log (`:521-525`) prints `pkg=` *the requested set*, not
  how many were actually applied. The one number that distinguishes "scoped to the
  game" from "scoped to nobody" is never recorded.
* The dev logger is disabled by default (`PacketVpnService.java:102`), so even
  that log is usually absent.
* `activeRouteModeName()` (`:625-630`) will then report
  `narrow_148_8_plus_103_78_86_128_25_UNSCOPED` — correct, but only in a log
  nobody is reading.

**Fix** — record what actually happened, and refuse to silently mean something
different from what the user asked for:

```java
java.util.List<String> failed = new java.util.ArrayList<>();
for (String pkg : allow) {
    if (pkg == null || pkg.isEmpty()) continue;
    try { builder.addAllowedApplication(pkg); scopedApps++; }
    catch (Exception e) { failed.add(pkg); }
}
if (!allow.isEmpty() && scopedApps == 0) {
    // The user picked target apps and NONE of them applied. An unscoped tunnel
    // is a different product; say so loudly rather than quietly becoming one.
    logger.logControl("SCOPE_EMPTY",
            "requested=" + allow + " none_installed -> UNSCOPED tunnel");
    telemetry.event(TelemetryCollector.EV_SCOPE_EMPTY);
}
logger.logControl("MODE_VPN_TUN_READY",
        "active=" + isActive + " route=" + activeRouteModeName()
        + " scoped=" + scopedApps + "/" + allow.size()
        + " failed=" + failed + " tun_ip=" + ip);
```

`scoped=N/M` belongs in the HUD line too; `app/GameTargets.debugLine()`
(`:154-174`) already renders the adjacent fact and this is the missing half.

### 9b. The app never excludes itself in the unscoped branch **[CERTAIN, latent]**

When `scopedApps > 0` the app is excluded automatically — `addAllowedApplication`
is a whitelist and this package is not on it. When `scopedApps == 0` there is no
exclusion of any kind. Today nothing loops, because every socket the engine opens
is `protect()`ed (`core/UdpSessionManager.java:109`, `:155`,
`core/TcpProxy.java:243`). One unprotected socket — a future analytics call, an
update check, an `HttpURLConnection` anywhere — and the app's own traffic to
`148.0.0.0/8` routes into its own tun and is relayed by itself.

**Fix** (API 21+, must be the *else* branch — mixing allowed and disallowed
applications throws `UnsupportedOperationException`):

```java
if (scopedApps == 0) {
    try { builder.addDisallowedApplication(context.getPackageName()); }
    catch (Exception e) { logger.logControl("SELF_EXCLUDE_FAIL", String.valueOf(e)); }
}
```

Note this must be decided **before** any `addAllowedApplication` call in the same
builder, so the loop needs to compute `scopedApps` against
`GameTargets.isInstalled()` first, or build two builders. Cheapest correct shape:
pre-filter `allow` with `GameTargets.isInstalled(context, pkg)` (that method
already exists, `app/GameTargets.java:63-71`), then branch once.

---

## 10. `TcpProxy` latches "started" before it starts **[CERTAIN]**

`core/TcpProxy.java:201-205`:

```java
private void startWriter(final Conn c) {
    synchronized (c.lock) {
        if (c.writerStarted || c.closed) return;
        c.writerStarted = true;                                        // :204
    }
    pool.execute(new Runnable() { ... });                              // :206
}
```

and identically at `:263-268` for `relayStarted`.

`pool.execute` is **not** guarded. The engine's `executeSafe`
(`core/VpnEngine.java:385-392`) exists precisely because this pool is shut down
by `stop()` — but `TcpProxy` bypasses it at `:206`, `:239` and `:268`. When
`execute` throws `RejectedExecutionException`:

* the flag stays `true`, so no later call will ever retry;
* the exception unwinds into `handlePacket`'s catch-all at `:173-175`
  (*"Never let a malformed packet kill the tun loop"*) and vanishes;
* for the writer: client bytes pile up in `c.toRemote` and are never sent;
* for the relay: nothing ever reads the remote socket, so the server's replies
  are never delivered;
* in both cases the client's TCP sees a live, ACKing connection that transfers
  nothing — it will retransmit into silence rather than reconnect.

`connectAsync` (`:238-260`) has the same unguarded `execute`, and there the
`Conn` and its already-constructed `Socket` (`:62`) are left in `conns` forever
with nothing to close them.

**Fix** — set the latch only on success, and make rejection tear the connection
down the way every other failure in this class does:

```java
private void startWriter(final Conn c) {
    synchronized (c.lock) {
        if (c.writerStarted || c.closed) return;
        c.writerStarted = true;
    }
    try {
        pool.execute(new Runnable() { ... });
    } catch (Throwable t) {
        synchronized (c.lock) { c.writerStarted = false; }
        sendRst(c);
        teardown(c.clientPort);
    }
}
```

Same three lines at `connectAsync` and `startRelay`. An RST is what every other
failure path in this class already emits (`:228-229`, `:255-256`, `:314-316`), and
the class comment at `:36-37` says that is deliberate: the game reconnects instead
of retransmitting into silence.

---

## 11. IPv6: advertised, never routed, silently dropped **[CERTAIN code / DEVICE impact]**

`core/VpnEngine.java:464` + `:469-470`:

```java
String ipsix = IPV6;                              // "fd64:2534:1111::2"  (:34)
...
.addAddress(ip, 24)
.addAddress(ipsix, 64)
```

and `addActiveRoutes` (`:602-615`) installs **only IPv4 routes** — `0.0.0.0/0`
or the narrow IPv4 pair. There is no `addRoute("::", 0)` anywhere.

Then `core/PacketLoop.java:47-52`:

```java
int version = (buf[0] >> 4) & 0xf;
if (version != 4) {
    logger.logProtocolDrop("DROP_NON_IPV4", ...);
    continue;
}
```

So the state is: the tunnel **claims** an IPv6 address (which makes the VPN
network look IPv6-provisioned to every app inside it, and makes the resolver
willing to return AAAA), installs no IPv6 route beyond the on-link
`fd64:2534:1111::/64`, and drops anything that does arrive — into a logger that
`PacketVpnService.java:102` disables at startup, so the drop is literally silent.

What saves it today is RFC 6724: `fd64::/7` is ULA, precedence 3, below IPv4's
35, so a dual-stack destination is tried over IPv4 first. That is luck, not
design. The black-hole cases are real:

* an IPv6-only match server or CDN endpoint → no route → the game stalls;
* a carrier on IPv6-preferring 464XLAT where the game's own stack prefers AAAA;
* any library inside the game that binds `AF_INET6` explicitly.

**Fix** — pick one and make it explicit. Both are one line and neither touches the
IPv4 path:

*(a) Honest: drop the IPv6 address.* Remove `.addAddress(ipsix, 64)` at `:470`.
The tunnel is then IPv4-only, apps inside it see no IPv6 source address, the
resolver stops offering AAAA, and `DROP_NON_IPV4` stops being reachable. This is
the right choice given the packet loop is IPv4-only by construction and the game
is known to speak IPv4 (`ff-udp-framing-solved`, 182 708 captured outbound
packets, all IPv4).

*(b) Complete: add `builder.addRoute("::", 0)` and handle v6 in `PacketLoop`.*
That is a real feature (v6 header parse, v6 NAT keys, v6 `PacketBuilder`), not a
robustness fix. Not recommended unless a capture shows the game using v6.

Until one is chosen, at minimum make the drop countable rather than log-only:
`engine.pDrop.incrementAndGet()` plus a rate-limited telemetry event at `:49`.

**[DEVICE] Test:** `adb shell dumpsys connectivity | grep -A5 tun` while the
tunnel is up, to confirm no `::/0` route; then `adb shell ip -6 route show table
<vpn table>`. Then run the game on an IPv6-heavy carrier APN and diff the outbound
packet count against a Wi-Fi session.

---

## 12. `onStartCommand` redelivery semantics are accidental **[CERTAIN]**

`PacketVpnService.onStartCommand` returns three different things:

```java
if (intent == null || intent.getAction() == null) return START_STICKY;   // :172
...
} else if (ACTION_STOP)       { ...; return START_NOT_STICKY; }          // :195
} else if (ACTION_DEACTIVATE) { ...; return START_NOT_STICKY; }          // :208
...
return START_STICKY;                                                     // :253
```

The return value is a property of the **service**, and the most recent call wins.
So the service's restart policy is whatever the last intent happened to be:
after a Deactivate it is NOT_STICKY, after the next filter toggle it is STICKY
again. Nobody designed that.

The STICKY case is actively harmful for a VPN. After a process kill the system
recreates the service with a **null intent**, which lands at `:172` and returns
without doing anything — but `onCreate()` has already run `setupForeground()`
(`:100`), so the user gets a permanent *"VPN đang hoạt động…"* notification
attached to a service with no tunnel, no engine thread, and no consent check.
`engine.isRun()` is false, so nothing recovers until the user opens the app.

**Fix** — one policy, and refuse the null-intent recreate:

```java
@Override
public int onStartCommand(Intent intent, int flags, int startId) {
    if (intent == null || intent.getAction() == null) {
        // Sticky recreate after a process kill: VPN consent may be gone and we
        // have no action to replay. Do not sit here wearing a notification.
        stopSelf();
        return START_NOT_STICKY;
    }
    ...
    return START_NOT_STICKY;   // every path
}
```

`START_NOT_STICKY` is correct for a VpnService: the tunnel requires user consent
that may have lapsed, and an auto-resurrected VPN that cannot establish is worse
than none. `START_REDELIVER_INTENT` is **wrong** here — redelivering a queued
`ACTION_FREEZE` after a kill would flip a filter the user never pressed.

---

## 13. `foregroundServiceType="dataSync"` on a VPN **[CERTAIN]**

`AndroidManifest.xml:56` (and `:48` for the overlay service):

```xml
android:foregroundServiceType="dataSync"
```

matched by `ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC` at
`PacketVpnService.java:119` and the `FOREGROUND_SERVICE_DATA_SYNC` permission at
`AndroidManifest.xml:20`.

At `targetSdk 34` this is legal and works. It is a timer, not a bug — yet:

* **Android 15 (API 35) puts a cumulative 6-hour-per-24h timeout on `dataSync`
  foreground services.** When it expires the system calls `Service.onTimeout()`
  and the app must stop the service; if it does not, the service is killed (and
  on later versions, an ANR). `PacketVpnService` does not override `onTimeout`.
  The moment `targetSdk` goes from 34 to 35 — which `compileSdk 35` is one line
  away from — a long session ends with the tunnel being killed underneath a live
  match. This is documented and has bitten shipping VPN apps (Brave, issue
  #53866).
* The correct type for a VPN that must run indefinitely is **`specialUse`**.
  `systemExempted` is reserved for system integrations and will be rejected.
  `specialUse` requires, in the `<service>` element:

  ```xml
  <service android:name="...PacketVpnService"
      android:permission="android.permission.BIND_VPN_SERVICE"
      android:foregroundServiceType="specialUse">
      <property
          android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
          android:value="vpn_tunnel" />
      ...
  </service>
  ```

  plus `<uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />`
  and `ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE` at
  `PacketVpnService.java:119`.

Two smaller manifest issues in the same block:

* `AndroidManifest.xml:8-11` still carries a `<uses-sdk>` element. Gradle
  overrides it; it is dead weight that will disagree with `build.gradle` the first
  time one is bumped and not the other.
* `FloatingOverlayService` (`:48`) is also `dataSync` and is also not a data sync.
  Same timer, same fix.

### 13b. `POST_NOTIFICATIONS` is never requested before going foreground **[CERTAIN]**

`AndroidManifest.xml:19` declares it. `app/PermissionController.java:73-84`
requests it — but only when the user taps that specific row, and
`MainActivity.startEngine()` (`MainActivity.java:306-335`) does not check it
before starting the service. On Android 13+ with the permission denied,
`startForeground()` still succeeds and the service runs, but **the notification is
not shown**. The user gets a VPN with no visible, tappable control surface — only
the system's VPN key icon.

Separately, the notification itself (`PacketVpnService.java:113-117`) has no
`setContentIntent`, so even when visible, tapping it does nothing. (UI polish is
out of scope here; the *behavioural* half is that there is no route back to the
app from the only persistent affordance the service has.)

**Fix:** gate `startEngine()` on the permission the same way it is gated on VPN
consent at `MainActivity.java:293-298`, or at minimum surface
`PermissionController.refresh()`'s `notifOk` state before starting.

---

## 14. `TcpProxy.toClient` is unbounded **[CERTAIN]**

`core/TcpProxy.java:289-292`, inside the relay read loop:

```java
synchronized (c.lock) {
    c.toClient.add(copyOf(buf, n));
}
flushToClient(c);
```

The relay keeps reading from the remote socket and appending to `toClient`
regardless of how much is already queued. `flushToClient` (`:335-353`) refuses to
emit while the client's window is shut (`:345`), which is the correct and
deliberate behaviour described at `:24-29`. The missing half is backpressure:
nothing stops the remote from filling the heap while the client's window stays
closed.

The class comment at `:26-29` describes exactly this scenario as the bug it was
written to fix ("permanently stalled the lobby connection after long matches:
*can't exit team*"). The window handling fixed the *correctness*; the *memory* is
still unbounded.

The advertised window makes it worse: `buildTcpIp` hard-codes the relay's own
receive window to 65535 on every segment (`:447-448`) irrespective of how much is
sitting in `toRemote` (`:65`), so the client is told it may send at full rate into
a queue drained by a single writer thread that may be blocked on a stalled remote.

**Fix** — stop reading from the remote once the backlog is large, which is what a
real stack does and what the client's own window already implies:

```java
private static final int MAX_QUEUED_TO_CLIENT = 512 * 1024;   // ~410 MSS

// in the relay loop, after adding:
int queued;
synchronized (c.lock) { queued = c.toClientBytes; }   // maintain a byte counter
while (queued > MAX_QUEUED_TO_CLIENT && !c.closed && engine.isRun) {
    try { Thread.sleep(10); } catch (InterruptedException e) { break; }
    synchronized (c.lock) { queued = c.toClientBytes; }
}
```

Blocking the relay thread propagates backpressure to the remote's TCP window
naturally, and it does not change a single byte the client sees. Mirror the same
cap on `toRemote` (`:65`) and drop the advertised window at `:447-448` from a
constant 65535 to `65535 - min(65535, toRemoteBytes)`.

⚠ This is the one `TcpProxy` change that alters *timing* on the lobby path
(a stalled remote now stalls sooner). It does not touch UDP, and the lobby path
is not latency-critical the way the match stream is — but it is a behaviour
change, so flagging it.

---

# S3 — hygiene, leaks, lying diagnostics

## 15. Byte and loss counters are never reset **[CERTAIN]**

`core/VpnEngine.java:54-58`:

```java
final AtomicLong bIn = new AtomicLong();
final AtomicLong bOut = new AtomicLong();
final AtomicLong pSent = new AtomicLong();
final AtomicLong pDrop = new AtomicLong();
final AtomicLong outUdpSeen = new AtomicLong();
```

Nothing writes `.set(0)` to any of them anywhere. `restartTunnel`
(`:394-447`) resets `GamePacketTaxonomy`, `pipeline`, `lobbyKey`, `aimBias` and
`PacketIntegrity` — and leaves these five. `stop()` (`:860-885`) resets none.

The stats loop then computes, `:684-687`:

```java
long sent = pSent.get();
long drop = pDrop.get();
long total = sent + drop;
int loss = total > 0 ? (int) (drop * 100L / total) : 0;
```

So the "loss" in the HUD is a **cumulative average over the whole process
lifetime**, across every tunnel session. Turn Freeze on for 30 s — which `DROP`s
by design (`core/PacketLoop.java:216-218`) — and the number climbs and then can
never come back down, because the denominator only grows. The same for
bytes-in/out, which are lifetime totals labelled as if they were session totals.

This is the requested sweep item: **state in `VpnEngine` that neither `stop()` nor
`run()` resets.** These five are it (plus findings 20 and 21).

**Fix** — reset in `run()`, which is the one place that is guaranteed to run once
per tunnel session:

```java
// VpnEngine.run(), alongside the existing learner resets at :456-460
bIn.set(0); bOut.set(0); pSent.set(0); pDrop.set(0); outUdpSeen.set(0);
```

Note `outUdpSeen` (`:58`, incremented at `core/PacketLoop.java:89`) now has **no
readers at all** — its only consumer was `scheduleLobbyRouteFallbackIfNoUdp`,
which is a documented no-op (`:666-668`). Either delete it or give it a reader.

---

## 16. The telemetry poller thread is never stopped **[CERTAIN]**

`core/VpnEngine.java:365` starts it (`startTelemetry()`, `:178-223`), which calls
`TelemetryCollector.start()` (`dev/capture/TelemetryCollector.java:71-82`) —
a raw `new Thread(...)`, not a pool task.

`TelemetryCollector.stop()` (`:85-91`) **has zero callers** anywhere in the repo.
`VpnEngine.stop()` (`:860-885`) does not call it.

Consequences:

* `threadPool.shutdownNow()` (`:883`) cannot touch it — it is not on the pool.
* The poller's `PollerSource` is an anonymous inner class of `VpnEngine`
  (`:179-222`), so it holds `VpnEngine` → `vpnService` → the **destroyed Service
  Context**. Every engine cycle leaks one thread and one Service.
* `start()` is idempotent via `if (running) return` (`:72`), so a second
  `VpnEngine.start()` does not double it — but that also means the *first*
  engine's poller is the one that survives, sampling a dead engine's counters.

**Fix:** `telemetry.stop();` in `VpnEngine.stop()`, and make the poller a daemon
thread at `dev/capture/TelemetryCollector.java:80` so it can never hold the
process up.

---

## 17. The always-on capture is never stopped by `stop()` **[CERTAIN]**

`core/VpnEngine.start()` opens a capture on **every** engine start
(`:367-375`), documented as deliberate. `capture.stop()` has exactly one call
site — inside `stopCapture()` (`:795`) — which is only reachable from
`ACTION_CAPTURE_STOP` / `ACTION_CAPTURE_DUMP`
(`PacketVpnService.java:240-243`). `VpnEngine.stop()` never calls it.

So each start/stop cycle leaves a `CaptureWriter` thread
(`dev/capture/CaptureWriter.java:266`) and an open, rotating, fsyncing file
behind, forever, plus unbounded external-storage growth at 32 MB per rotation.

Worse, the *user-initiated* stop is unreachable once the engine is down:
`stopCapture()` runs through `executeSafe` (`:792`), which returns immediately if
`stopped` (`:386`). Press Stop-engine then Dump-capture and the dump silently
never happens. And on `stop()` the pool is `shutdownNow()`n (`:883`), so an
in-flight dump task — a multi-second write of up to 160 k lines, per the comment
at `:787-791` — is interrupted mid-file.

**Fix:** in `VpnEngine.stop()`, before `threadPool.shutdownNow()`:

```java
capture.stop();                       // close the writer + flush the file
com.fakelag.cryhard8.dev.capture.LobbyCapture.shutdown();   // already there, :867
```

and use `threadPool.shutdown()` + `awaitTermination(3, SECONDS)` before falling
back to `shutdownNow()`, so a dump in flight gets a chance to finish.

---

## 18. A second unbounded thread pool is never shut down **[CERTAIN]**

`filter/DefaultFilterEngine.java:28`:

```java
private final ExecutorService executor = Executors.newCachedThreadPool();
```

`DefaultFilterEngine.shutdown()` (`:184-191`) is the only thing that calls
`executor.shutdownNow()`, and `FilterEngine.shutdown()` **has no callers**:
`VpnEngine.stop()` calls `filterEngine.disableAll()` at `:869`, not `shutdown()`.

`disableAll()` (`:158-164`) does everything `shutdown()` does except the
`executor.shutdownNow()`, so the abort gate *is* set and in-flight replays do
stop — the exposure is the leaked pool, not runaway packets. Cached-pool threads
die after 60 s idle, so this is a bounded leak, but the declared teardown API of
the filter subsystem is simply never invoked.

**Fix:** `filterEngine.shutdown();` instead of `filterEngine.disableAll();` at
`core/VpnEngine.java:869`.

---

## 19. Unbounded thread creation per flow and per connection **[CERTAIN]**

One `Executors.newCachedThreadPool()` (`PacketVpnService.java:89`) is shared by:

| Consumer | Threads | Site |
|---|---|---|
| UDP receive | **1 per unique (sport,dport,dstip)** | `core/UdpSessionManager.java:167` |
| TCP connect | 1 per connection | `core/TcpProxy.java:239` |
| TCP writer | 1 per connection | `core/TcpProxy.java:206` |
| TCP relay | 1 per connection | `core/TcpProxy.java:268` |
| Stats loop | 1 | `core/VpnEngine.java:674` |
| Capture dump / telemetry dump | 1 each, transient | `core/VpnEngine.java:792`, `:227` |

Nothing is created **per packet** — that was the specific question, and the answer
is no. But nothing is bounded either, and the UDP path is the one that matters:
a receive thread lives a minimum of `SO_TO` = 30 s even if the flow is dead
(`core/UdpSessionManager.java:33`, `:354-356`), each holds a 32 KB `rbuf`
(`:192`), and each Java thread reserves ~1 MB of stack. The map is only pruned
when a thread exits (`:361`).

With the app-scoped default route (`core/VpnEngine.java:605`) the exposure is
bounded by the game's own flow count, which is small. With the **unscoped** narrow
routes (finding 9, `:610-611`) it is bounded by every app on the device that talks
to `148.0.0.0/8`. There is no admission control in either case, and
`getOrCreate`'s failure path (finding 7) turns a thread-creation failure into
permanent silent deafness rather than a clean rejection.

**Fix:** cap the pool and give it a named factory, so exhaustion is visible and
bounded:

```java
// PacketVpnService.onCreate
threadPool = new ThreadPoolExecutor(
        4, 256,                                  // core, max
        60L, TimeUnit.SECONDS,
        new SynchronousQueue<Runnable>(),        // same handoff as cached pool
        new ThreadFactory() {
            private final AtomicInteger n = new AtomicInteger();
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "vpn-" + n.incrementAndGet());
                t.setDaemon(true);
                return t;
            }
        });
```

256 is far above any observed flow count and far below the point where the
process dies. With finding 7's fix, hitting the cap becomes a logged rejection
instead of a corrupted session map. Named threads also make a `bugreport` legible.

An `idleSweep` on `udpMap` would be better still — a single scheduled task that
closes sockets whose `SE.t` is older than `IDLE`, letting receive threads exit on
close rather than each holding a 30 s timeout — but that changes when sessions
are reaped, so it is a ⚠ SEMANTICS decision, not a drop-in.

---

## 20. `restartTunnel` resets five learners but not `SessionTimeline` or the ESP **[CERTAIN]**

`core/VpnEngine.java:426-435` resets, on restart:
`GamePacketTaxonomy.resetLearned()`, `pipeline.reset()`, `pipeline.markCurrent()`,
`lobbyKey.reset()`, `aimBias.reset()`, `PacketIntegrity.resetCounters()`,
`filterEngine.onTunnelRestart()`.

`stop()` additionally resets `SessionTimeline.reset()` at `:868`, with the
comment: *"Carrying either across a restart would splice two sessions' streams
together and keep a stale match/mode label."* — describing exactly the thing
`restartTunnel` does not do. `ACTION_SET_APP` calls `restartTunnel(true)`
(`PacketVpnService.java:190`), so the phase machine and the match/mode label
survive a target-app change into the new session.

`EspEngine` exposes no reset at all (there is an internal `resetMatch()` at
`esp/EspEngine.java:1661` driven by identity changes, but no external entry
point), so the ESP's roster, PRI state and entity table also cross a restart. The
internal match reset bounds the damage, and `ff-esp-health-names` records that
identity handling here is delicate — so this is a *note*, not a patch:
`resetMatch()`'s sentinel history (`esp/EspEngine.java:893-911`, "789 resets in
109 s") is exactly why nobody should wire a naive `esp.reset()` into
`restartTunnel` without reading that comment first.

**Fix (the safe half):** add `SessionTimeline.reset();` to `restartTunnel`
alongside the other resets at `:426-435`, matching what `stop()` already does.
Leave the ESP alone pending a decision informed by `esp/EspEngine.java:886-919`.

---

## 21. `routesAppScoped` reports the previous session's routes **[CERTAIN]**

`core/VpnEngine.java:603` is the only writer:

```java
private void addActiveRoutes(VpnService.Builder builder, boolean appScoped) {
    routesAppScoped = appScoped;
```

and `addActiveRoutes` is only called when `isActive` (`:514`). So a STANDBY
establish leaves `routesAppScoped` holding the value from the last ACTIVE session,
and `activeRouteModeName()` (`:625-630`) — used in the `MODE_VPN_TUN_READY` log
(`:523`), in three `PacketLoop` drop messages (`:50`, `:64`, `:81`) and in the HUD
— reports `all_ipv4_app_scoped` for a tunnel that has no routes at all.

The doc comment at `:617-623` says the previous version of this string was a
hard-coded list that *"no longer described the installed routes, which is
precisely the sort of silent mislabelling that hid the 43.252.x match server — a
diagnostic that lies is worse than none."* The rewrite fixed the ACTIVE case and
reintroduced the same class of lie in the STANDBY case.

**Fix:** set it on every establish, not only the active one:

```java
routesAppScoped = false;                       // reset before each establish
if (isActive) addActiveRoutes(builder, scopedApps > 0);
```

and add a `no_routes_standby` branch to `activeRouteModeName()`.

---

## 22. `rtt` measures idle time, not round-trip time **[CERTAIN]**

`core/UdpSessionManager.java:196-198`:

```java
long t0 = System.nanoTime();
fe.s.receive(pkt);
engine.rtt = (engine.rtt * 3 + (System.nanoTime() - t0) / 1000000L) / 4;
```

`t0` is taken immediately before a **blocking receive**, so the measured interval
is "how long this socket waited for the next inbound packet" — i.e. the
server's inter-packet gap, which `ff-timing-and-channel-id` records as ~198 ms
per tick. It has no relationship to a round trip. This value is broadcast as
`EXTRA_PING` (`core/VpnEngine.java:691`) and shown to the user as the ping.

It is also written from N receive threads concurrently onto a non-atomic
`volatile long` read-modify-write (`core/VpnEngine.java:51`), so samples are lost.

**Fix** — either delete the field and stop displaying a number that is not a ping,
or measure the real thing: record `System.nanoTime()` on the outbound send in
`UdpSessionManager.send()` (`:141`) keyed by the flow, and difference it on the
next receive for the same key. The second option costs one map write per packet
on the hot path — so if the HUD does not genuinely need a ping, delete it.

---

## 23. No MTU or 16-bit bound check when wrapping inbound datagrams **[CERTAIN code / DEVICE impact]**

`core/PacketBuilder.java:22-46`:

```java
int plen  = pkt.getLength();
int total = plen + 0x1c;
byte[] buf = new byte[total];
...
bb.putShort((short) total);                                            // :29
```

The receive buffer is 32768 bytes (`core/UdpSessionManager.java:192`) and the tun
MTU is 1280 (`core/VpnEngine.java:33`). Nothing checks `total` against either:

* `total > 1280` produces an IP packet larger than the interface MTU, written
  straight into the tun at `core/UdpSessionManager.java:351-353`. Whether the
  kernel accepts it, silently drops it, or fails the write with `EMSGSIZE` —
  which would hit `catch (Exception e) { break; }` at `:357` and take out the
  whole flow per finding 4 — is device-dependent.
* `total > 32767` corrupts the IP total-length field via the `(short)` cast at
  `:29`. Unreachable with a 32 KB buffer (max `total` = 32796 — so actually
  reachable, by 29 bytes, for a maximal datagram).

The DF bit is set unconditionally (`:31`, `0x4000`), so the kernel cannot fragment
it either.

**Fix** — a bound check plus a counter, so an oversized datagram is a recorded
event rather than a flow-killer:

```java
// UdpSessionManager, before buildPkt
if (rlen + 28 > MTU) {                     // MTU exposed from VpnEngine
    engine.pDrop.incrementAndGet();
    logger.logControl("INBOUND_OVER_MTU", "len=" + rlen);
    continue;
}
```

⚠ This *is* a semantics change — it drops a packet that today may or may not be
delivered. Do not apply it until the device test says which. Raising `MTU` is the
alternative and is a bigger semantics change: the game's own stack would then emit
larger datagrams.

**[DEVICE] Test:** log `rlen` distribution for a full match from
`core/UdpSessionManager.java:199` and check the maximum. `ff-esp-gate-starvation`
puts survival chains at ~630 B, well under the limit — if nothing exceeds 1252 in
practice, this is a bound check and nothing more.

---

## 24. The tun address comes from public IPv4 space **[CERTAIN]**

`core/TunAddressPool.java:52-55`:

```java
int b = TUN_IP_B_BASE + (next / TUN_IP_C_COUNT);      // 12..61
int c = next % TUN_IP_C_COUNT;                        // 0..253
String ip = "26." + b + "." + c + ".2";
```

`26.0.0.0/8` is **allocated, routable public space** (DoD NIC), not private. The
`/24` passed to `addAddress` (`core/VpnEngine.java:469`) installs an on-link route
for `26.b.c.0/24`, so 256 real public addresses become unreachable for every app
inside the tunnel, and any inbound packet the relay synthesises carries a source
that is not ours.

`RFC 1918` (`10/8`, `172.16/12`, `192.168/16`) or `RFC 2544` benchmark space
(`198.18.0.0/15`, which is specifically reserved and unlikely to collide with a
home LAN — the apparent reason `26.` was chosen) are the correct pools. Note the
engine's own default `tunIP` at `core/VpnEngine.java:44` is `0xC0A8010A` =
`192.168.1.10`, which contradicts the pool it is nominally a default for.

Second, smaller issue: `prefs.edit().…commit()` at `TunAddressPool.java:50` is a
synchronous disk write executed on the VPN thread immediately before
`establish()`, inside a static lock. `apply()` is sufficient — the cursor is a
hint, and losing one on a crash costs nothing.

---

## 25. A dead line in the TCP window check **[CERTAIN]**

`core/TcpProxy.java:343-345`:

```java
int inFlight = seqDelta(c.ourNext, c.clientAck);
if (inFlight < 0) inFlight += 0x100000000L;
if (inFlight + data.length > c.clientWindow) return;
```

`inFlight` is an `int`. `inFlight += 0x100000000L` is a compound assignment with
an implicit narrowing cast — `inFlight = (int)(inFlight + 0x100000000L)` — and
adding 2³² leaves the low 32 bits unchanged. The line is a **no-op**; the compiler
accepts it and it does nothing.

`inFlight` can therefore stay negative, and a negative `inFlight` makes the window
check pass when it should not. It requires ≥2 GB unacknowledged to trigger, so
this is latent, not live. Correct form:

```java
long inFlight = seqDelta(c.ourNext, c.clientAck) & 0xffffffffL;
if (inFlight + data.length > c.clientWindow) return;
```

While in this file: `c.ourNext` and `c.clientNext` are plain (non-volatile)
`long`s (`core/TcpProxy.java:72-76`) written under `c.lock` in `flushToClient`
(`:347-349`) but read and written **without** it from the tun loop (`:160`,
`:162`, `:165`, `:166`) and from `sendHeader`/`sendRst` (`:363`, `:373`). On arm64
a 64-bit load is atomic in practice, but the JMM guarantees neither atomicity nor
visibility, so a stale sequence number in an ACK is legal behaviour under the
model. Either take `c.lock` for those reads or make them `AtomicLong`.

---

## 26. Two settings paths that do not do what their names say **[CERTAIN]**

`core/VpnEngine.java:332-334`:

```java
public void loadLobbyRouteSetting(boolean rebuildIfChanged) {
    setLobbyRouteEnabled(true, rebuildIfChanged);
}
```

It never reads `Prefs`. `lobbyRouteEnabled` is already `true` at `:47`, so the
call from `PacketVpnService.java:104` is a no-op and the user's stored preference
(`VpnActions.EXTRA_LOBBY_ROUTE`) is only ever applied by the live dev broadcast at
`PacketVpnService.java:136`, never at startup.

`core/VpnEngine.java:349-351`:

```java
public void setLobbyRouteFallbackFull(boolean full) { lobbyRouteFallbackFull = full; }
```

**Zero callers.** Grep confirms the only writes to `lobbyRouteFallbackFull` are
`= false` at `:340` and `:722`. This is the latch documented in
`ff-route-fallback-kick` — **confirmed genuinely dead**, and
`activeRouteModeName()`'s `full_ipv4_fallback` branch (`:628`) is unreachable.

**Fix:** delete the setter, the field, and the `:628` branch; and either make
`loadLobbyRouteSetting` read the pref or delete it and the `:104` call.

The requested sweep for *other* latched state across restart found, beyond these:
the counters (finding 15), `routesAppScoped` (finding 21), and
`DefaultFilterEngine.abortGate` — set by `onTunnelRestart()`
(`filter/DefaultFilterEngine.java:173`) and cleared only by the next `toggle()`
per the comment at `:171-172`, so a restart with no subsequent toggle leaves it
armed. That one is inside the filter engine, outside this audit's scope, but it
is the same shape as `lobbyRouteFallbackFull` and deserves the same look.

---

## 27. Main-thread disk I/O in `onStartCommand` **[CERTAIN]**

`onStartCommand` runs on the main thread. On it:

* `PacketVpnService.java:176` — `Prefs.getTargetPackages(this)`, the first
  `SharedPreferences` load (disk).
* `PacketVpnService.java:231`, `:233` — two more `Prefs` reads.
* `core/VpnEngine.java:250` → `start()` → `:372-375` → `startCapture(...)` →
  `capture.start()` **and** `context.getExternalFilesDir("dev_logs")` +
  `LobbyCapture.start(lobbyDir)` at `:773-777` — file creation on external
  storage, synchronously, on the main thread, on every engine start.

`stopCapture()` was already moved off the main thread for exactly this reason
(`core/VpnEngine.java:786-791`: *"Running it on the caller (service main) thread
blocked every queued intent behind it — filter toggles silently 'didn't take'"*).
The start path has the same problem and was not moved.

**Fix:** wrap the `startCapture` body in `executeSafe(...)` the way `stopCapture`
is, and hoist `Prefs.get(this)` into `onCreate`.

---

## 28. No IP fragment check in the tun loop **[CERTAIN, latent]**

`core/PacketLoop.java:85-88`:

```java
int plen = PacketBuilder.rs(buf, ihl + 4) - 8;
int off = ihl + 8;
if (plen < 0 || off + plen > len) continue;
```

Nothing reads the flags/fragment-offset field at bytes 6-7. A **non-first**
fragment of a UDP datagram has no UDP header, but this code reads bytes at `ihl`
as source port, `ihl+2` as destination port and `ihl+4` as length — producing a
garbage 3-tuple which, if it survives the `plen` sanity check, creates a bogus NAT
session (a socket, a thread, a map entry) and emits the fragment's payload as a
standalone datagram to a garbage port.

With MTU 1280 and the game's small datagrams this is unlikely to fire, which is
why it is S3. The check is two lines and costs nothing:

```java
int fragField = PacketBuilder.rs(buf, 6);
if ((fragField & 0x1fff) != 0) continue;         // not the first fragment
if ((fragField & 0x2000) != 0) { /* MF set: first of several — see note */ }
```

⚠ Dropping fragments is a semantics change if any real traffic is fragmented.
Count them first (`logControl("DROP_IP_FRAGMENT", ...)` plus a telemetry event),
confirm the count is zero over a few matches, then drop.

---

# Verified correct — do not re-audit

Recorded so the next reader does not spend a cycle on them.

* **`PacketLoop` exit and spin behaviour** (`core/PacketLoop.java:41-44`). The
  `len < 0 → break` EOF path is right and cannot hot-spin; a tun `read()` never
  returns 0; `buf` at 65535 (`:39`) is far above the 1280 MTU so no packet is
  ever truncated on read.
* **`statsRunning` guard** (`core/VpnEngine.java:670-673`, `:702-704`). The
  `AtomicBoolean` compare-and-set plus the `finally` reset make `startStats()`
  genuinely idempotent, including across the restart handoff.
* **`drainPendingToggles` re-entrancy guard** (`PacketVpnService.java:304-332`).
  The `draining` CAS correctly prevents the inner broadcast-triggered drain from
  consuming the outer queue; the TTL at `:272` addresses a real double-press bug.
* **`restartTunnel` ordering of `tcpProxy.closeAll()` before `tun.close()`**
  (`core/VpnEngine.java:403-412`) is correct and the comment explains why.
* **`run()`'s `finally` stop-guard** (`core/VpnEngine.java:561`,
  `if (isRun && vpnT == Thread.currentThread() && !stopped)`) correctly prevents
  a retiring thread from stopping the engine its successor owns. Finding 3 is that
  the same ownership test is missing two lines above, at `:540-544`.
* **`lobbyRouteFallbackFull` latch** — confirmed dead (finding 26). The bug
  described in `ff-route-fallback-kick` cannot recur through this path.
* **`scheduleLobbyRouteFallbackIfNoUdp`** (`core/VpnEngine.java:666-668`) is a
  genuine no-op. No mid-match `restartTunnel` exists on any heuristic path. The
  only `restartTunnel` callers are `toggle()` (`:381`), `setLobbyRouteEnabled`
  (`:344`, dev broadcast only) and `ACTION_SET_APP`
  (`PacketVpnService.java:190`) — all user-initiated.
* **Self-tunnelling** — the app cannot tunnel itself while `scopedApps > 0`,
  because `addAllowedApplication` is a whitelist that omits it, and every socket
  the engine opens is `protect()`ed (`core/UdpSessionManager.java:109`, `:155`,
  `core/TcpProxy.java:243`). Finding 9b is the unscoped-branch gap only.
* **IP and TCP checksums** (`core/PacketBuilder.java:104-122`,
  `core/TcpProxy.java:471-512`) are correct, including the pseudo-header and the
  odd-length tail. `PacketBuilder.buildPkt` zeroing the UDP checksum (`:43`) is
  legal for IPv4.
* **`MSS = 1240`** (`core/TcpProxy.java:42`) is exactly `MTU(1280) - IP(20) -
  TCP(20)`. Correct.
* **`seqDelta`** (`core/TcpProxy.java:179-181`) is a correct wrap-safe signed
  comparison as used at `:145` and `:153`. Only the `:344` line built on top of it
  is wrong (finding 25).
* **`executeSafe`** (`core/VpnEngine.java:385-392`) correctly handles the
  `stopped`/`RejectedExecutionException` race. The bug is that `TcpProxy` does not
  use it (finding 10).

---

# Device-test matrix

| # | What to confirm | Test |
|---|---|---|
| 1 | `startForeground` throws on a background start | Revoke "Display over other apps" while the engine runs, then deliver a toggle intent. Expect a crash today. |
| 2 | STANDBY strands the game | Join a match, press Deactivate, watch for a network error. `adb shell dumpsys connectivity` for the tun's route list. |
| 3b | Whether a blocked tun `read()` returns on `close()` | Log at `PacketLoop.java:43` and `VpnEngine.java:533`; run `ACTION_SET_APP` 20× and count `TUN_JOIN_TIMEOUT`. |
| 4 | Mid-match re-NAT frequency | Log `getLocalPort()` at every `getOrCreate`; any repeat 3-tuple in one match is a re-NAT. |
| 8 | Handover behaviour | Wi-Fi → cellular during a live match; time to recovery or error. |
| 11 | IPv6 black-hole | Check for a `::/0` route; compare outbound counts on an IPv6 carrier vs Wi-Fi. |
| 13 | `dataSync` 6 h timeout | Only after `targetSdk` → 35. A 6 h+ session must not be killed. |
| 23 | Max inbound datagram size | Log the `rlen` distribution for a full match; confirm the max is < 1252. |
| 28 | Fragment frequency | Count `DROP_IP_FRAGMENT` candidates over several matches before dropping any. |

---

# Rejected fixes

Recorded so they are not proposed again.

* **Any mid-match `restartTunnel`.** `ff-route-fallback-kick`: tearing the
  interface down mid-match returns players to the lobby with a "network error".
  Findings 3, 6 and 8 all touch restart/teardown; every fix above is either a
  flag-ownership change or a diagnostic, and none of them adds a teardown
  trigger. Finding 8 explicitly declines the session-reset-on-handover fix for
  this reason.
* **Widening the idle timeouts or pinning the UDP source port** (finding 4).
  Both change what the server sees on the wire.
* **Raising the MTU above 1280** (finding 23). The game's own stack would then
  emit larger datagrams; that is a wire change, not a robustness fix.
* **Routing IPv6 into the tunnel** (finding 11b). That is a feature with a real
  packet-path cost, not a fix. Dropping the unused IPv6 address is the fix.
* **Rate-limiting or coalescing anything on the packet path.** Every hot-path
  change proposed above is a counter increment or a log on a path that already
  failed; nothing is added to the success path.
