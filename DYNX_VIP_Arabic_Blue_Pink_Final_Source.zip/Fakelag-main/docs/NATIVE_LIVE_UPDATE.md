# Native packet core — Rust port + live update (Phase 2)

The packet hot path ("Bucket-A": QQ-TEA, CRC-7, header permutation/mask, LEB128,
and — staged — the rewrite filters) is being moved from Java into a Rust
`libnuvola_native.so`, so recovering "how it works" goes from reading decompiled
Java to reversing obfuscated ARM64. The `.so` is delivered and updated *live* from
the VPS without shipping a new APK.

## Layout

```
native/                     Cargo workspace (Windows-native build, no WSL)
  nuvola-core/              pure logic: tea / crc7 / header / varint (+ selftest)
  nuvola-native/            JNI cdylib -> libnuvola_native.so (JNI_OnLoad + RegisterNatives only)
.github/workflows/build-native.yml   amice-obfuscated Linux/CI release build
server/app/native.py        manifest sign/verify + store paths
server/sign_native.py       VPS-only: sign + publish a lib into the store
app/.../net/NativeBridge.java   native method decls (bound by RegisterNatives)
app/.../net/NativeLoader.java   launch-time verify+load+fallback+update
```

`nuvola-core` is host-testable: `cd native && cargo test` (TEA/CRC-7 are pinned
byte-for-byte against the Python oracle in `tools/ffproto`, which was validated
against the Java on live captures).

## Build

**Dev (Windows, bundled fallback lib):**
```
cd native
cargo ndk -t arm64-v8a --platform 21 -o ../fakelag/fakelag-beta/app/src/main/jniLibs build --release
```
(cargo-ndk 4.1.2: use `--platform`, not `-p` — `-p` means cargo `--package`. Set
`ANDROID_NDK_HOME` to the r29 path.) The `.so` lands in `jniLibs/arm64-v8a/` and
AGP bundles it. Verify only `JNI_OnLoad` is exported:
`llvm-nm -D --defined-only libnuvola_native.so`.

**Release (CI):** `.github/workflows/build-native.yml` (tag `native-v*`, or manual)
reliably builds the **source-hardened** arm64 `.so` on ubuntu with stable rustc +
cargo-ndk: stripped, only `JNI_OnLoad` exported (RegisterNatives), `obfstr`
string encryption, `lto`/`panic=abort`. The job verifies the symbol table and
uploads the artifact. (Build-provenance attestation is non-fatal — unavailable on
private repos.)

**amice LLVM control-flow obfuscation — experimental, currently blocked.** Gated
behind `workflow_dispatch amice=true`. What is PROVEN in CI: LLVM 22 install via
apt.llvm.org, the amice plugin builds from source (`--no-default-features
--features llvm22-1`) against a pinned nightly whose LLVM matches
(**nightly-2026-05-15 = LLVM 22.1.4**, current nightly is LLVM 23 — too new), and
the plugin LOADS into rustc and runs passes. What blocks it: amice **v0.1.5-beta**
passes crash — its string-encryption chokes on Rust's `{ptr,[N x i8]}` string
constants (obfstr covers strings anyway), and even flatten-only SIGSEGVs rustc on
some upstream dependency IR (`jni`, `obfstr`). amice exposes **no crate/module
filter** (only C `__attribute__((annotate))`, unusable from Rust) and RUSTFLAGS
can't be scoped per-crate in one cargo build, so the passes can't be limited to
our dep-free `nuvola-core`. Re-enable once amice's passes stabilise on Rust dep
IR, upstream a module filter, or restructure to obfuscate `nuvola-core` in
isolation. Until then the source-hardened `.so` is the shippable release.

## Live-update trust model

The server signs a manifest with the **existing Ed25519 key** (public half pinned
in `AuthConfig.SERVER_ED25519_PUB_HEX` — the same key the offline lease uses, so
no new trust root). Signing happens **on the VPS, never in CI**: a leaked CI token
therefore cannot mint a lib the client will load. The signed bytes are a
fixed-order, domain-separated string (`nuvola-native-manifest-v1\n…`), never JSON,
so there is no canonicalisation ambiguity and a lease signature can't be replayed
as a lib manifest.

Signed fields (client rebuilds these exactly and verifies):
```
nuvola-native-manifest-v1\n abi=\n version=\n semver=\n sha256=\n size=\n
min_loader=\n not_before=\n not_after=\n
```
Manifest also carries `rollout_permille`, `kill`, `url`, `sig_alg`, `sig`.

## Endpoints (live on the VPS)

- `GET /version` → adds `"native": {"abi","version"}` (or null).
- `GET /native/manifest?abi=arm64-v8a` → the signed manifest JSON.
- `GET /native/lib/{version}?abi=arm64-v8a` → the raw `.so` bytes.

Store: `<NATIVE_DIR>/<abi>/{manifest.json, high_water, <version>/lib.so}`
(`NATIVE_DIR` = `/opt/nuvola/server/native_store`). Publish/rotate with:
```
cd /opt/nuvola/server
.venv/bin/python sign_native.py /path/libnuvola_native.so --version <N> --semver <x.y.z> \
    [--valid-days 90] [--rollout-permille 1000] [--kill] [--base-url https://66.154.107.27]
```
`--version` is the monotonic client version (drives the downgrade guard); it must
strictly increase (the tool refuses `<= high_water`). **v1 is published** (the
current base lib).

## Client load path (NativeLoader, launch-time, off the hot path)

1. Crash-loop check: a version left `attempting` bricked load last launch →
   quarantine it, never retry.
2. Try `candidate` then `active`: for each, re-verify SHA-256 == manifest AND the
   Ed25519 sig under the pinned key AND version ≥ high-water AND `min_loader` OK;
   `setReadOnly()` (required: API 34 warns, API 37 hard-fails on a writable lib);
   write a boot breadcrumb; `System.load(absPath)`; require `nnSelftest() ==
   EXPECTED_SELFTEST`; clear breadcrumb. First clean load of a candidate promotes
   it and raises the high-water mark.
3. Fallback: the APK-bundled copy via `System.loadLibrary` (always allowed).

Background: `GET /version` → if `native.version > have` → fetch + verify manifest
→ honour `kill` → staged-rollout bucket (`crc32(install_id) % 1000 <
rollout_permille`) → download → SHA check → `setReadOnly` → atomic rename → cache
manifest → mark `candidate` (promoted next clean launch). Stored in
`getNoBackupFilesDir()/native/arm64-v8a/`. Offline / server-down never blocks
launch — the installed or bundled lib keeps running.

## Threat model (summary)

MITM/rogue host → SPKI pin **and** Ed25519 sig over sha256 (fail closed).
Downgrade replay → monotonic version + high-water + `not_after`. Compromised CI →
signing key not in CI + VPS re-verifies provenance + human gate. Bad push that
SIGSEGVs on load → breadcrumb + two-phase promote + self-test + bundled fallback
= auto-rollback. Mass bad push → `rollout_permille` + `kill` + `not_after`.

## Status / next

**Pure per-packet logic — ALL ported & verified** (host `cargo test`, 38 tests):
- Decoder primitives: TEA, CRC-7, header permute/mask, LEB128 — TEA+CRC-7 pinned
  byte-for-byte to the Python==Java oracle.
- `PositionSync` (Cmd-2001 codec, teleport's keystone) — verified against 60 real
  captured packets (parse + canonical re-encode identity).
- `cmd` predicates (all filters' classification).
- `mark` (Cmd-148 pin rewrite) — full decrypt→rewrite→encrypt→DATA_LEN→reseal,
  round-tripped through the verified TEA.
- `aim` (Cmd-106 hit rewrite) — walk verified against 28 real decrypted hits
  (offsets + two-copy invariant); full rewrite (zone flip + hit-point move +
  canonical rebuild + checkParams Fisher-Yates) with the permutation KAT'd against
  both proven docs/CHECKPARAMS_ZONE_FIELD examples.

The split held: the pure transforms live in `nuvola-core`; the stateful
orchestration (Ghost replay timer, Freeze toggle, Teleport ramp/state machine,
`PacketSender`, `EspEngine` head-point resolution, config gating) stays in Java
and passes the resolved decisions in.

**Remaining (integration — needs the device):**
1. JNI entry points in `nuvola-native` exposing the transforms (position/mark/aim
   rewrite + a drop-decision helper), marshalling the layout (mask + order[5])
   and session key across the boundary.
2. Rewire the Java filters to call the Rust transforms (and thin/remove the Java
   copies), so the logic actually leaves Java at runtime.
3. On-device verification (device R3GL10AHL7P) — install, confirm each feature
   still works against the live game, then verify with captures. This is the step
   that must not be done blind, so it waits for the device.
