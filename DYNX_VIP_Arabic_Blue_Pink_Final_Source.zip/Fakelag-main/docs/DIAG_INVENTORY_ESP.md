# Silent-failure inventory — `esp/` and `decode/`

Research note, 2026-09-15. Written against the working tree (`0873617` + uncommitted
work). **No source file was modified by this pass.**

Scope: `esp/` (6 files, 3 438 lines) and `decode/` — `frame/` (9 files), `crypt/`
(2), `body/` (10). The other packages are covered by sibling inventories.

---

## 0. Status before you read the tables

**A diagnostic registry already exists and is partly wired.** It is untracked
(`git status` shows `?? .../cryhard8/diag/`), so it landed in this same effort:

| file | what it is |
|---|---|
| `diag/Diag.java` | `AtomicIntegerArray` of 240 slots; `hit(slot)`, `hit(slot,n)`, `event(slot,text)` ring of 64, `snapshot()` with per-window deltas |
| `diag/Slot.java` | dense int ids + names, blocked by module (tunnel 0-31, proto 32-63, **esp 64-111**, **decode 112-143**, filter 144-175, render 176-207, aim 208-239) |
| `diag/Invariants.java` | 9 alarm rules evaluated on each `snapshot()` |

**In scope, 14 call sites are already wired — all of them in `EspEngine.java`:**

| line | slot |
|---|---|
| `esp/EspEngine.java:144` | `ESP_OWN_FROM_ECHO` |
| `esp/EspEngine.java:703` | `ESP_KEEPALIVE_BAD` |
| `esp/EspEngine.java:766` | `ESP_OWN_FROM_2001` |
| `esp/EspEngine.java:1362` | `ESP_CLS_R1_SELF` |
| `esp/EspEngine.java:1395` | `ESP_CLS_R2_TEAM` / `ESP_CLS_R2_ENEMY` |
| `esp/EspEngine.java:1398` | `ESP_CLS_R2_NO_OWN_TEAM` |
| `esp/EspEngine.java:1412` | `ESP_CLS_NO_OWN_ID` |
| `esp/EspEngine.java:1422` | `ESP_CLS_R3_CLOSURE_ENEMY` |
| `esp/EspEngine.java:1433` | `ESP_CLS_R4_LATE_ENEMY` |
| `esp/EspEngine.java:1474` | `ESP_CLS_R6_DEFAULT_ENEMY` |
| `esp/EspEngine.java:1692-1695` | `ESP_TEAM_SRC_BIND` / `_ROSTER` / `_DAMAGE` / `_HANDLE` |
| `esp/EspEngine.java:1727` | `ESP_MATCH_RESET` |
| `esp/EspEngine.java:2189` | `ESP_VEHICLE_PARSE_REFUSED` |
| `esp/EspEngine.java:2228` | `ESP_OWN_FROM_2069` / `ESP_OWN_FROM_2002` |

**Seventeen slots are allocated and named but never hit by any code:**
`ESP_CHAIN_PKT`, `ESP_CHAIN_PARSE_STRUCTURED`, `ESP_CHAIN_PARSE_FALLBACK`,
`ESP_CHAIN_PARSE_REFUSED`, `ESP_KEEPALIVE_OK`, `ESP_TELEPORT_GUARD`,
`ESP_VEL_REJECTED`, `ESP_HP_BOUND`, `ESP_HP_UNBOUND`, `ESP_NAME_BOUND`,
`ESP_OWN_NONE`, `ESP_VEHICLE_OP_VARINT`, `DEC_VARINT_TRUNCATED`,
`DEC_BODY_SHORT`, `DEC_BODY_TRAILING_BYTES`, `DEC_TEA_BAD_LENGTH`,
`DEC_TEA_BAD_PADDING`.

A named-but-never-hit slot is invisible in a dump — `Diag.snapshot()` skips every
slot whose total is 0 (`diag/Diag.java:149`). So *"the slot exists"* and *"the
dump would have shown it"* are different claims, and today only the second matters.

**Zero instrumentation exists in:** `esp/PriTracker.java`, `esp/MatchRoster.java`,
`esp/OrientationProvider.java`, `esp/EspBodyDecoders.java`, `esp/MarkTarget.java`,
and **the entire `decode/` tree** — `frame/`, `crypt/` and `body/` alike.

Everything below is therefore a *delta*: `already covered` where a hit exists on
that exact line, `slot exists, unwired` where the registry has a home for it, and
`propose` where a new slot is needed.

---

## 1. THE CLASSIFIER LADDER — the highest-value part

`EspEngine.classify(int id, Track t)`, `esp/EspEngine.java:1340-1475`. Runs **per
entity per chain packet**, so every marking here is `counter`, never `event`.

### 1.1 Per-rung accounting: what exists, what is missing

| rung | line | outcome | slot | status |
|---|---|---|---|---|
| 1 SELF | `:1360-1364` | SELF | `ESP_CLS_R1_SELF` | already covered |
| team pull, Cmd 118 hit | `:1374-1375` | — | `ESP_TEAM_SRC_BIND` (fires inside `noteTeam`) | already covered |
| team pull, roster hit | `:1377-1378` | — | `ESP_TEAM_SRC_ROSTER` | already covered |
| **team pull, both miss** | **`:1372-1380`** | **falls through silently** | — | **propose `ESP_CLS_NO_TEAM_SOURCE`** |
| 2 server byte | `:1390-1396` | TEAM / ENEMY | `ESP_CLS_R2_TEAM` / `_R2_ENEMY` | already covered |
| **2 gate: own team unusable** | `:1398` | undecided → falls to 3/4/6 | `ESP_CLS_R2_NO_OWN_TEAM` | already covered |
| **2 gate: own team fine, entity team unknown** | `:1390` | falls to 3/4/6 | — | **propose `ESP_CLS_R2_NO_ENTITY_TEAM`** |
| no own id | `:1411-1414` | **`t.role` LEFT UNWRITTEN** | `ESP_CLS_NO_OWN_ID` | already covered |
| 3 squad closure | `:1420-1424` | ENEMY | `ESP_CLS_R3_CLOSURE_ENEMY` | already covered |
| 4 late arrival | `:1430-1435` | ENEMY | `ESP_CLS_R4_LATE_ENEMY` | already covered |
| 6 default | `:1473-1474` | ENEMY | `ESP_CLS_R6_DEFAULT_ENEMY` | already covered |

Two gaps, and both matter for exactly the bug class this exercise is for.

**`ESP_CLS_R2_NO_OWN_TEAM` at `:1398` conflates two states.** It is hit whenever
`ownTeamUsable` is false, *regardless of whether the entity had a team byte at
all*. So the reading "we have the server's answer for this entity and cannot use
it because we do not know our own team" — the friend-painted-red path, the single
most expensive outcome under the current product rule — is indistinguishable from
"we know nothing about anybody". `ESP_CLS_R2_NO_ENTITY_TEAM` at `:1390` splits
them: the pair `(NO_OWN_TEAM high, NO_ENTITY_TEAM low)` says our own keepalive is
the problem; `(NO_OWN_TEAM low, NO_ENTITY_TEAM high)` says Cmd 118/101 are not
arriving. Different fixes entirely.

**`ESP_CLS_NO_TEAM_SOURCE` at `:1372-1380`** counts the pull that found nothing in
either `pri.squadFor(id)` or `roster.squad(id)`. Without it, a dead Cmd 118 path
and a Cmd 118 path that simply has not reached this id yet look identical, because
`ESP_TEAM_SRC_BIND` only counts successes.

### 1.2 The invariant the rung counters buy

`classify()` always terminates in exactly one of eight ways. With the two proposed
additions the ladder is **closed**:

```
R1_SELF + R2_TEAM + R2_ENEMY + R3_CLOSURE_ENEMY + R4_LATE_ENEMY + R6_DEFAULT_ENEMY
  + NO_OWN_ID                                   == total classify() calls
```

`R2_NO_OWN_TEAM`, `R2_NO_ENTITY_TEAM` and `NO_TEAM_SOURCE` are pass-through marks,
not terminals, so they are *not* in the sum. That identity is worth asserting: if
it ever fails to hold, a rung was added without a counter — which is precisely how
rung 5 escaped for months (it was deleted, but the old rung 6 was *a comment, not
code*, so the method fell off the end and kept a stale role: `:1437-1466`).

### 1.3 Healthy distributions — BR vs Clash Squad

Derived from `docs/FRIEND_FOE_AUTHORITATIVE.md` §1.5, §3.3, §3.4 and
`docs/CS_MODE_ESP_FAILURE.md` §7.4. Percentages are of total `classify()` calls.

**Battle Royale squad** (measured: 31 360 samples, 26 players, 14 squads, own
squad 4 members):

| slot | healthy | source |
|---|---|---|
| `ESP_CLS_R1_SELF` | **14-16 %** | self 4 939 of 31 360 samples = 15.7 % |
| `ESP_CLS_R2_TEAM` | **1-4 %** | 3 real squadmates, ~12 000 samples, but only those whose Cmd 118 bind landed; entity 51's bind fell in the pre-key window |
| `ESP_CLS_R2_ENEMY` | **25-40 %** | ~35 % of samples carried a 118 byte in the measured match |
| `ESP_CLS_R3_CLOSURE_ENEMY` | **0 %** until all 4 squadmates are named, then rises | §3.4: "rung 3 arms once all 4 squadmates are named"; **always 0 in BR solo** (`ownSquadKnown()` tops out at 1) |
| `ESP_CLS_R4_LATE_ENEMY` | **10-30 %** | enemies are p50 42.1 s / p75 258 s first-sighting against the 20 s threshold |
| `ESP_CLS_R6_DEFAULT_ENEMY` | **20-45 %** | the undecided remainder, measured **96.9 % enemies** |
| `ESP_CLS_NO_OWN_ID` | **< 6 %** | §7.4 fixed-case "mean samples gated 5.26 %" — genuine keepalive silences (vehicles, death) |
| `ESP_CLS_R2_NO_OWN_TEAM` | **< 6 %** | same population |

**Clash Squad 4v4** (8 players, no interest management, dense damage feed):

| slot | healthy | source |
|---|---|---|
| `ESP_CLS_R1_SELF` | **12-13 %** | 1 of 8 replicated entities every tick |
| `ESP_CLS_R2_TEAM` | **35-40 %** | 3 of 8; §3.4 "very high — 8 players, all bound at match start" |
| `ESP_CLS_R2_ENEMY` | **45-50 %** | 4 of 8 |
| `ESP_CLS_R3_CLOSURE_ENEMY` | **small but non-zero** | §3.4 "rung 3 (closure) arms reliably" — it only fires for entities rung 2 did not already decide, so a *large* value means the team bytes are missing |
| `ESP_CLS_R4_LATE_ENEMY` | **~0 %** | a CS roster is fixed and streams from t=0 |
| `ESP_CLS_R6_DEFAULT_ENEMY` | **< 10 %** | anything higher means the authoritative path is dead |
| `ESP_CLS_NO_OWN_ID` | **< 2 %** | §7.4 fixed-case "mean samples gated 1.47 %" |
| `ESP_CLS_R2_NO_OWN_TEAM` | **< 2 %** | same |

**The two fingerprints to recognise:**

* *CS blackout (the `0873617` regression)* — `ESP_CLS_NO_OWN_ID` +
  `ESP_CLS_R2_NO_OWN_TEAM` at **22 %** of calls, `ESP_MATCH_RESET` climbing at
  ~10/s. Measured: 1 465 of 1 858 samples (78.8 %) gated, 789 resets in 109 s.
* *BR proximity inversion (the deleted rung 5)* — would have shown as
  `ESP_CLS_R2_TEAM` at **29.5 %** in a squad match where the true figure is a few
  percent. No packet anywhere shows this; only the rung counter does.

---

## 2. THE OWN-STATE SOURCE LADDER

Five sources, four already counted, one never reachable.

| source | line | slot | status |
|---|---|---|---|
| Cmd 2001 keepalive | `esp/EspEngine.java:766` | `ESP_OWN_FROM_2001` | already covered |
| Cmd 2069 (mount w/ aim) | `esp/EspEngine.java:2228` | `ESP_OWN_FROM_2069` | already covered |
| Cmd 2002 (vehicle, no aim) | `esp/EspEngine.java:2228` | `ESP_OWN_FROM_2002` | already covered |
| self-echo | `esp/EspEngine.java:144` | `ESP_OWN_FROM_ECHO` | already covered |
| **none** | — | `ESP_OWN_NONE` | **allocated, unreachable — see below** |

**`ESP_OWN_NONE` has no home, because nothing polls.** All four live slots are
hit by an *arrival*. "No source at all" is the absence of arrivals and can only be
detected by something that runs on a clock. The natural owner is the renderer's
own staleness bail, which already exists and is already counted as
`RENDER_NO_OWN_STATE` (`ui/render/EspRenderView.java:1022`, gate at `:1016` reading
`esp.ownStateMs()` against a 2 000 ms bound) — that is in the render package, not
mine, but the two slots are redundant. **Recommendation: delete `ESP_OWN_NONE`, or
give it to a periodic sweep.** Leaving an unreachable slot in the registry teaches
the reader that a zero means "healthy" when it means "not implemented".

Two real gaps in the ladder itself:

| finding | line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|---|
| self-echo refused for want of a pose | `esp/EspEngine.java:126` | `if (t == null \|\| !t.poseValid) return;` | silent | mounted ESP keeps a frozen camera; boxes drift then the overlay dies at the renderer's 2 s bail | degraded | `ESP_OWN_ECHO_NO_POSE` | ~5/s while mounted before the first pose | counter |
| 2069 aim vector degenerate | `esp/EspEngine.java:2207` | `if (m > 1e-4f)` — no else | silent | position updates, camera silently keeps the *previous* basis; boxes sit at a fixed angular offset | degraded | `ESP_OWN_2069_AIM_DEGENERATE` | ~0/s (should never fire) | both |

`refreshOwnFromEcho` is called only from `esp/EspEngine.java:1224`, gated on
`t.role == ROLE_SELF && mounted()`. Since `mounted()` (`:108-111`) is defined as
`ownLastUpdateMs` going quiet for 400 ms, and `ownLastUpdateMs` is set *only* at
`:763`, a session where `observeKeepalive` never succeeds has `ownLastUpdateMs == 0`
and therefore **`mounted()` returns false forever and the self-echo fallback never
arms**. That is correct as written (you cannot detect a mount you never dismounted
from) but it is worth knowing that `ESP_OWN_FROM_ECHO == 0` has two readings.

---

## 3. `esp/` — silent failure points

Rates: the entity chain ticks every **198 ms** (5.05 Hz per entity, IQR 2 ms,
`esp/EspEngine.java:271`); the outbound keepalive every **99 ms**; the renderer at
120 Hz. Where an absolute rate is not derivable I give it relative to an existing
counter, which is more honest than a guess.

### 3.1 `esp/EspEngine.java` — mask recovery

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `:638` | `if (maskLocked) return;` | silent | none — by design | benign | **none. Correct, leave silent.** | ~10/s | — |
| `:639` | `if (off < 0 \|\| off + 24 > data.length) return;` | silent | mask never learns | benign | `ESP_MASK_BOUNDS` | ~0/s | counter |
| `:661-669` | `if (total == 0 \|\| bestCount*100 < total*90) strong = false;` then `if (strong)` | **silent** | `maskValid` stays false forever. **`EspRenderView:1011` bails on `!esp.maskReady()`** → the whole overlay is blank, and the HUD says `"ESP LEARN (n)"` (`:2274`) which reads as "still warming up" rather than "gave up" | **fatal** | `ESP_MASK_WEAK` (evaluated, rejected) / `ESP_MASK_VALID` (accepted) | once per 96 input packets ≈ 0.1/s | both |
| `:679` | `if (!maskValid \|\| plen < 11 \|\| plen > 13) return;` | silent | no mask validation | benign | fold into `ESP_MASK_WEAK` | high | — |
| `:683-690` | loop finds no match, falls out | silent | mask never locks; stays in the re-evaluating state | benign | `ESP_MASK_VALIDATE_MISS` | ~1/s | counter |

The `evaluateMask` bail is the highest-severity item in the whole file and had no
counter, because the failure presents as a *waiting* message rather than an error.
`maskValid` is a hard precondition for drawing anything
(`ui/render/EspRenderView.java:1011`), yet the mask bytes `k2..k7` are read by
exactly one method — `observeSmallInbound` at `:684` — which does nothing but set
`maskLocked`. **The overlay's most important gate is a proxy for a value nothing
downstream uses.** Worth an alarm on its own (§6.4).

### 3.2 `esp/EspEngine.java` — `observeKeepalive` (own state, 10 Hz)

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `:696` | `if (plen < 32 \|\| off < 0 \|\| off + plen > data.length) return;` | **silent** | own state never updates; this bail runs **before** `keepaliveParseBad`, so the existing ok/bad pair cannot see it | degraded | `ESP_KEEPALIVE_SHAPE` | ~0/s (callers pre-gate at 32-96 B) | counter |
| `:701-705` | `bodyStart < 0` — handle varint truncated | counted | — | — | `ESP_KEEPALIVE_BAD` | — | already covered |
| **`:707-710`** | **`v == null \|\| v.length != 23`** | **`keepaliveParseBad++` only — NO `Diag.hit`** | own position, camera, RTT and **own team all stop**. This is the exact historical failure: a 5-byte handle made the body decode to 24 varints, 0/190 keepalives accepted, and the entire ESP rendered nothing (`:536-544`) | **fatal** | `ESP_KEEPALIVE_BAD` — **add the missing hit here**, and split as `ESP_KEEPALIVE_WRONG_COUNT` | 0/s healthy; 10/s when broken | both |
| `:711` | success | `keepaliveParseOk++` only | — | — | `ESP_KEEPALIVE_OK` — slot exists, **unwired** | 10/s | counter |
| **`:718`** | **`if (oid >= 1 && oid <= 127) ownEntityId = oid;`** — no else | **silent** | `ownEntityId` keeps its stale value or stays `-1`. Rung 1 cannot identify self → **our own character gets a red box**, and `classify` bails at `:1411` leaving every entity unwritten | **fatal** | `ESP_OWN_ID_REJECTED` | 0/s healthy | both |
| **`:726`** | **`if (isValidTeam(otm))`** — no else | **silent** | `ownTeam` stale or 0 → `ownTeamUsable` false → rung 2 never fires → **every teammate painted red** | **fatal** | `ESP_OWN_TEAM_REJECTED` | 0/s healthy | both |
| `:753` | `if (r >= 5 && r <= 2000) rttMs = ...` | silent | `measuredLagMs()` falls back to 0 until the self-echo converges; lead/prediction is off | benign | `ESP_RTT_REJECTED` | 0/s healthy | counter |

`:718` and `:726` deserve emphasis. Both are *acceptance* guards written without an
else branch, so a value outside the band leaves the previous value in place. After
a `resetMatch()` the previous value is the wipe sentinel, and the engine then
behaves as though identity is unknown — indefinitely, and with nothing said.

### 3.3 `esp/EspEngine.java` — `observeChainPacket` (the primary feed)

**No instrumentation at all today.** Four slots are allocated for it and all four
are unwired.

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `:889` | `plen < 20 \|\| plen > CHAIN_MAX_LEN` | silent | — | benign | fold into offered/accepted | high | — |
| `:890` | bounds | silent | — | benign | — | ~0/s | — |
| `:891` | `(data[off+8] & 0xff) != 0x00` | silent | **family discriminator** — most inbound traffic is not a chain. **Expected and high-volume: correct, and must stay silent per-packet.** | benign | count the *entry* as `ESP_CHAIN_PKT` (slot exists, unwired) and derive the rejection rate against `TUNNEL_PKT_IN` | = inbound packet rate | counter |
| `:893` | `(b9 & 1) != 0` | silent | as above | benign | — | high | — |
| `:895` | `declared < 1 \|\| declared > 64` | silent | as above | benign | — | high | — |
| **`:902`** | **`plen < CHAIN_HEADER + declared * MIN_RECORD_BYTES`** | **silent** | the 16-byte floor. It exists to reject 6 490 ciphertext packets in session 173746, but it is a *heuristic*: "rejects 91.1 % of 173746's collision set but 0.0 % in five of the other six sessions" (`:855` javadoc). A session where it starts biting loses real chains and the boxes stop following | **degraded** | `ESP_CHAIN_BUDGET_REFUSED` | 0/s healthy; watch the ratio to `ESP_CHAIN_PKT` | counter |
| `:910` | `recStart < 0` | silent | whole packet dropped | degraded | `ESP_CHAIN_HEADER_BAD` | ~0/s | counter |
| **`:976`** | **`if (parseStructured(...)) return;`** — the false branch | **silent** | falls through to the heuristic scanner, which **invents phantom entity ids** (up to 40/session per `:974`). Structural-parse rate is the single best health number the engine has: it fell **96.3 % → 59.4 %** during the CS reset loop (`docs/CS_MODE_ESP_FAILURE.md` §7.4) purely as a side effect | **degraded** | `ESP_CHAIN_PARSE_STRUCTURED` / `ESP_CHAIN_PARSE_FALLBACK` — both slots exist, **both unwired** | ~5-10/s combined | counter |
| `:980` | `v == null \|\| v.length < 4` | silent | packet dropped entirely — neither parser ran | degraded | `ESP_CHAIN_PARSE_REFUSED` (slot exists, unwired) | 0/s healthy | counter |
| **`:1026-1031`** | **`if (idMax == 0)`** — no (ceiling, Z-floor) pair reproduced `declared` | **silent** | falls back to the loosest pair; "a partial chain beats no chain", but a partial chain is also where phantom ids come from. Measured exact-split rate ranges 42.2 %-100 % by session | **degraded** | `ESP_CHAIN_SPLIT_INEXACT` | 0-1/s healthy | counter |
| `:1035-1037` | three `continue`s in the record scan | silent | the splitter's inner scan | benign | **none. Correct, leave silent.** | very high | — |
| **`:1053/:1055`** | `if (++found >= declared) break;` / `if (found > 0)` | **silent** | `found < declared` is a **partial parse**: some entities in this packet never updated. Nothing anywhere records it | **degraded** | `ESP_CHAIN_RECORDS_LOST`, hit with `(declared - found)` via `Diag.hit(slot, n)` | 0/s healthy | counter |

### 3.4 `esp/EspEngine.java` — `parseStructured` (per chain packet)

Six distinct `return false`s that all collapse into one outcome — "fall back to the
heuristic scanner" — with no way to tell which fired. That is the difference
between *"our id ceiling is too low for a 50-player lobby"* and *"the record layout
changed"*, and today they look the same.

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| **`:1092`** | `id < 1 \|\| id > MAX_ENTITY_ID` (64) | silent | whole packet to the fallback. **`MAX_ENTITY_ID` is 64 and Cmd 118 slots reach 53 in a 26-player BR match**; a 50-player solo lobby will cross it | **degraded** | `ESP_STRUCT_ID_CEILING` | 0/s healthy | counter |
| `:1096` | `x < MIN_RECORD_X` (500) | silent | as above | degraded | `ESP_STRUCT_X_FLOOR` | 0/s healthy | counter |
| `:1103` | self-echo 20-varint run truncated | silent | as above | degraded | `ESP_STRUCT_ECHO_SHORT` | 0/s healthy | counter |
| `:1110` | `pos[0] + 3 > end` — no room for the pose block | silent | as above | degraded | `ESP_STRUCT_POSE_SHORT` | 0/s healthy | counter |
| `:1119` | `pos[0] > end` | silent | as above | degraded | fold into `ESP_STRUCT_POSE_SHORT` | 0/s | — |
| **`:1123`** | **`left < 1 \|\| left > 3`** — trailing residue | **silent** | the terminal validation. This is the one that fires when the layout is *right in shape but wrong in length* — a new field appearing on the wire | **degraded** | `ESP_STRUCT_RESIDUE` | 0/s healthy | both |
| `:1128` | `if (t == null) continue;` | silent | unreachable in practice (`updateTrack` just inserted it) | benign | **none. Correct, leave silent.** | 0/s | — |

### 3.5 `esp/EspEngine.java` — `updateTrack` / velocity (per entity per packet)

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| **`:1211-1215`** | `d > 50000` → `pendingTeleport = true` | **silent** | the position is **held**, not applied: the box freezes for at least one 198 ms tick. Correct behaviour (it filters parse phantoms) but invisible, and a rising rate means the record splitter is producing garbage | degraded | `ESP_TELEPORT_GUARD` (slot exists, **unwired**) — **document a healthy range**: a handful per match (respawns, vehicle entry). More than ~1/s sustained means mis-parsing, not teleporting | **expected, low volume** | counter |
| `:1192-1195` | corroboration fails; the pending jump is discarded | silent | a real respawn is dropped for one more tick | benign | `ESP_TELEPORT_UNCORROBORATED` | rare | counter |
| **`:1258-1262`** | `dt > VEL_DT_MAX_MS` → `velValid = false` | **silent** | prediction switches off for that entity; the box lags by up to a full tick until a clean 185-260 ms pair arrives | degraded | `ESP_VEL_DROPOUT` | **expected and HIGH volume in BR** — interest-managed non-squad entities update at 1.2 Hz with gaps to 556 s, so this fires for most non-squad entities most of the time. **Healthy range: up to ~60 % of chain samples in BR, near 0 % in Clash Squad.** Without that documented it is pure noise | counter |
| `:1242-1246` | `abs(d*) > VEL_TELEPORT_UNITS` → velocity zeroed | silent | as above | degraded | `ESP_VEL_REJECTED` (slot exists, unwired) | rare | counter |
| `:1251` | `if (speed <= VEL_MAX_U_PER_MS)` — no else | silent | the sample is dropped; the old velocity persists | degraded | fold into `ESP_VEL_REJECTED` | ~0/s (13.0 u/ms sits above all 44 436 measured samples) | counter |
| `:1290` | `if (t.velValid) return;` | silent | by design — a measurement outranks a seed | benign | **none. Correct, leave silent.** | high | — |
| `:1294` | seed speed above the absurdity cap | silent | a just-appeared target stands still for a whole tick instead of being extrapolated | benign | `ESP_VEL_SEED_REJECTED` | rare | counter |

### 3.6 `esp/EspEngine.java` — team sources

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `:1574-1585` | six length/shape/range guards in `observeHandleEvent` | silent | a free teammate label is lost | benign→degraded | one `ESP_HANDLE_EVENT_REFUSED` for the lot, plus `ESP_HANDLE_EVENT_OK` | offered at inbound rate; accepted ~79 per match | counter |
| **`:1604`** | **`h0 < 0x80 \|\| h0 > 0xBF`** | **silent** | `h0` is the first LEB128 byte `0x80\|(id&0x7F)`, so the `0xBF` ceiling **silently drops every damage event whose victim id is 64..127**. The BR corpus reaches chain id 63 and Cmd 118 slot 53 — this is one lobby away from biting. `observeHandleEvent:1577` has **no such ceiling**: the two gates disagree (`docs/FRIEND_FOE_AUTHORITATIVE.md` §1.6(d)) | **degraded** | `ESP_DAMAGE_ID_CEILING` | 0/s today, non-zero the day it bites | both |
| `:1611` | `tt == 0 \|\| (tt & 0x07) != 0` | silent | the historical form of this gate discarded **20.5 % of all damage events, and 100 % in three of ten sessions** | degraded | `ESP_DAMAGE_TYPE_REFUSED` | 0/s healthy | counter |
| `:1613` | `v.length != 8` | silent | damage event dropped | degraded | `ESP_DAMAGE_SHAPE` | 0/s healthy | counter |
| `:1601`/`:1602`/`:1605`/`:1626` | length, bounds, handle-shape, id-range | silent | as above | benign | fold into `ESP_DAMAGE_REFUSED` | high (offered on every 20-40 B inbound packet) | counter |
| `:1627-1638` | `damage <= 0 \|\| damage > MAX_HP` with no SP damage either | silent | HP estimate and the team pairing both lost | benign | `ESP_DAMAGE_ZERO` | rare | counter |
| `:1678` | `id < 1 \|\| id > 127` in `noteTeam` | silent | team byte discarded | degraded | `ESP_NOTETEAM_BAD_ID` | 0/s healthy | counter |
| `:1681` | `!isValidTeam(team)` — rejects 0 and 255 | silent | correct and important (two entities both reading 0 compare equal and paint strangers blue) but invisible | benign | `ESP_NOTETEAM_BAD_TEAM` | rare | counter |
| `:1688` | `src < t.teamSrc` — precedence | silent | by design: a late damage handle must not downgrade a Cmd 118 bind | benign | `ESP_NOTETEAM_WEAKER_SRC` | moderate | counter |
| **`:1698`** | **`if (!isValidTeam(ownTeam)) return;`** | **silent** | `t.team` and `t.teamSrc` **are stored**, but `t.role` is never derived. We hold the server's own answer and decline to use it. Self-heals on the next `classify()` via the recompute at `:1390` — **but only if `ownTeam` becomes valid**, which is `:726`'s problem | degraded | `ESP_NOTETEAM_NO_OWN_TEAM` | 0/s healthy | counter |

### 3.7 `esp/EspEngine.java` — reliable-channel feeds

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| **`:1816-1823`** | **`PriSync.decode(...)`'s boolean return is discarded** | **silent** | `PriSync.decode`'s own contract says *"false means the body was not this grammar … and the caller must discard whatever the sink already received"* (`decode/body/PriSync.java:80-83`). The caller ignores it, and the sink has **already mutated `PriTracker`**. A mis-keyed body writes junk HP and is never counted | **degraded** | `ESP_PRISYNC_REFUSED` / `ESP_PRISYNC_OK` | ~a few/s | counter |
| `:1845` | `body == null \|\| len < 4 \|\| bounds` | silent | equipment join lost | benign | `ESP_EQUIP_REFUSED` | rare | counter |
| `:1849` | `r.bad` after the handle | silent | as above | degraded | fold above | rare | counter |
| `:1855` | `if (r.bad) break;` mid-scan | silent | a **truncated** value set is still handed to `pri.onEquipment` at `:1858`, so a partial set can produce a wrong `hasBoth` verdict | degraded | `ESP_EQUIP_TRUNCATED` | rare | counter |
| `:1858` | `if (n > 0)` — no else | silent | nothing bound | benign | fold into `ESP_EQUIP_REFUSED` | rare | counter |
| **`:1882`** | **`r.bad \|\| count < 1 \|\| count > 256`** | **silent** | Cmd 118 is **the authoritative friend/foe source** and arrives in a match-start burst of 12 285 records across 90 capture files. One refused body is a whole roster burst lost → everyone red | **degraded** | `ESP_BINDPRI_REFUSED` | 0/s healthy; bursts at match start | both |
| **`:1887`** | **`if (r.bad) return;` inside the record loop** | **silent** | **partial** bind list: the records before the failure are applied, the rest silently dropped. No record of how many were lost | **degraded** | `ESP_BINDPRI_TRUNCATED`, and `ESP_BINDPRI_RECORDS` hit with the accepted count | bursts at match start | both |
| `:1942`-`:1958` | five `return false`s in `headPointForVictim` (null out-array, id range, untracked, **>1500 ms stale**, NaN/overflow) | silent | the Cmd 106 hit-point rewrite falls back to the client's own point — the aim feature quietly does nothing | degraded | `ESP_HEADPOINT_NO_TRACK`, `ESP_HEADPOINT_STALE`, `ESP_HEADPOINT_BAD_COORDS` (three, because they mean three different things) | per outbound 106, bursty | counter |

### 3.8 `esp/PriTracker.java` — health and the owner→entity join

**Zero instrumentation.** It already carries five ad-hoc counters (§5).

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `:206` | `if (o.isPlayer == 0) return;` on CUR_HP | silent | correct and load-bearing — varId 0 is `EPRI_PLAYER_CUR_HP` **only for a player**; a capture carries 181 non-player binds against 28 player ones | benign | `ESP_HP_NONPLAYER` (`nonPlayers` already counts the bind side; this is the *read* side) | high | counter |
| `:210` | `hp < 0 \|\| hp > MAX_HP_MAX` | silent | HP update dropped | degraded | `ESP_HP_OUT_OF_RANGE` | 0/s healthy | counter |
| `:230`/`:232` | maxHp gated on `isPlayer` and range | silent | the bar scales to an assumed 200 | benign | `ESP_MAXHP_REFUSED` | rare | counter |
| `:241` | `if (hi != 0 && lo != 0)` — no else | silent | the equipment join is never seeded for that owner, so a player we never shoot never binds | degraded | `ESP_EQUIP_ONHAND_EMPTY` | moderate | counter |
| `:255` | `delta <= 0 \|\| delta > MAX_HP_MAX` | silent | damage correlation loses a sample | benign | fold | rare | counter |
| `:281` | handle/vals guards in `onEquipment` | silent | join lost | benign | fold into `ESP_EQUIP_REFUSED` | ~1 122/match | counter |
| **`:310`** | **`if (handle != -1 && handle != t.handle) { handle = -2; break; }`** then `:314` `if (handle > 0 …)` fails | **silent** | the **ambiguity rejection**. This is measured as the difference between *19 unanimous bindings* and *47 bindings of which only 6 were* — it is doing real work and nobody can see it working | degraded | `ESP_EQUIP_AMBIGUOUS` | bursty (everyone loots at once) | counter |
| **`:402-409`** | the `onDamage` loop finds no matching drop and returns | **silent** | **expected and high-volume**: only **8.5 % of HP drops correlate**, because we only see damage events for fights involving us. **Healthy range: ~90 % miss.** A counter here without that number documented is noise | benign | `ESP_DMG_CORR_MISS` / `ESP_DMG_CORR_HIT` | ~600 damage events/match | counter |
| `:414`/`:416` | `o == null` / already settled | silent | by design | benign | **none. Correct, leave silent.** | moderate | — |
| `:415` | `o.votes == Integer.MAX_VALUE` — server said so | silent | by design: a guess must not override Cmd 118 | benign | `ESP_BIND_GUESS_BLOCKED` (useful: proves 118 is winning) | moderate | counter |
| `:424` | `o.votes < CONFIRM_VOTES` | silent | binding pending; HP stays blank meanwhile | benign | `ESP_BIND_PENDING` | moderate | counter |
| `:355` | `if (player && squad <= 254)` — a type-1 record with squad 255 is dropped | silent | one player has no team byte → red | benign | fold into `ESP_NOTETEAM_BAD_TEAM` | ~0/s | counter |
| **`:443`** | **`hpFor`: `id == null return -1`** — handle not bound | **silent** | **HP blank on the box** | degraded | `ESP_HP_UNBOUND` (slot exists, **unwired**) | per entity per frame — **mark `counter`, and hit it once per frame not per lookup** | counter |
| **`:445`** | **`hpFor`: `o.curHp < 0 return -1`** — bound but never reported | **silent** | **HP blank on the box — same symptom, different cause.** Splitting these two is the whole point: unbound means the *join* failed, `curHp < 0` means the *Cmd 1900 channel* is not arriving | degraded | `ESP_HP_NO_VALUE` (new) vs `ESP_HP_UNBOUND` (existing); `ESP_HP_BOUND` on success (slot exists, unwired) | as above | counter |

**Not a bail, but found while reading:** `PriTracker.sweep(long)` (`:458-466`) has
**zero callers**, so `OWNER_STALE_MS = 30 s` never applies and `owners` grows for
the life of the match. `squadCount()` (`:172`) also has zero callers — a
ready-made diagnostic that nothing surfaces. Both are instrumentation-adjacent
and neither is a behaviour change to fix.

### 3.9 `esp/MatchRoster.java` — names and the roster squad byte

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `:86` | `r.bad \|\| nick == null \|\| nick.isEmpty()` | silent | a player has no name **and no roster squad byte** — `put()` stores both | degraded | `ESP_ROSTER_JOIN_REFUSED` | bursty at match start | counter |
| `:87` | `if (!put(...)) return;` | silent | as above | degraded | fold | bursty | counter |
| `:108` | same guards in `observeKill` | silent | mid-match gap-fill lost | benign | `ESP_ROSTER_KILL_REFUSED` | ~97/corpus | counter |
| `:110` | `if (names.containsKey(slot)) return;` | silent | by design | benign | **none. Correct, leave silent.** | moderate | — |
| `:119` | `r.bad` in `observeQuit` | silent | a departed player's name lingers | benign | fold | rare | counter |
| `:130` | `slot < 1 \|\| slot > 127` | silent | mis-parse guard | benign | `ESP_ROSTER_BAD_SLOT` | 0/s healthy | counter |
| `:133` | control byte in the nickname | silent | mis-parse guard | benign | fold above | 0/s healthy | counter |
| `:136` | `if (squad > 0) squads.put(...)` — no else | silent | correct (squad 0 is unassigned) | benign | **none. Correct, leave silent.** | moderate | — |
| success | — | — | — | — | `ESP_NAME_BOUND` (slot exists, **unwired**) — hit at `:135` | bursty | counter |

Note the roster is now genuinely wired: `EspEngine:1377` calls `roster.squad(id)`.
`docs/FRIEND_FOE_AUTHORITATIVE.md` §2.5's "`squad()` has 0 callers" is stale.

### 3.10 `esp/OrientationProvider.java` — **a live instance of the fixed bug**

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| **`:76-80`** | **`long ownMs = esp.ownLastUpdateMs(); if (ownMs <= 0 \|\| now - ownMs > STALE_MS) { have = false; return; }`** | **silent** | **`ownLastUpdateMs` tracks Cmd 2001 *specifically*, and by construction stops the moment you mount.** `EspEngine:150-169` documents this at length and `ui/render/EspRenderView.java:1016` was fixed to read `ownStateMs()` instead — **this reader was not.** So 1 500 ms into any vehicle ride `Full.yawKnown()` goes false and the renderer falls through to `Folded`, whose `pitch()` **returns a hard-coded 0.0** (`:246-249`) and whose yaw is inferred from movement quadrant. The self-echo and Cmd 2069 paths are feeding `dirX/dirY/dirZ` perfectly and are thrown away. Same mistake, same field, one reader further down | **degraded → fatal while mounted** | `ESP_ORIENT_STALE_2001` — and this one should be an **`event`**, because it names a specific bug | 120 Hz while mounted | **both** |
| `:75` | `esp == null` | silent | — | benign | `ESP_ORIENT_NO_ENGINE` | 0/s | counter |
| `:85-88` | `!(m > 0.25 && m < 4.0)` — not unit length | silent | orientation dropped; indicates a misparse, not a real orientation | degraded | `ESP_ORIENT_NOT_UNIT` | 0/s healthy | counter |
| `:171` | same unit check in `Folded` | silent | as above | degraded | fold | 0/s healthy | counter |
| `:193-197` | teleport-scale own velocity → `haveVel = false` | **partly visible** — `src` string | quadrant held | benign | `ESP_ORIENT_FOLD_HOLD` | moderate | counter |
| `:199-203` | `dt > 400` stale gap → resample | partly visible | as above | benign | fold | moderate | counter |
| `:207-215` | `!haveVel` / `vMag < MOVE_MIN` → `src = "hold"` | partly visible | **standing still, the folded yaw is simply the last one** — the documented "sustained backward running gives the opposite quadrant" limitation lives here | benign | fold | high while stationary | counter |
| `:232-234` | alignment below the switch threshold | partly visible | quadrant held | benign | fold | moderate | counter |

`Folded` is the better-behaved of the two: it records a provenance string
(`source()`, `:256-259`) that distinguishes `init` / `hold` / `move`. That string is
the right idea and is exactly what `Full` lacks — `Full.source()` returns only
`"full"` or `"full?"` (`:112-113`), so the mounted-staleness bail and the
not-unit-length bail are indistinguishable on the HUD.

### 3.11 `esp/EspBodyDecoders.java` — dead code, every bail unreachable

**This class has no callers.** `VpnEngine.java:94-101` explains why: registering
it while `PacketLoop` and `UdpSessionManager` run their own shape-gated feeds would
hand `EspEngine` every position twice. So all of the following are latent, not live.

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `:51` | `if (registry == null \|\| esp == null) return;` | silent | **registration silently does nothing** — the caller believes the ESP is wired | fatal *if reached* | `ESP_DECODERS_NOT_REGISTERED` | once | **event** |
| `:92`/`:130` | `if (legacyOff < 0) return false;` | silent | body offset below the 8-byte prefix the legacy parsers assume | degraded | `ESP_DECODER_BAD_OFFSET` | 0/s | counter |
| `:154` | `decodeOutbound` falls through to `return false` | silent | outbound packet not offered to any ESP feed | benign | fold into a fed/not-fed pair | high | counter |
| `:172-190` | the inbound length windows | silent | same starvation class as the historic 38 B floor (2 685/3 131 updates lost across 40 sessions, **median per-session loss 100 %**) | degraded | `ESP_DECODER_NOT_FED` | high | counter |

**Recommendation:** do not instrument this file. Either register it and delete the
duplicate feeds in the same change, or delete the class. Counters on unreachable
code are worse than none — a permanent zero reads as health.

### 3.12 `esp/MarkTarget.java`

No bails. `age()` (`:62-65`) returns `Long.MAX_VALUE` when never set, and the
staleness decision is correctly delegated to `filter/MarkFilter.java:158`, which is
**already counted** as `FLT_MARK_NO_TARGET`. Nothing to add.

---

## 4. `decode/` — silent failure points

**Zero instrumentation anywhere in this tree**, and five slots (`DEC_*`) allocated
for it, all unwired.

### 4.1 `decode/crypt/` — the top-priority gap

Everything reliable — health (Cmd 1900), the owner→entity bind (118), the roster
(101/107/139/102), the equipment join (121) — reaches `EspEngine` only if
`BodyCrypt.decrypt` succeeds. **It returns `-1` for four completely different
reasons and the caller cannot tell them apart**; `tunnel/UdpSessionManager.java:254`
then sets `bLen = 0` and drops the body without a word. This is the mechanism
behind *"health was invented rather than read, for months"*.

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| **`crypt/BodyCrypt.java:39`** | **`hex == null \|\| hex.length() != 32`** → no schedule | **silent** | **no session key. Every reliable channel is dead: no HP, no names, no Cmd 118 friend/foe.** The single most consequential "not ready yet" path in the codebase | **fatal** | `DEC_NO_KEY` (mirrors the existing `PROTO_NO_KEY`; keep one, not two) | per reliable packet until the key lands | counter |
| `crypt/BodyCrypt.java:46` | `Character.digit` < 0 → malformed hex | silent | as above, but indicates a *corrupt* key rather than a missing one | fatal | `DEC_KEY_MALFORMED` | 0/s | **event** |
| `crypt/BodyCrypt.java:69` | null / bounds | silent | body dropped | benign | `DEC_BODY_SHORT` (slot exists, unwired) | 0/s | counter |
| **`crypt/BodyCrypt.java:70`** | **`len < 16 \|\| (len & 7) != 0 \|\| len > 4096`** | **silent** | not a whole number of TEA blocks — the body is not what we think it is | degraded | `DEC_TEA_BAD_LENGTH` (slot exists, unwired) | 0/s healthy | counter |
| `crypt/BodyCrypt.java:72` | `sched == null` | silent | same as `:39` | fatal | fold into `DEC_NO_KEY` | — | counter |
| **`crypt/BodyCrypt.java:75-77`** | **`catch (Throwable t) { return -1; }`** | **a catch that swallows** | any bug in `Tea` is invisible; four causes already collapse to `-1` and this makes five | degraded | `DEC_TEA_THREW` | **must be 0** | **event** |
| **`crypt/Tea.java:157`** | **`if (out[start + plainLen + i] != 0) return -1;`** — the seven-zero tail check | **silent** | **this is the "wrong key" signal**, and it is the most diagnostic single bit in the decrypt path. `rand()` is stubbed to 0 in the shipped binary so the tail is deterministic; measured 138/138 and 339/339 with the correct key. Distinguishing this from a length problem tells you *rotate the key* versus *fix the framing* | **fatal** | `DEC_TEA_BAD_PADDING` (slot exists, unwired) | 0/s healthy | counter |
| `crypt/Tea.java:124-128` | five argument guards | silent | as above | benign | fold into `DEC_TEA_BAD_LENGTH` | 0/s | counter |
| `crypt/Tea.java:154` | `plainLen < 0` | silent | pad byte implies a negative plaintext | degraded | fold into `DEC_TEA_BAD_PADDING` | 0/s | counter |
| `crypt/Tea.java:57` | `schedule`: key null or < 16 B | silent | no schedule | fatal | fold into `DEC_NO_KEY` | 0/s | counter |
| `crypt/Tea.java:187-190` | three guards in `qqTeaEncrypt` | silent | an outbound rewrite silently fails to encrypt | degraded | `DEC_TEA_ENCRYPT_REFUSED` | 0/s | counter |

**The single highest-value pair in this whole inventory** is
`DEC_TEA_BAD_PADDING` versus `DEC_TEA_BAD_LENGTH`. `Invariants` already has a
`DECRYPT_FAILING` alarm (`diag/Invariants.java:136-141`) driven by
`PROTO_DECRYPT_OK` / `PROTO_DECRYPT_FAILED`, but those are set in the protocol
package and say only *that* it failed. The `DEC_*` pair says *why*.

### 4.2 `decode/body/`

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| **`body/PriSync.java:93,101,106,111,113,115`** | six `return false`s (owner varint bad; `blockLen` overruns; record varint bad; `i != stop` residue; > 256 groups; trailing bytes) | **silent, and the boolean is discarded by the only caller** (`EspEngine:1816`) | a mis-keyed or clipped Cmd 1900 body **has already fed the sink** before the failure is detected — partial junk HP is committed. Measured healthy rate is 6 709/6 709 exact, so any non-zero here is real | **degraded** | `DEC_PRISYNC_REFUSED`, split as `DEC_PRISYNC_RESIDUE` (`:111`/`:115`) vs `DEC_PRISYNC_TRUNCATED` (`:93`/`:106`) | ~a few/s | counter |
| `body/PriSync.java:97` | `i + 2 > end` — no room for the `FixUInt16` block length | silent | as above; this is the classic raw-vs-varint desync trap | degraded | fold into `DEC_PRISYNC_TRUNCATED` | rare | counter |
| **`body/WireReader.java:35`** | **ctor sets `bad` for null/negative/overrun** | **silent** | every subsequent read returns 0 with no exception. Callers that check `r.bad` are fine; `EspEngine:1880` reads `header` *before* checking, which is safe only because `u()` returns 0 when bad | benign | `DEC_READER_BAD_ARGS` | 0/s | counter |
| `body/WireReader.java:58` | `u()` truncated or overlong | silent, latched in `bad` | the field is 0 | degraded | `DEC_VARINT_TRUNCATED` (slot exists, unwired) | 0/s healthy | counter |
| `body/WireReader.java:70` | `rawByte()` past the end | silent, latched | | degraded | fold | 0/s | counter |
| `body/WireReader.java:83` | `str()` length implausible or overruns | silent, latched | a name is dropped | degraded | `DEC_STRING_REFUSED` | 0/s healthy | counter |
| **`body/WireReader.java:89-91`** | **`catch (Exception e) { bad = true; return null; }`** on UTF-8 decode | **a catch that swallows** | a name with odd bytes vanishes | benign | fold into `DEC_STRING_REFUSED` | 0/s | counter |
| **`body/VehicleSync.java:115-118`** | `!isVehicleCarrier \|\| null \|\| bounds` → `return null` **before** the `rejected` counter | **silent** | `rejected` (`:102`) does **not** count these, so `ESP_VEHICLE_PARSE_REFUSED` and `VehicleSync.rejected()` disagree by exactly this population | benign | fold into `ESP_VEHICLE_PARSE_REFUSED` (already hit at `EspEngine:2189`) | 0/s | — |
| **`body/VehicleSync.java:129-130`** | `rejected++` after both `tryParse` attempts fail | **counted, but undifferentiated** | eleven distinct causes (nine `Leb128.BAD`s, the terminal-cursor check `:200`, the quaternion check `:202`, the aim check `:203`) collapse into one number. "Position is 8 bytes short" and "the quaternion is not unit" need different fixes | degraded | split into `DEC_VEHICLE_TRUNCATED` (`:141,147,155,163,174,180,188,192`), `DEC_VEHICLE_RESIDUE` (`:200`), `DEC_VEHICLE_QUAT_BAD` (`:202`), `DEC_VEHICLE_AIM_BAD` (`:203`) | 10/s while mounted | counter |
| `body/VehicleSync.java:126` | `opVarintReads++` on the field-8 retry | counted | tells you whether field 8 is a raw byte or a varint — **a permanent 0 confirms raw-byte**, which is a real open question (`:31-38`) | benign | `ESP_VEHICLE_OP_VARINT` (slot exists, unwired) — wire it to this existing counter | rare | counter |
| `body/PositionSync.java:106,107,110,114,117,122,127,133` | eight `return false`s in `parse` | silent | the outbound keepalive is not recognised, so teleport and every other rewrite quietly decline | degraded | `DEC_POSSYNC_REFUSED` | up to 10/s | counter |
| `body/PositionSync.java:189` | `setSigned`: value outgrew its field | silent | **the caller must withhold the packet**; if it does not, a real position ships | degraded | `DEC_POSSYNC_WIDTH` | bursty | counter |
| **`body/PositionSync.java:262`** | **`if (declared != plen - hdrSize) return -1;`** — the stale-layout proof | **silent** | correct and important: a stale layout would write `Length` with the wrong mask and the server ends the session. But it is invisible, and the identical condition in the filter package **is** counted (`FLT_LAYOUT_STALE_REFUSED`) | degraded | reuse `FLT_LAYOUT_STALE_REFUSED`, or add `DEC_POSSYNC_LAYOUT_STALE` | 0/s healthy | **both** |
| `body/PositionSync.java:268,275,289,296` | scratch overflow, buffer overflow, reseal failure | silent | rebuild abandoned | degraded | `DEC_POSSYNC_REBUILD_FAILED` | 0/s | counter |
| **`body/BodyDecoderRegistry.java:112-120`** | **`dispatch` returns false when nothing consumed** | **silent — and both callers discard the return** (`tunnel/PacketLoop.java:180`, `tunnel/UdpSessionManager.java:273`) | the "how much of the wire do we actually understand" number exists and is thrown away on the floor | degraded | `DEC_DISPATCH_CONSUMED` / `DEC_DISPATCH_UNCLAIMED` | inbound + outbound packet rate | counter |
| `body/BodyDecoderRegistry.java:92` | `lookup` returns null | silent | falls to the fallback | benign | fold above | high | — |
| `body/BodyDecoderRegistry.java:48-50`, `:56` | `IllegalArgumentException` | **throws — loud** | — | benign | **none. Correct as is.** | startup | — |
| `body/BodyDecoderTable.java:115`, `:133` | a malformed packed chunk entry is skipped | silent | a wire layout silently missing → that command decodes positionally forever | benign | `DEC_TABLE_ENTRY_SKIPPED` | startup only | **event** |
| `body/BodyDecoderTable.java:406` | `matching()` returns -1 on unbalanced parens | silent | the program is refused | benign | fold above | startup | — |
| `body/BodyDecoderText.java:116-122` | `catch (Throwable) { failureCount++; }` | **counted** — `failureCount()` | — | — | **already covered.** Fold `failureCount` into the registry | writer thread | counter |
| `body/BodyDecoderText.java:126,138,159,166` | unreadable / residue / no-layout | **counted** — `unreadableCount` / `residueCount` / `noLayoutCount` / `exactCount` | — | — | **already covered** (§5) | writer thread | counter |
| `body/CmdCatalogue.java:89` | `name()` returns null | silent | `nameOr` falls back to `CMD_<n>` | benign | **none. Correct, leave silent.** | logging only | — |
| `body/Cmd.java:259` | `of()` → `UNKNOWN` | silent | by design, and the catalogue is explicitly open | benign | **none. Correct, leave silent.** | high | — |

`decode/body/BodyDecoderText.java` is the model the rest of the tree should copy:
four mutually exclusive outcome counters, a `coverage()` line that states
`exact/residue/nolayout/unreadable` and an explicit *"Should stay 0"* on the
swallow counter (`:71-72`). It is the only file in scope that was written with
this discipline, and it is not on a hot path.

### 4.3 `decode/frame/`

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `frame/PacketCodec.java:37,38` | null / bounds → `null` | silent | packet unparsed | benign | fold into `TUNNEL_NOT_MATCH_TRAFFIC` (already exists) | 0/s | — |
| `frame/PacketCodec.java:42` | `hdr == NOT_MATCH_TRAFFIC \|\| len < hdr` → `null` | silent | **the primary discriminator. Expected and high-volume** — foreign UDP lands in the MsgKey range ~8 % of the time. Already counted as `TUNNEL_NOT_MATCH_TRAFFIC` | benign | **already covered** | full packet rate | counter |
| `frame/PacketCodec.java:53` | `crcOk` computed and **returned, not enforced** | — | correct design: the caller decides. `PacketLoop:162` gates `cmd` on it and `TUNNEL_CRC_BAD` counts it | benign | **already covered** | — | — |
| `frame/PacketCodec.java:68,82,83,86,111` | `reserialize` / `refreshCrcIfMatchTraffic` return false | silent | **a mutated packet ships with a stale CRC and the server discards it** — the leading suspect for teleport's "server sets us back" | degraded | `DEC_RESEAL_REFUSED` | 0/s | **both** |
| **`frame/HeaderLayout.java:112,119`** | **`writeByte`/`writeShort`: `if (o < 0) return;`** | **silent no-op write** | the caller believes the write succeeded. `PositionSync.rebuild:292` writes `DATA_LEN` this way; a layout missing that field would silently ship the old length | degraded | `DEC_HEADER_WRITE_ABSENT` | 0/s | **event** |
| `frame/HeaderLayout.java:97,103` | `readByte`/`readShort` return `-1` for an absent field | silent | only `ORDER_ID` can be absent and `PacketCodec:49` handles it | benign | **none. Correct, leave silent.** | high | — |
| `frame/HeaderLayout.java:55,64` | `layOut` returns null → ctor **throws** | **loud** | — | benign | **none. Correct as is.** | startup | — |
| **`frame/Crc7.java:75`** | **`verify` returns false for null/short/overrun input** | **silent** | conflates *"not verifiable"* with *"checksum mismatch"*. Callers read a false as "corrupt packet" | benign | note only — the one caller, `PacketCodec.isIntactMatchTraffic:118`, pre-checks | 0/s | — |
| `frame/MsgKey.java:69-73` | `headerSizeOf` → `NOT_MATCH_TRAFFIC` | silent | as `PacketCodec:42` | benign | **already covered** | high | — |
| `frame/SendOption.java:50` | `of()` → `UNKNOWN` | silent | by design | benign | **none. Correct, leave silent.** | high | — |
| `frame/PacketFlags.java`, `frame/Direction.java`, `frame/HeaderField.java`, `frame/UdpPacket.java` | — | — | **no silent failure points.** `HeaderField.byId:79` returns null out of range but has no unchecked caller in scope | benign | — | — | — |

---

## 5. Existing ad-hoc counters, to fold into the registry

Nine counters already exist in scope, in four different reporting styles. All
should keep their current behaviour and gain a `Diag.hit` alongside.

| where | counter | surfaced via | folds into |
|---|---|---|---|
| `esp/EspEngine.java:172-173` | `keepaliveParseOk` / `keepaliveParseBad` | `calibrationReadout()` `:2295`, accessors `:2264-2265` | `ESP_KEEPALIVE_OK` (unwired) / `ESP_KEEPALIVE_BAD` (wired at `:703` only — **the `:707` branch is missed**) |
| `esp/EspEngine.java:1590-1592` | `spDamageTotal` / `spDamageEvents` | accessors `:1595`, `:1598` | `ESP_SP_DAMAGE` — a *quantity*, not a failure; keep as an accessor, do not make it a slot |
| `esp/EspEngine.java:1773-1774` (decl.) | `damageEvents` / `kills` | `calibrationReadout()` | quantities; keep |
| `esp/PriTracker.java:147-151` | `properties`, `hpUpdates`, `bindings`, `conflicts`, `nonPlayers` | `debugLine()` `:469-476` | `ESP_HP_BOUND` ← `bindings`; `ESP_BIND_CONFLICT` ← `conflicts`; `ESP_HP_NONPLAYER` ← `nonPlayers`; `properties`/`hpUpdates` are quantities |
| `esp/MatchRoster.java:41-42` | `joins`, `fromDeaths` | `debugLine()` `:66-68` | `ESP_NAME_BOUND` (unwired) — split as `_JOIN` / `_KILL` |
| `decode/body/VehicleSync.java:100-102` | `opVarintReads`, `rejected` | `EspEngine.ownSourceLine()` `:2243-2244` | `ESP_VEHICLE_OP_VARINT` (unwired) / `ESP_VEHICLE_PARSE_REFUSED` (wired — but see §4.2, the two populations differ) |
| `decode/body/BodyDecoderText.java:57-61` | `exactCount`, `residueCount`, `noLayoutCount`, `unreadableCount`, `failureCount` | `coverage()` `:84-97`, `resetCounters()` `:75` | `DEC_BODY_EXACT` / `_RESIDUE` / `_NOLAYOUT` / `_UNREADABLE` / `_THREW`. **The best-designed counters in scope** |
| `protocol/VisibilityMask.noteStreamedWhileHidden()` | called from `esp/EspEngine.java:1180` | that package | out of scope, but note the call site is in `esp/` |

Two of these are reported *only* inside a formatted HUD string — `teamLine()`
(`:1767-1788`) and `PriTracker.debugLine()` — which means they are visible on a
phone screen and nowhere in a dump. `docs/CS_MODE_ESP_FAILURE.md` §7.5 makes this
exact point: *"A reset counter climbing at 10/s on the HUD would have made this
visible in seconds."* `ESP_MATCH_RESET` now exists (`:1727`) and is alarmed
(`Invariants:78`); the rest of the HUD-only numbers still are not.

---

## 6. Invariants worth alarming on

Four rules already exist that touch this scope: `RESET_LOOP`, `CLASSIFIER_BLIND`,
`NO_AUTHORITATIVE_TEAM`, `DECRYPT_FAILING` (`diag/Invariants.java:78, 106, 115,
136`). The following are the gaps, each with its number's provenance.

### 6.1 Chain parse health — **the most valuable missing rule**

```
ESP_CHAIN_PARSE_STRUCTURED / (STRUCTURED + FALLBACK) < 0.90   for a window with > 50 chain packets
```

*Provenance:* the structural parse measures **99.77-100 %** across ten sessions
(`esp/EspEngine.java:973`). It fell to **59.4 %** (session 205046), **50.0 %**
(204856) and **85.9 %** (192806) purely as a side effect of the CS reset loop, and
recovered to 96.3 / 99.7 / 97.2 % when that was fixed
(`docs/CS_MODE_ESP_FAILURE.md` §7.4). 90 % is comfortably below every healthy
session and above every broken one. **This number is a leading indicator for
failures that have nothing to do with chain parsing**, which is what makes it
worth alarming on.

### 6.2 Entity count against expected roster size

```
distinct ids with a chain update in the window, versus mode:
  Clash Squad  expect 8   — alarm below 5
  BR squad     expect 4 continuous + interest-managed others — alarm below 4
```

*Provenance:* `docs/FRIEND_FOE_AUTHORITATIVE.md` §1.3 — in the measured BR match
**exactly four entities stream continuously for the whole match (12, 37, 44, 51)**
at 4.54-5.11 Hz, and Clash Squad "replicates all eight players every tick in a
rigid cadence" (`docs/CS_MODE_ESP_FAILURE.md` §0). Fewer than four continuous
streams in BR means the parser is losing records, not that players died —
a dead player stops streaming but `MatchRoster`/Cmd 118 still name them.

### 6.3 The 198 ms chain tick

```
ESP_CHAIN_PKT rate < 2.5/s over a 10 s window while TUNNEL_PKT_IN is healthy
```

*Provenance:* the tick is **198 ms, IQR 2 ms, 75 % of all gaps in a single 25 ms
bin, median 198 ms at every concurrency level from 1 to 8 entities**
(`esp/EspEngine.java:262-270`). Even the sparsest BR stream delivers ~5 chain
packets/s. Half that is not a slow network — it is a gate upstream, and the 38 B
floor incident is exactly what this catches (2 685/3 131 updates lost, median
per-session loss 100 %).

### 6.4 The mask never validating

```
ESP_MASK_WEAK > 3 with ESP_MASK_VALID == 0
```

*Provenance:* `evaluateMask` (`:650-670`) needs a 90 % mode on all six bytes over
96 samples. `EspRenderView:1011` bails the whole overlay on `!maskReady()`, and the
HUD prints `"ESP LEARN (n)"` (`:2274`) — a *progress* message for a *terminal*
state. Three consecutive failed evaluations is 288 input packets ≈ 30 s of play.

### 6.5 Own-state age against the renderer's bail

```
ESP_OWN_FROM_2001 + _2069 + _2002 + _ECHO == 0 in a window where ESP_CHAIN_PKT > 0
```

*Provenance:* the renderer gives up at **2 000 ms** (`Invariants.OWN_STALE_MS:48`,
`EspRenderView:1016`). Cmd 2001 arrives every 99 ms and the self-echo every 198 ms,
so a window with live chain traffic and *no* own-state arrival from any of the four
sources means every source stopped — which is the mounted blackout, and is
distinguishable from "not in a match" by the chain packets still flowing. This is
the rule that would have caught the `OrientationProvider.Full` bug in §3.10.

### 6.6 HP bound for fewer than N visible entities

```
ESP_HP_BOUND / (ESP_HP_BOUND + ESP_HP_UNBOUND + ESP_HP_NO_VALUE) < 0.80
  over a window with > 200 lookups
```

*Provenance:* `docs/ESP_HEALTH_AND_NAMES.md` §2b — with the shipped ±350 ms
both-halves equipment join, **43 of 51 bound players report HP (84 %)** and
**99.4 % of entity position samples (22 574 / 22 711) belong to an id we have
health for**. 80 % sits just below the measured floor. Splitting `UNBOUND` from
`NO_VALUE` says whether to chase the join or the Cmd 1900 channel.

### 6.7 Roster coverage at match start

```
ESP_NAME_BOUND < 0.60 x (distinct chain ids seen) 30 s after ESP_MATCH_RESET
```

*Provenance:* `docs/ESP_HEALTH_AND_NAMES.md` §4 — the pre-key window costs **224
inbound packets in one second decoding as `cmd = -1`**, leaving Cmd 101 naming 25
of 53 players and 107/139 recovering 17 more: **42/53 = 79 %**. Below 60 % means
worse than the known-bad baseline. This is also the invariant that would show the
pre-key fix working when it lands.

### 6.8 Damage correlation, with its healthy range stated

```
no alarm — but ESP_DMG_CORR_HIT / (HIT + MISS) has a documented healthy band of
0.05-0.15
```

*Provenance:* **only 8.5 % of HP drops correlate** with a Cmd 2010 event, because
we only receive damage events for fights involving us — 22 distinct victims against
270 owners with health (`docs/ESP_HEALTH_AND_NAMES.md` §2c). A 91.5 % miss rate is
*correct*. This is the clearest example of a counter that is useless, or actively
misleading, without its range written down.

---

## 7. Bails that are correct and should stay silent

Listed explicitly so nobody adds a counter to them later and buries the real signal.

| file:line | why it should stay silent |
|---|---|
| `esp/EspEngine.java:638` | `maskLocked` — the mask is solved; short-circuiting is the point |
| `esp/EspEngine.java:1035-1037` | the record splitter's inner scan; fires many times per packet by construction |
| `esp/EspEngine.java:1128` | `t == null` immediately after `updateTrack` inserted it — unreachable |
| `esp/EspEngine.java:1290` | a real velocity measurement outranking a seed |
| `esp/EspEngine.java:2079-2106` | `extrapolatedDir`'s seven `return false`s — every one fills `out` with the raw direction first, so the caller proceeds identically. Not a failure, a no-op |
| `esp/EspEngine.java:2033, 2037, 2047` | `camAngVelValid = false` on a camera cut or an out-of-band gap — refusing to extrapolate through a cut is the correct answer |
| `esp/MatchRoster.java:110` | `names.containsKey(slot)` — the join already named them |
| `esp/MatchRoster.java:136` | `squad > 0` — squad 0 is genuinely "unassigned" |
| `esp/PriTracker.java:414, 416` | owner unknown / binding already settled |
| `decode/body/Cmd.java:259`, `decode/body/CmdCatalogue.java:89`, `decode/frame/SendOption.java:50` | `UNKNOWN`/null for an uncatalogued id — the catalogue is explicitly open and the fallbacks are designed |
| `decode/frame/HeaderLayout.java:97, 103` | `-1` for an absent field; only `ORDER_ID` can be absent and `PacketCodec:49` handles it |
| `decode/frame/HeaderLayout.java:55`, `decode/body/BodyDecoderRegistry.java:48, 56` | these **throw**. Already loud; leave them |

---

## 8. Hot-path summary

| path | frequency | rule |
|---|---|---|
| `classify()` | per entity per chain packet — **~40-50/s** in CS (8 entities x 5 Hz), ~25-50/s in BR | `counter` only. Never `event`, never a String |
| `parseStructured()` | per chain packet — ~5-10/s | `counter`; the six refusal reasons want six slots, not six events |
| `updateTrack` / `updateVelocity` | per entity per packet — as `classify()` | `counter` only |
| `observeKeepalive` | 10 Hz | `counter`; the `:718`/`:726` identity rejections may be `event` because they should never fire |
| `observeChainPacket` entry gates | full inbound packet rate | count the **entry** once (`ESP_CHAIN_PKT`); derive rejections as a ratio. Do not count each gate |
| `observeDamage` / `observeHandleEvent` gates | offered on every inbound packet in a length window | one refusal counter for the shape gates, individual counters only for the semantically interesting ones (`:1604`, `:1611`) |
| `BodyCrypt.decrypt` | per reliable packet | `counter`, except the `Throwable` catch, which is an `event` because it must be zero |
| `OrientationProvider.update` | **120 Hz** (render thread) | `counter` only — except the `ownLastUpdateMs` bail, which deserves one `event` the first time it fires per mount |
| `PriTracker.hpFor` | per entity per frame — **~120 x entities/s**, the highest-rate site in scope | `counter`, and hit **once per frame**, not once per lookup, or it dominates every dump |

**Flagged as expected-and-high-volume, needing a documented healthy range or they
are noise:**

1. `ESP_VEL_DROPOUT` (`EspEngine:1258`) — normal for most non-squad BR entities;
   healthy up to ~60 % of samples in BR, ~0 % in Clash Squad.
2. `ESP_DMG_CORR_MISS` (`PriTracker:402`) — healthy **miss** rate is ~91.5 %.
3. `ESP_CHAIN_PKT` rejection ratio (`EspEngine:891`) — most inbound traffic is
   legitimately not a chain; only the ratio to `TUNNEL_PKT_IN` is meaningful.
4. `ESP_NOTETEAM_WEAKER_SRC` (`EspEngine:1688`) — precedence working as designed;
   a high value is *good*, it means Cmd 118 is landing first.
5. `ESP_HP_NONPLAYER` (`PriTracker:206`) — a capture carries 181 non-player binds
   against 28 player ones, so a 6:1 ratio is healthy.

---

## 9. Corrections to existing documentation, found while reading

* `docs/FRIEND_FOE_AUTHORITATIVE.md` §2.5 says `MatchRoster.squad()` has **0
  callers**. It is now called from `esp/EspEngine.java:1377`. Same for
  `PriTracker`'s squad byte (§1.6(e)): `slotSquad` is populated at `PriTracker:355`
  and read at `EspEngine:1373`.
* §1.6(b)'s `1..63` own-team bound is fixed — `isValidTeam` is `1..254`
  (`EspEngine:481-483`) and is used at `:726`.
* §1.6(c)'s "nothing rejects team 255" is fixed — same predicate, used in
  `noteTeam:1681`.
* §1.6(a)'s `resetMatch` gap is fixed — `:1711-1720` clears `ownTeam`,
  `ownEntityId`, `matchHandle` and records `lastMatchResetMs`.
* `docs/CS_MODE_ESP_FAILURE.md`'s root cause is fixed — `EspEngine:944-946` now
  guards `isValidTeam(ownTeam) && ownEntityId > 0` before packing the handle.
* **§1.6(d) is NOT fixed.** `observeDamage`'s `0xBF` ceiling is still at
  `EspEngine:1604` and still disagrees with `observeHandleEvent:1577`.
* **The `ownLastUpdateMs` reader bug is NOT fully fixed.** `EspRenderView:1016`
  was corrected to `ownStateMs()`; `esp/OrientationProvider.java:76` still reads
  `ownLastUpdateMs()`. See §3.10.
