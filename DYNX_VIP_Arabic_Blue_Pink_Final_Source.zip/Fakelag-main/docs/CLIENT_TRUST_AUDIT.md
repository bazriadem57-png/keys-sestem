# Client-trust audit — where the server accepts what we send

**Question:** which outbound (client→server) in-match messages carry fields the server
does **not** validate?

**Scope:** in-match RUDP only — Battle Royale / survival and Clash Squad. The lobby TCP
protobuf channel (`proto.*Req`/`proto.*Res`), the store, account and social surfaces are
excluded entirely.

**Answer, up front:**

> Of the **264 in-match outbound message ids** on the true outbound surface, exactly
> **one** puts a client-computed *magnitude* on the wire without an integrity token:
> **Cmd 382 `RUDP_TAKE_HEALING`**. Everything else that could matter names an **id** and
> lets the server look the value up, or is covered by the anti-cheat blob, or is a
> report the server can recompute for itself. Five messages carry an integrity token and
> are out of reach by project decision. **No second client-authoritative combat lever was
> found.** The already-known result (hits are client-authoritative, Cmd 106) remains the
> only one of its kind, and 106 is exactly the message the anti-cheat signs.

Written 2026-09-12. Companion artifacts:
`tools/il2cpp/ff_trust_audit.json` (every in-scope id, classified, with evidence) and
`tools/il2cpp/ff_outbound_registry_full.txt` (§1.1 — the corrected send-site registry).

This file is deliberately narrow: it answers *what is trusted*. For the enforcement
machinery see `docs/SERVER_VALIDATION_MODEL.md`, for manipulation candidates see
`docs/CLIENT_AUTH_SURFACE.md`. **§8 lists three places where this audit corrects those
documents or `IL2CPP_FINDINGS.md`.**

---

## 1. Method

1. Re-derive the outbound surface from `FF-RE/bin/libil2cpp_dec.so` by scanning every
   branch into `COW.GameFacade::Send` @ `0x075488ac`, recovering the msgid with
   `il2cpp_scan.regimm(site, w0)` and the message class from the nearest preceding
   `bl message.X::.ctor` in the same function.
2. Filter to in-match BR/CS gameplay by the game's own command names and by the sending
   `Type::Method` (the `COW.GamePlay.*` method names survived obfuscation).
3. For each survivor, read the field layout, then decide what each field *means* — from
   `COW.GamePlay` parameter names, from enum member names, from the shipped
   de-obfuscation table, and where those failed, by disassembling the sender.
4. Decide what the server validates, from (in descending strength): a server correction
   or rejection message for the same state; a client-side mirror of the rule; the
   absence of the quantity from the wire; measured wire behaviour.
5. Classify into exactly one of SERVER-VALIDATED / CLIENT-TRUSTED / ANTI-CHEAT PROTECTED
   / UNKNOWN.

### 1.1 The committed registry was 37 % incomplete — fix this first

`tools/il2cpp/ff_outbound_registry.txt` scanned only `BL` instructions. **270 of the 731
`GameFacade::Send` call sites reach it by a tail-call `B`** (the compiler turns
`Send(...); return;` into a branch), and those were invisible.

| | committed registry | this audit |
|---|---|---|
| `GameFacade::Send` sites | 461 | **731** (461 `BL` + 270 tail-call `B`) |
| distinct msgids | 307 | **475** |
| msgids reachable ONLY via a tail call | — | **168** |
| classes resolved | 288 of 308 | **727 of 731 sites** |

This is the same class of error as Trap 1 in `IL2CPP_FINDINGS.md` §0 (which cost 21 % of
the surface) and it compounds with it. In-match ids that were entirely missing include
**2016 `UDP_SYNC_AIM_ROTATION`**, **278 `RUDP_AIM_TARGET_CHANGE`**,
**203 `RUDP_DOOR_TAKE_DAMAGE`**, **1347 `RUDP_Take_Damge_DynamicCollider`**,
**392 `RUDP_REQUESTREVIVEWITHLOCATION`**, **1036 `RUDP_C2S_FRIENDOB_DATA_CHECK`**,
**1672 `RUDP_C2S_SecStart`**, **1245 `RUDP_C2S_COLLIDER_INVALID_ROUND`**,
**1206 `RUDP_START_ACTIVE_SKILL_CHARGE`**, **1706/1707 `RUDP_CARRY_PLAYER`/`RELEASE_CARRY`**,
**109 `RUDP_OPEN_DOOR`**, **282 `RUDP_SPAWN_OBJECT`**, **827/830** (jump pad, hand catapult),
**557 `RUDP_C2S_OPEN_WEAPONBOX`**, **2008 `UDP_VEHICLE_MACHINEGUN_SYNC`**.

**Two of those five anti-cheat-signed messages (1036, 1672) were invisible to the old
scan.** Any future census must scan `B` as well as `BL`.

The corrected registry is committed as `tools/il2cpp/ff_outbound_registry_full.txt`
(same columns plus a `BL`/`B` kind flag). The old file is left untouched — four agents
are coding against it right now.

### 1.2 The filtered in-match surface

| | msgids | send sites |
|---|---|---|
| total outbound surface | 475 | 731 |
| excluded as out of scope | 212 | 342 |
| **in-match BR / Clash Squad** | **264** | **389** |

Exclusions, by reason (all listed individually in `ff_trust_audit.json` → `excluded`):

| n | reason |
|---|---|
| 50 | seasonal event / side mode hosted inside a BR match (Ramadan, Winterland, Seafood, Dreamland, IIV, NB, Bloodmoon, Astrol Gate, SAP, Escort …) |
| 34 | meta / loadout / out-of-combat economy UI (presets, weapon awaken/upgrade, lucky-draw box, personal shop, bounty box …) |
| 28 | chrome — chat, HUD settings, camera mode, lifecycle, feedback |
| 23 | UGC runtime or editor |
| 21 | cosmetic — emotes, dances, animation triggers, wardrobe |
| 18 | spectator / observer / vertical-view camera |
| 17 | Training Ground and tutorial only |
| 8 | Werewolves party mode |
| 7 | Football / GB_GP party mode |
| 6 | other competitive modes (TDM-like, Control, ArmsRace, Infection, Zombie+, CSSO) |
| 5 | social lobby / subgame lobby |
| 5 | miscellaneous (voice moderation, unrecoverable msgid) |

Of the 264 in-scope ids, **97 are bidirectional** (the server relays the same id back) and
**167 are outbound-only** — the client asserts and the server announces the outcome under
a different id (106 → 2010, 382 → 2013, and so on).

---

## 2. The anti-cheat coverage map

`GFHPFJMGEKF::AKFFMELHGIJ` is the integrity checksum and is **not analysed here** — per
the standing project decision, the only question asked was *which messages it covers*, so
that findings under it can be set aside.

Complete scan of all 731 send sites plus every `BL`/`B` edge into `GCommon.Checker.*` and
`ffantihack.*`. Inside `COW.GamePlay.*`, **exactly five outbound messages carry an
integrity token**:

| Cmd | Name | Token | Where it is attached |
|---|---|---|---|
| **106** | `RUDP_TAKE_DAMAGE` | `List<byte> FHBHMKMHCHJ` @ `MMJPICCOJOM+0x68` | `PlayerNetwork::TakeDamage`, stored at `0736f9a8`; fed by `MFHPGMELLCC::DHMENGFJMII` (`0736f820`, rate-gated) **or** the `GFHPFJMGEKF::AKFFMELHGIJ` → `EJJLOHDHCPJ` chain (`0736f8d8`/`0736f9a0`) |
| **104** | `RUDP_START_FIRE` | `List<byte> DOBMKBAFODF` @ `PHLCCJAAHIH+0x28` | `PlayerNetwork::StartFiring` @ `073705b4` → `PCNABJAFBDO::PCHKNAGPNID` |
| **3039** | `RUDP_SYNC_WHOLE_BODY_FIRE` | `List<byte> DOBMKBAFODF` @ `FPIHHNBBFDG+0x30` | `PlayerNetwork::StartWholeBodyFiring`, same helper |
| **1036** | `RUDP_C2S_FRIENDOB_DATA_CHECK` | **two** `List<byte>` + tick + `realtimeSinceStartup` | `FFMOIGKIEPE::KJGJJINLGAE` @ `07aaf1d0` and `07aaf204` — a dedicated anti-hack heartbeat |
| **1672** | `RUDP_C2S_SecStart` | `List<byte> KGAIBJFMLOB` | `MCDLKHAOJJG::MEGEKNJBMCM` — a session-start attestation |

Everything else in the in-match set is **unsigned**. In particular:

- **Outbound 2001 carries no token** — independently re-confirmed here: `PNCPKGJGBPP`
  appears nowhere in the anti-cheat caller set.
- **The damage-claim class `MMJPICCOJOM` is reused by eleven other ids and only Cmd 106
  gets the blob.** `Vehicle::TakeDamage`, `LevelUAV::TakeDamage`, `IceWall::TakeDamage`,
  `Landmine::TakeDamage`, `LevelDoor::TakeDamage`, `SantinoDummy::TakeDamage` and the 18
  `::TakeDamage` overrides behind Cmd 394 are **not** in the anti-cheat caller list, so
  their `FHBHMKMHCHJ` is null on the wire.
- The `104`/`3039` token is a **standalone attestation, not a per-message MAC**:
  `PCHKNAGPNID` is called with `x0 = xzr` and receives no field of the message. It is also
  **one-shot** — `PlayerNetwork::StartFiring` `0x0737058c` tests a flag and, once set,
  stores `null` into the field instead.
- Cmd 106's checksum argument is **`msg->DNNFOOGPFHO`, the simulation tick** — see §8.2.

**Classification consequence:** 106, 104, 3039, 1036 and 1672 are `ANTI-CHEAT PROTECTED`
and this audit stops there.

### 2.1 The 45 `Cheating_*` detections are CLIENT-side, and they are visible on the wire

`COW.GamePlay.AKHFIKBPKFM` is a damage-source / death-reason enum. Its negative range
`-1…-53` is environmental (`Burning = -10`, `FloaterCannon = -45`, `IceWallModule = -46`
— exactly the negative weapon ids `IL2CPP_FINDINGS.md` §5.3 saw on the wire), and
`-100…-156` is a block of 45 `Cheating_*` members.

Scanning the image for `MOVN Wd, #imm` with those immediates puts every one of them in a
handful of **client-side per-frame checks**:

| function | detections materialised there |
|---|---|
| `COW.GamePlay.Player::PostUpdate` | SkinWidth, StepOffset, CharacterCenter, AvatarScale, CameraHack, AimAssist, NoScatter ×2, FallHigh, InWaterHack, JetPackHack, AutoFire, Sniper, FastRunHack, ScaleMapHack, StreamerHack_SkateBoard ×2 |
| `COW.GamePlay.GAJPGHGIIIK::OnUpdate` | CharacterCCT, HipsBoneNotRight, InvalidLossyScale, GameVar, SkillDataHack, WallHack, CameraHackRuntime |
| `COW.GamePlay.PNCPKGJGBPP::NKMLFBMDDMI` | HackTargetPlayer, StreamerHack, StreamerHack_LoadingRange, StreamerHack_Active |
| `COW.GamePlay.Player::OnUpdate` | CatapultHack, CannonHack |
| `COW.GamePlay.FDAEPHMIEPC::IBEJJIDOLMH` | AimAssist, NoScatter |
| `COW.GamePlay.LevelIceWall::LPIBEMOKAFA` | HackerIceWallName |
| `COW.GamePlay.SkateboardControllerBase::Jump` | SkateboardJump |

Every one of them loads the code into **`w4`** and calls the same virtual. Reading one
(`0x070dc880`–`0x070dc8dc`, `Cheating_NoScatter`):

```asm
070dc8c8  mov  w1, #0x2710          ; damage = 10000
070dc8cc  mov  w4, #-0x7a           ; weaponId = -122 = Cheating_NoScatter
070dc8b0  fmov s0..s5, wzr          ; hitPoint = hitDir = Vector3.zero
070dc8dc  blr  x10                  ; AttackableEntity::TakeDamage(...)
```

matched against the surviving signature
`TakeDamage(int damage, BHGGAEEHJCO attacker, GLLLEDKLLDA, int weaponId = -1, Vector3 hitPoint, Vector3 hitDir, List<float> checkParams, …)`.

**The client kills itself for 10 000 and tells the server why, through an ordinary
outbound Cmd 106 whose `int EJJFPFENMBP` (@`+0x24`) is the cheat code.** Three
consequences:

1. It confirms `EJJFPFENMBP` = `weaponDataID` in `MMJPICCOJOM` (and that the field is
   signed `int` precisely so it can carry these codes).
2. **None of these checks reads a packet.** They read the local Unity transform, camera,
   character controller, weapon scatter and PhysX state. A VPN that rewrites bytes in
   flight cannot trip any of them directly — which is why ghost and teleport have never
   produced one.
3. **It is a free tripwire for the dumper.** Any outbound Cmd 106 with
   `EJJFPFENMBP ∈ [-156, -100]` means the client has just self-flagged. That is worth a
   loud annotation in the capture, and `1245 RUDP_C2S_COLLIDER_INVALID_ROUND` is the same
   family. Neither should ever be suppressed.

---

## 3. What the server *does* validate — the evidence

### 3.1 Position: SERVER-VALIDATED, and the correction packet is now identified

`docs/TELEPORT.md` §2 records "No server correction packet was identified … Any
correction lives in the encrypted 10+8k channel." **It does not.** It is a plain RUDP
message:

- **Inbound Cmd 144 `RUDP_FORCE_SYNC_PLAYER_STATE`**, class `message.PGABPEBFLOK`, 13
  fields: `uint handle`, `uint`, **`PMFGOGFPDHM` position (millimetres)**, two
  `BDOPLCJODBN` rotation triples, two pose bytes, a `ushort`, three `bool`, an `int`, and
  `uint DNNFOOGPFHO` (the tick).
- Handler `FFMOIGKIEPE::BMJPKGGDEIB` @ `07a42b2c` → `PlayerNetwork::SyncStateWithServer`,
  which at `07368128` decodes the position through `message.KANJBNIANHC::GOEODCJNMPF`,
  then the rotation at `+0x40` and the pose byte at `+0x38`, and applies them.
- The very first thing `SyncStateWithServer` does (`073680c4`) is call
  `PlayerNetwork::NotifyServerGotForceSyncState`, which sends **outbound Cmd 146
  `RUDP_CONFIRM_SERVERFORCE_SYNC_PLAYER_STATE`** = `{handle, PNCPKGJGBPP::BJNKBGDPBAC(), uint}`
  reliably (`07367f8c`).

So the round trip is complete in code: **server pushes 144 → client applies → client acks
with 146.** That is the 399–402 ms snap-back `TELEPORT.md` measured, and the acceptance
threshold it measured (largest accepted jump **2.77 m**, smallest rejected **5.31 m**,
n = 52, p ≈ 4.5e-5) is the gate.

Siblings, all inbound, all the same pattern: **129** vehicle, **1370** moving platform,
**1406** scout (which also has an outbound sender), **470** vehicle ack, **1157** cannon
ack, **3583** server-authorized PhysX state.

**Verdict: position, velocity, pose and vehicle state are SERVER-VALIDATED.** The client
is trusted *within a tolerance band*, which is exactly what the teleport design already
exploits. Nothing new is available here.

### 3.2 Inventory, ammo and economy: SERVER-VALIDATED by absence

The Clash Squad shop reasoning (`IL2CPP_FINDINGS.md` §7.3 — "there is no price field, so
there is nothing to forge") generalises across the whole in-match economy. Checked
field-by-field:

| Cmd | Name | what is on the wire | what is **not** |
|---|---|---|---|
| 111 | `RUDP_PICKUP_INVENTORY` | `List<uint>` item ids + bools | any count |
| 113 | `RUDP_USE_INVENTORY` | 3 × uint id | any effect magnitude |
| 119/120 | `RUDP_EQUIP`/`UNEQUIP` | slot byte + `List<uint>` ids | durability |
| 217 | `PICKUP_INVENTORY_CHECK_TIME` | `List<uint>` ids + flags | count |
| **259** | `RUDP_FULL_AMMO` | `{handle, ushort ammoBoxId, float}` — `LevelAmmoBox::DoAction` @ `075aa900` puts the **box's own id** (`LevelAmmoBox+0xCC`) on the wire | **no ammo amount** |
| 358 | `RUDP_FULL_EQUIP` | one `ushort` | everything else |
| 413 | `RUDP_PURCHASE_CSITEMS` | context id + `List<uint>` item ids + buy-type enum | price, token balance |
| 607/608 | ask/pay-for-other | `List<uint>` ids (+ target) | price |
| 1000 | `RUDP_WEAPON_UPGRADE_REQ` | one `uint` | level, cost |

And the server can refuse outright: **inbound Cmd 853 `RUDP_S2C_USE_INVENTORY_FAIL`**
(`{uint, uint}`) and **823 `RUDP_USE_ACTIVE_SKILL_FAIL`**. All the quantities travel the
other way, in Cmd 1900 `RUDP_VAR_SYNC_PRI_DATA` EPRI vars, which is server→client only
(`docs/COMBAT_AND_HEALTH.md` §1).

**Verdict: SERVER-VALIDATED. There is no amount to over-claim anywhere in the in-match
economy.** This is a negative result and it is a solid one.

### 3.3 The hit claim already carries scrambled validation data

Cmd 106 (and the whole `MMJPICCOJOM` family, and Cmd 382) carries
`List<float> MPECMNGCKJN` — the `checkParams` argument of `TakeDamage`/`TakeHealing`,
named `LFLPGCMLPFM` in the surviving signature.

Before the send, `FDAEPHMIEPC::KOODEKEKFEK` @ `074e0c30` calls
`FDAEPHMIEPC::IJBAPAJAINA(list, seed)` → `ICALGMBOIBD::IJBAPAJAINA` @ `078bf848`, which
copies the list into parallel `int[]`/`float[]` arrays and **applies a keyed permutation**
driven by `ICALGMBOIBD::OCKMOCGKDAL` off `seed XOR 0xA3B1C6D9`, then writes the floats back
permuted. The seed is `BHGGAEEHJCO::LMCLIKOCCJM(victim PlayerID)` and the call is gated on
the victim being on another team (`BHGGAEEHJCO::DDPFMJDFEDJ` team compare at `074e0bd0`).

You do not scramble a field the receiver ignores. **The presence of a keyed-permuted
`List<float>` on every enemy hit claim is direct evidence that the server checks the
claim's parameters**, independently of the integrity blob. The contents were not pursued
further — that is anti-tamper territory.

### 3.4 Aim: CLIENT-TRUSTED but inert (and there is a second carrier)

Three aim vectors go out: outbound 2001 `v3–v5` (body facing) and `v13–v15`
(`GetAuxAimRotation`), plus — new here — **Cmd 2016 `UDP_SYNC_AIM_ROTATION`**
(`{BDOPLCJODBN euler, uint}`, unreliable) and **Cmd 278 `RUDP_AIM_TARGET_CHANGE`**
(`{byte, uint targetId}`).

The server accepts all of them; none of them decides anything. `IL2CPP_FINDINGS.md` §1
established why: the client raycasts, resolves the collider owner and the body part, and
hands over a finished claim, so the reported aim is presentation only. The project's own
30° aim-bias experiment (`net/AimBiasExperiment.java`) returned a clean null.

**Verdict: CLIENT-TRUSTED, payoff already measured at zero.** Recorded so nobody spends
another cycle on it — including on 2016 and 278, which were not previously known.

---

## 4. The one finding: Cmd 382 `RUDP_TAKE_HEALING`

**This is the only in-match message found that puts a client-computed magnitude on the
wire with no integrity token.**

Class `message.ECLNOMOGOFC`, sent reliably (`w2=2`) from
`COW.GamePlay.PlayerNetwork::TakeHealing` @ `0737006c`:

| off | type | name | meaning |
|---|---|---|---|
| 0x14 | uint | `AAFDKHICFDF` | target handle (`LMCLIKOCCJM(this.PlayerID)`) |
| **0x18** | **uint** | **`AKGPIAMBLHI`** | **the heal amount** |
| 0x1C | uint | `EACCGEMLNHJ` | second amount (healing-bullet path only) |
| 0x20 | uint | `OJKINJIPMHE` | healer handle |
| 0x24 | int | `EJJFPFENMBP` | source id (same field that carries the weapon / negative environment id in Cmd 106) |
| 0x28 | uint | `DNNFOOGPFHO` | simulation tick |
| 0x30 | `PMFGOGFPDHM` | `EPCMOGEBEKM` | point |
| 0x38 | `PMFGOGFPDHM` | `PHEOMEDPGED` | direction |
| 0x40 | `List<float>` | `MPECMNGCKJN` | checkParams |
| 0x48 | uint | `NKABLKJBDGM` | — |

**Evidence that the amount is client-computed:** the surviving signature is
`TakeHealing(DLOFHLEHHNP healInfo, List<float> checkParams)`, and `DLOFHLEHHNP` is a
plain client-side struct `{int AKECMLNMBEO; BHGGAEEHJCO AEBLLNMKKIC; int CBNGGHHMPHA;
Vector3 BAAJEMEJACH; Vector3 KHNFEFFKMEB; uint FKGPFHFDHKG;}`. At `0736ff28`:

```asm
0736ff28  ldrh w8, [x20, #0x10]    ; DLOFHLEHHNP.AKECMLNMBEO  = the amount
0736ff2c  str  wzr, [x21, #0x1c]
0736ff30  str  w8,  [x21, #0x18]   ; -> ECLNOMOGOFC.AKGPIAMBLHI
...
07370058  mov  w0, #0x17e          ; 382
0737006c  bl   COW.GameFacade::Send
```

**Evidence that it is unsigned:** the complete 731-site anti-cheat scan (§2) lists every
`COW.GamePlay.*` function that touches `GCommon.Checker.*` or `ffantihack.*`.
`PlayerNetwork::TakeHealing` is not among them, and `ECLNOMOGOFC` has no `List<byte>`
field at all. It is the structural twin of Cmd 106 — same handles, same tick, same two
`PMFGOGFPDHM` vectors, same `checkParams` — **minus the blob**.

**Why this is not yet a CLIENT-TRUSTED *result*.** The claim of this section is narrow and
should stay narrow: the client computes the number and sends it unsigned. Whether the
*server* accepts it is not decidable from the client, because HP is server-owned and
server-announced — `EPRI_PLAYER_CUR_HP` (Cmd 1900 var 0, CONFIRMED n=20 against HUD
screenshots) and the inbound broadcast **Cmd 2013 `UDP_PLAYER_HEAL`**, which is the exact
mirror of 2010 `UDP_PLAYER_HURT`. The server may well recompute from the item id named in
the preceding Cmd 113 and ignore ours.

**Mechanism:** REWRITE IN PLACE, in a 382 the client already sends. No injection. The
message only exists when the player genuinely heals, so the reachable manipulation is
"change the size of a heal that is already happening", nothing more.

**The experiment that settles it, in one line:** rewrite `AKGPIAMBLHI` once in a live
match and read `EPRI_PLAYER_CUR_HP` out of the next Cmd 1900 plus the inbound Cmd 2013.
If HP follows the claim → CLIENT-TRUSTED. If HP follows the med-kit's table value →
SERVER-VALIDATED and the audit closes with a clean negative.

Recorded as `CLIENT-TRUSTED` in the JSON because the *client-side* half of the claim is
proven; the evidence string states the remaining uncertainty explicitly.

---

## 5. Classification summary

Full per-message detail is in `tools/il2cpp/ff_trust_audit.json`.

| classification | n | what it means here |
|---|---|---|
| SERVER-VALIDATED | 201 | the server corrects it, rejects it, or owns the quantity outright |
| UNKNOWN | 52 | could not be decided from the client; each carries a named experiment |
| CLIENT-TRUSTED | 6 | the server accepts it — but see the column below |
| ANTI-CHEAT PROTECTED | 5 | 106, 104, 3039, 1036, 1672 |

### The CLIENT-TRUSTED six, ranked

| Cmd | Name | Worth | Mechanism |
|---|---|---|---|
| **382** | `RUDP_TAKE_HEALING` | **the only one with a magnitude on the wire** — §4 | REWRITE IN PLACE |
| 2016 | `UDP_SYNC_AIM_ROTATION` | zero — reported pose, inert (§3.4) | rewrite / drop (unreliable) |
| 278 | `RUDP_AIM_TARGET_CHANGE` | zero — inert (§3.4) | rewrite |
| 737 | `RUDP_C2S_NOT_HIGH_PING` | zero — **no serialised fields**; the server measures RTT itself from the 0.5 Hz ping/pong (852/852 byte-exact echoes) | none |
| 1557 | `RUDP_C2S_HighlightInStealth` | zero — no fields | none |
| 1245 | `RUDP_C2S_COLLIDER_INVALID_ROUND` | **do not touch** — a client anti-cheat self-report (§2.1) | none |

Plus one field, not a message: **outbound 2001 `v18`, the client-asserted RTT**. It is
unsigned and the server accepts it, but `docs/COMBAT_AND_HEALTH.md` §9 shows `v18` and the
true RTT are collinear to ±4 ms in every capture, so desynchronising them creates a
signature absent from all 18 600 real packets. Trusted, and not worth using.

### The UNKNOWN 52 — the two groups that matter

**(a) Unsigned damage claims against non-player objects** — 127 vehicle, 166 UAV, 203 door,
222 ice wall, 240 landmine, 340 weapon shield, 394 level object (24 send sites), 865
dummy, 1008 knock-down shield, 1197 ice destructible, 1347 dynamic collider.

Same `GMNGCBJMDLB` (`damage | zone<<24`) composite as Cmd 106, same `checkParams`, **no
blob**. Arguing for server validation: every one of these object types has a dedicated
server→client resync id — 223 `RESYNC_ICEWALL`, 239 `LANDMINE_RESYNC`,
339 `RESYNC_WEAPONSHIELD`, 495 `RESYNC_PHYXSHIELD`, 662 `RESYNC_TRAMPLE`,
666 `RESYNC_DROP`, 829 `JUMPPAD_RESYNC`. *Experiment:* rewrite the low 24 bits of
`GMNGCBJMDLB` in one outbound 222 or 394 and watch for the matching resync id inside
~400 ms. Note these target **objects, not players** — the project's standing boundary on
fabricating damage against other players is not engaged, and is not being extended.

**(b) Client-chosen world positions on spawn/use** — 160/1220 projectile throw,
218 missile fire, 221/335 ice wall, 282 spawn object, 286 grappling hook, 293 paint
sprayer, 467 vehicle reset, 756 find path, 775 balloon gun, 821 heat gun, 827 jump pad,
830 hand catapult, 847 telescope, **988 add teleport door (two positions + two rotations)**,
1267 safe-zone point, 1458 route marker, 1491 bomber maker, 1504 mount grenade, 3048
swing spider, 3072/3073 phase fire data.

The client names a `PMFGOGFPDHM` in millimetres and the server spawns something there.
Whether it range-checks against the player's own position is undecidable from the client:
the named rules exist (`Cheating_InvalidFirePos = -115`,
`Cheating_InvalidFireHitPos = -116`) but are evaluated client-side (§2.1). *Experiment:*
rewrite `MOEFFAIDCBP` in one outbound 160 or 988 and read the resulting object's position
off the server's broadcast.

**(c) Two reload floats** — 133 `RUDP_START_RELOAD` carries
`float APPGBFLNEBF` = the reload duration the client computed
(`SendStartReload(float ABPKDCKICLA, bool)`), and 1659 `RUDP_ChangeReLoadSpeed` puts the
speed on the wire directly (`OnWeaponReloadSpeedChanged` @ `073701a8`, `str s8, [x20,#0x18]`).
`Cheating_InvalidReloadSpeed = -119` names the rule; the check is client-side.

---

## 6. Negatives worth having on the record

1. **No second client-authoritative combat lever exists.** Every player-affecting damage
   path in the in-match set funnels through `MMJPICCOJOM`, and the only one aimed at a
   player (Cmd 106) is the one the anti-cheat signs. The names that looked promising do
   not survive contact: `657 RUDP_C2S_ClientHitFlyPlayer` fires only from level-script
   trigger volumes (`ClientHitFlyTrigger::OnTriggerEnter`), `550`/`549` are PVE energy
   ball, `543` is the auto-flight bomb, `1709 RUDP_CARRY_BATTLE_HIT` carries one uint,
   `3532 RUDP_C2S_ShopTokenGun_Hit` is the event token gun, and `1661` is football.
2. **The in-match economy has no forgeable quantity** (§3.2). `IL2CPP_FINDINGS.md` §7's
   conclusion for the Clash Squad shop is the general case, not a special one.
3. **No outbound message lets the client change what it is told about.** Confirming
   `IL2CPP_FINDINGS.md` §5.4 against the *complete* 731-site registry: ids 135/136/386/369
   still have no outbound sender, and nothing in the 168 newly-visible ids is an interest
   or visibility request.
4. **The shipped de-obfuscation table is nearly useless for the outbound protocol.**
   `IL2CPP_FINDINGS.md` §0 records as "unexploited" that a systematic pass over the
   outbound class list "would name a large slice of the protocol for free". It was run
   here: of **443 distinct field names** across the 288 outbound classes, the 1122-entry
   table resolves **9** (2.0 %) — `ItemID`, `VehicleID`, `LevelObjectID`, `HitBodyPart`,
   `ActionType`, `Faction`, `Type`, `SpawnPos`, `WeaponSkinID`. The productive levers are
   the surviving `COW.GamePlay` parameter names and reading the sender, as used throughout
   this document. **That item can be struck.**

---

## 7. Mechanism check

Every finding above is stated against the app's two proven-safe manipulations.

- §4 (Cmd 382) needs **REWRITE IN PLACE** only. The message already leaves the client
  whenever the player heals; nothing is injected and nothing is withheld.
- The UNKNOWN experiments in §5 are all rewrite-in-place of a field in a message the
  client already sends.
- **Nothing here requires injection.** Any candidate that would have needed a new reliable
  packet was discarded on sight — the sequence number the game's reliability layer never
  issued is what caused the mid-match kicks that took three iterations to eliminate.
- **Nothing here requires a drop.** Cmd 382, 106, 104 and the whole `RUDP_*` set are
  reliable (`GameFacade::Send` `w2=2`); withholding one owes the server an ack it never
  gets. The only unreliable in-match ids in the CLIENT-TRUSTED list are 2016 and 2001.
- Transport ids 1–99, the 0.5 Hz ping/pong pair and the ~1 Hz client probe are untouched
  by every recommendation.

---

## 8. Corrections to existing documents

### 8.1 `ff_outbound_registry.txt` is 37 % incomplete — §1.1

461 of 731 send sites, 307 of 475 msgids. `docs/CLIENT_AUTH_SURFACE.md` §7 calls its
appendix "the full in-match outbound census"; it was built on the short registry and is
missing 168 ids. Use `tools/il2cpp/ff_outbound_registry_full.txt`.

### 8.2 `AKFFMELHGIJ(0xA, 7, damage)` — the third argument is the TICK, not the damage

`IL2CPP_FINDINGS.md` §1 and `tools/il2cpp/ff_enforcement_map.json`
(`attestation_and_telemetry.value_attestation`) both record the call as
`AKFFMELHGIJ(0xA, 7, damage)`. Reading it:

```asm
0736f574  bl   COW.GameFacade::CurrentGameSimulationTimer
0736f57c  ldr  w8, [x0, #0x20]
0736f580  mov  x25, x21                 ; x21 = the MMJPICCOJOM
0736f588  str  w8, [x25, #0x30]!        ; x25 = msg + 0x30 = DNNFOOGPFHO (the tick)
...
0736f8ac  ldr  w23, [x25]               ; <-- reads msg+0x30, the TICK
0736f8c8  mov  w0, #0xa
0736f8cc  mov  w1, #7
0736f8d0  mov  w2, w23
0736f8d8  bl   GCommon.Checker.GFHPFJMGEKF::AKFFMELHGIJ
```

The damage lives in `GMNGCBJMDLB` at `+0x1c` (`0736f518`) and is never passed to the
Checker. This is stated as coverage information only; the checksum itself was not
analysed, per the standing decision.

### 8.3 The snap-back correction packet is inbound Cmd 144, confirmed in code

`docs/TELEPORT.md` §2 records that no correction packet was identified and places it in
the encrypted control channel. `ff_enforcement_map.json` promotes Cmd 144 to a
"candidate" on a 5-of-25 timing correlation. §3.1 closes it from the code: the class
carries a millimetre position, `PlayerNetwork::SyncStateWithServer` applies it, and the
client acks with outbound Cmd 146. Both documents can be updated.

### 8.4 Minor

- `ff_enforcement_map.json` → `attestation_and_telemetry.per_message_blob` lists four
  attachment sites and concludes "only four outbound sites carry it". That tracks
  `MFHPGMELLCC::DHMENGFJMII` only. Adding `PCNABJAFBDO::PCHKNAGPNID` brings the real
  coverage to **five outbound message ids** (§2), two of which — 1036 and 1672 — are
  invisible in the short registry.
- `IL2CPP_FINDINGS.md` §0's "unexploited: a systematic pass over the outbound class list
  would name a large slice of the protocol for free" is retired by §6.4 — it names 2 %.
