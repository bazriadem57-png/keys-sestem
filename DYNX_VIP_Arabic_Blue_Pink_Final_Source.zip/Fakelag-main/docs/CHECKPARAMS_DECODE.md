# checkParams (Cmd 106 idx11) full decode + hit-geometry validation model

Scope: outbound Cmd 106 RUDP_TAKE_DAMAGE (class message.MMJPICCOJOM), the three geometry-bearing
fields idx9 EPCMOGEBEKM (@0x38), idx11 MPECMNGCKJN (@0x48, checkParams) and idx15 LNOIFBAFGOK (@0x60).
Static decode from FF-RE/bin/libil2cpp_dec.so via tools/il2cpp/il2cpp_scan.py (capstone), cited by RVA.
Live values ground-truthed on the rooted LDPlayer (emulator-5554, pkg com.dts.freefiremax, pid 2171).
Build identity PROVEN: live memory at RVAs 0x74df4fc / 0x78e6004 / 0x74e208c byte-matches
libil2cpp_dec.so exactly (mapping live = rva + 0x4000233fc000 for the R+X segment). Supersedes
HIT_REWRITE_SPEC.md section 4 and 8.3/8.4.

Marking: PROVEN (in binary / live), INFERRED (strong static inference), UNKNOWABLE(server).

---

## 1. Verdict (one paragraph)

Forging a server-accepted Head hit by manipulating checkParams is **INFEASIBLE** for a wire-rewriting
relay, and this directly explains the observed zero-damage result. checkParams (idx11) is NOT a small
hit-geometry vector: it is a **variable-length (dozens of entries), runtime-context fingerprint** built
by FDAEPHMIEPC::LKHKGOFALIB @0x74e208c that appends the shooter weapon virtual-call outputs, player
attributes, live camera pitch/yaw/roll, character height, the victim **capsule-collider height**,
skill/game-mode config floats, and only a handful of hit-geometry values. The hit point is redundantly
on the wire as idx9 in **world millimetres** (round((x+1e-4)*1000)), and victim collider dimensions are
inside checkParams, so a server holding the victim live transform can recompute the zone from (idx9
point, idx10 dir, victim capsule) and reject any Head claim whose point sits at torso height. To make a
Head claim consistent you would have to (a) move idx9 to the victim true head world-position at that
tick, (b) set idx15 to the victim head-collider id (hitInfo+0x80), and (c) rebuild the ENTIRE
checkParams float list (correct length + values + order) and re-apply the victim-keyed permutation, i.e.
re-simulate the hit against live game state. Path (i) move-hit-point-only and (ii) recompute-all-floats
are both impractical because the list length and composition depend on runtime branches the relay
cannot observe, and (iii) copy-a-reference-headshot fails because the non-geometry entries (camera
angles, ammo, per-frame attribute/skill snapshots) and the tick/point differ frame-to-frame. Net: the
minimal 2a zone-flip is the only well-formed rewrite available and it is geometry-inconsistent by
construction, matching the empirical client-shows-the-number / server-applies-nothing result.

---

## 2. checkParams (idx11 MPECMNGCKJN) - populator, contents, order

**Populator is COW.GamePlay.FDAEPHMIEPC::LKHKGOFALIB @0x74e208c** (Weapon class; FDAEPHMIEPC=Weapon per
ff_deobfuscation_map). NOT KDIPAEGAIFL @0x74daa4c, which is the no-headshot-state dispatcher (calls
Player::IsInNoHeadShotState @0x712e6a8 and forwards to a JNHIOHFMPFN vtable method; it does not build
the list). PROVEN.

Call site (inside KOODEKEKFEK @0x74df4fc):
- 0x74e0620 bl LKHKGOFALIB(this=x19, x1, hitInfo+0x20, w3=modeFlag[sp+0x1a8], damageInfo=x23)
- 0x74e062c mov x20, x0  -> x20 = returned List<float>
- return value proven: ldr x0,[x29] @0x74e6f94 where x29 = x19+0x7e8 -> **the list is the Weapon field
  [Weapon+0x7e8]** (reset to size 0 at 0x74e2304-0x74e2310, then re-populated). PROVEN.

Structure: ~115 Add sites (grep 9badab8 + inline str s?,[x8,#0x20]), gated by many branches, so the
**list length is not fixed**: it depends on weapon type, game mode, party/carry/vehicle state, camera
presence and skill state (branch flag w27=modeFlag at 0x74e2314 selects two different opening
sequences). PROVEN that length is data-dependent.

Representative entries and sources (branch-B / normal path, in Add order), each appended as one float
via inlined List<float>.Add:
- (float)weaponVtbl[0x658]() scvtf @0x74e295c - weapon int stat (attack/ammo id) [getter INFERRED]
- [Weapon+0x114] @0x74e2a20 - weapon float field
- weaponVtbl[0x468]() @0x74e2a98 - weapon float
- (float)weaponVtbl[0x628]() scvtf @0x74e2b24 - weapon int
- s12 / s10 fdiv @0x74e2bc4 - **the effective scoped VERTICAL FOV, in degrees** (CORRECTED
  2026-09-20; was recorded here as "a config ratio" off `gameModeSetting`, which is wrong).
  s12=[X20+0xB8 +0x20] @0x74e23a0 is **`FollowCamera::C_FOV_NORMAL` = 60.0** - the class-ptr
  global loaded at 0x74e237c is 0xB0CFD28, the same one `FollowCamera::GetFovNormal`
  @0x0722320c reads (`LDR S0,[X8,#0x20]` @0x7223290), NOT a game-mode setting.
  s10=[X23+0xC0 +0x3c] @0x74e23b0 is the sight attachment's **`sight_fov_amplify_ratio`**,
  defaulted to 1.0 @0x74e27d4 when no sight is fitted.
  So the client ships its own scoped FOV on the wire every time it fires. Measured against
  the ESP, the "8X" sight divides by **3**, not 8 - `sight_amplify_ratio` (the int that
  prints the label and picks a sensitivity) and `sight_fov_amplify_ratio` (this float) are
  different CSV columns and they do not match. Neither is in the .so.
- Player::GetCharacterHeight() @0x74e2c44 - character height
- camera triple: s11=cam[+0x90] (0x74e2870), s14=cam[+0x8c] (0x74e288c), s9=cam[+0x6c] (0x74e28a0) via
  Player::get_MyFollowCamera - **live camera pitch/yaw/roll** (PROVEN these enter the list)
- config vector [singleton.b8 + 0/4/8] -> s15,s13,s11 @0x74e28e8
- weaponVtbl[0x5d8], [0x5e8], [0x668] ... (many more weapon virtual/field reads through 0x74e6f9x)
- CapsuleCollider::get_height() @0x74e713c - **victim capsule collider height** (PROVEN)
- literal 0.0 / 1.0 markers at several sites (str wzr / fmov s0,#1.0)

Conclusion: checkParams encodes the full firing/weapon/camera/attribute/skill context PLUS victim
collider dimensions. Hit geometry is a small minority of the list. PROVEN it is not purely geometry.

---

## 3. The permutation (idx11 scramble) - exact, reproducible

Chain: FDAEPHMIEPC::IJBAPAJAINA @0x74e71b4 (thin wrapper) -> ICALGMBOIBD::IJBAPAJAINA @0x78bf848 with
args (list, seed, &Weapon+0x7f8 (int[] scratch), &Weapon+0x800 (float[] scratch), 0)
(0x74e7218/0x74e721c). PROVEN.

PRNG ICALGMBOIBD::OCKMOCGKDAL @0x78bf7e8 is **xorshift32** (0x78bf828-0x78bf834):
x ^= x<<13; x ^= x>>17; x ^= x<<5; return x  (32-bit, state by pointer). PROVEN.

Algorithm in ICALGMBOIBD::IJBAPAJAINA @0x78bf848 (PROVEN):
1. n = list.Count; if n < 2 return (0x78bf908).
2. Fill scratch: idx[i]=i, val[i]=list[i] for i=0..n-1 (0x78bf978-0x78bf9c8).
3. state = seed XOR 0xA3B1C6D9; if 0 -> 1 (0x78bf9cc-0x78bf9dc).
4. Fisher-Yates (Durstenfeld) backwards, i=n..2: r=xorshift32(state); k=r % i; swap idx[i-1],idx[k]
   (0x78bf9ec-0x78bfa40). Modulus uses current i (descending).
5. Writeback scatter: list[idx[j]] = val[j] for j=0..n-1 (0x78bfa50-0x78bfa9c).

Content-preserving reorder (same floats, new order). Python reference:

```python
def xorshift32(s):
    s &= 0xFFFFFFFF
    s ^= (s << 13) & 0xFFFFFFFF
    s ^= (s >> 17)
    s ^= (s << 5) & 0xFFFFFFFF
    return s & 0xFFFFFFFF

def scramble_checkparams(values, victim_playerid_low32):
    n = len(values)
    if n < 2:
        return list(values)
    idx = list(range(n)); val = list(values)
    s = (victim_playerid_low32 ^ 0xA3B1C6D9) & 0xFFFFFFFF
    if s == 0: s = 1
    i = n
    while i >= 2:                 # i = n, n-1, ..., 2
        s = xorshift32(s)
        k = s % i
        idx[i-1], idx[k] = idx[k], idx[i-1]
        i -= 1
    out = [0.0]*n
    for j in range(n):
        out[idx[j]] = val[j]
    return out
```

### 3a. Seed transform
seed = BHGGAEEHJCO::LMCLIKOCCJM(victim.PlayerID) @0x7c4b8fc = **`*(int32*)&PlayerID`** (literally
ldr w0,[x19] @0x7c4b958), the low 32 bits of the victim PlayerID struct, no transform. PROVEN. Seed
source is the victim (collider owner, x29=x21=HitDetectColliderHelper::GetOwner), read at 0x74e0c20
immediately before the scramble.

### 3b. Enemy-only gate
Scramble runs only when attacker/victim are on different teams. Team = BHGGAEEHJCO::DDPFMJDFEDJ
@0x7c4c1d0 = **PlayerID.byte[8]** (ldrb w0,[x19,#8] @0x7c4c2c4; a special UGC-mode remap via
MCDLKHAOJJG::HMGMKMPDKAM exists but default is byte[8] = squad index). Compare 0x74e0bcc-0x74e0bd4:
if teamA == teamB -> skip scramble (b.eq 0x74e0c3c), else scramble at 0x74e0c30. PROVEN. Matches memory
note team-is-a-squad-index.

---

## 4. idx9 hit point + idx10 hit direction

Encoder message.KANJBNIANHC::COGCJKJPPHI @0x577e298, per axis:
enc = round((coord + 1e-4) * 1000.0) as int32 (scale const 0x447a0000 = **1000.0f** @0x577e32c; bias
[0x18ba38c] = **9.999999e-05** ~ 1e-4 rounding epsilon; banker rounding via ac74d20; result ints at
+0x14/+0x18/+0x1c). PROVEN.
- idx9 EPCMOGEBEKM = COGCJKJPPHI(v13,v12,v11) (TakeDamage 0x736f5b8, store msg+0x38) = **world hit point
  in millimetres** (int3 zigzag on wire). PROVEN units 1000/m (confirms memory note 1000/m).
- idx10 PHEOMEDPGED = COGCJKJPPHI(v10,v9,v8) (0x736f5dc, store msg+0x40) = hit direction * 1000. PROVEN.

In KOODEKEKFEK, hit-point/normal Vector3s copied hitInfo->damageInfo: damageInfo+0x4c<-hitInfo+0x74,
+0x58<-hitInfo+0x28, +0x64<-hitInfo+0x34 (0x74e02d0-0x74e0300); damageInfo+0x78<-hitInfo+0x88 (collider
obj ptr) at 0x74e032c-0x74e0334. PROVEN.

---

## 5. idx15 collider id layout

GLLLEDKLLDA::KFEOBAJJFEF @0x78e6004 = **plain hitType | colliderBodyId** (orr w0,w19,w20 @0x78e604c),
result truncated to 16-bit (strh w0,[damageInfo+0x70] @0x74e0328). Inputs (0x74e0318): w0=hitType =
prior damageInfo+0x70; w1=colliderBodyId = **hitInfo+0x80** (ushort, the specific collider struck,
0x74e0308). PROVEN. Exact bit split is a bare OR with no shift, so the two fields are not cleanly
separable for an in-place edit without the game collider-id numbering - INFERRED. Key point PROVEN:
idx15 carries the identity of the actual collider hit; a body-collider value does not correspond to a
head collider.

---

## 6. LDPlayer live confirmation

- Build == libil2cpp_dec.so: 3 RVAs byte-match live process memory. PROVEN.
- **Zone multipliers** (config sf = *(*(*(0xafd0228)) + 0xb8), chain JBJDLGPLAPB 0x78e4250-0x78e4270),
  read live from pid 2171:
  - head    sf+0x308 = **5.5**
  - body    sf+0x30c = **1.0**
  - limb    sf+0x310 = **0.75**
  - vehicle sf+0x314 = **1.0**
  - sf+0x318 = 0.75, sf+0x31c = 2.8, sf+0x320 = 0.7, sf+0x324 = 3.0
  PROVEN LIVE. Head:body damage ratio = **5.5x** (higher than prior 2.6-4.2x estimate).
- Live checkParams list capture during a hit: NOT captured (needs hooking Weapon+0x7e8 at hit time;
  bonus only). Static decode is complete and self-consistent.

---

## 7. Recipe to make a Head claim consistent - and why it is infeasible

For a server geometry re-validation to pass, ALL of the following must be mutually consistent with a
real head hit against the victim at tick idx8:
1. idx9 = victim head world-position at that tick, mm (round((headPos+1e-4)*1000) per axis). Needs the
   victim live head bone/collider world position - not on the wire.
2. idx10 = shot direction into the head, *1000.
3. idx15 = headHitType | victimHeadColliderId, colliderId = the head collider hitInfo+0x80 - the numeric
   id of the victim head collider, which the relay does not know.
4. idx11 = the FULL checkParams list rebuilt for a head hit: correct length (data dependent), values
   (weapon virtuals, live camera angles, character height, victim capsule height, attributes, skills,
   config), correct pre-scramble ORDER, then permuted via scramble_checkparams(list, victimPID_low32).
   Because the list embeds the victim collider dimensions and shooter live camera/attribute state, it
   re-encodes the same geometry idx9/idx15 do plus surrounding context.
5. idx3-high + idx7 = 1 (Head), idx16 = 0 (no downgrade), shooter not in IsInNoHeadShotState.

- Path (i) move-hit-point-only: INFEASIBLE - idx11/idx15 still say body collider; server can cross-check
  idx9 against the victim capsule (inside idx11) and against idx15.
- Path (ii) recompute-all-floats-for-a-head-position: INFEASIBLE in practice - requires reproducing
  LKHKGOFALIB branch-dependent list composition and every live input at the tick, then the permutation.
  This is re-simulating the hit.
- Path (iii) copy-a-reference-headshot-packet: only self-consistent if captured against the SAME victim
  (seed) at a compatible frame; the non-geometry entries (camera angles, ammo, per-frame attribute/skill
  snapshots) and the tick/hit-point differ frame-to-frame, so a transplanted idx11 is inconsistent with
  the rewritten packet idx8/idx9/idx10. Not reliable.

Therefore: **forging a Head hit via wire rewrite is infeasible**; the only geometrically honest way to
produce a valid Head checkParams is to land the shot on the head collider. The minimal 2a zone-flip
(idx3-high, idx7 -> 1; idx16 -> 0) is well-formed but geometry-inconsistent, consistent with the
empirical zero-damage result: the server re-validates hit geometry (idx9 / idx15 / idx11) against the
claimed zone and clamps a torso-geometry Head claim to no effect. UNKNOWABLE(server) which of the three
it checks, but any one defeats the flip.

---

## 8. RVA index

| symbol | RVA | role |
|---|---|---|
| FDAEPHMIEPC::LKHKGOFALIB | 0x74e208c | checkParams populator (returns list @Weapon+0x7e8) |
| FDAEPHMIEPC::KOODEKEKFEK | 0x74df4fc | damage builder; calls populator + scramble |
| FDAEPHMIEPC::KDIPAEGAIFL | 0x74daa4c | no-headshot-state dispatcher (NOT populator) |
| FDAEPHMIEPC::IJBAPAJAINA | 0x74e71b4 | scramble wrapper (list,seed,&+0x7f8,&+0x800) |
| ICALGMBOIBD::IJBAPAJAINA | 0x78bf848 | Fisher-Yates permutation |
| ICALGMBOIBD::OCKMOCGKDAL | 0x78bf7e8 | xorshift32 PRNG |
| BHGGAEEHJCO::LMCLIKOCCJM | 0x7c4b8fc | seed = PlayerID low32 |
| BHGGAEEHJCO::DDPFMJDFEDJ | 0x7c4c1d0 | team = PlayerID.byte[8] |
| message.KANJBNIANHC::COGCJKJPPHI | 0x577e298 | idx9/idx10 mm encoder (*1000) |
| GLLLEDKLLDA::KFEOBAJJFEF | 0x78e6004 | idx15 = hitType OR colliderBodyId |
| GLLLEDKLLDA::JBJDLGPLAPB | 0x78e40fc | zone->multiplier (sf+0x308.. head 5.5/body 1.0/limb 0.75) |
| PlayerNetwork::TakeDamage | 0x736f0e4 | Cmd 106 serializer (idx9@f5b8 idx10@f5dc idx11@f598 idx15@f608) |
