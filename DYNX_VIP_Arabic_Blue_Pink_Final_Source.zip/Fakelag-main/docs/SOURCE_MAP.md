# Source map — how the code is laid out, as built

**Read this before opening anything.** The tree was reorganised on 2026-09-15
from 10 packages to 19. **Every file path in an older doc or memory note is
stale.** The old→new table in §2 is the translation.

Module root: `fakelag/fakelag-beta/app/src/main/java/com/fakelag/cryhard8/`
Java 8 only — no records, no `var`, no switch expressions, no `List.of`.
compileSdk 35, minSdk 21, `./gradlew.bat assembleDebug`.

---

## 1. The tree, and what each package owns

```
root (3)          the three AndroidManifest-named components, and only those
  MainActivity, PacketVpnService, FloatingOverlayService

config (4)        persisted settings + intent action names
  Prefs           107 KEY_* strings, persisted on the device — NEVER rename
  EspTuning       SharedPreferences write-through for ~124 renderer statics
  VpnActions      intent action strings (not class names)
  GameTargets     the Free Fire package list + which are installed/running

util (5)          pure helpers: forget the game exists and the unit test still works
  Leb128, ZigZag, Num, Hex, Buffers

decode/frame (9)  the UDP header: MsgKey, HeaderField, HeaderLayout,
                  PacketCodec, Crc7, UdpPacket, PacketFlags, SendOption, Direction
decode/crypt (2)  Tea, BodyCrypt
decode/body (10)  message bodies: Cmd, CmdCatalogue, WireReader, PositionSync,
                  PriSync, VehicleSync, BodyDecoder*, BodyDecoderTable/Text

protocol (9)      STATEFUL observers of the wire
  PacketPipeline      owns the solver; observeAndParse + dispatch
  SessionKeySolver    header layout: lobby seed, else vote
  LobbyKeySniffer     recovers key + header permutation from lobby TCP
  SessionTimeline     phase machine (lobby/matchmaking/loading/match)
  GamePacketTaxonomy  wire classification with learned session state
  PacketIntegrity     CRC-7 seal/repair
  VisibilityMask, AimBias, AimBiasExperiment

tunnel (7)        the VpnService transport (was core/)
  VpnEngine       lifecycle, routes, allow-list, stats loop
  PacketLoop      the TUN read loop, per packet
  UdpSessionManager  per-flow NAT onto protected sockets + recv threads
  TcpProxy        userspace TCP relay (this is where the lobby key is sniffed)
  PacketBuilder, TunAddressPool, VpnEngineState

filter (15)       packet policies; filter/replay (2) is the replay engine
  DefaultFilterEngine dispatches; Ghost, Freeze, Teleport, Aim, Mark

esp (6)           the entity engine
  EspEngine       ~2300 lines: keepalive parse, chain parse, dead reckoning,
                  lag estimator, friend/foe ladder, match boundary, own state
  PriTracker      Cmd 1900 owner→entity binding + real HP
  MatchRoster     names + squad bytes from Cmd 101/107/139
  OrientationProvider, MarkTarget, EspBodyDecoders

diag (3)          module health — see docs/MODULE_HEALTH.md
  Diag, Slot, Invariants

dev (2) + dev/capture (10)   the packet dumper
  CaptureWriter   single writer thread, streams to disk, writes the DIAG block

ui/render (1)     EspRenderView — projection + drawing, ~1900 lines
ui/overlay (3)    EspOverlay (the window), DevPopup, CrosshairView
ui/panel (1)      EspTunePanel — collapsible sections, built in Java not XML
ui/button (4)     OverlayButton, OverlayAnimations (status title), touch, drawable
ui/aim (4)        AimInjector (Shizuku touch), TouchWatcher, AimEditOverlay, AimCalibrator
ui/settings (4)   AppPicker, UiBindings, PermissionController, AppearanceBroadcaster
```

### Dependency direction

`util` → nothing. `decode` → `util`. `protocol` → `decode`. `tunnel` → all of
those + `filter`. `esp` → `decode`+`protocol`. `ui` → everything. `config` is
the only thing `esp` and `ui` share.

Moving `EspTuning` into `config` is what removed the two upward edges
(`esp→ui`, `esp→filter`). **Do not let `esp` import `ui` again.**

---

## 2. Old path → new path

| was | now |
|---|---|
| `core/*` | `tunnel/*` |
| `net/MsgKey,HeaderField,HeaderLayout,PacketCodec,Crc7,UdpPacket,PacketFlags,SendOption,Direction` | `decode/frame/*` |
| `net/Tea,BodyCrypt` | `decode/crypt/*` |
| `net/Cmd,CmdCatalogue,WireReader,PositionSync,PriSync,BodyDecoder*` | `decode/body/*` |
| `net/PacketPipeline,SessionKeySolver,SessionTimeline,LobbyKeySniffer,VisibilityMask,AimBias*` | `protocol/*` |
| `filter/GamePacketTaxonomy,PacketIntegrity` | `protocol/*` |
| `overlay/EspRenderView` | `ui/render/` |
| `overlay/EspTunePanel` | `ui/panel/` |
| `overlay/EspOverlay,DevPopup,CrosshairView` | `ui/overlay/` |
| `overlay/OverlayButton,OverlayAnimations,...` | `ui/button/` |
| `overlay/AimInjector,TouchWatcher,...` | `ui/aim/` |
| `app/*` | `ui/settings/` (except `GameTargets` → `config/`) |
| `esp/EspTuning` | `config/` |
| `Prefs,VpnActions` | `config/` |
| `replay/*` | `filter/replay/*` |
| `filter/JitterFilter`, `overlay/MaskBar` | **deleted** (dead / branding) |

---

## 3. Data flow, end to end

```
TUN fd
  └─ tunnel/PacketLoop           per packet: parse IP, classify, filter
       ├─ protocol/PacketPipeline  solve header, read Cmd
       ├─ esp/EspEngine            observeKeepalive (2001) / observeVehicleState (2002,2069)
       ├─ filter/*                 ghost/teleport/aim/mark may rewrite in place
       └─ tunnel/UdpSessionManager NAT out on a protected socket
            └─ recv thread         inbound: decrypt, decode, feed esp + capture

tunnel/TcpProxy                  lobby TCP
  └─ protocol/LobbyKeySniffer      SECRET_KEY + header permutation, in plaintext
       └─ PacketPipeline.seedLayout   skips ~2 s of solver voting

esp/EspEngine  ──snapshot──▶  ui/render/EspRenderView  ──▶  screen
                                (120 Hz Choreographer)
```

---

## 4. The invariants that cost days to learn

Break any of these and a feature dies silently.

1. **Only a server-published team byte may paint a box as a teammate.** Never
   geometry. The proximity rule was *inverted* in Battle Royale and painted 21
   enemies per match blue. `FRIEND_FOE_AUTHORITATIVE.md`.
2. **Rewrite packets in place; never inject.** A new reliable message mints an
   OrderID the reliability layer never issued → window desync → disconnect.
3. **Edit any byte at offset ≥2 and you MUST re-seal CRC-7**, or the server
   silently discards the packet — which feels exactly like a server correction.
4. **`reliable ⟺ TEA-encrypted`, `unreliable ⟺ plaintext`.** The readable set is
   exactly the touchable set.
5. **The ESP render window must span the true display**, with
   `FLAG_LAYOUT_NO_LIMITS` + cutout mode, and the projection must use *display*
   metrics, not `getWidth()`. An inset mimics an FOV error exactly.
6. **`onDraw` allocates nothing.** Paints and scratch arrays are preallocated.
7. **When you narrow a field's meaning, grep EVERY reader.** This caused four
   separate bugs in one session. `ownLastUpdateMs` means "Cmd 2001 is alive";
   `ownStateMs` means "own state is fresh from any source".
8. **Never reinstate a mid-match `restartTunnel`** on a no-UDP heuristic — it
   dropped players out of live matches.
9. **`Prefs` key strings are on the user's device.** Never rename one.
10. **There is no player camera on the wire while mounted.** Cmd 2001 stops,
    Cmd 2002 has no aim, and the server freezes the self-echo's camera vector
    for the whole ride (67/67 samples byte-identical). The vehicle heading is
    the best obtainable substitute and is wrong by the free-look angle.
    `MOUNTED_ESP_FIX.md`.
11. **A counter placed before the value it reads instruments nothing.**
    `RENDER_DREW_BOX` read `enemyCount` above the loop that assigns it, so
    `RENDER_BLIND` produced 79 false alarms in one capture. Replay a new
    invariant against a real capture before trusting it.

---

## 5. Diagnostics: read these before theorising

The dump now carries **module health**, not just packets — see
`MODULE_HEALTH.md`. Order of investigation:

1. `# DIAGALARM` lines in the capture footer — each names the failure and what
   the user sees. No alarms ⇒ the subsystems believe they are healthy.
2. The HUD's own rows, live on screen:
   `TGT` (which app is tunnelled) · `LAYOUT` (seeded vs solved) ·
   `OWN` (2001 / 2069 / 2002 / self-echo) · `TEAM` (team-byte provenance) ·
   `VP` (viewport vs display) · `DIAG` (worst current alarm)
3. `WHEN_NOTHING_WORKS.md` — the packet-level triage, keyed on the capture
   footer's `out`/`in`/`foreign`/`decrypted`.

**Capture is always-on.** `VpnEngine` opens a fresh dump on every engine start;
there is no capture button and there must not be one — it could only ever turn
*off* the recording the diagnostics depend on.

**`DevLogger` is a no-op in production** (`devMode = false` by default). Never
route a diagnostic through it. Use `Diag.hit(Slot.X)`, which is unconditional.

---

## 6. Doc index, by question

| question | doc |
|---|---|
| nothing works at all | `WHEN_NOTHING_WORKS.md` |
| what do the DIAG lines mean | `MODULE_HEALTH.md` |
| the protocol, generally | `PROTOCOL_MASTER.md` (note §6.1 retracted) |
| friend/foe colours | `FRIEND_FOE_AUTHORITATIVE.md` |
| HP and names | `ESP_HEALTH_AND_NAMES.md` |
| camera, FOV, sensitivity | `GAME_CLIENT_CONSTANTS.md` |
| ESP blank in Clash Squad | `CS_MODE_ESP_FAILURE.md` |
| vehicles / mounted | **`MOUNTED_ESP_FIX.md` first**, then `MOUNTED_CAPTURE_ANALYSIS.md`, `VEHICLE_PARSE_SPEC.md`, `CMD_2002_VEHICLE_LAYOUT.md`, `VEHICLE_DISPATCH_MAP.md` |
| match-start data loss | `PREKEY_WINDOW_FIX.md` |
| VPN service behaviour | `VPN_SERVICE_AUDIT.md` |
| CPU / battery | `PERF_AUDIT.md` |
| UI design tokens | `UI_DESIGN_SPEC.md` |
| marking / Moco | `MARKING_MECHANIC.md`, `MARK_REVEAL_SURFACE.md` |
| planned refactors not yet done | `SPLIT_PLAN_ESP.md`, `UTIL_EXTRACTION.md`, `ARCHITECTURE_TARGET.md` |
| remaining uninstrumented bails | `DIAG_INVENTORY_{TUNNEL,ESP,FILTER_UI}.md` |
