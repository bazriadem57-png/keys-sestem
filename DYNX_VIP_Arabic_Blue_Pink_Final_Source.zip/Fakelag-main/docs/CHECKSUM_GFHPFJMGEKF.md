# GCommon.Checker.GFHPFJMGEKF — decoded

Image analyzed: `C:\Users\Tonyt\Documents\FF-RE\bin\libil2cpp_dec.so` (decrypted twin of the shipped
`libil2cpp.so`; same build, same RVAs — coordinator confirmed byte-identical, and 0x083b6c20 decodes
identically in both copies, so this function is not encryption-blocked). All asm verified with capstone
(`tools/il2cpp/il2cpp_scan.py`). idalib was NOT usable (the MCP exposes no open verb and no session was
pre-bound; `survey_binary` with the path and with no arg both returned "no database bound"), so every
pseudocode line below is capstone-derived. metadata v31.
AKFFMELHGIJ@0x83b6c20: validity 1.0 over 154 insns; exactly 1 `bl` caller.

## 1. Verdict (one paragraph)

**NON-DETERMINISTIC. Not damage-dependent. Not replicable as a fixed value.** `AKFFMELHGIJ(10,7,tick)`
builds a token whose 10 core characters are the base-32 rendering of bytes produced by
`System.Random.NextBytes()` on a freshly constructed `new System.Random()` (default ctor, seeded at
runtime from a process-global source). The only deterministic inputs are: arg0=10 (output length),
arg1=7 (the digit inserted), and arg2=tick (which ONLY selects the insert position `tick%10`).
`tick` is the game-simulation tick read from `msg+0x30`, NOT the damage (confirmed: the caller loads
`w23 = *(x25)` and passes it as arg2; no damage value participates). The class name `fake_version` is
literal: the field it emits is effectively a random nonce/decoy. It is then XOR-obfuscated
(`EJJLOHDHCPJ@0x83b6e88`, a Vigenere-style byte XOR — NOT AES) with a caller-supplied key and stored as
bytes at `MMJPICCOJOM+0x68` (field FHBHMKMHCHJ) on outbound **Cmd 0x6A = 106 RUDP_TAKE_DAMAGE**.
Because the payload is random, you cannot reproduce a SPECIFIC observed token offline; you can only
reproduce its FORMAT (given below). The single cheapest experiment to make it fully replicable is to
control/seed the RNG (see section 7).

## 2. AKFFMELHGIJ — full algorithm (RVA 0x083b6c20, len 0x268)

Signature (IL2CPP static): `string AKFFMELHGIJ(int a, int b, uint c, MethodInfo*)` — x0=a, x1=b, x2=c, x3=MethodInfo.
Observed call: `a=10, b=7, c=tick`.

Pseudocode (each line cited):

```
static bool s_init;                                   // byte @ &0xb89ee50
string AKFFMELHGIJ(int a, int b, uint c) {
  if (!s_init) {                                       // 0x83b6c38 ldrb / 0x83b6c4c tbnz
     initRuntimeMetadata(&Byte_cell);                  // 0x83b6c50  &0xafcb890  (System.Byte)
     initRuntimeMetadata(&Int16_cell);                 // 0x83b6c5c  &0xafcba00  (System.Int16)
     initRuntimeMetadata(&Random_cell);                // 0x83b6c68  &0xafcc030  (System.Random)
     initRuntimeMetadata(&StringBuilder_cell);         // 0x83b6c74  &0xafcb1c8  (System.Text.StringBuilder)
     initRuntimeMetadata(&EmptyStrOwner_cell);         // 0x83b6c80  &0xafcc798  (owner of default return string)
     initRuntimeMetadata(&Alphabet_strlit_cell);       // 0x83b6c8c  &0xb114e08  (base-32 alphabet string literal)
     s_init = true;                                    // 0x83b6c98
  }
  short acc = 0;                                        // strh wzr,[sp,#8]  (0x83b6ca4) insert accumulator slot
  if (a < 1)  return DEFAULT;                           // 0x83b6ca0 cmp a,#1 ; 0x83b6ca8 b.lt -> 0x83b6e54
  if (b >= 10) return DEFAULT;                          // 0x83b6cac cmp b,#0xa ; 0x83b6cb0 b.ge -> 0x83b6e54

  Random rnd = new Random();                            // obj_new(Random) 0x83b6cc0 ; Random..ctor 0x83b6ccc (0xa13a184)
  byte[]  buf = new byte[8];                            // array_new(Byte,8) 0x83b6ce0 (0xab6e068), w1=#8
  StringBuilder sb = new StringBuilder((a/10)*5 + 5);   // capacity 0x83b6cfc..0x83b6d10 ; ctor 0x83b6d1c (0x9f9c49c)
                                                        //   for a=10 -> (1)*5+5 = 10
  while (sb.Length < a) {                                // get_Length 0x9f9cfcc @0x83b6d28/dd8 ; cmp a
     rnd.NextBytes(buf);                                // virtual @Random.klass+0x1c8, arg=buf  (0x83b6d5c blr)
     buf[5]=buf[6]=0; buf[7]=0;                          // sturh wzr,[buf+0x25] (0x83b6d80) ; strb wzr,[buf+0x27] (0x83b6d7c)
     long v = BitConverter.ToInt64(buf, 0);             // 0x83b6d84 (0xa088db0 -> 0xa088cac): buf[0..7] as int64 LE
                                                        //   => v is a 40-bit value (top 3 bytes forced to 0)
     while (v != 0 && sb.Length < a) {                  // 0x83b6d8c cbz ; 0x83b6d90..da0 length check
        char ch = ALPHABET[(int)(v & 0x1f)];            // and w1,w24,#0x1f (0x83b6dac) ; get_Chars 0x9f8b35c (0x83b6db4)
        sb.Append(ch);                                  // StringBuilder.Append(char) 0x9f9e944 (0x83b6dc4)
        v >>= 5;                                        // lsr x24,x24,#5 (0x83b6dc8)
     }
  }
  string bs = ((Int32)b).ToString();                    // 0xa126ca8 on &b (arg1 @sp+0xc, stored 0x83b6c48) -> "7"
  short  ins = Int16.Parse(bs);                          // 0xa08c9c0 (single-digit parse) -> out @sp+8 = 7  (0x83b6e20 ldrh)
  int    idx = (int)c % a;                               // sdiv/msub 0x83b6e24/e28 -> tick % 10
  sb.Insert(idx, ins);                                   // StringBuilder.Insert 0x9f9d8f4 (0x83b6e34)  => inserts "7"
  return sb.ToString();                                  // virtual @sb.klass+0x168 (0x83b6e48 blr)
DEFAULT:                                                 // 0x83b6e54
  return EmptyStrOwner.static_fields[0];                 // *(&0xafcc798)->static_fields[0]  (likely String.Empty)
}
```

Net output shape: **10 base-32 chars, then the decimal digit of `b` ("7") inserted at index `tick%10` => 11 chars.**

### The base-32 alphabet
- Accessed as `ALPHABET[(v & 0x1f)]` via `String.get_Chars` (confirmed: `0x9f8b35c` has length@+0x10,
  chars@+0x14 — exact IL2CPP `System.String` layout). Cell `&0xb114e08` is a **string-literal** cell.
- Value (HIGH confidence): metadata string-literal **idx 2187 = `0123456789ABCDEFGHJKLMNPQRTUVWXY`**
  (32 chars; omits I,O,S,Z — a Crockford-style custom set). Evidence: it is the ONLY length-32 string
  literal in the whole 54,099-entry table that is a base-conversion alphabet, and the code does a 5-bit
  index into a 32-char string. Caveat: v31 metadata has no metadataUsage-pair table and no IDA session
  was available, so cell->literal-index was not walked by pointer; identification is by content+length
  uniqueness.

### The six statics (resolved, type + role)
| cell | type | role | evidence |
|------|------|------|----------|
| `&0xafcb890` | System.Byte | element type for `new byte[8]` | array_new count=8; byte-granular zeroing buf[5..7] |
| `&0xafcba00` | System.Int16 | `Int16.Parse` of `b.ToString()` | 0xa08c9c0 single-char->short; cctor flag @+0xe0 |
| `&0xafcc030` | System.Random | `new Random()` | ctor 0xa13a3bc = 56-int SeedArray, MSEED=161803398 |
| `&0xafcb1c8` | System.Text.StringBuilder | the token builder | ctor 0x9f9c49c (maxCap=0x7fffffff); Length/Append/Insert |
| `&0xafcc798` | owner of default-return string | guard-fail return | `->static_fields[0]`, likely `String.Empty` |
| `&0xb114e08` | string literal | the base-32 alphabet | get_Chars indexing; idx 2187 (above) |

BCL/runtime helper identities (resolved by reading bodies):
- `0xa088db0 -> 0xa088cac` = `BitConverter.ToInt64(byte[],int)` (bounds `start<=len-8`, 8-byte load @+0x20).
- `0x9f8b35c` = `String.get_Chars(int)`.
- `0x9f9c49c` = `StringBuilder..ctor(int capacity)` (maxCapacity const 0x7fffffff).
- `0x9f9cfcc` = `StringBuilder.get_Length` (`m_ChunkOffset@+0x24 + m_ChunkLength@+0x20`).
- `0x9f9e944` = `StringBuilder.Append(char)`.
- `0x9f9d8f4` = `StringBuilder.Insert(int,...)`.
- `0xa08c9c0` = `Int16.Parse` (single-digit fast path via get_Chars).
- `0xa126ca8` = `Int32.ToString()` (value-type `this`).
- `0xa13a184` = `System.Random..ctor()` wrapper: seed = `0xa13a1e0()`, tail-call `0xa13a3bc(this,seed)`.
- `0xa13a3bc` = `System.Random..ctor(int)` (subtractive generator; int.MinValue special case; MSEED 0x09A4EC86).
- `0xa13a1e0` = default-seed source: reads `Random.static_fields[0]` (shared object) and calls its
  vtable+0x188 method to get an int seed => runtime/state-varying.
- `0xab6df80` = il2cpp_codegen_initialize_runtime_metadata (barrier `dmb ish`); `0xab6e20c` = object_new;
  `0xab6e068` = array_new; `0x9f90978` = `String.IsNullOrEmpty` (null->true; length@+0x10==0 -> true).

## 3. Determinism analysis (input by input)

| input | classification | source |
|-------|----------------|--------|
| a (=10) | constant | immediate at call site (0x736f8c8 `mov w0,#0xa`) -> output length |
| b (=7)  | constant | immediate (0x736f8cc `mov w1,#7`) -> digit inserted ("7") |
| c (tick)| runtime, non-secret | `*(uint*)(msg+0x30)` (0x736f8ac `ldr w23,[x25]`) -> used only as `tick%10` insert index |
| ALPHABET| compile-time constant | string literal idx 2187 |
| the 10 core chars | **RUNTIME RANDOM** | `new Random().NextBytes()` — 40-bit values, seed from process-global source (0xa13a1e0) |

There is NO account id, secret key, `Time.time`, or monotonic packet counter feeding the VALUE. The
randomness is genuine `System.Random` state, re-seeded per call. Two calls with identical `(10,7,tick)`
produce DIFFERENT tokens (differ in the 10 core chars; identical only in length and in the '7' at position `tick%10`).

## 4. Call sites of 0x083b6c20

`bl_callers(0x083b6c20)` -> **exactly 1**:
- `COW.GamePlay.PlayerNetwork::TakeDamage+0x7f4` (RVA 0x736f8d8), constants **(a=10, b=7, c=tick)**
  (verified: `regimm` -> w0=10, w1=7; w2=w23=`*(x25)`).

No other caller passes different (a,b). (Note: a DIFFERENT overload `AKFFMELHGIJ@0x83b655c` is called
twice by sibling `COGLOODPLPP` — that is not this method.)

## 5. EJJLOHDHCPJ — the "AES wrap" (it is NOT AES)

Two overloads exist:
- **`0x83b6e88`** — used on the TakeDamage wire (caller `TakeDamage+0x8bc`, 0x736f9a0). Algorithm: a
  **repeating-key byte XOR** (Vigenere), NOT AES. Core: `out[i] = (char)(keyBytes[(i+srcLen) mod keyLen] XOR src[i])`
  — the XOR is explicit at 0x83b6fe4 `eor w2,w8,w0`; key bytes read at `key+idx+0x20` (0x83b6fd8); index
  `(i + srcLen) mod keyLen` (0x83b6fbc..fd0). If key is null/empty (`String.IsNullOrEmpty` @0x83b6f08) or
  src invalid, returns static string `*(&0xafe0320)`. No S-box, no rounds, no IV — confirmed not a block cipher.
  Key source at the wire site: `key = 0xa1490ec(x25)` — a runtime-computed string (`0xa1490ec` is a
  BCL/generic helper that reads `*(int*)arg` and returns a string form: a per-message value, not a constant).
  Result -> `MMJPICCOJOM+0x68` (0x736f9a8 `str x0,[x20,#0x68]!`), then `GameFacade::Send(0x6A, msg,…)` (0x736f9e8).
- **`0x83b3ebc`** — the general obfuscator used across networking/matchmaking (~40 callers: UIModelGroup,
  UIModelMatch, UIModelRecruit, UIModelSkinModCheck, GCommon.Obfuscate.PLPIAHGIGHM, etc.). This is the
  "family" encode method; it is NOT the one applied to the TakeDamage token.

Sibling `GMADMEPEOPD@0x83b77a4` = `EJJLOHDHCPJ(GFHPFJMGEKF.static_fields[0], arg)` — encode using the
class's own static string as key. That static string is set in `.cctor` (0x83b78b4 `str x9,[static_fields]`)
from string-literal cell `&0xb114e18`, which is the class's `fake_version` key; exact literal is almost
certainly idx 47742 = `fake_versionsdf|` (the only `fake_version*` literal in metadata; the '|' is a delimiter).
Sibling `DOOCCPEPNEN@0x83b6750` = the paired **decoder** (guards both args with IsNullOrEmpty; XOR mirror).
Sibling `AKKDOJLCOGF@0x83b68e4` = the **file/lib hasher** (called once, by `UIModelLogin::GenerateLibMapAndMemThread+0x1f0`);
iterates a static dictionary of module names and hashes them — a login-time integrity self-check. Out of scope for the token.

Replicable offline? The wire XOR is a plain byte-XOR: trivially reversible IF you know the key. But the key
is a per-message runtime string (not the raw "fake_versionsdf" literal at the TakeDamage site), and the
plaintext already contains a random token — so the wire bytes are non-reproducible in value.

### 5a. XOR-key source at the TakeDamage wrap site (follow-up)

Traced `x25`: it is the Cmd106 message object (`MMJPICCOJOM`). At 0x736f57c-0x736f588 the client stamps the
tick into the message: `w8 = COW.GameFacade::CurrentGameSimulationTimer().field@0x20` (the game-sim tick),
then `str w8,[x25,#0x30]!` — a **pre-index write-back** — so `message[0x30] = tick` and `x25` is left equal to
`message+0x30`. Both later consumers read `*(message+0x30)`:
- arg2 of AKFFMELHGIJ: `ldr w23,[x25]` (0x736f8ac);
- the XOR key: `0xa1490ec(x25)` reads `w19 = *(message+0x30) = tick` (0xa14913c) and tail-calls
  `0xa125338(tick, formatProvider, 0, 0)` (0xa149180). `0xa125338` is the number-to-string core
  (stack canary + 0xc0 frame + shared NumberFormatInfo static `&0xb131d98`), i.e. `0xa1490ec = Int32.ToString(tick)`
  returning the decimal ASCII of the tick (e.g. "12345"). It is NOT an enum name and NOT a dictionary lookup.

So the wire XOR key = `ASCII(tick)`, tick = message field **@0x30** (game-sim tick, from
`CurrentGameSimulationTimer.@0x20`). The key does NOT derive from the hit zone or the damage.

**VERDICT: token-survives-a-zone-rewrite = YES** — the XOR key is derived only from the tick (message @0x30),
which a hit-zone/damage rewrite leaves untouched. Rewriting zone/damage in place while leaving the token bytes
(v22 @ FHBHMKMHCHJ +0x68) and the tick field (@0x30) unchanged keeps the server's XOR-decrypt of the token valid.
It would break ONLY if the rewrite also changed message @0x30 (the tick).

## 6. Python reference reimplementation (FORMAT only — value is random by design)

```python
import random

ALPHABET = "0123456789ABCDEFGHJKLMNPQRTUVWXY"   # string-literal idx 2187 (see caveat in section 2)
DEFAULT  = ""                                    # guard-fail return (String.Empty, likely)

def gen_token(tick, a=10, b=7, rng=None):
    """Reproduces AKFFMELHGIJ(a,b,tick). Output value is RANDOM by design; only the
    format is deterministic. Pass a seeded random.Random() as rng to make it repeatable."""
    if a < 1 or b >= 10:
        return DEFAULT
    r = rng or random
    sb = []
    while len(sb) < a:
        buf = bytearray(r.getrandbits(8) for _ in range(8))
        buf[5] = buf[6] = buf[7] = 0                     # mask to 40 bits
        v = int.from_bytes(buf, "little")               # BitConverter.ToInt64(buf,0)
        while v != 0 and len(sb) < a:
            sb.append(ALPHABET[v & 0x1f])
            v >>= 5
    sb.insert(tick % a, str(b))                          # insert "7" at tick%10
    return "".join(sb)

# Wire XOR (EJJLOHDHCPJ @0x83b6e88): out[i] = chr(key[(i+len(src)) % len(key)] ^ ord(src[i]))
def wrap_xor(src, key):
    kb = key.encode("utf-8")
    if not key or not src:
        return src
    n = len(src)
    return "".join(chr(kb[(i + n) % len(kb)] ^ ord(src[i])) for i in range(n))
```

Verifiable invariants a server/tester can check (the only deterministic facts):
- length == a + 1 (== 11 for a=10),
- every char is in ALPHABET,
- char at index (tick % a) == str(b) ("7"). (Weak: a random char can also be '7'.)

## 7. Not resolved / caveats

- **Alphabet cell->literal index not proven by pointer.** idx 2187 is by content+length uniqueness only
  (v31 has no usage-pair table; idalib had no bound session and the MCP exposes no open verb). Confidence HIGH.
- **Random seed source `0xa13a1e0`** confirmed runtime-varying (shared static + virtual call), but not pinned
  to `Environment.TickCount` vs a shared-`Random.Next()`. Either way it is non-constant.
- **`Random.NextBytes` vtable slot** (+0x1c8) identified by behavior (Random instance, byte[] arg, output read
  as int64), not by a metadata slot walk.
- **XOR key getter `0xa1490ec`** at the TakeDamage site is a BCL/generic helper returning a string from
  `*(int*)msgField`; its exact BCL identity (enum ToString vs dictionary lookup) was not finalized.
- **`fake_versionsdf|`** (idx 47742) is the class static key by strong inference (.cctor writes literal cell
  `&0xb114e18` into static_fields[0]; GMADMEPEOPD uses static_fields[0] as key); cell->literal not pointer-proven.
- Cheapest experiment to make the token fully replicable/attributable: seed/hook the RNG (or capture two live
  TakeDamage packets with the same tick and diff them) to confirm the 10 core chars vary and the '7' position
  tracks tick%10 — that empirically closes both the determinism and the alphabet questions.
