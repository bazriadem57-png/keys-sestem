# Cmd 106 hit-claim rewrite spec - redirect a real hit to a different body part

Scope: outbound Cmd 0x6A = 106 RUDP_TAKE_DAMAGE, class message.MMJPICCOJOM, built by
COW.GamePlay.PlayerNetwork::TakeDamage @0x0736f0e4 (ends ~0x0736fa18) and sent reliably
(GameFacade::Send w2=2) at 0x0736f9e8. Mechanism = REWRITE IN PLACE of a 106 the client already
emits (6828 in one capture); OrderID inherited, transport already solved.

All disasm from FF-RE/bin/libil2cpp_dec.so via tools/il2cpp/il2cpp_scan.py (capstone). idalib MCP
could not be bound (no open verb exposed; every database= form returned not-found/no-database-bound),
so every line below is capstone-derived and cited by RVA. Wire layout cross-checked against
tools/il2cpp/ff_message_layouts.json. Token facts from docs/CHECKSUM_GFHPFJMGEKF.md.

---

## 1. Verdict (one paragraph)

A real outbound 106 CAN be rewritten to change the claimed body part, and every client-side and
structural gate is satisfiable by the rewrite. The zone travels in three mutually-derived wire fields
- GMNGCBJMDLB high byte (idx3), EHNFCMJMPMJ byte (idx7), and LNOIFBAFGOK short (idx15, a packed
hitType|colliderBodyId) - plus two marker bytes (idx16 downgrade, idx17). The two-copy agreement
(idx3/idx7) is a PROVABLE-STRUCTURAL check trivially satisfied by writing both. The anti-cheat token
(idx18) is IRRELEVANT: it is a System.Random nonce XOR-wrapped with a key derived from
*(int*)(msg+0x30) = the TICK (confirmed at 0x0736f988, x25=msg+0x30), so a zone rewrite touches
neither the nonce nor the key - the original token stays valid, no re-wrap. Damage is on the wire
(idx3 low-24-bits = client-computed damage, w1/arg1) but is zone-recomputable: the client itself
derives damage = weaponBase x zone-multiplier x armour via a jump table on hitPart-1 (JBJDLGPLAPB
@0x78e40fc, multipliers at config singleton +0x308 head / +0x30c body / +0x310 limb / +0x314
vehicle), so a server that recomputes needs only the zone flipped to apply the head multiplier. The
single genuinely UNKNOWABLE-from-client fact is whether the server re-validates hit GEOMETRY - the hit
point (idx9), the collider id packed in idx15, and the keyed-scrambled checkParams float list (idx11,
scrambled only for enemy victims, seed = victim PlayerID XOR 0xA3B1C6D9) - against the claimed zone.
That is what the hard-boundary verdict in SERVER_VALIDATION_MODEL.md 3.7 (literally unfinished) rests
on, and the one thing only the live experiment in section 7 can settle.

---

## 2. The rewrite recipe (Body(2) -> Head(1), and general zone X->Y)

Fields = obf-name + declaration index (wire fields serialize in JSON declaration order; the relay
BodyDecoderTable maps index->tag). struct-off = C# object offset used to locate the source in disasm;
the rewrite operates on the decoded varint stream.

### 2a. MUST change together - PROVABLE-STRUCTURAL (satisfiable, no server geometry needed)

| # | field | struct-off | wire enc | current (Body) | write (Head) | source RVA |
|---|---|---|---|---|---|---|
| idx3 | GMNGCBJMDLB | 0x1C | uint varint | damage OR (2<<24) | damage OR (1<<24), set bits 24-31 = 1 | pack 0x0736f504 / store 0x0736f518 |
| idx7 | EHNFCMJMPMJ | 0x2C | byte raw | 0x02 | 0x01 | 0x0736f51c |

GMNGCBJMDLB = orr w27,w27,w8,lsl#24 where w27 = w1 = arg1 = damage (low 24 bits, PROVABLE) and w8 =
damageInfo+0x14 = ColliderType/zone (high byte). Both idx3-high and idx7 come from the SAME source
(damageInfo+0x14), so a real packet always has them equal - set BOTH to Y or the two-copy check trips.

### 2b. Change for client-consistency - CLIENT-ENFORCED marker

| # | field | struct-off | enc | rule | value RVA |
|---|---|---|---|---|---|
| idx16 | HKJJLFNGMKO | 0x62 | bool | for a Head claim set 0 (no downgrade). Genuine Body hit already 0; a downgraded head is 1. | =damageInfo+0x72, copied 0x0736f610 |
| idx17 | EPAOEHEGPHO | 0x63 | bool | leave as emitted (marker from damageInfo+0x20; not zone-derived) | 0x0736f514 |

### 2c. Change ONLY to survive a possible server geometry check - INFERRED-SERVER (the unknowable)

| # | field | struct-off | enc | why | source RVA |
|---|---|---|---|---|---|
| idx15 | LNOIFBAFGOK | 0x60 | short zigzag | = KFEOBAJJFEF(hitType,colliderBodyId) = hitType OR colliderBodyId; colliderBodyId = hitInfo+0x80 is the specific collider hit. A body-shot value does not correspond to a head collider. | call 0x74e0324, store 0x74e0328 |
| idx9 | EPCMOGEBEKM | 0x38 | nested msg, mm | hit point in mm; a body hit point sits at torso height, not head. | 0x0736f5b8 (via KANJBNIANHC::COGCJKJPPHI) |
| idx11 | MPECMNGCKJN | 0x48 | List<float> | keyed-scrambled geometry params (section 4). | 0x0736f598; scramble 0x74e0c30 |

Minimal rewrite = 2a (+ idx16=0). Defeats every check PROVABLE from the binary. It does NOT move the
geometry (idx9/idx11/idx15), so it only succeeds if the server does NO geometry cross-check (section
7). If the server cross-checks, you additionally need 2c set to a real head hit captured values (idx9
head point, idx15 head collider, idx11 head checkParams), needing a reference head-shot packet to copy
from - which is why the ideal source packet is one already a headshot downgraded to Body (idx16==1,
zone==2): geometry already head-correct; flip idx3-high+idx7 to 1 and clear idx16.

### 2d. Do NOT touch

- idx18 FHBHMKMHCHJ token (0x68) - tick-keyed nonce, payload-independent (section 6). Leave verbatim.
- idx3 low-24 damage - leave as emitted (STRONG inference: server recomputes from zone; section 3).
  Only rewrite it if section 7 proves the server trusts client damage (then scale by headMult/bodyMult).
- idx0/idx4/idx5/idx8 (victim/attacker/weapon/tick) - identity + token key; changing them desyncs.

---

## 3. Full 106 field map (from TakeDamage decompile)

| # | obf | struct-off | type/enc | source (RVA) | meaning |
|---|---|---|---|---|---|
| 0 | AAFDKHICFDF | 0x14 | uint varint | LMCLIKOCCJM(this.PlayerID) 0736f4ec/f4f4 | victim handle |
| 1 | HOGJAFJMKOO | 0x18 | ushort | Player::BNLIKKEGAON ret 0736f2e4, stored 0736f5f8 | hit-result code |
| 2 | LJIIDMHPFEH | 0x1A | ushort | BNLIKKEGAON out-param [sp+0x1ac], stored 0736f600 | hit-result aux |
| 3 | GMNGCBJMDLB | 0x1C | uint varint | 0736f504/f518 | low24 = damage (arg1); high byte = zone |
| 4 | LJFHDBEHHJG | 0x20 | uint varint | LMCLIKOCCJM(attacker) 0736f558/f55c | attacker handle |
| 5 | EJJFPFENMBP | 0x24 | int zigzag | w25=arg4, 0736f55c | weaponDataID (signed; carries -Cheating_* codes) |
| 6 | NKABLKJBDGM | 0x28 | uint varint | not written in main path | (default 0) |
| 7 | EHNFCMJMPMJ | 0x2C | byte raw | 0736f51c | zone byte = damageInfo+0x14 (HitBodyPart) |
| 8 | DNNFOOGPFHO | 0x30 | uint varint | CurrentGameSimulationTimer+0x20 0736f57c/f588 | TICK (token key + token arg) |
| 9 | EPCMOGEBEKM | 0x38 | nested 3x zigzag mm | KANJBNIANHC::COGCJKJPPHI(v0..v2) 0736f5b8 | hit point (mm) |
| 10 | PHEOMEDPGED | 0x40 | nested 3x zigzag | COGCJKJPPHI(v3..v5) 0736f5dc | hit direction |
| 11 | MPECMNGCKJN | 0x48 | List<float> | arg x24, stored 0736f598; scrambled 0x74e0c30 | checkParams (section 4) |
| 12 | DDNGNJACOGB | 0x50 | uint varint | =damageInfo+0x74 when protection & arg7==0, 0736f628 | armour-plate damage |
| 13 | BKDCJBLGJII | 0x54 | float f32 | not in main path | (default) |
| 14 | CFIKODJDKDN | 0x58 | ulong varint | not in main path | (default) |
| 15 | LNOIFBAFGOK | 0x60 | short zigzag | =damageInfo+0x70 0736f608; built KFEOBAJJFEF 0x74e0324 | bodyPart = hitType OR colliderBodyId |
| 16 | HKJJLFNGMKO | 0x62 | bool | =damageInfo+0x72 0736f610 | headshot-downgrade marker |
| 17 | EPAOEHEGPHO | 0x63 | bool | =damageInfo+0x20 0736f514 | marker flag |
| 18 | FHBHMKMHCHJ | 0x68 | List<byte> | AKFFMELHGIJ(10,7,tick)+wrap 0736f8d8..f9a8 | anti-cheat token (nonce) |
| 19 | JMJKEBAPBHA | 0x70 | float f32 | not in main path (Cmd382 twin uses it) | (default) |
| 20 | CAHOMGADPGP | 0x74 | bool | not in main path | (default) |
| 21 | AFHGLCCBKCP | 0x76 | ushort varint | PingCounter::CurrentPingValueUInt16 0736f590 | current ping |

Resolved - GMNGCBJMDLB low-24-bits = DAMAGE, and damage IS transmitted. w27 (packed into idx3) is w1
= arg1; the Cheating_* self-flag path proves arg1 is damage (mov w1,#0x2710 =10000 at the suicide
call, CLIENT_TRUST_AUDIT 2.1). So the wire carries damage | (zone<<24). Whether the SERVER reads that
damage or recomputes it is UNKNOWABLE (section 7); the client formula below shows the value is fully
zone-derived, so recomputation is available to the server.

### Damage is zone-selected (client formula, server-recomputable)

FDAEPHMIEPC::KOODEKEKFEK @0x74df4fc computes damage into damageInfo+0x10 (HP) / +0x74 (armour) from
hitInfo+0x58, then the multiplier chain applies the zone factor:
- GLLLEDKLLDA::JBJDLGPLAPB @0x78e40fc: sub w8,hitPart,#1; cmp w8,#0x1b -> jump table on hitPart-1 (28
  entries, byte table @0x192d491). Multiplier from config singleton [0xafd0228]->+0xb8: +0x308 head,
  +0x30c body, +0x310 limb, +0x314 vehicle (ldr s8,[x8,#0x308] @0x78e4270, #0x30c @0x78e4298).
- GLLLEDKLLDA::OFKCCJIDAGD @0x78e5c1c wraps it (bitmask 0x10040300 special-cases zones 8,9,18,28; zone
  4 = vehicle path).
Empirical head:body ratio 2.6-4.2x (project priors). PROVABLE: the client damage number is a pure
function of (weapon, zone, armour) - no client free-parameter damage input reaches the formula, so
flipping the zone flips the multiplier deterministically.

---

## 4. checkParams (idx11 MPECMNGCKJN) decoded

- Built inside KOODEKEKFEK from the hit-info struct (hitInfo+0x34/0x3c/0x58/0x80/0x88 copied into
  damageInfo at 0x74e02f4-0x74e0334), then keyed-permuted in place before send.
- Scramble: FDAEPHMIEPC::IJBAPAJAINA @0x74e71b4 (thin wrapper) -> ICALGMBOIBD::IJBAPAJAINA @0x78bf848,
  args (list, seed, this+0x7f8, this+0x800, 0). Per CLIENT_TRUST_AUDIT 3.3 it copies the list into
  parallel int[]/float[], permutes via OCKMOCGKDAL(seed XOR 0xA3B1C6D9), writes floats back permuted.
- Seed = BHGGAEEHJCO::LMCLIKOCCJM(victim.PlayerID) and the scramble is gated on the victim being on
  another team (BHGGAEEHJCO::DDPFMJDFEDJ compare w28&0xff == w0 at 0x74e0bcc/f0bd4 -> skip on same
  team; scramble at 0x74e0c30 on enemy).
- Assessment: a per-enemy, victim-id-keyed permutation of a float list derived from the hit geometry.
  You do not permute a field the receiver ignores. It is the prime candidate for the server geometry
  cross-check - it plausibly encodes the hit point / collider offsets the server can re-project against
  the claimed zone. PROVABLE: it exists, is geometry-sourced, enemy-only, victim-keyed.
  INFERRED-SERVER: that the server validates its contents against the zone. NOT fully decoded: exact
  float semantics/order (permutation is content-preserving; the pre-scramble population site was not
  isolated without Hex-Rays; KDIPAEGAIFL @0x74daa4c, called immediately before KOODEKEKFEK with the
  same hitInfo + a float in v0, is the likely populator).

---

## 5. Gate analysis (every client-side condition on a Head claim)

1. Headshot-eligibility / downgrade gate 0x74e01e8-0x74e0244 (inside KOODEKEKFEK): if zone==1 (Head)
   AND Player::IsLocalPlayer (0x7064838) AND (Player::IsInNoHeadShotState @0x712e6a8 true OR a virtual
   [klass+0xef8] true) -> damageInfo+0x14 = 2 (Body) and damageInfo+0x72 = 1 (marker -> idx16).
   CLIENT-ENFORCED. Server very likely mirrors it: a Head claim while the shooter is in a no-headshot
   state is the one client-visible condition that makes Head illegitimate. Precondition for a clean
   Head rewrite: shooter NOT in no-headshot state, and idx16 emitted 0.
2. Protection routing HitDetectColliderHelper::IsProtection @0x7b89e40 = return *(int*)(ctx+0x20) == 5
   (validity 1.0 over the body; cmp w8,#5; cset). When true, damage routes to armour: damageInfo+0x10
   = 0, damageInfo+0x74 = damage (0x74e0258-0x74e0264), idx12 carries the armour value. Zone 5 =
   Protection. A Head claim must NOT have zone==5 anywhere.
3. Collider->bodypart resolution GLLLEDKLLDA::KFEOBAJJFEF @0x78e6004 = return hitType | colliderBodyId
   (validity 1.0; orr w0,w19,w20). colliderBodyId = hitInfo+0x80 (0x74e0308), the actual collider
   struck. Result -> idx15. This field ties the claim to a specific collider; it is the structural
   residue that a body->head flip leaves inconsistent unless idx15 is also moved (2c).
4. DEAD-CODE decoy (do not use): PlayerColliderChecker.HitPart (Head=0,Neck=1,Chest=2,Hips=3) - 0
   callers; shifts every zone by one. Live enum is COW.GamePlay.LLEDPGIGCMO (ColliderType: None=0
   Head=1 Body=2 Limb=3 Vehicle=4 Protection=5 ...).

---

## 6. Protection classification table

| protection | class | binary proof |
|---|---|---|
| two-copy zone agreement (idx3-high == idx7) | PROVABLE-STRUCTURAL | same source damageInfo+0x14 (0736f504, 0736f51c); write both -> satisfied |
| token (idx18) covers zone/damage | IRRELEVANT | token = System.Random nonce, XOR key = 0xa1490ec(msg+0x30=tick) (0736f988, x25=msg+0x30); neither nonce nor key reads zone/damage -> untouched token stays valid, no re-wrap |
| damage checksum protects damage | IRRELEVANT / DISPROVEN | token arg is tick (0736f8ac ldr w23,[msg+0x30]), not damage; CHECKSUM_GFHPFJMGEKF 1 |
| server trusts client damage (idx3 low24) | INFERRED-SERVER (assume NO) | damage fully zone-derived client-side (JBJDLGPLAPB); trusting it vs enemies = a one-shot exploit the anti-cheat exists to stop. Assume recompute; section 7 settles it |
| headshot no-headshot-state downgrade | CLIENT-ENFORCED (server likely mirrors) | gate 0x74e01e8; respect by not claiming Head in that state |
| protection/armour routing (zone 5) | CLIENT-ENFORCED | IsProtection @0x7b89e40; do not set zone 5 |
| idx15 collider-id consistency | INFERRED-SERVER | idx15 = hitType OR colliderBodyId, carries struck collider; server could check it matches the zone |
| hit-point (idx9) vs zone geometry | INFERRED-SERVER | mm hit point; server could re-project vs claimed zone |
| checkParams (idx11) geometry cross-check | INFERRED-SERVER (prime suspect) | enemy-only, victim-id-keyed permuted float list (section 4) |
| Cheating_* self-report (idx5 in [-156,-100]) | CLIENT-ENFORCED tripwire | local per-frame checks emit a 106 with negative weaponId; never generate/suppress one |

Skeptical read of the standing hard-boundary verdict: the two inferences it rested on both fail. (1)
"checksum protects damage" - DISPROVEN, the token is a tick-keyed nonce. (2) "the two zone copies must
agree" - trivially satisfiable. What remains is exactly ONE untested boundary: the server-side
geometry cross-check (idx9/idx11/idx15). Everything else is PROVABLE-satisfiable or IRRELEVANT.
SERVER_VALIDATION_MODEL.md 3.7 (ends mid-sentence) should close as: structurally satisfiable; gated
only by an unproven server geometry check.

---

## 7. The empirical experiment (settles server acceptance)

Setup: private/duo room, one cooperating victim, one weapon, fixed engagement distance, land a genuine
Body hit, rewrite that 106 in place.

Hold constant: idx0 victim, idx4 attacker, idx5 weaponId, idx8 tick, idx9 hit point, idx10 hit dir,
idx11 checkParams, idx15 bodyPart, idx16/17 markers, idx18 token. Keep firing cadence and distance
identical trial-to-trial.

Vary (only edit): idx3 high byte 0x02->0x01 AND idx7 0x02->0x01 (2a). Recompute CRC-7, re-encrypt.
Nothing else.

Measure: inbound Cmd 2010 UDP_PLAYER_HURT damage for that victim/tick (and victim EPRI_PLAYER_CUR_HP
delta in Cmd 1900), plus watch for kick/force-sync signature.

Signatures:
- ACCEPT (server recomputes from zone): 2010 damage ~ pre-rewrite body value x (head/body ratio) ~
  2.6-4.2x. Confirms zone-only Body->Head aim works with the minimal 2a rewrite.
- SILENT-REJECT (server recomputes but geometry/zone-mismatch clamps to body, OR ignores client zone):
  2010 damage == unchanged body value; no kick. -> geometry cross-check (idx9/idx11/idx15) is real;
  re-run adding 2c copied from a captured real head-shot to test full-geometry consistency.
- FLAG/KICK: no 2010 for that shot, and/or inbound Cmd 144 FORCE_SYNC_PLAYER_STATE or the known
  transport-kick fingerprint (own position frozen, entities 99-100% frozen, path length 0, then
  silence - SERVER_VALIDATION_MODEL 4). Distinguish from route-fallback self-kick by confirming the
  tunnel stayed up.

Second variant (isolates the geometry check): repeat with 2c ALSO set to a captured real headshot
idx9/idx11/idx15 (rewrite a Body claim into a fully head-consistent claim). If accepted while the
2a-only variant is silent-rejected, the server geometry check is confirmed and the requirement is move
the whole geometry, not just the zone.

Damage-trust control: separate trial rewrite ONLY idx3 low-24 (damage) up by 3x with zone left at
Body. If 2010 follows -> server trusts client damage (aim = pure damage edit, zone irrelevant); if
2010 unchanged -> server recomputes (expected).

---

## 8. What could not be resolved

1. Server geometry re-validation (idx9 hit point / idx11 checkParams / idx15 collider id vs zone) -
   UNKNOWABLE from the client; the section 7 experiment is the only settler. This is the real boundary.
2. Does the server read idx3-low24 damage or recompute? STRONG inference = recompute; not proven from
   client. Section 7 damage-trust control settles it.
3. checkParams exact float semantics/order - permutation is content-preserving but the pre-scramble
   population site (KDIPAEGAIFL @0x74daa4c suspected) not fully decoded without Hex-Rays; only its
   provenance (geometry-sourced, enemy-only, victim-keyed) is proven.
4. idx15 internal bit split between hitType and colliderBodyId - plain OR (0x78e6004), so the two
   components bit ranges (and whether the zone bits are cleanly separable for an in-place edit) were
   not delimited; per-collider colliderBodyId comes from hitInfo+0x80.
5. idx18 XOR key getter 0xa1490ec exact BCL identity - confirmed to read *(int*)(msg+0x30) (tick) and
   return a string; the precise helper is unpinned but does not affect the verdict (key is
   tick-derived, unchanged by a zone rewrite).
