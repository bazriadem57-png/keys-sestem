# Two co-working touches — why injected taps fight the user's fingers, and the only way to fix it

**Status: IMPLEMENTED + proven in a live match (2026-09-18).** The design below
shipped as the Rust daemon `native/touchmux/` (`libnvmux.so`), driven by
`ui/aim/AimInjector.java` over stdin; walk + aim coexist on device. See
`docs/SESSION_2026_09_18_touch_coexistence.md` for the build, the stdin protocol,
and the four bugs fixed after this design doc (SELinux socket→stdin, respawn
storm, slot cross-contamination, swipe location). This doc is the original
research + hardware proof.
Probe sources: `native/uinput-probe/{probe,grab_probe,clone_probe}.c`
Measured on device `R3GL10AHL7P` (Samsung SM-S948U1, Android 14), 2026-09-18.

---

## 0. The question, stated precisely

> Can a synthetic touch and the user's real fingers be held down **at the same
> time**, on the same app, with neither cancelling the other?

Today the answer is **no**, and it is not a tuning problem. This document
establishes why from AOSP source, proves the failure on our own device, and
documents the one architecture that actually works — including proof it works
here, and the four things that can still stop it.

Read §1 if you want the cause, §4 if you want the fix.

---

## 1. Root cause: Android allows **one input device per connection**

### 1.1 The rule, from the commit that introduced it

AOSP commit `2899c55fc54fc13089396eb41b0c919612b1c16a` — *"Allow multi-window
multiple device streams"* — is the origin of our problem. Its message is
unusually explicit:

```
Before this CL, only one device could be active in the system at a given time.
This was enforced early inside the dispatcher code.

In this CL, this restriction is removed, and a new restriction is introduced:
- At most one input device can be active for a given connection

...
TouchState        -> always works in the multi-device mode. Assumes 1 window
                     can receive multiple pointers from different devices.
InputState (per-connection) -> acts as a rejector / multiplexor. It only
                     selects a single device to be active for the given
                     connection.

What happens if there are multiple device streams being sent?
- In general, latest device always wins
- Exception: stylus always takes precedence over other devices
```

Two things in that quote matter more than the rest:

1. **`InputState` is per-connection, and a fullscreen game is one connection.**
   So the rule applies at exactly the granularity that hurts us.
2. **"latest device always wins."** A new device's `ACTION_DOWN` is not merged,
   not queued — it **preempts**. The loser is cancelled.

The CL author also left the door open, explicitly:

> *"In the future, we can consider enabling same-window multi-device streams.
> This would likely require a new public API."*

That API has not been added. Checked through Android 16.

### 1.2 What "cancel" means at the app

`InputDispatcher.cpp` synthesises a real `ACTION_CANCEL`:

```cpp
case EventEntry::Type::MOTION: {
    const MotionEntry& motionEntry = static_cast<const MotionEntry&>(entry);
    if (motionEntry.source & AINPUT_SOURCE_CLASS_POINTER) {
        CancelationOptions options(CancelationOptions::Mode::CANCEL_POINTER_EVENTS, reason);
        synthesizeCancelationEventsForAllConnectionsLocked(options);
    }
```

So the game receives `ACTION_CANCEL` on **all** the user's pointers. Free Fire
reads that as "lift every finger" — the movement stick snaps to neutral and the
fire button releases. Then the user's still-physically-held finger keeps
generating events for a gesture that no longer exists, so they must physically
lift and re-press to recover.

**Symmetric.** Whichever device starts a new gesture last wins. Our `ACTION_DOWN`
kills their gesture; their next `ACTION_DOWN` kills ours. That is exactly the
reported behaviour: *the aim works right up until you touch the screen.*

### 1.3 Why our injected events can never be the touchscreen

The device id of an injected event is **not ours to choose**. `InputDispatcher`
forces it, keeping the caller's only when `POLICY_FLAG_FILTERED` is set — and the
AOSP evidence for that is an asymmetry inside `InputManagerService.java`, between
its two injection call sites:

```java
// (1) the public binder entry point -- what Shizuku calls. NO FLAG_FILTERED.
public boolean injectInputEvent(InputEvent event, int mode) {
    ...
    result = nativeInjectInputEvent(mPtr, event, pid, uid, mode,
            INJECTION_TIMEOUT_MILLIS, WindowManagerPolicy.FLAG_DISABLE_KEY_REPEAT);
}

// (2) the InputFilterHost callback -- the ONLY place the flag is set.
public void sendInputEvent(InputEvent event, int policyFlags) {
    synchronized (mInputFilterLock) {
        if (!mDisconnected) {
            nativeInjectInputEvent(mPtr, event, 0, 0,
                    InputManager.INJECT_INPUT_EVENT_MODE_ASYNC, 0,
                    policyFlags | WindowManagerPolicy.FLAG_FILTERED);
        }
    }
}
```

Only `sendInputEvent` — the `InputFilter` host, which is the accessibility path —
passes `FLAG_FILTERED`; note it also passes `injectorPid = 0, injectorUid = 0`.
The ordinary `injectInputEvent` passes neither, so
`InputDispatcher::injectInputEvent` falls to its default and rewrites the id to
`VIRTUAL_KEYBOARD_ID` (−1). `InputFilter.java` states the same asymmetry from the
other side:

> *"The input filter only receives input events that were generated by an input
> device; the input filter will not receive input events that were injected into
> the system by other means, such as by instrumentation."*

So every event we inject through Shizuku arrives as **device id −1, a different
device from the panel.** It is structurally a second device, and §1.1 then
guarantees mutual cancellation. This is why `AimInjector.deviceId()` returns 0
and documents that it does not matter — the value is discarded upstream.

### 1.4 The accessibility path re-implements the same rule

Worth knowing, because it is the path people reach for second. Android 14 added
`Flags.handleMultiDeviceInput()`, and `AccessibilityInputFilter` grew a
multiplexer whose comment is the rule verbatim:

```java
if (Flags.handleMultiDeviceInput()) {
    if (!shouldProcessMultiDeviceEvent(event, policyFlags)) {
        // We are only allowing a single device to be active at a time.
        return;
    }
}
```

and inside it:

```java
case MotionEvent.ACTION_DOWN:
    if (mLastActiveDeviceMotionEvent != null
            && mLastActiveDeviceMotionEvent.getDeviceId() != motion.getDeviceId()) {
        // This is a new gesture from a new device. Cancel the existing state
        MotionEvent canceled = cancelMotion(mLastActiveDeviceMotionEvent);
        onInputEventInternal(canceled, policyFlags);
    }
```

And the accessibility injector says the quiet part out loud — in
`MotionEventInjector`:

> *"MotionEventInjector would cancel any injected gesture when any MotionEvent
> arrives."*

**Conclusion for §1: the constraint is not about how many pointers exist. It is
about how many *devices* are streaming.** One device with ten pointers is fine.
Two devices with one pointer each is not.

### 1.5 The crucial corollary

> Android's "one device" rule forbids two **devices**, not two **fingers**.

That single sentence is the entire design. Every dead end below tries to make
two devices cooperate. Every working solution **merges into one device before the
framework ever sees the events.**

---

## 2. What we measured on our own hardware

All of the following was run as **uid 2000 / `u:r:shell:s0`** — the identity
Shizuku gives us. **No root at any point.**

### 2.1 Device facts (`getevent -pl`, `/proc`)

| | |
|---|---|
| Real panel | `/dev/input/event8` — `name="sec_touchscreen"`, bus 24, vid:pid `0000:0000`, `INPUT_PROP_DIRECT` |
| Protocol | Type-B multitouch: `ABS_MT_SLOT` **max 9** (→ 10 simultaneous pointers), `ABS_MT_POSITION_X/Y` **max 4095**, `ABS_MT_TRACKING_ID` max 65535 |
| Resolution | Android maps it to **1080x2340**, `mode DIRECT`, `display id 0` |
| Other touch-ish nodes | `event9 sec_touchpad` (a touchpad, `INPUT_PROP_POINTER` — **not** the screen), `event10 sec_touchproximity`, `event12 sec_e-pen` |

`sec_e-pen` being a separate **stylus** device is not a curiosity — see §7.3.

### 2.2 `/dev/uinput` is writable by the shell user

```
crw-rw---- 1 uhid uhid 10, 223 /dev/uinput
uid=2000(shell) groups=...,1004(input),...,3011(uhid) context=u:r:shell:s0
```

Two independent grants line up: the `uhid` **group** (3011) on the node, and the
AOSP SELinux policy, which contains an explicit allow:

```
(allow shell uhid_device (chr_file (ioctl read write getattr lock append map open)))
```

`ueventd.rc` is what creates the node with that group:

```
/dev/uhid   0660 uhid uhid
/dev/uinput 0660 uhid uhid
/dev/input/* 0660 root input
```

**Verified, not inferred:** `dd of=/dev/uinput` succeeded as shell, and a probe
registered a Type-B multitouch device and got:

```
I EventHub:  New device: id=62, path='/dev/input/event14', name='nuvola_probe_touch',
             classes=TOUCH | TOUCH_MT, bus=6, vid:pid=1234:5678
I InputReader: Device reconfigured: id=58, name='nuvola_probe_touch', size 1080x2340,
             orientation Rotation0, mode DIRECT, display id 0
I InputReader: Device added: id=58, ... sources=TOUCHSCREEN
I InputReader: Btn_touch(62): value=1
I InputReader: Touch event's action is 0x0 (id=58, t=0) [pCnt=1, s=0.1 ]
I InputReader: Btn_touch(62): value=0
I InputReader: Touch event's action is 0x1 (id=58, t=0) [pCnt=1, s=]
```

**Android accepted a shell-created virtual touchscreen and consumed its
synthetic DOWN → MOVE → UP as a real tutorial-grade touch gesture.**

### 2.3 The critical half: `EVIOCGRAB` on the real panel **succeeds**

This is the result that makes the whole design possible, and it is the one I
expected to fail.

```
--- /dev/input/event8 ---
  open O_RDONLY   -> OK (fd=3)
      EVIOCGNAME=sec_touchscreen
      ABS_MT_POSITION_X max=4095
      ABS_MT_SLOT max=9
      EVIOCGRAB(1) -> ** SUCCESS ** (exclusive access granted)
      EVIOCGRAB(0) -> released
  open O_RDWR     -> FAIL: Permission denied (errno=13)
```

The nuance is the whole answer. AOSP `system/sepolicy/public/shell.te` contains:

```
# b/30861057: Shell access to existing input devices is an abuse
# vector. The shell user can inject events that look like they
# originate from the touchscreen etc.
neverallow shell input_device:chr_file no_w_file_perms;
```

That `neverallow` removes the **`write`** bit — hence `O_RDWR` → `EACCES`, which
is also why `sendevent` and `minitouch` are dead on modern Android, and why
`getevent` (read-only) still works. **But `EVIOCGRAB` is an `ioctl`, not a
`write()`.** `ioctl` is not in that `neverallow`, and this Samsung ROM's compiled
policy permits it.

So on this device:

* we **cannot** write events into the real panel's node (`sendevent` path — dead)
* we **can** read the real panel's events (`getevent` path — works, already used by `TouchWatcher`)
* we **can** take exclusive ownership of the real panel so its events stop reaching Android

That combination is exactly what the multiplexer needs.

### 2.4 The remaining design risk — and it came back clean

If we clone the panel, does `InputReader` reject a second device with the *same
descriptor*? (A descriptor is a hash of bus/vendor/product/version/name.) If it
deduplicated or refused, the clone could not replace the panel.

It does not. Cloning identity exactly:

```
real:  name='sec_touchscreen' bus=24 vid=0000 pid=0000 ver=0 phys='sec_touchscreen'
clone: created with IDENTICAL identity to the real panel
...
I EventHub: New device: id=63, path='/dev/input/event13', name='sec_touchscreen',
            classes=KEYBOARD | TOUCH | TOUCH_MT, bus=24, vid:pid=0000:0000
D KeyboardLayoutManager: ... descriptor: 840ea35f64a3b00f7a5a1984263302b44c63636b
I InputReader: Device added: id=59, eventHubId=63, name='sec_touchscreen',
            descriptor='840ea35f64a3b00f7a5a1984263302b44c63636b', sources=KEYBOARD | TOUCHSCREEN
I InputReader: Device reconfigured: id=59, name='sec_touchscreen', size 1080x2340,
            orientation Rotation0, mode DIRECT, display id 0
```

**A duplicate descriptor is accepted, not rejected.** No `Duplicate`, no
`Ignoring` — a clean `Device added` with the correct size, DIRECT mode and
display.

**One bug the probe exposed, worth carrying into the implementation:** the clone
came back as `sources=KEYBOARD | TOUCHSCREEN`, and Android bound the generic
keyboard layout to it, because the probe copied **all** of `EV_KEY` from the
panel. A touchscreen clone must copy only `BTN_TOUCH` (+ optionally
`BTN_TOOL_FINGER` / `BTN_TOOL_*TAP`). A virtual device that advertises a full
keyboard range shows up as a physical keyboard and drags keyboard-layout
handling along with it — visible in the log as
`KeyboardLayoutManager: Overlay KLD=.../keyboard_layout_english_us`.

---

## 3. The mental model

```
   WHAT DOES NOT WORK                        WHY
   ─────────────────────────────────────     ────────────────────────────────
   user finger  ──┐                          Two DEVICES. InputState keeps one
                  ├─ device A (panel)        per connection. Latest DOWN wins,
   our inject  ───┘  device B (-1)            the other gets ACTION_CANCEL.

   WHAT WORKS
   ──────────────────────────────────────────────────────────────────────────
   user finger ──► real panel (READ + EVIOCGRAB, so its events stop)
                        │
                        ▼  mirror
                  ┌──────────────────┐
   our inject ───► │  ONE uinput dev  │ ──► ONE device, slots 0..9,
   (IPC)           │  (the clone)     │     N pointers, no second device,
                  └──────────────────┘     nothing to preempt
```

The framework sees **one** touchscreen with **many** pointers. That is precisely
how a two-thumb game session already works — it has never been about pointer
count. This is why the fix is architectural rather than a flag.

---

## 4. The architecture

### 4.1 Shape

A small long-lived native helper ("the multiplexer daemon"), spawned once via
`Shizuku.newProcess` (already reflected in `TouchWatcher.newProcess`), so it runs
as uid 2000. It owns two file descriptors and one socket.

```
   Shizuku (uid 2000)
        │ spawns
        ▼
   ┌──────────────────────────────────────────────────────────┐
   │  multiplexer daemon                                      │
   │                                                          │
   │  fd_real  = open("/dev/input/event8", O_RDONLY|O_NONBLOCK)│
   │  ioctl(fd_real, EVIOCGRAB, 1)   ← panel goes quiet        │
   │  fd_virt  = open("/dev/uinput", O_WRONLY|O_NONBLOCK)      │
   │            clone identity + ABS ranges + DIRECT           │
   │                                                          │
   │  loop:  read fd_real ──► rewrite slot adds ──► write fd_virt
   │         read socket  ──► synthetic ptr  ──► write fd_virt │
   └──────────────────────────────────────────────────────────┘
        ▲ abstract unix socket (low latency, no fs permissions)
        │
   com.nuvola.app  ──  replaces AimInjector's injectInputEvent path
```

### 4.2 Slot allocation — the one rule that must not be broken

The panel reports `ABS_MT_SLOT max 9`, and **the kernel assigns the user's slots
from 0 upward** in the order fingers land. So:

| slots | owner |
|---|---|
| **0 … N−1** | mirrored verbatim from the user's real fingers |
| **9** (highest) | **reserved for the synthetic pointer** |

Reserving the top slot means a synthetic pointer can never collide with a user
finger, no matter how many they place. `ABS_MT_TRACKING_ID` for synthetic
pointers should come from a high, dedicated range (e.g. 60000+) so it can never
alias a real one.

`BTN_TOUCH` is a **device-level "any finger down" flag**. It must be derived from
the *merged* state, not mirrored: set it when any slot (real or synthetic) is
down, clear it only when all are up. Getting this wrong produces exactly the
"stuck in long-press, tap never completes" symptom documented publicly against
naive uinput injectors, where the final `ABS_MT_TRACKING_ID = -1` never lands.

### 4.3 Clone setup, in order

1. `open(real, O_RDONLY|O_NONBLOCK)`.
2. `EVIOCGNAME`, `EVIOCGID`, `EVIOCGPHYS`, `EVIOCGPROP`, `EVIOCGBIT(EV_ABS)`,
   `EVIOCGBIT(EV_KEY)` — read the panel's true identity and capabilities. **Do not
   hardcode** 0..4095 or 10 slots; those are this panel's numbers and the whole
   point of reading them is that another device differs.
3. `open("/dev/uinput", O_WRONLY|O_NONBLOCK)`.
4. `UI_SET_EVBIT` for `EV_SYN`, `EV_KEY`, `EV_ABS`.
5. `UI_SET_KEYBIT` for **`BTN_TOUCH` only** (+ `BTN_TOOL_FINGER` if desired).
   **Never copy the whole `EV_KEY` range** — §2.4.
6. `UI_ABS_SETUP` per axis, with the real `input_absinfo` copied verbatim.
7. `UI_SET_PROPBIT(INPUT_PROP_DIRECT)` — this is what makes it a touch**screen**
   rather than a touch**pad**. Omitting it gives you a mouse-like relative
   device and the coordinates go nowhere useful.
8. `UI_DEV_SETUP` with the real `input_id` and real name; then `UI_DEV_CREATE`.
9. **Sleep ~700 ms before the first event.** AOSP's own `cmds/uinput` documents
   this: the device is not ready until `InputReader` has enumerated it, and
   *"any commands sent to the device during that time will be dropped."*
10. Only now `ioctl(fd_real, EVIOCGRAB, 1)`.
11. On `UI_DEV_DESTROY`/exit: release the grab **first**, then destroy.

### 4.4 Four traps in the mirror loop, and how each shows up

These come from the kernel's own `Documentation/input/multi-touch-protocol.rst`
and from the slot-protocol design discussion, and each one fails in a way that
looks like something else.

**(a) Slots are per-contact and stable, not per-event.** The protocol switches
the active slot with `ABS_MT_SLOT` and then sends that slot's changed attributes;
the core "will only emit events for slots with modified MT events." So a naive
"read an event, write an event" loop is *nearly* correct — but it can collide:
the panel assigns from slot 0 up, so a nine-finger user reaches slot 9, which is
our reserved slot.

> **Do not mirror slot numbers verbatim. Remap.** Keep an explicit
> `real→virt` slot map and place the user's contacts in `0 … top-1`, keeping
> `top` (the panel's maximum, 9 here) exclusively ours. Emit `ABS_MT_SLOT` before
> each slot's attribute block, which is exactly what the protocol expects.

**(b) A finger already down when you grab is a "latecomer" the kernel will not
resend.** This is the subtlest failure and it is the one that would produce a
bug report like *"the aim is dead until I lift my thumb"*. The input protocol is
change-driven: if the receiver was not present when a contact was created, it
never learns about it, and — in the words of the protocol discussion — the
symptom is that you *"can wriggle your finger around and nothing happens, but
once you lift it goes 'well, now it works again'."* `SYN_DROPPED` normally
causes a full state resync, but **`EVIOCGRAB` is not `SYN_DROPPED`**, so nothing
resyncs.

> **Only grab while no fingers are down.** Read `ABS_MT_TRACKING_ID` for every
> slot (`EVIOCGMTSLOTS`) and refuse to arm until all are `-1`. This is a
> concrete, load-bearing use for the `TouchWatcher` we are otherwise making
> redundant — and it is the real reason to keep it.

**(c) Slot reuse is how a contact ends.** The kernel frees a slot when its
contact is destroyed (`ABS_MT_TRACKING_ID = -1`) and may hand it to a new
contact. A mirror that caches slot state must invalidate on the `-1`, or the next
contact on that slot inherits stale coordinates for one packet.

**(d) `BTN_TOUCH` is device-level.** Covered above: derive it from merged state,
never mirror it. This is the single most-reported bug in naive uinput injectors —
"stuck in long-press, the tap never completes" — and it is always this.

### 4.5 Low-overhead shaping (8 ms budget)

`AimInjector` currently ticks at 8 ms (125 Hz). A daemon that does
`read()` per event and `write()` per event will spend a lot of syscalls on a
panel that emits ~5 events per finger per frame. Three cheap rules:

1. **`O_NONBLOCK` on both fds**, drain the real panel in a tight `while(read() >
   0)` loop rather than blocking per event.
2. **Coalesce to one `SYN_REPORT` per iteration.** Accumulate the changed slots,
   emit them, then a single `EV_SYN/SYN_REPORT`. The kernel applies state on the
   sync, so intermediate syncs are pure overhead.
3. **`poll()` with a timeout that is also your heartbeat deadline.** One
   syscall serves both the event wait and the §6 watchdog, instead of a sleep
   plus a separate timer.

### 4.6 Verifying it without a game

Cheapest possible end-to-end check, before Free Fire is involved: enable
**Settings → Developer options → Pointer location** (or run
`getevent -lt /dev/input/eventN` on the *clone's* node). Hold one finger on the
screen and have the daemon inject a synthetic pointer. The overlay must show
**two** simultaneous pointers that move independently.

If it shows one, the mirror is dropping the user's contact; if the user's pointer
dies the instant the synthetic one appears, the merge failed and you are back to
two devices — which means the grab did not take, or the app is talking to the
old `injectInputEvent` path.

### 4.7 Why an abstract unix socket for the app↔daemon link
`TouchWatcher` already proved the pattern of spawning a shell-uid process. For
the control channel:

* an **abstract** socket (`\0nuvola_inject`) needs **no filesystem node** and no
  write permission anywhere — it is a name in the kernel's abstract namespace;
* line-oriented, so a dropped message is a dropped line rather than a desync;
* one socket beats `adb shell` stdin for latency, which is the same reason
  scrcpy uses one.

Protocol shape (deliberately minimal):

```
D <slot> <x_norm> <y_norm>     finger down   (coords normalised 0..65535)
M <slot> <x_norm> <y_norm>     finger move
U <slot>                       finger up
Q                              quit
```

Normalised coordinates matter: the daemon knows the panel's `ABS_MT_*` maxima
from `EVIOCGABS`, and Android scales those to the display. Sending raw display
pixels couples the app to this panel's resolution.

---

## 5. What this buys, and what it costs

### Buys

* **True simultaneity.** The user's movement thumb and fire button stay down
  *while* the aim drags. No `ACTION_CANCEL` in either direction.
* **No yield-and-retry dance.** `AimInjector.yieldToTouch`, `holdMs`,
  `regripMs`, `checkStall()`'s stall detection and the whole re-grip machinery
  exist *only* to work around mutual cancellation. With one device they become
  unnecessary. (Keep `TouchWatcher` — it is still useful to know whether the user
  is touching, e.g. to avoid fighting a deliberate look-drag.)
* **Lower latency.** No binder round trip into `system_server` per event; the
  events go straight into the kernel input subsystem.
* **Not `INJECT_EVENTS`.** This is the documented bypass for ROMs that block the
  `injectInputEvent` path outright — uinput events enter as hardware, so no
  signature permission is consulted.

### Costs — state these to the user plainly

1. **`EVIOCGRAB` is a single point of failure for *all* touch input.** While held,
   the real panel's events reach only us. If the daemon hangs while holding the
   grab and does not exit, **the screen is dead until it does.** The kernel
   releases the grab when the fd closes, so the true hazard is a *live but
   wedged* process, not a crash.
   *Mitigation is mandatory, see §6.*
2. It is **device-specific**. Slot count, axis maxima, `phys`, and whether
   `EVIOCGRAB` is permitted at all are all per-ROM. §2.3 passing on a Samsung
   SM-S948U1 says nothing about a Xiaomi or a Pixel — the `neverallow` above is
   stock and some ROMs tighten further.
3. It is a **more invasive mechanism** than anything currently in this app. The
   VPN reads packets. This takes ownership of the touchscreen. The `AIM_PLAN.md`
   risk section applies with more force here, not less.
4. `sec_e-pen` (event12) is a **separate stylus device** and is *not* covered by
   grabbing `event8`. A stylus press during a grab would be a second device and
   would cancel the merged stream. If stylus use matters, it needs its own grab
   and mirror into the same clone — or it must be accepted as a known hole.

---

## 6. Safety design — non-negotiable

`TouchWatcher`'s class comment already named this hazard and chose not to take
it on: *"a crash there blanks input until reboot."* If this is built, that risk
has to be engineered down, not accepted.

1. **Watchdog lease.** The daemon holds the grab only while it has heard from the
   app within a timeout (a few hundred ms to a couple of seconds). No heartbeat →
   release the grab → exit. This turns "wedged daemon" into "input returns".
2. **`EVIOCGRAB(0)` in a signal handler and on every exit path**, including
   `SIGTERM`, `SIGINT` and `SIGPIPE`. The `finally`-equivalent must run even on
   the abnormal path.
3. **A physical escape hatch that does not need the screen.** Volume-down via
   `gpio-keys` (event0) still works while the touch panel is grabbed, because it
   is a different device. Bind it to "release grab and exit". This is the belt to
   the watchdog's braces — it is usable by a player mid-match with one hand.
4. **Fail-open on every setup step.** If any of `EVIOCGRAB`, clone registration
   or the 700 ms readiness wait fails, exit *without* holding the grab. Never
   leave a half-built state where the panel is silenced and nothing replaces it.
5. **Verify the clone is enumerated before grabbing.** Order matters: create the
   clone, wait, confirm it appears (`InputDevice.getDeviceIds()` from the app, or
   an `InputDeviceListener`), and only then grab. Grabbing first leaves a window
   with no touch input at all.
6. **Grab only while no finger is down.** Not a safety rule but a correctness one
   with a safety-shaped failure: a contact that exists at grab time is a
   "latecomer" the change-driven protocol will never resend (§4.4b), so the user
   would have to lift and re-press. So a user mid-drag-and-shoot is also a user
   who must not be grabbed *yet*. Wait for all `ABS_MT_TRACKING_ID == -1`.
7. **Teardown on app death.** If `FloatingOverlayService` dies, the daemon must
   not survive holding the panel. Tie the lease to the app's process.

---

## 7. Public prior art, and what each is actually worth

### 7.1 `openstf/minitouch` — the canonical read/write evdev injector

`minitouch` (and `minicap`'s sibling tooling) injects by writing directly into
`/dev/input/eventN`. It is *the* reference implementation for low-latency,
multi-pointer injection.

**Its applicability to us is now settled and it is a hard no:** issue #41
documents that Android 10 added exactly the `neverallow shell
input_device:chr_file no_w_file_perms;` quoted in §2.3, producing

```
avc: denied { write } for name="event7" ... scontext=u:r:shell:s0
      tcontext=u:object_r:input_device:s0 tclass=chr_file permissive=0
```

This is the same wall our `O_RDWR` → `EACCES` hit, confirmed independently on a
completely different device. **The `sendevent` / direct-write family is closed on
modern Android without root.** Do not spend time here.

*Value: high as a negative result and as a pointer-transport design; zero as a
path.*

### 7.2 The uinput clone/mirror pattern — the design we want, in the wild

**`Xtr126`'s gist, "Android: mirror touchscreen as touchpad (uinput)"** is the
closest published implementation of the core idea, and it is worth reading in
full before writing a line of the daemon:

* enumerates `/dev/input/*`, opens each `O_RDONLY`;
* filters to genuine touchscreens by testing `INPUT_PROP_DIRECT` (a touchpad has
  `INPUT_PROP_POINTER` — the same distinction that bit our clone in §2.4);
* builds a uinput device **copying the source's capabilities**
  (`EVIOCGBIT(EV_ABS)` → `UI_ABS_SETUP`, `EVIOCGBIT(EV_KEY)` → `UI_SET_KEYBIT`);
* `EVIOCGRAB(1)` on the real device, then forwards every `struct input_event`
  verbatim to uinput;
* toggles with volume keys (`gpio-keys`) — the escape hatch of §6.3;
* release path calls `EVIOCGRAB(0)` and `UI_DEV_DESTROY`.

It mirrors as a **touchpad** (relative) rather than a touchscreen, so it is not a
drop-in, but its structure is exactly §4.3.

**`CalcProgrammer1/TouchpadEmulator`** is the same pattern in C with the cleanest
separation of `enable_touchpad()` / `disable_touchpad()` around
`EVIOCGRAB`/`UI_DEV_DESTROY`, and it detects the touchscreen by capability
(`BTN_TOUCH` + `ABS_MT_SLOT` + position axes) — a more robust test than a name
match.

**`kp7742/TouchSimulation`** (Go) does the inverse and is worth knowing for one
reason: it **bridges a Type-B device to Type-A**, documenting in code that the
two multitouch protocols are not interchangeable. If the clone is created with
the wrong protocol style the pointers arrive but the game sees them oddly.

*Value: high. §4.3 is essentially these three, adapted.*

### 7.3 Stylus coexistence — the one place Android already allows two pointers

`InputDispatcher`'s multi-device commit carves out a single exception:

> *"Exception: stylus always takes precedence over other devices."*

`AccessibilityInputFilter`'s tests (`testStylusWithTouchInTheMiddle`) show a
stylus gesture and a touch gesture being **tracked and cancelled independently**
across the same window. So a stylus *can* be down at the same time as a finger.

This is genuinely interesting and it is **not a shortcut for us**: it requires
being a *real stylus device* (`sec_e-pen` already occupies that role on this
device), and "stylus takes precedence" means it cancels touch rather than
coexisting with it in a merged stream. Recorded because it is the only
framework-sanctioned case of two pointer sources in one window, and because it is
the mechanism behind any "pen and finger together" feature.

*Value: conceptual; not a path.*

### 7.4 `aka-munan/keysync` — Shizuku-based key mapping, honest about its limits

An open-source Android keymapper that maps keyboard/mouse to touch using
**Shizuku**, no root. It is the closest published project to our current
`AimInjector`, and it confirms the shape we already have. Two things are worth
noting:

* it advertises an "anti-detection" mechanism (randomised touches), which is the
  same class of signal-shaping `AIM_PLAN.md` §4 discusses;
* it is **built for physical keyboard and mouse**, and its README admits
  *"Emulator support may be limited due to input constraints."* That is the
  one-device rule showing through: with a peripheral *device* generating input,
  it is a second device, and coexistence is the same problem.

*Value: confirms the Shizuku baseline and its ceiling. Does not solve coexistence.*

### 7.5 Game keymappers (Octopus, Panda Gamepad Pro, KeyMapper)

Octopus markets *"no root or activator required"* and works on non-rooted
devices, so it is not doing §4. Worth being precise about why, because it is the
question a reader will ask:

* **`keymapperorg/KeyMapper`** is explicit that its basic mechanism is an
  **AccessibilityService**, and its own documentation and issue tracker are where
  the "gestures cancel your touches" limitation is publicly acknowledged (closed
  upstream as **"Can't fix"**). §1.4 is the reason.
* Octopus's marketing copy requires *"the same permissions as the games you
  play"* and ships a plugin — consistent with a privileged-access path rather
  than an accessibility-only one, but the mechanism is not published. **Do not
  treat vendor marketing as a technical claim.**

*Value: establishes that the commercial, no-root keymappers either yield to the
user's gesture or require privileges. None of them publish a technique that
merges streams.*

### 7.6 The `uinput` device *is* the documented non-root bypass for `INJECT_EVENTS`

Worth recording as an independent confirmation of §4's direction. A published
injector describes the motivation directly:

> *"This bypasses MIUI's `INJECT_EVENTS` block (which kills the InputManager /
> `adb shell input` path) because uinput events enter the kernel input subsystem
> as if from real hardware — no permission required, only group access to
> `/dev/uinput` (shell is in that group)."*

That is precisely the mechanism §2.2 proved works here. (Note the published
implementation is a fragment and its `uinput_user_dev`-era code is partly
corrupted; read it for the idea, not the source.)

### 7.7 USB OTG HID — the only fully undetectable option

Carried over from `AIM_PLAN.md` §4, unchanged and still true: AOA 2.0 lets a host
register a **real HID digitizer**. It is a real kernel device, it coexists
correctly, and it has the lowest latency of any option. It is *still* a second
device, so §1.1 applies — the difference is that **two real HID devices are a
supported configuration** (this is how a gamepad plus the touchscreen already
works), whereas an injected stream is not.

*Value: the ceiling, if hardware is ever acceptable. Not a software path.*

---

## 8. Verification log

Everything below was executed, not reasoned. Reproduce with
`native/uinput-probe/`.

| # | Claim | Method | Result |
|---|---|---|---|
| 1 | `/dev/uinput` writable by uid 2000 | `dd of=/dev/uinput` as shell | **PASS**, exit 0 |
| 2 | Shell can create a virtual **touchscreen** | `probe.c` → `getevent -pl`, logcat | **PASS**, `sources=TOUCHSCREEN`, `mode DIRECT`, 1080x2340 |
| 3 | Android consumes its synthetic gesture | logcat `InputReader` | **PASS**, `Btn_touch value=1` → `action 0x0` → `value=0` → `action 0x1` |
| 4 | Real panel readable by shell | `open(O_RDONLY)` on event8 | **PASS**, `EVIOCGNAME=sec_touchscreen` |
| 5 | **`EVIOCGRAB` on the real panel allowed** | `ioctl(fd, EVIOCGRAB, 1)` | **PASS** — the enabling result |
| 6 | `O_RDWR` on the real panel denied | `open(O_RDWR)` | **FAIL, EACCES** — expected; `sendevent` path closed |
| 7 | Duplicate descriptor accepted, not deduped | `clone_probe.c` + logcat | **PASS**, clean `Device added`, same descriptor hash |
| 8 | Clone identity/geometry correct | logcat | **PASS**, `size 1080x2340, mode DIRECT, display id 0` |
| 9 | Copying all `EV_KEY` is a bug | logcat | **Found.** Clone came back `sources=KEYBOARD | TOUCHSCREEN` + keyboard layout bound |
| 10 | Not yet tested: end-to-end merged gesture under grab | — | **OPEN** |
| 11 | Not yet tested: game receives both pointers | — | **OPEN** |
| 12 | Not yet tested: `Shizuku.newProcess` daemon holds grab stably | — | **OPEN** |
| 13 | Only the `InputFilter` host sets `POLICY_FLAG_FILTERED` | AOSP `InputManagerService.java`, both injection call sites | **PASS** — quoted in §1.3 |
| 14 | Slots are per-contact and stable; only changed slots are emitted | Kernel `multi-touch-protocol.rst` + slot-protocol design thread | **PASS** — drives the slot-remap rule, §4.4a |
| 15 | A contact present before the receiver attaches is never resent | Same (the "latecomer" case) | **PASS** — drives the grab-only-when-idle rule, §4.4b / §6.6 |

**Rows 10–12 are the gate.** Do not build the production daemon before they pass.

---

## 9. What this means for the existing code

| existing piece | verdict |
|---|---|
| `AimInjector.inject()` / `IInputManager` reflection / `ShizukuBinderWrapper` | **Replaced.** The binder path is the second device. Keep the code until the daemon is proven, then remove. |
| `AimInjector.yieldToTouch`, `holdMs`, `regripMs`, `regrip()`, `checkStall()` | **Becomes unnecessary** — all four exist solely to survive mutual cancellation. Keep the *stall* idea; the re-grip will not be needed. |
| `AimInjector` controller (ring lag compensator, `axisStep`, deadzone hysteresis) | **Keep verbatim.** This is the valuable half and is independent of the transport. |
| `TouchWatcher` | **Keep — for a second reason now.** The original justification (yield to the user) becomes unnecessary, but §4.4b and §6.6 need exactly the same information to decide *when it is safe to grab*. Do not delete it with the yield logic. |
| `AimInjector.deviceId()` returning 0 | **Keep the comment** — it documents the `VIRTUAL_KEYBOARD_ID` rewrite that motivates §4. |
| `Slot.AIM_*` | Ten of fourteen are still unwired (see the DIAG audit). Add daemon slots as `AIM_MPX_*` when this lands. |

---

## 10. Open questions to settle before implementation

1. **Rows 10–12 above.** In particular: with the panel grabbed and the clone
   live, does a full two-finger user gesture *plus* a synthetic pointer arrive at
   the game as three simultaneous pointers? Nothing less settles the design.
2. **Does the grab survive a game in the foreground?** `InputReader` may
   reconfigure devices on focus change.
3. **What does the `surfaceflinger`/`InputReader` path do on a second
   `EVIOCGRAB`** if the app restarts without the daemon noticing?
4. **Do we need to mirror `sec_e-pen` too** (§5.4), or is stylus use an accepted
   hole?
5. **Free Fire's own input handling** — does it read raw `MotionEvent` pointer
   ids, or does it normalise through Unity's `Input.touches`? This decides
   whether our slot choice is observable to the game at all.
6. **Detection surface.** A `BUS_VIRTUAL` device with vid:pid `0000:0000` is
   visible in `getevent` and to any app enumerating input devices. The grabbed
   panel's own node still exists. `AIM_PLAN.md` §7's ban-risk section applies to
   this decision directly and it is the owner's call, not an engineering one.

---

## 11. The one-paragraph version

Android's `InputDispatcher` keeps **one input device active per connection**, and
a fullscreen game is one connection; a new device's `ACTION_DOWN` cancels the
running gesture. Our Shizuku-injected events are forced to device id −1, so they
are *structurally* a second device and can never merge with the panel — which is
why the aim works until you touch the screen, and why yielding was the only sane
stopgap. Android forbids two **devices**, not two **fingers**. The fix is
therefore to stop being a second device: as uid 2000 we can (a) write
`/dev/uinput` and register a virtual touchscreen — **verified**, Android
enumerates it as `sources=TOUCHSCREEN` and consumes its gestures; and (b)
`EVIOCGRAB` the real panel — **verified**, despite `neverallow shell
input_device:chr_file no_w_file_perms`, because `EVIOCGRAB` is an `ioctl` and not
a `write()`. So grab the panel, mirror it through one uinput clone that carries
the panel's own identity (**verified**: a duplicate descriptor is accepted, not
rejected), reserve the top slot for our synthetic pointer, and the framework sees
one device with N pointers. Also verified, and easy to get wrong: do not copy the
panel's whole `EV_KEY` range or the clone registers as a keyboard. The costs are
real — `EVIOCGRAB` is a single point of failure for all touch input, so a
heartbeat lease, a release-on-every-exit-path, and a volume-key escape hatch are
mandatory, not optional.

---

## 12. Sources

**AOSP — authoritative**

- Multi-device commit (the rule's origin):
  https://android.googlesource.com/platform/frameworks/native/+/2899c55fc54fc13089396eb41b0c919612b1c16a
- `AccessibilityInputFilter.java` (multiplexer, "only allowing a single device"):
  https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/services/accessibility/java/com/android/server/accessibility/AccessibilityInputFilter.java
- `MotionEventInjector.java` ("would cancel any injected gesture"):
  https://android.googlesource.com/platform/frameworks/base/%2B/refs/heads/main/services/accessibility/java/com/android/server/accessibility/MotionEventInjector.java
- `InputFilter.java` (injected events excluded from the filter; `POLICY_FLAG_FILTERED`):
  https://android.googlesource.com/platform/frameworks/base/+/HEAD/core/java/android/view/InputFilter.java
- `InputManagerService.java` (both injection call sites — only `sendInputEvent`
  sets `FLAG_FILTERED`):
  https://android.googlesource.com/platform/frameworks/base/+/a2910d0/services/java/com/android/server/input/InputManagerService.java
- `InputDispatcher.cpp` (`synthesizeCancelationEvents`, cancellation modes):
  https://android.googlesource.com/platform/frameworks/native/+/fe46a177d53b3045080de207287a43996e43e958/services/inputflinger/dispatcher/InputDispatcher.cpp
- `rootdir/ueventd.rc` (`/dev/uinput 0660 uhid uhid`):
  https://android.googlesource.com/platform/system/core/+/refs/heads/main/rootdir/ueventd.rc
- `cmds/uinput` (JSON/evemu protocol; the ~700 ms readiness requirement):
  https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/cmds/uinput
- Kernel `uinput` documentation:
  https://docs.kernel.org/input/uinput.html

**The `neverallow` that closes the direct-write path**

- `public/shell.te`, Android Q → S:
  https://android.googlesource.com/platform/system/sepolicy/+/refs/heads/android-s-beta-4/public/shell.te
- Confirmed in the field, `openstf/minitouch` issue #41:
  https://github.com/openstf/minitouch/issues/41
- `system_app`/`shell` uhid allow rules, worked example:
  https://github.com/Team-Encoder/A1AndroidControlFix

**The pattern to implement**

- Mirror-touchscreen-via-uinput, capability copying + grab + volume-key toggle:
  https://gist.github.com/Xtr126/c5de3932490758f2cbac44f8a6c3206e
- Same pattern, cleanest grab/destroy lifecycle:
  https://github.com/CalcProgrammer1/TouchpadEmulator
- Type-B → Type-A bridging caveat:
  https://github.com/kp7742/touchsimulation

**Shizuku-era prior art**

- `aka-munan/keysync` — Shizuku keymapper, no root, honest limitations:
  https://github.com/aka-munan/keysync
- `keymapperorg/KeyMapper` — accessibility-based; the "gestures cancel your
  touches" limitation is acknowledged upstream ("Can't fix"):
  https://github.com/keymapperorg/KeyMapper
- Octopus (mechanism unpublished — marketing only, not evidence):
  https://www.apkmirror.com/apk/octopus-gaming-studio/

**In-repo**

- `docs/AIM_PLAN.md` §4 — the injection-path comparison this document extends
- `ui/aim/AimInjector.java` — the binder path being replaced; controller retained
- `ui/aim/TouchWatcher.java` — names the `EVIOCGRAB` risk this document takes on
