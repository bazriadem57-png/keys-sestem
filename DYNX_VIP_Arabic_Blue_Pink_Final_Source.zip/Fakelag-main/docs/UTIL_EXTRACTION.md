# UTIL_EXTRACTION — duplicate low-level logic inventory and shared-API spec

**Scope.** Every piece of duplicated byte/number/varint logic in
`fakelag/fakelag-beta/app/src/main/java/com/fakelag/cryhard8/` (97 Java files,
31 467 lines), with the exact copies, a real diff of their contracts, the
proposed shared signatures, and a call-site migration table.

**This document does not design the package tree.** That is
`docs/ARCHITECTURE_TARGET.md`. This one answers only: *what is duplicated, do
the copies actually agree, what should the shared API look like, and which
edits are risky.*

**Constraints assumed throughout:** Java 8, minSdk 21, no `Optional`, no
streams, **no per-call allocation** — the existing out-param / index-return
style (`int[] pos`, "returns next index", `long` packed value+length) is
preserved deliberately, not replaced with a returned object.

---

## 0. Method

All paths below are relative to
`fakelag/fakelag-beta/app/src/main/java/com/fakelag/cryhard8/`.
Commands were run from that directory.

```bash
# 1. every declaration that looks like a low-level helper
rg -n '(static|private|public|protected).*\b(vi|skipVarints?|readVarint|varint|writeVarint|writeCanonical|writeZigzag|zigzag|zz|ensure|clamp|clampI|hex|toHex|hexOf|varintWidth)\s*\(' --glob '*.java'

# 2. every varint bit-twiddle, including inline copies with no helper at all
rg -n '0x80|0x7f|0x7F' --glob '*.java' -c

# 3. zigzag, in every spelling
rg -n '>>> 1\) \^ -\(|>> 1\) \^ -\(|<< 1\) \^ \(' --glob '*.java'

# 4. canonical LEB128 writers
rg -n '>>>= 7' --glob '*.java'

# 5. scratch-buffer growth
rg -n 'new byte\[Math\.max' --glob '*.java'

# 6. hex formatting
rg -n '0123456789|Integer\.toHexString|String\.format\(.*%02|HEX' --glob '*.java'

# 7. clamps
rg -n 'Math\.max\(.*Math\.min|static (float|int|double|long) clamp|clamp\w*\(' --glob '*.java'

# 8. byte-order helpers / checksums
rg -n '&\s*0xff\)\s*<<\s*8|<<\s*8\)\s*\|\s*\(' --glob '*.java'

# 9. TEA key-schedule caches
rg -n 'Character\.digit|keyScheduleHex|Tea\.schedule' --glob '*.java'
```

Every copy listed below was read **in full** before being declared identical or
different.

---

## 1. Duplication inventory

Legend for the verdict column:

- **IDENTICAL** — same behaviour on every input, including truncation and
  overflow. Mechanical extraction.
- **EQUIVALENT** — different code, provably the same behaviour. Mechanical, but
  the proof is written out below so nobody re-derives it.
- **DIFFERENT** — the copies disagree on at least one input. The spec says which
  one wins. These are the only risky edits.

---

### 1.1 LEB128 unsigned varint — **value read**

Sixteen implementations. They fall into six contract families, which is the
point: the duplication is not just redundancy, it is *six different answers to
"what happens when the buffer runs out"*.

| # | Location | Form | Truncation / overflow result | Max bytes |
|---|---|---|---|---|
| R1 | `net/WireReader.java:47-60` `u()` | cursor object | sets `bad`, returns `0`; **latches** (`if (bad) return 0` at entry) | 10 |
| R2 | `net/BodyDecoderText.java:288-299` `Cur.varint()` | cursor object | sets `bad`, returns `0`; **does not latch** | 10 |
| R3 | `esp/EspEngine.java:1027-1038` `vi(byte[], int[], int)` | out-param cursor | returns `-1`, parks `pos[0] = end` | 10 |
| R4 | `dev/capture/DecodedDumper.java:649-660` `vi(byte[], int[], int)` | out-param cursor | returns `-1`, parks `pos[0] = end` | 10 |
| R5 | `esp/EspEngine.java:522-532` `readVarint(byte[], int, int)` | value only | returns `-1` | 10 |
| R6 | `net/AimBiasExperiment.java:132-143` `readVarint(byte[], int, int)` | value only | returns `-1` | 10 |
| R7 | `net/SessionTimeline.java:884-894` `readVarint(byte[], int, int)` | value only | returns `Long.MIN_VALUE` | 10 |
| R8 | `dev/capture/LobbyCapture.java:668-678` `varint(byte[], int, int)` | value only | returns `Long.MIN_VALUE` | 10 |
| R9 | `net/PriSync.java:125-139` `varint(byte[], int, int)` | **packed** `(value & 2^56-1) \| (len << 56)` | returns `-1L` | 10 |
| R10 | `filter/AimFilter.java:1070-1083` `skipVarint(byte[], int, int)` | next index + **`lastVal` field side-channel** | returns `-1`; **leaves `lastVal` stale** | 10 |
| R11 | `net/PositionSync.java:113-127` | inline in `parse()` loop | `return false` from the enclosing parse | 10 |
| R12 | `net/VisibilityMask.java:72-91` | inline in `observe()` | `return false` | 10 |
| R13 | `filter/GamePacketTaxonomy.java:716-729` `bodyVarint` | inline inner loop | returns `-1` | 10 |
| R14 | `net/AimBias.java:194-209` `readVarints` | inline inner loop, bulk | **accepts a truncated tail** (see below) | 10 |
| R15 | `esp/EspEngine.java:551-576` `varints` | bulk, returns `long[]` | returns `null` | 10 |
| R16 | `dev/capture/DecodedDumper.java:199-217` `varints` | bulk, returns `long[]` | returns `null` | 10 |

#### What they agree on (verified, not assumed)

**The 10-byte cap is universal.** Two different guards appear — `shift += 7; if
(shift > 63) fail` (R1-R8, R10-R16) and `if (++n > 9) fail`
(`filter/MarkFilter.java:326-329`, skip-only). They are the same:

- shift guard: shifts run 0, 7, … 63. The 10th byte is read and ORed at
  shift 63 (only its bit 0 survives); if it terminates, accept — otherwise
  shift becomes 70 and we fail.
- count guard: `n` counts continuation bytes. After 9 continuations `n == 9`,
  not `> 9`, so the 10th byte is read; terminator → accept, continuation →
  `n == 10 > 9` → fail.

Both accept exactly 1-10 bytes. **No behaviour change from unifying on either.**

`net/PriSync.java` uses a third spelling (`n < 10` in the loop condition, no
shift guard) which also caps at 10 bytes.

#### What they disagree on — **DIFFERENT**

**D1 — `net/AimBias.java:194-209` silently accepts a truncated final varint.**
The inner loop has no `done` flag:

```java
while (i < end) {
    int c = b[i++] & 0xff;
    v |= (long) (c & 0x7f) << shift;
    if ((c & 0x80) == 0) break;      // <- the only way out that means "complete"
    shift += 7;
    if (shift > 63) return -1;
}
vals[n++] = v;                       // <- reached ALSO when i hit end mid-varint
...
return (i == end) ? n : -1;
```

A body ending with a continuation byte falls out of the inner loop on
`i < end`, the partial value is stored, and `i == end` then reports success.
Every other bulk reader (R15, R16) returns `null` for that input.

*Correct behaviour: reject.* The protocol is an untagged positional stream
(`docs/PROTOCOL_MASTER.md` §2) — a body that does not tile exactly into varints
has been mis-identified, and R15/R16's `null` is the behaviour the rest of the
codebase is built on. **Affected call site: `net/AimBias.java:186`
(`readVarints`) only.** `AimBias` is toggle-gated and documented as disproven
(`core/PacketLoop.java:185-198`), so the blast radius is one experiment.

**D2 — `filter/AimFilter.java:1070-1083` leaves `lastVal` stale on failure.**
`readVarintAt` (1090-1093) calls `skipVarint` and then *unconditionally* reads
`lastVal`, so a truncated read returns the previous field's value rather than a
sentinel. The javadoc claims "the walk has already proved the varint terminates
before it", which is true for the current six call sites — but it is a
precondition carried in prose, not in the type. The shared API must make it
explicit (see §2, `Leb128.readAt`).

**D3 — latching.** `WireReader.u()` refuses to read once `bad` is set;
`BodyDecoderText.Cur.varint()` does not. In practice `BodyDecoderText.run()`
(line 336) tests `c.bad` before every op, so the latch is a no-op there —
adopting `WireReader`'s latching behaviour is safe. Verified: every `Cur` method
call in `BodyDecoderText` (22 sites) is reached only from `run()` or from
`positional()` (line 431), which also tests `c.bad` immediately after each read.

**D4 — sentinel collision (latent, not currently reachable).** `-1` (R3-R6,
R9, R10, R13) and `Long.MIN_VALUE` (R7, R8) are both legal decodings of a
10-byte varint. In this protocol no field exceeds 2^56 (`net/PriSync.java:121`
masks to 56 bits on that basis), so neither is reachable today. The shared API
keeps the `-1` convention but documents it as "valid only because the protocol
has no 57-bit fields".

#### Call-site counts

| Helper | Call sites |
|---|---|
| `EspEngine.vi` | 12 (lines 1059, 1061-1063, 1071, 1075-1077, 1083-1086) |
| `DecodedDumper.vi` | 11 (608, 610-612, 620-622, 628-631) |
| `EspEngine.readVarint` | 1 (686) |
| `EspEngine.varints` | 4 (676, 947, 1525, 1556) |
| `DecodedDumper.varints` | 10 (350, 375, 377, 378, 410, 454, 549, 853, 943, 964) |
| `AimFilter.skipVarint` | 3 (1004, 1061, 1091) |
| `AimFilter.readVarintAt` | 6 (466, 471, 480, 513, 517, 548) |
| `SessionTimeline.readVarint` | 3 (824, 833, 846) |
| `LobbyCapture.varint` | 3 (622, 631, 640) |
| `PriSync.varint` | 2 (92, 105) |
| `GamePacketTaxonomy.bodyVarint` | 2 (787, 820) |
| `AimBiasExperiment.readVarint` | 1 (inline caller at 110-129 duplicates it again) |
| `WireReader.u()/z()/rawByte()/str()` | 14 across `esp/MatchRoster.java` (7) and `esp/EspEngine.java:1780-1815` (7) |
| `BodyDecoderText.Cur.*` | 22 |

---

### 1.2 LEB128 — **skip only** (index return)

| Location | Guard | Verdict |
|---|---|---|
| `net/PositionSync.java:300-309` `skipVarint` | shift > 63 | reference |
| `filter/MarkFilter.java:324-332` `skipVarint` | `++n > 9` | **EQUIVALENT** (proof in §1.1) |
| `filter/GamePacketTaxonomy.java:771-780` `skipOneVarint` | shift > 63 | **IDENTICAL** to `PositionSync` |
| `esp/EspEngine.java:534-546` `skipVarints(…, count)` | shift > 63 | **IDENTICAL**, n-ary |
| `dev/capture/DecodedDumper.java:256-268` `skipVarints(…, count)` | shift > 63 | **IDENTICAL**, byte-for-byte the same as `EspEngine`'s |
| `net/WireReader.java:96-98` `skipU(int n)` | delegates to `u()` | different: discards the index, sets `bad` |

All return **the index just past the varint(s), or `-1` when truncated**. One
contract, five copies.

Call sites: `PositionSync` 1 (line 108) · `MarkFilter` 2 (228, 237) ·
`GamePacketTaxonomy` 1 (765) · `EspEngine.skipVarints` 2 (674, 877) ·
`DecodedDumper.skipVarints` 2 (274, 543).

**Load-bearing:** the javadoc on `EspEngine.skipVarints` (lines 514-521) and
`DecodedDumper.skipVarints` (245-255) both record the same measurement — a fixed
`b12` body offset gave **0/190** accepted keepalives, the derived offset gives
**190/190**, because the object handle is 4 *or* 5 bytes. That comment must
survive the move; it is the reason the helper exists at all.

---

### 1.3 Varint **count / parse-all**

| Location | Extra behaviour | Verdict |
|---|---|---|
| `esp/EspEngine.java:551-576` `varints` | growable `long[32]`, returns exact-size copy | reference for the array form |
| `dev/capture/DecodedDumper.java:199-217` `varints` | growable `long[64]`, `Arrays.copyOf` | **EQUIVALENT** (only the initial capacity differs) |
| `filter/GamePacketTaxonomy.java:697-713` `countVarints` | **also fails when `n > 16`** | **DIFFERENT — deliberate** |
| `net/AimBias.java:194-209` `readVarints` | caps at `MAX_VARINTS`, writes into a field | **DIFFERENT — bug D1** |

`countVarints`'s `n > 16` is not an overflow guard, it is a **shape gate** used
by `isTeamAssignment` (expects exactly 8) and `isPositionKeepalive` (expects
exactly 23 — see below). If it is extracted, the cap must become a parameter,
never a constant, or the 23-varint test breaks.

> Note the apparent contradiction: `countVarints` rejects `n > 16` yet
> `isPositionKeepalive` (line 767) compares the result to 23. The cap is applied
> to the *body after* `skipOneVarint`, and the early `return -1` means the
> `== 23` test can never pass through this path — this is pre-existing and out
> of scope here, but flag it to whoever owns `filter/`. `isPositionKeepalive` is
> already `@Deprecated` in favour of `Cmd.isOwnPositionCarrier(cmd)`.

---

### 1.4 Canonical (minimal-width) LEB128 **write**

| Location | Bounds-checked? | Returns |
|---|---|---|
| `filter/AimFilter.java:945-956` `writeCanonical` | **no** | next index |
| `filter/MarkFilter.java:335-347` `writeZigzag` | **no** | next index (zigzag-encodes first) |
| `net/PositionSync.java:267-280` (inline in `rebuild`) | **yes** — `if (p >= scratch.length) return -1` | via enclosing method |
| `net/AimBias.java:211-230` `writeVarints` | **yes** — `if (p >= scratch.length) return -1` | byte count, or -1 |

The write loop is byte-identical in all four. The only difference is the
bounds check. **DIFFERENT, and the difference matters:** `PositionSync.rebuild`
returns `-1` on overflow so the caller *withholds the packet* — documented at
lines 234-235 and 284 (`"no room: caller withholds"`). That path must not be
lost.

Resolution: ship **both** — an unchecked `write` (for callers that sized the
buffer themselves, i.e. `AimFilter` and `MarkFilter`, which both call
`ensure(...)` immediately beforehand) and a checked `writeBounded` returning
`-1`. See §2.

Call sites: `AimFilter.writeCanonical` 4 (871, 872, 873, 908) ·
`MarkFilter.writeZigzag` 3 (266, 267, 268) · `PositionSync` 1 (inline) ·
`AimBias.writeVarints` 1.

---

### 1.5 **Padded** (non-canonical, fixed-width) LEB128 write

| Location | Verdict |
|---|---|
| `net/PositionSync.java:186-190` (inline in `setSigned`) | reference |
| `filter/AimFilter.java:1110-1116` `writeVarintPadded` | **IDENTICAL** |

```java
for (int k = 0; k < width - 1; k++) { b[start + k] = (byte)((u & 0x7F) | 0x80); u >>>= 7; }
b[start + width - 1] = (byte)(u & 0x7F);
```

**Load-bearing, do not "fix" into a canonical write.** `PositionSync`'s class
javadoc (lines 27-38) records the measurement this depends on: over **18 178
real reports, 58% of velocity fields are a single byte** (±63 units = ±0.066 m,
capping a ramp at **1.15 m/s**), and non-canonical padding is legal because
*the game itself emits it* (`8a 8a 00` = 1290). The padded path is the one that
keeps the packet byte-length identical so no `Length` repair and no re-CRC of a
resized packet is needed.

Call sites: `PositionSync` 1 · `AimFilter.writeVarintPadded` 5 (651, 653, 697,
698, 699).

---

### 1.6 Varint width

| Location | Verdict |
|---|---|
| `net/PositionSync.java:312-316` `varintWidth(long)` | **only copy — already shared** |

Already `public static` and already used cross-package: 2 internal call sites
(170, 184) + 6 in `filter/AimFilter.java` (555, 578, 579, 606, 607, 608).
Pure move, zero risk.

---

### 1.7 Zigzag decode

| Location | Expression | Verdict |
|---|---|---|
| `net/WireReader.java:63-66` `z()` | `(v >>> 1) ^ -(v & 1L)` | correct |
| `net/PositionSync.java:322-324` `zigzagDecode` | `(u >>> 1) ^ -(u & 1L)` | correct |
| `esp/EspEngine.java:599-601` `zz` | `(v >>> 1) ^ -(v & 1L)` | correct |
| `net/BodyDecoderText.java:303-306` `Cur.zigzag()` | `(v >>> 1) ^ -(v & 1L)` | correct |
| `net/BodyDecoderText.java:436` (inline) | `(v >>> 1) ^ -(v & 1L)` | correct |
| `dev/capture/DecodedDumper.java:646` `zz` | **`(v >> 1) ^ -(v & 1)`** | **DIFFERENT — wrong** |

**D5 — `DecodedDumper.zz` uses an arithmetic shift.** It is a literal
transliteration of the Python reference in `docs/PROTOCOL_MASTER.md` §2.1
(`zz = lambda v: (v >> 1) ^ -(v & 1)`), which is correct in Python because
Python ints are unbounded and non-negative here. In Java with `long` it differs
from the other five copies for any `v` with bit 63 set — i.e. a genuine 10-byte
varint, and also the `-1` failure sentinel (`>>` gives `0`, `>>>` gives
`Long.MIN_VALUE`).

*Correct behaviour: `>>>`.* Five copies to one, and `>>>` is the protobuf
`sint64` definition.

*Is it currently reachable?* No. Traced: in both `EspEngine.parseStructured`
(1058-1094) and `DecodedDumper.parseChain` (604-643) a truncated `vi` parks the
cursor at `end`, every later `vi` also returns -1, and the mandatory trailing
tick-varint check (`left = end - pos[0]; if (left < 1 || left > 3) return false`)
then rejects the record **before** any value reaches `zz`. So the fix is
behaviour-preserving on all real input — but it is still a *fix*, and the
migration table flags it.

**Load-bearing semantics to preserve verbatim in the moved javadoc**
(`esp/EspEngine.java:578-598`, `docs/PROTOCOL_MASTER.md` §2.1):
`|zz(v3),zz(v4),zz(v5)| = 100.000` on **100%** of keepalives across two full
matches (p1 99.37 / p50 100.00 / p99 100.65); enemies-within-30°-of-view went
0.226 → 0.438 and 0.341 → 0.480 purely from decoding zigzag; and **encoding is
per field** — `v13/v14/v15` are raw float32 bit patterns and `v22` is a plain
counter, so zigzag must never be applied blindly.

Call sites: `EspEngine.zz` 16 · `DecodedDumper.zz` 3 (697, 698, 699) ·
`PositionSync.zigzagDecode` 4 (156 + `AimFilter` 517, 549, 1006) ·
`WireReader.z()` (via `str()` and callers) · `BodyDecoderText` 2.

---

### 1.8 Zigzag encode

| Location | Verdict |
|---|---|
| `net/PositionSync.java:318-320` `zigzagEncode` | `(v << 1) ^ (v >> 63)` — reference |
| `filter/MarkFilter.java:336` (inline in `writeZigzag`) | `(v << 1) ^ (v >> 63)` — **IDENTICAL** |

Call sites: `PositionSync.zigzagEncode` 9 (170, 182, 191, 213 + `AimFilter` 565,
569, 596, 597, 598) · `MarkFilter` 3 (via `writeZigzag`).

---

### 1.9 uint32 bits → float32

| Location | Verdict |
|---|---|
| `esp/EspEngine.java:604-606` `f32` | `Float.intBitsToFloat((int)(u & 0xffffffffL))` |
| `dev/capture/DecodedDumper.java:220-222` `f32` | **IDENTICAL**, byte for byte |

Plus three uncached inline uses in `net/AimBias.java:124-126, 171-173` and two
in `net/BodyDecoderText.java:376, 438`.

Call sites: `EspEngine` 3 (708 ×3) · `DecodedDumper` 9 (421 ×3, 457 ×3, 967 ×3).

---

### 1.10 Scratch-buffer growth

| Location | Behaviour |
|---|---|
| `filter/AimFilter.java:1136-1139` `ensure(byte[], int)` | `len >= n ? buf : new byte[max(n, 512)]` |
| `filter/MarkFilter.java:349-351` `ensure(byte[], int)` | **IDENTICAL** (ternary spelling) |
| `net/PacketPipeline.java:273-281` `scratchFor(int)` | **DIFFERENT** — ThreadLocal, `MAX_SCRATCH` cap → `null`, assigns |
| `dev/capture/CaptureAnnotator.java:351-358` `scratchFor(int)` | **DIFFERENT** — static field, `MAX_SCRATCH` cap → `null`, floor 1024 |

`AimFilter`/`MarkFilter` are identical and share the awkward "returns the buffer,
caller must re-assign the field" idiom (`plain = ensure(plainScratch, payLen);
plainScratch = plain;`). Extract those two. The two `scratchFor` variants own
their storage and their cap policy — **leave them**, they are not the same
function.

Call sites: `AimFilter.ensure` 4 (448, 704, 863, 931) · `MarkFilter.ensure` 3
(210, 260, 280).

---

### 1.11 Hex formatting

| Location | Sink | Case | Bounds | Notes |
|---|---|---|---|---|
| `dev/capture/DecodedDumper.java:306-309` `hex2(int)` | **new `String` per byte** | upper | n/a | allocates 2 objects per byte |
| `dev/capture/DecodedDumper.java:311-315` `hexOf(byte[],int,int)` | `StringBuilder` | upper | clamps to `d.length` | calls `hex2` per byte |
| `dev/capture/DecodedDumper.java:663-668` `hexRange(byte[],int,int)` | `StringBuilder` | upper | returns `""` on bad range; **caps at 96 bytes** | calls `hex2` per byte |
| `dev/capture/LobbyCapture.java:592-599` `hex(StringBuilder,…)` | `StringBuilder` | upper | **none** | `char[] HEX` table |
| `net/BodyDecoderText.java:466-473` `appendHex(StringBuilder,…)` | `StringBuilder` | upper | clamps to `b.length` | `char[] HEX` table |
| `dev/capture/CaptureWriter.java:194-197 + 536-541` | **`byte[]`** | upper | caller-sized | `byte[] HEX` table |
| `dev/capture/CaptureWriter.java:666-678` `putHexInt(byte[],int,int)` | `byte[]` | upper | caller-sized | minimal-width int, not bytes |
| `net/LobbyKeySniffer.java:134-141` `toHex(byte[])` | `String` | **lower** | whole array | `Character.forDigit` |

**DIFFERENT in three ways:** sink type, case, and bounds policy.

- Case: `LobbyKeySniffer.toHex` is the odd one out, and deliberately — its
  output is compared against `lastKeyHex()` and the sniffer's own
  `isLowerHex()` validator (line 216). **Must stay lowercase.**
- Bounds: `LobbyCapture.hex` will throw on a bad range where `hexOf` and
  `appendHex` silently clamp. Since `LobbyCapture.hex` is only called with
  ranges it just validated (528, 563), adopting the clamping version is safe.
- Sink: `CaptureWriter`'s `byte[]` form is on the allocation-free capture-writer
  path (class javadoc line 17, "allocation-free queue straight to disk").
  **Do not collapse it into the `StringBuilder` form.**

Decoding direction: `net/LobbyKeySniffer.java:278-287` `decodeHex(byte[],…)`
(bytes → bytes) and the three inline `Character.digit` loops in §1.13 are a
separate, smaller duplicate.

Call sites: `hex2` 6 · `hexOf` 4 (346, 384, 835, 875) · `hexRange` 1 (586) ·
`LobbyCapture.hex` 2 (528, 563) · `appendHex` 1 (447) ·
`CaptureWriter` inline 1 · `putHexInt` 2 (525, 587) · `toHex` 1.

---

### 1.12 ASCII dump

| Location | Substitution |
|---|---|
| `net/BodyDecoderText.java:459-464` `appendAscii` | non-printable **or `"`** → `.` |
| `dev/capture/LobbyCapture.java:696-703` `ascii` | `"` → `'`, everything else passed through raw |
| `dev/capture/LobbyCapture.java:688-695` `isPrintable` | `0x20..0x7e` gate, `len == 0` → false |

**DIFFERENT.** Both exist to keep a quoted CSV/text field intact, but they
substitute differently and `ascii` assumes `isPrintable` already ran. Low value;
share only `isPrintable`, or leave both. Flagged for completeness, not
recommended for extraction.

---

### 1.13 Session key hex → TEA schedule (with cache)

| Location | Storage | Verdict |
|---|---|---|
| `net/BodyCrypt.java:35-51` `schedule()` | `public static`, **volatile** fields | reference — already the shared one |
| `filter/AimFilter.java:1120-1134` `schedule()` | `private` instance fields | **IDENTICAL logic**, redundant cache |
| `dev/capture/CaptureAnnotator.java:335-349` `schedule()` | `private static`, **non-volatile** | **IDENTICAL logic**, unsafe publication |

All three: `LobbyKeySniffer.lastKeyHex()` → length-32 check → 16× `Character.digit`
pair → `Tea.schedule(key)` → cache keyed on the hex string. `AimFilter`'s own
comment (line 1118) says *"mirrors CaptureAnnotator.schedule"*.

This is not a `util/` extraction — `BodyCrypt.schedule()` **already exists and is
public**. Delete the other two and call it. `CaptureAnnotator`'s non-volatile
static is also a real (if benign-in-practice) visibility bug that the
consolidation removes for free.

Call sites: `AimFilter.schedule()` 3 · `CaptureAnnotator.schedule()` 2.

---

### 1.14 Clamp

| Location | Signature | NaN |
|---|---|---|
| `esp/EspTuning.java:727-730` `clamp(float,float,float)` | float | **NaN → lo** |
| `esp/EspTuning.java:732-734` `clampI(int,int,int)` | int | n/a |
| `filter/AimFilter.java:363-366` `clampF(float,float,float)` | float | **NaN → lo** — IDENTICAL to `EspTuning.clamp` |
| `overlay/AimInjector.java:820-822` `clampF(float,float,float)` | float | **no guard — NaN propagates** |
| `overlay/EspRenderView.java:1796-1798` `clamp255(int)` | int, fixed 0..255 | n/a |
| `net/AimBias.java:161-163` `clamp(double)` | double, fixed ±1.0 | no guard |
| `overlay/CrosshairView.java:125-135` `clampCrosshairSize/Alpha` | int, fixed bounds | n/a |
| `replay/ReplayEngine.java:128` `clampTeleReplayDelayMs` | int, fixed bounds | n/a |
| inline `Math.max(lo, Math.min(hi, v))` | `esp/EspEngine.java:1923`, `dev/capture/DecodedDumper.java:424, 582, 802`, `overlay/AimInjector.java:545-546` | — |

**DIFFERENT on NaN.** `EspTuning.clamp` and `AimFilter.clampF` are byte-identical
including the `Float.isNaN(v) return lo` guard. `AimInjector.clampF` has no
guard, so `clampF(NaN, 2f, screenH-2f)` returns `NaN` and the injector plants a
gesture at a NaN coordinate. Adopting the guarded version is almost certainly
an improvement, but it *is* a behaviour change on the aim path — see the
migration table.

The fixed-bound clamps (`clamp255`, `AimBias.clamp`, the crosshair pair,
`clampTeleReplayDelayMs`) are domain policy, not generic maths. They should call
a shared clamp internally but keep their own named entry points.

Call sites: `EspTuning.clamp` **78** · `EspTuning.clampI` 6 · `AimFilter.clampF`
2 (321, 342) · `AimInjector.clampF` 6 · `clamp255` 2 · `AimBias.clamp` 1.

---

### 1.15 Ones-complement (internet) checksum

| Location | Accumulator | Return |
|---|---|---|
| `core/PacketBuilder.java:108-121` `cksum(byte[],int,int)` | **`int`** | `(short)(~sum)` |
| `core/TcpProxy.java:470-487` `checksum(byte[],int,int)` | `long` | `(int)(~sum & 0xffff)` |
| `core/TcpProxy.java:489-511` `tcpChecksum(…)` | `long` | `(int)(~sum & 0xffff)` — same fold loop, plus an IPv4 pseudo-header prologue |

**DIFFERENT, marginally.** The 16-bit word fold and the end-around carry are
identical. `PacketBuilder` uses an `int` accumulator: a 64 KiB buffer of `0xFF`
bytes sums to 32 768 × 0xFFFF ≈ 2.147 × 10^9, which is right at `Integer.MAX_VALUE`
— it does not overflow for the ≤ 1500-byte IP/ICMP packets it is used on, but
the `long` version is the one to keep.

The pseudo-header prologue in `tcpChecksum` is protocol-specific and stays where
it is; only the fold loop is shared.

Call sites: `PacketBuilder.cksum` 3 (37, 76, 84) · `TcpProxy.checksum` 1 (433) ·
`TcpProxy.tcpChecksum` 1 (458).

---

### 1.16 Big-endian byte access

| Location | Verdict |
|---|---|
| `core/PacketBuilder.java:125-127` `ri(byte[],int)` (BE32 read) | reference |
| `core/TcpProxy.java:514-517` `getInt(byte[],int)` | **IDENTICAL** |
| `dev/capture/LobbyCapture.java:490-493` `be32(byte[],int)` | **IDENTICAL** |
| `core/PacketBuilder.java:130-132` `rs(byte[],int)` (BE16 read) | reference |
| `core/TcpProxy.java:100-101, 106` (inline BE16) | **IDENTICAL**, 3 inline copies |
| `core/TcpProxy.java:519-524` `putInt(byte[],int,int)` (BE32 write) | only copy |
| `net/PriSync.java:98` (inline **LE**16) | different endianness — `ReadFixUInt16` |
| `net/BodyDecoderText.java:318-323` `Cur.fixU16()` (LE16) | matches `PriSync:98` |

`ri` / `getInt` / `be32` are three byte-for-byte copies of the same four-line
function. Zero risk.

Call sites: `PacketBuilder.ri` 1 (`core/PacketLoop.java:58`) ·
`PacketBuilder.rs` 3 (`PacketLoop` 59, 60, 85) · `TcpProxy.getInt` 4 ·
`TcpProxy.putInt` 4 · `LobbyCapture.be32` (internal).

---

### 1.17 Protobuf tag-walk primitives (lobby TCP)

| Location | Verdict |
|---|---|
| `net/SessionTimeline.java:884-894` `readVarint` + `896-903` `varintLen` | reference |
| `dev/capture/LobbyCapture.java:668-678` `varint` + `680-687` `varLen` | **IDENTICAL**, both functions, both sentinels (`Long.MIN_VALUE`) |

And the *callers* are the same shape too — `SessionTimeline.walkModeFields`
(818-861) and `LobbyCapture.dumpProtobuf` (615-660) both do
`tag = readVarint(...); p += varintLen(...)`, then the same
wire-type 0/1/2/5 dispatch.

`varintLen` has its own contract quirk worth writing down: on a truncated
buffer it returns the number of bytes **scanned** (and `0` when `off >= end`),
not `-1`. Callers rely on the paired `readVarint` having already returned the
`BAD` sentinel, so the length is never used on a failure path. Keep that, but
document it.

The read-then-measure pattern decodes each varint **twice**. Worth collapsing
into one packed read (like `PriSync`'s) — but this is the lobby TCP path, not
the UDP packet thread, so it is a tidiness win, not a performance one.

Call sites: 3 + 3 in each file.

---

## 2. The proposed shared API

Exact signatures. Every one is `static`, allocation-free, and primitive-only.
No `Optional`, no boxing, no varargs, no returned arrays on any hot-path method.

### `util/Leb128.java`

```java
package com.fakelag.cryhard8.util;

/**
 * LEB128 varints: the wire encoding of every scalar in the game's body stream.
 * No protocol knowledge lives here -- these are the bit rules only.
 *
 * <h3>Universal contract</h3>
 * <ul>
 *   <li>A varint is 1..10 bytes. The 10th byte contributes only its bit 0
 *       (shift 63); an 11th continuation byte is malformed.</li>
 *   <li>Every read is bounded by {@code end} (exclusive) and never throws.</li>
 *   <li>{@code -1} is the failure sentinel for both value and index returns.
 *       As a VALUE it is ambiguous in principle -- a 10-byte all-ones varint
 *       decodes to -1 -- but no field in this protocol exceeds 2^56, so it is
 *       unreachable. Do not reuse this class for a format where it is not.</li>
 * </ul>
 */
public final class Leb128 {

    private Leb128() { }

    /** Largest legal encoded width. */
    public static final int MAX_BYTES = 10;

    // ---- read ----

    /**
     * Reads the varint at {@code pos[0]} and advances the cursor past it.
     *
     * <p>On truncation or overflow: returns {@code -1} and <b>parks the cursor
     * at {@code end}</b>, so a caller that keeps reading gets -1 for every
     * subsequent field and can detect the failure once, at the end, instead of
     * branching per field. This is the contract
     * {@code EspEngine.parseStructured} and {@code DecodedDumper.parseChain}
     * are built on: they validate by requiring the trailing tick varint to
     * still be there.</p>
     */
    public static long read(byte[] b, int[] pos, int end);

    /**
     * Reads the varint at {@code i} without a cursor.
     *
     * @return the value, or {@code -1} when truncated or overlong
     */
    public static long readAt(byte[] b, int i, int end);

    /**
     * Reads the varint at {@code i}, returning value and width packed into one
     * long: {@code (value & VALUE_MASK) | ((long) width << WIDTH_SHIFT)}.
     *
     * <p>For callers that need both and must not allocate. Use
     * {@link #valueOf} and {@link #widthOf} to unpack. Returns {@link #PACKED_BAD}
     * on failure.</p>
     *
     * <p><b>The value is truncated to 56 bits.</b> That is safe for this
     * protocol and is what {@code net/PriSync} has always done.</p>
     */
    public static long readPacked(byte[] b, int i, int end);

    public static final int  WIDTH_SHIFT = 56;
    public static final long VALUE_MASK  = (1L << WIDTH_SHIFT) - 1L;
    public static final long PACKED_BAD  = -1L;

    public static long valueOf(long packed);
    public static int  widthOf(long packed);

    // ---- skip ----

    /** Index just past one varint, or -1 when truncated. */
    public static int skip(byte[] b, int i, int end);

    /** Index just past {@code count} varints, or -1 when the data runs out. */
    public static int skip(byte[] b, int i, int end, int count);

    /**
     * Exact varint count for {@code b[from..end)}, or -1 when the range does
     * not tile into whole varints.
     *
     * @param max stop and fail once more than this many are seen -- a shape
     *            gate, not an overflow guard. Pass {@link Integer#MAX_VALUE}
     *            for "no limit".
     */
    public static int count(byte[] b, int from, int end, int max);

    // ---- write ----

    /** Minimum bytes needed to encode {@code u}. Never 0; 1 for u == 0. */
    public static int width(long u);

    /**
     * Writes {@code u} canonically (minimal width). <b>Unbounded</b> -- the
     * caller must have sized the buffer, e.g. via {@link Buffers#ensure}.
     *
     * @return the next index
     */
    public static int write(byte[] b, int p, long u);

    /**
     * Writes {@code u} canonically, refusing to run past {@code cap}.
     *
     * @return the next index, or -1 when it would not fit -- in which case
     *         {@code b} may have been partially written and the caller must
     *         discard the whole buffer (which is what
     *         {@code PositionSync.rebuild} does: it withholds the packet)
     */
    public static int writeBounded(byte[] b, int p, int cap, long u);

    /**
     * Writes {@code u} as LEB128 padded to exactly {@code width} bytes.
     *
     * <p>Non-canonical padding is legal and the game emits it itself
     * ({@code 8a 8a 00} = 1290). This is the write that keeps a packet's byte
     * length identical, so no Length field repair is needed. The caller
     * guarantees {@code width(u) <= width}; nothing is checked.</p>
     */
    public static void writePadded(byte[] b, int start, int width, long u);
}
```

### `util/ZigZag.java`

```java
package com.fakelag.cryhard8.util;

/** Protobuf sint32/sint64 zigzag. Pure bit maths; no protocol knowledge. */
public final class ZigZag {

    private ZigZag() { }

    /**
     * {@code (u >>> 1) ^ -(u & 1)}.
     *
     * <p>The shift is LOGICAL. The Python reference in
     * {@code docs/PROTOCOL_MASTER.md} §2.1 writes {@code >>}, which is correct
     * there because Python ints are unbounded -- in Java it is wrong for any
     * value with bit 63 set. See UTIL_EXTRACTION §1.7 (D5).</p>
     */
    public static long decode(long u);

    /** {@code (v << 1) ^ (v >> 63)} -- this shift IS arithmetic. */
    public static long encode(long v);
}
```

### `util/Bits.java`

```java
package com.fakelag.cryhard8.util;

/** Fixed-width byte access and bit reinterpretation. */
public final class Bits {

    private Bits() { }

    /** uint32 bit pattern -> float32, bit-exact. */
    public static float f32(long u);

    public static int  be32(byte[] b, int off);
    public static int  be16(byte[] b, int off);
    public static void putBe32(byte[] b, int off, int v);
    public static void putBe16(byte[] b, int off, int v);

    /** Two raw little-endian bytes -- the game's {@code ReadFixUInt16}. */
    public static int le16(byte[] b, int off);

    /**
     * RFC 1071 ones-complement sum over {@code b[off..off+len)}, folded, NOT
     * inverted. Callers that need a checksum invert and mask themselves; callers
     * that need a pseudo-header seed it into {@code start}.
     *
     * <p>{@code long} accumulator: an {@code int} one is within a factor of two
     * of overflowing on a 64 KiB buffer.</p>
     */
    public static long onesComplementSum(byte[] b, int off, int len, long start);

    /** {@code (int) (~onesComplementSum(b, off, len, 0) & 0xffff)}. */
    public static int checksum16(byte[] b, int off, int len);
}
```

### `util/Buffers.java`

```java
package com.fakelag.cryhard8.util;

/** Reusable scratch growth for the packet threads. */
public final class Buffers {

    private Buffers() { }

    /** Minimum allocation when a grow is needed. */
    public static final int MIN = 512;

    /**
     * {@code buf} if it already holds {@code n} bytes, else a new
     * {@code byte[max(n, MIN)]}. <b>The caller must re-assign its field</b> --
     * this cannot do it, and that is the existing idiom:
     * {@code plain = ensure(plainScratch, n); plainScratch = plain;}
     *
     * <p>Contents are NOT preserved: every caller overwrites before reading.</p>
     */
    public static byte[] ensure(byte[] buf, int n);
}
```

### `util/Num.java`

```java
package com.fakelag.cryhard8.util;

/** Clamps. Separate from Bits so the ESP/overlay side does not pull in wire code. */
public final class Num {

    private Num() { }

    /** NaN maps to {@code lo} -- a NaN must never escape into a screen coordinate. */
    public static float  clamp(float v, float lo, float hi);
    public static double clamp(double v, double lo, double hi);
    public static int    clamp(int v, int lo, int hi);
    public static long   clamp(long v, long lo, long hi);
}
```

### `util/Hex.java`

```java
package com.fakelag.cryhard8.util;

/** Hex formatting. Three sinks because the three callers have three budgets. */
public final class Hex {

    private Hex() { }

    /** UPPERCASE, clamped to {@code b.length}; out-of-range is a no-op, never a throw. */
    public static void append(StringBuilder sb, byte[] b, int off, int len);

    /** As {@link #append}, stopping after {@code maxBytes} source bytes. */
    public static void append(StringBuilder sb, byte[] b, int off, int len, int maxBytes);

    /**
     * UPPERCASE into a caller-sized {@code byte[]}; returns the next index.
     * Allocation-free -- this is the capture-writer path.
     */
    public static int put(byte[] out, int p, byte[] src, int off, int len);

    /** Minimal-width uppercase hex of an int into a byte[]; returns the next index. */
    public static int putInt(byte[] out, int p, int v);

    /** lowercase -- the session key's canonical form, compared against lastKeyHex(). */
    public static String toLower(byte[] b, int off, int len);

    /** Bytes of ASCII hex -> binary; null when malformed or odd-length. */
    public static byte[] decode(byte[] src, int off, int len);

    /** Hex String -> {@code out}; false when malformed. No allocation. */
    public static boolean decodeInto(String hex, byte[] out);
}
```

### `decode/` — the protocol-aware layer

These move rather than get created; they already exist and already carry the
measurements.

```java
package com.fakelag.cryhard8.decode;

/**
 * Cursor over a decrypted message body, implementing GCommon.FastBinaryReader's
 * NON-UNIFORM rules -- moved from net/WireReader, merged with the private
 * BodyDecoderText.Cur.
 *
 *   U / Z / float  -> ONE LEB128 varint (type changes interpretation, not length)
 *   B              -> ONE RAW BYTE, not a varint  <- the classic desync
 *   S              -> ZIGZAG byte-length, then that many raw UTF-8 bytes
 *   FixUInt16      -> TWO RAW LITTLE-ENDIAN BYTES
 *
 * {@code bad} latches: once set, every read returns 0/null without advancing.
 */
public final class BodyReader {
    public BodyReader(byte[] buf, int off, int len);
    public boolean hasMore();
    public int     position();
    public boolean bad();
    public long    u();            // LEB128
    public long    z();            // zigzag
    public int     rawByte();      // B
    public int     fixU16();       // FixUInt16, little-endian
    public String  str(int maxLen);// S: zigzag length + UTF-8
    public void    skipU(int n);
}
```

```java
package com.fakelag.cryhard8.decode;

/**
 * Body-offset arithmetic for handle-led messages.
 *
 * <p>THE BODY DOES NOT START AT A FIXED OFFSET. It follows the object-handle
 * varint at b8, which is 4 OR 5 bytes depending on the value -- in a training
 * match the local handle is 0x10000010, which needs five. Measured: 0/190
 * keepalives accepted at a fixed b12, 190/190 when the offset is derived.</p>
 */
public final class BodyOffsets {
    /** Index of the first body byte after {@code n} leading handle varints, or -1. */
    public static int afterHandles(byte[] b, int start, int end, int n);
}
```

Everything else that is protocol-shaped — `PositionSync`'s field indices,
`GamePacketTaxonomy`'s shape gates, `PriSync`'s EPRI grammar, `Cmd`, `MsgKey`,
`HeaderLayout` — keeps its current home for now; placing them is
`ARCHITECTURE_TARGET.md`'s job.

---

## 3. Call-site migration table

`R` = risky (behaviour differs). Everything unmarked is mechanical.

### Varint read

| Current call | New call | R |
|---|---|---|
| `esp/EspEngine.java` 1059, 1061-1063, 1071, 1075-1077, 1083-1086 — `vi(d, pos, end)` | `Leb128.read(d, pos, end)` | |
| `dev/capture/DecodedDumper.java` 608, 610-612, 620-622, 628-631 — `vi(r.payload, pos, end)` | `Leb128.read(...)` | |
| `esp/EspEngine.java:686` — `readVarint(data, off+8, end)` | `Leb128.readAt(...)` | |
| `net/AimBiasExperiment.java` (inline loop 110-129 + `readVarint`) | `Leb128.readAt(...)` | |
| `net/SessionTimeline.java` 824, 833, 846 + 826, 835, 848 | `Leb128.readPacked` once instead of read+len twice | **R1** |
| `dev/capture/LobbyCapture.java` 622, 631, 640 + 624, 633, 642 | same | **R1** |
| `net/PriSync.java` 92, 105 | `Leb128.readPacked` | |
| `filter/GamePacketTaxonomy.java` 787, 820 (`bodyVarint`) | `BodyOffsets.afterHandles` + `Leb128.readAt` | |
| `net/VisibilityMask.java:72-91` (inline) | `Leb128.readPacked` + `widthOf == payloadLength` | |
| `net/PositionSync.java:113-127` (inline) | `Leb128.readPacked` per field | **R2** |
| `filter/AimFilter.java` 466, 471, 480, 513, 517, 548 (`readVarintAt`) | `Leb128.readAt` | **R3** |
| `filter/AimFilter.java` 1004, 1061 (`skipVarint` for index) | `Leb128.skip` | |
| `net/AimBias.java:186` (`readVarints`) | `Leb128.readAt` in a loop with a `done` check | **R4** |
| `esp/EspEngine.java` 676, 947, 1525, 1556 (`varints`) | keep local — see §4 | |
| `dev/capture/DecodedDumper.java` ×10 (`varints`) | keep local — see §4 | |

**R1** — `SessionTimeline` / `LobbyCapture`: the current code decodes each varint
twice (`readVarint` then `varintLen`). Collapsing to one `readPacked` changes
nothing *provided* the caller keeps treating a `BAD` return as fatal before
using the width. Both already do. Low risk, but it is a rewrite of the walk loop,
not a rename.

**R2** — `PositionSync.parse`: the inline loop also records `starts[k]` and
`widths[k]`. `readPacked` gives the width directly, so `widths[k] = widthOf(p)`
and `starts[k] = i` before the advance. Same values. The risk is purely
transcription — this loop is the one that must consume the body *exactly*
(`if (i != end) return false`, line 128), and that check must survive.

**R3** — `AimFilter.readVarintAt`: today a truncated read returns the *previous*
field's value via the stale `lastVal`. `Leb128.readAt` returns `-1` instead.
Six call sites, all of which currently assume the walk already proved
termination — so the new `-1` should be unreachable. **Add an explicit
`if (v < 0) return PASS;` at each of 466, 471, 480, 513, 517, 548** rather than
trusting the precondition silently. This is the edit most likely to change
observable behaviour if the precondition was ever false.

**R4** — `AimBias.readVarints`: the shared reader rejects a body ending
mid-varint; the current one accepts it. `AimBias` will therefore apply its bias
to strictly fewer packets. Given `AimBias` is toggle-gated and documented as
disproven (`core/PacketLoop.java:185-198`), this is acceptable — but it is a
real behaviour change and must be called out in the commit.

### Varint skip

| Current call | New call | R |
|---|---|---|
| `net/PositionSync.java:108` | `Leb128.skip(b, i, end)` | |
| `filter/MarkFilter.java` 228, 237 | `Leb128.skip(b, i, end)` | |
| `filter/GamePacketTaxonomy.java:765` | `Leb128.skip(b, i, end)` | |
| `esp/EspEngine.java` 674, 877 | `Leb128.skip(b, i, end, count)` | |
| `dev/capture/DecodedDumper.java` 274, 543 | `Leb128.skip(b, i, end, count)` | |
| `filter/GamePacketTaxonomy.java` 693, 767 (`countVarints`) | `Leb128.count(b, from, end, 16)` — **cap must be passed, not assumed** | |

`MarkFilter`'s byte-count guard becomes the shift guard: **proven equivalent**
(§1.1), no behaviour change.

### Varint write

| Current call | New call | R |
|---|---|---|
| `filter/AimFilter.java` 871-873, 908 (`writeCanonical`) | `Leb128.write` | |
| `filter/MarkFilter.java` 266-268 (`writeZigzag`) | `Leb128.write(out, q, ZigZag.encode(v))` | |
| `net/PositionSync.java:267-280` (inline, in `rebuild`) | `Leb128.writeBounded(scratch, p, scratch.length, u)`; keep `return -1` | **R5** |
| `net/AimBias.java:211-230` (`writeVarints`) | `Leb128.writeBounded` | |
| `net/PositionSync.java:186-190` (inline, in `setSigned`) | `Leb128.writePadded` | |
| `filter/AimFilter.java` 651, 653, 697-699 (`writeVarintPadded`) | `Leb128.writePadded` | |

**R5** — `PositionSync.rebuild`: the overflow path is load-bearing (`"no room:
caller withholds"`). Do not let the unchecked `write` be used here. Verify the
`-1` still propagates to line 270's `return -1`.

### Zigzag

| Current call | New call | R |
|---|---|---|
| `esp/EspEngine.java` ×16 (`zz`) | `ZigZag.decode` | |
| `dev/capture/DecodedDumper.java` 697-699 (`zz`) | `ZigZag.decode` | **R6** |
| `net/PositionSync.java` 156 + `filter/AimFilter.java` 517, 549, 1006 | `ZigZag.decode` | |
| `net/BodyDecoderText.java` 303-306, 436 | `ZigZag.decode` | |
| `net/WireReader.java:63-66` | `ZigZag.decode` inside `BodyReader.z()` | |
| `net/PositionSync.java` 170, 182, 191, 213 + `filter/AimFilter.java` 565, 569, 596-598 | `ZigZag.encode` | |
| `filter/MarkFilter.java:336` (inline) | `ZigZag.encode` | |

**R6** — arithmetic `>>` becomes logical `>>>`. Differs only for a value with
bit 63 set, which the trailing-tick validation in `parseChain` (line 640) makes
unreachable. Correct per five other copies and per protobuf. Changes the three
`entities_.csv` columns `x_zz,z_zz,y_zz` only on input that is already rejected.

### Everything else

| Current | New | R |
|---|---|---|
| `esp/EspEngine.java:604` / `dev/capture/DecodedDumper.java:220` `f32` | `Bits.f32` | |
| `net/AimBias.java` 124-126, 171-173; `net/BodyDecoderText.java` 376, 438 | `Bits.f32` | |
| `net/PositionSync.java:312` `varintWidth` (+8 call sites) | `Leb128.width` | |
| `filter/AimFilter.java` 448, 704, 863, 931 `ensure` | `Buffers.ensure` | |
| `filter/MarkFilter.java` 210, 260, 280 `ensure` | `Buffers.ensure` | |
| `esp/EspTuning.java` ×78 `clamp`, ×6 `clampI` | `Num.clamp` | |
| `filter/AimFilter.java` 321, 342 `clampF` | `Num.clamp` | |
| `overlay/AimInjector.java` ×6 `clampF` (699, 700, 922, 923, 934, 935) | `Num.clamp` | **R7** |
| `overlay/EspRenderView.java:1482` `clamp255` | keep the named wrapper, body → `Num.clamp(v, 0, 255)` | |
| `net/AimBias.java:131` `clamp(double)` | `Num.clamp(v, -1.0, 1.0)` | |
| `overlay/CrosshairView.java` 125-135, `replay/ReplayEngine.java:128` | keep named wrappers over `Num.clamp` | |
| `core/PacketBuilder.java` 37, 76, 84 `cksum` | `(short) Bits.checksum16(...)` | **R8** |
| `core/TcpProxy.java:433` `checksum` | `Bits.checksum16` | |
| `core/TcpProxy.java:458` `tcpChecksum` | keep the prologue, body → `Bits.onesComplementSum(pkt, off, segLen, seed)` | |
| `core/PacketLoop.java` 58 (`ri`), 59, 60, 85 (`rs`) | `Bits.be32` / `Bits.be16` | |
| `core/TcpProxy.java` 98, 99, 102, 103 (`getInt`), 431, 432, 443, 444 (`putInt`), 100, 101, 106 (inline BE16) | `Bits.be32` / `Bits.putBe32` / `Bits.be16` | |
| `dev/capture/LobbyCapture.java:490` `be32` | `Bits.be32` | |
| `net/PriSync.java:98`, `net/BodyDecoderText.java:318-323` | `Bits.le16` | |
| `dev/capture/DecodedDumper.java` `hex2`/`hexOf`/`hexRange` (11 sites) | `Hex.append(...)` / `Hex.append(..., 96)` | |
| `dev/capture/LobbyCapture.java` 528, 563 `hex` | `Hex.append` | **R9** |
| `net/BodyDecoderText.java:447` `appendHex` | `Hex.append` | |
| `dev/capture/CaptureWriter.java` 536-541, 525, 587 | `Hex.put` / `Hex.putInt` | |
| `net/LobbyKeySniffer.java:134` `toHex` | `Hex.toLower` | |
| `net/LobbyKeySniffer.java:278` `decodeHex` | `Hex.decode` | |
| `filter/AimFilter.java:1120-1134` `schedule()` | **delete**; call `BodyCrypt.schedule()` | **R10** |
| `dev/capture/CaptureAnnotator.java:335-349` `schedule()` | **delete**; call `BodyCrypt.schedule()` | **R10** |

**R7** — `AimInjector.clampF` gains a NaN guard it never had. A NaN screen
coordinate now clamps to the edge margin instead of propagating. Six call sites,
all on the aim-injection gesture path. Almost certainly an improvement; still a
behaviour change, so land it in its own commit so a regression is bisectable.

**R8** — `PacketBuilder.cksum` changes accumulator from `int` to `long`.
Identical for every buffer under ~32 KiB, which covers every IP/ICMP packet it
sees. The `(short)` cast at the call sites must be kept — `checksum16` returns
an `int` masked to 16 bits, which is the same bit pattern.

**R9** — `LobbyCapture.hex` currently has no bounds check and will throw
`ArrayIndexOutOfBoundsException` on a bad range; `Hex.append` clamps. Both call
sites pass validated ranges, so this only removes a crash that cannot fire.

**R10** — deleting the two private `schedule()` copies changes *caching*
behaviour: `AimFilter` had a per-instance cache, `CaptureAnnotator` a
non-volatile static, and both become `BodyCrypt`'s volatile static. Net effect
is one shared cache and correct publication across the packet threads. This is
the change with the widest thread-visibility footprint in the whole extraction
— do it alone.

---

## 4. What must NOT be shared

Not everything that looks duplicated is.

**`net/PriSync.java:125-139` — the packed value+length reader.** Its own comment
(119-121) says why: *"A varint read has to return both the value and how many
bytes it took. Packing them into one long keeps this allocation-free on a path
that runs for every property of every player several times a second."* The
56-bit value truncation is part of the contract, not an accident. It should
**become** `Leb128.readPacked` (the shared API above adopts its design
wholesale) — but the packing must not be replaced by an out-param or a small
object for tidiness.

**`esp/EspEngine.java:551-576` and `dev/capture/DecodedDumper.java:199-217` —
the bulk `varints()` array readers.** These allocate a `long[]` per packet,
which is bad, but `EspEngine`'s runs on the packet thread at 5-10 Hz × N
entities. Extracting them into a shared helper does not fix the allocation and
adds a cross-package call. Either leave them as-is, or replace them with a
caller-supplied out-array variant — but that is a performance project, not part
of this extraction. **Do not collapse the two into one shared allocating helper
and call it done.**

**`filter/AimFilter.java` and `esp/EspEngine.java` hot-path readers — checked,
and they are NOT specially hand-tuned.** Both were read in full. `AimFilter`'s
`skipVarint` (1070-1083) is the standard loop plus the `lastVal` side channel;
`EspEngine`'s `vi` (1027-1038) is byte-for-byte identical to
`DecodedDumper`'s. Neither has an unrolled first byte, a fast path for 1-byte
values, or an elided bounds check. So the usual justification for keeping a
private copy does not apply here — the only real hot-path constraint is that the
shared version must stay `static`, primitive-only, and small enough for the JIT
to inline, which the proposed API is. `AimFilter`'s `lastVal` field is the one
genuinely different contract, and §3/R3 handles it by making the sentinel
explicit.

**`dev/capture/CaptureWriter.java`'s `byte[]`-target hex.** The class is
documented as an "allocation-free queue straight to disk" (line 17) with a
"hot-path intake" section (211). Routing it through `StringBuilder` would
allocate per record. Keep the `byte[]` sink as a first-class part of `Hex`, not
an afterthought.

**`filter/GamePacketTaxonomy.java:697` `countVarints`'s `n > 16` cap.** It is a
shape gate for `isTeamAssignment`/`isPositionKeepalive`, not an overflow guard.
Must become a parameter. Dropping it silently widens two packet classifiers.

**`core/TcpProxy.java:489-511` `tcpChecksum`'s pseudo-header prologue.** IPv4
TCP-specific. Only the fold loop is shared.

**`overlay/CrosshairView.clampCrosshairSize/Alpha`,
`replay/ReplayEngine.clampTeleReplayDelayMs`, `EspRenderView.clamp255`,
`AimBias.clamp`.** These are named policy constants wearing a clamp's clothes.
Keep the named methods (they are the single source of truth for those bounds)
and only replace their bodies.

**`net/LobbyKeySniffer.toHex`'s lowercase output.** Compared against
`lastKeyHex()` and validated by `isLowerHex()`. Uppercasing it silently breaks
key-rotation detection.

**`net/WireReader.java`'s per-type rules.** `u()` vs `rawByte()` vs `str()` vs
`fixU16()` are not four spellings of the same read — the class javadoc calls the
non-uniformity *"the trap that desynchronises every naive parser"*. This is
protocol knowledge and belongs in `decode/`, never in `util/`.

---

## 5. The `util/` ↔ `decode/` boundary

**The rule, stated so future code has an obvious home:**

> A helper belongs in **`util/`** if you could forget every fact about Free Fire
> and still write its unit test from first principles.
>
> If its correctness argument cites a capture, a `Cmd` id, a field index, a
> header size, a measured ratio, or an IL2CPP symbol, it belongs in **`decode/`**.

Operationally: `util/` may not import anything from `net/`, `esp/`, `filter/`,
`dev/` or `decode/`, and may not contain a single number that came out of a
packet. `decode/` may import `util/` freely.

| Goes in `util/` | Goes in `decode/` |
|---|---|
| `Leb128` — the 1-10 byte rule, the shift-63 guard, canonical vs padded write | `BodyReader` — U/Z/B/S/FixUInt16, because *which* rule applies to a field is protocol knowledge |
| `ZigZag.encode/decode` — the bit identity | "positions and velocities are zigzag, `v13/v14/v15` are float32, `v22` is plain" — the per-field table |
| `Bits.f32` — IEEE-754 reinterpretation | "read a float field as `f32(v[13])`" — the index |
| `Bits.be32/be16/le16` | `MsgKey.headerSizeOf`, `HeaderLayout.readShort` — permuted, masked, per-session |
| `Bits.onesComplementSum` — RFC 1071 | `Crc7`, `PacketCodec.reserialize` — the game's own framing |
| `Buffers.ensure` | `BodyOffsets.afterHandles` — the 4-or-5-byte handle, 0/190 vs 190/190 |
| `Num.clamp` | `EspTuning`'s bounds constants — every one is a measured value |
| `Hex` | `GamePacketTaxonomy`'s shape gates — every constant is a capture statistic |

Two boundary calls worth stating explicitly:

1. **`Leb128.count(b, from, end, max)` is `util/`; every *use* of it is
   `decode/`.** Counting varints is arithmetic. Knowing that a keepalive body is
   23 of them is protocol.
2. **`ZigZag` is `util/` even though zigzag is "the second trap".** The trap is
   not the transform, it is knowing *which fields* get it. The transform is
   four tokens of bit maths; the knowledge stays in `decode/` and in
   `docs/PROTOCOL_MASTER.md` §2.1.

---

## 6. Suggested landing order

Ordered so that each commit is independently bisectable and the risky ones are
isolated.

| # | Commit | Risk |
|---|---|---|
| 1 | `util/Bits` (`f32`, `be32/be16/le16`, `putBe*`) + migrate `PacketBuilder`/`TcpProxy`/`LobbyCapture`/`EspEngine`/`DecodedDumper` | none (R8 is contained) |
| 2 | `util/Buffers.ensure` + migrate `AimFilter`, `MarkFilter` | none |
| 3 | `util/ZigZag` + migrate all 7 sites | **R6** — the one real fix |
| 4 | `util/Leb128` read/skip/width + migrate the 10 non-risky readers and all 6 skippers | none |
| 5 | `util/Leb128` write/writeBounded/writePadded + migrate the 6 writers | **R5** |
| 6 | `util/Num` + migrate clamps, keeping the named policy wrappers | **R7** — own commit |
| 7 | `util/Hex` + migrate the 8 formatters | **R9** |
| 8 | `AimFilter` sentinel handling (R3) + `AimBias` strict truncation (R4) | **R3, R4** — own commit |
| 9 | Delete the two `schedule()` copies, route to `BodyCrypt.schedule()` | **R10** — own commit |
| 10 | `decode/BodyReader` (move `WireReader`, fold in `BodyDecoderText.Cur`) + `decode/BodyOffsets` | **D3** — verify all 22 `Cur` sites |
| 11 | Collapse the two protobuf tag-walkers onto `readPacked` | **R1** |

Steps 1-5 and 7 are the bulk of the edits (roughly 180 call sites) and are
mechanical. Steps 6, 8, 9, 10 and 11 are the whole risk surface: five commits,
about 25 call sites.
