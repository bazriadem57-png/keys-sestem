# Server ops — the Nuvola backend on the VPS

**2026-09-17.** Operational runbook for the licensing/config backend. Design is
in `docs/LOGIN_AND_SERVER.md`; reasoning in `docs/SECURITY_MODEL.md`.

**No secrets in this file or the repo.** Keys, salts, passwords and the cert
private key live only on the VPS and in the owner's password manager.

---

## 0. Host

- VPS: `66.154.107.27`, SSH port 22. **No domain** (client pins a self-signed
  cert by SPKI). A cheap domain later unlocks Let's Encrypt + Cloudflare
  TLS/WAF/rate-limiting — a drop-in change (swap the pin), not a rewrite.
- Backend lives in its **own directory/repo**, separate from the APK source.

### First: lock the box (do before deploying anything)
The current root password travelled through chat/email — treat it as burned.
1. Create a non-root sudo user; add your SSH public key to it.
2. `sshd_config`: `PermitRootLogin no`, `PasswordAuthentication no`; restart sshd.
3. Rotate the root password (kept only in a password manager, unused for login).
4. Firewall: allow 22 + 443 only (`ufw allow 22,443/tcp`, `ufw enable`).
5. `unattended-upgrades` for security patches.

---

## 1. Stack

- **FastAPI** (Python — matches the owner's `tools/*.py` fluency) + **SQLite**
  (upgrade path to Postgres if scale demands). Run under `uvicorn` as a
  **systemd** service, bound to `127.0.0.1`.
- **Caddy** (or nginx) in front terminating **TLS with a self-signed cert**, and
  doing rate-limiting (Caddy `rate_limit`, or nginx `limit_req`; or `slowapi`
  inside FastAPI). Caddy's auto-HTTPS needs a domain, so with a bare IP we
  configure it with an explicit self-signed cert instead.
- Crypto libs: `cryptography` (Ed25519 signing, X25519 ECDH, HKDF, AES-256-GCM),
  `argon2-cffi` (if passwords are ever added), `PyJWT` (or hand-sign Ed25519).

### Self-signed cert + client pin
1. Generate an EC (P-256) key + self-signed cert on the VPS (long expiry, CN/SAN
   = the IP). Keep the private key `600`, root-only.
2. Compute the **SPKI SHA-256 pin** from the cert; put it in the client's
   `CertificatePinner`. Document the pin value in the client, not the key.
3. On cert rotation: ship a client update carrying **both** old and new pins,
   then retire the old — never a flag-day pin swap.

---

## 2. Data model (SQLite)

- `licenses(id, key_hash, tier, status, expiry, max_devices, created_at, note)`
  — key stored as a hash; shown in cleartext only once at mint time.
- `devices(id, license_id, fingerprint_hash, pubkey, first_seen, last_seen,
  active)`.
- `refresh_tokens(id, license_id, device_id, token_hash, family_id, used,
  created_at)` — rotating, reuse-detection.
- `config_versions(version, tier, blob, created_at, active)` — the Bucket-B
  payloads; per-user watermark applied at request time.
- `audit(id, license_id, fingerprint_hash, ip, asn, endpoint, ts)` — feeds
  anomaly detection.
- `server_keys` — Ed25519 signing keypair, `server_salt` for the fingerprint
  HMAC, X25519 handled ephemerally per request. Stored in a root-only file or
  env, **never** in the repo or a client.

---

## 3. Endpoints
See `docs/LOGIN_AND_SERVER.md` §3–4 for the request/response contracts:
`POST /auth/activate`, `POST /auth/refresh`, `POST /config`, `GET /version`.
Rate-limit `/auth/*` tightly (e.g. 5/min per IP) to blunt key brute-force and
credential stuffing.

---

## 4. Admin key-mint CLI (SSH-only, not an HTTP endpoint)

A local script (`admin.py`) run over SSH:
- `mint --tier T --devices N --expiry DATE [--note ...]` → prints the cleartext
  key once, stores only its hash.
- `revoke <key|license_id>` → sets `status=revoked`; takes effect within one
  refresh cycle (≤10 min).
- `list [--devices]` → licenses and bound devices.
- `deactivate-device <license_id> <fingerprint>` → frees a seat.
- `rotate-config <version>` → activates a new Bucket-B version; leaked older
  blobs die on clients' next fetch.

Payments are handled off-platform (right for a small paid base): take payment,
run `mint`, send the key.

---

## 5. Kill-switch & leak response

- **Revoke a license:** `admin.py revoke` → next `/auth/refresh` returns 401 →
  client locks. For an immediate cut before the ≤10 min access-token expiry, add
  the `jti` to a small denylist the token check consults.
- **Config leak traced by watermark:** identify the license from the leaked
  blob's per-user watermark, revoke it, and `rotate-config` so the blob is dead
  fleet-wide.
- **Kill old builds:** raise `min_supported` in `/version`.
- **Feature kill:** serve capability flags in the config blob so a risky feature
  can be disabled fleet-wide without shipping an APK.

## 6. Anomaly detection
From `audit`: flag a license seen from more than its `max_devices` fingerprints,
rapid IP/geo/ASN hops, or many distinct fingerprints in a short window —
classic key-sharing. Auto-throttle or suspend on threshold; review manually at
this scale.

## 7. Backups & monitoring
- Nightly SQLite backup (`.backup`) off-box; test a restore.
- Log to journald; alert on 5xx spikes and auth-failure spikes.
- Keep the server signing key + salt backed up in the password manager — losing
  them invalidates every issued token and lease.

---

## 8. Deploy — one script

`deploy/bootstrap.sh` does §1–§3 in one run (uvicorn terminates TLS directly on
:443 with the pinned self-signed cert — no Caddy needed at this scale; the
in-process limiter in `app.main` covers rate limiting). On the VPS, as root,
after copying the tree:

```
scp -r server root@66.154.107.27:/opt/nuvola/server   # from your machine
ssh root@66.154.107.27
bash /opt/nuvola/server/deploy/bootstrap.sh
```

It prints the two values to paste into the Android client's `AuthConfig.java`:
`CERT_PIN` and `SERVER_ED25519_PUB_HEX`. Then:

1. Box locked (§0) — do this first; the pasted root password is burned.
2. `ufw allow 22,443/tcp && ufw enable`.
3. `cd /opt/nuvola/server && .venv/bin/python admin.py mint --devices 2` → give the key out.
4. Fill `AuthConfig.CERT_PIN` + `AuthConfig.SERVER_ED25519_PUB_HEX`, build release, install.
5. Verify: activate → engine unlocks → `admin.py revoke <id>` → app locks within a
   refresh cycle. mitmproxy in front → client refuses (pin holds).
