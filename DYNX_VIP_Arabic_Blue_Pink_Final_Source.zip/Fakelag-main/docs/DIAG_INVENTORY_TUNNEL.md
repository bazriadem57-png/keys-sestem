# Diagnostic inventory — `tunnel/` and `protocol/`

Every place in these two packages where the code **declines to do its job and says
nothing**, with a proposed counter name, so the next multi-hour "everything stopped
working" is a dump line instead of packet archaeology.

**Scope**: `fakelag/fakelag-beta/app/src/main/java/com/fakelag/cryhard8/tunnel/`
(7 files, 2 460 lines) and `.../protocol/` (9 files, 3 965 lines). Nothing outside
those two packages. Sibling inventories cover `filter/`, `esp/`, `decode/` and
`dev/capture/`.

**Instrumentation only.** Every counter below is addable without altering control
flow: an increment on the line before an existing `return`/`continue`/`break`, or
inside an existing `catch`. Nothing here proposes a behaviour change. Where a bail
is genuinely correct, it is listed in §6 as *do not instrument* rather than padded
into the tables.

Companion docs: `WHEN_NOTHING_WORKS.md` (triage), `VPN_SERVICE_AUDIT.md` (findings
2, 3, 4, 7, 8, 9, 10, 11, 14, 23, 25, 28 are re-used here with current line
numbers), `PREKEY_WINDOW_FIX.md` (the pre-solver window).

---

## 0. Two facts that change the whole design

Read these before the tables; they invalidate the naive reading of the
"current visibility" column.

### 0.1 Every `logger.*` call in `tunnel/` is a no-op in production

`dev/DevLoggerImpl.java:61` declares `private volatile boolean devMode = false;`
and `PacketVpnService.java:105` sets it `false` on service create. `logPacket`
(`DevLoggerImpl.java:139`), `logControl` (`:161`) and `markProtocolDrop` (`:189`)
all open with `if (!devMode) return;`. Dev mode is only ever turned on by an
explicit intent (`PacketVpnService.java:207`).

**Consequence**: all eleven `logger.logControl(...)` / `logProtocolDrop(...)` sites
in `tunnel/` — including `MODE_VPN_SCOPE_EMPTY`, `MODE_VPN_RESTART_JOIN_TIMEOUT`
and `UDP_DECODE_THREW`, each of which was added *after* a multi-hour debugging
session — produce **nothing at all** unless the user happened to have dev mode on
before the failure. Rows marked `logs` in the tables below are therefore
`logs (dev-mode only)`: they are silent in every session that matters.

Two further caps apply even with dev mode on: control events stop being retained
after 20 000 (`DevLoggerImpl.java:50`, `:171` `devControlDropped`), and protocol
drops stop being recorded after 1 024 (`:52`, `:195`).

**Design input**: every proposed counter must be unconditional — an `AtomicLong`
that is always incremented — never routed through `DevLogger`. The `event` half of
a `both` proposal can go through the logger, but the counter must not.

### 0.2 The existing counters are write-only

These already exist and are already incremented on the right lines. **None of them
is read anywhere in the repo**, so the data exists and never reaches a dump:

| counter | read by |
|---|---|
| `PacketPipeline.parsedCount()` | nobody |
| `PacketPipeline.crcFailureCount()` | nobody |
| `PacketPipeline.undecodableCount()` | nobody |
| `PacketPipeline.forcedResolveCount()` | nobody |
| `SessionKeySolver.solveCount()` / `resolveCount()` / `packetsObserved()` | nobody |
| `PacketIntegrity.sealedCount()` / `repairedCount()` | nobody |
| `VisibilityMask.streamedWhileHidden()` | nobody (written by `esp/EspEngine.java:1180`) |
| `LobbyKeySniffer.keyEventCount()` / `keyRotationCount()` / `statusLine()` | nobody |
| `AimBias.appliedCount()` / `skippedCount()` | nobody |
| `GamePacketTaxonomy.drainVoiceFrames()` | `VpnEngine.java:220` — but **`countVoiceFrame()` (`GamePacketTaxonomy.java:544`) has zero callers**, so it is permanently 0 and the telemetry row lies |

The only protocol state that reaches any surface is `LobbyKeySniffer.lastKeyHex()`
(capture header, ESP overlay), `VisibilityMask.debugLine()`
(`ui/overlay/EspOverlay.java:307`) and `PacketPipeline.layoutSourceLine()`
(`ui/render/EspRenderView.java:1143`).

**Design input**: the registry's main job is not collecting new numbers, it is
giving the existing ones an exit. Fold §7 in first.

### 0.3 Two seams are wired to nothing

Not silent bails, but they make several rows below permanently hot:

- **`PacketPipeline.setSessionKey()` (`PacketPipeline.java:111`) has zero callers.**
  `keySchedule` is therefore always null, `hasSessionKey()` always false, and
  **every encrypted body that reaches `dispatch()` takes the `k == null` branch at
  `PacketPipeline.java:292-295` and is dropped into `undecodable`.** The registry
  never decodes a single encrypted command. The ESP's own reliable feed survives
  only because `UdpSessionManager.java:249` calls `BodyCrypt` directly, and
  `BodyCrypt` pulls the key statically from `LobbyKeySniffer.lastKeyHex()`
  (`decode/crypt/BodyCrypt.java:38`). This is the `ff-dumper-wiring-is-the-trap`
  pattern: the code compiles, runs, and does nothing.
- **`AimBias.apply()` has zero callers.** The class is constructed
  (`VpnEngine.java:110`) and reset (`:465`, `:492`) but never applied — consistent
  with the DISPROVEN note at `PacketLoop.java:194-217`. Its ten guard-`return -1`
  paths are therefore dead and are **deliberately not listed** in §2; see §6.

---

## 1. `tunnel/` — silent failure points

Measured load: 193–1 007 packets/sec. Rate column assumes 1 000 pkt/s split
roughly evenly, so ≈500/s outbound through `PacketLoop` and ≈500/s inbound through
`UdpSessionManager.RecvRunnable`.

### 1.1 `tunnel/PacketLoop.java` — hot, every outbound packet

| file:line | trigger | visibility | consequence | sev | proposed counter | rate @1k | mode |
|---|---|---|---|---|---|---|---|
| `PacketLoop.java:43` | `if (len < 0) break;` | silent | tun EOF: loop exits, `VpnEngine.run()` finally calls `stop()`, whole engine dies | fatal | `TUNNEL_TUN_EOF` | 0 (once) | event |
| `PacketLoop.java:44` | `if (len < 20) continue;` | silent | one runt IP packet lost | benign | `TUNNEL_IP_RUNT` | <0.1/s | counter |
| `PacketLoop.java:48-51` | `if (version != 4)` | logs (dev-mode only) | **IPv6 is advertised (`VpnEngine.java:501`) but never routed (`addActiveRoutes`, `:655-668`).** Any IPv6 packet that does arrive is dropped and invisible. Audit #11 | degraded | `TUNNEL_DROP_NON_IPV4` | 0 normally | both |
| `PacketLoop.java:56` | `if (len < ihl + 8) continue;` | silent | truncated L4 header; one packet lost | benign | `TUNNEL_IP_SHORT_L4` | <0.1/s | counter |
| `PacketLoop.java:77-83` | `if (proto != 17)` | logs (dev-mode only) | non-TCP/UDP/ICMP dropped. Expected, but on the default route (`0.0.0.0/0`, `:658`) this catches everything the OS emits | benign | `TUNNEL_DROP_NON_UDP` | 0–5/s | counter |
| `PacketLoop.java:88` | `if (plen < 0 \|\| off + plen > len) continue;` | silent | **Runs BEFORE `outUdpSeen.incrementAndGet()` (`:89`)**, so a game packet lost here also under-reports the out counter every "no UDP seen" diagnostic keys on. Also the missing IP-fragment guard (audit #28): a non-first fragment is parsed as if its payload were a UDP header | degraded | `TUNNEL_UDP_LEN_BAD` | 0 healthy | both |
| `PacketLoop.java:101-104` | `plen>=32 && plen<=96 && b9==0x80 && b10==0x80 && (b8&0x80)!=0` else nothing | silent | packet not fed to `observeKeepalive`; own-state/radar go dark if the shape assumption ever breaks — this exact gate previously killed ESP in 2 of 6 sessions | fatal if it regresses | `TUNNEL_ESP_KEEPALIVE_SHAPE_MISS` | ~480/s **(normal to be large)** | counter |
| `PacketLoop.java:148` | `if (parsed != null)` — else `cmd` stays `CMD_UNRESOLVED`, no `dispatch`, no `SessionTimeline`, no `aimExperiment` | silent | **The pre-solver window.** ~1.1–2.6 s and ~440 packets per session in which no command id exists; `RUDP_PLAYER_JOIN` survives at 20.4 %. If the solver never converges this is permanent and every feature is on shape heuristics forever | fatal (windowed) | `PROTO_PARSE_UNSOLVED_OUT` | 500/s in window, 0 after | both |
| `PacketLoop.java:162` | `if (parsed.isCrcValid())` | silent | no `cmd`, no `VehicleSync` feed, no timeline. Expected for foreign UDP (~8 % of arbitrary payloads land in the MsgKey range) | benign | `PROTO_CRC_REJECT_OUT` | ~0–40/s **(normal to be non-zero)** | counter |
| `PacketLoop.java:229-234` | `if PASS … else if DROP … // HOLD:` — HOLD falls off the end | silent | a filter buffered the packet for replay. If the replay never happens the packet is gone with **no counter on any path** | degraded | `TUNNEL_FILTER_HOLD` | 0–15/s when jitter/teleport armed | counter |
| `PacketLoop.java:232` | `engine.pDrop.incrementAndGet()` | counted | **`pDrop` is shared between outbound filter DROP (`:232`), inbound filter DROP (`UdpSessionManager.java:346`) and decoder exceptions (`:374`).** The HUD loss % cannot distinguish "freeze is working" from "the decoder is throwing on every packet" | — | split into `TUNNEL_DROP_FILTER_OUT` / `TUNNEL_DROP_FILTER_IN` / `TUNNEL_UDP_DECODE_THREW` | — | counter |

### 1.2 `tunnel/UdpSessionManager.java` — hot, every inbound packet + every outbound send

| file:line | trigger | visibility | consequence | sev | proposed counter | rate @1k | mode |
|---|---|---|---|---|---|---|---|
| `UdpSessionManager.java:102-104` | `catch (Exception e) { // fall through to protected fallback socket }` | silent | the replayed packet leaves from a **brand-new source port**; the server sees a different NAT binding mid-match — the documented kick fingerprint (`ff-ack-starvation-kicks`) | fatal | `TUNNEL_REPLAY_SESSION_SEND_FAILED` | 0 | both |
| `UdpSessionManager.java:114-115` | `catch (Exception e) { return false; }` | silent | ghost-anchor / teleport replay packet lost entirely; `send()` returns false and the `filter/` callers do not all check it | degraded | `TUNNEL_REPLAY_SEND_FAILED` | 0 | event |
| `UdpSessionManager.java:118-122` | `catch (Exception e) { // ignore }` (fallback close) | silent | fd leak only | benign | — (see §6) | 0 | — |
| `UdpSessionManager.java:131` | `if (se == null) return;` | silent | `getOrCreate` failed; the outbound packet is dropped and neither `pSent` nor `bOut` moves, so the HUD shows no loss | fatal for that flow | `TUNNEL_SESSION_CREATE_FAILED` | 0 | both |
| `UdpSessionManager.java:138` | `if (sendLen <= 0 \|\| ctx.off + sendLen > ctx.buf.length) sendLen = ctx.plen;` | silent | **a filter's rewritten length is silently reverted while its body edit stands** — the server receives a mutated body under the original length | fatal (corrupts the packet) | `TUNNEL_OUTLEN_CLAMPED` | 0 healthy | both |
| `UdpSessionManager.java:145-147` | `catch (Exception e) { // ignore send failure }` | silent | **audit #8**: Wi-Fi↔cellular handover kills every protected socket and this hides it for the full 45 s idle window. Every outbound packet lost; `pSent` does not move so the loss % does not either | fatal | `TUNNEL_UDP_SEND_THREW` | 0, then 500/s during a handover | both |
| `UdpSessionManager.java:156-160` | `catch (Exception e) { // ignore }` around `setSoTimeout(SO_TO)` | silent | the socket has no read timeout, so the `SocketTimeoutException` idle-reaping path at `:354-356` never fires and the recv thread leaks for the process lifetime | degraded | `TUNNEL_SO_TIMEOUT_FAILED` | 0 | event |
| `UdpSessionManager.java:167-171` | `threadPool.execute(new RecvRunnable(...))` inside the `try`; `catch (Exception e) { return null; }` | silent | **audit #7.** `putIfAbsent` at `:162` already succeeded, so a rejected `execute` leaves a **reader-less socket in `udpMap`**. Every later packet on that 3-tuple finds it at `:152` and sends fine; nothing ever reads the replies. That flow's inbound is lost permanently and invisibly | fatal | `TUNNEL_RECV_THREAD_REJECTED` | 0 | event |
| `UdpSessionManager.java:215` | `if (parsed != null)` | silent | inbound half of the pre-solver window | fatal (windowed) | `PROTO_PARSE_UNSOLVED_IN` | 500/s in window | both |
| `UdpSessionManager.java:223` | `if (parsed.isCrcValid())` | silent | no `cmd` ⇒ no `VisibilityMask`, no 1900/118/121/101/107/139/102 ESP feed, no timeline. Expected ~8 % foreign | benign | `PROTO_CRC_REJECT_IN` | ~40/s **(normal to be non-zero)** | counter |
| `UdpSessionManager.java:250-256` | `if (plain > 0) {...} else { bLen = 0; }` | silent | **`BodyCrypt.decrypt` failed (no key, or the key rotated) and the body is discarded with zero signal.** This is precisely the `ESP_HEALTH_AND_NAMES` failure: HP invented, names absent, owner→entity bind missing | fatal | `PROTO_BODY_DECRYPT_FAILED` | 0 with key / ~30/s without | both |
| `UdpSessionManager.java:258` | `if (bLen > 0)` | silent | restates the above; also covers a legitimately empty body | benign | folded into the above | — | — |
| `UdpSessionManager.java:289-291` | `rlen >= 22 && rlen <= 26 && isHitConfirmation(...)` | silent | **the caller's window is NARROWER than the predicate** — `isHitConfirmation` itself accepts 20–40 (`GamePacketTaxonomy.java:689`). Hits at 20–21 and 27–40 B are structurally valid and never counted. Same class as the 38 B chain floor that ate 85.8 % of entity updates | degraded | `TUNNEL_HIT_TELEMETRY_WINDOW_MISS` (count `rlen∈[20,40] \ [22,26]` that pass the predicate) | <1/s | counter |
| `UdpSessionManager.java:325` | `if (rlen >= 20 && rlen <= 1024)` | silent | a chain above 1 024 B reaches no parser. Survival/BR chains already run to ~630 B; the previous 170 B ceiling made ESP mode-specific for weeks | fatal if it regresses | `TUNNEL_CHAIN_OVER_CEILING` | 0 healthy | both |
| `UdpSessionManager.java:325-339` | the four length windows (`20-1024`, `11-13`, `20-40`, `14-20`) do not tile | silent | `rlen` 0–10 and >1 024 reach **no** ESP feed at all | degraded | `TUNNEL_INBOUND_UNCLASSIFIED` | ~0 | counter |
| `UdpSessionManager.java:351-353` | `synchronized (out) { out.write(ip); }` throws ⇒ falls to `:381` | silent | one transient tun write failure ends the session and closes the socket | fatal for that flow | `TUNNEL_TUN_WRITE_THREW` | 0 | event |
| `UdpSessionManager.java:354-356` | `catch (SocketTimeoutException)` → `if (now - fe.t > IDLE) break;` (`IDLE = 45 000 ms`) | silent | the session is reaped; the next outbound re-creates it on a **new source port** — the kick fingerprint again, now on a timer | fatal if it fires mid-match | `TUNNEL_SESSION_IDLE_REAPED` | 0 | event |
| `UdpSessionManager.java:357-380` | `catch (RuntimeException e)` | counted + logs (dev-mode only) | packet dropped, session kept (correct, post-fix). But in production only an anonymous `pDrop` bump remains | degraded | `TUNNEL_UDP_DECODE_THREW` (unconditional counter alongside the existing log) | 0 healthy | both |
| `UdpSessionManager.java:381-384` | `catch (Exception e) { break; }` | silent | genuine I/O failure ends the session. Correct narrowing, still invisible | fatal for that flow | `TUNNEL_SESSION_IO_ENDED` | 0 | event |
| `UdpSessionManager.java:387-391`, `:397-403` | `catch (Exception e) { // ignore }` on close | silent | fd hygiene only | benign | — (see §6) | — | — |

### 1.3 `tunnel/VpnEngine.java` — lifecycle, all rare

| file:line | trigger | visibility | consequence | sev | proposed counter | rate | mode |
|---|---|---|---|---|---|---|---|
| `VpnEngine.java:386` | `executeSafe: if (stopped) return;` | silent | a queued capture dump / telemetry dump / restart never runs | degraded | `TUNNEL_TASK_DROPPED_STOPPED` | 0 | event |
| `VpnEngine.java:389-391` | `catch (RejectedExecutionException e) { }` | silent | same, on the pool-shutdown race | degraded | `TUNNEL_TASK_REJECTED` | 0 | event |
| `VpnEngine.java:398`, `:450`, `:468` | `if (stopped) return;` inside `restartTunnel` | silent | leaves `isRun=false`, tun closed, no new thread. Engine is dead but nothing said so | fatal | `TUNNEL_RESTART_ABORTED` | 0 | event |
| `VpnEngine.java:403-407`, `:592-596`, `:925-929` | `catch (Exception e) { // ignore }` around `tcpProxy.closeAll()` | silent | the RSTs never reach the game, which then retransmits into silence for minutes — the exact behaviour `closeAll`'s javadoc says it prevents | degraded | `TUNNEL_CLOSEALL_THREW` | 0 | event |
| `VpnEngine.java:424-449` | join timeout after 2×1 s | logs (dev-mode only) | **audit #3**: the retiring thread's `finally` (`:597`) nulls `tunWriter`, which the new session just set (`:584`). `writeToTun` then silently returns forever: lobby/login relayed out, nothing delivered back | fatal | `TUNNEL_RESTART_JOIN_TIMEOUT` (unconditional counter) | 0 | both |
| `VpnEngine.java:482` | `run(): if (stopped) return;` | silent | the VPN thread exits before establishing anything | fatal | `TUNNEL_RUN_ABORTED_STOPPED` | 0 | event |
| `VpnEngine.java:549-555` | `catch (Exception e) { // Not installed for this user }` | silent (only the total is logged) | **a target package silently drops out of the allow-list.** This is failure mode #1 in `WHEN_NOTHING_WORKS.md`: play an uncovered build and you get `out=1 in=6247 foreign=6248 decrypted=0`. `scopedApps` counts successes; nothing names the package that failed | fatal | `TUNNEL_ALLOWED_APP_REJECTED` (event carries the package name) | 0 | both |
| `VpnEngine.java:562-565` | `if (scopedApps == 0)` → `MODE_VPN_SCOPE_EMPTY` | logs (dev-mode only) | **audit #9**: zero allowed apps silently degrades to an unscoped narrow-route tunnel. Also drives `addActiveRoutes(builder, false)` at `:557`, which installs the narrow 148/8 pair — and the 43.252.x match server is outside it | fatal | `TUNNEL_SCOPE_EMPTY` (unconditional) | 0 | both |
| `VpnEngine.java:569-572` | `if (tun == null) { stop(); return; }` | **silent — nothing at all** | `builder.establish()` returned null (permission revoked, another VPN took the slot). The engine calls `stop()` with no log, no counter, no broadcast reason. The user sees the toggle flip back for no stated cause | fatal | `TUNNEL_ESTABLISH_NULL` | 0 | event |
| `VpnEngine.java:586-587` | `catch (Exception e) { e.printStackTrace(); }` around `packetLoop.loop` | logcat only | any exception escaping the packet loop ends the tunnel. `printStackTrace` reaches neither the capture nor a counter | fatal | `TUNNEL_PACKET_LOOP_THREW` (event carries the exception class) | 0 | both |
| `VpnEngine.java:600-606` | `catch (InterruptedException e) { break; }` in the standby sleep | silent | falls out of standby into the `finally` → `stop()` | degraded | `TUNNEL_STANDBY_INTERRUPTED` | 0 | event |
| `VpnEngine.java:608-609` | outer `catch (Exception e) { e.printStackTrace(); }` | logcat only | a `Builder`/`establish` failure is invisible outside logcat | fatal | `TUNNEL_ESTABLISH_THREW` | 0 | both |
| `VpnEngine.java:734-735` | `catch (InterruptedException e) { return; }` in the stats loop | silent | the stats loop dies; the HUD freezes and `broadcastState()` stops, so every UI surface keeps painting the last good state forever | degraded | `TUNNEL_STATS_LOOP_ENDED` | 0 | event |
| `VpnEngine.java:793` | `writeToTun: if (out == null) return;` | silent | **audit #3's black hole.** Every synthesized TCP segment discarded: login, lobby matchmaking, match-end handoff and voice signalling all relayed out with nothing delivered back | fatal | `TUNNEL_TUN_WRITE_NO_WRITER` | 0 healthy | both |
| `VpnEngine.java:798-800` | `catch (Exception e) { // tunnel closed }` | silent | relay writes lost | degraded | `TUNNEL_TUN_WRITE_THREW` (shared with `UdpSessionManager:351`) | 0 | counter |
| `VpnEngine.java:867-870` | `catch (Throwable t)` → `DECODED_DUMP_FAIL` | logs (dev-mode only) | the decoded dump is missing and the analyst does not know why | degraded | `TUNNEL_DECODED_DUMP_FAILED` | 0 | both |

### 1.4 `tunnel/TcpProxy.java` — lobby/login/voice relay, ~0–50 segments/s

| file:line | trigger | visibility | consequence | sev | proposed counter | rate | mode |
|---|---|---|---|---|---|---|---|
| `TcpProxy.java:95`, `:97` | `if (len < 40) return;` / `if (len < ihl + 20) return;` | silent | runt TCP packet dropped | benign | `TUNNEL_TCP_RUNT` | <0.1/s | counter |
| `TcpProxy.java:136` | `if (c == null \|\| c.closed) return;` | silent | a segment for an unknown/closed connection is dropped **with no RST**, so the game's stack retransmits into silence. A non-zero value during a match means a lobby connection was torn down underneath the game | degraded | `TUNNEL_TCP_NO_CONN` | 0 healthy | counter |
| `TcpProxy.java:137` | `if ((flags & FLAG_ACK) == 0) return;` | silent | non-ACK, non-SYN segment ignored | benign | — (see §6) | — | — |
| `TcpProxy.java:154` | `if (diff > 0 && diff <= payloadLen)` | silent | covers retransmits (benign) **and gaps** (`diff > payloadLen`). There is no reassembly queue, so one reordered segment permanently desynchronises the lobby stream — and the lobby stream is where the session key and the header permutation live | fatal | `TUNNEL_TCP_RETRANSMIT` (`diff<=0`) and `TUNNEL_TCP_GAP_DISCARDED` (`diff>payloadLen`) | 0 healthy | both |
| `TcpProxy.java:167-171` | `catch (Exception e) { // not connected yet }` on `shutdownOutput` | silent | client FIN never propagated to the remote | degraded | `TUNNEL_TCP_FIN_LOST` | 0 | event |
| `TcpProxy.java:173-175` | `catch (Exception e) { // Never let a malformed packet kill the tun loop. }` | silent | swallows **everything** in `handlePacket`, including NPEs and index bugs. One bad segment vanishes; a systematic bug vanishes 100 % of lobby traffic with zero signal | fatal | `TUNNEL_TCP_HANDLE_THREW` | 0 healthy | both |
| `TcpProxy.java:203-206` | `if (c.writerStarted \|\| c.closed) return;` … `c.writerStarted = true;` **then** `pool.execute(...)` | silent | **audit #10**: the latch is set before the execute. A rejected execute means no writer ever runs, `toRemote` fills forever and the connection hangs with no error | fatal | `TUNNEL_TCP_WRITER_NOT_STARTED` | 0 | event |
| `TcpProxy.java:222` | `if (out != null)` — else the polled `data` is dropped | silent | the payload was already `poll()`ed at `:218`, so if `remoteOut` went null between the two it is **lost**, not requeued | degraded | `TUNNEL_TCP_WRITE_LOST_NO_STREAM` | 0 | event |
| `TcpProxy.java:227-230` | `catch (Exception e) { sendRst(c); teardown(...); }` | silent | the connection is reset on any write failure, with no record of which | degraded | `TUNNEL_TCP_WRITER_THREW` | 0 | event |
| `TcpProxy.java:254-257` | `catch (Exception e) { sendRst(c); teardown(...); }` in `connectAsync` | silent | **the connect to the real server failed and nobody says so.** If a Garena host is unreachable through the tunnel this is the only evidence it happens, and it is invisible | fatal | `TUNNEL_TCP_CONNECT_FAILED` (event carries `dstIp:dstPort`) | 0 | both |
| `TcpProxy.java:265-268` | `relayStarted` latched before `pool.execute` | silent | same as `:203`; no relay thread ⇒ no downlink ⇒ **no session key and no header permutation for the whole match** | fatal | `TUNNEL_TCP_RELAY_NOT_STARTED` | 0 | event |
| `TcpProxy.java:292-296` | `if (headMask >= 0 && headOrder != null) engine.pipeline().seedLayout(...)` — and the return value is discarded | silent | the lobby fast path is skipped. The solver then spends 1.1–2.6 s / ~440 packets voting, during which `RUDP_PLAYER_JOIN` survives at 20.4 %. `PREKEY_WINDOW_FIX.md` §5 calls this the highest-value remaining fix | fatal (windowed) | `PROTO_LAYOUT_SEED_UNAVAILABLE` (mask<0 or order null) and `PROTO_LAYOUT_SEED_INSTALLED` (return true) | 0–20/s over the downlink | both |
| `TcpProxy.java:309-310` | `catch (Exception e) { // Read failure }` | silent | remote read died; RST follows, reason unrecorded | degraded | `TUNNEL_TCP_RELAY_READ_THREW` | 0 | event |
| `TcpProxy.java:312` | `if (c.closed \|\| !engine.isRun) return;` in the `finally` | silent | the RST/FIN is skipped, so the game gets **no close notification at all** | degraded | `TUNNEL_TCP_CLOSE_UNNOTIFIED` | 0 | event |
| `TcpProxy.java:318-322` | 100×50 ms drain wait, then `if (queuedToClient(c) > 0) sendRst(c);` | silent | after 5 s of a shut client window the **queued downlink is thrown away** and the connection is reset — the tail of a lobby message is lost | degraded | `TUNNEL_TCP_WINDOW_DRAIN_TIMEOUT` (event carries the dropped byte count) | 0 | event |
| `TcpProxy.java:359` | `if (inFlight + data.length > c.clientWindow) return;` | silent | **audit #14**: `toClient` is unbounded and grows for as long as the window is shut — the exact scenario the class comment claims to have fixed | degraded | `TUNNEL_TCP_WINDOW_CLOSED` + gauge `TUNNEL_TCP_TOCLIENT_DEPTH` | 0–5/s | counter |
| `TcpProxy.java:358` | `if (inFlight < 0) inFlight += 0x100000000L;` | silent | **audit #25**: `inFlight` is an `int`, so this is a compile-time no-op. On sequence wrap the window check at `:359` mis-evaluates and either stalls or over-sends | degraded | not a bail — flag as an invariant (§8.9) | — | — |

### 1.5 `tunnel/PacketBuilder.java`

| file:line | trigger | visibility | consequence | sev | proposed counter | rate | mode |
|---|---|---|---|---|---|---|---|
| `PacketBuilder.java:22-46` | `buildPkt` — **no bound check anywhere** | silent | **audit #23**: `total = plen + 0x1c` is written into a 16-bit field (`:29`) with no check, and never compared against `MTU = 1280` (`VpnEngine.java:33`). An inbound datagram >1 280 B is written into the tun regardless; one >65 507 B wraps the length field | degraded | `TUNNEL_TUN_WRITE_OVER_MTU` | 0–2/s (chains run to ~630 B) | counter |
| `PacketBuilder.java:57` | `if (totalLen <= 0 \|\| totalLen > len) totalLen = len;` | silent | a bad IP total-length is silently repaired | benign | `TUNNEL_IP_TOTLEN_FIXED` | 0 healthy | counter |
| `PacketBuilder.java:96-101` | `catch (Exception e) { logProtocolDrop("DROP_ICMP_ECHO_REPLY_FAIL", ...); return true; }` | logs (dev-mode only) | **returns `true`**, so `PacketLoop:65` `continue`s as if the echo was answered. The ping silently goes unanswered | benign | `TUNNEL_ICMP_REPLY_FAILED` | 0 | counter |

### 1.6 `tunnel/TunAddressPool.java`, `tunnel/VpnEngineState.java`

No silent failure points. `TunAddressPool.java:45-49` (cursor out of range ⇒ random) is correct and deliberate. `VpnEngineState` is a pure value object. Two hygiene notes, not bails: `TunAddressPool.java:50` does a synchronous `SharedPreferences.commit()` on the VPN thread, and `:54` allocates out of **public** IPv4 space `26.0.0.0/8` (audit #24).

---

## 2. `protocol/` — silent failure points

### 2.1 `protocol/PacketPipeline.java` — hot, every packet both directions

| file:line | trigger | visibility | consequence | sev | proposed counter | rate @1k | mode |
|---|---|---|---|---|---|---|---|
| `PacketPipeline.java:128-129` | `if (orderIds == null \|\| orderIds.length != HeaderField.COUNT) return false;` / `if (mask < 0 \|\| mask > 0xFF) return false;` | silent | the lobby seed is rejected and **the only caller discards the return value** (`TcpProxy.java:295`) | fatal (windowed) | `PROTO_SEED_ARG_INVALID` | 0 | event |
| `PacketPipeline.java:133` | `if (id < 0 \|\| id >= HeaderField.COUNT) return false;` | silent | same | fatal (windowed) | `PROTO_SEED_ARG_INVALID` | 0 | event |
| `PacketPipeline.java:238` | `if (l == null) return null;` | silent | **the pre-solver window, at its source.** `layoutSourceLine()` is the only hint anywhere and it only reaches the ESP renderer | fatal (windowed) | `PROTO_PARSE_UNSOLVED` | 1000/s in window | both |
| `PacketPipeline.java:240` | `if (p != null)` — `PacketCodec.parse` returned null | silent | not match traffic, or too short. Expected and large on an unscoped tunnel; **a value ≈ 100 % is the `foreign=6248` signature of the wrong app in the tunnel** | benign | `PROTO_PARSE_NULL` | 0–80/s **(normal to be large)** | counter |
| `PacketPipeline.java:259-263` | `if (run >= CRC_FAILURE_RUN) { forcedResolves++; solver.reset(); }` | counted (write-only, §0.2) | 256 consecutive CRC failures force a re-solve; every consumer loses `cmd` for the next few hundred packets | degraded | `PROTO_FORCED_RESOLVE` | 0 healthy | both |
| `PacketPipeline.java:276-280` | `if (!packet.isCrcValid()) { crcFailures++; return false; }` | counted (write-only) | body never dispatched. Note the **accounting trap**: `crcFailures` is bumped here, in `dispatch`, while `noteChecksum` (`:253`) runs on every *parse* — so `crcFailureCount()` does not equal the number of CRC-failing packets | benign | `PROTO_DISPATCH_CRC_REJECT` (rename to disambiguate) | ~80/s | counter |
| `PacketPipeline.java:281` | `if (packet.payloadLength() <= 0) return false;` | silent | header-only packet not dispatched | benign | `PROTO_EMPTY_BODY` | 0–10/s | counter |
| `PacketPipeline.java:283-288` | `if (packet.isZipped()) { undecodable++; return false; }` | counted (conflated) | **healthy value is exactly 0.** Nothing on the match wire is compressed — 0 of 88 413 packets once the header is read right. A non-zero value means the solver elected the wrong permutation and ~49 % of traffic is being discarded unread (`WHEN_NOTHING_WORKS.md` §3). This is the single most valuable number in the package and it is currently pooled with three unrelated causes | fatal | `PROTO_UNDECODABLE_ZIPPED` | **0** | both |
| `PacketPipeline.java:292-295` | `int[] k = keySchedule; if (k == null) { undecodable++; return false; }` | counted (conflated) | **`setSessionKey()` has no callers (§0.3), so this is 100 % of encrypted bodies, always.** The registry never decodes an encrypted command | fatal | `PROTO_UNDECODABLE_NO_KEY` | ~100/s **(currently always the ceiling)** | both |
| `PacketPipeline.java:298-301` | `byte[] buf = scratchFor(payLen); if (buf == null) { undecodable++; }` | counted (conflated) | body larger than `MAX_SCRATCH - BODY_PREFIX` (~8 KB) never decrypted | degraded | `PROTO_UNDECODABLE_SCRATCH` | 0 healthy | event |
| `PacketPipeline.java:304-307` | `if (plainLen < 0) { undecodable++; return false; }` | counted (conflated) | **TEA decryption failed: the key is wrong or has rotated.** A run of these is the exact signature of a re-key the pipeline missed, and it is indistinguishable from "no key" and "zipped" in the current counter | fatal | `PROTO_TEA_DECRYPT_FAILED` | 0 healthy | both |
| `PacketPipeline.java:308`, `:314` | `return registry.dispatch(...)` — the boolean is discarded by both callers (`PacketLoop.java:180`, `UdpSessionManager.java:273`) | silent | "no decoder wanted this command" is invisible | benign | `PROTO_DISPATCH_UNCONSUMED` | ~200/s **(normal to be large)** | counter |
| `PacketPipeline.java:321` | `scratchFor: if (need > MAX_SCRATCH) return null;` | silent | same as `:298` | degraded | `PROTO_UNDECODABLE_SCRATCH` | 0 | event |

### 2.2 `protocol/SessionKeySolver.java` — hot until solved, then outbound-only

| file:line | trigger | visibility | consequence | sev | proposed counter | rate @1k | mode |
|---|---|---|---|---|---|---|---|
| `SessionKeySolver.java:306` | `if (hdr == MsgKey.NOT_MATCH_TRAFFIC) return;` | silent | foreign UDP ignored. Expected and large; **a value ≈ 100 % of observed is the "wrong app in the tunnel" fingerprint** | benign | `PROTO_SOLVER_NOT_MATCH_TRAFFIC` | 0–80/s **(normal to be large)** | counter |
| `SessionKeySolver.java:218` | `if (order == null \|\| order.length != HeaderField.COUNT) return false;` | silent | **`seedsRejected` is NOT incremented here** — only the wire-disagreement path at `:553` bumps it. An argument-shaped rejection is invisible even in `layoutSourceLine()` | fatal (windowed) | `PROTO_SEED_MALFORMED` | 0 | event |
| `SessionKeySolver.java:233` | `if (sameLayout(cur, mask, order)) return false;` | silent | benign "same seed again" — but it returns the same `false` as a real rejection, so the call site cannot tell them apart | benign | `PROTO_SEED_DUPLICATE` | 0–20/s **(normal to be large — `TcpProxy` re-seeds on every downlink read)** | counter |
| `SessionKeySolver.java:238-240` | `catch (IllegalArgumentException e) { return false; }` | silent | the announced permutation is not a permutation; `seedsRejected` not incremented | fatal (windowed) | `PROTO_SEED_NOT_PERMUTATION` | 0 | event |
| `SessionKeySolver.java:378-385` | `if (voteTested >= VOTE_GIVEUP_PACKETS) { votes = null; voteTested = 0; return; }` | silent | **4 096 outbound packets voted and nothing convincing: the whole tally is discarded and restarted.** At ~200 outbound/s that is a silent 20 s cycle of never converging. Every feature stays on shape heuristics and the user just sees "it doesn't work" | fatal | `PROTO_VOTE_GIVEUP` | **0** | event |
| `SessionKeySolver.java:407` | `if (bestPerm < 0) return;` | silent | empty tally | benign | — (see §6) | — | — |
| `SessionKeySolver.java:408` | `if (bestCount * 4 < voteTested * 3) return;` | silent | the winner does not carry 75 %; `elect()` declines and retries every 16 packets. Expected during warm-up; **sustained** decline is the never-converges state | degraded | `PROTO_ELECT_DECLINED` | few during warm-up | counter |
| `SessionKeySolver.java:495-500` | `if (!convincing) { restartVoting(); return; }` | silent | **256 packets of tie-break scoring thrown away** and the whole solve restarts | fatal | `PROTO_TIEBREAK_UNCONVINCING` | **0** | event |
| `SessionKeySolver.java:503-506` | `catch (IllegalArgumentException e) { restartVoting(); return; }` | silent | the elected candidate is not a valid layout | fatal | `PROTO_COMMIT_BAD_LAYOUT` | **0** | event |
| `SessionKeySolver.java:551-557` | `if (provisional) { provisional = false; seedsRejected++; restartVoting(); }` | counted | the lobby-announced permutation disagreed with the very first packet — the lobby and the wire have diverged. Reaches `layoutSourceLine()` only | fatal (windowed) | `PROTO_SEED_REJECTED_BY_WIRE` | **0** | both |
| `SessionKeySolver.java:558-562` | `if (++consecutiveIdentityFailures >= 24) { resolveCount++; restartVoting(); }` | counted (write-only) | session change detected; every consumer loses `cmd` for a fresh convergence window | degraded | `PROTO_SESSION_RESOLVE` | 0–1 per match | both |
| `SessionKeySolver.java:558` (the 1–23 failures **before** the threshold) | `++consecutiveIdentityFailures` with no action | **silent, uncounted** | for up to 23 packets after a real session change, `layout()` still returns the stale layout and **every `cmd` handed to every consumer is garbage that parses**. `SessionKeySolver.java:220-227` names this exact hazard ("garbage that parses is worse than garbage that does not") for the seed path, but the 24-failure grace window has the same property and no counter | degraded | `PROTO_IDENTITY_FAILURE` | 0 healthy | counter |

### 2.3 `protocol/SessionTimeline.java` — hot (`observeUdp` on every parsed packet)

| file:line | trigger | visibility | consequence | sev | proposed counter | rate @1k | mode |
|---|---|---|---|---|---|---|---|
| `SessionTimeline.java:245-247` | `catch (Throwable t) { // Observer. }` in `observeTcp` | silent | **a parse bug anywhere in `scanDownlink`/`findAssignment`/`walkModeFields` silently stops all mode and phase detection for the session.** `MATCH_ASSIGNED` never fires, the capture cannot say which mode was played | fatal | `PROTO_TIMELINE_TCP_THREW` | **0** | both |
| `SessionTimeline.java:276-278` | `catch (Throwable t) { // Observer. }` in `observeUdp` | silent | same, on the hot path — both directions, every parsed packet | fatal | `PROTO_TIMELINE_UDP_THREW` | **0** | both |
| `SessionTimeline.java:285-287`, `:331-333`, `:350-352`, `:482-484`, `:672-674` | five more `catch (Throwable t)` in `phaseId`/`describe`/`drainEvents`/`onSessionKey`/`drainMirrorEvents` | silent | each hides a different failure; `phaseId()` is called per capture record (cached 100 ms at `dev/capture/CaptureWriter.java:429`) | degraded | `PROTO_TIMELINE_THREW` with a site tag | **0** | both |
| `SessionTimeline.java:264` | `if (p.isCrcValid())` | silent | no phase transition, no liveness stamp | benign | covered by `PROTO_CRC_REJECT_*` | — | — |
| `SessionTimeline.java:535-537` | `default: break;` in the `applyUdpCmd` switch | silent | correct — most commands are not lifecycle commands | benign | — (see §6) | ~900/s | — |
| `SessionTimeline.java:554-555` | `if (colon <= 0) return;` in `setEndpoint` | silent | `serverAddr` is updated but **`matchIp`/`matchPort` keep their PREVIOUS values** — a stale endpoint that reads as current | degraded | `PROTO_ENDPOINT_PARSE_FAILED` | 0 | event |
| `SessionTimeline.java:559-562` | `catch (Throwable t) { matchIp = 0; matchPort = 0; }` | silent | the observed endpoint is lost; `headerLines()` prints `observed=-` | degraded | `PROTO_ENDPOINT_PARSE_FAILED` | 0 | event |
| `SessionTimeline.java:648-652` | `if (eventCount.get() >= MAX_EVENTS && events.poll() != null)` | silent | at 512 queued events the **oldest is discarded** — and the oldest are `MATCH_ASSIGNED` and `KEY_ROTATED`, the two most valuable lines in the file. Only matters when nothing drains, i.e. capture off | degraded | `PROTO_TIMELINE_EVENT_DROPPED` | **0** | counter |
| `SessionTimeline.java:653-657` | same for the `mirror` queue | silent | `LobbyCapture` loses the head of its own event log | degraded | `PROTO_TIMELINE_MIRROR_DROPPED` | **0** | counter |
| `SessionTimeline.java:714-718` | `if (consumed >= 0 \|\| total >= pending.length) pendingLen = 0;` | silent | **the mode walk gives up when the 1 024-byte pending buffer fills.** `gameMode`/`matchMode` stay −1 and the capture cannot say which mode was played — which is exactly defect D7 this class was written to fix | degraded | `PROTO_MODE_WALK_ABANDONED` | **0** | event |
| `SessionTimeline.java:769` | `if (isNew \|\| gameMode < 0)` | silent | the mode walk is skipped for a duplicate signature | benign | — (see §6) | — | — |
| `SessionTimeline.java:835` | `if (field <= 3 \|\| field > 60) break;` | silent | **walked out of the message into unrelated bytes**; falls through to `return -1` at `:883`, and the caller then stashes 1 024 bytes of garbage and retries on the next chunk | degraded | `PROTO_MODE_WALK_OUT_OF_MESSAGE` | 0 healthy | counter |
| `SessionTimeline.java:829`, `:838`, `:851`, `:853`, `:856`, `:859` | six `return -1` (ran out of bytes) | silent | legitimate "resume next chunk"; conflated with the give-up path above | benign | `PROTO_MODE_WALK_RESUMED` | 0–2 per match | counter |
| `SessionTimeline.java:862` | `else break; // groups: not used by this schema` | silent | correct | benign | — (see §6) | — | — |
| `SessionTimeline.java:933`, `:937` | `parseIpv4` returns 0 on a bad quad | silent | feeds `setEndpoint`'s stale-value bug above | degraded | folded into `PROTO_ENDPOINT_PARSE_FAILED` | 0 | — |

### 2.4 `protocol/GamePacketTaxonomy.java` — hot, `observeOutbound` on every outbound packet

| file:line | trigger | visibility | consequence | sev | proposed counter | rate @1k | mode |
|---|---|---|---|---|---|---|---|
| `GamePacketTaxonomy.java:252` | `if (plen < 45 \|\| plen > 64) return;` | silent | outside the keepalive length window; the tuple learner never sees it | benign | `PROTO_TAXO_KEEPALIVE_LEN_MISS` | ~400/s **(normal to be large)** | counter |
| `GamePacketTaxonomy.java:253`, `:418`, `:628`, `:690`, `:764` | `if (off < 0 \|\| off + plen > data.length) return;` (five sites) | silent | a bounds failure means the learner, the hit detector or the keepalive detector silently skips a packet it should have seen | degraded | `PROTO_TAXO_BOUNDS_REJECT` | **0** | counter |
| `GamePacketTaxonomy.java:255-257` | `if (outTuples.size() > 256) outTuples.clear();` | silent | **the whole tuple learner is wiped.** Every partially accumulated `steadyCount` restarts; under tuple churn confirmation may never happen | degraded | `PROTO_TUPLE_MAP_CLEARED` | **0** | event |
| `GamePacketTaxonomy.java:272` | `&& reliabilityTuples.size() < MAX_LEARNED_TUPLES (32)` | silent | once 32 tuples are learned **no further tuple can ever be confirmed**, so a channel that appears late in a match is never protected and freeze will drop it | degraded | `PROTO_TUPLE_LEARN_SATURATED` | **0** | event |
| `GamePacketTaxonomy.java:275-277` | `else { t.steadyCount = 0; }` | silent | a gap outside 50–150 ms resets the run. The ratio of resets to confirmations is the whole answer to "why did the keepalive channel never confirm" | benign | `PROTO_TUPLE_STEADY_RESET` | ~50/s **(normal to be large)** | counter |
| `GamePacketTaxonomy.java:417` | `if (plen < 21 \|\| plen > 40) return;` | silent | outside the movement-learner window | benign | `PROTO_MOVE_LEN_MISS` | ~350/s **(normal to be large)** | counter |
| `GamePacketTaxonomy.java:430-440` | `if (nowMs - lastAdopt > 2000L)` | silent | the rotated header is not re-adopted this time; deliberate rate limit | benign | — (see §6) | — | — |
| `GamePacketTaxonomy.java:445` | `if (moveCands.size() >= 16) moveCands.clear();` | silent | **every endpoint's candidate state wiped at once** | degraded | `PROTO_MOVE_ENDPOINT_MAP_CLEARED` | **0** | event |
| `GamePacketTaxonomy.java:450` | `if (cands.size() > 128) cands.clear();` | silent | **the documented regression, one cap up.** At 32 this fired every ~33 fire bursts and repeatedly delayed movement re-confirmation by 8–40 s mid-match, silently disarming freeze and ghost. 128 absorbs one engagement — nothing says when it is exceeded | degraded | `PROTO_MOVE_CAND_MAP_CLEARED` | **0 per match** | event |
| `GamePacketTaxonomy.java:460-464` | `if (gap > 1500) { c.count = 0; c.steadyRun = 0; }` | silent | candidate restarted. This is the mechanism behind "freeze silently never armed" | benign | `PROTO_MOVE_CAND_RESET` | ~5/s | counter |
| `GamePacketTaxonomy.java:474-476` | `else { c.steadyRun = 0; }` | silent | same | benign | folded into the above | — | counter |
| `GamePacketTaxonomy.java:498-501` | `if (matchServerIp != 0 && (dip != matchServerIp \|\| dp != matchServerPort) && nowMs - lastTrackedMoveMs < 10000) return;` | silent | **a genuine new match server is refused for up to 10 s** because the previous one still looks live. At a match handover every endpoint-scoped feature is blind for that window | degraded | `PROTO_MOVE_ENDPOINT_REFUSED` (event carries both endpoints) | **0** | event |
| `GamePacketTaxonomy.java:600` | `if (plen < 5 \|\| off < 0 \|\| off + plen > data.length) return FAMILY_C;` | silent | a bounds failure **misclassifies as family C**, which `FreezeFilter` and `PacketClassifier` treat differently from R — a silently wrong answer rather than a bail | degraded | `PROTO_FAMILY_BOUNDS_FALLBACK` | **0** | counter |
| `GamePacketTaxonomy.java:618` | `return FAMILY_C;` (catch-all) | silent | expected. The R/S/C *ratio* is the best single health signal for the taxonomy and nothing records it | benign | `PROTO_FAMILY_R` / `PROTO_FAMILY_S` / `PROTO_FAMILY_C` as a distribution | 1000/s total | counter |
| `GamePacketTaxonomy.java:626-632` | `learnRMarker`: `if (b2 == b3) learnedRMarker = b2;` — otherwise nothing | silent | under a positional keystream `b2` never equals `b3`, the marker stays −1 forever and `family()` (`:615`) falls back to the weaker `b2 == b3^1` test for the whole session | degraded | `PROTO_RMARKER_UNLEARNED` (invariant, §8.7) | — | event |
| `GamePacketTaxonomy.java:694` | `if (tt == 0 \|\| (tt & 0x07) != 0) return false;` | silent | **a family-ID assumption (`team << 3`) on a single byte** — the exact class of trap that pinned `b11` to 0x08 and made the whole ESP session-specific. A session where the low 3 bits are non-zero rejects **every** hit confirmation, silently | fatal if it regresses | `PROTO_HIT_TEAMBYTE_REJECT` | <1/s healthy | counter |
| `GamePacketTaxonomy.java:689-695` | the other four `return false` guards | silent | expected structural rejection | benign | `PROTO_HIT_SHAPE_REJECT` | ~30/s **(normal to be large)** | counter |
| `GamePacketTaxonomy.java:708`, `:710`, `:712` | `countVarints` returns −1 | silent | folded into the hit rejection above | benign | folded | — | — |
| `GamePacketTaxonomy.java:789-790` | `long d = bodyVarint(...); return (d < 0 \|\| d > 255) ? 0 : (int) d;` | silent | **a parse failure and a genuine 0-damage hit are the same value.** Damage >255 also reports 0 | degraded | `PROTO_HIT_DAMAGE_UNPARSED` | 0 healthy | counter |
| `GamePacketTaxonomy.java:836-838` | `hitWeaponTag` reads `data[off + 16]` with **no bounds check at all** | silent | would throw `AIOOBE` on a short packet — which `UdpSessionManager.java:357` would swallow as a decode-threw. Currently uncalled and deprecated | benign (latent) | flag for deletion, no counter | — | — |
| `GamePacketTaxonomy.java:866`, `:883`, `:894` | `return KIND_UNKNOWN;` (three sites) | silent | the capture's `kind` column says UNKNOWN. Expected, but a rising share means the shape heuristics have drifted off the session | benign | `PROTO_KIND_UNKNOWN` | ~150/s **(normal; healthy < ~20 %)** | counter |
| `GamePacketTaxonomy.java:544` | `countVoiceFrame()` | **dead** | zero callers ⇒ `drainVoiceFrames()` (`:549`) always returns 0 ⇒ the telemetry poller's voice row (`VpnEngine.java:220`) reports a permanent 0 that reads as "no voice exempted" | degraded | delete, or wire it | — | — |

### 2.5 `protocol/VisibilityMask.java` — warm, every CRC-valid inbound packet

| file:line | trigger | visibility | consequence | sev | proposed counter | rate @1k | mode |
|---|---|---|---|---|---|---|---|
| `VisibilityMask.java:69` | `if (p == null \|\| p.cmd() != 135) return false;` | silent | correct dispatch guard | benign | — (see §6) | ~500/s | — |
| `VisibilityMask.java:70` | `if (p.isEncrypted() \|\| p.isZipped()) return false;` | silent | **if Cmd 135 is ever sent encrypted the mask is never read, `hasMask()` stays false forever**, and the ESP's only free measurement of our effective range silently disappears | degraded | `PROTO_VISMASK_ENCRYPTED` | **0** | event |
| `VisibilityMask.java:82` | `if (i != end) return false;` | silent | **the cmd matched but the body did not parse as one varint — i.e. the header layout is putting us on the wrong bytes.** A non-zero value here is a direct, early indicator of a wrong permutation | fatal | `PROTO_VISMASK_RESIDUE` | **0** | both |
| `VisibilityMask.java:91`, `:93` | `if (shift > 63) return false;` / fall-through | silent | malformed / truncated varint | degraded | folded into `PROTO_VISMASK_RESIDUE` | **0** | counter |
| `VisibilityMask.java:118` | `(mask & (1L << (entityId & 63)))` | silent | **the documented aliasing**: entity id 64 maps onto bit 0, and the largest id measured is 64. A silently wrong `isVisible()`, not a bail | degraded | invariant (§8.8) | — | — |
| `VisibilityMask.java:131-137` | `noteStreamedWhileHidden()` / `streamedWhileHidden()` | counted (write-only) | already exactly the right measurement, written by `esp/EspEngine.java:1180`, read by nobody | — | fold as `PROTO_VISMASK_STREAMED_WHILE_HIDDEN` | — | counter |

### 2.6 `protocol/AimBiasExperiment.java` — hot (called unconditionally from both packet paths)

`observe()` is called from `PacketLoop.java:181` and `UdpSessionManager.java:274` on
**every parsed packet**, and it does not check `running` first — it decodes eight
varints out of every inbound Cmd 2010 before `noteDamage` (`:83`) discards the
result. Harness off by default, so this is pure waste on the hot path; worth a note
even though it is not a silent failure.

| file:line | trigger | visibility | consequence | sev | proposed counter | rate @1k | mode |
|---|---|---|---|---|---|---|---|
| `AimBiasExperiment.java:84` | `if (ownHandle == 0 \|\| attackerHandle != ownHandle) return;` | silent | **if the own handle is never learned, every hit is discarded and the harness reports `n=0` forever** — which reads as "no data yet", not "broken" | degraded | `PROTO_AIMEXP_NO_OWN_HANDLE` | 0 while off | counter |
| `AimBiasExperiment.java:119` | `if (at >= end) return;` | silent | a Cmd 2010 with fewer than 8 varints is discarded mid-decode, leaving `v[]` half-filled | degraded | `PROTO_HURT_SHORT` | 0 healthy | counter |
| `AimBiasExperiment.java:127` | `if (shift > 63) return;` | silent | malformed varint | degraded | folded into the above | 0 | counter |
| `AimBiasExperiment.java:111-112` | `long h = readVarint(...); if (h > 0) noteOwnHandle(h);` — `readVarint` returns −1 on failure | silent | **a parse failure and a zero handle are the same branch**; the own handle is silently never learned, which makes `:84` above fire 100 % | degraded | `PROTO_OWNHANDLE_UNPARSED` | 0 healthy | counter |
| `AimBiasExperiment.java:105` | `if (p == null \|\| p.isEncrypted() \|\| p.isZipped()) return;` | silent | correct | benign | — (see §6) | — | — |

### 2.7 `protocol/PacketIntegrity.java` — replay path only, ~15/s

| file:line | trigger | visibility | consequence | sev | proposed counter | rate | mode |
|---|---|---|---|---|---|---|---|
| `PacketIntegrity.java:70` | `return SEAL_FOREIGN;` | **silent — the only branch with no counter** | the packet was not recognised as match traffic, so a mutated packet **goes out with a stale CRC-7** and the server treats it as corrupt. This is the leading suspect for the "server sets us back" behaviour in `TELEPORT.md`. `SEALED`/`REPAIRED` are incremented on the other two branches only | fatal | `PROTO_SEAL_FOREIGN` | **0 on a scoped tunnel** | both |
| `PacketIntegrity.java:75` | `return pkt == null ? SEAL_FOREIGN : ...` | silent | a null packet is indistinguishable from foreign traffic | degraded | `PROTO_SEAL_NULL` | **0** | event |
| `UdpSessionManager.java:92` | `PacketIntegrity.seal(tp.data);` — **return value discarded** | silent | the `SEAL_FOREIGN` outcome is invisible at the one call site that could act on it | fatal | (consume the return; counter as above) | — | — |

### 2.8 `protocol/LobbyKeySniffer.java` — runs over every relayed TCP downlink byte

| file:line | trigger | visibility | consequence | sev | proposed counter | rate | mode |
|---|---|---|---|---|---|---|---|
| `LobbyKeySniffer.java:252-268` | six `continue`s in `scanPermutation` + `if (!ok \|\| seen != 0x1F) continue;` | silent | if field 42 is never matched, `headOrder` stays null, **`TcpProxy.java:294`'s `headOrder != null` test fails and `seedLayout` is never called for the whole session** — the fast path is silently off and the pre-solver window costs its full ~80 % of `RUDP_PLAYER_JOIN` | fatal (windowed) | `PROTO_PERM_CANDIDATE_REJECTED` (counter) + `PROTO_PERM_NEVER_SEEN` (session-end event) | ~0 | both |
| `LobbyKeySniffer.java:302-317` | seven `continue`s in `scan` | silent | a missed key means `decrypted=0` for the whole match. Partially covered: `keyEvents`/`keyRotations` count *successes*, and `:328` is an `android.util.Log.i` — **the only unconditional log in either package** — but nothing counts "scanned N MB, found nothing" | fatal | `PROTO_KEY_NEVER_SEEN` (invariant, §8.3) | 0 | event |
| `LobbyKeySniffer.java:317` | `if (key == null) continue;` | silent | `decodeHex` failed after `isLowerHex` passed — unreachable | benign | — (see §6) | — | — |
| `LobbyKeySniffer.java:344-346` | `catch (Throwable t) { // The sniffer's own job must survive any observer failure. }` | silent | swallows a `SessionTimeline.onSessionKey` failure, so `KEY_ROTATED` silently stops appearing in the capture | degraded | `PROTO_KEY_OBSERVER_THREW` | **0** | event |
| `LobbyKeySniffer.java:211` | `if (buf == null \|\| len <= 0 \|\| off < 0 \|\| off + len > buf.length) return false;` | silent | correct | benign | — (see §6) | — | — |

### 2.9 `protocol/AimBias.java` — dead code, **not instrumented**

`apply()` has **zero callers** anywhere in the repo, and `PacketLoop.java:194-217`
records why (the bias was measured to do nothing: control 19 HP n=81 vs biased
17 HP n=46). Its ten guard-`return -1` paths and four `skipped++` paths are
unreachable and are deliberately left out of the tables. Two notes for whoever
revives or deletes it:

- `AimBias.java:121` `if (n < 4) return -1;` — `readVarints` returns −1 on a parse
  failure, and −1 < 4, so **a parse failure is indistinguishable from a short
  packet and neither increments `skipped`**; `skippedCount()` under-reports.
- `AimBias.java:128`, `:134`, `:156`, `:158` all share one `skipped` counter, so
  "index out of range", "not unit length", "encode failed" and "no room in the
  buffer" are one number.

---

## 3. Hot-path classification summary

The rule applied throughout: anything on the per-packet path gets a **counter
only**; anything that should happen at most a few times per match gets an **event**.

**`counter` only — per-packet, a log line here is unaffordable at 1 000 pkt/s**

`TUNNEL_IP_RUNT`, `TUNNEL_IP_SHORT_L4`, `TUNNEL_DROP_NON_UDP`,
`TUNNEL_ESP_KEEPALIVE_SHAPE_MISS`, `TUNNEL_FILTER_HOLD`, `TUNNEL_TCP_RUNT`,
`TUNNEL_TCP_NO_CONN`, `TUNNEL_TCP_WINDOW_CLOSED`, `TUNNEL_TUN_WRITE_OVER_MTU`,
`TUNNEL_INBOUND_UNCLASSIFIED`, `TUNNEL_HIT_TELEMETRY_WINDOW_MISS`,
`PROTO_CRC_REJECT_OUT`, `PROTO_CRC_REJECT_IN`, `PROTO_PARSE_NULL`,
`PROTO_EMPTY_BODY`, `PROTO_DISPATCH_UNCONSUMED`, `PROTO_SOLVER_NOT_MATCH_TRAFFIC`,
`PROTO_SEED_DUPLICATE`, `PROTO_ELECT_DECLINED`, `PROTO_IDENTITY_FAILURE`,
`PROTO_TAXO_*`, `PROTO_TUPLE_STEADY_RESET`, `PROTO_MOVE_LEN_MISS`,
`PROTO_MOVE_CAND_RESET`, `PROTO_FAMILY_R/S/C`, `PROTO_HIT_SHAPE_REJECT`,
`PROTO_HIT_TEAMBYTE_REJECT`, `PROTO_KIND_UNKNOWN`, `PROTO_HURT_SHORT`,
`PROTO_OWNHANDLE_UNPARSED`, `PROTO_AIMEXP_NO_OWN_HANDLE`,
`PROTO_TIMELINE_EVENT_DROPPED`, `PROTO_TIMELINE_MIRROR_DROPPED`,
`PROTO_MODE_WALK_*`, `PROTO_VISMASK_RESIDUE`, `PROTO_PERM_CANDIDATE_REJECTED`.

**`event` — rare, wants the detail**

`TUNNEL_TUN_EOF`, `TUNNEL_ESTABLISH_NULL`, `TUNNEL_ESTABLISH_THREW`,
`TUNNEL_RECV_THREAD_REJECTED`, `TUNNEL_SO_TIMEOUT_FAILED`,
`TUNNEL_SESSION_IDLE_REAPED`, `TUNNEL_SESSION_IO_ENDED`, `TUNNEL_TUN_WRITE_THREW`,
`TUNNEL_RESTART_ABORTED`, `TUNNEL_RUN_ABORTED_STOPPED`,
`TUNNEL_STANDBY_INTERRUPTED`, `TUNNEL_STATS_LOOP_ENDED`, `TUNNEL_CLOSEALL_THREW`,
`TUNNEL_TASK_DROPPED_STOPPED`, `TUNNEL_TASK_REJECTED`,
`TUNNEL_TCP_WRITER_NOT_STARTED`, `TUNNEL_TCP_RELAY_NOT_STARTED`,
`TUNNEL_TCP_FIN_LOST`, `TUNNEL_TCP_WRITER_THREW`,
`TUNNEL_TCP_WRITE_LOST_NO_STREAM`, `TUNNEL_TCP_RELAY_READ_THREW`,
`TUNNEL_TCP_CLOSE_UNNOTIFIED`, `TUNNEL_TCP_WINDOW_DRAIN_TIMEOUT`,
`TUNNEL_REPLAY_SEND_FAILED`, `PROTO_SEED_ARG_INVALID`, `PROTO_SEED_MALFORMED`,
`PROTO_SEED_NOT_PERMUTATION`, `PROTO_VOTE_GIVEUP`, `PROTO_TIEBREAK_UNCONVINCING`,
`PROTO_COMMIT_BAD_LAYOUT`, `PROTO_UNDECODABLE_SCRATCH`,
`PROTO_ENDPOINT_PARSE_FAILED`, `PROTO_MODE_WALK_ABANDONED`,
`PROTO_TUPLE_MAP_CLEARED`, `PROTO_TUPLE_LEARN_SATURATED`,
`PROTO_MOVE_ENDPOINT_MAP_CLEARED`, `PROTO_MOVE_CAND_MAP_CLEARED`,
`PROTO_MOVE_ENDPOINT_REFUSED`, `PROTO_RMARKER_UNLEARNED`,
`PROTO_VISMASK_ENCRYPTED`, `PROTO_SEAL_NULL`, `PROTO_KEY_OBSERVER_THREW`,
`PROTO_PERM_NEVER_SEEN`.

**`both` — counter plus a log on the first N (suggest N = 5)**

`TUNNEL_DROP_NON_IPV4`, `TUNNEL_UDP_LEN_BAD`, `TUNNEL_SESSION_CREATE_FAILED`,
`TUNNEL_OUTLEN_CLAMPED`, `TUNNEL_UDP_SEND_THREW`,
`TUNNEL_REPLAY_SESSION_SEND_FAILED`, `TUNNEL_UDP_DECODE_THREW`,
`TUNNEL_CHAIN_OVER_CEILING`, `TUNNEL_ALLOWED_APP_REJECTED`, `TUNNEL_SCOPE_EMPTY`,
`TUNNEL_RESTART_JOIN_TIMEOUT`, `TUNNEL_TUN_WRITE_NO_WRITER`,
`TUNNEL_PACKET_LOOP_THREW`, `TUNNEL_TCP_HANDLE_THREW`,
`TUNNEL_TCP_CONNECT_FAILED`, `TUNNEL_TCP_GAP_DISCARDED`,
`PROTO_PARSE_UNSOLVED` (+`_IN`/`_OUT`), `PROTO_LAYOUT_SEED_UNAVAILABLE`,
`PROTO_UNDECODABLE_ZIPPED`, `PROTO_UNDECODABLE_NO_KEY`,
`PROTO_TEA_DECRYPT_FAILED`, `PROTO_BODY_DECRYPT_FAILED`, `PROTO_FORCED_RESOLVE`,
`PROTO_SESSION_RESOLVE`, `PROTO_SEED_REJECTED_BY_WIRE`,
`PROTO_TIMELINE_TCP_THREW`, `PROTO_TIMELINE_UDP_THREW`, `PROTO_TIMELINE_THREW`,
`PROTO_VISMASK_RESIDUE`, `PROTO_SEAL_FOREIGN`.

---

## 4. Expected and high-volume — counters that are *normal to be large*

A counter nobody can read is noise. These are the ones that will dominate the dump,
with what a healthy value looks like.

| counter | healthy value @1k pkt/s | what a *wrong* value means |
|---|---|---|
| `TUNNEL_ESP_KEEPALIVE_SHAPE_MISS` | ~480/s (≈96 % of outbound) | a **drop toward 0** means the shape gate broke and everything is being fed — a **rise to 100 %** means own-state and radar are dark |
| `PROTO_PARSE_NULL` | 0–80/s on a scoped tunnel | ≈100 % of observed = the wrong app is in the tunnel (`foreign=6248` signature) |
| `PROTO_SOLVER_NOT_MATCH_TRAFFIC` | 0–80/s | same; this is the earliest place the condition is visible |
| `PROTO_CRC_REJECT_IN` / `_OUT` | ≲8 % of parsed | a sustained >20 % means the layout is on the wrong bytes |
| `PROTO_SEED_DUPLICATE` | 0–20/s over the downlink | 0 for a whole session means `seedLayout` is never being called at all |
| `PROTO_TAXO_KEEPALIVE_LEN_MISS` | ~400/s | — (pure denominator) |
| `PROTO_MOVE_LEN_MISS` | ~350/s | — (pure denominator) |
| `PROTO_TUPLE_STEADY_RESET` | ~50/s | resets ≫ confirmations for >30 s means the keepalive channel will never confirm |
| `PROTO_HIT_SHAPE_REJECT` | ~30/s | ≈100 % of 20–40 B inbound means the `team<<3` assumption broke |
| `PROTO_KIND_UNKNOWN` | <20 % of classified | a rising share means the shape heuristics have drifted off this session |
| `PROTO_DISPATCH_UNCONSUMED` | ~200/s | — (most commands have no registered decoder) |
| `PROTO_FAMILY_R/S/C` | R ≫ 0, S ≫ 0, C modest | **C ≈ 100 % means the encoding rotated and nothing is classified** |
| `PROTO_UNDECODABLE_NO_KEY` | should be 0 — **is currently ~100/s always**, see §0.3 | this is the seam that is wired to nothing |

Counters whose healthy value is **exactly zero**, and which therefore deserve an
alarm rather than a column: `PROTO_UNDECODABLE_ZIPPED`, `PROTO_VISMASK_RESIDUE`,
`PROTO_VOTE_GIVEUP`, `PROTO_TIEBREAK_UNCONVINCING`, `PROTO_COMMIT_BAD_LAYOUT`,
`PROTO_TIMELINE_TCP_THREW`, `PROTO_TIMELINE_UDP_THREW`, `PROTO_SEAL_FOREIGN`,
`TUNNEL_UDP_LEN_BAD`, `TUNNEL_OUTLEN_CLAMPED`, `TUNNEL_CHAIN_OVER_CEILING`,
`TUNNEL_TUN_WRITE_NO_WRITER`, `TUNNEL_SCOPE_EMPTY`.

---

## 5. Existing ad-hoc counters to fold into the registry

All of these are already correct; they only need a name in the registry and an
exit to the dump. See §0.2 — none of them is read today.

| current name | file:line | proposed registry name |
|---|---|---|
| `SessionKeySolver.seedsAccepted` | `SessionKeySolver.java:245`, read `:265` | `PROTO_SEED_ACCEPTED` |
| `SessionKeySolver.seedsRejected` | `SessionKeySolver.java:553`, read `:266` | `PROTO_SEED_REJECTED_BY_WIRE` |
| `SessionKeySolver.solveCount` | `:513`, read `:286` | `PROTO_LAYOUT_SOLVED` |
| `SessionKeySolver.resolveCount` | `:559`, read `:291` | `PROTO_SESSION_RESOLVE` |
| `SessionKeySolver.packetsObserved` | `:309`, read `:281` | `PROTO_SOLVER_OBSERVED` |
| `PacketPipeline.parsed` | `:241`, read `:160` | `PROTO_PARSED` |
| `PacketPipeline.crcFailures` | `:278`, read `:165` | `PROTO_DISPATCH_CRC_REJECT` (note the accounting trap in §2.1) |
| `PacketPipeline.undecodable` | `:286`, `:293`, `:299`, `:305`, read `:170` | **split four ways** — `PROTO_UNDECODABLE_ZIPPED` / `_NO_KEY` / `_SCRATCH` / `PROTO_TEA_DECRYPT_FAILED` |
| `PacketPipeline.forcedResolves` | `:261`, read `:175` | `PROTO_FORCED_RESOLVE` |
| `PacketPipeline.crcFailureRun` | `:258` | gauge `PROTO_CRC_FAILURE_RUN` |
| `PacketIntegrity.SEALED` | `:60`, `:66`, read `:80` | `PROTO_SEAL_OK` |
| `PacketIntegrity.REPAIRED` | `:67`, read `:92` | `PROTO_SEAL_REPAIRED` (healthy = 0) |
| `LobbyKeySniffer.keyEvents` | `:339`, read `:148` | `PROTO_KEY_SEEN` |
| `LobbyKeySniffer.keyRotations` | `:341`, read `:153` | `PROTO_KEY_ROTATED` |
| `VisibilityMask.hiddenStream` | `:132`, read `:136` | `PROTO_VISMASK_STREAMED_WHILE_HIDDEN` |
| `VisibilityMask.updates` / `peakVisible` | `:84`, `:87` | `PROTO_VISMASK_UPDATES` / gauge `PROTO_VISMASK_PEAK` |
| `SessionTimeline.tcpUpBytes` / `tcpDownBytes` / `assignments` | `:233`, `:237`, `:796` | `PROTO_LOBBY_UP_BYTES` / `_DOWN_BYTES` / `PROTO_MATCH_ASSIGNED` |
| `SessionTimeline.eventCount` / `mirrorCount` | `:652`, `:657` | gauges `PROTO_TIMELINE_QUEUE_DEPTH` / `_MIRROR_DEPTH` |
| `GamePacketTaxonomy.voiceFrames` | `:541`, drained `:550` | **dead — `countVoiceFrame()` has no callers**; delete or wire |
| `AimBias.applied` / `skipped` | `:163`, `:128`/`:134`/`:156`/`:158` | dead (`apply()` uncalled) — see §2.9 |
| `AimBiasExperiment.hits[]` / `damageSum[]` / `damageMax[]` | `:88-90` | `PROTO_AIMEXP_*` (harness off by default) |
| `VpnEngine.bIn` / `bOut` / `pSent` / `pDrop` / `outUdpSeen` | `VpnEngine.java:54-58` | `TUNNEL_BYTES_IN` / `_OUT` / `TUNNEL_PKT_SENT` / `TUNNEL_PKT_DROPPED` / `TUNNEL_OUT_UDP_SEEN`. **Audit #15: never reset**, so the HUD loss % is a lifetime average that can never recover. `pDrop` needs the three-way split from §1.1 |

---

## 6. Bails that are correct and should stay silent

Listed so nobody instruments them later and adds noise.

- `PacketLoop.java:62-66` — ICMP echo handled and consumed; the failure path is
  already covered at `PacketBuilder.java:96`.
- `PacketLoop.java:174-178` — `isVehicleCarrier(cmd)` false: a dispatch, not a bail.
- `UdpSessionManager.java:118-122`, `:387-391`, `:397-403` — `catch` around
  `Socket.close()`. Nothing can be done and nothing is lost.
- `UdpSessionManager.java:163-166` — `putIfAbsent` lost the race; closing the loser
  and returning the winner is exactly right.
- `UdpSessionManager.java:268` — `default: break;` in the command switch. The outer
  `if` at `:241` already enumerates every case; the default is unreachable.
- `VpnEngine.java:546` — `if (isActive)` around scope+routes. Standby deliberately
  installs neither; the comment at `:533-544` explains why. Covered by invariant §8.10.
- `VpnEngine.java:614` — `if (isRun && vpnT == Thread.currentThread() && !stopped)`.
  The negative branch is the restart handoff working correctly.
- `VpnEngine.java:719-721` — `scheduleLobbyRouteFallbackIfNoUdp` is a deliberate
  no-op with 15 lines of javadoc saying why. Do not add a counter; it would only
  measure how often a dead call site is reached.
- `VpnEngine.java:726` — `statsRunning.compareAndSet` idempotence guard.
- `TcpProxy.java:137` — non-ACK, non-SYN segment ignored; correct TCP.
- `TcpProxy.java:219`, `:356`, `:393`, `:416` — routine null checks on queue/map reads.
- `PacketBuilder.java:60-62` — "not an echo request" is the overwhelmingly common
  case and correctly returns false.
- `TunAddressPool.java:45-49` — cursor out of range ⇒ random start. Deliberate.
- `SessionKeySolver.java:303` — `INBOUND && SOLVED` fast-path skip. Documented, correct.
- `SessionKeySolver.java:325-327` — `default: break;` over a 3-value enum, all handled.
- `SessionKeySolver.java:407` — `if (bestPerm < 0) return;` on an empty tally.
- `SessionKeySolver.java:535` — `if (l == null) return;` benign race with `reset()`.
- `SessionTimeline.java:535-537` — `default: break;` in `applyUdpCmd`. ~900/s of
  non-lifecycle commands; a counter here measures nothing.
- `SessionTimeline.java:769` — mode-walk dedup for a signature seen twice, which the
  carry-join window guarantees.
- `SessionTimeline.java:862` — `else break;` on protobuf group wire types, unused by
  this schema.
- `GamePacketTaxonomy.java:430-440` — the 2 s header re-adoption rate limit.
- `GamePacketTaxonomy.java:806-808` — `hitZone` returns 0 unconditionally, on purpose.
  Do not instrument; delete when `106.v7`/`168.v3` fully replace it.
- `GamePacketTaxonomy.java:900-923` — `default:` in `familyName`/`kindName`; display only.
- `VisibilityMask.java:69` — the Cmd 135 dispatch guard.
- `VisibilityMask.java:117` — `entityId < 0`.
- `AimBiasExperiment.java:105`, `:110`, `:115` — command dispatch guards.
- `LobbyKeySniffer.java:211`, `:317` — argument validation and an unreachable
  `decodeHex` failure.

One honest note on `SessionKeySolver.reset()` (`:332-346`): it clears
`primaryScore`/`secondaryScore` but not `orderScore`/`lastOrderId`. Harmless —
both are reallocated in `elect()` at `:426-428` before any read — but it reads as
an omission and is worth a comment rather than a counter.

---

## 7. Existing log calls — keep these, do not duplicate

Every one is `devMode`-gated (§0.1). The recommendation is to keep the log text
verbatim and add an unconditional counter beside it, not to replace it.

| file:line | call | keep? |
|---|---|---|
| `PacketBuilder.java:92` | `logPacket("REPLY_ICMP_ECHO", ...)` | yes — low volume, useful |
| `PacketBuilder.java:97` | `logProtocolDrop("DROP_ICMP_ECHO_REPLY_FAIL", ...)` | yes + counter |
| `PacketLoop.java:49` | `logProtocolDrop("DROP_NON_IPV4", ...)` | yes + counter |
| `PacketLoop.java:78` | `logProtocolDrop("DROP_NON_UDP", ...)` | yes + counter |
| `UdpSessionManager.java:376` | `logControl("UDP_DECODE_THREW", cls/msg)` | **yes — the text is the whole diagnosis**; add `TUNNEL_UDP_DECODE_THREW` |
| `VpnEngine.java:236` | `logControl("TELEMETRY_DUMP", file)` | yes |
| `VpnEngine.java:341` | `logControl("MODE_VPN_ROUTE_CHANGED", route/active/run)` | yes |
| `VpnEngine.java:445` | `logControl("MODE_VPN_RESTART_JOIN_TIMEOUT", ...)` | **yes** + `TUNNEL_RESTART_JOIN_TIMEOUT` |
| `VpnEngine.java:563` | `logControl("MODE_VPN_SCOPE_EMPTY", requested/applied)` | **yes** + `TUNNEL_SCOPE_EMPTY`; extend to name the *individual* package that failed at `:552` |
| `VpnEngine.java:573` | `logControl("MODE_VPN_TUN_READY", active/route/pkg/applied/tun_ip)` | **yes — the single best line in the package**; it already prints requested vs applied vs route mode |
| `VpnEngine.java:831` | `logControl("CAPTURE_ON", ...)` | yes |
| `VpnEngine.java:869` | `logControl("DECODED_DUMP_FAIL", throwable)` | yes + counter |
| `VpnEngine.java:877` | `logControl("CAPTURE_OFF", raw/report/decoded)` | yes |
| `LobbyKeySniffer.java:328` | `android.util.Log.i("FakelagKey", "lobby key recovered for " + ep + " : " + hex)` | **yes — the only unconditional log in either package.** Keep it exactly as it is |

Gap: there is **no** log or counter for `builder.establish()` returning null
(`VpnEngine.java:569`), which is the most abrupt fatal path in the package.

---

## 8. Invariants worth alarming on

Each threshold is sourced, not invented.

**8.1 — Outbound and inbound packet counts stay within an order of magnitude once
a match is live.**
`abs(log10(TUNNEL_OUT_UDP_SEEN / TUNNEL_PKT_IN)) < 1`, evaluated over a 10 s window
while `SessionTimeline.phaseId() == P_MATCH`.
Source: `WHEN_NOTHING_WORKS.md` §0 — healthy is `out=972 in=870`; the wrong-app
failure is `out=1 in=6247`. "The single most diagnostic number is the out/in ratio."
Violation ⇒ the game's traffic is not entering the tunnel: check
`TUNNEL_SCOPE_EMPTY` and `TUNNEL_ALLOWED_APP_REJECTED` first.

**8.2 — The header layout is committed within 3 s of the first match UDP packet.**
`PROTO_LAYOUT_SOLVED > 0` within 3 000 ms of the first `PROTO_SOLVER_OBSERVED`
increment after a reset.
Source: `SessionKeySolver.java:189-191` measures voting at 1.1–2.6 s / ~440 packets;
`PREKEY_WINDOW_FIX.md` §5.2 measures the lobby seed arriving 231–274 ms *before*
the first UDP packet. 3 s is the voting ceiling plus margin.
Violation ⇒ the seed path is off; check `PROTO_LAYOUT_SEED_UNAVAILABLE`,
`PROTO_PERM_NEVER_SEEN`, `PROTO_VOTE_GIVEUP`.

**8.3 — A session key is recovered within 5 s of `MATCH_ASSIGNED`.**
`PROTO_KEY_SEEN` increments within 5 000 ms of a `PROTO_MATCH_ASSIGNED` increment.
Source: `LobbyKeySniffer.java:43-48` — the key and the assignment are **fields 2 and
3 of the same message**, so they are byte-adjacent and arrive together. Any gap at
all means the scan missed it.
Violation ⇒ `decrypted=0` for the whole match; ESP health and names are dead.

**8.4 — `PROTO_UNDECODABLE_ZIPPED` stays at exactly 0.**
Source: `WHEN_NOTHING_WORKS.md` §3 — the ZIPPED bit is set on **0 of 88 413**
packets once the header is read correctly; the wrong permutation made ~49 % of
packets look zipped and silently discarded 14 911 of them in one capture.
Violation, even by one ⇒ the solver elected the wrong permutation. This is the
highest-value single alarm in the package.

**8.5 — A UDP session is not recreated more than 3 times per minute per 3-tuple.**
Count `TUNNEL_SESSION_CREATE` per `(sp,dp,dip)` key.
Source: `UdpSessionManager.java:32` — `IDLE = 0xafc8` = 45 000 ms, so a healthy
long-lived match flow is created **once**. Each recreation is a new source port,
which is the documented kick fingerprint (`ff-ack-starvation-kicks`,
`UdpSessionManager.java:357-368`). 3/min allows for one genuine handover plus
margin.
Violation ⇒ correlate with `TUNNEL_SESSION_IDLE_REAPED`, `TUNNEL_SESSION_IO_ENDED`
and `TUNNEL_UDP_SEND_THREW`.

**8.6 — `PROTO_SESSION_RESOLVE` fires at most once per `PROTO_KEY_ROTATED`.**
Source: `SessionKeySolver.java:88` — `RESOLVE_FAILURE_RUN = 24` exists to catch a
key rotation, and the key rotates once per match
(`WHEN_NOTHING_WORKS.md` §2: "the key is sent once per match"). A resolve without a
matching rotation means the Length identity is failing for some other reason.
Violation ⇒ check `PROTO_IDENTITY_FAILURE` (the 1–23 window with no counter today).

**8.7 — The R-marker is learned within 500 outbound packets, or the taxonomy is
running on its weak fallback.**
`learnedRMarker != -1` by the time `PROTO_TAXO_KEEPALIVE_LEN_MISS +
PROTO_FAMILY_R/S/C` reaches 500.
Source: `GamePacketTaxonomy.java:626-632` — the marker needs one outbound packet
with `b2 == b3`, and at ~500 outbound/s that is well under a second on a
constant-mask session. A session that never learns it is a keystream session, where
`family()` falls back to `b2 == b3^1` (`:615`) for good.
Violation ⇒ freeze's family-R protection is degraded; expect reliability-timer
starvation symptoms.

**8.8 — `VisibilityMask.peakVisible() <= 63`.**
Source: `VisibilityMask.java:43-45` — `1ULL << 64 == 1ULL << 0`, and the largest
entity id measured is **64**, which aliases onto bit 0. A peak at 64 means the
aliasing is live and `isVisible()` is returning a wrong answer for somebody.
Violation ⇒ ESP visibility filtering is silently wrong for at least one entity.

**8.9 — `TUNNEL_TCP_TOCLIENT_DEPTH` stays under 64 segments (~80 KB at MSS 1240).**
Source: `TcpProxy.java:66-67` and audit #14 — `toClient` is an unbounded
`ArrayDeque` drained only by `flushToClient` (`:349`), which returns early whenever
the client window is shut (`:359`). The drain timeout at `:318` gives up after
100×50 ms = 5 s. 64 segments is ~4× the largest observed burst and still well under
the 5 s give-up. Related: the dead sign guard at `:358` (audit #25) means the window
check mis-evaluates on sequence wrap, which is one way to reach this state.
Violation ⇒ the lobby connection is about to be RST and lose queued data.

**8.10 — An ACTIVE tunnel always has at least one route AND at least one allowed
app, or neither.**
`(TUNNEL_ROUTES_INSTALLED > 0) == (TUNNEL_APPS_SCOPED > 0)` at every
`MODE_VPN_TUN_READY`.
Source: `VpnEngine.java:533-544` — "SCOPE AND ROUTES MUST BE GATED TOGETHER";
audit #2 recorded a tunnel scoped to the game with **zero routes**, holding open the
one app that must never lose connectivity with nowhere for its packets to go. The
inverse (routes, no scope) is audit #9: a silent downgrade to the narrow 148/8 pair
that misses the 43.252.x match servers.
Violation ⇒ refuse to report ACTIVE.

**8.11 — `TUNNEL_TUN_WRITE_NO_WRITER` stays at exactly 0 while the engine is ACTIVE.**
Source: `VpnEngine.java:414-423` — the documented restart handoff race, where the
retiring thread's `finally` (`:597`) nulls the new session's `tunWriter` (`:584`).
Every subsequent `writeToTun` returns silently at `:793`: "lobby and login traffic
relayed OUT with nothing ever delivered back, forever, with no retransmit queue and
no error anywhere."
Violation ⇒ correlate with `TUNNEL_RESTART_JOIN_TIMEOUT`; the tunnel is a black
hole for TCP and only a restart will clear it.

**8.12 — `PROTO_SEAL_FOREIGN` stays at 0 on the replay path.**
Source: `PacketIntegrity.java:22-29` and `UdpSessionManager.java:80-88` — `send()`
is the single choke point for every packet the app puts on the wire that did not
come off the tun. A FOREIGN outcome there means a replayed match packet was not
recognised and therefore left with a **stale CRC-7**, which the server treats as
corrupt — the leading suspect for the "server sets us back" behaviour in
`TELEPORT.md`.
Violation ⇒ ghost/teleport replays are being silently rejected by the server.

---

## 9. What to build first

Ranked by (probability of recurrence) × (hours previously lost), using this repo's
own history:

1. **Unconditional counters that do not go through `DevLogger`** (§0.1) — without
   this, nothing else in the doc works in a real session.
2. **An exit for the counters that already exist** (§0.2, §5) — the numbers are
   already being collected; they just have nowhere to go.
3. **Split `PacketPipeline.undecodable` four ways** (§2.1) — one of those four
   (`ZIPPED`) is the §8.4 alarm and is currently invisible inside a pooled total.
4. **`TUNNEL_SCOPE_EMPTY` + `TUNNEL_ALLOWED_APP_REJECTED`** (§1.3) — failure mode #1
   in the playbook, diagnosed three separate times.
5. **`PROTO_PARSE_UNSOLVED` + `PROTO_LAYOUT_SEED_UNAVAILABLE`** (§1.1, §1.4) — the
   pre-key window, which `PREKEY_WINDOW_FIX.md` calls the highest-value remaining fix.
6. **`TUNNEL_TUN_WRITE_NO_WRITER` and `TUNNEL_ESTABLISH_NULL`** (§1.3) — two fatal
   paths with literally no output today.
