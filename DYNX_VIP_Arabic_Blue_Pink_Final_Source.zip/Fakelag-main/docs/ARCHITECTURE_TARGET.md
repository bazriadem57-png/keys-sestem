# Target package architecture — `com.fakelag.cryhard8`

Module: `fakelag/fakelag-beta/app`
Source root: `app/src/main/java/com/fakelag/cryhard8/`
Java 8 (`sourceCompatibility 1.8`), `compileSdk 35`, `minSdk 21`, `namespace = applicationId = com.fakelag.cryhard8`.

**This is a move/rename refactor. Behaviour must not change.** Every step below is a
package move, a file split along an existing seam, or the deletion of code with a proven
zero-reference count. Nothing here changes a decision, a constant, a threshold, or an
order of operations. Where a step *could* change behaviour if done carelessly, that is
called out explicitly.

Current state: **97 Java files in 10 packages** —
root 5, `app` 5, `core` 7, `dev` 2, `dev/capture` 10, `esp` 7, `filter` 18, `net` 27,
`overlay` 14, `replay` 2.

---

## 0. Facts established before designing (read this first)

These were measured, not assumed. They change what is safe.

| Check | Command | Result |
|---|---|---|
| Inline fully-qualified references | `rg -n "com\.fakelag\.cryhard8\." --glob '*.java' \| rg -v ':(package\|import) '` | **277 hits.** An import-only rewrite breaks silently. |
| String-literal class names | `rg -n '"com\.fakelag' --glob '*.java'` | Only `VpnActions` intent-action strings (`"com.fakelag.cryhard8.ACTIVATE"` etc.). These are **not** class names — do not touch them, they are the IPC contract between the activity, the services and the overlay. |
| Reflection | `rg -n "Class\.forName\|getDeclaredMethod\|getMethod\(\|newInstance\|setAccessible" --glob '*.java'` | **Zero hits repo-wide.** `overlay/AimInjector.java` uses Shizuku's typed `ShizukuBinderWrapper` + `hiddenapibypass`, not string lookup. No reflection risk from moves. |
| Custom views named in XML | `rg -n "com.fakelag" app/src/main/res/` | **Zero hits.** `EspRenderView`, `CrosshairView` etc. are constructed in code. No layout XML to update. |
| ProGuard/R8 keep rules | `cat app/proguard-rules.pro` | **Empty file** (0 bytes). `minifyEnabled true` in release, but no keep rule names a package. Moves are safe under R8. |
| Manifest class paths | `app/src/main/AndroidManifest.xml` | Names exactly three classes: `com.fakelag.cryhard8.MainActivity`, `.FloatingOverlayService`, `.PacketVpnService`. |

**Two corrections to the brief's assumptions**, both verified:

* `filter/MarkFilter.java` reaches `MarkTarget` by a normal **import** (line 4), not an
  inline FQN. The inline `com.fakelag.cryhard8.esp.MarkTarget` write is in
  `overlay/EspRenderView.java:1586,1590`.
* `com.fakelag.cryhard8.filter.MarkFilter.ENABLED` is read inline from
  **`overlay/EspTunePanel.java:317`**, and written from `esp/EspTuning.java:242`.

---

## 1. Target tree

```
com.fakelag.cryhard8
│
├── (root)                 3 files — the Android components the manifest names, nothing else
│
├── util/                  NEW. Leaf. Zero dependencies on any other app package.
│                          Varints, ZigZag, Hex, MathUtil, Bytes.
│
├── config/                NEW. Persisted + tunable state and the IPC contract.
│                          Everything a UI writes and a worker reads, in one place.
│
├── decode/                NEW (from net/). Stateless wire codec. No Android imports,
│   │                      no session state, no threads. Pure bytes <-> values.
│   ├── frame/             the UDP envelope: byte 0, flags, header permutation, CRC-7
│   ├── crypt/             TEA block cipher and body decryption
│   └── body/              message-body reader, layout table, catalogue, per-Cmd decoders
│
├── protocol/              NEW (from net/ + 2 from filter/). STATEFUL protocol observers:
│                          things that learn across packets (session solve, timeline,
│                          visibility, taxonomy, integrity, aim bias).
│
├── tunnel/                <- core/. The VPN transport: tun loop, UDP sessions, TCP relay.
│
├── filter/                Packet policies (unchanged name — it is already coherent).
│   ├── aim/               AimFilter's rewrite internals (from the split)
│   └── replay/            <- replay/. Only filters use it; nest it under its only consumer.
│
├── esp/                   ESP domain state. No Android, no drawing.
│
├── ui/                    All Android UI. Split BY WIDGET KIND, per the ask.
│   ├── overlay/           WindowManager window hosts (add/remove/layout-params lifecycle)
│   ├── render/            Canvas drawing: the ESP render view + its helpers
│   ├── panel/             The in-game tune panel: rows, sections, knob plumbing
│   ├── button/            Floating buttons, their drawables, touch listeners, animators
│   ├── aim/               Aim input: Shizuku injection, calibration, drag editor, touch watch
│   └── settings/          <- app/. The settings-activity helpers.
│
└── dev/                   Dev logging
    └── capture/           Packet capture + offline dumpers (unchanged)
```

### Why each package exists (one line each)

| Package | Rationale |
|---|---|
| `util` | The five helper families currently reimplemented 17 times across 13 files. Must have **zero** app dependencies so anything can use it without creating a cycle. |
| `config` | The user's ask for a place where "our code is clean": one home for `SharedPreferences` keys, the intent-action contract, the live-tuning write-through, and the game-package list. Breaks two dependency cycles as a side effect (see §6). |
| `decode/frame` | The UDP envelope is solved and immutable — byte 0 range, flags, `HEAD_SECRET` permutation, CRC-7. It never learns anything, so it belongs at the bottom. |
| `decode/crypt` | TEA + body decryption. Separate from `frame` because it is keyed and the key arrives over a different transport (lobby TCP). |
| `decode/body` | The varint/zigzag message-body layer — the maths the user asked to isolate. Reader, layout-program table, text dump, catalogue, and the two per-Cmd decoders. |
| `protocol` | Everything in the old `net/` that holds session state. Keeping it apart from `decode/` is what makes `decode/` safely testable and reusable. |
| `tunnel` | `core/` renamed to say what it is. Owns the tun fd, the UDP session map, the TCP relay — the only package that touches sockets. |
| `filter` | Already coherent: `PacketFilter` implementations plus their shared context/value types. |
| `filter/aim` | `AimFilter` is 1140 lines with four responsibilities; the three that are not "policy" get their own files under a sub-package. |
| `filter/replay` | `replay/` is a top-level package with exactly two files used by exactly one package. Nest it. |
| `esp` | The ESP tracking domain — engine, tracks, roster, health, orientation. Stays free of Android and of `overlay` (§6). |
| `ui/overlay` | Classes whose job is `WindowManager.addView` / `LayoutParams` / remove-lifecycle. |
| `ui/render` | Classes whose job is `Canvas`. Separate from `ui/overlay` because the render view is the only real drawing code and it is 1865 lines. |
| `ui/panel` | The tune panel's rows and sections — a distinct widget kind from buttons. |
| `ui/button` | Explicitly requested. Round floating buttons, their ring drawable, their drag/tap listeners, their animators. |
| `ui/aim` | Aim *input* (injection, calibration, drag editing, real-touch watching) is not drawing and not a window host; it is its own subsystem with its own failure mode (Shizuku). |
| `ui/settings` | `app/` renamed. The settings screen's view bindings, permission rows, app picker, appearance broadcast. |
| `dev` / `dev/capture` | Already correct. No change. |

### Layering rule (enforce by review; there is no module system here)

```
util  <-  decode  <-  protocol  <-  { esp, filter, tunnel }  <-  ui  <-  root
                          ^                                        |
                        config  <------------------------------------
```

`config` sits to the side: it may depend on `esp`, `filter` and `ui/render` (it writes
their statics), and everything may depend on it. That is deliberate — it is the *only*
package allowed to reach "upward", and concentrating that privilege in one small package
is what removes the cycles listed in §6.

---

## 2. Move table — all 97 files

`= ` means "stays where it is".

### root (5)

| File | Destination | Note |
|---|---|---|
| `MainActivity.java` | `= root` | Manifest-named. Recommend leaving. |
| `PacketVpnService.java` | `= root` | Manifest-named. |
| `FloatingOverlayService.java` | `= root` | Manifest-named. |
| `Prefs.java` | `config/Prefs.java` | **Key strings must not change.** 107 `KEY_*` constants persisted in `SharedPreferences("xevpn_prefs")` on the user's device. The package move does not touch them — edit only the `package` line and the imports. |
| `VpnActions.java` | `config/VpnActions.java` | Its `"com.fakelag.cryhard8.ACTIVATE"`-style strings are **intent actions, not class names**. Leave every string byte-identical. |

> **Judgement call (root).** *Recommendation:* leave the three Android components at root.
> After the reorg, root contains exactly the three classes the manifest names — a clean,
> conventional Android layout, and it needs zero manifest edits.
> *Alternative:* move them into `app/` (or `ui/`), in which case update
> `AndroidManifest.xml` lines 34, 47 and 55:
> `android:name="com.fakelag.cryhard8.MainActivity"` -> `...app.MainActivity`, and likewise
> for `FloatingOverlayService` and `PacketVpnService`. The real cost is that a user's
> pinned launcher shortcut targets the old component name and would break.

### app/ (5) -> `ui/settings/` and `config/`

| File | Destination |
|---|---|
| `app/AppPicker.java` | `ui/settings/AppPicker.java` |
| `app/AppearanceBroadcaster.java` | `ui/settings/AppearanceBroadcaster.java` |
| `app/PermissionController.java` | `ui/settings/PermissionController.java` |
| `app/UiBindings.java` | `ui/settings/UiBindings.java` |
| `app/GameTargets.java` | `config/GameTargets.java` — **not** `ui/settings`. `core/VpnEngine.java:494,500` and `overlay/EspOverlay.java:222` both read it; routing it through a `ui/` package would make the tunnel depend on the UI. |

### core/ (7) -> `tunnel/`

| File | Destination |
|---|---|
| `core/PacketBuilder.java` | `tunnel/PacketBuilder.java` |
| `core/PacketLoop.java` | `tunnel/PacketLoop.java` |
| `core/TcpProxy.java` | `tunnel/TcpProxy.java` |
| `core/TunAddressPool.java` | `tunnel/TunAddressPool.java` |
| `core/UdpSessionManager.java` | `tunnel/UdpSessionManager.java` |
| `core/VpnEngine.java` | `tunnel/VpnEngine.java` |
| `core/VpnEngineState.java` | `tunnel/VpnEngineState.java` |

### dev/ (2) — unchanged

| File | Destination |
|---|---|
| `dev/DevLogger.java` | `= dev/` |
| `dev/DevLoggerImpl.java` | `= dev/` |

### dev/capture/ (10) — unchanged

| File | Destination |
|---|---|
| `dev/capture/CaptureAnnotator.java` | `= dev/capture/` |
| `dev/capture/CaptureEvent.java` | `= dev/capture/` |
| `dev/capture/CaptureRecord.java` | `= dev/capture/` |
| `dev/capture/CaptureRing.java` | `= dev/capture/` |
| `dev/capture/CaptureWriter.java` | `= dev/capture/` |
| `dev/capture/DecodedDumper.java` | `= dev/capture/` |
| `dev/capture/FreezeDiffAnalyzer.java` | `= dev/capture/` |
| `dev/capture/LobbyCapture.java` | `= dev/capture/` |
| `dev/capture/PacketCapture.java` | `= dev/capture/` |
| `dev/capture/TelemetryCollector.java` | `= dev/capture/` |

### esp/ (7)

| File | Destination |
|---|---|
| `esp/EspEngine.java` | `= esp/` — **SPLIT**, see §3.1 |
| `esp/EspBodyDecoders.java` | `= esp/` |
| `esp/MarkTarget.java` | `= esp/` |
| `esp/MatchRoster.java` | `= esp/` |
| `esp/OrientationProvider.java` | `= esp/` |
| `esp/PriTracker.java` | `= esp/` |
| `esp/EspTuning.java` | **`config/EspTuning.java`** — the single most valuable move in this plan; it alone removes the `esp -> overlay` and `esp -> filter` upward edges (§6). |

### filter/ (18)

| File | Destination |
|---|---|
| `filter/AimFilter.java` | `= filter/` — **SPLIT**, see §3.4 |
| `filter/DefaultFilterEngine.java` | `= filter/` |
| `filter/FilterDecision.java` | `= filter/` |
| `filter/FilterEngine.java` | `= filter/` |
| `filter/FilterKind.java` | `= filter/` |
| `filter/FreezeFilter.java` | `= filter/` |
| `filter/GhostFilter.java` | `= filter/` |
| `filter/MarkFilter.java` | `= filter/` |
| `filter/PacketClassifier.java` | `= filter/` |
| `filter/PacketContext.java` | `= filter/` |
| `filter/PacketFilter.java` | `= filter/` |
| `filter/PacketSender.java` | `= filter/` |
| `filter/TelePacket.java` | `= filter/` |
| `filter/TeleportFilter.java` | `= filter/` |
| `filter/TeleportState.java` | `= filter/` |
| `filter/GamePacketTaxonomy.java` | **`protocol/GamePacketTaxonomy.java`** — 923 lines of wire classification with learned session state (match-server IP, movement signature). It is not a `PacketFilter`; it has 13 consumers across `tunnel`, `dev/capture`, `filter` and `overlay`. |
| `filter/PacketIntegrity.java` | **`protocol/PacketIntegrity.java`** — CRC-7 seal/repair, consumed by `tunnel/UdpSessionManager`, `tunnel/VpnEngine` and `filter/AimFilter`. Protocol, not policy. |
| `filter/JitterFilter.java` | **DELETE** (dead, §5) — or `= filter/` if the main agent prefers to defer deletion to its own commit. |

### net/ (27) -> `decode/**` + `protocol/`

| File | Destination |
|---|---|
| `net/MsgKey.java` | `decode/frame/MsgKey.java` |
| `net/PacketFlags.java` | `decode/frame/PacketFlags.java` |
| `net/SendOption.java` | `decode/frame/SendOption.java` |
| `net/Direction.java` | `decode/frame/Direction.java` |
| `net/HeaderField.java` | `decode/frame/HeaderField.java` |
| `net/HeaderLayout.java` | `decode/frame/HeaderLayout.java` |
| `net/PacketCodec.java` | `decode/frame/PacketCodec.java` |
| `net/Crc7.java` | `decode/frame/Crc7.java` |
| `net/UdpPacket.java` | `decode/frame/UdpPacket.java` |
| `net/Tea.java` | `decode/crypt/Tea.java` |
| `net/BodyCrypt.java` | `decode/crypt/BodyCrypt.java` |
| `net/WireReader.java` | `decode/body/WireReader.java` |
| `net/BodyDecoder.java` | `decode/body/BodyDecoder.java` |
| `net/BodyDecoderRegistry.java` | `decode/body/BodyDecoderRegistry.java` |
| `net/BodyDecoderTable.java` | `decode/body/BodyDecoderTable.java` |
| `net/BodyDecoderText.java` | `decode/body/BodyDecoderText.java` |
| `net/Cmd.java` | `decode/body/Cmd.java` |
| `net/CmdCatalogue.java` | `decode/body/CmdCatalogue.java` |
| `net/PositionSync.java` | `decode/body/PositionSync.java` |
| `net/PriSync.java` | `decode/body/PriSync.java` |
| `net/PacketPipeline.java` | `protocol/PacketPipeline.java` |
| `net/SessionKeySolver.java` | `protocol/SessionKeySolver.java` |
| `net/SessionTimeline.java` | `protocol/SessionTimeline.java` |
| `net/VisibilityMask.java` | `protocol/VisibilityMask.java` |
| `net/LobbyKeySniffer.java` | `protocol/LobbyKeySniffer.java` |
| `net/AimBias.java` | `protocol/AimBias.java` |
| `net/AimBiasExperiment.java` | `protocol/AimBiasExperiment.java` |

> **Judgement call (`PositionSync` / `PriSync`).** *Recommendation:* `decode/body`.
> `PriSync` is a stateless decode of Cmd 1900; `PositionSync` holds only per-packet parse
> state (offsets and widths for the buffer currently being rewritten), not session state.
> *Alternative:* `protocol/`, if the rule you prefer is "anything with an instance and a
> `dirty` flag lives in protocol". Either works — but do not split the pair.

> **Judgement call (`SessionKeySolver`).** *Recommendation:* `protocol/`, because it
> *learns* the layout across packets and `PacketPipeline` owns it. Its immutable output,
> `HeaderLayout`, correctly stays in `decode/frame`. *Alternative:* `decode/crypt/` if you
> read "key solving" as crypto; it stays acyclic either way since it needs nothing from
> `protocol`.

### overlay/ (14) -> `ui/**`

| File | Destination |
|---|---|
| `overlay/EspOverlay.java` | `ui/overlay/EspOverlay.java` |
| `overlay/DevPopup.java` | `ui/overlay/DevPopup.java` |
| `overlay/MaskBar.java` | `ui/overlay/MaskBar.java` |
| `overlay/CrosshairView.java` | `ui/overlay/CrosshairView.java` |
| `overlay/EspRenderView.java` | `ui/render/EspRenderView.java` — **SPLIT**, see §3.2 |
| `overlay/EspTunePanel.java` | `ui/panel/EspTunePanel.java` — **SPLIT**, see §3.3 |
| `overlay/OverlayButton.java` | `ui/button/OverlayButton.java` |
| `overlay/AnimatedCircleDrawable.java` | `ui/button/AnimatedCircleDrawable.java` |
| `overlay/OverlayTouchListener.java` | `ui/button/OverlayTouchListener.java` |
| `overlay/OverlayAnimations.java` | `ui/button/OverlayAnimations.java` |
| `overlay/AimInjector.java` | `ui/aim/AimInjector.java` |
| `overlay/AimCalibrator.java` | `ui/aim/AimCalibrator.java` |
| `overlay/AimEditOverlay.java` | `ui/aim/AimEditOverlay.java` |
| `overlay/TouchWatcher.java` | `ui/aim/TouchWatcher.java` |

> **Judgement call (`OverlayAnimations`).** *Recommendation:* `ui/button/`. Its own javadoc
> says it "owns the top banner view and the rainbow/pulse/banner animators that drive the
> **ring drawables**" — the ring drawables are `AnimatedCircleDrawable`, i.e. the buttons.
> *Alternative:* `ui/overlay/`, on the grounds that it also owns a top-level banner window.
> If you take the alternative, move `AnimatedCircleDrawable` with it — they are a pair.

> **Judgement call (`AimEditOverlay`).** *Recommendation:* `ui/aim/` — it is the aim
> subsystem's editor and only makes sense next to `AimInjector`. *Alternative:*
> `ui/overlay/`, since mechanically it is two `WindowManager` handle windows.

### replay/ (2) -> `filter/replay/`

| File | Destination |
|---|---|
| `replay/PacketBuffer.java` | `filter/replay/PacketBuffer.java` (or delete — §5.1) |
| `replay/ReplayEngine.java` | `filter/replay/ReplayEngine.java` |

---

## 3. Files that should be SPLIT, not just moved

### 3.1 `esp/EspEngine.java` — 2161 lines -> 7 files

The file already marks its own seams with `// ====` banner comments. Use them.

| New file | Source lines | Responsibility |
|---|---|---|
| `esp/EspEngine.java` | facade | Fields, the `observe*` entry points, the accessor block (1900-1924, 2091-2130), `calibrationReadout()`. Delegates to the rest. Target ~500 lines. |
| `esp/Track.java` | 172-289 | The per-entity track plus its velocity/dead-reckoning constants (`TICK_MS`, `VEL_*`, `SUB_TICK_MS`). **Promoted from nested `EspEngine.Track` to top level.** Pure rename; update `overlay/EspRenderView.java:11` and the `Map<Integer, Track>` signature on `entities()`. |
| `esp/OwnStateDecoder.java` | 38-170, 667-738 | The 23-varint keepalive decode, the session mask (`maskCounts`), and the whole `// MOUNTED: THE KEEPALIVE STOPS` block including `observeSmallInbound` echo recovery. |
| `esp/ChainDecoder.java` | 739-1430 | `observeChainPacket` and everything under it: `countStarts`, `vi`, `seedVelocity`, the `MAX_ENTITY_ID` / `CHAIN_*` / `MIN_RECORD_*` constants, `ID_CEILINGS`, `Z_FLOORS`. ~690 lines — the largest single responsibility in the file. |
| `esp/LagEstimator.java` | 290-426 | The `// LIVE LAG MEASUREMENT (auto-LEAD)` block: `histMs/histX/histY`, `LAG_*` constants, `measuredLagMs()`, `lagFromEcho()`, `rttMs()`, `lagSampleCount()`, `slidePathPos()`. Self-contained instance state — the cleanest seam in the file. |
| `esp/TeamResolver.java` | 427-484, 1427-1899 | Team-byte provenance (`TEAM_SRC_*`, `ROLE_*`, `isValidTeam`), squad handling, `observeHandleEvent`, `observeDamage`, `observeBindPri`, `observeEquipment`, `observePriSync`, `teamLine()`, the roster/PRI wiring, and the head-point store (1838-1899). |
| `esp/CameraTracker.java` | 1925-2090 | The `// CAMERA-FORWARD ANGULAR EXTRAPOLATION` block: `CAM_*` constants, the direction-sample ring, `extrapolatedDir`, `dirSampleMs`, `camPitchDeg`, `camYawDeg`, `camAngSpeedDegPerSec`. Self-contained. |

Also removed from this file: `readVarint` (522), `skipVarints` (534), `varints` (551),
`zz` (599), `f32` (604), `vi` (1027) -> `util/Varints` (§4).

**Mechanics.** `ChainDecoder` and `TeamResolver` write into `EspEngine`'s `entities` map and
own-state fields. Keep them as package-private classes taking the `EspEngine` (or the
`ConcurrentHashMap<Integer, Track>`) as a constructor argument — do **not** duplicate the
state. `LagEstimator` and `CameraTracker` own their arrays outright and can be plain
instance fields of `EspEngine`.

> *Alternative if 7 files is too much churn:* do a 3-way split only —
> `EspEngine` (facade + own state), `ChainDecoder` (739-1430), `TeamResolver` (1427-1899).
> That removes ~1400 of the 2161 lines and captures most of the benefit. The
> `LagEstimator` / `CameraTracker` extractions are independent and can follow later.

### 3.2 `overlay/EspRenderView.java` — 1865 lines -> 6 files

| New file | Source lines | Responsibility |
|---|---|---|
| **`config/EspConfig.java`** | 57-660 | The ~90 `public static volatile` calibration knobs (`FOV_X_DEG`, `MIRROR_X`, `LEAD_MS`, `AIM_*`, `RADAR_*`, `VIEW_MODE`, ...) plus `pxPerDeg()`, `viewModeName()`, `UNITS_PER_METER`. **The highest-value extraction in the whole plan** — see §6. |
| `ui/render/EspPaints.java` | 643-660, 814-845 | The colour constants and the ~20 pre-allocated `Paint` objects. |
| `ui/render/Projection.java` | within 996-1320 | The world->screen maths: view-basis construction, the factored `P*V*e` evaluation, near-plane clip, `sane()`, `axisMapCode()`. The purest "maths only" unit in the UI half of the codebase. |
| `ui/render/EspRenderView.java` | 661-1320, 1319-1617 | Keeps `update(EspEngine)` (the snapshot + smoothing + extrapolation into the `enemy*` / `sm*` arrays), `refreshViewport`, and `onDraw`'s box / label / HP-bar path. Target ~600 lines. |
| `ui/render/AimTargetSelector.java` | 1618-1826 | `selectAimTarget` + `clamp255`. It reads the snapshot arrays and publishes to `esp/MarkTarget` and `ui/aim/AimInjector`; it is aim logic wearing a renderer's coat. |
| `ui/render/RadarRenderer.java` | 1827-1865 | `drawRadar`. Self-contained, reads the same snapshot arrays. |

**The `EspConfig` extraction must be mechanical.** Move the fields verbatim — same names,
same initialisers, same `volatile`, same order — and rewrite every reader. Reference counts
to update (`rg -c "EspRenderView\." --glob '*.java'`):

```
esp/EspTuning.java            124     <- becomes config/EspTuning.java writing config/EspConfig
overlay/EspTunePanel.java      57
FloatingOverlayService.java    10
overlay/AimEditOverlay.java     8
overlay/AimCalibrator.java      3
overlay/OverlayButton.java      1     (FQN: com.fakelag.cryhard8.overlay.EspRenderView.FOV_ZOOM)
filter/AimFilter.java           1     (javadoc-only import — delete it, §7 step 1)
esp/EspEngine.java              1     (javadoc-only mention, no import)
```

### 3.3 `overlay/EspTunePanel.java` — 1298 lines -> 4 files

| New file | Source lines | Responsibility |
|---|---|---|
| `ui/panel/EspTunePanel.java` | 92-272, 1229-1298 | Window lifecycle (`show` / `update` / `hide` / `isShown`), the hint ticker, `setExpanded`, `refreshAll`, the inner `DragTapListener`. Target ~300 lines. |
| `ui/panel/Knobs.java` | 65-91 | The five knob interfaces (`FloatKnob`, `BoolKnob`, `IntKnob`, `HintProvider`, `TextProvider`). Tiny, but they are the panel's public contract — `FloatingOverlayService.java:242` implements `HintProvider` by FQN. |
| `ui/panel/TuneRows.java` | 273-737, 870-913 | `buildRows()` — 445 lines, the largest single method in the repo. It is a flat catalogue of sections; split it *inside this one file* into `addEspRows()`, `addAimRows()`, `addHitRows()`, `addTeleportRows()`, matching the `section(...)` calls already present. Also takes `runSelfTest` (870), `runCalibrate` (896) and the `teleport()` / `aim()` live-filter lookups (719-737). |
| **`ui/button/PanelButtons.java`** | 738-1228 | The widget factory: `section`, `num`, `bool`, `info`, `action`, `zoomRow`, `viewModeRow`, `stepRow`, `resetRow`, `rowLayout`, `stepButton`, `tapButton`, `tapButtonWide`, `miniButton`, `card`, `dp`, `indexOf`. **This is literally the "buttons in their own folder" the user asked for.** |

### 3.4 `filter/AimFilter.java` — 1140 lines -> 5 files

| New file | Source lines | Responsibility |
|---|---|---|
| **`config/AimHitConfig.java`** | 110-166, 315-367 | `ZONE_*`, `IDX15_*`, every `cfg*` volatile, the `*_MIN` / `*_MAX` bounds, the `set*` write-through setters, `clampF`. `esp/EspTuning.java:264-275` and `:331+` write all of these; moving them out of `AimFilter` is what lets `EspTuning` stop depending on `filter` (§6). |
| `filter/AimFilterStats.java` | 236-314 | The 14 `public static final AtomicLong dbg*` counters, `dbgActive`, `idx15ModeName`, `zoneName`, `debugLine()`. Read from `overlay/EspOverlay.java:261` by FQN. |
| **`decode/body/BodyWalker.java`** | 987-1135 | `walk`, `walkInner`, `skipScalar`, `skipVarint`, `readVarintAt`, `matching`, `writeVarintPadded`. This is a **generic layout-program walker** over `PROG_106_OUT`-style strings — the same machinery `decode/body/BodyDecoderTable` describes and `BodyDecoderText` interprets. It has no business inside an aim policy. Moving it here is the one split that also removes duplication (§4). |
| `filter/aim/HitBodyRewriter.java` | 730-958 | `rebuildBody`, `writeCanonical`, `xorshift32`, `fisherYatesIdx`, the `CP_*` / `CANON_*` constants, `logRewrite`, `hex8`. The checkParams transplant machinery. |
| `filter/AimFilter.java` | 368-729, 959-986 | The `PacketFilter` itself: `onOutbound`, `onInbound`, `start` / `stop` / `shutdown` / `toggle`, the harvest store (`harvestIdx15`, `harvestCpBytes`, `clearHarvest`), the key schedule. Target ~350 lines. |

---

## 4. Duplicated logic that must collapse into `util/`

### 4.1 LEB128 varint readers — **17 implementations across 13 files**

```
$ rg -n "0x7[fF]" --glob '*.java' app/src/main/java/com/fakelag/cryhard8 | rg -v "^\s*\*"
```

| File:line | Shape |
|---|---|
| `net/WireReader.java:53` | `v \|= (long)(c & 0x7f) << shift` |
| `net/PositionSync.java:119` | same |
| `net/PriSync.java:131` | same |
| `net/SessionTimeline.java:889` | same (`readVarint`) |
| `net/VisibilityMask.java:76` | same |
| `net/AimBias.java:201` | same (`readVarints`) |
| `net/AimBiasExperiment.java:122`, `:137` | **two** copies in one file |
| `net/BodyDecoderText.java:294` | same (cursor class) |
| `esp/EspEngine.java:526`, `:561`, `:1031` | **three** copies in one file (`readVarint`, `varints`, `vi`) |
| `filter/GamePacketTaxonomy.java:722` | same |
| `filter/AimFilter.java:1075` | same (`skipVarint`, side-effects `lastVal`) |
| `filter/MarkFilter.java:326` | skip-only variant (no accumulator) |
| `dev/capture/LobbyCapture.java:673` | same |
| `dev/capture/DecodedDumper.java:208`, `:653` | **two** copies in one file |

**Target:** `util/Varints.java`

```java
public static long   read(byte[] b, int i, int end);          // -1 on truncation
public static int    skip(byte[] b, int i, int end);          // index past, or -1
public static int    skip(byte[] b, int i, int end, int n);   // n varints
public static long[] readAll(byte[] b, int off, int end);     // null on truncation
public static int    width(long u);
public static int    write(byte[] b, int p, long u);
public static void   writePadded(byte[] b, int start, int width, long u);
```

Two call sites need care because their current versions are **not** plain reads:
`filter/AimFilter.skipVarint` parks the value in the instance field `lastVal` (consumed by
`readVarintAt`), and `net/PositionSync` records per-field offsets and widths as it walks.
Give those a `long[] out` parameter or keep a thin private wrapper — do not change what the
callers observe.

### 4.2 ZigZag — 5 decodes, 3 encodes

```
$ rg -n ">>> 1\) \^ -" --glob '*.java'
esp/EspEngine.java:600          net/BodyDecoderText.java:306
net/BodyDecoderText.java:436    net/PositionSync.java:323
net/WireReader.java:65
```

Encodes: `net/PositionSync.java:319` `(v << 1) ^ (v >> 63)`, `filter/MarkFilter.java:337`,
`filter/AimFilter.java:946` (inside `writeCanonical`).

**Target:** `util/ZigZag.java` — `encode(long)` / `decode(long)`.
`net/PositionSync.zigzagEncode` / `zigzagDecode` are currently the *public* API that
`filter/AimFilter.java:517,549,565,569,1006` calls. Keep those two methods as one-line
delegates to `util/ZigZag` so `AimFilter` needs no edit in the same step.

### 4.3 Hex — 4 tables, one byte-identical validator pair

```
$ rg -n "0123456789[aA][bB]" --glob '*.java'
dev/capture/LobbyCapture.java:592   private static final char[] HEX = "0123456789ABCDEF".toCharArray();
net/BodyDecoderText.java:466        private static final char[] HEX = "0123456789ABCDEF".toCharArray();
```

plus `dev/capture/CaptureWriter.java:194` (a `byte[] HEX` for direct buffer writes),
`dev/capture/DecodedDumper.java:306 hex2 / :311 hexOf / :663 hexRange`,
`filter/AimFilter.java:747 hex8`,
`net/LobbyKeySniffer.java:134 toHex / :269 isLowerHex / :278 decodeHex / :290 hexVal`.

**Byte-identical pair, verified by diff:** `net/LobbyKeySniffer.java:269-276` and
`net/SessionTimeline.java:918-925` are the same eight lines of
`isLowerHex(byte[], int, int)`.

**Target:** `util/Hex.java` — `append(StringBuilder, byte[], int, int)`, `of(byte[])`,
`b2(int)`, `i8(int)`, `isLowerHex(byte[],int,int)`, `decode(byte[],int,int)`, `val(int)`,
plus the `byte[] TABLE` that `CaptureWriter` writes through directly.

### 4.4 clamp — 10 sites, one byte-identical pair

```
$ rg -n "static .*clamp" --glob '*.java'
core/VpnEngine.java:353          clampTeleReplayDelayMs(int)
replay/ReplayEngine.java:128     clampTeleReplayDelayMs(int)   <- byte-identical, verified
esp/EspTuning.java:727           clamp(float,float,float)
esp/EspTuning.java:732           clampI(int,int,int)
filter/AimFilter.java:363        clampF(float,float,float)
overlay/AimInjector.java:820     clampF(float,float,float)
overlay/AimEditOverlay.java:210  clampInt(int,int,int)
overlay/CrosshairView.java:125   clampCrosshairSize(int)
overlay/CrosshairView.java:131   clampCrosshairAlpha(int)
overlay/EspRenderView.java:1796  clamp255(int)
net/AimBias.java:161             clamp(double)           <- single-arg [-1,1]; do NOT merge
net/BodyDecoderText.java:265     clamp(StringBuilder)    <- unrelated: truncates a string
```

**Target:** `util/MathUtil.java` — `clamp(float,float,float)`, `clamp(int,int,int)`,
`clamp(double,double,double)`. The `CrosshairView` and `VpnEngine` / `ReplayEngine` variants
become one-line calls with their existing named bounds. **Do not** fold
`net/AimBias.clamp(double)` (a fixed `[-1,1]` unit-vector clamp) or
`net/BodyDecoderText.clamp(StringBuilder)` (a string truncator) into it — same name,
different job.

### 4.5 byte-array `ensure` / grow

```
filter/AimFilter.java:1136   ensure(byte[] buf, int n)    -> new byte[Math.max(n, 512)]
filter/MarkFilter.java:349   ensure(byte[] b, int need)   -> new byte[Math.max(need, 512)]
```

Semantically identical (one is an `if`, one a ternary). Also:
`core/TcpProxy.java:464 copyOf(byte[],int)`, `core/PacketBuilder.java:141` (inline copy),
`dev/capture/DecodedDumper.java:214` (`Arrays.copyOf(tmp, n*2)` growth),
`dev/capture/LobbyCapture.java:444` (manual grow-and-`arraycopy`).

**Target:** `util/Bytes.java` — `ensure(byte[], int)` (scratch reuse, min 512),
`grow(byte[], int)` (copy-preserving), `copyOf(byte[], int)`.

---

## 5. Dead code

Method: `rg -lw "<identifier>" --glob '*.java'` excluding the declaring file, then `rg -cw`
within the declaring file to distinguish "used privately but over-exposed" from "never
referenced at all". Reported below only where the total repo-wide occurrence count is
**1** — the declaration itself.

### 5.1 Genuinely dead — safe to delete

**`filter/JitterFilter.java` (149 lines) — the only fully dead class in the repo.**

```
$ rg -lw "JitterFilter" --glob '*.java'
app/src/main/java/com/fakelag/cryhard8/filter/JitterFilter.java      <- only itself
```

It is not wired up. `FilterKind.JITTER` exists and is live, but
`filter/DefaultFilterEngine.java:128` routes it to `TeleportFilter.press()` and `:151`
reports `teleport.isActive()`. `JitterFilter` is never constructed.

**Transitively dead with it:**

| Symbol | Evidence |
|---|---|
| `replay/PacketBuffer.java` (102 lines) | `rg -n "PacketBuffer" --glob '*.java'` -> `JitterFilter.java:4,34,35` and `ReplayEngine.java:93,99,102`. Both reachable only from `JitterFilter`. |
| `ReplayEngine.teleReplayTask` + inner `TeleReplayRunnable` (92-127) | sole caller is `JitterFilter.java:109`. |
| `ReplayEngine.replayPacketList` (54), `replayTelePackets` (50), `shouldAbort` (40) | zero references repo-wide. |

After removing `JitterFilter`, `ReplayEngine` retains only `TELE_REPLAY_DELAY_*` and
`setTeleReplayDelayMs`, both used by `DefaultFilterEngine.java:42-43`.
**Recommendation:** delete `JitterFilter` and `PacketBuffer`, strip the four dead
`ReplayEngine` methods, and fold what remains of `ReplayEngine` into `DefaultFilterEngine`
as a plain int field — which removes the `filter <-> replay` cycle entirely and deletes the
`filter/replay/` package before it is created.
*Alternative:* keep the package and delete only `JitterFilter` + `PacketBuffer`.
Either way, **do this as its own commit, after the moves**, so a behavioural regression can
be bisected to it.

**Other zero-reference public methods.** 53 in total; those with no javadoc claiming a
purpose are the real candidates:

```
net/Tea.java:                 decryptBlock, encryptBlock   (every caller uses qqTeaDecrypt/qqTeaEncrypt)
net/Cmd.java:                 carriesHitZone, hasWireLayout, isCsShop, isVisibilityMask
net/CmdCatalogue.java:        allIds, isReceivable, isReliableChannel, isUnreliableChannel
net/Direction.java:           isInbound, isOutbound
net/HeaderField.java:         isReliableOnly
net/HeaderLayout.java:        headSecret
net/PacketFlags.java:         isSetIn
net/UdpPacket.java:           sendOptionValue
net/PositionSync.java:        isDirty
net/SessionTimeline.java:     isReconnection
net/LobbyKeySniffer.java:     keyEventCount, keyRotationCount
net/AimBias.java:             appliedCount, lockedIndex, skippedCount
net/PacketPipeline.java:      crcFailureCount, forcedResolveCount, hasSessionKey,
                              parsedCount, resolveSession, undecodableCount
filter/PacketIntegrity.java:  repairedCount, sealedCount
filter/PacketClassifier.java: isBroadFirePayload
filter/PacketContext.java:    withTeleType
filter/TeleportFilter.java:   isDesynced
esp/EspEngine.java:           camAngSpeedDegPerSec, camYawDeg, lagSampleCount
esp/PriTracker.java:          squadCount
app/GameTargets.java:         addTarget
core/VpnEngine.java:          isCaptureRunning
dev/capture/CaptureWriter.java:  queueDepth
dev/capture/LobbyCapture.java:   currentFile
overlay/TouchWatcher.java:    isSupported, sinceLastTouchMs
```

**Do not delete these as part of this refactor.** Almost all are one-line accessors over
state that is already computed; deleting them saves nothing and risks removing the exact
readout the next debugging session needs. If you want one concrete deletion, take
`net/Tea.decryptBlock` / `encryptBlock` — genuine dead primitives, every caller goes
through the `qqTea*` wrappers.

### 5.2 Intentionally unused — documented no-ops, DO NOT DELETE

| Symbol | Evidence |
|---|---|
| `core/VpnEngine.scheduleLobbyRouteFallbackIfNoUdp(String)` (line 667) | Body is `// Deliberately does nothing. See the javadoc above.` The 40-line javadoc explains it was kicking players out of live matches and says *"Kept as a no-op so the call sites stay honest about what used to happen here. Do not reinstate without a capture showing game traffic outside those blocks."* |
| `core/VpnEngine.setLobbyRouteFallbackFull(boolean)` (line 349) | The only writer of the `lobbyRouteFallbackFull` latch the disabled fallback used. Zero callers **by design**, same documented decision. |
| `filter/TeleportFilter` empty body at line 764 | `// Intentionally empty: nothing stale is held.` |
| `dev/capture/PacketCapture` mirror (`setMirrorEnabled`, `snapshot`) | Javadoc line 47: *"That mirror is retained but is..."* — a deliberate diagnostic path. |
| `dev/capture/CaptureAnnotator.cmdName` / `decodeBody` / `expectedCrc` / `flagLetters` | Under the banner `// Small helpers the writer and the dev panel can use`. Deliberate offline-analysis surface. |
| `dev/capture/PacketCapture.recordTcp` | *"D1's capture half — the transport that was never captured at all."* |
| `PacketVpnService.vpnEngine()` | *"The live engine, for the dev panel."* |
| Six `@Deprecated` methods in `filter/GamePacketTaxonomy` (685, 759, 803, 818, 833, 862) | Each carries a javadoc saying exactly why it is wrong (*"There is no hit zone in this packet"*, *"Reads the wrong number"*, *"PRE-SOLVER FALLBACK ONLY"*). They are still reachable and still used as fallbacks before the solver converges. |

---

## 6. Circular and upward dependencies

Measured by extracting, per file, its `import com.fakelag.cryhard8.*` lines **and** every
inline `com.fakelag.cryhard8.<pkg>.` occurrence.

### 6.1 `esp <-> overlay` — real; the one the brief flagged

* `esp/EspTuning.java` -> **124** references to `overlay.EspRenderView` statics
  (`EspRenderView.FOV_X_DEG = ...`, lines 207-260 and the `set*` block).
* `overlay/EspRenderView.java` -> `esp.EspEngine`, `esp.EspEngine.Track`,
  `esp.OrientationProvider` (imports, lines 10-12) and writes `esp.MarkTarget`
  (lines 1586, 1590).
* `overlay/EspTunePanel.java`, `overlay/AimCalibrator.java`, `overlay/AimEditOverlay.java`
  -> `esp.EspTuning`.

**Should it be inverted? Yes — but the inversion is "move the config out of both", not
"make the renderer own it".** The renderer reading the engine (`overlay -> esp`) is the
correct direction and stays. The wrong edge is `esp -> overlay`, and it exists only because
~90 tuning knobs happen to be declared as statics **inside a `View` subclass**.

**Fix, in two mechanical moves:**

1. `esp/EspTuning.java` -> `config/EspTuning.java`. `EspTuning` is not ESP domain logic; it
   is a `SharedPreferences` write-through adapter. Once it is in `config/`, `esp` no longer
   references `overlay` **at all** (`rg -n "overlay" esp/` -> a single javadoc mention in
   `EspEngine.java:1855`).
2. `EspRenderView`'s config block (lines 57-660) -> `config/EspConfig.java` (§3.2).
   Then `config -> { ui/render, filter, esp }` and `ui/render -> { esp, config }` — acyclic.

Step 1 alone breaks the cycle and is a single `git mv` plus a package line. Step 2 is the
quality win (the renderer stops being a global settings object) but touches ~205 reference
sites. **Recommendation: do step 1 in the move phase and step 2 in the split phase.**

### 6.2 `esp <-> filter` — real

* `esp/EspTuning.java:7` imports `filter.AimFilter`; `:242` writes `filter.MarkFilter.ENABLED`;
  `:264-275` writes eleven `AimFilter.cfg*` statics; `:316-321` reaches
  `PacketVpnService.filterEngineOrNull()` and downcasts to `filter.DefaultFilterEngine`.
* `filter/TeleportFilter.java:4` imports `esp.EspEngine`;
  `filter/MarkFilter.java:4` imports `esp.MarkTarget`.

**Fix:** the same move — `EspTuning` -> `config/`. After that, `esp -> filter` is
javadoc-only (`esp/MarkTarget.java:5,24` and `esp/EspEngine.java:1843` `{@link}` tags), and
`filter -> esp` remains as the single correct direction. Extracting
`config/AimHitConfig.java` (§3.4) additionally means `config` needs `filter.AimFilter` only
for the live-instance setters, not for the static knobs.

### 6.3 `filter <-> overlay` — **not real; it is a javadoc-only import**

```
$ rg -n "EspRenderView" filter/AimFilter.java
15:import com.fakelag.cryhard8.overlay.EspRenderView;
67: *   ESP's own head-height offset ({@code EspRenderView.AIM_HEIGHT_M}) on the up
131: *   the idx9 hit point. Replaces the hardcoded {@link EspRenderView#AIM_HEIGHT_M}
```

No code use. Deleting line 15 and turning `{@link EspRenderView#AIM_HEIGHT_M}` into
`{@code EspRenderView.AIM_HEIGHT_M}` removes the whole edge in one line. That is why it is
step 1 of the migration.

`overlay -> filter` (from `EspTunePanel` and `EspOverlay`) is real and correct: the UI reads
policy state. It stays.

### 6.4 `filter <-> replay` — real, dissolved by the dead-code removal

`filter/DefaultFilterEngine.java:8` and `filter/JitterFilter.java:4-5` -> `replay`;
`replay/ReplayEngine.java` and `replay/PacketBuffer.java` -> `filter.TelePacket`,
`filter.PacketSender`. Nesting `replay` under `filter/` makes it a sub-package rather than a
peer, which removes the *inter-package* cycle. Deleting the dead half (§5.1) removes it
outright.

### 6.5 `filter -> dev.capture` and `net -> filter` — **both javadoc-only**

```
filter/GamePacketTaxonomy.java:129   @see com.fakelag.cryhard8.dev.capture.CaptureAnnotator
net/SessionTimeline.java:105,264     prose mentions of GamePacketTaxonomy, no import
```

`net/` is a clean bottom layer today. Keep it that way: after the split, **nothing in
`decode/` or `protocol/` may import `filter`, `esp`, `ui` or `tunnel`.** Moving
`GamePacketTaxonomy` and `PacketIntegrity` into `protocol/` is consistent with that — both
already import only from `net/`.

### 6.6 `dev <-> dev.capture <-> filter` — cycle at package granularity only

`filter/*` imports `dev.DevLogger` (an interface that imports nothing);
`dev/DevLoggerImpl.java` imports `dev.capture.*`; `dev/capture/*` imports `filter.*`.
Acyclic at class granularity. **Leave it.** If you want it formally clean, move
`DevLoggerImpl` to `dev/log/` so `dev/` holds only the interface. Low priority.

---

## 7. Migration order

Each step must end with a green `./gradlew assembleDebug` and a clean stale-reference grep.
**Do not batch steps.**

After *every* step, run both checks:

```bash
# 1. No stale package references anywhere, including inline FQNs and javadoc @link.
rg -n "com\.fakelag\.cryhard8\.(app|core|net|overlay|replay)\." --glob '*.java'

# 2. Manifest and resources still resolve.
rg -n "com\.fakelag" app/src/main/AndroidManifest.xml app/src/main/res/
```

The 277 inline FQNs are the trap. A `sed` that rewrites only `^import ` lines compiles fine
for the files that used imports and **silently fails to move** the 277 that did not — then
fails to compile in a way that looks unrelated. Prefer Android Studio's *Refactor -> Move*
(which rewrites FQNs), or `sed` on the **FQN prefix**
(`s/com\.fakelag\.cryhard8\.core\./com.fakelag.cryhard8.tunnel./g`) applied to the whole
file, which handles imports and inline uses in a single pass.

| # | Step | Risk | Why here |
|---|---|---|---|
| **0** | Record the baseline: `git rev-parse HEAD`, build, note APK timestamp/size. Commit or stash the currently-dirty `esp/EspEngine.java`. | — | Bisection anchor. `git status` shows `EspEngine.java` modified and `docs/CS_MODE_ESP_FAILURE.md` untracked — resolve both before starting. |
| **1** | Delete `filter/AimFilter.java:15` (javadoc-only `EspRenderView` import); change `{@link EspRenderView#AIM_HEIGHT_M}` -> `{@code ...}` at line 131. | none | One line. Removes `filter -> overlay`. Free. |
| **2** | Create `util/` with `Varints`, `ZigZag`, `Hex`, `MathUtil`, `Bytes`. **Add the files; rewire nothing yet.** | none | New files only; cannot break a build. |
| **3** | `git mv core/ -> tunnel/`, `replay/ -> filter/replay/`, `app/{AppPicker,AppearanceBroadcaster,PermissionController,UiBindings} -> ui/settings/`. | low | Pure package renames, no splits. Exercises the FQN-rewrite procedure on 14 files before betting the `net/` split on it. |
| **4** | Create `config/`; move `Prefs`, `VpnActions`, `GameTargets`, **`EspTuning`**. | low | `EspTuning` is the cycle-breaker (§6.1, §6.2). **Verify `Prefs` key strings are byte-identical** — `git diff Prefs.java` must show only the `package` line. |
| **5** | Split `net/` -> `decode/frame`, `decode/crypt`, `decode/body`, `protocol/`; move `GamePacketTaxonomy` and `PacketIntegrity` from `filter/` -> `protocol/`. | medium | 29 files, ~120 inline FQNs. One commit; `net/` must not exist afterwards. |
| **6** | Split `overlay/` -> `ui/overlay`, `ui/render`, `ui/panel`, `ui/button`, `ui/aim`. | medium | Touches `FloatingOverlayService` (10 FQNs) and `MainActivity`. |
| **7** | Extract `config/EspConfig.java` from `EspRenderView` (§3.2). | **high** | ~205 reference sites. Move fields **verbatim** — same names, initialisers, `volatile`, order. A typo here is a silently wrong calibration constant, which presents as "the ESP is slightly off", not a crash. Diff the extracted block against the original: `git show HEAD:...EspRenderView.java \| sed -n '57,660p'`. |
| **8** | Extract `config/AimHitConfig.java` from `AimFilter` (§3.4). | medium | Same discipline, ~30 reference sites. |
| **9** | Remaining `EspRenderView` splits: `EspPaints`, `Projection`, `AimTargetSelector`, `RadarRenderer`. | medium | Method moves rather than field moves — much safer than step 7. |
| **10** | `EspTunePanel` split -> `Knobs`, `TuneRows`, `ui/button/PanelButtons`. | low | Almost entirely private methods; the only external contract is `HintProvider`, FQN-referenced from `FloatingOverlayService.java:242`. |
| **11** | `AimFilter` split -> `AimFilterStats`, `decode/body/BodyWalker`, `filter/aim/HitBodyRewriter`. | medium | `AimFilterStats.debugLine()` is FQN-referenced from `EspOverlay.java:261`. |
| **12** | `EspEngine` split -> `Track`, `OwnStateDecoder`, `ChainDecoder`, `LagEstimator`, `TeamResolver`, `CameraTracker`. | **high** | Biggest file, most cross-references, on the hot path. Do the coarse 3-way split first (§3.1 alternative) and build; then the fine split. `Track` promotion changes a type name used in `EspRenderView`'s imports. |
| **13** | Rewire duplicate helpers onto `util/` (§4), one family per commit: Varints -> ZigZag -> Hex -> clamp -> Bytes. | medium | Deliberately last: this is the only phase that edits *logic*, so doing it after the moves means a regression bisects to a small single-purpose commit. |
| **14** | Dead-code removal: `JitterFilter`, `PacketBuffer`, the four dead `ReplayEngine` methods (§5.1). | low | Separate commit, last. Leaves §5.2 untouched. |

### Verification beyond "it compiles"

A package move cannot change behaviour, but a botched field extraction can. After step 7
and again after step 12, do a **runtime** check, not just a build:

1. Install, start the tunnel, join a match.
2. Confirm the ESP boxes land on enemies at the same offsets as before — a step-7
   regression shows as a constant or angle-dependent offset.
3. Open the tune panel; confirm every slider reads back its persisted value — a `Prefs`
   key typo shows as a knob resetting to default.
4. Confirm freeze / ghost / tele / aim all still toggle.

---

## 8. Net effect

| | Before | After |
|---|---|---|
| Packages | 10 | 19 |
| Files | 97 | ~115 after splits, ~112 after dead-code removal |
| Files > 1000 lines | 6 (`EspEngine` 2161, `EspRenderView` 1865, `EspTunePanel` 1298, `AimFilter` 1140, `DecodedDumper` 1118, `SessionTimeline` 1089) | 2 (`DecodedDumper`, `SessionTimeline` — both dev-only, both deliberately left alone) |
| Inter-package cycles | 5 (`esp<->overlay`, `esp<->filter`, `filter<->overlay`, `filter<->replay`, `dev<->dev.capture<->filter`) | 1 (`dev<->dev.capture<->filter`, class-level acyclic, documented) |
| Varint implementations | 17 across 13 files | 1 (`util/Varints`) |
| ZigZag implementations | 8 across 5 files | 1 (`util/ZigZag`) |
| `clamp` implementations | 10 | 1, plus 2 deliberately distinct (`AimBias`, `BodyDecoderText`) |
| Dead classes | 2 (`JitterFilter`, `PacketBuffer`) | 0 |
