# Client-authoritative send surface — outbound manipulation candidates (in-match)

**Question answered:** of everything the client SENDS to the match server during a
live Battle Royale/survival or Clash Squad match, which fields could we rewrite to
our advantage, and for each — is it self- or other-affecting, and does the server
appear to trust or correct it?

**Scope:** in-match RUDP/UDP only. Every lobby / matchmaking / `proto.*` message is
excluded. "CS" here means **Clash Squad** (the RUDP mode), never the lobby `proto.*`
`CS`=Client→Server prefix (IL2CPP_FINDINGS §7.1).

**This is the SEND half.** A sibling agent is determining what the server validates;
each candidate below is written so a validation verdict can be attached to its row.

**Method:** msgids and field layouts from `tools/il2cpp/ff_outbound_registry.txt`,
`ff_outbound_classes.json`, `ff_inbound_registry.tsv`, cross-named through
`CmdCatalogue.java` and the shipped de-obfuscation map. **On-wire presence and rates
re-derived first-hand** from four full-payload captures with `tools/ffdecode.py`
(framing per `ff-udp-framing-solved`): the header — including **Cmd** — is recoverable
from a capture with **no body key**, so every outbound message can be counted by real
command id. All four solved at **DATALEN fit 6000/6000 and CRC7 100%** (see appendix),
so the census is trustworthy, not inferred from packet shape.

Last updated 2026-09-12. Read-only survey; nothing in the code tree was touched.

---

## 0. TL;DR — the top 5 to try first, and why

Everything actionable rides **one message**: Cmd 2001 `UDP_PLAYER_STATE_SYNC`, the
position keepalive. It is the *only* outbound in-match message with a **plaintext
body** (§1), so it is the only one the project's proven-safe **rewrite-in-place**
mechanism can touch without the TEA key. All five leads are its sub-fields or its
mounted twins.

| # | candidate | why first |
|---|---|---|
| 1 | **2001 v0–v2 position (X,UP,Z, mm)** | Already **proven**: teleport rewrites it across **50,543 packets, 0 withheld, 0 corrections below the 2.77 m/tick gate** (`TELEPORT.md §6b`). Self-affecting, trusted within a distance budget. This is the reference candidate, not a hypothesis. |
| 2 | **2001 v8–v10 velocity (cm/s)** | The coherence lever. Position rewrites are only accepted while `velocity ≈ next-tick displacement` (ratio p50 **1.010**, n=11,949). It doubles as the probe for whether the server runs a *separate* velocity/displacement check (IL2CPP §5.1 lead). Self-affecting. |
| 3 | **2001 v12 EPHYSXPOSE (crouch/prone/dash) + v11 EPHYSXSTATE** | Cheapest untested self-state. Raw bytes riding the already-trusted keepalive. Tests whether *any* 2001 sub-field beyond position is validated. Low intrinsic payoff (posture height is applied client-side, §4.5), high information value. |
| 4 | **2001 v18 ping (ms)** | Self-reported RTT on a trusted message. If the server feeds it into lag-compensation, rewriting it is a pure-self peeker's-advantage lever — no geometry, no other player asserted. Untested; cheap; potentially high value. |
| 5 | **2002/2006/2031 vehicle-position twins** | Bring the proven position lever to the mounted case, where ghost/teleport currently go blind (IL2CPP §5.1 bug 2). Layout known (§5); **not observed on-wire in my four on-foot matches** — needs a vehicle capture to confirm shape and plaintext status. |

**The single most valuable *negative* result:** the client-authoritative hit claim
**Cmd 106 `RUDP_TAKE_DAMAGE` is never sent outbound** in any of four cleanly-decoded
matches (2 Clash Squad + 2 survival) despite heavy firing, and where the code *does*
build it, it is TEA-encrypted and carries two anti-cheat signatures over the damage
value. It is OTHER-affecting and gated; per project policy no forgery recipe is given
(§4).

---

## 1. THE MASTER GATE: only Cmd 2001 has a plaintext body

This decides the whole ranking. The manipulable surface is not "which fields does the
server trust" — it is first "which messages can we even edit." The proven, kick-free
mechanism is **rewrite-in-place of a plaintext body** (fix CRC7, keep length):
`TELEPORT.md`, `ff-teleport-rewrite`. TEA-encrypted bodies would additionally need the
16-byte `SECRET_KEY` (obtainable off lobby TCP per `ff-key-is-on-the-wire`, but a much
larger lift) **and**, being reliable, are bound by the reliability `OrderID` window —
you may rewrite in place but never inject or withhold (the documented desync-kick,
IL2CPP §7.4, `ff-route-fallback-kick`).

Encryption status per outbound Cmd, measured on capture `20260910_161940`
(Clash Squad, 18,013 OUT packets), `Flags&1` = TEA-encrypted body:

| Cmd | name | body | rewritable in place? |
|---|---|---|---|
| **2001** | `UDP_PLAYER_STATE_SYNC` | **plaintext** (5591/5591) | **YES — today, key-free** |
| 2000 | `UDP_SYNC_SERVER_TIME` | plaintext (287/287) | yes, but carries no exploitable game state |
| 3 | `UDP_PING` | plaintext (560/560) | yes; liveness only |
| 2 | (encrypted input stream) | **TEA** (11055/11055) | no (needs key) |
| 104 | `RUDP_START_FIRE` | **TEA** (88/88) | no (needs key) |
| 105 | `RUDP_STOP_FIRE` | **TEA** (135/135) | no |
| 108 | `RUDP_CHANGE_INVENTORY_ON_HAND` | **TEA** (51/51) | no |
| 113 | `RUDP_USE_INVENTORY` | **TEA** (36/36) | no |
| 131 | `RUDP_TRYUSE_INVENTORY` | **TEA** (9/9) | no |
| 111 | `RUDP_PICKUP_INVENTORY` | **TEA** (12/12) | no |
| 133/134 | `RUDP_START/STOP_RELOAD` | **TEA** (29/30) | no |
| 137/138 | `RUDP_START/STOP_SNIPER` | **TEA** (8/8) | no |
| 413 | `RUDP_PURCHASE_CSITEMS` | **TEA** (34/34) | no |
| 1492 | `RUDP_C2S_SYNC_USE_CSSHOP` | **TEA** (10/10) | no |
| 148/142/143 | mapmark / rescue | **TEA** | no |

**Every reliable gameplay message is encrypted; only the unreliable state/time/ping
plaintext trio is not.** So the actionable candidate list = the field family of
Cmd 2001 (Tier A), plus its vehicle twins. Everything else is Tier B: enumerated for
the validation sibling, but blocked behind the transport before trust even matters.

---

## 2. TIER A — Cmd 2001 `UDP_PLAYER_STATE_SYNC`: the manipulable surface

- **outbound class:** `message.DAIDIMLOEPL` wrapping `message.ACDHGKMPIDJ`
- **sole sender:** `COW.GamePlay.PNCPKGJGBPP::EAIKJCCNGMJ+0x145c` @ **0x078CF1D4**
  (of 461 `GameFacade::Send` sites, exactly one passes 2001 — IL2CPP §5.1)
- **serialize:** `0x047cb4c4` / `0x049d4900`
- **rate:** plaintext, unreliable (`sendOption=0`), **~10 Hz** (measured 9.81 / 10.09 /
  7.83 / 9.93 Hz across four matches; throttled `(counter%3)==0` off a ~30 Hz driver)
- **inbound echo (feedback, not correction):** Cmd 2001 handler
  `KGHDCJFHGNP` → `FFMOIGKIEPE.DCFLPNAOHFH` — the self-echo teleport uses as ground truth
- **field order re-derived from our own image** (IL2CPP §5.1); do **not** substitute
  `dump.cs` ordering (Trap 2)

Fields ranked by exploitability. All are SELF-AFFECTING — 2001 asserts only our own
reported client state; it contains no field about another player, and its aim vectors
are consumed for *rendering our avatar on other clients*, never for hit resolution
(§4, IL2CPP §1).

| field | meaning | enc | self/other | server corrects? | manip idea | exploit | conf | evidence |
|---|---|---|---|---|---|---|---|---|
| **v0–v2** | position X, UP, Z — mm (zigzag int, /1000) | plain | self | **yes, beyond gate** → inbound **Cmd 144** force-sync (§3) | teleport / ghost / anchor | **HIGH** | **HIGH** | 50,543 rewrites 0 withheld; accepted ≤2.77 m/tick, rejected ≥5.31 m/tick; snap-back 399–402 ms (`TELEPORT.md §1,§6b`) |
| **v8–v10** | velocity cm/s (zigzag short) | plain | self | coupled to v0–v2; likely coherence-checked | must equal next-tick Δpos; rewrite with position | **HIGH** | **HIGH** | ratio p50 1.010 n=11,949; band ≥5 m collapses to 0.054 in naïve rewrites (`TELEPORT.md §2`) |
| v11 | EPHYSXSTATE (WALKING 0 … PASSIVEMOVING 21), airborne | RAW byte | self | unknown | fake airborne/ground | MED | MED | IL2CPP §5.1; own-keepalive v11 (PROTOCOL_MASTER §3) |
| v12 | EPHYSXPOSE (STANDING 0, CROUCHING 1, DASHING 2, CREEPING 3) | RAW byte | self | unknown | spoof posture | LOW–MED | MED | IL2CPP §5.1; **posture height is client-side, not on the wire** (PROTOCOL_MASTER §4.5) |
| v3–v5 | aim dir #1 = `GetAimRotation()*forward` ×100 (body facing) | plain | self | no (render only) | — (proven inert) | **LOW** | HIGH | tracks velocity heading to 0.8° (PROTOCOL_MASTER §3) |
| v13–v15 | aim dir #2 = `GetAuxAimRotation()*forward` — 3 raw float32 | plain | self | no (render only) | — (proven inert) | **LOW** | HIGH | **the aim-bias null was on THIS field**: rewriting it changed nothing; hits are client-resolved (IL2CPP §1, §5.1; `ff-aim-bias-disproven`) |
| v6–v7 | ground move dir X,Z ×100 (zigzag short) | plain | self | no | animation only | LOW | MED | IL2CPP §5.1 |
| v18 | ping ms (LEB128 ushort) | plain | self | unknown | spoof RTT → bias lag-comp | **MED** | LOW | `Random.Range(0,100)` before `m_StartShowTime` (IL2CPP §5.1) — server tolerates garbage here early, a hint it is not tightly checked |
| v16 | moving-platform id (LEB128 ushort) | plain | self | n/a | leave alone | LOW | MED | when `!=0`, **v0–v2 become platform-relative** (IL2CPP §5.1 bug 3) — a rewrite trap, not a lever |
| v17 | low-gravity-area flag | RAW byte | self | unknown | — | LOW | LOW | IL2CPP §5.1 |
| v19 | UGC-only flag | RAW byte | self | — | — | LOW | LOW | IL2CPP §5.1 |
| v20 | bezier-slide path pos \| slideId<<24 | LEB128 uint | self | unknown | — | LOW | LOW | IL2CPP §5.1 |
| v21 | snowslide side / lobby voice | RAW byte | self | — | — | LOW | LOW | **can exceed 127; a varint decoder desyncs** (IL2CPP §5.1) |
| v22 | client ms clock (+99/pkt) | LEB128 uint | self | no | leave monotonic | LOW | HIGH | 0/27,143 non-positive steps; no tick-dedup observed (`TELEPORT.md §3`) |
| h | PlayerID (LEB128, leading handle) | plain | self | identity — do not touch | — | — | HIGH | first varint = object handle (PROTOCOL_MASTER §1.3) |

**2001 carries no anti-cheat blob — nothing in it is signed** (IL2CPP §5.1). That is
exactly why position rewriting works and why 2001 is the whole vein.

### 2.1 Vehicle-position twins — same semantics, different shape, currently blind

Dispatched from the *same* method that sends 2001. `EAIKJCCNGMJ` branches on
`IsInVehicle()` **before** the on-foot path, so while mounted 2001 is never sent and
ghost/teleport go dark (IL2CPP §5.1 bug 2):

| Cmd | name | class | position carrier | send site |
|---|---|---|---|---|
| 2002 | `UDP_VEHICLE_STATE_SYNC` (driver) | outbound class msgid-unresolved in registry | — | `EAIKJCCNGMJ` |
| 2006 | `UDP_PASSENGER_STATE_SYNC` | `JGGMLMNCMAA` | 2× `BDOPLCJODBN` (3 shorts /100) | `EAIKJCCNGMJ+0xb50` @ 0x078CE8C8 |
| 2031 | `UDP_SYNC_CANNON` | msgid-unresolved | — | `EAIKJCCNGMJ` |

Note 2006 uses the **compact `BDOPLCJODBN` (short/100)** vector, not 2001's
`int/1000` — a different wire shape, which is why the 2001 shape-test misses them.
Self-affecting position, same trust class as 2001 in principle. **Not seen on the wire
in my four (on-foot) matches** — presence, plaintext status and rewritability are
unverified. Also a real position lever hiding in plain sight: **Cmd 126
`RUDP_GETOFF_VEHICLE` (`HGELOADAPFF`) carries the dismount position as a
`PMFGOGFPDHM` int3** — client says where it steps off (but the body is TEA, §Tier B).

---

## 3. The correction fingerprint: inbound Cmd 144

A validated field's tell is a correction message; a trusted field's tell is silence.
For 2001 position we can name the correction:

- **inbound Cmd 144 `RUDP_FORCE_SYNC_PLAYER_STATE`** — handler `PGABPEBFLOK` →
  `FFMOIGKIEPE.BMJPKGGDEIB`. The server forces the client back to a server-authoritative
  position: this is the snap-back.
- the client **acks with outbound Cmd 146 `RUDP_CONFIRM_SERVERFORCE_SYNC_PLAYER_STATE`**,
  and **146 is observed on the wire in all four matches** (counts 6 / 8 / 3 / 2) — so
  the server force-syncs the client a handful of times *even in normal play*.
- the client can also *request* one: outbound 144 from
  `PlayerNetwork::RequestFoceSyncPosition+0x1a0`.

This **refines** (does not contradict) `TELEPORT.md §2`, which found "no server
correction packet" in plaintext capture scans and placed the correction "in the
encrypted 10+8k channel." Cmd 144 is a **reliable (TEA) message**, so it would not
appear in a plaintext scan — consistent with both observations. **Confidence: MEDIUM**
(the 144 handler and the observed 146 acks are code+wire facts; that 144 is *the*
carrier of the specific ≥5.31 m snap-back is inference, settle by decoding an inbound
144 body around a rejection with the session key).

---

## 4. TIER B — encrypted-body messages (need the key; some gated; some inert)

These carry manipulable-looking state but sit behind the TEA gate (§1). Listed for the
validation sibling with the trust hypothesis and the mechanism that would gate each.
None is rewritable today without `SECRET_KEY`; none rides a plaintext body.

### 4.1 The hit / damage-claim path — OTHER-AFFECTING, GATED, and not even on the wire

Documenting the boundary is the result here; **no forgery recipe** (project standing
line, IL2CPP §5.5 caveat).

- **Cmd 106 `RUDP_TAKE_DAMAGE`**, class `message.MMJPICCOJOM` (22 fields). Built inside
  `PlayerNetwork::TakeDamage+0x904` @ 0x0736F9E8 and `NetworkAIPawn::TakeDamage+0x99c`
  @ 0x07C06A6C. The client resolves the victim, body part and damage *locally* and
  hands over the finished claim (client-authoritative, IL2CPP §1).
- **It is gated four ways:** (a) TEA-encrypted body; (b) two anti-cheat signatures over
  the damage — `CFIKODJDKDN` (ulong @0x58) and `FHBHMKMHCHJ` (`List<byte>` @0x68, the
  `GCommon.Checker.GFHPFJMGEKF(0xA,7,damage)` blob); (c) the **hit zone is sent twice**
  for a server cross-check — `EHNFCMJMPMJ` byte @0x2C **and** packed into
  `GMNGCBJMDLB` high byte (`orr …,lsl #24`), IL2CPP §4.1; (d) collider-name anti-cheat
  (`Cheating_HipsBoneNotRight=-154`, `_HackerIceWallName=-155`, `_SniperColliderName=-156`).
- **Critically, it is NOT observed outbound in any of four cleanly-decoded matches**
  (2 Clash + 2 survival), despite 104 `START_FIRE` firing in every one (21–88 events
  each). So in normal PvP the client is **not** emitting 106 at all — the hit path
  likely rides the encrypted Cmd 2 input stream and/or is server-simulated. This is
  **new wire evidence** bearing on IL2CPP §5.5 / PROTOCOL_MASTER §8.2.
- Reused for non-player victims (same class, all OTHER/world-affecting, all gated):
  **127** `VEHICLE_TAKE_DAMAGE`, **166** `UAV_TAKE_DAMAGE`, **222** `ICEWALL_TAKE_DAMAGE`,
  **240** `LANDMINE_TAKE_DAMAGE`, **394** `LEVELOBJECT_TAKE_DAMAGE`, **865**
  `SANTINODUMMY_TAKE_DAMAGE` — none observed on-wire either.
- **Cmd 3532 `RUDP_C2S_ShopTokenGun_Hit`**, class `OINOHHNMFKJ` = 4 uints
  {shooter, victim, int, tick}, sent from the hit path `FDAEPHMIEPC::KOODEKEKFEK+0x1fe0`
  @ 0x074E14DC, gated on `IsLocalPlayer`. IL2CPP §5.5 flagged it as the cheapest way to
  detect the client-hit path in a capture; **it is absent from all four matches** — same
  verdict as 106.

### 4.2 Self-affecting weapon/action state (encrypted; sibling should check for trust)

Each declares our own client state; the *effect* is largely server-owned. Rewriting
would need the key; these are the interesting "does the server trust self-state"
questions:

| Cmd | name | outbound class | fields of interest | note |
|---|---|---|---|---|
| 104 | `RUDP_START_FIRE` | `PHLCCJAAHIH` | `IDOLFKFPGLI` fire-state enum (`NMCBIHOOFFF`), float, `List<byte>` | no geometry (IL2CPP §6); the bullet is client-side |
| 3039 | `RUDP_SYNC_WHOLE_BODY_FIRE` | `FPIHHNBBFDG` | fire-state enum + 2 bytes + `List<byte>` | akido/whole-body fire variant |
| 133/134 | `RUDP_START/STOP_RELOAD` | — | reload state | self timer/state |
| 137/138 | `RUDP_START/STOP_SNIPER` | `IBNFEDBKMIO` (138) | ADS/scope state | self |
| 108 | `RUDP_CHANGE_INVENTORY_ON_HAND` | `JDIHDLDIMCK` | 2 uints (player, item) | weapon switch |
| 643 | `RUDP_SWITCH_WEAPON` / 173 `SWITCH_ATTACH` (`JCHOEGCLELP`) | — | 3–4 uints | self loadout |
| 248/249 | `RUDP_USE/STOP_ACTIVE_SKILL` | — | ability id | cooldown/charge server-owned (hypothesis) |
| 951/952 | `RUDP_START/STOP_EXECUTE` | — | finisher | self |
| 204/193/198/199 | `PLAYER_DO_ACTION` / `START_CLIMB` / `GETON/GETOFF_STROP` | — | action enums | self animation/traversal |
| 221 | `RUDP_ADD_ICEWALL` | — | gadget deploy | creates a world object; self-initiated |
| 160/162/3030 | `PROJECTILE_THROW` / `START_GRENADE` / `TRIGGER_GRENADE` | `DJIJDPIJDOB` (160) | **`MOEFFAIDCBP` pos (int3) + `AIGPMFLKHLC` euler + float force** | throw geometry is client-authored; detonation damage goes via the gated 106 path; **not observed on-wire in the four matches** |

### 4.3 Consumables and shop — client names an id, server owns the value (buys/heals nothing)

The shop finding generalizes to consumables: the client sends only an **item id**; the
price, balance and inventory never leave the server, so a hand-built message cannot
grant anything (IL2CPP §7.3).

| Cmd | name | class | body | verdict |
|---|---|---|---|---|
| 413 | `RUDP_PURCHASE_CSITEMS` | `DAFMJPEBBHI` | round ctx, `List<uint>` item ids, `ECSItemBuyType` | **on-wire (18/34) but buys nothing** — no price/token field; send site `IHFFDJIDIAA::NMPDDOPCHBN+0x16c` @ 0x07398B84 |
| 607/608 | `ASK_PURCHASE` / `PURCHASE_FOROTHERS` | `ODAFMPDAEIL` / `FDDGNOMMIGP` | `List<uint>` (+target) | 608 spends *your* tokens on a teammate |
| 1474/1492/481/983/996 | reinforce / sync-use / ingame-shop-buy / personal-shop | — | ids/flags | all server-authoritative balances |
| 113/131/132 | `USE_INVENTORY` / `TRYUSE` / `CANCELUSE` | `HHKGAHCLGJI` / `DEHBIKODNMO` | item id + 2 uints | **131 has an inbound handler `PLBLAINCCLN` → the server validates the try-use and answers**; 113 has no inbound handler |
| 111 | `RUDP_PICKUP_INVENTORY` | — | — | server owns world loot |
| 142/143/1054 | rescue / call-for-revive | `COBFBHFCIPD` / `HBLNNOBIIKF` | target player id | OTHER-affecting but *helpful*, not harm |

---

## 5. What I could NOT determine, and the trace/capture that would settle each

1. **Is there a body-integrity MAC on 2001?** The whole rewrite design rests on "no,"
   yet no capture has ever exercised a *modified* body (ghost only ever replayed
   byte-identical packets; 0 `JITTER`-phase rows in 229 files). **Decisive test:** rewrite
   `v0` by +1 unit for 10 s and watch the self-echo (`TELEPORT.md §8`). I cannot answer
   it from existing data.
2. **Exact position gate** in (2.77, 5.31] m — binary-search with ghost releases.
3. **Vehicle-position twins (2002/2006/2031):** no vehicle appears in the four captures
   I have on disk; their on-wire presence, plaintext status and rewritability are
   unverified. Needs a BR capture taken while driving/riding.
4. **Independent velocity/displacement check** separate from the distance gate — rewrite
   position only, leave velocity, watch for a correction (IL2CPP §5.1 lead).
5. **Whether v18 ping is trusted for lag-compensation** — spoof it low/high and measure
   hit-registration timing off the damage feed.
6. **Encrypted Tier-B bodies unverified on-wire** — layouts are read from the binary,
   not decoded live. Confirming any field's real value (and whether the server corrects
   it) needs the session `SECRET_KEY` + a decode pass; without it these rows are
   structure-only.
7. **Does the client ever send 106/3532 for PvP in BR?** Absent in my 2 survival + 2
   Clash matches; a longer BR capture with confirmed player kills would strengthen the
   "never" to a firm negative.

---

## 6. Agreement and refinements vs IL2CPP_FINDINGS.md

**No contradictions found** — every layout was checked against our own image, not
`dump.cs`. Refinements/additions, all evidence-backed:

- **New:** the correction message for out-of-gate position is inbound **Cmd 144**, with
  the client acking via outbound **146** (observed 6/8/3/2). IL2CPP/TELEPORT left the
  correction carrier unnamed. Refinement, not contradiction (§3).
- **New wire evidence:** **Cmd 106 and 3532 are absent outbound in 4/4 cleanly-decoded
  matches** despite active fire — bears directly on the open IL2CPP §5.5 / PROTOCOL_MASTER
  §8.2 question "does the client claim PvP hits in a real match." In these matches: no.
- **Confirmed first-hand:** 2001 plaintext + all reliable gameplay msgs TEA-encrypted
  (§1); 2001 ~10 Hz sole plaintext state carrier; 413 on-wire but value-less (§4.3).
- **Note for the master doc (outside IL2CPP's scope):** PROTOCOL_MASTER §1.1's "6-byte
  rotating XOR mask" is superseded by `ff-udp-framing-solved` — the header is a
  single-byte `m=SECRET_KEY[0]` XOR plus a `HEAD_SECRET` field-order permutation, and
  the **Cmd is in the header** (which is what let me count real msgids here). Not an
  IL2CPP contradiction; flagged so the two docs are reconciled.

---

## 7. Appendix — the full in-match outbound census (this is the classified set)

**47 distinct outbound command ids** observed across the union of four cleanly-decoded
matches (2 Clash Squad + 2 survival) — this is the in-match SEND set I classified.
Rates from capture `20260910_161940` (Clash) / `20260910_225854` (survival):

```
PLAINTEXT (unreliable), rewritable in place:
  2    (encrypted input stream)   ~20-27 Hz   [body TEA despite plaintext header]
  2001 UDP_PLAYER_STATE_SYNC      ~10 Hz      *** the manipulable surface ***
  2000 UDP_SYNC_SERVER_TIME       ~0.5 Hz     plaintext, no exploitable state
  3    UDP_PING                   ~1 Hz       liveness

TEA-encrypted reliable (need SECRET_KEY to rewrite; never inject/withhold):
  fire/aim:   104 105 137 138 3039
  reload:     133 134
  weapon:     108 643 173
  inventory:  111 113 131 132 855(CONTAINER_PICKUPSTATE)
  ability:    248 249 951 952
  movement:   193 198 199 204
  gadget:     221(ADD_ICEWALL)
  revive:     142 143 1054
  comms:      148 551 1621
  cs-shop:    413 481 983 996 1474 1492 1042
  zone/misc:  322 387 235 737 1000 146(CONFIRM_FORCESYNC) 2020

NEVER observed outbound in 4/4 matches (present in code, gated/other-affecting):
  106 127 166 222 240 394 865 (TAKE_DAMAGE family)   3532 (ShopTokenGun_Hit)
  160 162 3030 (grenade)   125 126 (vehicle on/off)   2002 2006 2031 (vehicle pos)
```

**Framing-solve provenance (all four, no body key):**

| capture | mode | m | HEAD_SECRET order | DATALEN fit | CRC7 | OUT pkts | 146 acks |
|---|---|---|---|---|---|---|---|
| phone_pull12 `150701` | Clash | 0x20 | [Flags,OrderID,Length,SendOption,Cmd] | 6000/6000 | 25704/25704 | 11,996 | 6 |
| phone_pull15 `161940` | Clash | 0x71 | [SendOption,OrderID,Flags,Cmd,Length] | 6000/6000 | 37100/37100 | 18,013 | 8 |
| dev_logs `221243` | survival | 0xDB | [SendOption,Flags,Cmd,Length,OrderID] | 6000/6000 | 14034/14034 | 6,640 | 3 |
| dev_logs `225854` | survival | 0x97 | [Flags,Cmd,Length,OrderID,SendOption] | 6000/6000 | 34841/34841 | 15,904 | 2 |

> Two further full captures (`155351`, `175549`) solved framing cleanly but mis-split
> the 2-byte Cmd/OrderID pair (the solver's `_fix_1byte_ambiguity` only disambiguates
> the two 1-byte fields), so their reliable "cmds" read out as sequential OrderID
> numbers (87,88,89,…). **Excluded from the census** to avoid that artifact — a caution
> for anyone re-running `ffdecode.py`: verify reliable cmds aren't a monotone run
> before trusting them.
