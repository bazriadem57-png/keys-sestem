# Split plan: `EspEngine` and `EspRenderView`

**Status:** plan only. No source file has been modified.
**Scope:** structural refactoring. Behaviour, timing, allocation profile and field
visibility semantics must come out byte-for-byte equivalent.
**Language level:** Java 8 (`app/build.gradle` pins
`sourceCompatibility`/`targetCompatibility` to `VERSION_1_8`). No records, no `var`,
no switch expressions, no `List.of`, no `Map.of`, no local type inference.

| file | measured lines | brief said |
| --- | --- | --- |
| `app/src/main/java/com/fakelag/cryhard8/esp/EspEngine.java` | **2161** | 2125 |
| `app/src/main/java/com/fakelag/cryhard8/overlay/EspRenderView.java` | **1865** | 1865 |

`EspEngine.java` is 36 lines longer than the brief states because it is currently
modified in the working tree (`git status`: ` M .../esp/EspEngine.java`). **Every line
range in this document is against the working-tree file as read, not against
`HEAD`.** Re-derive the ranges if the working tree is reset before the split starts.

---

## 0. Why this is delicate

These two files are not merely large. They are the written record of about a dozen
debugging cycles, and a large fraction of their bulk is comments that exist because
someone already made the obvious change and it was wrong. Three structural facts
constrain every option below:

1. **`EspEngine`'s public surface is load-bearing across 18 files.** `core/PacketLoop`,
   `core/UdpSessionManager`, `esp/EspBodyDecoders`, `filter/AimFilter`,
   `filter/TeleportFilter`, `filter/MarkFilter`, `overlay/*`, `dev/capture/DecodedDumper`
   all call into it. The class name, its public constants (`MAX_HP`, `ROLE_*`,
   `TEAM_SRC_*`, `UNITS_PER_METRE`, `PITCH_DEG_PER_LSB`) and its nested `Track` type
   must survive unchanged.

2. **`EspRenderView`'s `public static volatile` tuning fields are referenced 204 times
   from 8 files** (`esp/EspTuning` 124, `overlay/EspTunePanel` 57, `FloatingOverlayService`
   10, `overlay/AimEditOverlay` 8, `overlay/AimCalibrator` 3, `filter/AimFilter` 1,
   `overlay/OverlayButton` 1, `esp/EspEngine` 1). They are the app's persisted
   configuration surface; `EspTuning` reads and writes them by name against
   `SharedPreferences` keys. **They stay in `EspRenderView`.**

3. **The engine is fed from several threads at once.** `core/PacketLoop` (the TUN read
   loop) calls `observeKeepalive` / `observeInputStream`; `core/UdpSessionManager`
   dispatches one `RecvRunnable` **per UDP session** onto a thread pool, and each of
   those calls `observeChainPacket` / `observeDamage` / `observeHandleEvent` /
   `observeSmallInbound` / `observePriSync` / `observeEquipment` / `observeBindPri`.
   The view snapshots on the UI thread (`EspOverlay`'s `Choreographer.FrameCallback`
   calls `renderView.update(...)` then `invalidate()`) and draws on the UI thread.
   `statusLine()` / `calibHint()` are polled at 500 ms from the same main `Handler`.

---

## PART 1 — `esp/EspEngine.java`

### 1.1 Current structure map

Reference map of the existing file, used by every table below.

| lines | content |
| --- | --- |
| 1–35 | package, imports, wire-format class javadoc |
| 38–43 | session-mask state (`maskCounts`, `maskSamples`, `k2`–`k7`, `maskValid`, `maskLocked`) |
| 45–54 | own-state volatiles (`posX/posZ/posY`, `dirX/dirY/dirZ`, `airborne`, `stateEnum`, `tickMs`, `rttMs`, `slidePathPos`) |
| 56–89 | `MOUNTED: THE KEEPALIVE STOPS` banner |
| 91–144 | `OWN_STALE_MS`, `ownEcho`, `ownEchoMs`, `ownFromEcho()`, `mounted()`, `refreshOwnFromEcho()` |
| 145–170 | `ownLastUpdateMs`, `ownSamples`, `keepaliveParseOk/Bad`, `ownTeam` + squad-index javadoc, `ownTeamSeenMs`, `lastMatchResetMs` |
| 172–235 | `public static final class Track` |
| 237–288 | `TICK_MS`, `VEL_GAIN`, `VEL_DT_MIN/MAX_MS`, `VEL_MAX_U_PER_MS`, `VEL_TELEPORT_UNITS`, `SUB_TICK_MS` |
| 290–339 | `LIVE LAG MEASUREMENT` banner, history arrays, `lagMs`, `lagSamples`, `LAG_*` |
| 341–386 | `pushOwnHistory()`, `measureLag()` |
| 388–424 | `measuredLagMs()`, `lagFromEcho()`, `rttMs()`, `slidePathPos()`, `lagSampleCount()` |
| 426–462 | `MAX_HP`, `ROLE_UNKNOWN`, `TEAM_SRC_*`, `isValidTeam()`, `ROLE_SELF/TEAM/ENEMY` |
| 464–496 | `UNITS_PER_METRE`, `SELF_UNITS`, deleted-proximity tombstone, `entities`, `lastEntityCount` |
| 498–501 | `calibReadout`, constructor |
| 503–606 | `readVarint()`, `skipVarints()`, `varints()`, `zz()`, `f32()` |
| 608–665 | `observeInputStream()`, `evaluateMask()`, `observeSmallInbound()` |
| 667–737 | `observeKeepalive()` |
| 739–854 | chain-family javadoc, `MAX_ENTITY_ID`, `MAX_CHAIN_RECORDS`, `CHAIN_HEADER`, `MIN_RECORD_BYTES`, `MIN_RECORD_X`, `CHAIN_MAX_LEN` |
| 856–1024 | `observeChainPacket()` — incl. `---- MATCH BOUNDARY ----` 881–923, `---- STRUCTURAL PARSE ----` 924–944, `---- ADAPTIVE RECORD SPLIT ----` 946–1024 |
| 1026–1127 | `vi()`, `parseStructured()`, `ID_CEILINGS`, `Z_FLOORS`, `countStarts()` |
| 1130–1193 | `updateTrack()` |
| 1195–1265 | `updateVelocity()`, `seedVelocity()` |
| 1267–1419 | `classify()` (javadoc 1267–1307, rung ladder 1308–1419) |
| 1421–1480 | `YAW_DEG_PER_LSB`, `PITCH_DEG_PER_LSB`, `MAX_SQUAD`, `LATE_ARRIVAL_MS`, `MATCH_GAP_MS`, `firstChainMs`, `lastChainMs`, `matchHandle` |
| 1482–1609 | `observeHandleEvent()`, `spDamage*`, `observeDamage()` |
| 1611–1690 | `noteTeam()`, `resetMatch()` |
| 1692–1730 | `teamLine()`, `ownSquadKnown()` |
| 1732–1828 | `ownEntityId`/`damageEvents`/`kills`, `pri`, `observePriSync()`, `EQUIP_SCAN`, `observeEquipment()`, `roster`, `observeBindPri()`, id/counter accessors |
| 1830–1898 | `HEAD_POINT_STALE_MS`, `headPointForVictim()` |
| 1900–1923 | `maskReady()`, `maskLocked()`, `posX/posZ/posY()`, `dirX/dirY/dirZ()`, `yawRad()`, `pitchRad()` |
| 1925–2089 | `CAMERA-FORWARD ANGULAR EXTRAPOLATION` banner, `dirSampleMs`, `camAngVel*`, `CAM_*`, `computeCameraAngVel()`, `extrapolatedDir()`, `dirSampleMs()`, `camPitchDeg()`, `camYawDeg()`, `camAngSpeedDegPerSec()` |
| 2091–2110 | `airborne()`, `stateEnum()`, `tickMs()`, `ownLastUpdateMs()`, `entities()`, `activeEntityCount()`, `keepaliveParse*()` |
| 2112–2161 | `calibrationReadout()`, `updateCalibReadout()` |

### 1.2 Proposed classes

All new types go in `com.fakelag.cryhard8.esp` and are **package-private
(`final class X`)** unless stated. `EspEngine` stays `public final class` and keeps its
entire public surface as a thin delegating facade.

---

#### `EspEngine` (facade — stays public, ~300 lines)

**Responsibility:** the public API and the wiring between collaborators. Owns nothing
but `final` references, the public constants, and `resetMatch()`.

**Keeps (does not move):**
- lines 1–35 class javadoc (the wire-format contract — it describes the whole file's
  subject and belongs on the facade),
- 172–235 `public static final class Track` — see §1.5,
- 426–462 `MAX_HP`, `ROLE_*`, `TEAM_SRC_*`, `isValidTeam()`,
- 464–485 `UNITS_PER_METRE`,
- 1429–1439 `public static volatile float PITCH_DEG_PER_LSB`,
- 1641–1690 `resetMatch()`,
- 1737–1740 `pri` + `pri()`, 1795–1798 `roster` + `roster()`.

**Public surface:** unchanged — all 9 `observe*` methods, `maskReady()`,
`maskLocked()`, `posX/posY/posZ()`, `dirX/dirY/dirZ()`, `yawRad()`, `pitchRad()`,
`airborne()`, `stateEnum()`, `tickMs()`, `ownLastUpdateMs()`, `ownEntityId()`,
`ownFromEcho()`, `mounted()`, `measuredLagMs()`, `lagFromEcho()`, `lagSampleCount()`,
`rttMs()`, `slidePathPos()`, `entities()`, `activeEntityCount()`, `damageEvents()`,
`kills()`, `spDamageTotal()`, `spDamageEvents()`, `keepaliveParseOk/Bad()`,
`extrapolatedDir()`, `dirSampleMs()`, `camPitchDeg()`, `camYawDeg()`,
`camAngSpeedDegPerSec()`, `headPointForVictim()`, `teamLine()`,
`calibrationReadout()`, `pri()`, `roster()`.

Each becomes a one-line delegate, e.g. `public double posX() { return own.posX; }`.

---

#### `Varints` — LEB128 / zigzag / float32 primitives

| moves in | from |
| --- | --- |
| `readVarint()` | 521–532 (+ javadoc 505–520) |
| `skipVarints()` | 534–547 |
| `varints()` | 549–577 |
| `zz()` | 579–601 |
| `f32()` | 603–606 |
| `vi()` | 1026–1038 |

**Public surface:** `static long readVarint(byte[], int, int)`,
`static int skipVarints(byte[], int, int, int)`, `static long[] varints(byte[], int, int)`,
`static long zz(long)`, `static float f32(long)`, `static long vi(byte[], int[], int)`.

All already `private static` with no state. Purely mechanical; zero risk.
The 16-line `readVarint` javadoc (505–520, "the body does not start at a fixed offset")
moves with it verbatim — it is the reason `skipVarints` exists at all.

*Per-packet cost:* `varints()` allocates `long[32]` plus an exact-size copy per call.
Unchanged by the move — do not "optimise" it in this pass.

---

#### `SessionMask` — session XOR-mask recovery

| moves in | from |
| --- | --- |
| mask state | 38–43 |
| `observeInputStream()` | 610–622 |
| `evaluateMask()` | 624–644 |
| `observeSmallInbound()` | 646–665 |

**Public surface:** `void observeInputStream(byte[], int)`,
`void observeSmallInbound(byte[], int, int)`, `boolean valid()`, `boolean locked()`.

Self-contained: `maskCounts`/`maskSamples` are touched only by `observeInputStream`
(PacketLoop thread); `k2`–`k7`/`maskValid`/`maskLocked` are `volatile` and read by
`observeSmallInbound` (a recv thread) and by `maskReady()` (UI thread). Modifiers copy
across verbatim.

---

#### `CameraMotion` — camera-forward angular velocity and extrapolation

| moves in | from |
| --- | --- |
| banner comment | 1925–1938 |
| `dirSampleMs`, `camAngVel*`, `camAngVelValid`, `CAM_DT_MIN/MAX_MS`, `CAM_CUT_RAD` | 1940–1954 |
| `computeCameraAngVel()` | 1956–1995 |
| `extrapolatedDir()` | 1997–2045 |
| `dirSampleMs()`, `camAngSpeedDegPerSec()` | 2047–2060, 2082–2089 |

**Public surface:** `void observe(float px, float py, float pz, long pMs, float nx,
float ny, float nz, long nMs)`, `boolean extrapolatedDir(long now, double leadMs,
double maxDeg, float[] out)`, `long sampleMs()`, `void invalidate()`,
`double angSpeedDegPerSec()`.

`invalidate()` is the extraction of line 141 (`camAngVelValid = false;` inside
`refreshOwnFromEcho`) — the mounted path must still be able to say "refuse to
extrapolate a 1.41-degree-quantised yaw".

`camPitchDeg()` / `camYawDeg()` (2062–2080) read `dirX`/`dirY`/`dirZ`, which live in
`OwnStateTracker`, so they belong there rather than here despite the "cam" prefix.

*Per-frame cost:* `extrapolatedDir` runs once per `update()` (up to 120 Hz). It writes
into the caller's preallocated `float[3]`; the signature is unchanged so the view's
`dirScratch` still does the work. **Do not change the signature to return a new array.**

---

#### `LagEstimator` — self-echo cross-correlation ping measurement

| moves in | from |
| --- | --- |
| banner comment | 290–314 |
| `OWN_HIST`, `histMs/histX/histY`, `histCount`, `histHead` | 316–322 |
| `lagMs`, `lagSamples`, `LAG_MIN/MAX_MS`, `LAG_MATCH_UNITS`, `LAG_MOVE_UNITS`, `LAG_ALPHA` | 324–339 |
| `pushOwnHistory()` | 341–347 |
| `measureLag()` | 349–386 |
| `measuredLagMs()`, `lagFromEcho()`, `lagSampleCount()` | 388–424 (minus `rttMs()`/`slidePathPos()`) |

**Public surface:** `void push(double x, double y, long now)`,
`void measure(double ex, double ey, long now)`, `double measuredLagMs(int rttMsFallback)`,
`boolean fromEcho()`, `int sampleCount()`, `void reset()`.

Two changes of shape, both behaviour-preserving:
- `pushOwnHistory()` currently reads the enclosing `posX`/`posY` fields directly
  (lines 343–344). It takes them as parameters instead. The caller
  (`OwnStateTracker.observeKeepalive`) passes the values it has just written, in the
  same order, at the same point in the method — line 732 of the current file.
- `measuredLagMs()` (403–406) consults `rttMs`, which stays in `OwnStateTracker`.
  Pass it in: `own.measuredLagMs()` becomes
  `lag.measuredLagMs(own.rttMs)`. The facade's `measuredLagMs()` does that join.

`reset()` is lines 1686–1689 of `resetMatch`.

**Threading note — do not "fix" this.** `histMs`/`histX`/`histY`/`histCount`/`histHead`
are **plain, non-volatile**, written by `push()` on the PacketLoop thread and read by
`measure()` on a UDP recv thread. That is a pre-existing benign data race and it is
tolerable precisely because a stale history entry costs at most one lag sample out of
an EMA. Adding `synchronized` or `volatile` here would put a lock or a memory barrier
on a 10 Hz write / 5 Hz-per-entity read path and would change timing. **Copy the
modifiers verbatim; add a comment saying why they are what they are.**

---

#### `OwnStateTracker` — Cmd 2001 keepalive decode and own-player state

| moves in | from |
| --- | --- |
| own-state volatiles | 45–54 |
| `MOUNTED` banner | 56–89 |
| `OWN_STALE_MS`, `ownEcho`, `ownEchoMs`, `ownFromEcho()`, `mounted()`, `refreshOwnFromEcho()` | 91–144 |
| `ownLastUpdateMs`, `ownSamples`, `keepaliveParseOk/Bad` | 145–148 |
| `ownTeam` javadoc + `ownTeam`, `ownTeamSeenMs` | 150–168 |
| `observeKeepalive()` | 669–737 |
| `ownEntityId` | 1733 |
| own-state accessors | 1900–1923, 2062–2080, 2091–2094, 2109–2110 |

**Public surface:** `void observeKeepalive(byte[], int, int)`,
`void refreshFromEcho(EspEngine.Track, long now)`, `boolean mounted()`,
`boolean fromEcho()`, plus the read accessors the facade delegates to.

**This class is where the two writer threads collide**, and concentrating that in one
file is the single biggest legibility win in the engine split:
`observeKeepalive` writes `posX/posY/posZ`, `dirX/dirY/dirZ`, `dirSampleMs` from the
**PacketLoop thread**, and `refreshOwnFromEcho` writes *the same fields* from a **UDP
recv thread** (via `observeChainPacket` → `updateTrack` → line 1192). Every one of
those fields is `volatile` today and must stay `volatile`. There is no atomic grouping
across them and there never was — a reader can see a new `posX` with an old `dirX`.
**Do not introduce an immutable snapshot object to "fix" that**: it would add an
allocation on the 99 ms keepalive path and change what a mid-update reader sees.

The negative coupling documented at lines 113–124 — `refreshOwnFromEcho` deliberately
does **not** touch `ownLastUpdateMs` (it is the mounted detector itself) and
deliberately does **not** call `pushOwnHistory` (the lag estimator would correlate the
echo against itself and collapse to zero) — now spans a class boundary to
`LagEstimator`. **Restate that comment in both classes**, because a future reader of
`LagEstimator.push()` has no way to see the omission from there.

`observeKeepalive` also calls out to `LagEstimator.push()` (732) and to
`CameraMotion.observe()` (709) and updates `ownTeam` (696–699). Those become three
collaborator calls in the same order, at the same points.

---

#### `TrackStore` — the entity map, position gate and velocity

| moves in | from |
| --- | --- |
| velocity constants + `TICK_MS`, `SUB_TICK_MS` | 237–288 |
| `SELF_UNITS` + proximity tombstone | 487–494 |
| `entities`, `lastEntityCount` | 495–496 |
| `updateTrack()` | 1130–1193 |
| `updateVelocity()` | 1195–1233 |
| `seedVelocity()` | 1235–1265 |
| `YAW_DEG_PER_LSB` | 1421–1427 |
| `HEAD_POINT_STALE_MS`, `headPointForVictim()` | 1830–1898 |
| `entities()`, `activeEntityCount()` | 2096–2107 |

**Public surface:** `Track update(int id, long x, long z, long y, long now)`,
`Track get(int id)`, `Track getOrCreate(int id)`, `Map<Integer, Track> map()`,
`int activeCount(long ms)`, `boolean headPointForVictim(int, int, int[])`,
`void clear()`, `void setLastEntityCount(int)`, `int lastEntityCount()`.

`updateTrack()` currently ends by calling `classify(id, t)` (1189) and
`refreshOwnFromEcho(t, now)` (1192). Both are cross-cutting. Either
- **(recommended)** have `update(...)` return the `Track` and let the caller
  (`EntityChainParser`) do `teams.classify(id, t); if (t.role == ROLE_SELF &&
  own.mounted()) own.refreshFromEcho(t, now);` at exactly the same point, or
- hold `TeamClassifier` and `OwnStateTracker` references inside `TrackStore`.

Prefer the first: it keeps `TrackStore` a leaf with no back-references, and the two
calls are already the last two statements of the method so the ordering is trivially
preserved.

*Per-packet cost:* `updateTrack` + `updateVelocity` run once per entity per chain
packet, ~5 Hz per entity. Both are branch-and-arithmetic only, no allocation except a
`new Track()` on first sighting. Unchanged.

---

#### `TeamClassifier` — friend/foe

| moves in | from |
| --- | --- |
| `classify()` javadocs + rung ladder | 1267–1419 |
| `MAX_SQUAD`, `LATE_ARRIVAL_MS` | 1441–1467 |
| `noteTeam()` | 1611–1639 |
| `teamLine()`, `ownSquadKnown()` | 1692–1730 |

**Public surface:** `void classify(int id, Track t)`, `void noteTeam(int id, int team,
int src)`, `String teamLine()`.

Reads, from collaborators: `own.ownTeam`, `own.ownTeamSeenMs`, `own.ownEntityId`,
`boundary.lastMatchResetMs()`, `boundary.firstChainMs()`, `store.map()`,
`store.get(ownEntityId)`, `pri.squadFor(id)`, `roster.squad(id)`. Pass the
`OwnStateTracker`, `MatchBoundary`, `TrackStore`, `PriTracker` and `MatchRoster`
references in the constructor. All reads are of `volatile` fields today and stay so.

---

#### `MatchBoundary` — match-boundary detection state

| moves in | from |
| --- | --- |
| `MATCH_GAP_MS` | 1469–1473 |
| `firstChainMs`, `lastChainMs`, `matchHandle` | 1475–1480 |
| `lastMatchResetMs` | 169–170 |
| the `---- MATCH BOUNDARY ----` block | 881–923 |

**Public surface:** `boolean isNewMatch(long ownHandleNow, long now)`,
`void noteChain(long ownHandleNow, long now)`, `void noteReset(long now)`,
`long firstChainMs()`, `long lastMatchResetMs()`.

`resetMatch()` (1641–1690) **stays in `EspEngine`**, because it is the one place that
fans out across every collaborator: `store.clear()`, `own.clearIdentity()`,
`boundary.noteReset(now)`, `pri.reset()`, `roster.reset()`, `lag.reset()`. Putting it
anywhere else would give one collaborator references to all the others.

---

#### `EntityChainParser` — inbound chain framing and record extraction

| moves in | from |
| --- | --- |
| chain-family javadoc | 739–766 |
| `MAX_ENTITY_ID` + measurement table | 767–791 |
| `MAX_CHAIN_RECORDS`, `CHAIN_HEADER`, `MIN_RECORD_BYTES`, `MIN_RECORD_X`, `CHAIN_MAX_LEN` | 792–854 |
| `observeChainPacket()` | 856–1024 (minus the boundary block, which calls into `MatchBoundary`) |
| `parseStructured()` | 1040–1111 |
| `ID_CEILINGS`, `Z_FLOORS`, `countStarts()` | 1113–1127 |

**Public surface:** `void observeChainPacket(byte[], int, int)`.

The largest single unit at ~290 lines, and it should stay one unit: the structural
parse (924–944 / 1040–1111) and the adaptive fallback (946–1024) are a
preferred-path/fallback pair, and the 8-session measurement table at 968–982 is the
justification for the fallback existing at all.

*Per-packet cost, flagged:* `parseStructured` allocates **13 arrays per chain packet**
(1050–1056), sized `declared`. At the measured 5 Hz chain cadence that is ~65 small
arrays per second. This is existing behaviour. **The split must not multiply it** —
in particular do not turn each record into an object. Converting those 13 arrays to
preallocated `MAX_CHAIN_RECORDS`-sized fields is a genuine improvement but it is a
*behaviour-adjacent* change (it makes the parser stateful and therefore
non-reentrant across the concurrent recv threads); leave it out of this refactor and
raise it separately.

---

#### `CombatFeed` — damage, handle events, and the replication plumbing

| moves in | from |
| --- | --- |
| damage javadoc + `observeHandleEvent()` | 1482–1531 |
| `spDamageTotal/Events` + accessors | 1533–1542 |
| `observeDamage()` | 1544–1609 |
| `observePriSync()` | 1742–1757 |
| `EQUIP_SCAN`, `observeEquipment()` | 1759–1793 |
| `observeBindPri()` | 1800–1824 |
| `damageEvents`, `kills` + accessors | 1734–1735, 1827–1828 |

**Public surface:** the five `observe*` methods plus `damageEvents()`, `kills()`,
`spDamageTotal()`, `spDamageEvents()`.

Depends on `TrackStore` (creates/updates victim tracks), `TeamClassifier.noteTeam()`,
and `PriTracker`.

---

#### `EspDebugText` — the calibration readout builder

| moves in | from |
| --- | --- |
| `calibReadout` | 498–499 |
| `calibrationReadout()`, `updateCalibReadout()` | 2112–2160 |

**Public surface:** `String readout()`, `void refresh()`.

Read-only over every other collaborator, so it is the last thing to move and the
easiest to verify (its output is a string you can diff on screen).

*Cost:* `updateCalibReadout()` is called from `observeKeepalive` every 10th keepalive
(line 736), i.e. ~1 Hz, and it allocates a `StringBuilder` plus several
`String.format` results. That is fine at 1 Hz. **Do not move the call site into a
faster path.**

### 1.3 Result

`EspEngine.java` goes from 2161 lines to roughly 300 (constants, `Track`, `resetMatch`,
and ~35 one-line delegates). The ten collaborators land between 60 and 300 lines each.

### 1.4 Shared state that makes the engine split hard

**Fields that genuinely cross a thread boundary.** Every one is `volatile` today.
Every one stays `volatile` after the move, regardless of which class it lands in —
`volatile` on a field of a package-private class reached through a `final` reference
gives exactly the same guarantee it gives today.

| field(s) | written by | read by | lands in |
| --- | --- | --- | --- |
| `posX`, `posY`, `posZ` | PacketLoop (`observeKeepalive`) **and** recv thread (`refreshOwnFromEcho`) | UI (`update`), recv (`measureLag`), filters | `OwnStateTracker` |
| `dirX`, `dirY`, `dirZ`, `dirSampleMs` | PacketLoop **and** recv thread | UI (`update`, `extrapolatedDir`), `AimCalibrator` | `OwnStateTracker` / `CameraMotion` |
| `camAngVelX/Y/Z`, `camAngVelValid` | PacketLoop; invalidated from recv thread | UI (`extrapolatedDir`) | `CameraMotion` |
| `airborne`, `stateEnum`, `tickMs`, `rttMs`, `slidePathPos` | PacketLoop | UI | `OwnStateTracker` |
| `ownLastUpdateMs`, `ownEcho`, `ownEchoMs` | PacketLoop + recv | UI (`update`, `statusLine`) | `OwnStateTracker` |
| `ownTeam`, `ownTeamSeenMs`, `ownEntityId` | PacketLoop; **cleared by `resetMatch` on a recv thread** | recv (`classify`, `noteTeam`), UI | `OwnStateTracker` |
| `k2`–`k7`, `maskValid`, `maskLocked` | PacketLoop | recv (`observeSmallInbound`), UI (`maskReady`) | `SessionMask` |
| `lagMs`, `lagSamples` | recv | UI | `LagEstimator` |
| `firstChainMs`, `lastChainMs`, `matchHandle`, `lastMatchResetMs` | recv (possibly >1 recv thread) | recv (`classify`), UI | `MatchBoundary` |
| `damageEvents`, `kills`, `spDamage*`, `lastEntityCount` | recv | UI | `CombatFeed` / `TrackStore` |
| every field of `Track` | recv | UI (`update`), filters (`headPointForVictim`) | `EspEngine.Track` (unmoved) |
| `calibReadout` | PacketLoop | UI | `EspDebugText` |

**Fields that are deliberately NOT volatile and must not become so:**

| field(s) | why it is safe today |
| --- | --- |
| `maskCounts[]`, `maskSamples` | single writer (PacketLoop), never read elsewhere |
| `histMs/histX/histY`, `histCount`, `histHead` | written PacketLoop, read recv — a real race, but a lost sample only perturbs an EMA; a barrier here would sit on a 10 Hz path |
| `keepaliveParseOk/Bad`, `ownSamples` | counters, display only; `ownSamples` is also zeroed by `resetMatch` from a recv thread |

**How the split keeps the contract:**

1. Every collaborator is held in a `final` field of `EspEngine`, constructed in the
   `EspEngine` constructor. Final-field semantics guarantee safe publication of the
   collaborator object itself to every thread that can reach the engine; per-field
   `volatile` then carries the same guarantee it carries today.
2. No collaborator reference is ever reassigned. No lazy init.
3. No `synchronized`, no `AtomicX`, no `ReentrantLock` is introduced anywhere.
   Introducing one would change the timing of the hot path and is out of scope.
4. Field modifiers are copied **verbatim**. A `volatile double` stays a
   `volatile double`; a plain `int` stays a plain `int`.
5. Cross-collaborator reads stay direct field or one-line-getter reads. Do **not**
   introduce defensive copies, snapshots or immutable value objects on any path that
   runs per packet.

### 1.5 What must NOT move, and why

1. **`Track` stays a nested class of `EspEngine`** (172–235). `EspRenderView` imports
   `com.fakelag.cryhard8.esp.EspEngine.Track` and `PriTracker`/`MarkTarget` javadoc
   refers to `EspEngine.Track`. Promoting it to a top-level `Track` buys nothing and
   invalidates those references. Its `---- dead reckoning ----` comment block
   (221–228) explains the units (game-units per **millisecond**, `vx/vy` horizontal,
   `vz` vertical) and must stay attached to the fields it describes.

2. **The velocity rules stay together and stay in `TrackStore`** (237–288 with
   1195–1265). Three separate measured findings are encoded here and each has already
   been "improved" once:
   - `VEL_GAIN = 1.0` — *smoothing the velocity was measured and it HURTS* (RMS 0.574
     latest-tick vs 0.580/0.595/0.615 for EMA and mean variants);
   - `VEL_MAX_U_PER_MS = 13.0` — *"Do not clamp below this"*, with the sweep showing
     every tighter clamp made things worse (1044 → 1082 → 1098 → 1110 → 1140 RMS);
   - `VEL_TELEPORT_UNITS` — *"the exact filter whose absence destroyed the correlation
     analysis twice"*, mandatory.

   Splitting the constants from `updateVelocity()`/`seedVelocity()` puts the evidence
   one file away from the code it forbids changing. **Keep the constant block
   immediately above the two methods in the new file.** Note also that
   `EspRenderView.SMOOTH_MS`'s javadoc (256–277) is the other half of this finding —
   *smooth the rendered position, never the velocity*. Add a one-line cross-reference
   in each direction; it is currently implicit and a split makes it invisible.

3. **The match-boundary block stays whole** (881–923), and its sentinel pairing must
   be explicit. The bug recorded there is precisely that a sentinel was invented in one
   method and never taught to its reader: `resetMatch()` sets `ownEntityId = -1`
   (line 1671), and the boundary detector's `(ownEntityId & 0xFFFFFFL)` read
   `0x00FFFFFF`, not zero — so a wiped identity read as *a different match*, and the
   reset re-triggered ten times a second (789 resets in 109 s; p90 blackout 24.15 s in
   Clash Squad). The plan's arrangement puts `resetMatch()` in `EspEngine` and the
   detector in `MatchBoundary`, which is exactly the geometry that produced the bug.
   **Mitigation, mandatory:** `MatchBoundary.isNewMatch()` takes `ownHandleNow` as a
   parameter, already computed by the caller, and the guard expression from 912–914
   stays with `resetMatch()`'s sentinel in `EspEngine`. Copy the full 1671-line comment
   *and* the 890–911 regression note to both sides.

4. **The friend/foe rung ladder stays one contiguous method** (1308–1419). Do not
   extract rungs into helper methods. The ladder's correctness is its *reading order* —
   rung 0's narrowed freshness gate, rung 1 self, rung 2 as the only rung permitted to
   conclude `TEAM`, rungs 3/4/6 as `ENEMY`-only, and rung 5's 30-line tombstone
   explaining that proximity promotion was **inverted** in Battle Royale (teammates
   0.158–0.206 vs enemies 0.641–0.888 on fraction-inside-10 m). The governing rule —
   *"only a server-published team byte may ever produce blue. No geometry, no
   co-location, no update rate."* — is a comment at 1410–1411 with no code of its own;
   it survives only because it sits inside the method. Extracting rungs orphans it.
   The `SELF_UNITS` / deleted-`TEAM_UNITS` tombstone at 487–494 is the same rule stated
   at the constant level and moves with `TrackStore` — keep a pointer from one to the
   other.

5. **The adaptive record-split table stays with its loop** (946–999 with the 8-session
   measurement table at 968–982, plus `MAX_ENTITY_ID`'s ceiling sweep at 767–791). The
   table is the reason a *fixed* ceiling is not used; separating them invites someone
   to "simplify" to a constant, which is exactly what broke every mode except Clash
   Squad.

6. **`MIN_RECORD_BYTES = 16`'s javadoc stays with the constant** (802–829). It is the
   only thing separating a real chain from the ECB-encrypted transport, and it
   documents 6 490 ciphertext packets that produced 522 phantom records colliding with
   live player ids.

7. **`UNITS_PER_METRE`'s javadoc stays** (464–485): the 950→1000 correction, and the
   corollary that Free Fire's gravity is −9.313 m/s² by design. *Observed, do not fix
   here:* `EspRenderView.UNITS_PER_METER` (565–574) is an alias of this constant but
   its javadoc still claims 1670 — a stale comment. Leave it; fixing it is a separate,
   reviewable one-line change, not something to bury in a refactor diff.

---

## PART 2 — `overlay/EspRenderView.java`

### 2.1 Current structure map

| lines | content |
| --- | --- |
| 1–55 | package, imports, class javadoc (world frame, view basis, axis mapping, snapshot contract) |
| 58–563 | **`public static volatile` calibration + feature config** — FOV, offsets, axis map, `MIRROR_X`, third-person boom, prediction, smoothing, camera extrapolation, pose, the whole AIM block, `SHOW_*`, `VIEW_MODE`, `PITCH_SIGN` |
| 469–475 | `public static float pxPerDeg()` |
| 565–641 | fixed render constants: `UNITS_PER_METER`, `BOX_H_M`, `BOX_W_M`, `STALE_MS`, `OWN_STALE_MS`, `MAX_DRAW`, `MIN_DIST_M`, `HEIGHT_REL_MAX`, `NEAR_UNITS`, radar sizes/ranges, `radarRangeM` |
| 643–655 | colour constants |
| 661–674 | `OrientationProvider` instances; `hasState`, `ownX/Y/Z`, `theta`, `fwd*`, `fwdValid`, `pitch`, `thetaKnown`, `foldedDeg`, `oriSource` |
| 675–704 | `enemyCount` + 17 parallel `enemy*` arrays sized `MAX_DRAW` |
| 706–711 | `SMOOTH_SLOTS`, `smX/smY/smZ/smMs` |
| 713–797 | `THE GAME'S VIEWPORT, NOT OURS` banner; `vpW/vpH/vpOriginX/vpOriginY/locScratch/vpCheckMs/vpExact`; `refreshViewport()` |
| 799–808 | `viewportHint()` |
| 810–846 | 20 preallocated `Paint` fields, `densityScale`, `labelBuf`, `lastCamSampleMs` |
| 848–858 | `eyeX/Y/Z`, `eyeValid`, view basis `fX..uZ`, `scratchX/scratchY` |
| 860–874 | `lastLeadMs`, `lastLeadEcho`, `dirScratch`, `lastCamExtrapDeg`, `lastMeasLagMs`, `lastOwnEcho` |
| 876–899 | `near*` calibration readout fields; `aimValid/aimId/aimScreenX/aimScreenY/aimYawErrDeg/aimPitchErrDeg/aimDistM`; `lockedId` |
| 901–985 | constructor (all `Paint` setup) |
| 996–1240 | `update(EspEngine)` |
| 1242–1244 | `sane()` |
| 1246–1312 | `statusLine()`, `viewModeName()`, `axisMapCode()` |
| 1318–1602 | `onDraw()` |
| 1604–1762 | `selectAimTarget()` |
| 1764–1784 | `calibHint()` |
| 1786–1818 | `clamp255()`, `project()` |
| 1820–1864 | `drawRadar()` |

### 2.2 Proposed classes

All new types go in `com.fakelag.cryhard8.overlay`, package-private `final class`.

---

#### `EspRenderView` (stays public, extends `View`, ~600 lines)

**Responsibility:** the Android `View` — window lifecycle, the public config surface,
and dispatch of `update()` and `onDraw()` to collaborators.

**Keeps (does not move):**
- 58–563 the entire `public static volatile` config block, and 469–475 `pxPerDeg()`.
  **Non-negotiable:** 204 references from 8 files, all by the name
  `EspRenderView.FIELD`, and `EspTuning` binds each to a `Prefs.KEY_*` string.
- 565–641 the fixed render constants (`MAX_DRAW` in particular is the array size the
  snapshot depends on, so it must be visible to it; package-private access is enough).
- 643–655 colour constants (referenced by two painters and by `drawRadar`; keeping them
  here avoids picking an arbitrary owner).
- 901–985 the constructor — but it now constructs the collaborators instead of 20
  `Paint`s, and each collaborator preallocates its own `Paint`s in *its* constructor.
- `update(EspEngine)` and `onDraw(Canvas)` as thin dispatchers, ~15 lines each.
- The public read surface used by `FloatingOverlayService`/`EspTunePanel`:
  `statusLine()`, `calibHint()`, `viewportHint()`, `viewModeName()`, `axisMapCode()` —
  as one-line delegates to `EspDebugLines`.

---

#### `EspSnapshot` — per-frame state, written by the builder, read by the painters

| moves in | from |
| --- | --- |
| `hasState`, `ownX/Y/Z`, `theta`, `fwdX/Y/Z`, `fwdValid`, `pitch`, `thetaKnown`, `foldedDeg`, `oriSource` | 664–674 |
| `enemyCount` + all 17 `enemy*` arrays | 675–704 |
| `radarRangeM` | 641 |
| `lastLeadMs`, `lastLeadEcho`, `lastCamExtrapDeg`, `lastMeasLagMs`, `lastOwnEcho`, `lastCamSampleMs` | 846, 860–874 (minus `dirScratch`) |

**Public surface:** package-private mutable fields. This is a data holder, not an
abstraction; getters would be 40 methods of noise and one more indirection each.

**Allocation contract, mandatory:** exactly **one** `EspSnapshot` instance, created in
the `EspRenderView` constructor. All arrays sized `MAX_DRAW` (or `SMOOTH_SLOTS`) once,
in the `EspSnapshot` constructor. `update()` overwrites slots `0..enemyCount` in place
and never reallocates. **Any design in which `update()` returns a new snapshot, or
copies arrays, or uses a `List`, is wrong** — the current code is explicitly written
around preallocation.

**Per-frame cost, called out:** `enemyWX[i]` in `onDraw` becomes
`snap.enemyWX[i]` — one extra `getfield` on a `final` field before the `aaload`. It is
negligible on ART, but the draw loop runs up to 64 entities × 120 Hz. **Mitigation:
hoist the arrays into locals once at the top of each loop**, e.g.
`final float[] wx = snap.enemyWX;`. That is free, allocation-free, and restores the
current bytecode shape exactly.

**Threading:** every field is written by `update()` on the UI thread and read by
`onDraw()` on the UI thread. That is why most are *not* volatile today, and they stay
non-volatile. The exceptions — `lastLeadMs`, `lastLeadEcho`, `lastCamExtrapDeg`,
`lastMeasLagMs`, `lastOwnEcho`, and the `near*` / `aim*` fields — are `volatile` today
even though `statusLine()` also runs on the main `Handler`. That is conservative but
harmless; **copy the modifiers verbatim rather than reasoning about whether they are
needed.** Removing a `volatile` is a visibility-semantics change and the brief forbids
it.

---

#### `EspProjector` — world→screen projection, viewport resolution, view basis

**Do this one first.** It is self-contained and it removes the 9-argument `project()`
that would otherwise have to be threaded through all three painters.

| moves in | from |
| --- | --- |
| `THE GAME'S VIEWPORT, NOT OURS` banner + viewport fields | 713–751 |
| `refreshViewport()` | 753–797 |
| `eyeX/Y/Z`, `eyeValid`, `fX..uZ`, `scratchX/scratchY` | 848–858 |
| basis build, **SIGN TRAP**, normalise | 1325–1359 |
| third-person boom | 1361–1371 |
| `---- projection constants ----`, HOR+ aspect model, `xSign` | 1373–1405 |
| `NEAR_UNITS` | 612–621 |
| `project()` + its javadoc | 1786–1818 |

**Public surface:**
```java
boolean beginFrame(EspSnapshot snap, int viewW, int viewH);  // false => nothing drawable
boolean project(float x, float y, float z);                  // result in scratchX/scratchY
float scratchX();  float scratchY();
float tanHalfX();  float tanHalfY();
float cx();  float cy();  float halfW();  float halfH();
String viewportHint();
```

`beginFrame()` is lines 1325–1405 verbatim: build forward from `snap.fwdValid`, build
right/up, bail on a degenerate basis (the `return` at 1357 becomes `return false`),
compute the boom eye, call `refreshViewport(w, h)`, derive `cx/cy/halfW/halfH`,
`tanHalfX/tanHalfY`, `xSign`. Those seven values become **fields** of the projector
instead of seven arguments passed to every `project()` call.

**Why this is the biggest mechanical win.** `project()` is called up to 6× per drawn
entity per frame (feet, head, chest, body-ray end, head-2, aim-ray end) plus once for
the nearest-target readout plus once per aim candidate. At 64 entities and 120 Hz that
is on the order of 46 000 calls per second, each currently pushing 9 arguments. Making
them fields is strictly cheaper and allocates nothing.

**Do not** make `project()` return a `PointF` or a `float[]`. `scratchX`/`scratchY`
as fields is the existing no-allocation contract; the javadoc at 1786–1795 says so
("copy it out before the next call") and every call site already does.

`viewportHint()` (799–808) uses `String.format` and moves here, but note it is called
from the 500 ms debug ticker via `statusLine()`, **not** from `onDraw`. Keep it that
way.

---

#### `EspBoxPainter` — boxes, health bars, labels, names, pose rays

| moves in | from |
| --- | --- |
| `boxStroke`, `boxFill`, `labelPaint`, `hpBarBg`, `hpBarFill`, `hpBarEdge`, `bodyPaint`, `aimPaint` (the pose ray paint) | 814–816, 824, 829–834 + their setup in 907–918, 940–942, 962–968 |
| `labelBuf` | 844 |
| the box loop | 1407–1548 |
| `clamp255()` | 1796–1798 |
| `BOX_H_M`, `BOX_W_M`, `AIM_RAY_M` usage | reads the constants that stay on the view |

**Public surface:** `void draw(Canvas c, EspSnapshot snap, EspProjector p, float densityScale)`.

`Paint`s are allocated in the `EspBoxPainter` constructor, which runs once from the
`EspRenderView` constructor. Net `Paint` count is unchanged. `labelBuf` stays a reused
`StringBuilder` and the draw call stays
`canvas.drawText(labelBuf, 0, labelBuf.length(), ...)` — **do not** change it to
`labelBuf.toString()`, which would allocate a `String` per entity per frame.

Note the `aimPaint` naming collision: line 823's `aimPaint` is the *pose aim-ray* paint
used at 1546, not an aim-system paint. Rename it `poseAimPaint` when it moves, so it
does not get shipped to `EspAimController` by mistake.

---

#### `EspRadarPainter` — the radar square

| moves in | from |
| --- | --- |
| `RADAR_PX`, `RADAR_MARGIN_PX` | 623–625 |
| `radarBg`, `radarBorder`, `radarDot`, `radarSelf`, `radarFacing`, `radarText` + setup | 818–822, 919–934, 982–984 |
| `drawRadar()` | 1820–1864 |

**Public surface:** `void draw(Canvas c, EspSnapshot snap, int viewW, int viewH)`.

`RADAR_MIN_RANGE_M` / `RADAR_MAX_RANGE_M` stay on `EspRenderView` (public config,
read by `EspTuning`); `radarRangeM` moves into `EspSnapshot` because it is recomputed
per frame in `update()` (1231–1239) and consumed in `drawRadar` (1851).

Smallest and most independent painter — a good second or third step, and a cheap
visual regression check (the radar is either right or obviously not).

---

#### `EspAimController` — target selection, aim overlay, injection publish

| moves in | from |
| --- | --- |
| `aimFovPaint`, `aimDotPaint`, `aimLockPaint`, `aimGuidePaint`, `aimAnchorPaint`, `aimSwipePaint`, `aimEditLabelPaint` + setup | 825–828, 836–841, 944–957, 970–980 |
| `aimValid/aimId/aimScreenX/aimScreenY/aimYawErrDeg/aimPitchErrDeg/aimDistM`, `lockedId` | 887–899 |
| `selectAimTarget()` | 1604–1762 |

**Public surface:** `void frame(Canvas c, EspSnapshot snap, EspProjector p, float
densityScale)` and read accessors for the seven result fields, which `EspDebugLines`
and `EspRenderView` surface.

**Careful:** the `aim*` result fields are `public volatile` on `EspRenderView` today.
A repo-wide grep shows **no external reader** — they are consumed only by
`statusLine()` (1286–1291) and by `onDraw`'s mark-target selection (1579). So they can
become package-private on `EspAimController` *and stay `volatile`*. If you would rather
not risk it, keep `public volatile` delegating fields on `EspRenderView`; that costs a
per-frame copy of 7 primitives, which is nothing. Recommendation: move them, keep
`volatile`.

Lines 1593–1599 of `onDraw` (the `AIM_ON` branch and the `AimInjector.aimRelease()`
else-arm) stay in the dispatcher, because the else-arm also clears `lockedId` and must
run whether or not the controller is invoked.

---

#### `EspSnapshotBuilder` — the per-frame engine read

| moves in | from |
| --- | --- |
| `full`/`folded` `OrientationProvider` instances | 661–662 |
| `SMOOTH_SLOTS`, `smX/smY/smZ/smMs` | 706–711 |
| `dirScratch` | 866 |
| `update(EspEngine)` body | 996–1240 |
| `sane()` | 1242–1244 |

**Public surface:** `void update(EspEngine esp, EspSnapshot out)`.

The smoothing arrays (`smX/smY/smZ/smMs`) are **per-entity render state that persists
across frames**, so they belong to the builder, not to the snapshot. Keeping them out
of `EspSnapshot` also keeps the snapshot honest as "this frame's values only".

`dirScratch` is a preallocated `float[3]` passed to `esp.extrapolatedDir(...)` (1047).
**It must stay a field.** A `new float[3]` there would be one allocation per frame at
120 Hz.

*Per-frame cost already present, preserve exactly:*
`esp.entities().entrySet()` (1122) allocates an iterator and `Map.Entry` views per
frame; `esp.roster().name(...)` (1219) returns a `String` per entity per frame;
`esp.pri().hpFor(...)` / `maxHpFor(...)` (1220–1221) are two map lookups per entity per
frame. All of this is in `update()`, not `onDraw`, and all of it is existing
behaviour. Do not "clean it up" in this pass; do not move any of it into `onDraw`.

---

#### `EspDebugLines` — the calibration/status text builders

| moves in | from |
| --- | --- |
| `statusLine()` | 1246–1296 |
| `viewModeName()`, `axisMapCode()` | 1298–1312 |
| `calibHint()` | 1764–1784 |
| `near*` fields | 876–886 |

**Public surface:** `String statusLine(...)`, `String calibHint()`,
`void setNearest(int id, float distM, boolean onScreen, float ndcX, float ndcY)`,
`void clearNearest()`; plus `static String viewModeName(int)` and
`static String axisMapCode()` which `EspRenderView` re-exposes as static delegates
(`EspTunePanel` calls them statically).

The nearest-target readout block (1550–1571) currently lives *inside* `onDraw` because
it needs the live projection. Keep the computation where it is and have it call
`debug.setNearest(...)` — a 5-primitive setter, no allocation. Moving the computation
out of `onDraw` would change what it measures.

**Allocation warning:** `statusLine()` and `calibHint()` use `String.format` heavily
(11 calls in `statusLine` alone). They are called at 2 Hz from `EspOverlay`'s debug
`Handler`, never from `onDraw`. **A split that accidentally routes either into the draw
path is the single most likely allocation regression in this plan** — verify by grep
after the move that neither name appears inside `onDraw`, `EspBoxPainter.draw`,
`EspRadarPainter.draw` or `EspAimController.frame`.

### 2.3 Result

`EspRenderView.java` goes from 1865 lines to roughly 600, almost all of which is the
`public static volatile` config block that must not move. The seven collaborators land
between 60 and 260 lines each.

### 2.4 Shared state that makes the view split hard

The view is *not* multi-threaded in the way the engine is — `update()`, `onDraw()`,
`statusLine()` and `calibHint()` all run on the UI thread — but it has three real
boundaries:

1. **The engine boundary.** `update()` is the *only* place engine state is read
   (class javadoc, 51–54: *"All state is snapshotted on the main thread by `update`
   before `invalidate()`; `onDraw` performs no engine reads"*). **This invariant must
   survive the split literally:** after the move, `EspEngine` must appear in exactly
   one new file, `EspSnapshotBuilder`. `EspBoxPainter`, `EspRadarPainter`,
   `EspAimController` and `EspProjector` must not import it except for the
   `EspEngine.ROLE_*` / `EspEngine.MAX_HP` constants, which are compile-time
   constants and not reads. Grep for `esp\.` inside each painter after the move — it
   must be empty.

2. **The wire boundary.** `onDraw` publishes to `MarkTarget.set(...)` (1586–1588),
   which is read from a packet thread by `filter/MarkFilter`. `MarkTarget` is already a
   separate class with its own publication discipline — **do not touch it**, and keep
   the `enemyRaw*` values it is fed untouched by the display axis map (the comment at
   681–686 and 1573–1577 is the reason those three parallel arrays exist at all).
   `MarkTarget.set` stays in the `onDraw` dispatcher, after the aim controller has run,
   because it prefers `aimId` when there is one.

3. **The injector boundary.** `AimInjector.aimTo(...)` / `aimRelease()` are called from
   `selectAimTarget` and from `onDraw`'s else-arm. `AimInjector` does its own
   rate-limiting and threading; the split must not change *when* those calls happen —
   `aimTo` exactly once per frame when `AIM_INJECT && aimValid`, `aimRelease()` on
   every other frame. The comment at 1679–1688 records that an earlier design pushed a
   complete swipe every 70 ms and cancelled the user's own touches.

4. **`volatile` on UI-thread-only fields.** `lastLeadMs`, `lastLeadEcho`,
   `lastCamExtrapDeg`, `lastMeasLagMs`, `lastOwnEcho`, `nearValid`, `nearId`,
   `nearDistM`, `nearNdcX`, `nearNdcY`, `nearOnScreen`, and the seven `aim*` results
   are all `volatile` today. Copy the modifier verbatim. Dropping it is a visibility
   change, and the brief rules those out.

### 2.5 What must NOT move, and why

1. **The SIGN TRAP and `MIRROR_X` must land in the same class, `EspProjector`.**
   This is the highest-risk item in the entire plan. The pair is:
   - line 1352 — `rX = -fZ; rY = 0f; rZ = fX;` — which is the **negation** of Unity's
     `cross(up, f) = (fZ, 0, -fX)`;
   - line 1402 — `float xSign = MIRROR_X ? -1f : 1f;` with `MIRROR_X` defaulting to
     `true`, i.e. `xSign = -1`;
   - line 1815 — where `xSign` is applied, and the only place `rX/rY/rZ` reach the
     screen.

   They cancel. The comment at 1337–1351 says so explicitly, and records the binary
   evidence (the Cmd 2001 packer at `0x0577E1D8` is a plain float32 copy of
   `Quaternion * Vector3.forward` — no negation, no swap) plus the fact that the
   8-way `VIEW_MODE` search was only ever compensating for this local convention.
   **Correcting one half alone silently mirrors the entire ESP** — every box lands on
   the mirror-image target, which looks like a calibration problem rather than a sign
   problem, and cost days the first time.

   Concretely: a "natural" split that puts the basis construction in a
   `ViewBasis` class and leaves the projection constants (including `xSign`) in
   `onDraw` **is wrong**, because the two halves then live in different files with no
   comment linking them. The proposed `EspProjector.beginFrame()` takes 1325–1405 as
   one block, so the comment sits between its two halves exactly as it does now.
   If a reviewer insists on separating them, the mitigation is a duplicated comment on
   both sides naming the other — but the recommendation is: **do not separate them.**

2. **The HOR+ aspect model stays with the viewport derivation, both in `EspProjector`.**
   The banner at 713–744 works the algebra through —
   `scale_x = halfW/tanHalfX = (w/2)/(tanHalfV·w/h) = h/(2·tanHalfV)`, **the width
   cancels** — and concludes that a *height* inset (nav bar) is a multiplicative error
   that `OFFSET_X_PX` can never absorb, while a *width* inset is additive and it can.
   That derivation is the justification for `refreshViewport()` existing and for
   `tanHalfX` being computed from `vpW/vpH` (line 1401) rather than from
   `getWidth()/getHeight()`. The HOR+ block at 1386–1401 then reinterprets `FOV_X_DEG`
   as horizontal-FOV-at-16:9, derives the aspect-independent vertical, and re-derives
   the actual horizontal from the real aspect.

   **Splitting `refreshViewport()` from the `tanHalfX` derivation separates a
   conclusion from its proof.** Any arrangement where the aspect is computed from the
   `View`'s own `w`/`h` reintroduces the original bug — zero error at the crosshair,
   growing with angle from it, indistinguishable on screen from a wrong FOV.
   `vpExact` and `viewportHint()`'s `"INSET-CORRECTED"` string exist to make that
   distinguishable and must keep working.

3. **`onDraw` must not allocate — and the preallocation is structural, not incidental.**
   Concretely, the following must survive verbatim:
   - 20 `Paint` objects preallocated in constructors (they redistribute across three
     painters; the *count* and the *construction site* — once, at view construction —
     do not change);
   - `labelBuf` reused with the `drawText(CharSequence, int, int, ...)` overload;
   - `dirScratch` (`float[3]`) and `locScratch` (`int[2]`) as fields;
   - `scratchX`/`scratchY` as fields rather than a returned object;
   - the 17 parallel `enemy*` arrays sized `MAX_DRAW` once, and `smX/smY/smZ/smMs`
     sized `SMOOTH_SLOTS` once.

   Two natural-looking splits that would break this, and must be refused:
   - **"`project()` returns a point object."** One allocation per call, ~46 000 per
     second. Use the scratch fields.
   - **"the snapshot is an immutable value object / a `List<EnemyRow>`."** One object
     per entity per frame, plus the list. Use the single mutable preallocated
     `EspSnapshot`.

   A third, subtler one: **"painters take the snapshot fields as arguments."** Not an
   allocation, but `EspBoxPainter.draw` would need ~17 array parameters and Java 8 has
   no way to bundle them without allocating. Pass the one `EspSnapshot` reference.

4. **`public static volatile` config fields stay on `EspRenderView`.** 204 references
   across 8 files, and `EspTuning` (124 of them) binds each to a persisted preference
   key. Moving them is pure churn and would strand ~10 javadoc cross-references in
   `EspTuning` and `EspTunePanel`. In particular `MIRROR_X`'s javadoc (143–157) says it
   is *"kept as a flag rather than folded into the basis so an existing install's saved
   preference does not double-flip"* — the field name is part of the persistence
   contract.

5. **`EXTRAPOLATE`'s gating of the camera extrapolation stays in `update()`**
   (1036–1043, condition at 1046). The comment records that the camera predictor used
   to answer only to its own `CAM_EXTRAP_MS` knob in a different panel section, so
   turning prediction off still left the basis being led 90 ms. *"One switch now means
   what it says."* The gate must remain a single `if` in the snapshot builder, not be
   pushed down into `CameraMotion`, or the two predictors drift apart again.

6. **The `MIN_DIST_M`, `STALE_MS`, `EXTRAP_FADE_MS`, `EXTRAP_STOP_MS` and
   `HEIGHT_REL_MAX` constants keep their javadocs.** `HEIGHT_REL_MAX` in particular
   (602–610) records that an *absolute* height band silently rejected every enemy
   height on a second map and flattened every box to own ground level.

---

## PART 3 — The order to do it in

Every step compiles and runs on its own. Build with (PowerShell, on its own, nothing
else in the same invocation — and check the APK timestamp afterwards):

```
.\gradlew assembleDebug
```

Commit per step. Do **not** batch steps: the whole value of this ordering is that a
regression is bisectable to one ~200-line move.

### Phase A — engine leaves (no behaviour reachable, pure mechanics)

| # | step | why here |
| --- | --- | --- |
| A1 | `Varints` | zero state, zero dependencies, all methods already `static`. Warms up the review. |
| A2 | `SessionMask` | self-contained state, two entry points, one reader. |
| A3 | `CameraMotion` | self-contained; one writer (`observeKeepalive`), one reader (`extrapolatedDir`). Verify: `statusLine`'s `CAMX applied=` figure still moves when you turn. |
| A4 | `LagEstimator` | self-contained; the only shape change is `push()` taking coordinates as arguments. Verify: `statusLine`'s `LEAD ... (echo)` still converges after ~3 m of movement. |

### Phase B — engine core

| # | step | why here |
| --- | --- | --- |
| B1 | `OwnStateTracker` | depends on A1/A3/A4. The biggest single move; do it when its three collaborators already exist so the keepalive body's fan-out is a straight substitution. Verify: `POS` and `DIR` lines in the calibration readout, and boxes still appear. |
| B2 | `TrackStore` | leaf with no back-references (see §1.2). Verify: `ENT n live, m moving`. |
| B3 | `MatchBoundary` | small, and `TeamClassifier` reads `lastMatchResetMs`/`firstChainMs` from it, so it must precede B4. |
| B4 | `TeamClassifier` | depends on B1/B2/B3 + `pri`/`roster`. Verify: `teamLine()` still reports `own=`, `known=n/m` and non-zero `src=118:` in a live match. **The highest-risk engine step** — a mistake here paints friends red. |
| B5 | `EntityChainParser` | depends on A1, B1–B4. Second-biggest move. Verify: `ka ok/bad` ratio unchanged, no phantom entity ids above the roster size. |
| B6 | `CombatFeed` | depends on B2/B4. Verify: `DMG n KILLS n` still increments, health bars still appear. |
| B7 | `EspDebugText` | read-only over everything; last, and its own output is the diff. |

### Phase C — view

| # | step | why here |
| --- | --- | --- |
| C1 | **`EspProjector`** | **first**, because it collapses the 9-argument `project()` into a 3-argument one *before* the painters are extracted — otherwise every painter would be written against the wide signature and rewritten in C3–C5. Touches only `onDraw`'s first 80 lines plus `project()`/`refreshViewport()`/`viewportHint()`. Verify: `calibHint()` still reads ~`+0.00,+0.00` on a target you are aimed at, and `viewportHint()` still says `exact` or `INSET-CORRECTED` as before. |
| C2 | `EspSnapshot` | the data holder. Touches both `update()` and `onDraw` in one diff, but it is a pure field rename (`x` → `snap.x`) and the compiler finds every site. Do the local-hoisting (§2.2) in this same step. |
| C3 | `EspRadarPainter` | smallest, most independent painter; a cheap confidence check that the C1+C2 plumbing is right. |
| C4 | `EspBoxPainter` | the bulk of `onDraw`. Verify box geometry, health bar colour ramp, label text, pose rays. |
| C5 | `EspAimController` | depends on C1/C2. Verify lock stickiness and the injected swipe direction (`AIM_SWIPE_INVERT` behaviour is sign-sensitive; a flipped sign here is the aim equivalent of the SIGN TRAP). |
| C6 | `EspSnapshotBuilder` | extract `update()` last among the workers, once the snapshot shape is settled. Verify dead reckoning (boxes track a running target) and render smoothing (no 198 ms sawtooth). |
| C7 | `EspDebugLines` | read-only; last. Verify every line of the debug panel against a screenshot taken before Phase C. |

### Recommended checkpoint

Take a screenshot of the full debug panel *and* a short screen recording of live boxes
on a moving target **before A1**, and diff against the same after B7 and after C7. The
panel is 12 lines of derived state and is a far better regression test than reading the
diff — `ka ok/bad`, `ENT n live`, `TEAM own=/known=`, `LEAD (echo)`, `CAMX applied=`,
`VP ... exact`, and `near eN ... scr +0.00,+0.00` between them cover the keepalive
parse, the chain parse, friend/foe, the lag estimator, the camera predictor, the
viewport model and the projection.

---

## PART 4 — Judgement calls, with the alternative

| # | call | recommendation | alternative (one line) |
| --- | --- | --- | --- |
| 1 | Own-state volatiles: holder object vs staying on the facade | **Holder** (`OwnStateTracker`), reached through a `final` field — `final` gives safe publication, per-field `volatile` is unchanged | Leave them on `EspEngine` and give a `KeepaliveParser` a back-reference — smaller diff, but the facade keeps a 20-field mutable state block and gains nothing. |
| 2 | `Track`: nested vs top-level | **Nested, unmoved** — `EspEngine.Track` is the published name | Promote to top-level `Track` and fix ~4 imports/javadoc refs; no benefit. |
| 3 | View config fields: move to `EspConfig` | **No** — 204 refs across 8 files, and `EspTuning` binds them to preference keys | Move them and do a mechanical sweep in one dedicated commit *before* Phase C, so the rename never mixes with a structural diff. |
| 4 | Snapshot: mutable holder vs value object | **Single mutable preallocated `EspSnapshot`**, with arrays hoisted to locals in draw loops | Keep the arrays as `EspRenderView` fields and pass `this` to the painters — zero indirection, but the painters need package-private access to ~25 view fields, which is the god-object again. |
| 5 | `resetMatch()`: in `MatchBoundary` vs the facade | **Facade** — it is the single fan-out point across six collaborators | Put it in `MatchBoundary` and give that class references to all six; couples a small state holder to everything. |
| 6 | `updateTrack`'s trailing `classify` + `refreshOwnFromEcho` | **Caller does it** — `TrackStore.update()` returns the `Track`, `EntityChainParser` makes the two calls in the same order | Give `TrackStore` references to `TeamClassifier` and `OwnStateTracker`; fewer call-site edits, but `TrackStore` stops being a leaf. |
| 7 | `aim*` result fields: move to `EspAimController` or keep public on the view | **Move, keep `volatile`** — a repo-wide grep shows no external reader | Keep `public volatile` delegating copies on `EspRenderView` and assign them once per frame; costs 7 primitive stores, immune to a missed reference. |
| 8 | `parseStructured`'s 13 per-packet arrays | **Leave them** — preallocating would make the parser stateful and therefore unsafe across the concurrent recv threads | Preallocate at `MAX_CHAIN_RECORDS` *and* make `EntityChainParser` per-session rather than per-engine; a real change, raise it separately. |
| 9 | Fix the stale `1670` comment on `EspRenderView.UNITS_PER_METER` (565–574) | **Not in this refactor** — it is a one-line comment fix that deserves its own reviewable commit | Fix it in Phase C; it will be invisible inside a 1300-line structural diff. |

---

## PART 5 — Cost checklist (use as a review gate)

Per-**frame** (up to 120 Hz), in `update()` or `onDraw()`:

- [ ] no `new` anywhere reachable from `onDraw` — including `Paint`, arrays, `PointF`,
      `String`, `StringBuilder`, autoboxing, varargs, enhanced-for over a collection
- [ ] `project()` still writes scratch fields, still takes only `(x, y, z)`
- [ ] `dirScratch` and `locScratch` are still fields
- [ ] `labelBuf` still uses the `CharSequence` `drawText` overload
- [ ] `String.format` appears in `EspDebugLines` and `EspProjector.viewportHint()`
      only, and neither is called from a draw path
- [ ] snapshot arrays hoisted to locals in the box, radar and aim loops
- [ ] `EspEngine` is imported by exactly one new view class (`EspSnapshotBuilder`)

Per-**packet** (~5 Hz per entity, plus a 99 ms keepalive):

- [ ] `observeKeepalive`'s allocation profile unchanged (`varints()`'s `long[32]` +
      copy, and nothing else)
- [ ] `parseStructured`'s 13 arrays per packet — unchanged, not multiplied
- [ ] `updateCalibReadout()` still called on every 10th keepalive, not more often
- [ ] no `synchronized`, `Atomic*`, `Lock` or `ThreadLocal` introduced anywhere
- [ ] every field modifier copied verbatim — no `volatile` added, none removed

Invariant comments (grep for each string after the split; each must be present exactly
once, adjacent to the code it governs):

- [ ] `SIGN TRAP` — in `EspProjector`, between the `rX = -fZ` line and the `xSign` line
- [ ] `the width CANCELS` / `HOR+ aspect model` — both in `EspProjector`
- [ ] `Do not clamp below this` / `smoothing ... measured` / `destroyed the correlation
      analysis twice` — all three in `TrackStore`
- [ ] `a sentinel only works if EVERY reader agrees on it` — cross-referenced between
      `MatchBoundary` and `EspEngine.resetMatch()`
- [ ] `only a server-published team byte may ever produce blue` — in `TeamClassifier`,
      inside `classify()`
