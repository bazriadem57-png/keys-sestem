# Combat, health and the hit zone — field layouts

Derived from `libil2cpp.so` plus three live Training-Ground captures with the session
key read from the running process, validated against on-screen HUD readings.
Evidence pcaps: `FF-RE/pcaps/pri{1,2,3}.pcap`. Decoders: `tools/pri.py`,
`tools/corr.py`, `tools/ffpcap.py`.

| capture | SECRET_KEY | HEAD_SECRET | pkts |
|---|---|---|---|
| pri1 | `8bda44e7b7f57ea58ad684513f58d29f` | `[0,3,4,1,2]` | 7 709 |
| pri2 | `9b70d7d7924731e3968df0ddb6c852cd` | `[0,4,1,3,2]` | 18 020 |
| pri3 | `3a48ac4d96f76aad036a2de9bd70c9ad` | `[3,1,2,4,0]` | 13 349 |

TEA decrypt 100% on all three.

---

## 0. The body reader settles the encoding question for every message

`GCommon.FastBinaryReader`:

| method | behaviour |
|---|---|
| `ReadUInt32/16/64` | **plain** LEB128 varint |
| `ReadInt32/16/64` | varint then `(x>>1)^-(x&1)` — **zigzag** |
| `ReadSingle` | plain varint, bits reinterpreted — **float32 is a varint bit pattern** |
| `ReadByte` | **1 raw byte**, not a varint |
| `ReadFixUInt16` | **2 raw LE bytes**, not a varint |

**Every scalar is exactly one varint** (float and int64 included) — type changes
interpretation, never length. **Strings are `[zigzag varint byte-length][UTF-8]`**
(confirmed n=97, including multi-byte names).

**Field test with no symbols: if a field's non-zero values are all even over hundreds
of samples, it is zigzag.**

---

## 1. Cmd 1900 `RUDP_VAR_SYNC_PRI_DATA` — health, armour, weapon

Authority: `GCommon.ReplicationDataPool::SyncReplicationData` @ `0x082B8D4C`.

```
body   := group+
group  := varint  ownerReplicationId
          u16 LE  blockLen        <- ReadFixUInt16: 2 RAW bytes, NOT a varint
          record*                 <- exactly blockLen bytes
record := u8      varId           <- ReadByte: 1 RAW byte, NOT a varint
          varint  value
```

Cmd 1901 `RUDP_VAR_SYNC_GRI_DATA` is byte-identical **minus** `ownerReplicationId`.

**6 709 / 6 709 packets parse with exact byte consumption and zero residue** across
three sessions, plus 46/46 for 1901 and 56/56 on the `ff2.pcap` BR match. Unknown
`varId`s are skipped as exactly one varint, so a decoder never desyncs.

### Fields that matter

| id | name | encoding | status |
|---|---|---|---|
| **0** | `EPRI_PLAYER_CUR_HP` | plain, HP | **CONFIRMED n=20** against HUD screenshots over 40 s, covering damage drops and regen ticks |
| 1 | `EPRI_PLAYER_MAX_HP` | plain | CONFIRMED — only 9 values ever (200/300/500/…/1500) |
| **2** | `VEST_DURABILITY` | **`(itemId << 32) \| durability`** | CONFIRMED — lo32 ∈ 0…225 over 1 215 samples, 0 outliers; drops with damage events |
| 3 | `HELMET_DURABILITY` | same packing | PLAUSIBLE — 438/503; the other 65 hold a float |
| **4** | `ITEM_ON_HAND` | **`(inventoryItemId << 32) \| weaponId`** | CONFIRMED — lo32 == `zigzag(Cmd2010.v2)` in 1 000/1 065. **lo32 is NOT ammo** |
| 21 | `FIRING_STATUS` | plain {0,1,2} | CONFIRMED n=2 159 |
| 31 | `TOTAL_DAMAGE` | plain | CONFIRMED — strictly monotonic per player |
| 6/7 | `CUR_EP` / `MAX_EP` | plain | |
| 83/150 | armour modifiers | **float32 bit pattern** | `1067030938` = 1.20f |

### ownerReplicationId ↔ entity handle — NOT derivable, must be learned

`ownerReplicationId` is an arbitrary server-assigned int, **unrelated** to the ESP
handle `(team<<24)|id`. Two validated bindings:

1. **From damage** — for an HP drop of Δ on owner *O*, find a Cmd 2010 within ±0.25 s
   with `v5 == Δ`; its `v0` is *O*'s handle. 98.2% purity (588/599), 16/16 owners.
2. **From equipment (ship this one)** — match a var-4 change against a Cmd 121 within
   ±0.35 s whose item id equals var4's hi32. Agrees with (1) on **13/13**, zero
   disagreements, and covers **more** entities (18 vs 16) — and needs no combat.

> Cmd **1902** `RUDP_VAR_SYNC_PRI_MSG` (the typed/initial variant) never appeared in
> any capture, and its handler is one of the methods encrypted-at-rest in the APK.
> It is not needed to parse 1900 — all values are one varint regardless.

---

## 2. THE HIT ZONE — it exists, in Cmd 106 and Cmd 168

**`Cmd 106.v7` and `Cmd 168.v3` carry a hit zone ∈ {0,1,2,3}.** Mean damage for the
*same weapon*, grouped by zone:

| weapon | zone 1 | zone 2 | zone 3 | zone 0 |
|---|---|---|---|---|
| 30 | **43.9** | 16.6 | 10.8 | — |
| 42040 (fist) | **92.0** | 21.8 | 18.5 | — |
| 14 | **52.5** | 20.5 | 22.5 | — |
| 36 | **202–213** | 69.0 | 100 | — |
| 18 | **262** | 54–59 | 58.5 | — |
| 61 (hazard) | — | — | — | 6–9 |

Consistent across every weapon: **1 = head (≈2.6–4.2× body), 2 = torso, 3 = limb,
0 = non-directional (hazard/explosive)**. The kill feed independently prints
"Headshot" for zone-1 kills. **PLAUSIBLE, not confirmed** — cells are small; a
controlled head-vs-body test with a firearm would close it.

**To detect headshots you must read Cmd 106 or 168. Cmd 2010 does not carry the zone,
and damage magnitude alone is not sufficient.**

---

## 3. Cmd 2010 `UDP_PLAYER_HURT` — the authoritative damage feed

Always exactly **8 varints, 1 075/1 075**.

| idx | meaning | encoding |
|---|---|---|
| v0 | **victim handle** | plain `(team<<24)\|id` |
| v1 | **attacker handle** | plain |
| v2 | weapon / damage source | **zigzag** — equals attacker's `ITEM_ON_HAND.lo32` |
| v3 | server tick | **zigzag** |
| v4 | same field as `106.v3` | plain — **UNDETERMINED**, not armour absorption |
| **v5** | **DAMAGE in HP** | plain — CONFIRMED, 628 matches vs 4 and 6 for next-best |
| v6 | flag | 0 in 1 067/1 075 |
| v7 | — | always 0 |

## 4. Cmd 106 `RUDP_TAKE_DAMAGE` — operand order is REVERSED vs 2010

`[attacker][victim][damage][=2010.v4][weaponId zigzag][0][flag][**hitZone**]`

## 5. Cmd 168 `RUDP_SHOW_DAMAGE`

`[attacker][victim][damage][hitZone][weaponId][0]×7[zigzag strLen][UTF-8 icon]`
— e.g. `"UI_icon_kunai"`.

## 6. Cmd 107 `RUDP_DEAD`

`[victim handle][killer handle][string KILLER name][weaponId][hitZone]…`

**The name after the two handles is the KILLER's — 97/97 (100%)**, vs 29/97 if read as
the victim. Verified on multi-byte names. The tail carries a second name
(kill-feed payload) and is UNDETERMINED.

## 7. Cmd 104/105 `START_FIRE`/`STOP_FIRE` — negative result

```
OUT: 8 varints [handle][v1..v7]      IN: 3 varints [handle][0][0]
```

**There is no shot origin and no direction vector — CONFIRMED.** The whole OUT
message is 11–14 bytes and with fists every field after the handle is zero; there is
no room for a 3-vector and none appears. **Shot geometry must come from the aim
fields in Cmd 2001/2012, not from the fire events.** `v1` recurs per burst and lands
in the weapon-id space (PLAUSIBLE).

## 8. Supporting

| Cmd | layout | status |
|---|---|---|
| 133 `START_RELOAD` | `[handle][float32 seconds][0][0]` | CONFIRMED n=859 — decodes to 0.80…2.375 s, plausible reload times |
| 134 `STOP_RELOAD` | `[handle][zigzag v1]` | PLAUSIBLE |
| **121** `EQUIPMENT_CHANGED` | `[handle][slot][itemId]…` | n=1 856 — **the cheap weapon-id source and the best replicationId↔handle binder** |
| 124 `ATTACHMENT_CHANGED` | `[handle][slot][weaponItemId][attach]×4` | n=326 |
| **135** `SYNC_PLAYERS_VISIBILITY` | **one 64-bit varint, nothing else** | CONFIRMED n=58. A bitmask, sense appears **inverted**. Governs which entities you are told about — worth its own experiment |
| 1109 `ENEMY_HIT_NOTIFY` | 4 varints | UNDETERMINED — 0 occurrences |

---

## Corrections to existing docs

1. `PROTOCOL_MASTER.md` §5's "IN damage feed" **is Cmd 2010 `UDP_PLAYER_HURT`** — now
   named, not inferred from byte shapes.
2. **§5's tick is wrong by 2×.** `v3` is **zigzag**, so the real server tick is
   **33.008 ms / 30.30 Hz**, not 16.5 ms / 60.6 Hz.
3. §5's v2 "damage source" is **zigzag** and equals the attacker's held weapon
   (`ITEM_ON_HAND & 0xFFFFFFFF`), provable per event.
4. `tools/ffdecode.py`'s capture reader cannot read `tcpdump -i any` output
   (LINKTYPE_LINUX_SLL2 = 276). Use `tools/ffpcap.py`.
5. **The aim vector: BOTH "v13-v15" and "v14-v16" are correct — they use different
   index origins.** This is a trap; read it before touching any body index.

   | convention | where index 0 is | varint count | unit aim triple |
   |---|---|---|---|
   | **body** (what the code uses) | after skipping the object handle | **23** | **v13, v14, v15** |
   | **wire** | at byte 8, handle included | **24** | v14, v15, v16 |

   Measured 18 600/18 600 keepalives across four captures: `|f32(v13),f32(v14),f32(v15)|
   = 1.000` under **body** indexing. `EspEngine.observeKeepalive` skips the handle first,
   so its `v[13..15]` is right; this document's earlier "v14..v16" was counting from
   byte 8, so it was right too. **`v18` in the code is the 20th varint on the wire.**
   Get this wrong and you rewrite `v17` or `v19`.

   This also retires a lingering doubt about the aim-bias disproof: `AimBias` parsed
   from byte 8 (wire convention) and locked index **14** — the correct field. It was
   rewriting the real aim vector and the server still ignored it. The negative stands.

---

## 9. Hit timing, and a decisive negative on server-side rewind

Measured over four full-payload captures (18 600 keepalives, 1 510 damage events).

### The fire -> confirm delay is exactly one RTT, and it tracks the session

Method: identify own handle from the keepalive, keep inbound damage events whose
attacker is us, cluster into bursts at a 400 ms gap, measure the lag back to the
preceding outbound control packet (34 B — `RUDP_START_FIRE`'s 8 varints padded to one
24 B ciphertext payload).

| capture | lag p50 | n | session RTT p50 | `v18` p50 |
|---|---|---|---|---|
| 155351 | **290 ms** (σ 3.9) | 6 | 283 | 287 |
| 161940 | **271 ms** | 22 | 263 | 267 |
| 225854 | **282 ms** | 11 | 276 | 281 |

Against a +20 s time-shifted control the peak bin holds 6/8, 13/23 and 8/16 of our
bursts versus **0/5, 0/18, 0/5** for the control, and 12%, 1.2%, 5.2% for damage dealt
by other players. The peak moves with the session's RTT.

> **Caveat:** the 34 B signature did **not** reproduce in `capture_raw_20260911_104112`
> (BR-style lobby) — lags flat from 122-497 ms. Do not assume it generalises across
> modes; that is the same class of assumption that cost this project a whole feature
> (`PROTOCOL_MASTER.md` §4.1).

### `Cmd 2010.v3` is an emission stamp, not a rewound view time — CONFIRMED NEGATIVE

Built the absolute server clock from the inbound len-13 family (**also zigzag**: raw
slope 2.0000 units/ms; linear fit 1.00000, residual σ 8.3-38.1 ms), then compared each
damage event's `zz(v3) × 33.008 ms` against it, **split by attacker**:

| capture | attackers | per-attacker median offset spread | all-events σ |
|---|---|---|---|
| 161940 | 8 | −3.0 … +1.1 ms | 11.4 ms |
| 225854 | 10 | −2.4 … +8.8 ms | 12.8 ms |
| 155351 | 8 | −4.6 … +5.7 ms | 12.8 ms |

Different shooters have different RTTs. If `v3` carried the *rewound* resolution time
their offsets would diverge by tens to hundreds of ms. **They agree within ±10 ms
across 26 attacker-sessions.** `v3` is stamped at emission on one shared server clock
and carries no rewind information.

### Why the lag alone can never settle rewind vs receive-time

A server resolving at receive time replies at `t_fire + RTT`. A server rewinding to
your view time **also** replies at `t_fire + RTT` — rewinding changes *where* the
targets are, not *when* the answer comes back. And "lag varies with reported RTT" is
not a discriminator either: in every capture we own, `v18` and true RTT are collinear
to ±4 ms. Only an experiment that **breaks that collinearity** — inflating `v18` while
leaving the network path untouched — can separate them.

### The two client-controllable time fields, and nothing else

`v19` and `v21` are **0 in 18 600/18 600** (dead). `v16`/`v17` carry a single constant
during one episode each and are zero otherwise — incompatible with a delay field. So
**the only time fields in the outbound body are `v18` (client-asserted RTT, range
253-580 ms observed) and `v22` (wall-clock ms, +99/packet)**. Any interpolation delay,
if sent at all, is in the encrypted stream.

Two liveness pairs, re-measured:
- **Server ping -> our pong** (IN 11 B / OUT 10 B, 0.505 Hz): byte-for-byte echo
  **852/852**, our reply latency p50 **13-28 ms**. This is the *only* path by which the
  server can measure our RTT. We control exactly one thing: when we answer.
- **Our probe -> server ack** (OUT 16-19 B, 1.017 Hz): exact-timestamp echo
  **1 975/1 988 = 99.35%**. **The timestamp is zigzag at 2 units/ms** — the earlier
  "first varint is a ms clock" was off by 2×, which matters if it is ever rewritten.
  `probe_varint0/2 − v22` is constant to σ ≈ 28 ms, so the probe clock and `v22` are
  **the same client clock**; desynchronising them would create a signature absent from
  all 18 600 real packets.
