# The feature (plugin) system

**2026-09-16.** Every capability is a `Feature` that declares its own settings.
The settings screen, the load/save wiring and the reset behaviour are all
derived from that declaration instead of being written per feature.

Research behind it: `docs/PLUGIN_ARCHITECTURE_RESEARCH.md`.
What it has to absorb: `docs/SETTINGS_INVENTORY.md`.

---

## 1. Why

A setting used to be declared in **four places**: a key string in `Prefs`, a
mutable `public static` on its consumer, a load line in `EspTuning`, and a
hand-written row in a panel or layout. Adding one meant touching all four — and
**34 of the 99 keys had drifted**, saved somewhere and loaded nowhere. Nothing
fails at compile time when that happens.

One declaration now produces all four.

## 2. What was borrowed, and what was not

**DeepSeek Harness** (<https://github.com/deepseek-ai/deepseek-harness>,
created 2026-08-13 — *"Everything is a Plugin"*) is real, and it post-dates my
training data, so everything about it here came from reading it. It is a
Node/TypeScript agent runtime, so **none of it is portable — only the design**.

Taken from it:

- **Presence, not value, means "the user chose this."** Its config resolves in
  layers (*schema default → base → user*), and a field counts as overridden by
  being *present* in the user layer. A flat `SharedPreferences` file cannot
  otherwise distinguish "the user chose false" from "the default was false and
  got written out" — so correcting a bad default in code would never reach
  anyone who had ever opened the panel. Here: `prefs.contains(key)`, and reset
  is `remove(key)`.
- **`applies: live | restart`**, so the UI can say a change is not in effect
  yet instead of quietly lying.
- **`validate` kept deliberately out of the schema**, because the schema is
  also what the settings surface renders.

Taken from **Forge's `ForgeConfigSpec`**: the fluent builder with sticky
sections and `defineInRange`, producing typed handles the owner keeps in a
field — no annotations, no reflection.

Taken from **OBS**: a toolkit-independent property description that a renderer
walks, and **dependent fields resolved imperatively**. This is the part
declarative systems reliably get wrong — VS Code's schema cannot express
`dependsOn`, so its fields stay visible and editable while doing nothing.

Taken from **Home Assistant**: a per-feature `schemaVersion` + `migrate`.

**Rejected from DeepSeek**: the Fiber state machine
(`PENDING→LOADING→ACTIVE→FAILED`), reversible effects, and 5-layer config
composition. Those exist for out-of-tree hot-reloadable plugins. We ship one
APK of features the same author wrote — and that runtime's own docs note a
stuck plugin *"prints nothing — no crash, no partial run — exits 0 silently"*,
which is precisely this codebase's recurring failure. Lifecycle here is
`onEnable` / `onDisable`, and every refusal is a `Diag.hit`.

## 3. The shape

```
config/plugin/            depends on NOTHING
  Refs          BoolRef / FloatRef / IntRef / StringRef
  Setting       Bool | Num | Int | Choice   — descriptor + binding, no storage
  SpecBuilder   fluent declaration
  Feature       id, schemaVersion, migrate, enabledSetting,
                defineSettings, validate, onSettingsChanged,
                onEnable, onDisable
  Features      registry: install / loadAll / commit / reset / setEnabled

features/                 depends on ui/, esp/, filter/
  Registry      THE ARRAY — the whole index, one screen
  EspFeature  RadarFeature  MountedCameraFeature
  FilterFeature (×3: ghost, freeze, teleport)  CaptureFeature

ui/panel/SettingsRenderer  walks a Feature's settings, emits rows
```

`config/plugin` never names a feature: `Features.install(ctx, Feature[])` takes
the array as an argument. That is what keeps `config/` dependency-free and
keeps the `esp/ → ui/` edge removed.

## 4. The two decisions that matter

### A setting owns no value

It holds a **reference** to the plain `static` that already exists:

```java
b.bool(Prefs.KEY_ESP_BOXES, "ESP", true, new Refs.BoolRef() {
    public boolean get() { return EspRenderView.SHOW_BOXES; }
    public void set(boolean v) { EspRenderView.SHOW_BOXES = v; }
});
```

`onDraw` runs at **120 Hz** and `classify()` once per entity per packet. A map
lookup, an autobox or an interface dispatch there is real cost for nothing —
and 120 fps is an 8 ms budget where overrunning by 1 ms drops the whole frame.
So the `Setting` is touched on exactly two cold paths, load/save and drawing a
row, and **the hot path keeps doing the plain field load it does today**.

This also makes the migration incremental: storage does not move, so the
renderer needed no edit at all.

### Discovery is a hand-written array

Not `ServiceLoader`, not annotation processing, not reflection:

- `ServiceLoader` on Android reads `META-INF/services` at runtime — one
  documented case took a library's init from **250 ms to 500 ms** — and its
  entries are fragile under shrinking.
- Annotation processing adds a new class of silent build failure to a build
  whose existing failure mode is already *"it looked like it worked, check the
  APK timestamp"*.
- Reflection costs ~350 ns per read, **breaks under `minifyEnabled true`**, and
  turns 99 greppable key constants into invisible metadata — directly against
  the "grep every reader" rule that exists because ignoring it caused four
  bugs in one session.

An array is compile-checked, free at startup, R8-safe, and readable in one
screen.

## 5. Rules for adding a feature

1. Implement `Feature`, add one line to `features/Registry.build()`.
2. **Name an existing `Prefs.KEY_*` constant, verbatim.** Never derive a key
   from a field or class name.
3. Bump `schemaVersion` only when a stored value's **meaning** changes under an
   unchanged key — not when adding a setting. (`KEY_ESP_FOV_X` is the worked
   example; its ad-hoc `KEY_ESP_CAM_SCHEMA` marker is what this generalises.)
4. One `dependsOn` gate in the schema; anything harder goes in `validate`.
5. Every bail gets a `Diag.hit`, never a `DevLogger` call.
6. When a key moves into a `Feature`, **delete its line from `EspTuning.load`**
   — do not leave both.

## 5b. The migration is HALF DONE, and that is the dangerous state

A reachability trace found the plugin system's entire **write** path
unreachable: `ui/panel/SettingsRenderer` has zero callers, and it is the only
caller of `Features.commit/reset/resetAll/setEnabled/isOverridden`,
`Feature.validate`, `onEnable`, `onDisable`, `Setting.save/reset/display`.
About 1,200 lines currently buy ~13 duplicate `getBoolean`/`getFloat` calls at
startup.

**That overlap already caused live data loss.** Four `Feature` declarations
re-decided values `EspTuning` owned, with narrower ranges, and
`Setting.Num.load` clamps on every launch — a saved 4000 m radar ceiling came
back as 500 m every start, and the tune panel then wrote the clamped value
back. Fixed in `020d165` by sourcing `EspTuning`'s constants, but the shape
that allowed it is still there.

**Decide one way or the other. Leaving it here is the worst option:**

- **Finish** — migrate the remaining ~82 settings, delete `EspTuning.load`
  and its 72 write-through setters, point `EspTunePanel` at
  `SettingsRenderer`. Roughly **−920 lines** and one declaration per setting.
- **Revert** — delete `config/plugin/` (744), `features/` (464),
  `SettingsRenderer` (291). **−1,499 lines**, and the divergence class goes
  with it.

Until then: **a `Feature` must never state a range or default of its own.**
Source them from `EspTuning`'s constants, as `RadarFeature` and `EspFeature`
now do.

## 6. Migration status

| feature | settings declared | old load line removed |
|---|---|---|
| ESP | 10 | not yet |
| Radar | 3 | not yet |
| Vehicle camera | 1 | not yet |
| Ghost / Freeze / Teleport | 1 each | n/a |
| Capture | 0 (no switch, by design) | n/a |

`EspTuning.load` and the registry run in that order, **registry last**, so a
migrated setting wins. The overlap is deliberate: the build stays green
throughout rather than needing one 99-setting flag day.

Remaining: ~80 settings, the aim block being the largest. The tune panel still
renders its own rows; pointing it at `SettingsRenderer` is what retires
`EspTunePanel`'s hand-written section.

## 7. Why the unused SpecBuilder/Features API is still here

`SpecBuilder.independent/restart/live/integer/choice`, `Features.all/settings/
resetAll`, `Registry.*Available/espOn` and `SettingsRenderer.view` are
unreferenced. The 2026-09-16 dead-code sweep deleted 133 other unreferenced
methods and deliberately left these: they are the write half of the migration
above, and deleting them would quietly decide "revert" on the owner's behalf.
They come out with `config/plugin/` if that is the call, and they get callers
if it is not.
