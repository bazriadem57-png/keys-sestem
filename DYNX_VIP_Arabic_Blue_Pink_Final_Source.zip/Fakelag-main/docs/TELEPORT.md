# Teleport — measured mechanics and design

Everything here was computed over 229 raw captures (20 with full payloads), using
the self-echo as ground truth for what the server believes. Working set: 63,940
own-keepalive steps, 27,213 self-echo residual samples, 30,084 labelled outbound
DROPs, 52 labelled filter-release events, 2,952 liveness probes.

**Headline: teleport is a DISTANCE BUDGET problem, not a timing problem. You never
need to drop a packet — you rewrite the position and walk the server's belief.**

---

## 1. The acceptance rule — measured, with perfect separation

For each of 52 release events (a run of ≥4 dropped keepalives followed by a PASS),
the quantity that matters is the jump **the server sees**: the distance between the
first position reported after the outage and the server's last echoed position.

```
capture              t(s)     gap_m   nDrop    outcome
20260910_225854     223.0     12.90    133     REJECTED, snapped back +399 ms
20260910_222646      31.9      9.57     32     REJECTED, snapped back +401 ms
20260910_175549     191.5      5.31     14     REJECTED, snapped back +402 ms
20260910_225854     209.6      2.77     69     accepted
20260910_175208      98.5      2.20    252     accepted
20260911_104112     496.8      2.19    123     accepted
 ... 43 further events, all gap <= 1.89 m ...   accepted
```

- **Largest accepted jump: 2.77 m. Smallest rejected jump: 5.31 m.**
- Threshold lies in **(2.77, 5.31] m** — call it ~3–5 m.
- Probability of that split by chance: `1/C(52,3) = 4.5e-5`.

**It is NOT a speed check.** Implied speed over the outage for the three rejections
was 0.97, 2.93 and 4.58 m/s — *slower* than several accepted cases (one accepted at
13.47 m/s). The 13 s / 12.9 m rejection at 0.97 m/s is decisive: a perfectly
walkable average speed, rejected. **Distance from the server's held position is the
only discriminant.**

**Why normal play never trips it:** the server's belief is refreshed every 100 ms, so
the gap is always sub-metre. The client routinely reports **3.24 m per 100 ms tick at
p99** (falls, ziplines, vehicles) and the server accepts it — because at that moment
its belief is one tick old.

Acceptance is observable live: the echo adopts the new position within **0–472 ms**
on every accepted release.

**Rejection is directly visible, not inferred.** During the 225854 rejection the echo
read a constant 4.29 m from the anchor at +157/+355/+553 ms while our keepalives
reported 13.5–14.7 m away — the server never moved. In accepted cases the echo
re-locks to within 0.12–0.21 m.

---

## 2. Snap-back

**Definition that works:** a single ~100 ms step in our own OUTBOUND keepalive that
lands on the server's last echoed position.

- 63,940 steps; 1,121 exceed 2 m.
- Landing within 1.5 m of the last echo, by step size: 2–5 m → 5.1%; 5–10 m → 13.6%;
  **10–20 m → 85.7%; 20–50 m → 75.0%**.
- Time-shifted control (echo sampled +20 s later): **1.0%**.
- So at ≥10 m: **9/11 = 81.8% vs a 1.0% baseline.**

**Latency is a hard constant: 399, 401, 402 ms** across three independent sessions
(spread 3 ms) — approximately one round trip (measured probe RTT 239–287 ms). Exactly
4 keepalives are passed reporting the rejected position before the correction lands.

### Distinguishing a snap-back from an accepted move

1. **The echo does not follow.** Accepted: echo reaches the new position ≤472 ms,
   residual returns to ~0.2 m. Rejected: echo stays pinned within 0.02 m of the anchor
   across 3+ ticks.
2. **Velocity/position incoherence.** The keepalive's `v8,v9,v10` triple matches the
   *next* tick's displacement with median ratio **1.010**, and 1.006–1.045 for every
   band from 0.2 to 5 m/tick (n = 24,894). In the 5–20 m band the ratio collapses to
   **0.054**, and above 20 m to **0.000** — position moved, declared velocity ≈ 0.
   **That shape never occurs in legitimate client traffic.** It is exactly what a
   naive position rewrite would emit on every packet, which is why velocity must be
   rewritten too.

**No server correction packet was identified.** Aggregate inbound in the 61 snap
windows is *lower* than control (0.70–0.76×), so there is no inbound burst. The
self-echo chain was PASSed in all three snap windows and was byte-identical across
consecutive ticks. **Any correction lives in the encrypted 10+8k channel.**

**One negative that constrains the mechanism:** during a 13 s ghost episode the client
received the echo saying "you are at A" ~66 times while locally 12.9 m away and did
**not** snap. It snapped 400 ms after we resumed sending. So the snap is **not**
standing reconciliation against the echo — it is triggered by the server *receiving* a
position it rejects.

---

## 3. The tick (v22) is not the problem

- Pooled Δtick over 27,143 consecutive keepalives: **+99 in 93.6%**, +98 in 854,
  +100 in 842. **0 / 27,143 non-positive steps.**
- Δtick / Δt_wall: p10 0.9802, p50 **0.9900**, p90 1.0102 → it is a wall-clock
  millisecond counter, not a packet counter.
- Across every DROP→PASS boundary (n = 27): **+99 in 26, +100 in 1.** Withholding
  produces exactly the same advance as sending. A 33.3 s outage produced Δtick = 33,561.
- There is no sequence number for the server to notice gaps: `b0` takes only **20
  distinct values** over 12–18k outbound packets (deltas 0/+1/−1 in roughly equal
  thirds — not a counter); `b1` is a 128-value nonce.

**The one place the tick matters is the opposite of the hypothesis.** GHOST replays a
byte-identical saved keepalive every 500 ms, so it re-sends a **stale, repeated tick**.
Any server de-duplicating on tick discards every replay. That never mattered because
liveness is carried by other families — but it is a strong argument for **rewriting
rather than replaying**: a rewritten keepalive carries a fresh monotonic tick and is
indistinguishable in the time domain.

---

## 4. What the current filters actually do

**30,084 outbound DROPs across 15 captures:**

| category | count | share |
|---|---|---|
| position keepalive | 4,512 | 15.0% |
| encrypted input stream (`8+8k`, mostly 24 B) | 25,568 | **85.0%** |
| encrypted control channel (`10+8k`) | 4 | 0.013% |
| small plaintext liveness (9–20 B) | **0** | **0.00%** |

### GHOST does NOT drop heartbeats — the complaint was aimed at the wrong filter

Across **382 s of cumulative suppression windows** in 10 sessions:
- client timestamp probes replied to: **374/377 = 99.2%** inside vs 98.4% outside;
- server liveness pings answered: **191 pings → 191 pongs, ratio 1.000**.

Zero degradation. Ghost's windows never intersect the 9–20 B liveness families.

### TELE is exactly inverted, and this is why teleport fails

- `PacketClassifier.classify` → `TYPE_MOVE` only for the **learned** signature, and
  `MOVE_MIN_LEN/MAX_LEN = 21/40`. The learned `moveLen` is **24** in all 10 sessions —
  that is the *encrypted input stream*, not the position channel.
- `DefaultFilterEngine.reclassifyFire` then re-labels **every 21–54 B packet** as
  `TYPE_FIRE`, also HELD → in outbound terms, the encrypted **control/RPC** channel.
- The 56–67 B position keepalive matches neither, so after the ~6–12 s learning window
  it is **PASSED**.
- Empirical: the only **9 HOLD rows in all 229 captures** are 26 B and 34 B control
  packets. Not one keepalive was ever held.
- The pre-learning fallback (55–160 B) *does* hold the keepalive, which is why teleport
  may have appeared to work for the first few seconds and then stopped.
- On release, `ReplayEngine.TeleReplayRunnable` replays every buffered packet at
  1–50 ms spacing — **the entire walked path compressed 20–100×**. That is not a
  teleport, it is a speedrun of the path, every packet an oversized delta.

### FREEZE does not withhold position at all

`FreezeFilter.onOutbound` returns `PASS` unconditionally. Sessions 161940/205046/
221243/222258 show FREEZE OUT PASS 42/197/99/43 and **OUT DROP 0**. It is an
inbound-only visual effect. `PROTOCOL_MASTER` §8 describing freeze as withholding
position is **stale relative to the shipped code**.

---

## 5. Outbound family inventory

Unaccounted residue is 0.00–0.02% in every session.

| family | shape | rate | withhold? |
|---|---|---|---|
| **POSITION KEEPALIVE** | plaintext, `b9=b10=0x80`, body exactly 23 varints, **48–67 B** | ~10 Hz, tick +99 | **YES — the only lever** |
| **INPUT STREAM** | ECB `len = 8+8k` (24/32/40/48) | 12.6–45.9 Hz | safe but pointless — dropping it does not move the server's belief |
| **CONTROL / RPC** | ECB `len = 10+8k`, per-session channel id in b8:b9 | 0.02–0.5 Hz, bursty | **NO — never withhold** |
| **LIVENESS** | plaintext 9–20 B, two sub-families | 0.5 Hz and ~1 Hz | **NEVER** |

The liveness layer resolves into two request/response pairs:

**A. Server ping → client pong.** Inbound 11 B at 0.5 Hz carrying one varint stepping
by exactly **+60** (1,746/1,757 = 99.4%, strictly monotonic). The outbound 10 B reply
**echoes it byte-for-byte in 704/704 = 100.00%**, median latency 14–28 ms.

**B. Client probe → server ACK.** Outbound 16–19 B at ~1 Hz whose first varint is a ms
clock. **2,911/2,952 = 98.6%** get a reply within 800 ms (median 239–287 ms), and
**95.9%** echo the exact timestamp. The reverse never echoes (0/2,952) — the client is
unambiguously the requester.

---

## 6. Recommended design — rewrite, never drop

### Classification (replaces every length window)

```
POSITION  := b9==0x80 && b10==0x80 && (b8&0x80)!=0
             && varints(payload, bodyOffset(handle)) has exactly 23 elements
LIVENESS  := plen <= 20                       -> ALWAYS PASS
CONTROL   := plen >= 26 && (plen-10)%8 == 0   -> ALWAYS PASS
INPUT     := plen >= 24 && (plen-8)%8 == 0 && plen <= 64  -> ALWAYS PASS
```

This replaces `45..64`, `55..160` and `21..54`, all of which are wrong against the real
48–67 B length distribution. Do **not** use `GamePacketTaxonomy.family()` for drop
decisions — it keys off b2/b3, which are masked and rotated per session.

### The algorithm

```
ARM (user marks destination B; server belief = A):
    passthrough, record A from the self-echo

RAMP (10 Hz, one step per outbound keepalive):
    target_k = A + clamp(B - A, step_budget)
    rewrite v0,v1,v2   := zigzag(target_k)
    rewrite v8,v9,v10  := zigzag(target_k - target_{k-1})   # MUST match the step
    leave v22, v11, v12, v13-v15 untouched
    PASS the packet

FEEDBACK (from the inbound self-echo, already parsed by EspEngine):
    residual = |echo(t) - target(t - 230ms)|
    residual < 1.5 m for 2 consecutive echoes -> server keeping up, continue
    residual > 3 m -> HALT, hold target at last confirmed echo, wait for re-lock

LAND: when |target - B| < 0.5 m, stop rewriting, resume passthrough.
```

### Step budget

| budget | implied speed | 100 m in | justification |
|---|---|---|---|
| 1.2 m/tick | 12 m/s | 8.3 s | ≤ fastest observed real player (12.57 m/s) |
| **1.8 m/tick** | **18 m/s** | **5.6 s** | vehicle speed; 3.76% of *normal* steps already exceed it |
| 2.5 m/tick | 25 m/s | 4.0 s | still under both the 2.77 m accepted gap and the 3.24 m p99 normal step |

**Never exceed 2.77 m/tick** — the largest value observed to be accepted.

### Rewriting is length-preserving

Over 27,153 keepalives, the distance X can move while `zigzag(X)` keeps the same LEB128
byte width is **p50 707 m, p10 151 m** (dominant width triple (3,3,3) in 19,134). So for
≥90% of packets a 150 m displacement changes **no byte lengths** — the masked b2–b7
length field never needs touching. For the residue (minimum observed headroom 0.05 m at
a width boundary) either pad the varint non-canonically (LEB128 permits it; the game's
own records carry `8a 8a 00` = 1290) or skip that packet and re-plan 100 ms later.

### Why this beats the current design

- Nothing is ever withheld — the detection surface from *missing* traffic goes to zero.
- No replay, so no compressed path speedrun.
- Every packet carries a fresh monotonic tick.
- Velocity stays coherent, avoiding the one shape provably absent from real traffic.
- The snap-back cannot fire, because the gap never exceeds the threshold.

---

## 6b. BUILT — 2026-09-11

§6 is implemented as `filter/TeleportFilter` + `net/PositionSync`, wired to
`FilterKind.JITTER`. `JitterFilter`/`PacketClassifier`/`reclassifyFire` are no longer
in the outbound path.

Three states on one button: **press** = ANCHOR (report pinned, velocity 0), **press**
= RAMP (walk the belief to the live position at the step budget), **auto** = IDLE on
arrival, so the toggle light is the progress indicator.

Two corrections to §6's plan, both from measuring the real fields:

1. **Length-preserving padding cannot carry a teleport.** §6 assumed the p50 707 m
   width headroom made padding sufficient; that figure is for *position*, which is
   3 bytes in 96% of reports. The binding constraint is **velocity: 58% of those
   fields are one byte** (±63 units = ±0.066 m), which caps a ramp at a measured
   **1.15 m/s**. `PositionSync.rebuild` therefore re-encodes the body canonically and
   repairs `Length` via `HeaderLayout`. Canonical is also the *more* natural output —
   byte for byte what the game emits for those values.
2. **`v8,v9,v10` re-confirmed as next-tick displacement** independently here:
   ratio p50 **1.010**, n=11 949, matching §2 exactly.

**Offline proof, 41 sessions / 72 361 position reports:** 50 543 rewrites, **0
withheld**; 50543/50543 each for re-parses-as-23-varints, CRC7 valid, position reads
back as intended, velocity reads back as intended. Rebuild size delta p50 +1, max +4
bytes. Sustained ramp **25.0 m/s** at the 2.5 m default (tunable, hard cap 2.70).

**§8's MAC question is still open and this is the one real risk** — but the first
press is now that experiment: if a body integrity check exists, the position simply
will not move.

---

## 7. Bug fixes required regardless of teleport

1. ~~`GhostFilter` 45–64 window~~ — **FIXED 2026-09-11**, now uses
   `GamePacketTaxonomy.isPositionKeepalive` (shape test). It was leaking 10.9% of
   keepalives in session 225854 (65/66/67 B) and 1.2% in 155351.
2. ~~`DefaultFilterEngine.reclassifyFire` treating 21–54 B as FIRE-and-hold~~ →
   **DELETED 2026-09-11**, along with the replay catch-up path that depended on it.
3. ~~`PacketClassifier`'s 55–160 B pre-learning fallback~~ — **no longer reachable
   2026-09-11**; `PacketClassifier` survives only as a dev-capture label. Teleport
   identifies the channel by exact `Cmd 2001`, falling back to the shape test.
4. `GamePacketTaxonomy.family()` reading b2/b3 → stop using it for drop decisions.
4b. ~~`ctx.cmd` was set from CRC-**invalid** packets~~ — **FIXED 2026-09-11.**
   `PacketPipeline.observeAndParse` returns a packet whether or not the checksum
   validates (it feeds the solver's own failure backstop), and `PacketLoop` copied
   `cmd()` out of it unconditionally. Foreign UDP lands in the MsgKey range ~8% of
   the time, so a command id read out of an unrelated datagram could reach filters
   that treat `hasCmd()` as "exactly identified" and act on it — **ghost drops on
   it and teleport rewrites on it.** Now gated on `isCrcValid()`. Affects every
   filter, not just teleport.
5. `PROTOCOL_MASTER` §8 vs `FreezeFilter.onOutbound` — doc and code disagree.
6. ~~`toggle(FREEZE)` calling `stopIfActive(jitter)`~~ — **FIXED 2026-09-11.** It was
   the only cross-filter stop in the app and ghost was exempt, which is exactly the
   reported asymmetry ("ghost stays on, tele turns itself off"). Worse, it called
   `stop()` not `shutdown()`, firing the whole replay at an unintended moment.
7. ~~Stale queued tap re-applied~~ — **FIXED 2026-09-11.** A tap during a tunnel
   restart was queued, `broadcastState()` repainted the button OFF, the user pressed
   again, and that press drained the stale one in the same call chain — two presses,
   net zero. `drainPendingToggles` is now re-entrancy-guarded, the queue is
   synchronised (it was a bare `ArrayDeque` written from three threads), and taps
   older than 3 s are discarded.

---

## 8. THE GATING EXPERIMENT — do this before building anything

**Teleport has never been captured.** Across all 229 files there are **0 rows with
phase `JITTER`** and only 9 `HOLD` rows. Everything above is inferred from ghost
releases — same mechanism, never driven with intent.

**Is there a body integrity check (MAC)?** Nothing tests it: ghost only ever replayed
**byte-identical** packets, which would pass any MAC. The entire rewrite design rests
on this.

> **Test:** rewrite `v0` by **+1 unit** on one keepalive per second for 10 s. Watch the
> self-echo. If the echo tracks the offset, there is no body integrity check.
> Five minutes, and it gates everything else.

Other open questions, in priority order:

| unknown | experiment |
|---|---|
| Exact threshold in (2.77, 5.31] m | Ghost on, walk to a marked distance, release. Binary-search 3.0/3.5/4.0/4.5/5.0 m, 3 trials each, read accept/reject off the echo. ~15 trials. |
| Distance gate vs speed gate | Disable the 500 ms ghost replay so the reference interval is the whole outage, repeat the bracket. Unchanged threshold in metres ⇒ distance gate. |
| Does dropping the inbound self-echo suppress snap-back? | Ghost, walk 15 m, and at release drop inbound `b8==0` chains for 1 s. No snap at +400 ms ⇒ reconciliation is client-side, and a far more aggressive teleport becomes possible. **Highest value after the MAC test.** |
| What carries the correction | Repeat the 15 m rejection 20×, look for an inbound `10+8k` block0 value present in ≥19/20 pre-snap windows. The ECB codebook attack applies directly. |
| Must the input stream be rewritten too? | Rewrite only the keepalive and see whether the echo follows. Ghost data already suggests the keepalive is sole authority — holding it alone pinned the echo for 33.3 s with drift 0.00 m. |
