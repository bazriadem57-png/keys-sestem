# ESP Renderer — design as implemented

> **PARTIALLY SUPERSEDED.** Read [`PROJECT_STATE.md`](PROJECT_STATE.md) first.
>
> Since this was written: handedness was settled (`MIRROR_X = true`), the shoulder
> offset was measured (-0.70 m), dead reckoning and vsync rendering were added, the
> lead became measured rather than assumed (215 ms), and friend/foe was rewritten
> as a relational squad test. Treat the geometry here as sound and the constants as
> stale.


The render side of the ESP: full-screen Canvas overlay drawing enemy boxes
+ distance labels over the game, a radar-lite corner square, and a debug
calibration panel. Build dir `fakelag\fakelag-beta`, package
`com.fakelag.cryhard8`.

**Files:**
- `esp\OrientationProvider.java` — pluggable orientation (Full / Folded).
- `overlay\EspRenderView.java` — the Canvas renderer (boxes, labels, radar,
  all calibration constants).
- `overlay\EspOverlay.java` — window management: full-screen renderer window
  + toggleable debug panel, ~30 fps render loop.
- `FloatingOverlayService.java` — wiring only (provider now also supplies the
  live `EspEngine`).
- `esp\EspEngine.java` (decode side, varint schema) — supplies posX/posY/posZ,
  dirX/dirY/dirZ, and the `entities()` map (rewritten by the decode
  workstream; documented here only as the renderer's data contract).

---

## 1. Coordinate frames — all conversions live in ONE place

The game is **Unity, Y-up**. The engine's own-state decode gives:

| Engine field | Meaning |
|---|---|
| `posX()` | own horizontal axis 1 (varint v0) |
| `posY()` | own horizontal axis 2 (varint v2) |
| `posZ()` | own **height** (varint v1) |
| `dirX(), dirY(), dirZ()` | float32 unit view direction (v13/v14/v15); dirX along posX, dirZ along posY, dirY = height |
| `entities()` | map id → `Track{x, y, z}`; `x` pairs with posX, `y` with posY, `z` = height |

The renderer converts to world coordinates **only in
`EspRenderView.update()`**:

```
world (x, y, z) = (posX, posZ, posY)     // y-up: height slot in the middle
own:   (ownX, ownY, ownZ) = (posX, posZ, posY)
enemy: (wx,  wy,  wz)     = (t.x,  t.z,  t.y )  (after the axis map, §3)
```

## 2. Projection math (as implemented)

Per the approved design, with own position `p`, yaw `theta`, pitch `phi`:

```
f = (sin(theta)cos(phi), sin(phi), cos(theta)cos(phi))   // forward
r = f x up_world                                          // right  (up = (0,1,0))
u = r x f                                                 // up
V = [[ rT, -r·p ],
     [ uT, -u·p ],
     [ -fT,  f·p ],
     [ 0,   1   ]]
s = P · V · e          (enemy homogeneous position; draw iff s.w > 0)
```

Implementation note: `EspRenderView.onDraw()` evaluates `P·V·e` in
**factored form** instead of building matrices — algebraically identical,
no matrix scaffolding:

- basis built directly: `f`, `r = (-f.z, 0, f.x)`, `u = r x f` (then
  normalized; both are already unit when phi = 0),
- camera coords of `d = e - p` are `(d·r, d·u, d·f)`,
- **drawable iff clip w = d·f > NEAR_UNITS (30 u ≈ 13 cm)** — this is the
  `s.w > 0` test,
- screen: `x = cx ± (d·r)/(d·f)/tan(fovX/2) · (w/2)`,
  `y = cy − (d·u)/(d·f)/tan(fovY/2) · (h/2)` with `tan(fovY/2) =
  tan(fovX/2)·h/w` (square pixels).

Projection constants: **`FOV_X_DEG`** (default 90 — FF Max default; a
`public static volatile float` in `EspRenderView`), aspect from the actual
view dimensions. `MIRROR_X` flips the screen-x sign (world-handedness
calibration).

**Box drawing:** for each enemy, project the feet point (decoded enemy
height `t.z` when it passes a 0..65536 plausibility band, else own height)
and the head point (feet + 1.8 m = `1.8 × 236` units). The box spans the
two projections; width = `0.6 m` scaled by box height (`BOX_W_M/BOX_H_M`
× boxH). Red stroke (~1.5 dp) + faint red fill; label above the box:
`<distance m> e<entity id>`. Entities updated within 3 s are drawn (STALE_MS);
closer than 1 m is skipped (self-track filter); max 24 per frame.

**Radar-lite:** bottom-left 150 px square, self centered, world-x → radar
right, world-z → radar up; enemies within 100 m as dots (3 px), facing as
a green line from `theta`, 50 m range ring. `SHOW_RADAR` toggles it.

## 3. Axis-mapping configuration point (UNVERIFIED — calibrate live)

The varint decode established that enemy and own coordinates share the
same frame and units, so the **identity mapping is expected to be
correct** — but the axis correspondence was never verified against
in-game ground truth. All enemy-axis remapping lives in four `public
static volatile` flags in `EspRenderView`, applied **only** in
`update()`:

| Flag | Default | Meaning |
|---|---|---|
| `ENEMY_AXIS_SWAP` | `false` | swap the two enemy horizontal axes (t.x ↔ t.y) |
| `ENEMY_NEG_AXIS1` | `false` | negate enemy axis 1 (t.x) |
| `ENEMY_NEG_AXIS2` | `false` | negate enemy axis 2 (t.y) |
| `MIRROR_X` | `false` | mirror projected screen x |

Historical note: the pre-varint decode read own axes LITTLE-endian and
enemy axes BIG-endian from fixed offsets — both rigorously verified, the
oddity was real. The varint rewrite made the question moot (same
reader, same frame), but the flags remain as the calibration surface.

The debug panel prints the current mapping compactly
(`axisMapCode()`, e.g. `ID` or `SWAP,-A2,mir`).

## 4. Orientation: Full provider + Folded fallback

**Axis conventions now VERIFIED** (captures\REPORT_orientation_decode.md,
independent validation on the full-match + calibration captures):
- `yaw = atan2(dirX, dirZ)` — NON-FLIPPED (parachute drift converges on
  this yaw, never yaw+180; vehicle sprints are the only exception and
  free-look is normal there).
- `pitch = asin(dirY)` with **dy = +up** (falling → looking-down; engine
  clamps pitch to −40.00°/+85.00° — observed exact clamp values).
- v3/v4/v5 are the FOLDED **body/aim** direction (not the camera): they
  match movement heading while moving and the camera while firing — this
  resolves the old "frozen during camera-only" mystery (it was the body
  pair, not the view vector).

`esp\OrientationProvider.java` — `update(EspEngine)` / `yaw()` /
`pitch()` / `yawKnown()` / `source()`.

- **Full (primary):** from the decoded float32 unit direction vector:
  `yaw = atan2(dirX, dirZ)`, `pitch = asin(dirY)`. Validated per tick
  against |v| ≈ 1 (0.25 < |v|² < 4, NaN-safe) and keepalive freshness
  (< 1.5 s). Signed yaw AND pitch — no folding, no inference.
- **Folded (fallback, kept):** folds the direction magnitudes to
  [0°, 90°] (`atan2(|dx|, |dz|)`) and recovers the quadrant by correlating
  the four sign candidates against the own-position velocity (computed in
  the provider from successive posX/posY samples; movement shares the
  world frame with facing). Hysteresis: keep the current quadrant at
  alignment ≥ 0.55, switch only at ≥ 0.80. When still or strafing
  (velocity ⊥ facing), the last quadrant is held. Limitations: sustained
  backward running yields the opposite quadrant; pitch unavailable
  (assumes `PITCH_FALLBACK_RAD`, default 0).

`EspRenderView.update()` uses Full when `yawKnown()`, else Folded, and
reports the provenance in the debug panel (`src=full` / `src=hold:move`).

## 5. Debug panel (calibration tool)

Small monospace TextView window (top-left, below the buttons), polled at
500 ms: engine readout (`calibrationReadout()`: mask state, POS, DIR
yaw/pitch, ENT counts, per-entity lines) **plus** the renderer's
`statusLine()`:

```
VIEW fold=43.2° full=312.8° src=full pitch=-4.0° FOV=90° map=ID
ESP draw=3 radar=on
```

- `fold` = atan2(|dirX|, |dirZ|) — the folded view (cross-check).
- `full` = best-known full yaw (`?` when the fallback hasn't locked a
  quadrant), `src` = provenance (`full` / `fold:move|hold|init`).
- `map` = axis-mapping code (§3), `draw` = enemies drawn last frame.

Toggle with `EspOverlay.setDebugVisible(boolean)` (renderer keeps
running). The panel handles "engine off / no mask yet" gracefully (the
renderer simply draws nothing).

## 6. Performance & window contract

- Render loop: `Handler.postDelayed` chain at **33 ms (~30 fps)**; each
  tick snapshots engine state on the main thread (`update()`) then
  `invalidate()`. `onDraw` does no engine reads and no allocations (all
  paints/scratch preallocated; the only StringBuilder is reused).
- Windows: `TYPE_APPLICATION_OVERLAY` (TYPE_PHONE pre-26) with
  `FLAG_NOT_FOCUSABLE | FLAG_NOT_TOUCHABLE | FLAG_LAYOUT_IN_SCREEN`,
  translucent pixel format — no focus, no touch interception, no dim
  pass-through interference with the game. No new permissions.
- Additive only: freeze/ghost/jitter/capture, banner, crosshair, mask bar,
  dev popup untouched.

## 7. Known limitations

1. **Axis mapping unverified** (§3) — identity expected per the varint
   finding; calibrate once against the minimap.
2. **Enemy height (`t.z`) plausibility-gated, not verified** — if the
   third varint is not a height on some entity, the box floats/sinks;
   falls back to own height when outside 0..65536.
3. **Folded fallback limitations** (§4) — only active when the direction
   vector is missing/non-unit.
4. **FOV is a constant, not measured** — 90° default; calibrate per §8.
5. Pitch comes from the decoded direction vector (camera pitch) — boxes
   use it correctly, but during extreme pitch the head-point projection
   can fall behind the near clip (enemy then skipped).
6. Box width/height are game-independent constants (1.8 m / 0.6 m), not
   per-animation; ~236 units/m scale is the run-speed estimate.

## 8. In-game calibration procedure

1. **Axis mapping:** enter a match with the overlay on. Compare the radar
   dots (and box bearings) with the in-game minimap while rotating:
   - dots mirrored front/back → `ENEMY_NEG_AXIS2` (or A1);
   - dots rotated 90° → `ENEMY_AXIS_SWAP`;
   - boxes on the wrong side when turning → `MIRROR_X`.
   Edit the `EspRenderView` static flags (they are `volatile`, so a
   hot-swap helper/debug broadcast can flip them without restart).
2. **FOV:** stand at a known spot, aim at a landmark at screen edge;
   adjust `FOV_X_DEG` until the box sits on it (default 90; try 80–100).
   Vertical FOV follows automatically from the aspect ratio.
3. **Orientation sanity:** in the debug panel, `full` yaw should sweep
   0–360° smoothly while rotating; `src=full` should hold during idle
   aim (keepalive direction persists; if stale > 1.5 s the renderer falls
   back to `fold:` and shows it).
4. **Scale check:** the label distance vs the in-game teammate/enemy
   distance readout; if consistently off, refine `UNITS_PER_METER`.

## 9. Build

```
cmd /c "gradlew.bat assembleDebug > build_out.txt 2>&1"   (in fakelag\fakelag-beta)
```
`BUILD SUCCESSFUL` verified 2026-09-10 after the renderer landed.
Install manually (`adb install -r app\build\outputs\apk\debug\app-debug.apk`).
