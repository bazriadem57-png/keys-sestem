# Fakelag — project state, architecture and open questions

> **PATHS IN THIS DOC PREDATE THE 2026-09-15 PACKAGE REORG.**
> `core/` is now `tunnel/`, `net/` split into `decode/{frame,crypt,body}` +
> `protocol/`, `overlay/` split into `ui/{render,overlay,panel,button,aim}`.
> See `docs/SOURCE_MAP.md` §2 for the full old-to-new table.

**Start here for orientation.** For wire-format detail read
[`PROTOCOL_MASTER.md`](PROTOCOL_MASTER.md), which is authoritative and supersedes
this file wherever they disagree.

Last substantial update: 2026-09-11.

---

## 1. What this is

An Android `VpnService` that routes a target app's UDP through a userspace relay,
decodes Free Fire Max's game protocol, and acts on it. Three capability layers:

| layer | what it does | status |
|---|---|---|
| **Filters** | withhold / delay / replay our OWN outbound packets — `ghost`, `freeze`, `tele` | ghost + freeze work; tele needs rework |
| **ESP** | decode inbound entity state, draw boxes / radar / pose over the game | works; calibrated by eye |
| **Aim** | FOV cone, target lock, aim point, drag guide | visual only, no input injection |

It is a **pure external observer of its own traffic.** It does not read game memory,
does not hook the game, has no root and no input injection. Everything it knows comes
from packets it was already carrying.

### Module map

```
core/        PacketLoop, UdpSessionManager, VpnEngine   — transport + packet gates
filter/      GhostFilter, FreezeFilter, GamePacketTaxonomy
esp/         EspEngine (protocol decode + tracks), EspTuning (calibration store),
             OrientationProvider
overlay/     EspRenderView (projection + drawing), EspOverlay (vsync loop),
             EspTunePanel (in-game knobs), OverlayButton, CrosshairView, MaskBar
dev/capture/ PacketCapture, CaptureRing, DecodedDumper, FreezeDiffAnalyzer
app/         UiBindings, AppearanceBroadcaster, PermissionController, AppPicker
```

Two settings paths, and mixing them up causes bugs:
- **App toggles** → SharedPreferences → `AppearanceBroadcaster.send()` → broadcast →
  `FloatingOverlayService.applyAppearanceIntent()`.
- **In-game panel** → `EspTuning.setX()` → writes the renderer's `volatile` static
  **and** SharedPreferences in one expression. No broadcast.

`EspTuning.load()` must run before any setter, or the setters silently no-op (its
`sp` field is static and only assigned by `load()`).

---

## 2. The five traps

Every one of these cost a full debugging cycle. They are listed in
`PROTOCOL_MASTER.md` in detail; this is the index.

1. **Never identify a packet by bytes b2–b7.** That window is XOR-masked *and*
   cyclically rotated per session. Key off b8/b9.
2. **Body fields are zigzag** (`(v>>1) ^ -(v&1)`) — but **per field**. The camera
   triple is raw float32 bits; ticks are plain.
3. **Never bound anything by player count.** A hard-coded roster of 8 made the ESP
   work only in Clash Squad. Bound by what the bytes can physically hold.
4. **The body does not start at a fixed offset.** It begins after the leading
   object-handle varint at b8, which is 4 *or* 5 bytes. A fixed b12 made the entire
   ESP render nothing in training mode (0/190 keepalives accepted vs 190/190).
5. **The entity record is not a pure varint run.** Bytes 7/8/9 are fixed-width pose
   fields and must not be varint-decoded.

A sixth, methodological: **check that the analysis tooling shares the production
parser's assumptions before trusting a dump.** Record counts once looked capped at 8
because the dumper discarded everything above 8 — the analysis was circular and
pointed the wrong way.

---

## 3. What we can read from the wire

### Our own player — OUT keepalive, ~10 Hz, 23 varints

`v0,v1,v2` position (zigzag, v1 = height) · `v3–v7` state values capped ~200
(**unidentified**) · `v8–v10` velocity · `v11` airborne · `v12` state enum ·
`v13,v14,v15` **float32 unit camera direction** · `v16–v21` (**unidentified**) ·
`v22` ms tick (+99/packet).

The camera vector is the single most valuable field in the protocol — it is the
instrument that makes several otherwise-unanswerable questions measurable (§6).

### Every other player — IN entity chains, hard 198 ms tick

```
varint [0..6]  id, X, height, Y, vX, vHeight, vY
byte   [7]     body/leg yaw   u8    360/256 deg per LSB
byte   [8]     aim/head yaw   u8    same scale
byte   [9]     aim pitch      int8  ~1.29 deg per LSB, range ±64
varint [10..13] mode, state, reserved(0), reserved(0)
```
The self-echo record is different: 20 plain varints, no byte block.

### Combat — IN damage feed, 8 varints

`v0` victim handle, `v1` attacker handle, `v2` weapon/source (persistent per
attacker), `v5` damage. **There is no hit zone** — the packet parses as exactly 8
varints consuming every byte with no padding, and damage is continuous per
(attacker, weapon) with no headshot multiplier to expose one.

### Identity — the object handle

`(team << 24) | id`. **`team` is a per-match SQUAD INDEX**, not an own/enemy flag —
values 1..14 observed, ids to 55. Friend/foe is **relational**: friend iff the team
equals the one in our own keepalive handle. The old absolute rule was exactly
inverted in 4 of 10 sessions.

---

## 4. Measured constants

| quantity | value | how it was established |
|---|---|---|
| units per metre | **950** | gravity from airborne frames (−9313 u/s²) |
| entity tick | **198 ms** (5.05 Hz) | 49 246 inter-arrivals, IQR 2 ms |
| data staleness | **230 ms** | self-echo cross-correlation, 6 sessions; 200–260 |
| shipped lead | `age + 215 ms` | midpoint of two independent methods agreeing within 30 ms |
| handedness | `MIRROR_X = true` | in-game toggle; not derivable from packets |
| shoulder offset | **−0.70 m** | in-game; corroborated by own character rendering left of centre |
| boom / pivot | 3.0 m / 1.6 m | in-game |
| moving speed | p50 4.06, p90 6.19, max 12.57 m/s | 44 436 filtered samples |
| squad size | max **4**, never exceeded | 107 entities, 10 sessions |

### Things that are NOT in the packets, and never will be

- **Bones / limbs.** Settled, four independent ways — the record is structurally
  complete (2 of 14 fields constant zero), the byte budget is 20–21 B against ~90 B
  minimum for a skeleton, an exhaustive 4.96 M-candidate sweep found body-scale
  offsets **24× below** a chance control, and every other match-server family is
  ECB ciphertext. **Do not re-investigate.**
- **Hit zone / body part.** Confirmed absent (§3).
- **Camera FOV, and the handedness of the view basis.** The server sends positions,
  never a projection matrix. These are tuned by eye and persisted.
- **Crouch/prone height.** Posture does not change the transmitted height.
- **A faster position channel.** Exhaustively checked: only `b8 == 0x00` carries
  coordinates. The faster inbound families (12.4 Hz, 8.0 Hz) are ECB-encrypted and
  scored **0** position hits against a 4.6–19.8% chance baseline.

---

## 5. Three intuitions that measurement overturned

Recorded because each was implemented on instinct and then disproved:

1. **Smoothing the velocity hurts.** Latest single-tick finite difference 0.574 RMS
   vs naive; EMA(0.6) 0.580; 2-tick mean 0.595; EMA(0.4) 0.615. The tick is so
   regular that averaging only adds lag. Smooth the *rendered position* instead.
2. **Clamping speed hurts.** No clamp 1044 RMS; 8000 u/s 1082; 6500 u/s 1098;
   4000 u/s 1140. 12.57 m/s players are real.
3. **Capping the prediction horizon hurts.** No cap 1044; 400 ms cap 1086; 250 ms cap
   1201. Handle staleness by fading confidence with age, not by truncating.

Also: the server *does* send per-entity velocity, and it is a **worse** predictor
than our own finite difference (0.681 vs 0.553) because it covers one 99 ms sub-tick
and is noisier. It is used only to seed a newly-seen entity.

---

## 6. The self-echo is the project's measuring instrument

The server echoes our own player back to us as an ordinary entity record. Because we
*sent* the original, we know the truth — so anything the server does to it is
measurable.

This already yields the **live ping measurement**: keep ~9.6 s of our own reported
positions, and when an echo arrives find which past position it matches; the age of
that entry is the round-trip staleness. Requires movement (standing still makes the
match degenerate) and a match within ~1.2 m.

The same instrument can answer, without any new tooling:
- whether inbound packets can steer the camera (uncommanded yaw/pitch changes),
- pixels-per-degree for touch input, per sensitivity state,
- whether the game's aim assist moves the crosshair or bends bullets,
- what the server accepts or rejects during a teleport.

**When a question looks unanswerable, ask whether the self-echo can answer it.**

---

## 7. Aim — current position

Built and installed: FOV cone circle, aim point, sticky target lock, drag guide,
hold-to-aim button, panel knobs. **Nothing is injected.**

Two findings shape everything further:

**A precision aimbot from packet data is not achievable.** At real engagement moments
(2 094 damage events) victim speed is p50 2.00 m/s, and at a ~330 ms horizon the
predicted error is 0.40 m — already wider than a head. Against a sprinter it is over
a metre.

**The viable design exploits Free Fire's own aim assist** (officially "Aim
Precision"; Garena's patch notes prove it does target selection with a priority
function). Get the crosshair inside its envelope, let it hold the torso, then nudge
up by `atan(0.6 / range)` — range being the one quantity staleness barely degrades.

Injection path: **AccessibilityService is disqualified** — dispatching a gesture
cancels the user's own touches, and the drag headshot is performed *while firing*.
Shizuku is the only viable software route. See [`AIM_PLAN.md`](AIM_PLAN.md) for the
full analysis, the five open measurements, and the risk section (Garena bans
devices, not just accounts).

---

## 8. Known defects

**See [`SESSION_2026-09-11.md`](SESSION_2026-09-11.md) for full evidence on all of these.**

| defect | status |
|---|---|
| **Captures clipped at 200 B** — 2.88% of bytes and 100% of large chains lost, while the summary printed "0 clipped" | **FIXED** (default now 2048) |
| Solo ESP blackout — squad closure needs 4 teammates, unsatisfiable in solo | **FIXED** (late-arrival rung, 20 s) |
| Early-match friend/foe inverted — `entities` was never cleared between matches | **FIXED** (match reset on handle change OR 30 s chain silence) |
| ESP FOV wrong when scoped | **FIXED** (`FOV_ZOOM` multiplier + panel stepper + optional floating button) |
| Ghost leaked 10.9% of keepalives (45–64 B window vs real 48–67 B) | **FIXED** (shape test) |
| Dumper lost 20% of entity records and capped ids at 8 by construction | **FIXED** (calls the structural parser) |
| Dumper oracle scored 0/1624 and printed "OK" | **FIXED** (FAILs below 95%) |
| **TELE classification is exactly inverted** — holds the control channel, passes the keepalive | **open**, see TELEPORT.md |
| **FREEZE does not withhold position at all** (`onOutbound` returns PASS) — doc and code disagree | **open** |
| `PermissionController` requests 3 storage permissions not declared in the manifest | known, unrelated |

**Everything above is BUILT but NOT INSTALLED** — the phone disconnected. Also: the
worktree is ahead of HEAD `4188fc0`, which still carries the pre-relational friend/foe
classifier.

---

## 9. How to work on this

**Build and install** (from memory `fakelag-build-command`):
```
cd C:\Users\Tonyt\Documents\GitHub\Fakelag\fakelag\fakelag-beta
& .\gradlew.bat assembleDebug
```
as a PowerShell call **on its own**, with the sandbox disabled. Never combine it with
other shell work — that hangs. Gradle must not run sandboxed: a sandboxed daemon
silently discards writes while still reporting success.

**Always verify the install landed** — `adb shell dumpsys package com.fakelag.cryhard8 |
grep lastUpdateTime`. Do not trust "BUILD SUCCESSFUL".

**Calibration is by eye, in game, through the ⚙ panel.** FOV, handedness, shoulder
offset and lead are not derivable from captures; the panel exists so they can be
settled in seconds instead of arguing from data that cannot answer.

**Every claim in the docs should carry its evidence.** The recurring failure mode on
this project has been a plausible constant that happened to hold in early captures —
handedness, the roster of 8, the b11 team byte, the fixed body offset. When a
constant "works", check it across **sessions**, not just across game modes.
