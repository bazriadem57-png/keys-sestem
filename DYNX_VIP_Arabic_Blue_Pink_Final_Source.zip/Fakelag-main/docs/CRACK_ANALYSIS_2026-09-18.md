# Crack analysis — "Nuvola_Crack_No_Login.apk" (2026-09-18)

A repackaged build of the app was found that runs with no login and no server
contact — ESP and features work fully offline. This documents exactly how, from
a jadx diff of the crack against our own `nuvola-2.0.apk` release (both R8 full-
mode minified; the crack was rebuilt so its obfuscation mapping differs, hence
class letters differ between the two).

## The bypass: two booleans + a fake token

Our `SessionManager` (R8-renamed to `Y` in the crack) had its static
initializers flipped:

```java
// crack defpackage/Y.java  (== com.nuvola.app.auth.SessionManager)
public static volatile boolean d = true;   // authorized       — original: false
public static volatile boolean e = true;   // leaseAuthorized   — original: false
public static volatile String  b = "eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.<pro/exp2030>.AAA";
public static volatile String  c = "eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.<pro/exp2030>.AAA";
```

The token header base64-decodes to `{"alg":"none","typ":"JWT"}`, payload
`{"sub":"nuvola","tier":"pro","exp":1893456000}` (exp = 2030), signature `AAA`.

Our gate, both in `LoginActivity.onStart` and `MainActivity.onCreate`, is the
inlined `isAuthorized()`:

```java
// pass to the app when:
(authorized && ConfigStore.isLoaded()) || leaseAuthorized
```

With `leaseAuthorized = true`, this is **true unconditionally** — `ConfigStore`
(the server config blob) is short-circuited out. Both activities fall straight
through to the app. No key entry, no `/auth/activate`, no network.

Confirmed the original starts both false: the original SessionManager-equivalent
class initializes its two auth booleans to `false` (they are set `true` only
inside `activate()`/`resume()` after a real server round-trip).

## Why ESP works with no server

`ConfigStore.isLoaded()` (renamed `B0.a`) is referenced in **exactly two places
across the whole APK — the two startup gates above — and nowhere else.**
`PacketVpnService` (the engine) contains **no authorization check**. So once the
activity opens, the entire packet-decode / ESP path runs with zero dependency on
anything the server delivers:

- The Cmd 2012 entity-chain decoder (the ESP's position source) is
  self-contained — it needs no server table (Bucket-B). It decodes plaintext
  packets by shape alone.
- The session key for reliable channels arrives over lobby TCP (client-side),
  not from our server.

So nothing the tool actually does requires the server. **The license is a
client-side boolean gate, not a cryptographic dependency of the feature.**

## Additional facts

- The crack is **re-signed** with a different certificate (repackaged) — a
  runtime signing-cert check would detect it.
- The forged JWT is `alg:none`. Our *server* rejects that (it verifies EdDSA),
  but no *client* code verifies the token signature (it is read only for local
  timing), and the crack never contacts the server — so key revocation cannot
  touch it.

## What actually raises the cost

A purely client-side tool cannot be made uncrackable: anything the client can do
offline, an attacker can unlock offline. The realistic goal is to move the bar
from "flip two booleans in Java" to "defeat obfuscated native anti-tamper."

1. **Gate in the native `.so`, entangled with a required transform.** Have
   `libnuvola_native` verify the server-signed Ed25519 lease itself with the
   pinned key, and make a *required* decode/rewrite step depend on that
   verification — so stubbing the check also breaks the feature. The attacker
   must then patch obfuscated Rust, not a `static boolean`. (Aligns with the
   Phase-2 native port.)
2. **Native signing-cert / anti-tamper check** at `.so` load — the re-signed
   crack fails it.
3. **Bind ≥1 genuinely-used capability to a server secret not in the APK** — the
   only true cryptographic leash. Hard for pure ESP (2012 needs no table);
   feasible for features that consume the Bucket-B tables.

None of these is absolute; each raises attacker cost. Item 1 is the highest
leverage given the architecture already in flight.
