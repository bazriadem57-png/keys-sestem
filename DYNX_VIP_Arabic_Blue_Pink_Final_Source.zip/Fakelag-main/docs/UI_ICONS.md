# The icon system

**2026-09-16.** Seven vector icons, all authored in this repo. Three for the
in-game floating buttons, four for the settings tab bar.

| file | used by | shape |
|---|---|---|
| `ic_ghost.xml` | floating GHOST | sheet ghost, domed head, three-lobe hem, two eyes and a mouth |
| `ic_freeze.xml` | floating FREEZE | six-spoke snowflake with barbs |
| `ic_tele.xml` | floating TELEPORT | pad in perspective, arrow dropping into it, motion dashes |
| `ic_tab_engine.xml` | Engine tab | bolt inside a chip |
| `ic_tab_overlay.xml` | Overlay tab | stacked layers |
| `ic_tab_aim.xml` | Aim tab | crosshair with a centre dot |
| `ic_tab_system.xml` | System tab | gear |

---

## The four traps, in the order they bit

Every one of these produced a wrong icon that looked *fine in the source*. None
was found by reading; all four came off the device.

### 1. `fillType="evenOdd"` needs API 24, and this app's minSdk is 21

Where it is unsupported it is **silently ignored**, so a face cut with evenOdd
fills solid: a featureless blob, on old devices only, never reproducing in
testing.

Cut holes by **winding direction** instead. The outer body is wound one way and
each hole the other, so the default nonZero rule cancels them on every API.

### 2. Sweep-flag 1 is CLOCKWISE on screen

With y pointing down, an arc with sweep-flag `1` draws **clockwise**. The ghost
body leaves the top heading right, which is also clockwise, so features drawn
with sweep-flag 1 *added* winding instead of cancelling it — and the first
build shipped a ghost with no face.

The body is clockwise, so **the holes use sweep-flag 0**.

### 3. A top compound drawable is NOT centred vertically

`TextView` draws the top compound drawable at `scrollY + mPaddingTop` —
**top-aligned** — and centres it only horizontally. The text is then laid out
below it.

Collapsing the empty label's line box (`setTextSize(PX, 0f)`) is necessary but
not sufficient: it removes the label's height, not the top alignment. The glyph
still sat ~35px high in a 183px button.

**The padding does the centring.** `OverlayButton.centreIcon` sets top and
bottom to half the slack. Horizontal padding is left alone, because TextView
already centres across it.

`updateButtonLayout` must apply the same rule on resize and must **not** set a
text size on an iconned button — doing so restores the line box and the glyph
creeps up every time the size slider moves. That is the same one-of-two-paths
failure as the px/dp bug already recorded in that method.

### 4. A bounding box is not where the mass is

Two separate sizing errors, both invisible in the XML:

- **The ghost was lopsided.** Its dome ran `x=6..20` — centre 13, not 12 — so
  it sat half a unit right inside its own viewport.
- **The artwork does not reach its viewport edges.** The ghost filled 58% of
  the 24-unit box where the snowflake fills 72%, so at identical button sizes
  the ghost simply looked smaller. `ic_tele`'s pad had the same problem at
  rx 7.2.

A ghost is also top-heavy — solid dome over a scalloped hem — so centring its
*bounding box* still leaves the ink high. It starts at `y=2.2`, not the rounder
`1.8`, so the **ink** centres on 12.

---

## How to check an icon, since none of that is visible in the source

The floating buttons are `FLAG_NOT_FOCUSABLE`, so they **never appear in a
uiautomator / a11y dump**. Their frames come from the window manager:

```bash
adb -s R3GL10AHL7P shell dumpsys window windows | grep -E "frame=\[" 
```

Two things that will waste a cycle if you skip them:

- **This device's density override is 398, not the 480 the panel reports.**
  `wm density` says `Physical density: 450 / Override density: 398`. Every
  position computed by hand from 480 is wrong, and the first attempt at this
  measured the wallpaper instead of the buttons.
- **Mask to the inscribed circle before thresholding.** Sampling the square box
  catches whatever is behind the button. It reported the freeze glyph 24px
  right of centre and the ghost 29px left — *opposite directions*, which is
  what gave the contamination away. Both were actually the white "CONNECTED"
  text showing through.

Scroll the app so a flat dark surface sits behind the buttons before measuring,
or the hero gradient bleeds into the threshold.

### The numbers this settled on

Glyph box = **0.70 of the button** (`OverlayButton.iconPx`). At 0.58 the visible
ink measured only 39–42% of the button and read small; at 0.70 it measures
about 52%. A square inscribed in a circle can reach 0.707 before its corners
touch the rim, and none of these three glyphs has ink in its corners — the
snowflake's arms stop at 60°, not 45° — so 0.70 is safe. Going higher makes the
corners matter.

Measured on device, worst case 2.5px off centre on a 183px button:

| | ink, as % of button | dx | dy |
|---|---|---|---|
| freeze | 54% | −1.0 | −1.0 |
| ghost | 51% | −1.0 | −2.5 |
| tele | 53% | −1.0 | +0.5 |

---

## Wiring

**Floating buttons.** `OverlayButton.makeBtn` / `paintBtn` take an `iconRes`
through overloads; the old signatures delegate with `0`, so AIM, the zoom step
and CAPTURE stay text-only and untouched.

The glyph is a **compound drawable, not a second overlay window** — one window
per button is already the budget, and `WindowManager.addView` is the call that
has failed silently in this file before. Bounds are set explicitly rather than
using `setCompoundDrawablesWithIntrinsicBounds`, which would pin the icon at
24dp and ignore the size slider (which goes to 260%).

The buttons are **icon only**. They keep a name through `contentDescription`,
so they are not anonymous to TalkBack or in layout dumps. `R.string.tele` is
`"TELEPORT"` and is now only that content description — it is never drawn.

A `LayerDrawable` over the ring was tried and rejected: a layer fills its bounds
unless inset, and the inset depends on a button width `paintBtn` does not
reliably have yet.

**Tab bar.** `tools/gen_layout.py`'s `tab()` emits `android:drawableTop` on the
same TextView, so `Pager` keeps addressing one view per tab.

`Pager.paintTab` **tints the drawable**. A compound drawable does *not* follow
`setTextColor`, so without it every icon would stay at its authored white while
the labels moved, and the selected tab would say two different things at once.
It uses `setColorFilter`, not `setCompoundDrawableTintList` — the tint list
needs API 23 and this minSdk is 21, where it is a `NoSuchMethodError` rather
than a no-op.

---

## Known, not fixed

The **teleport button's default position** (`18, 248` dp) puts it underneath the
ESP button. Both are draggable, so it is cosmetic, but a new install lands them
overlapping.
