# VEHICLE_DISPATCH_MAP — what actually goes on the wire when the local player is mounted

> **CORRECTED 2026-09-15 by live capture.** Sec 3.5 (field 8 is a varint) and
> Sec 9.6 (inbound `GetCurrentPackedOp` is constant 8) are both **wrong**. Field 8
> is one RAW BYTE in both directions, and inbound it carries an occupancy bit
> (`op & 0x80` set on 0/756 empty vehicles and 115/155 occupied). Sec 9.5's open
> question is resolved: the outbound and inbound vehicle id spaces ARE shared.
> See `MOUNTED_CAPTURE_ANALYSIS.md` Q4.

**Scope.** The complete dispatch decision tree in `COW.GamePlay.PNCPKGJGBPP::EAIKJCCNGMJ`
(`0x078CDD78` .. `0x078CF588`), the non-2001 / non-2002 siblings, their wire layouts,
their reliability class, and where a **horse** lands.

**Image.** All addresses are in `C:\Users\Tonyt\Documents\FF-RE\bin\libil2cpp_dec.so`
(decrypted), symbols from `rva_map.txt`. Disassembly by capstone (`vaddr = file_offset + 0x4000`
inside `.text`; verified against ELF phdr: `.text` off `0x351f92c` → vaddr `0x352392c`).

**dump.cs provenance.** `C:\Users\Tonyt\Videos\ZRT-Toolbox\Dump\dump.cs` is a **different build**.
It is used here ONLY for structure (field names, field offsets, class hierarchy, vtable
slot numbers, the `Cmd` enum). **Every field offset quoted below was independently
re-read out of our own image's `Serialize` bodies** — where a claim rests on dump.cs alone
it is marked *(dump.cs)*.

**Cmd 2002's internal field layout is deliberately not decoded here** — that is a separate
agent's deliverable. What is here about 2002 is only its position in the tree, its envelope,
and its reliability.

---

## 0. TL;DR

| state | msgid | enum name | outbound class | has player position? | has player aim/camera? |
|---|---|---|---|---|---|
| on foot | **2001** | `UDP_PLAYER_STATE_SYNC` | (pooled; see §3.7) | yes (mm) | yes |
| **driver of a normal vehicle (car/bike)** | **2002** | `UDP_VEHICLE_STATE_SYNC` | `message.JBECKHDPPOO` | **no** — *vehicle* position only | **no** |
| **driver where the vehicle allows the driver to fire → the HORSE case** | **2069** | `UDP_VEHICLEWEAPONFIRE_STATE_SYNC` | `message.OGHGHMCCKFK` | **no** — *vehicle* position only | **YES** |
| passenger (whether or not they can fire) | **2006** | `UDP_PASSENGER_STATE_SYNC` | `message.KOEDKEJGCEP` | **no** | **YES** (2 direction vectors) |
| in a catapult | **2015** | `UDP_SYNC_CATAPULT` | `message.EHCDBOKGLEM` | **yes** (mm) | no (catapult rotation only) |
| on a chair | **2016** | `UDP_SYNC_AIM_ROTATION` | `message.ECBGLGKBEBH` | **no** | **YES** |
| in a cannon | **2031** | `UDP_SYNC_CANNON` | `message.GOOGGMOFFIK` | **yes** (mm) | no (cannon rotation only) |

* **Every one of these is sent with `sendOption = 0`** ⇒ `UDPMsgPacket.IsReliable()` is **false**
  ⇒ non-reliable 8-byte header, exactly the same framing class as Cmd 2001 ⇒ **plaintext,
  readable without the session key.** (§5, empirically corroborated for 2002 in our own captures.)
* **A horse is a `Vehicle`.** `COW.GamePlay.MountableAnimal : AmphibiousVehicle : MultiControllerVehicle : Vehicle`.
  `Player::IsInVehicle()` is literally `m_Vehicle != null`, so mounting a horse takes the
  vehicle branch. The rider is the **driver**.
* `MountableAnimal` is the **only** class in the image that overrides `Vehicle::CanDriverFire()`
  (slot 153) to anything other than `return false`. That is what routes the horse to **2069**
  rather than **2002** — and 2069 is the only driver message that carries the player's aim vector.

---

## 1. Entry conditions and cadence

`EAIKJCCNGMJ(this, Player p)` has exactly one caller:

```
078cf7a8  bl  0x78cdd78          in COW.GamePlay.PNCPKGJGBPP::OPHFNKPJOCI+0x220
```

`OPHFNKPJOCI(this, float, float)` @ `0x078CF588` is the module tick (two float args =
delta times; it has **zero** direct BL callers, i.e. it is invoked through the module
manager's virtual tick). It walks a player collection and calls the dispatcher once per
tick for **every entity where `GCommon.Entity::IsAutonomousProxy()` is true** (`0x078CF798`).

### The counter and the throttle

```
078cdef0  ldr  w8, [x19, #0x660]     ; this->sendCounter
078cdefc  add  w8, w8, #1
078cdf00  str  w8, [x19, #0x660]
078cdf04  bl   PNCPKGJGBPP::EFJEIMIIEJO   ; 0x078CDADC
078cdf08  tbz  w0, #0, 0x78ce8cc          ; false -> return, send NOTHING
```

`EFJEIMIIEJO` @ `0x078CDADC` is the **single gate in front of every branch**:

```
if (this->byte@0x65c != 0)                  return false;   // 078cdb4c
if (player == null)          /* Unity == */ return false;   // 078cdb78
if (AttackableEntity::get_IsDead(p))        return false;   // 078cdb8c
if (Player::get_IsOnBoard(p))               return false;   // 078cdb9c
if (Player::get_IsOnFerrisWheel(p))         return false;   // 078cdbac
if (Player::get_IsFollowing(p))             return false;   // 078cdbbc
if (Player::get_IsPassiveMoving(p))         return false;   // 078cdbcc
if (Player::IsOnlineBotAgent(p))            return false;   // 078cdbdc
return (this->counter@0x660 % 3) == 0;                      // 078cdbf4..078cdc10
```

The modulo is the classic magic-multiply form — `mul w8, w8, #0xAAAAAAAB` then
`cmp w8, #0x55555556 ; cset lo`, which is exactly `x % 3 == 0`.

**Consequences:**

1. The `(counter % 3) == 0` throttle is **not specific to 2001** — it gates *all seven*
   msgids. The repo's measured **99 ms** period therefore applies to 2002/2006/2015/2016/2031/2069
   identically.
2. **Five additional states send nothing at all** (`IsOnBoard`, `IsOnFerrisWheel`,
   `IsFollowing`, `IsPassiveMoving`, `IsOnlineBotAgent`). These are silent holes beyond the
   mounted case — no fallback msgid exists for them.

---

## 2. The complete decision tree, in evaluation order

Read top to bottom; first matching predicate wins.

```
EAIKJCCNGMJ(this=x19, player=x20)             @ 0x078CDD78
│
├─ [iFix patch dispatch, id 0x28B0F]          @ 0x078CDE98 .. 0x078CDEEC   (not taken in prod)
│
├─ this->counter@0x660 += 1                   @ 0x078CDEF0
├─ if (!EFJEIMIIEJO(this, player)) ───────────► RETURN, nothing sent       @ 0x078CDF04/08
│
├─ if (Player::IsInVehicle(player))            @ 0x078CDF18  [0x0706A2EC]
│  │   ── body: `return m_Vehicle@0x8b0 != null` (UnityEngine.Object::op_Inequality)
│  │
│  ├─ if (Player::IsPassengerInVehicleCanFire) @ 0x078CDF28  [0x070833EC]
│  │  │   ── GameModeSetting.EnableVehiclePassengerFire@0x22
│  │  │      && m_Vehicle != null
│  │  │      && player != Vehicle::get_Driver()      (BHGGAEEHJCO::PDJKLNDADFO, "not equal")
│  │  │      && Vehicle::CanPassengerFire()          [0x07F9FD14, non-virtual]
│  │  └──────► build KOEDKEJGCEP + JGGMLMNCMAA @0x078CDF48/64, jump to shared tail 0x078CE728
│  │                                             ⇒ Cmd 0x7D6 = 2006, Send @ 0x078CE8C8 (BL)
│  │
│  ├─ w22 = Player::IsVehicleSupportDriverWeaponFire()  @ 0x078CE0D8  [0x07083924]
│  │   x21 = Player::GetVehicleIAmIn()                  @ 0x078CE0E8  [0x07065968]
│  │   ── w22 = GameModeSetting.EnableVehicleDriverWeaponFire@0x23
│  │            && m_Vehicle != null
│  │            && player == Vehicle::get_Driver()      (BHGGAEEHJCO::EEOFJDHOLBP, "equal")
│  │            && vehicle->vtable[0xac8]()  ==  Vehicle::CanDriverFire()   (slot 153)
│  │
│  ├─ if (w22)                                  @ 0x078CE0F0
│  │  ├─ if (!Vehicle::IsLocalAuth(veh))  ─────► RETURN                     @ 0x078CE100
│  │  ├─ if (Player::get_WaitForForceSync) ────► RETURN                     @ 0x078CE110
│  │  └──────► build OGHGHMCCKFK (+ nested OLEOJNOGCCN) @ 0x078CE130/0x078CE204
│  │                                             ⇒ Cmd 0x815 = 2069, Send @ 0x078CE684 (tail B)
│  │                                             ◄── THE HORSE LANDS HERE (§4)
│  │
│  └─ else  (not a firing passenger, vehicle does not grant driver fire)     @ 0x078CE3EC
│     ├─ if (Player::get_IsDriver)               @ 0x078CE3F4  [0x07065824]
│     │  │   ── m_Vehicle != null && player == Vehicle::get_Driver()
│     │  ├─ if (!Vehicle::IsLocalAuth(veh))  ──► RETURN                      @ 0x078CE408
│     │  ├─ if (Player::get_WaitForForceSync) ─► RETURN                      @ 0x078CE418
│     │  └──────► build JBECKHDPPOO (+ nested OLEOJNOGCCN) @ 0x078CE438/0x078CE454
│     │                                          ⇒ Cmd 0x7D2 = 2002, Send @ 0x078CE684 (tail B)
│     │
│     └─ else  (passenger who cannot fire)       @ 0x078CE688
│        └──────► build KOEDKEJGCEP + JGGMLMNCMAA, shared tail 0x078CE728
│                                                 ⇒ Cmd 0x7D6 = 2006, Send @ 0x078CE8C8 (BL)
│
├─ else if (Player::IsInCatapult(player))        @ 0x078CDFDC  [0x07071AA8]
│  │   ── player->attachedLevelObj@0x1b98 valid && FGAHFBDAKPI::JELOHFOGPLC(...) == 0x10
│  ├─ cat = Player::GetCatapultIAmIn()           @ 0x078CDFEC  [0x07084014]
│  ├─ if (!(cat != null))                   ────► RETURN                     @ 0x078CE020
│  └──────► build EHCDBOKGLEM @ 0x078CE03C
│                                                 ⇒ Cmd 0x7DF = 2015, Send @ 0x078CE684 (tail B)
│
├─ else if (Player::IsInCannon(player))          @ 0x078CE2F8  [0x07071B78]
│  │   ── same field @0x1b98, type enum == 0x17
│  ├─ can = Player::GetCannonIAmIn()             @ 0x078CE308  [0x0708405C]
│  ├─ if (!(can != null))                   ────► RETURN                     @ 0x078CE33C
│  └──────► build GOOGGMOFFIK @ 0x078CE358
│                                                 ⇒ Cmd 0x7EF = 2031, Send @ 0x078CE684 (tail B)
│
├─ else if (Player::IsOnChair(player))           @ 0x078CE570  [0x07077BC4]
│  │   ── `return player->chair@0x928 != null`
│  └──────► build ECBGLGKBEBH @ 0x078CE590
│                                                 ⇒ Cmd 0x7E0 = 2016, Send @ 0x078CE684 (tail B)
│
└─ else  ON FOOT                                 @ 0x078CE8FC
   ├─ if (Player::get_WaitForForceSync)     ────► RETURN                     @ 0x078CE904
   ├──────► build the 2001 body (pooled; §3.7)
   │                                              ⇒ Cmd 0x7D1 = 2001, Send @ 0x078CF1D4 (BL)
   └─ then, ONLY if GameModeSetting.byte@0x99c && GameFacade::IsCustomRoomLeague():
      build a second message (UserControlHandler axis data)
                                                  ⇒ Cmd 0x807 = 2055
                                                    `UDP_PLAYER_HUD_OPERATE_SYNC`,
                                                    Send @ 0x078CE8C8 (via B to 0x078CE8B8)
```

### The shared exit

Three distinct entry labels converge on one epilogue that tail-calls `GameFacade::Send`:

```
078ce644  mov  w0, #0x7e0       ; LBL A — chair falls through here, msgid 2016
078ce648  mov  x1, x21          ; LBL B — catapult (w0=0x7df) / cannon (w0=0x7ef) jump here
078ce64c  ...epilogue...        ; LBL C — 2002 (w0=0x7d2,x1=x19) / 2069 (w0=0x815,x1=x22) jump here
078ce674  mov  w2, wzr          ; sendOption = 0
078ce678  mov  w3, wzr          ; cacheMsgAnyWay = false
078ce67c  mov  x4, xzr          ; il2cpp methodInfo
078ce684  b    #0x75488ac       ; -> COW.GameFacade::Send   (TAIL CALL)
```

The 2006 path and the on-foot 2001 path use ordinary `BL` sites at `0x078CE8C8` and
`0x078CF1D4`, also with `w2 = w3 = 0`.

> **Registry correction.** `tools/il2cpp/ff_outbound_registry_full.txt` lists only
> `2001 @078cf1d4`, `2006 @078ce8c8` and `2016 @078ce684` for this function. **2002, 2015,
> 2031 and 2069 are missing entirely** because they all reach `Send` through the same
> tail-call at `0x078CE684` and the scanner's `regimm(site, w0)` only recovered the
> immediately preceding `mov w0, #0x7e0`. The same file also mislabels 2001's class as
> `JGGMLMNCMAA` — the nearest-preceding-`.ctor` heuristic walked back into the passenger
> branch; 2001's body is taken from an object pool, not `new`-ed (§3.7).

---

## 3. Layouts

### 3.0 Serializer primitives (verified in our image)

| writer | address | encoding |
|---|---|---|
| `FastBinaryWriter::Write(uint)` | `0x08291898` | **plain LEB128 varint** (no zigzag) |
| `FastBinaryWriter::Write(int)` | `0x08290EF4` | **zigzag then LEB128** (`(v<<1)^(v>>31)`) |
| `FastBinaryWriter::Write(short)` | `0x08291B38` | **zigzag then LEB128** |
| `FastBinaryWriter::Write(long)` | `0x08291900` | zigzag then LEB128 |
| `FastBinaryWriter::Write(ulong)` | `0x0829196C` | plain LEB128 |
| `FastBinaryWriter::WriteFixU16` | `0x08292078` | 2 raw LE bytes |
| `FastBinaryWriter::Flush` | `0x08290E84` | end of a (sub-)message |

Quantiser / vector types (`message.KANJBNIANHC`, `0x0577D73C`..`0x0577EBA8`):

| helper | address | produces | wire | scale (read from the `mov w9, #imm` before the `fmul`) |
|---|---|---|---|---|
| `COGCJKJPPHI(Vector3)` | `0x0577E298` | `PMFGOGFPDHM` | **3 × zigzag-varint int32** | `0x447A0000` = **1000.0f** → millimetres |
| `JNMALNNFDLI(Vector3)` | `0x0577DE98` | `BDOPLCJODBN` | **3 × zigzag-varint int16** | `0x42C80000` = **100.0f** → value/100 |
| `HDMMEFFMIJP(Quaternion)` | `0x0577E5E0` | `BJIPILEFOGL` | **4 × zigzag-varint int16** (x,y,z,w) | `0x447A0000` = **1000.0f** → value/1000 |
| `JMELIEOFFHJ(Vector3)` | `0x0577E1D8` | `DECDPFHCEDH` | 3 × raw float32 | n/a |
| `MPHBFOGKIHH(Vector3)` | `0x0577D73C` | `FOENPKFAEOC` | (2001 only) | — |

Vector serializers re-read from our image: `BDOPLCJODBN::Serialize` `0x047C2DE0`
(3 × `Write(short)` from `+0x12/+0x14/+0x16`), `PMFGOGFPDHM::Serialize` `0x047C2FF0`
(3 × `Write(int)` from `+0x14/+0x18/+0x1C`), `BJIPILEFOGL::Serialize` `0x047C30F8`
(4 × `Write(short)` from `+0x12/+0x14/+0x16/+0x18`).

The quaternion ×1000 scale is independently confirmed on the wire — see
`captures/phone_aim7/capture_raw_20260912_161312.txt`, inbound 2002 records:
`aim.x=22 aim.y=366 aim.z=-6 aim.w=930` → `(0.022, 0.366, −0.006, 0.930)`, ‖q‖ = 0.9997.

### 3.1 Cmd 2006 — `UDP_PASSENGER_STATE_SYNC`

Envelope `message.KOEDKEJGCEP` (`.ctor 0x049D7018`, `Serialize 0x049D6DD8`):

| # | field *(dump.cs name)* | offset | type | wire |
|---|---|---|---|---|
| 1 | `HNNHFPHJMGL` | `+0x18` | `JGGMLMNCMAA` | nested sub-message (see below) |
| 2 | `HMKGHANBCNJ` | `+0x20` | uint | plain varint — **client ms timestamp** (§3.6) |

Body `message.JGGMLMNCMAA` (`.ctor 0x047CEBCC`, `Serialize 0x047CE8B4`):

| # | field | offset | type | wire | filled from |
|---|---|---|---|---|---|
| 1 | `BHGGAEEHJCO` | `+0x14` | uint | plain varint | `BHGGAEEHJCO::LMCLIKOCCJM(Player::get_PlayerID(p))` @ `0x078CE72C` — the packed entity/player id |
| 2 | `LFCNHAJBHEE` | `+0x18` | `BDOPLCJODBN` | 3 × zigzag short ÷100 | `IsFiring() ‖ GetSightingState()` ? **aim forward** : `Entity::get_Forward()` @ `0x078CE740`..`0x078CE7EC` |
| 3 | `DIPPKFBIILG` | `+0x20` | `BDOPLCJODBN` | 3 × zigzag short ÷100 | **always** aim forward @ `0x078CE810`..`0x078CE878` |

"aim forward" throughout this document means
`UnityEngine.Quaternion::op_Multiply(Player::GetAimRotation(p), Vector3.forward)` —
`GetAimRotation` @ `0x070718A8`, `op_Multiply` @ `0x0A82BAF4`, the `Vector3` operand
loaded as `ldp s4,s5,[x8,#0x48] ; ldr s6,[x8,#0x50]` from the `UnityEngine.Vector3`
static block.

`Player::GetSightingState()` is the virtual at `Player` vtable slot 198 (`[x8,#0xd98]`,
`(0xd98−0x138)/16 = 198`) — ADS state *(slot name from dump.cs)*.

**No position at all.** A passenger's own world position never leaves the client.

### 3.2 Cmd 2015 — `UDP_SYNC_CATAPULT`, class `message.EHCDBOKGLEM`

`.ctor 0x04D9C754`, `Serialize 0x04D9C3D8`, build block `0x078CE030`..`0x078CE0CC`.

| # | field | offset | type | wire | filled from |
|---|---|---|---|---|---|
| 1 | `GPKOMGIOFPF` | `+0x14` | uint | plain varint | `BaseLevelObject::GetObjectID(catapult)` @ `0x078CE04C` |
| 2 | `LFCNHAJBHEE` | `+0x18` | `BJIPILEFOGL` | 4 × zigzag short ÷1000 | `LevelCatapult::get_AbsoluteRotation()` @ `0x078CE060` → `HDMMEFFMIJP` |
| 3 | `MEKKBLGDNCH` | `+0x20` | `PMFGOGFPDHM` | 3 × zigzag int, mm | **`Entity::get_Position(player)`** @ `0x078CE084` → `COGCJKJPPHI` |
| 4 | `HMKGHANBCNJ` | `+0x28` | uint | plain varint | `BJNKBGDPBAC` ms timestamp @ `0x078CE0A8` |

Carries the **player's** world position. Carries **no player aim** — only the catapult's
absolute rotation.

### 3.3 Cmd 2031 — `UDP_SYNC_CANNON`, class `message.GOOGGMOFFIK`

`.ctor 0x04D9D890`, `Serialize 0x04D9D514`, build block `0x078CE340`..`0x078CE3E8`.
Structurally identical to 2015:

| # | field | offset | type | wire | filled from |
|---|---|---|---|---|---|
| 1 | `GDGLBJBAPCO` | `+0x14` | uint | plain varint | `BaseLevelObject::GetObjectID(cannon)` @ `0x078CE368` |
| 2 | `LFCNHAJBHEE` | `+0x18` | `BJIPILEFOGL` | 4 × zigzag short ÷1000 | `LevelCannon::get_AbsoluteRotation()` @ `0x078CE37C` |
| 3 | `MEKKBLGDNCH` | `+0x20` | `PMFGOGFPDHM` | 3 × zigzag int, mm | **`Entity::get_Position(player)`** @ `0x078CE3A0` |
| 4 | `HMKGHANBCNJ` | `+0x28` | uint | plain varint | `BJNKBGDPBAC` @ `0x078CE3C4` |

Player position present; player aim absent (the cannon's rotation *is* the aim in this state).

### 3.4 Cmd 2016 — `UDP_SYNC_AIM_ROTATION`, class `message.ECBGLGKBEBH`

`.ctor 0x04D9FDBC`, `Serialize 0x04D9FB7C`, build block `0x078CE578`..`0x078CE644`.

| # | field | offset | type | wire | filled from |
|---|---|---|---|---|---|
| 1 | `DIPPKFBIILG` | `+0x18` | `BDOPLCJODBN` | 3 × zigzag short ÷100 | **aim forward** @ `0x078CE59C`..`0x078CE604` |
| 2 | `HMKGHANBCNJ` | `+0x20` | uint | plain varint | `BJNKBGDPBAC` @ `0x078CE624` |

Two fields, total. The enum name (`UDP_SYNC_AIM_ROTATION`) is literal: while seated on a
chair the client transmits **only the aim direction and a timestamp**. No position, no
chair id, no player id. This is the most degenerate state in the family.

### 3.5 Cmd 2069 — `UDP_VEHICLEWEAPONFIRE_STATE_SYNC`, class `message.OGHGHMCCKFK`

`.ctor 0x049D7860`, `Serialize 0x049D74E4`, build block `0x078CE118`..`0x078CE2EC`.

| # | field | offset | type | wire | filled from |
|---|---|---|---|---|---|
| 1 | `COCJHEFNCGP` | `+0x18` | `OLEOJNOGCCN` | nested sub-message | the same vehicle-state record 2002 uses |
| 2 | `DNNFOOGPFHO` | `+0x20` | uint | plain varint | `GameFacade::CurrentServerTick()` @ `0x078CE1E4` |
| 3 | `DIPPKFBIILG` | `+0x28` | `BDOPLCJODBN` | 3 × zigzag short ÷100 | **aim forward** @ `0x078CE14C`..`0x078CE1B4` |
| 4 | `HMKGHANBCNJ` | `+0x30` | uint | plain varint | `BJNKBGDPBAC` @ `0x078CE138` |

**2069 is 2002 plus a player aim vector plus a client timestamp.** Fields 1 and 2 are
byte-for-byte the same two fields `JBECKHDPPOO` (2002) carries, in the same order — a
2002 decoder reads the first two fields of a 2069 body unchanged and then finds four
extra varints.

Nested `message.OLEOJNOGCCN` (`.ctor 0x047CF0AC`, `Serialize 0x047CEC24`) — shown for
decoder completeness only; **the field semantics of this record are the other agent's
deliverable**:

| # | field | offset | type | wire | filled from (in the 2069 block) |
|---|---|---|---|---|---|
| 1 | `FAAMLGOPLAC` *(= "VehicleID", from the shipped deobfuscation map)* | `+0x14` | uint | plain varint | `BaseLevelObject::GetObjectID(vehicle->field@0x120)` @ `0x078CE22C` |
| 2 | `MOEFFAIDCBP` | `+0x18` | `PMFGOGFPDHM` | 3 × zigzag int, mm | `Entity::get_Position(vehicle)` @ `0x078CE244` |
| 3 | `LFCNHAJBHEE` | `+0x20` | `BJIPILEFOGL` | 4 × zigzag short ÷1000 | `Entity::get_Rotation(vehicle)` @ `0x078CE270` |
| 4 | `JBOGMCKPKLJ` | `+0x28` | byte | **plain varint** via `Write(uint)` in `OLEOJNOGCCN::Serialize`, *not* a raw byte | `vehicle->vtable[0x8a8]()` = `Vehicle::GetCurrentPackedOp()` (slot 119) @ `0x078CE2D4` |
| 5 | `AAPGPMPKMBD` | `+0x30` | `BDOPLCJODBN` | 3 × zigzag short ÷100 | `PNCPKGJGBPP::INCBJGDHGOA(vehicle)` @ `0x078CE298` |

`INCBJGDHGOA` @ `0x078CDC1C` is a static helper: it returns
`vehicle->vtable[0x8f8]()` = `Vehicle::GetVelocity()` (slot 124), except that it returns
`Vector3.zero` when `Vehicle::InWaterAndShouldBreak()` is true and `‖v‖² ≤ threshold²`
(threshold from a static float at `+0x1288`).

> Note on field 4: `JBOGMCKPKLJ` is declared `byte` but is written through the **uint**
> overload, so on the wire it is a varint, not a raw byte. This is one of the cases the
> "`B` (byte) → one RAW byte" rule does **not** cover — the rule applies to
> `FastBinaryWriter` byte overloads, and this field does not use one. Observed value in
> our captures: `v8=8`.

### 3.6 `BJNKBGDPBAC` — the `HMKGHANBCNJ` timestamp

`PNCPKGJGBPP::BJNKBGDPBAC(this)` @ `0x078CF3B8`:

```
if (GameFacade::IsRushingPetsMode())
    return (uint)ceil(GameFacade::CurrentServerTime() * 1000.0f);   // 078cf490..078cf4f8
else
    return this->baseTick@0x64c
         + (uint)ceil((UnityEngine.Time.time - this->t0@0x648) * 1000.0f);  // 078cf500..078cf570
```

i.e. a **client millisecond clock**, the same `v22` field already documented for 2001.
Both scale constants are `0x447A0000` = 1000.0f.

`DNNFOOGPFHO` in 2002/2069 is a *different* quantity: `GameFacade::CurrentServerTick()`
(`0x0754978C`).

### 3.7 Cmd 2001's body object (for the record)

The on-foot path does **not** `new` its message. At `0x078CE914` it loads a cached
wrapper from `this->field@0x668`, then at `0x078CE944` calls `0x0902E57C` — an il2cpp
shared-generic pool `Get<T>()` whose type token comes from `[0xb02c000 + 0x230]`. The
symbol at `0x0902E57C` is unresolved in `rva_map.txt` (nearest preceding symbol is
`<>c::<SetEditorP12FileName>b__4_0+0x69aa5c`, i.e. meaningless). This is why class-by-
nearest-`.ctor` heuristics mis-attribute 2001. The same pool call appears inside
`JGGMLMNCMAA::Serialize`, `KOEDKEJGCEP::Serialize`, etc., for lazily allocating null
sub-messages.

---

## 4. Where a horse lands — the answer

### 4.1 A horse is a Vehicle, and the rider is its driver

`COW.GamePlay.MountableAnimal` is the mount class. Evidence, all from **our** image's
`rva_map.txt` unless marked:

* Hierarchy *(dump.cs)*: `MountableAnimal : AmphibiousVehicle : MultiControllerVehicle : Vehicle`.
* Its fields *(dump.cs)* are explicitly equine: `HorseParam horseParam` (`+0x500`),
  `HorseObstacleAvoidance m_ObstacleAvoidance` (`+0x540`), `HorseColliderOpt horseColliderOpt`
  (`+0x5C8`), `float FireMaxSpeedScale` (`+0x4F8`). All three of those class names exist in
  our image: `COW.GamePlay.HorseParam`, `COW.GamePlay.HorseObstacleAvoidance`,
  `GCommon.HorseColliderOpt`, plus `COW.GamePlay.MountableAnimalAnimator`.
* In our image, `COW.GamePlay.Vehicle` itself carries `Mount` (`0x07FBF4A4`),
  `UnMount` (`0x07FBFA6C`), `ReleaseMounted` (`0x07FB6A9C`), `IsShowHorseMoveEffect` (`0x07FC315C`).
* `VehicleEffectChange::InitInGameHorseMoveEffect` (`0x05D3ABD8`) takes a `Vehicle` *(dump.cs signature)*.
* Also in our image: `COW.MiniMapVehicleHorse::IsMountableAni` (`0x05C441BC`),
  `COW.UIUtils::GetVehicleHPColorForHorse` (`0x05CAA1A4`),
  `COW.GamePlay.Player::TryGetHorseAutoDriveSteerByAim` (`0x07184880`),
  `COW.UIHudVehicleStatsController::get_IsMountableAnimal` (`0x05391FAC`).

`Player::IsInVehicle()` @ `0x0706A2EC` is one line:

```
0706a354  ldr  x19, [x19, #0x8b0]      ; Player::m_Vehicle
0706a37c  b    UnityEngine.Object::op_Inequality      ; return m_Vehicle != null
```

There is **no separate mount system and no mount-specific message**. The horse is a
`Vehicle`, and a mounted player therefore enters the `IsInVehicle` branch. The rider is
the `Vehicle::get_Driver()`, so `Player::get_IsDriver()` (`0x07065824`) is true and
`IsPassengerInVehicleCanFire()` is false.

### 4.2 Which driver branch — 2002 or 2069?

`Player::IsVehicleSupportDriverWeaponFire()` @ `0x07083924` is evaluated **before**
`get_IsDriver`, and its final term is a virtual call:

```
07083a8c  ldr  x0, [x19]
07083a9c  ldr  x9, [x8, #0xac8]        ; vtable slot (0xac8-0x138)/16 = 153
07083aa4  blr  x9                       ; = Vehicle::CanDriverFire()
```

Slot 153 is `CanDriverFire` — confirmed two ways: the slot arithmetic, and dump.cs which
labels both `Vehicle::CanDriverFire` and `MountableAnimal::CanDriverFire` as `Slot: 153`.

The two implementations in our image:

```
COW.GamePlay.Vehicle::CanDriverFire           @ 0x07FC2D38
    07fc2d70  mov  w0, wzr                     ; return false — ALWAYS

COW.GamePlay.MountableAnimal::CanDriverFire   @ 0x0758F4C4
    0758f50c  bl   COW.GamePlay.Vehicle::GetVehicleData      ; 0x07FAD55C
    0758f514  ldrb w0, [x0, #0x59]             ; return vehicleData->bool@0x59
```

`MountableAnimal` is the **only** override of slot 153 in the image (`grep` over
`rva_map.txt` for `::CanDriverFire` returns exactly these two symbols).

**Therefore:**

* Driving a **car, bike, tuk-tuk, bumper car, helicopter, boat, …** → `CanDriverFire()`
  returns false → `get_IsDriver` → **Cmd 2002**.
* Riding a **horse** → `CanDriverFire()` returns the per-row CSV flag → if that flag is
  set **and** `GameModeSetting.EnableVehicleDriverWeaponFire` (`+0x23`, name *(dump.cs)*,
  offset read from our image at `0x070839C8`) is set → **Cmd 2069**; otherwise it falls
  through to **Cmd 2002**.

### 4.3 Is the CSV flag set for horses? — probably yes, but the binary cannot settle it

`GetVehicleData()` returns `GKEDHMFHDFM` *(dump.cs)*, a `CSVBaseData` row; offset `0x59`
is `public bool PECCGBBOIAM` *(dump.cs)*. The value lives in a CSV asset bundle, **not in
the binary**, so this document cannot state it as fact.

Circumstantial evidence that it is set for horse rows (all names from dump.cs, several
mirrored in our `rva_map.txt`):

* `MountableAnimal.FireMaxSpeedScale` — a speed multiplier that only makes sense if the
  rider can fire.
* `MountableAnimal::RefreshIdleHoldWeaponAnim` (our image, `0x07590BE8`).
* `COW.GameVarDef`: `HorseFireIkFixedAngleX` / `HorseFireIkFixedAngleZ`,
  `HorseAimAngleRightLeft` / `HorseAimAngleUp` / `HorseAimAngleDown`,
  `EnableHorseAimForwardDeflect`, `HorseAimForwardKeepAngle`.
* `COW.UIHudCameraEmoteItemController::IsLocalPlayerInHorseCombatState` (our image, `0x03A247F8`).
* `COW.WeaponVehicleIKFixData::MountableWeaponType`.
* `Player::TryGetHorseAutoDriveSteerByAim` (our image, `0x07184880`) — steering derived
  from the aim vector, which is exactly the extra field 2069 adds over 2002.

**How to settle it in one minute of play:** mount a horse, capture, and look at which
msgid replaces 2001 in the outbound stream — **2069** means `CanDriverFire` is true for
that horse row, **2002** means it is false. No other test is needed. Because the mode
setting is also in the condition, the answer may differ between BR and Clash Squad; test
in the mode that matters.

### 4.4 Practical consequence for the tool

* If the horse takes **2069**: both position *and* camera basis are recoverable while
  mounted. Position = the *vehicle's* mm position (`OLEOJNOGCCN` field 2), which under a
  rider is within a metre or so of the player. Camera forward = `DIPPKFBIILG`, a unit
  vector ÷100 — directly usable, no quaternion reconstruction needed.
* If the horse takes **2002**: only the vehicle's position and *rotation* are available.
  The vehicle rotation is the horse's body yaw, **not** the camera. Free Fire's horse aim
  is decoupled from the body (that is precisely what `HorseAimAngleRightLeft/Up/Down` and
  `EnableHorseAimForwardDeflect` are for), so a camera basis built from vehicle rotation
  will be wrong by up to the configured aim cone. In that case the inbound self-echo
  stopgap is the only source of a true camera direction, and it should be kept.
* A **horse passenger**, if two-seat mounts exist (`MountableAnimal::SetSeat` @ `0x0758C464`
  in our image), sends **2006** — aim direction but **no position at all**.

---

## 5. Reliable or unreliable, per branch — all seven are UNRELIABLE

`GameFacade::Send(uint messageID, UDPClientMessageBase msg, byte sendOption = 0, bool cacheMsgAnyWay = false)`
*(signature from dump.cs; argument registers confirmed in our image at `0x075488AC`)*.

**Every call site in `EAIKJCCNGMJ` passes `w2 = 0` and `w3 = 0`:**

| branch | msgid setup | sendOption |
|---|---|---|
| 2006 | `078ce8b4  mov w0,#0x7d6` | `078ce8bc  mov w2, wzr` |
| 2015 | `078ce0c8  mov w0,#0x7df` | `078ce674  mov w2, wzr` (shared epilogue) |
| 2016 | `078ce644  mov w0,#0x7e0` | `078ce674  mov w2, wzr` |
| 2031 | `078ce3e4  mov w0,#0x7ef` | `078ce674  mov w2, wzr` |
| 2002 | `078ce558  mov w0,#0x7d2` | `078ce674  mov w2, wzr` |
| 2069 | `078ce2e0  mov w0,#0x815` | `078ce674  mov w2, wzr` |
| 2001 | `078cf1c0  mov w0,#0x7d1` | `078cf1c8  mov w2, wzr` |

`GCommon.UDPMsgPacket::IsReliable(uint cmd, byte sendOption)` @ `0x082C0C04`:

```
082c0c54  cmp  w20, #2            ; cmd == 2 (UDP_ACK) -> never reliable
082c0c58  b.eq 0x82c0c88          ;   -> return false
082c0c5c  ldr  x8, [x0, #0xb8]
082c0c60  ldrb w8, [x8]           ; a static kill-switch; nonzero -> return false
082c0c64  cbnz w8, 0x82c0c88
082c0c68  sub  w8, w19, #1        ; sendOption - 1
082c0c70  cmp  w9, #4
082c0c74  b.hi 0x82c0c88          ; (sendOption-1) & 0xff > 4 -> return false
082c0c78  mov  w9, #0x13          ; 0b10011
082c0c7c  lsr  w8, w9, w8
082c0c80  and  w0, w8, #1         ; return bit (sendOption-1) of 0b10011
```

`0x13` has bits 0, 1 and 4 set, so reliable ⟺ `sendOption ∈ {1 HELLO, 2 RELIABLE, 5 VAR_RELIABLE}`
*(constant names from dump.cs `UDPMsgPacket`)*. **`sendOption = 0` (`UDPMESSAGE_SENDOPTION_NONE`)
takes the `> 4` unsigned branch and returns false.**

`UDPSession::Send` @ `0x082C83CC` calls this same `IsReliable` at `0x082C8458` and uses
the result to choose the header form (`sturb w24,[x26,#-0x15]` → `UDPMsgPacket.SendOption@0x13`,
`sturh w25,[x26,#-0x14]` → `Cmd@0x14`, `sturh w20,[x26,#-0xe]` → `Length@0x1A`; offsets
match dump.cs exactly).

**Verdict: 2001, 2002, 2006, 2015, 2016, 2031 and 2069 are all non-reliable, 8-byte-header,
plaintext packets. None of them requires the session key.** They differ from Cmd 2001 in
no framing respect whatsoever — identical function, identical argument registers.

### Empirical corroboration

`captures/phone_aim7/capture_raw_20260912_161312.txt` (and 8 other capture files)
already contains **plaintext, correctly-decoded inbound Cmd 2002**:

```
... UDP IN PASS MATCH 1 2002 UDP_VEHICLE_STATE_SYNC ...
   r0{v0=37 v1.pos.x=282421 v2.pos.y=8023 v3.pos.z=235592
      v4.aim.x=22 v5.aim.y=366 v6.aim.z=-6 v7.aim.w=930
      v8=8 v9.vel.x=0 v10.vel.y=0 v11.vel.z=0 } ... v12=1 v13.tick=1200
```

That record is exactly `CHOIJILECHG { List<OLEOJNOGCCN>, bool, uint }` — see §7.

---

## 6. Cadence

* Driver: `PNCPKGJGBPP::OPHFNKPJOCI` per module tick, once per autonomous-proxy entity.
* Throttle: `(this->counter@0x660 % 3) == 0`, inside `EFJEIMIIEJO` @ `0x078CDBF4`,
  applying to **all** branches.
* The repo's existing measurement — ~30 Hz driver ⇒ **99 ms** between sends, matching the
  `+99/packet` step in 2001's `v22` — therefore carries over unchanged to 2002/2006/2015/
  2016/2031/2069. This document does not independently re-measure the 30 Hz.
* On the on-foot path only, a second `Send` (Cmd **2055** `UDP_PLAYER_HUD_OPERATE_SYNC`,
  `mov w0,#0x807` @ `0x078CF3AC`) fires in the same tick when
  `CurrentGameModeSetting->byte@0x99c` **and** `GameFacade::IsCustomRoomLeague()`.
  The mounted branches have no such second send.

---

## 7. Inbound counterparts

From `tools/il2cpp/ff_inbound_registry.tsv` (msgid → inbound class → handler), cross-checked
against the `Cmd` enum in dump.cs:

| cmd | enum name | inbound class | note |
|---|---|---|---|
| 2001 | `UDP_PLAYER_STATE_SYNC` | `KGHDCJFHGNP` | `int` + `List<ALCBKBHIOAJ>` + `bool` + `uint` — the batched player broadcast |
| **2002** | `UDP_VEHICLE_STATE_SYNC` | **`CHOIJILECHG`** | `List<OLEOJNOGCCN>` + `bool IDNHFFFKDFB` + `uint DNNFOOGPFHO` — **the batched broadcast of every visible vehicle** |
| 2015 | `UDP_SYNC_CATAPULT` | `HILAABLKGEI` | |
| 2031 | `UDP_SYNC_CANNON` | `LELPELOLODB` | |
| 129 | `RUDP_FORCE_SYNC_VEHICLE_STATE` | `AFOIDEILIGE` | `ushort FAAMLGOPLAC` + `PMFGOGFPDHM` pos + `BJIPILEFOGL` rot + `byte` — a **one-shot authoritative snap for a single vehicle** *(fields from dump.cs)* |
| 136 | `RUDP_SYNC_VEHICLES_VISIBILITY` | `OFMNCKLKCKC` | **a single `ulong` bitmask.** Visibility bits only — **no positions.** Not a position source. |
| 125 / 126 | `RUDP_GETON_VEHICLE` / `RUDP_GETOFF_VEHICLE` | `JKOLBBEFDIB` / `LPIKFAGLDFD` | mount / dismount events — the join between a player and a vehicle id |
| 187 | `RUDP_VEHICLE_CHANGE_SEAT` | `JNMEAHFMNFO` | |
| 269 / 270 | `RUDP_GETON_CHAIR` / `RUDP_GETOFF_CHAIR` | `KBFDFFKJEKB` / `FIGGFOANPMD` | |
| 395 / 396 | `RUDP_GETIN_CATAPULT` / `RUDP_GETOUT_CATAPULT` | `HFGAACKPHDB` / `EDJBJMJDGND` | |
| 701 / 702 | `RUDP_GETIN_CANNON` / `RUDP_GETOUT_CANNON` | `BJEHGGJMKOF` / `PMAJDJOIOMC` | |
| **2006** | `UDP_PASSENGER_STATE_SYNC` | **none registered** | client→server only |
| **2016** | `UDP_SYNC_AIM_ROTATION` | **none registered** | client→server only |
| **2069** | `UDP_VEHICLEWEAPONFIRE_STATE_SYNC` | **none registered** | client→server only |

**Cmd 2002 is bidirectional with a different class per direction** — outbound
`JBECKHDPPOO` (one vehicle), inbound `CHOIJILECHG` (a list of vehicles). This is the
pattern the project already recorded for the registry generally.

### The second ESP blind spot

The inbound 2001 per-player record `ALCBKBHIOAJ` *(dump.cs)* is:

```
byte GDKHFHLAIPJ@0x11; PMFGOGFPDHM MOEFFAIDCBP@0x18; BDOPLCJODBN LFCNHAJBHEE@0x20;
FOENPKFAEOC CCLCIJGALBH@0x28; BDOPLCJODBN AAPGPMPKMBD@0x30; byte BGDMAEFKAFK@0x38;
byte LADGDMGAMBG@0x39; BDOPLCJODBN DIPPKFBIILG@0x40; ushort LPKKPCBKEBA@0x48;
byte MNAFFIEBGAD@0x4A
```

**There is no vehicle handle, mount id, or "is mounted" flag anywhere in it.** So the
inbound player chain cannot tell you *that* a remote player is mounted, let alone which
vehicle they are on. The join has to be built from the event messages (125 `GETON_VEHICLE`
/ 126 `GETOFF_VEHICLE`, 187 `CHANGE_SEAT`, 269/270 chair, 395/396 catapult, 701/702 cannon),
and the live position for a mounted remote player has to come from the **inbound 2002
vehicle list**, keyed by vehicle object id.

**What the binary cannot settle:** whether the server *also* keeps publishing a mounted
player's body position inside the inbound 2001 list (it could synthesise one from the
vehicle), or whether that player's 2001 entry simply goes stale. That is server behaviour.

**How to settle it:** in a capture where a remote player mounts, correlate the 125
`RUDP_GETON_VEHICLE` for their entity id against their subsequent entries in inbound 2001.
If their `MOEFFAIDCBP` stops changing while the matching vehicle id keeps moving in
inbound 2002, the 2001 chain is dead for mounted players and the vehicle chain is mandatory.
This is a pure offline analysis of captures the repo already has.

---

## 8. Corrections to existing docs

### `docs/IL2CPP_FINDINGS.md`, "THREE BUGS IN SHIPPED CODE", item 2

> "`EAIKJCCNGMJ` dispatches on `IsInVehicle()` first: driver → **Cmd 2002**, passenger →
> **Cmd 2006**, another case → **Cmd 2031**, `IsOnChair()` → another class."

The headline ("2001 is never sent while mounted") is **correct and confirmed**. The
breakdown is incomplete and, in one place, misleading:

1. **2031 is not an `IsInVehicle` case.** It is the **cannon** branch, reached only when
   `IsInVehicle()` is *false* (`Player::IsInCannon` @ `0x078CE2F8`). Same for 2015 (catapult)
   and 2016 (chair) — all three are siblings of the vehicle branch, not children of it.
2. **Two msgids are missing entirely: 2015 (catapult) and 2069 (driver-can-fire).**
3. **"driver → 2002" is only true for vehicles whose `CanDriverFire()` is false.** A driver
   whose vehicle grants driver weapon fire — the horse being the only such class in the
   image — sends **2069**, not 2002. This is the single most load-bearing correction in
   this document for the user's case.
4. The chair's "another class" is `message.ECBGLGKBEBH`, **Cmd 2016** `UDP_SYNC_AIM_ROTATION`.

Also worth adding there: the `(counter % 3) == 0` throttle noted under "Refinements" is
inside `EFJEIMIIEJO` and gates **all** of these msgids, not just 2001; and five further
states (`IsOnBoard`, `IsOnFerrisWheel`, `IsFollowing`, `IsPassiveMoving`, `IsOnlineBotAgent`)
suppress the send entirely with no substitute message.

### `tools/il2cpp/ff_outbound_registry_full.txt`

Missing 2002 / 2015 / 2031 / 2069 at site `0x078CE684`, and 2001's class is wrong. See the
boxed note in §2. Any future regeneration should follow the `mov w0, #imm` backwards
across *all* predecessors of a shared `B`-to-`Send`, not just the fall-through one.

### `docs/CLIENT_AUTH_SURFACE.md`

Not re-audited in this pass. Its 2001-centric statements about the manipulable surface are
not contradicted by anything here, but note that the surface is **wider than 2001**: six
further msgids carry client-authored position and/or orientation under the identical
unreliable/unsigned framing.

---

## 9. Explicitly unresolved

1. **Does a horse's `VehicleData` row set `CanDriverFire` (bool at `+0x59`)?** Not in the
   binary — it is CSV asset data. Settled by one mounted capture (§4.3): 2069 ⇒ yes,
   2002 ⇒ no.
2. **Is `GameModeSetting.EnableVehicleDriverWeaponFire` (`+0x23`) on in the mode the user
   plays?** Same test, same capture. It is a per-mode setting, so BR and CS may differ.
3. **No on-wire sample of 2006 / 2015 / 2016 / 2031 / 2069 exists in the repo's captures.**
   `phone_aim6/capture_raw_20260912_162908.txt` appears to contain five such packets, but
   they are almost certainly **header-decode false positives**: they all sit in the
   `MATCH 2` session (a different server, `148.222.88.45`, while the file's mask was solved
   against `MATCH 1`), they carry an `ord=` field (reliable header form), their payload hex
   is high-entropy, and their decoded varints are noise (`2016` showing five fields when the
   class has two; `ord=1900` on a 26-byte packet). Do not treat them as evidence. All other
   295 capture files contain **zero** packets from this family, and every one of the 1 083
   Cmd 2002 records found is **inbound**, i.e. the user has never yet captured themselves
   driving or riding.
4. **Whether the server keeps a mounted player alive in the inbound 2001 list** (§7).
5. `Vehicle::field@0x120` — the object whose `GetObjectID()` becomes `FAAMLGOPLAC`. It is
   presumably the vehicle's `BaseLevelObject`/`LevelVehicle` representation, but this was
   not chased; it matters only if the id in outbound 2002/2069 turns out not to match the
   ids seen in the inbound 2002 vehicle list. One capture of the user driving resolves it.
6. The exact semantics of `Vehicle::GetCurrentPackedOp()` (the `JBOGMCKPKLJ` byte) were not
   decoded — it is constant `8` in the inbound samples we have.

---

## 10. Reproduction

Disassembler used (capstone + `rva_map.txt`, no IDA):
`<scratchpad>/vdisp/vd.py` — `vaddr = file_offset + 0x4000`, symbols resolved by
`bisect` over the sorted RVA map, `bl` targets annotated. Caller search
(`<scratchpad>/vdisp/xref.py`) decodes all `BL` (`opcode>>26 == 0x25`) in `.text` with
numpy in one pass — `0x1DD4D58` instructions, a few seconds.

Key ranges:

| what | range |
|---|---|
| `EAIKJCCNGMJ` (the dispatcher) | `0x078CDD78` .. `0x078CF588` (0x1810 bytes, 1540 insns) |
| `EFJEIMIIEJO` (the gate) | `0x078CDADC` .. `0x078CDC1C` |
| `INCBJGDHGOA` (vehicle velocity) | `0x078CDC1C` .. `0x078CDD78` |
| `BJNKBGDPBAC` (ms timestamp) | `0x078CF3B8` .. `0x078CF588` |
| `OPHFNKPJOCI` (the tick / only caller) | `0x078CF588` .. `0x078CF874` |
