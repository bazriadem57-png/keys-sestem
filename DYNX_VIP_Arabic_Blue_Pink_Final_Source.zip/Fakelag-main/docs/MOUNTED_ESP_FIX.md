# Mounted ESP — the blackout, the cause, and what now happens

**2026-09-15.** User report: *"when I'm riding a vehicle — either a horse or a
car — the ESP and radar disable entirely and don't work; they only work again
when I get off."*

Evidence: `MOUNTED_CAPTURE_ANALYSIS.md` (capture corpus), `VEHICLE_PARSE_SPEC.md`
(binary), `captures/pull_20260915_post_reorg/`.

---

## 1. The cause

`observeChainPacket` assigned the pose fields **after** the self-record's
`continue`:

```java
if (ownEntityId > 0 && ids[r] == ownEntityId) { measureLag(...); continue; }
...
t.aimYawDeg = ...; t.aimPitchDeg = ...; t.poseValid = true;   // unreachable for self
```

`refreshOwnFromEcho` — the whole mounted fallback — opens with
`if (!t.poseValid) return;`.

Cmd 2001 stops the instant you mount. Cmd 2002 carries position and **no aim at
all**. The self-echo was meant to cover the camera, and it bailed on line one.
**The camera basis froze at whatever it held when you mounted**, so every box
and every radar bearing was projected against a stale view for the whole ride,
snapping back on dismount. Boxes and radar die together because both read the
one `enemy*[]` array filled by `EspRenderView.update`.

It hid for so long because `poseValid` **latches true early**: before
`ownEntityId` is known our own record takes the normal path, so the flag is set
and the *angles* then stop updating while the flag stays set. A frozen-but-valid
pose is indistinguishable from a working one — the fifth instance of the pattern
named in `CLAUDE.md`.

## 2. What the wire actually offers while mounted

All measured, `MOUNTED_CAPTURE_ANALYSIS.md` Q1, N = 2 rides / 67 mounted samples:

| quantity | available? |
|---|---|
| our position | **yes** — outbound Cmd 2002 at 99 ms, first-hand, exact |
| our position (echo) | yes — inbound self-echo, ~300 ms lag, within 25–324 mm |
| vehicle heading | **yes** — the quaternion in our own Cmd 2002 |
| **our camera / look direction** | **NO. Nowhere.** |

The echo's *moving* aim field is the vehicle rotation re-encoded (median **0.5°**
from the forward vector of the quaternion we sent, p90 3.5°, 100 % under 20°).
The echo's 3-D camera vector is **byte-identical to its last pre-mount value in
67/67 samples** and stays frozen ~1.3 s past dismount. Velocity, moveDir,
physState and pose are zero throughout.

So the choice is **vehicle heading vs a camera frozen at the moment of
mounting** — not heading vs a real camera. This retracts
`VEHICLE_PARSE_SPEC.md` §5.2 for the mounted case.

## 3. What now happens

**Own-state ladder**, resolved independently for position and direction:

```
position:   2001 > 2069 > 2002 > self-echo
direction:  2001 > 2069 > 2002-quaternion(heading) > self-echo
```

- Heading comes from **our own** quaternion, not the echo's copy: 99 ms vs
  198 ms, exact vs 1.41°/LSB, no round-trip lag.
- **Pitch is set level (0)**, not taken from the quaternion — its vertical
  component is terrain slope, and using it would pitch the overlay on every hill.
- Never extrapolated: a heading is not a view and is quantised besides.
- `MOUNT_VEHICLE_CAMERA` (tune panel **VEH CAM**, default on) turns it off.
- HUD names it: `dir=2002q(heading!)`.

**It is wrong by the free-look angle whenever the rider looks away from the
direction of travel.** That is the honest limit and it cannot be improved from
packets.

## 4. Everything else changed

| change | why |
|---|---|
| pose assigned for every entity, self included | the blackout itself |
| `refreshOwnFromEcho` split `takePos` / `takeDir` | 2002 and the echo both wrote position, fighting at ~5 Hz |
| echo-derived own position sent through the axis map | entity coords get the map, own coords do not — with the map on, own position sat in a different frame from every entity |
| **Cmd 125 / 126 consumed** | authoritative mount signal, replacing a 400 ms silence guess; also the only statement of which player rides which vehicle |
| `mounted()` cleared by any live Cmd 2001 | 2001 cannot be sent while mounted, so a missed/undecryptable Cmd 126 self-corrects in one tick |
| **inbound Cmd 2002 vehicle list consumed** | a remote rider's chain presence drops to ~50 %; this list carries them at the full tick |
| renderer own-state timeout 2 s → 6 s while mounted | that gate removes the overlay rather than degrading it |
| `RENDER_DREW_BOX` moved after the loop | it read `enemyCount` before assignment; `RENDER_BLIND` was firing ~79×/capture, always falsely |
| `NO_AUTHORITATIVE_TEAM` keyed on totals | binds arrive only at match start, so a delta rule fired in every healthy window — 64 false alarms |
| `OWN` HUD row moved above the render gates | it froze at its last good value exactly when the screen went blank |

New alarms: `MOUNTED_NO_CAMERA`, `VEHICLE_PARSE_FAILING`.
New counters: `ESP_MOUNT_{ON_SELF,OFF_SELF,REMOTE,PARSE_BAD}`,
`ESP_VEHICLE_LIST_{PKT,APPLIED}`.

## 5. Inbound Cmd 2002 — the vehicle list

Measured exact on 592/592 packets, 911 records, independently reproduced:

```
body   := listHdr:varint          ; recordCount << 1, even in 592/592
          record x recordCount
          v12:varint  tick:varint
record := id:varint               ; VEHICLE id, never PlayerID-shaped
          x,y,z:zigzag            ; millimetres
          qx,qy,qz,qw:zigzag      ; quaternion x1000  (the parse oracle)
          op:RAW BYTE             ; bit 0x80 = occupied
          vx,vy,vz:zigzag
```

`op & 0x80` set on **0 of 756** unoccupied records and **115 of 155** occupied —
trust a positive, read nothing into a negative. Vehicle ids are shared with
Cmd 125/126 and with our own outbound 2002, which is what makes vehicle→rider
pairing possible. **Seat offset is zero** to within measurement: draw the rider
at the vehicle position, no correction.

Parsing is two-pass — nothing is applied until the whole body validates,
including the terminal cursor — because a half-applied list would teleport some
players and leave others.

## 5b. Confirmed independently by the binary

`MOUNTED_CAMERA_IL2CPP.md`, addresses included there:

- **Q3 is a definitive negative.** The look rotation lives at `Player+0x5B4`,
  rebuilt each frame from `FollowCamera.transform.forward`. The Cmd 2002 branch
  contains **no `GetAimRotation` call at all**, while 2001, 2069, 2016 and 2006
  all have one. The camera exists client-side and is simply never transmitted.
  Binary and capture agree, by completely independent routes.
- **A car can NEVER emit Cmd 2069.** `Vehicle::CanDriverFire` returns 0 and
  `MountableAnimal` is its only override — so 2069 implies a rideable animal.
  The horse's own flag is `vehicleData->byte@0x59`, loaded from an **asset
  bundle** keyed by map and game mode: unknowable from the binary, and only a
  capture can answer it.
- **`Vehicle::IsLocalAuth()` false, or `WaitForForceSync` true, makes the
  dispatcher send nothing at all** — a silent carrier gap right after mounting.
  The 6 s mounted own-state window exists partly for this.
- **`chainEntityId == (PlayerID & 0xFF)`** — the low BYTE, not the low 24 bits.
  The game's own unpacker produces both, and it is the low byte the
  inbound-2001 handler compares against a chain record. This is the general
  join from any PlayerID (Cmd 125/126/101/147) to an entity in our map, with no
  Cmd 118 bind required.

## 6. Not settled

- **No horse has ever been captured.** Zero outbound Cmd 2069 in 2 836 files
  / 3 569 MB; both recorded rides were cars on the 2002 path. Whether a horse
  routes to 2069 (and so carries a real aim vector) is untested, not disproved.
  Riding one and reading the `OWN` row answers it in ten seconds.
- Passenger (2006), chair (2016), cannon (2031), catapult (2015) send **no
  position at all**. The echo is the only source there and is now the only
  thing keeping the overlay alive in those states.
- The corpus cannot confirm a mounted-only fix, because
  `RENDER_DREW_BOX` was broken for the whole capture. Re-capture with the
  counter fixed.
- **Cmd 147 `RUDP_INIT_VEHICLE_STATE` carries a full vehicle roster with each
  vehicle's `{playerId, seat}` occupant list** — a better rider link than
  inferring from Cmd 125/126, and the only one that works when joining
  mid-match or reconnecting. NOT wired: it is reliable and therefore encrypted,
  and all three occurrences in the capture land inside the pre-key window, so
  the schema `(UUZZZZZZZB(UB)SSB)B` could not be validated against a single
  real body. Wiring an unverified parser into rider identity is exactly the
  class of guess this project keeps retracting. Capture one decrypted Cmd 147
  first.
- `PROTOCOL_MASTER.md` §4.5 calls entity-chain fields 10/11 varints; the binary
  says raw bytes. **Measured: the two readings accept exactly the same 6 344 of
  12 452 candidate packets, raw-byte rescues none, and neither field ever
  reaches 0x80** — so the encodings are indistinguishable on all real data and
  the parse was left alone. `ESP_CHAIN_MDST_HIGH` now counts the case that
  would make it matter; a non-zero value there means switch to raw bytes.
