# checkParams (Cmd 106 idx11) -- the canonical zone/body-part field

Scope: which float(s) in the 79-entry checkParams list (FDAEPHMIEPC::LKHKGOFALIB
output, wire idx11 of outbound Cmd 106 RUDP_TAKE_DAMAGE) encode the body part, in
canonical (pre-permutation) order. Ground truth = capture
captures/phone_aim6/capture_raw_20260912_161312.txt, TEA key
27fd2864df6984c5f8436094c0e70def (28 real, unmodified, decision=PASS outbound 106;
28/28 pass the QQ-TEA 7-zero-tail oracle). Binary cites are RVAs in
FF-RE/bin/libil2cpp_dec.so. Marking: PROVEN, INFERRED, UNKNOWABLE(server).

## 0. TL;DR

- The body part is NOT a label or a per-zone multiplier anywhere in checkParams.
  Every checkParams float that is constant-per-zone is zone-INDEPENDENT (same value
  for head/body/limb). PROVEN.
- The zone is carried implicitly, as continuous local hit geometry, in the consecutive
  canonical triple canon[31], canon[32], canon[33] (a Vector3). canon[33] alone fully
  separates all three zones across both test victims: head 0.180, body 0.258, limb
  0.128 (disjoint ranges, section 2). PROVEN.
- That triple is world-position-invariant and victim-invariant (two vic=25 head shots
  56 m apart give the same ~(0.18,0.195,0.18)); it is a hit point normalised against the
  victim collider/mesh bounds -- a body-space hit coordinate. Identity INFERRED (bounds
  pipeline PROVEN present; exact Add index INFERRED).
- Seed for the per-victim permutation is the raw idx0 (full 32 bits, high byte
  included), NOT the masked 24-bit victim id. PROVEN bit-exact (section 3).
- Verdict: this is the field the server would use for the zone, but it is a
  bounds-normalised coordinate the server can recompute from the victim transform it
  holds authoritatively. With the empirical fact that sweeping the wire hit point (idx9)
  1.1-2.5 m did nothing, this is most likely a WALL (~70%), disprovable by one test.

## 1. Method

Program UUUUUZUBUZZZZZZ(F)UFUZBB(B)FBU; checkParams = the (F) list (LEB128 IEEE-754 bit
patterns); idx0 = f[0] raw, victim = idx0 & 0xFFFFFF; idx7 = real zone byte (1=head,
2=body,3=limb). All 28 packets carry n = 79 floats. PROVEN.

Per-victim zone coverage used (multi-zone same victim is the lever):
- vic=3  (idx0 = 0x2000003): 3 limb + 3 head
- vic=25 (idx0 = 0x7000019): 3 body + 1 limb + 2 head

Un-permutation: reproduce the backward Fisher-Yates (xorshift32: x^=x<<13; x^=x>>17;
x^=x<<5; state = seed XOR 0xA3B1C6D9, ->1 if 0) as CHECKPARAMS_DECODE.md section 3.
Forward map is wire[idx[j]] = canonical[j], so canonical[j] = wire[idx[j]]. The zone
field is the canonical index that is (a) stable within a zone across multiple same-zone
hits and (b) takes distinct per-zone values with the SAME canonical index across BOTH
victims.

## 2. Result -- the canonical zone field is canon[31..33] (canon[33] cleanest)

Per-shot values (recovered canonical order, seed = raw idx0):

    zone  vic  seq      canon[31]  canon[32]  canon[33]
    head   3   2203      0.1798     0.1948     0.1804
    head   3   2227      0.1801     0.1948     0.1802
    head   3   2263      0.1803     0.1948     0.1801
    head  25   23471     0.1783     0.1952     0.1814
    head  25   52917     0.1853     0.1938     0.1786
    body  25   23407     0.2621     0.2234     0.2559
    body  25   23417     0.2582     0.2203     0.2607
    body  25   23430     0.2616     0.2166     0.2579
    limb   3   2156      0.1788     0.2622     0.1321
    limb   3   2181      0.0984     0.0969     0.1017
    limb   3   2184      0.1788     0.2622     0.1321
    limb  25   23446     0.1483     0.1422     0.1466

Per-zone ranges pooled over BOTH victims:

    canon[31] head 0.178-0.185  body 0.258-0.262  limb 0.098-0.179  (limb overlaps head)
    canon[32] head 0.194-0.195  body 0.217-0.223  limb 0.097-0.262  (limb spans both)
    canon[33] head 0.179-0.181  body 0.256-0.261  limb 0.102-0.147  ALL THREE DISJOINT

canon[33] is the single index whose head/body/limb ranges are all mutually disjoint.
canon[31..33] is a consecutive Vector3 (one source, added x/y/z). PROVEN.

Independent cross-check: the earlier vic=25 permuted discriminators {39,53,60} invert
(seed = raw idx0) to canonical {32,31,33} -- exactly this triple. (vic=3 {32,53,58} ->
canonical {52,60,50} were world-height fields the raw diff latched onto for that
head-vs-limb pair; pooling both victims isolates canon[33] as the universal one.) PROVEN.

### What canon[54] is (and why it is NOT the field)
canon[54] is a discrete integer: head vic3 = 4/4/4, but head vic25 = 28/0; body =
8/14/18; limb = 17/36/24. It varies per shot AND per victim -> a per-instance
collider/bone id, not a stable zone. A head value on one victim (4) is nonsense on
another (28). Not patchable to a universal head. PROVEN.

### There is no zone multiplier / zone enum in checkParams
The known damage multipliers (head 5.5 / body 1.0 / limb 0.75, config
static_fields+0x308..0x310, PROVEN live in CHECKPARAMS_DECODE.md section 6) do NOT
appear as a per-zone float. Every constant-per-zone float is identical across zones
(e.g. canon[44]=0.75 in ALL zones -- a config constant that merely equals the limb
multiplier; canon[4]=1.0, canon[3]=45.0, canon[6]=1.34, canon[29]=0.4, canon[73]=2.3,
canon[71]=-1.0). No index takes {5.5,1.0,0.75} or a {1,2,3} enum by zone. PROVEN.

## 3. Seed + permutation reproduction (which victim-id form)

Seed = raw idx0 (full 32 bits, INCLUDING the high byte), not idx0 & 0xFFFFFF. Proof:
un-permuting with seed = idx0_raw makes 20 canonical indices bit-identical across all 28
packets (spanning 10 different victims with 10 different idx0 values); seed = idx0 &
0xFFFFFF makes 0 align. Config constants can only line up across different victims if the
seed (hence the whole permutation) is exactly right. PROVEN.

The 20 bit-identical anchors: canon[3]=45.0 (0x42340000), canon[4]=1.0 (0x3f800000),
canon[21]=1.0, canon[71]=-1.0 (0xbf800000), canon[73]=2.3 (0x40133333), plus 15 zeros at
canon[13,27,43,47,48,49,55,58,62,63,65,68,75,77,78].

Note: idx0_raw = (highByte<<24) | victimId24. High byte constant per victim (vic3=0x02,
vic25=0x07, vic44=0x01, vic43/38/33=0x0a, vic40=0x0e, vic19=0x05). Matches
CHECKPARAMS_DECODE.md section 3a: seed = victim PlayerID low-32 reinterpreted (int32
reinterpret of PlayerID) = the whole idx0 word, not the masked display id.

Reference (Python), verified against the capture:

    def xorshift32(s):
        s &= 0xFFFFFFFF; s ^= (s<<13)&0xFFFFFFFF; s ^= (s>>17); s ^= (s<<5)&0xFFFFFFFF
        return s & 0xFFFFFFFF

    def fisher_yates_idx(n, seed_raw_idx0):     # forward: wire[idx[j]] = canonical[j]
        idx = list(range(n))
        s = (seed_raw_idx0 ^ 0xA3B1C6D9) & 0xFFFFFFFF
        if s == 0: s = 1
        i = n
        while i >= 2:
            s = xorshift32(s); k = s % i
            idx[i-1], idx[k] = idx[k], idx[i-1]
            i -= 1
        return idx

Verified wire slots holding canon[31,32,33]:
- vic=3  (idx0=0x2000003): wire slots [61, 72, 15]
- vic=25 (idx0=0x7000019): wire slots [53, 39, 60]  (matches the earlier {39,53,60})

## 4. What the binary says the field IS

Populator FDAEPHMIEPC::LKHKGOFALIB @0x74e208c (returns List<float> at Weapon+0x7e8;
~5000 instr, data-dependent length that here resolves to 79). Named geometry calls
present in the function (PROVEN):

    UnityEngine.Collider::get_bounds (x3)  @0xa89f67c  victim collider AABB
    Player::GetMeshBounds                  @0x712ee70  character mesh AABB
    GCommon.Entity::get_Position (x3)                   victim world position
    Player::GetCharacterHeight/GetCharacterCenterY     stature
    message.KANJBNIANHC::BAAOLAOGICK (x2)   @0x577eba8  Vector3 -> float-triple encoder
    Player::get_MyFollowCamera (x4)         @0x707fb60  camera pitch/yaw/roll
    Player::GetAuxAimRotation, Quaternion::op_Multiply  aim rotation
    GLLLEDKLLDA::CCAIEDHAMOL (x2)                       zone/collider helper class

At 0x74e4d4c-0x74e4ea0 the function reads get_bounds twice + GetMeshBounds, computing
corner sums (fadd sN,sN,sN = center*2 / size) and differences (fsub = min/max). A hit
point normalised against that AABB yields exactly the observed behaviour: a value in
~0.1-0.26 invariant to world position and to which victim was hit, clustering by body
region. Identity: canon[31..33] = the hit point expressed relative to the victim
collider/mesh bounds (body-space / normalised hit coordinate). Bounds pipeline PROVEN;
the precise Add index for the triple is INFERRED (the 79 Adds cannot be ordered reliably
through the branchy 5k-instr body -- identity rests on data invariances + bounds
pipeline). This is geometry the server can reproduce, not a client-chosen tag: a
function of (world hit point, victim transform, victim collider). NOT a bone enum the
server would blindly trust.

## 5. Patch recipe (to forge Head from a Body hit)

Runtime already holds the wire (permuted) list and the seed. To set canonical index j
without a full un-permute/re-permute, write directly to wire[ idx[j] ] where
idx = fisher_yates_idx(79, raw_idx0):

    seed      = idx0_raw                    # full 32-bit idx0 word, NOT masked to 0xFFFFFF
    idx       = fisher_yates_idx(79, seed)
    # head-cluster float bit patterns (pooled head means from section 2):
    canon[31] = 0x3e3916a6  (0.18075)
    canon[32] = 0x3e4760a6  (0.19470)
    canon[33] = 0x3e3874c0  (0.18013)
    write LE float32 to wire slots idx[31], idx[32], idx[33]   # 4-byte float entries

Do this alongside the existing minimal zone flip (idx3-high & idx7 -> 1, idx15 low2 ->
0), and for internal consistency also move idx9/idx10 to the victim head world point. No
re-permute step needed when editing the already-permuted wire in place; if you instead
decode -> edit-canonical -> re-encode, re-apply the scatter (out[idx[j]] = canonical[j]).
Leave canon[54] alone (per-victim collider id -- no safe universal head value).

## 6. Honest verdict -- beatable or wall?

Most likely a WALL. Confidence ~70%.

For (against beatable):
- canon[31..33] is a bounds-normalised coordinate: a deterministic function of the world
  hit point and the victim transform/collider, all of which the server holds
  authoritatively. It can recompute the value and ignore a forged one -- exactly as it
  already ignores the wire zone label.
- Empirically decisive: sweeping the wire world hit point idx9 across 1.1-2.5 m had zero
  effect. If the server derived the zone from wire-reported position it would have moved;
  it did not. The server is not trusting wire geometry for zoning; it uses its own
  raycast/transform. A forged canon[31..33] is more wire geometry from the same
  untrusted channel.
- canon[54] and idx15 both still say body collider; a lone canon[33] edit is
  inconsistent with them and with the server own cast.

Against (why one test is still worth it):
- Unlike idx9 (raw world mm, plausibly redundant telemetry), canon[31..33] is the
  processed, bounds-relative form -- precisely the shape a zone classifier consumes. It
  is the one lever not yet swept. If the server reads the client-supplied normalised
  coordinate instead of recomputing it, flipping canon[33] 0.258->0.180 flips body->head.

Recommended single experiment (cheap, decisive): on a real Body hit, set canon[31,32,33]
to the head bits in section 5 (re-permuted), leave idx9 at the true body point, fire once.
Damage lands as head -> checkParams is trusted (beatable, canon[33] is THE field). Body
damage persists -> WALL confirmed; server recomputes the zone from its own geometry and
no wire edit moves it.

## 7. RVA / index quick reference

    capture             captures/phone_aim6/capture_raw_20260912_161312.txt
    TEA key             27fd2864df6984c5f8436094c0e70def (28/28 tail-ok)
    checkParams length  79 floats (idx11)
    zone field          canon[33] (full separation); triple canon[31,32,33]
    head/body/limb      canon[33] = 0.180 / 0.258 / 0.128
    permutation seed    raw idx0 (full 32 bits), XOR 0xA3B1C6D9, xorshift32 Fisher-Yates
    collider-id NOTzone canon[54] (per-shot/per-victim int)
    populator           FDAEPHMIEPC::LKHKGOFALIB @0x74e208c
    bounds pipeline     Collider::get_bounds @0xa89f67c, Player::GetMeshBounds @0x712ee70
    Vector3 encoder     message.KANJBNIANHC::BAAOLAOGICK @0x577eba8
    verdict             likely WALL (~70%); one patch test disproves cheaply
