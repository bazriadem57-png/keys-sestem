# Security review — 2026-09-18

Read-only audit of the three security surfaces of the Nuvola Rust/live-update
work: the Rust packet core + JNI shim, the FastAPI licensing server, and the
native live-update pipeline. Conducted by subagent, verified in the main thread.

**Headline: no Critical / High / Medium exploitable defect.** Every genuine
finding is Low-severity hardening. Two are fixed in code; two are the owner's
call. The classic failure modes (JWT alg-confusion, SQLi, refresh-token replay,
signature-after-load, downgrade/rollback, key leakage) were all checked and are
**closed** — details at the end.

## Fixed in code

### F4 — `off + len` usize-add could wrap a bounds guard into a slice panic ✅ FIXED
`native/nuvola-core` — every `(buf, off, len)` entry point.

The guard `off + len > total` adds two `usize` before comparing; a caller whose
sum wraps past `usize::MAX` slips it, and the following `&buf[off..off+len]`
panics on `start > end`. With the workspace `panic = "abort"`, that aborts the
whole VpnService rather than unwinding.

*Reachability:* Low. `off`/`len` are framing values from the app's tun loop, not
attacker-controlled packet content, and none of the affected functions is
JNI-wired yet (only `nnSelftest` + `crc7Seal` are exported, and `crc7Seal` is
clean). Fixed pre-emptively before they are wired.

*Fix:* added `nuvola_core::in_bounds(off, len, total)` = `off <= total && len <=
total - off` (no add), routed all 9 sites through it, and gave
`refresh_crc_if_match_traffic` its own guard (it sliced with no local check).
Regression test: `tests/bounds.rs`.

### F2 — unbounded native-lib download; signed `size` never enforced ✅ FIXED
`net/Http.java`, `net/NativeLoader.java`.

`getBytes` buffered the entire response into memory (`ResponseBody.bytes()`)
with no ceiling; the SHA-256 check ran only *after*. A hostile/compromised
origin (or a TLS-pin bypass) answering with a multi-GB body OOMs the loader
thread before the hash can reject it. The manifest carries a **signed** `size`
that was never used.

*Fix:* `Http.getBytes(path, maxBytes)` rejects on `Content-Length > maxBytes` and
enforces the cap while streaming (in case the header lies); `NativeLoader` passes
the signed `size` (bounded by a hard `MAX_NATIVE_BYTES = 16 MiB`) and asserts
`bytes.length == size` before hashing.

## Owner's decision (not changed)

### F1 — `/native/lib`, `/native/manifest`, `/version` are unauthenticated
`server/app/main.py:387-421`.

Unlike `/config`, these have no `_verify_access(authorization)`, so any
unauthenticated client behind the per-IP rate limits (`native` 30/min,
`native_lib` 10/min) can pull the signed manifest and the raw `.so`.

**Why it may be intentional:** the same `.so` ships bundled in the APK, and the
client verifies an Ed25519 signature + SHA-256 before loading, so integrity does
not depend on the transport being authed. The genuinely confidential material
(Bucket-B tables) is delivered only through the authenticated + AES-GCM `/config`
path. So this is "the binary is as public as the APK."

**Decision needed:** if the native core is meant to be license-gated, add
`_verify_access(authorization)` to `native_lib` (and optionally
`native_manifest`). If it is intentionally public, no change — just confirm.

### F3 — seat-cap TOCTOU race in `/auth/activate` ✅ FIXED
`server/app/main.py` (activate) + `server/app/db.py`.

`SELECT COUNT(*) ... active=1` then a separate `INSERT INTO devices` is not
atomic; each request gets its own SQLite connection, so N concurrent activations
for one license with N distinct new fingerprints can all pass the count and
overshoot `max_devices` by up to N-1.

*Mitigations already present:* `UNIQUE(license_id, fingerprint)` blocks duplicate
seats for the *same* device, and the deploy is single-process uvicorn (the race
needs true parallelism). Requires possession of the license key.

**Fix applied:** the cap is now enforced in the write itself — the new-device
`INSERT ... SELECT ... WHERE (SELECT COUNT(*) ... active=1) < maxd` and the
reactivation `UPDATE ... WHERE active=0 AND (SELECT COUNT(*) ...) < maxd`, each
checked via `rowcount != 1 -> 409`. `db.py` adds `busy_timeout=5000` + WAL so
overlapping writers serialize (the loser re-reads the committed count) instead
of erroring. Verified by `server/test_seatcap.py` (cap holds, per-license
independence, reactivation respects the cap, UNIQUE still blocks a duplicate
seat). Still single-process; the "move to shared storage if scaled to
--workers>1" note continues to apply to the rate-limiter.

## Verified CLEAN

- **Rust core:** no `unwrap`/`panic`/`unreachable` on parsed data; the one
  `expect` is on a compile-time constant. Every content-driven reader
  bounds-checks, caps shift at 63 bits, caps list counts, and requires exact
  consumption. TEA decrypt validates block alignment, capacity, pad ≤ 7, and the
  7-zero tail. JNI `GetDirectBufferAddress`/capacity handling is correct.
- **Server:** all queries parameterized (no SQLi); `section`/`abi` allowlisted
  (no traversal). JWT is EdDSA verified with `algorithms=["EdDSA"]` (no alg
  confusion). Refresh: device-binding + PoP checked *before* reuse logic, so a
  lifted token can't trigger a family revoke; genuine reuse revokes the family.
  PoP consumes the nonce before verifying. No raw-secret `==` (hash/index lookups
  + `hmac.compare_digest`). Config delivery: fresh ephemeral X25519 + random data
  key + per-call GCM nonce + one-time `jti` (no replay). `server_keys.json`
  gitignored, untracked, `chmod 600`, prod fails fast, never returned.
- **Live-update:** signature verified BEFORE `System.load` on both paths; the
  pinned Ed25519 key is baked into the APK (not MITM-swappable) and fails closed
  if empty; SHA-256 checked against the signed value; v2 canonical string folds
  `rollout_permille`/`kill`/`url` into the signature; monotonic high-water on
  both load and update blocks downgrade/rollback; validity window fails closed;
  the crash-loop breadcrumb is written with `.commit()` before `System.load`.
