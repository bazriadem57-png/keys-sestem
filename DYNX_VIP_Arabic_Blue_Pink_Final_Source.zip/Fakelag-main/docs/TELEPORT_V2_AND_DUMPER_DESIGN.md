# Teleport-v2 + dumper integration — RE, architecture, and test plans

Scope: (A) a binary-grounded RE of the position/movement/teleport primitives and the
instant-vs-ramp verdict; (B) the teleport-v2 Java architecture (state machine, exact fix
points, the Ghost relationship, the shots-from-anchor caveat); (C) how teleport AND the
Cmd-106 hit-rewrite become observable in the capture/dumper, with two test plans.

Binary work is capstone over `C:\Users\Tonyt\Documents\FF-RE\bin\libil2cpp_dec.so`
(`tools/il2cpp/il2cpp_scan.py`, metadata v31, byte-identical to the shipped image). Layout
facts are cross-checked against `tools/il2cpp/ff_wire_layouts.json`,
`ff_inbound_registry.tsv`, `ff_outbound_registry_full.txt`. Builds on
`docs/TELEPORT.md`, `docs/TELEPORT_KICK_ANALYSIS.md`, `docs/VALIDATION_AND_INBOUND.md`,
`docs/HIT_REWRITE_SPEC.md`, `docs/CHECKSUM_GFHPFJMGEKF.md` — not re-derived here. Tags:
**PROVEN** (read from binary or measured on ≥N captures), **INFERRED** (server-side, not
visible in the client).

---

## A. Position / movement / teleport-primitive RE

### A.0 Verdict (one paragraph)

**A true instant client-commanded teleport is IMPOSSIBLE. The ceiling is the ANCHOR→RAMP
rewrite of the outbound 2001 position stream, bounded by the server distance gate at
≤2.70 m/report (25 m/s at the 2.5 m default).** Every client→server world-position write is
Cmd 2001 (`UDP_PLAYER_STATE_SYNC`) and its mounted siblings; none of them, and no other
outbound message, carries a *destination* the server will honour as a jump. The only
message that can carry a teleport *destination* is **inbound** (server→client): Cmd 144
carries a full corrected transform, Cmd 145 a teleport notification. Their outbound twins
either have **zero fields** (144, PROVEN) or **do not exist** (145 has no client send site,
PROVEN). The client-sendable teleport verbs are all fixed-portal *requests*
(1555 door, 1570/1571 AstrolGate) whose destination the server owns. So the server's belief
can only be *walked*, never *jumped*.

### A.1 The outbound self-position model — 2001 is the sole client-authored world position

**PROVEN.** The position report is built in `COW.GamePlay.PNCPKGJGBPP::EAIKJCCNGMJ`, which
dispatches on `Player::IsInVehicle()` *before* the on-foot branch. Send sites
(`ff_outbound_registry_full.txt:672-673`):

```
2001  078cf1d4  BL JGGMLMNCMAA  PNCPKGJGBPP::EAIKJCCNGMJ+0x145c   on foot
2006  078ce8c8  BL JGGMLMNCMAA  PNCPKGJGBPP::EAIKJCCNGMJ+0xb50    passenger who can fire
```

- **2001** layout is fully decoded and is the one this project rewrites: pos v0-2 (mm,
  zigzag), aim, ground-move, velocity v8-10 (cm/s), platform-id v16, EPHYSXSTATE raw byte,
  EPHYSXPOSE raw byte, v22 wall-clock tick. See `net/PositionSync.java:53-77` and
  `ff-outbound-2001-solved`.
- **2002** (driving) and **2031** (cannon) are the other mounted carriers
  (`net/Cmd.java:371-386`); their outbound bodies are **undecoded** — teleport goes blind
  in vehicles (see B.4). *(Caveat: the 2002/2006/2031 id mapping is from a sibling build and
  `docs/VALIDATION_AND_INBOUND.md §9` flags 2006/2031 as unconfirmed inbound — but the
  dispatch branch itself is real and on-foot 2001 is certain.)*
- No other outbound message builds a world coordinate. The 106 hit-claim carries a hit
  *point* (idx9, mm) but that is a shot geometry field, not a self-position the server
  integrates as movement.

**Nothing else client-outbound can move the server's belief about where you are.** PROVEN.

### A.2 Cmd 144 `RUDP_FORCE_SYNC_PLAYER_STATE` — bidirectional, but the outbound half is empty

**Inbound 144** (server→client) class `PGABPEBFLOK`, handler
`COW.GamePlay.FFMOIGKIEPE::BMJPKGGDEIB` — 13 fields (`ff_wire_layouts.json:13699-13769`):
`entityId(uint)`, a uint, `pos` (type `PMFGOGFPDHM`, mm), **two rotation triples**
(`BDOPLCJODBN` ×2), two pose bytes, ushort, three bools, int, and `DNNFOOGPFHO(uint)` = tick.
**This is the server's correction packet: a full corrected transform.** PROVEN.

**Outbound 144** class `PJEENOJINOA` — `"decl": []`, `"prog": ""` — **ZERO fields**
(`ff_wire_layouts.json:54061-54068`). Built and sent by
`PlayerNetwork::RequestFoceSyncPosition` (RVA 0x0737604c):

```
073761d4  bl  message.PJEENOJINOA::.ctor      ; new empty message, no position args
073761d8  mov w0, #0x90                        ; cmd = 144
073761dc  mov w2, #2                           ; SendOption = RELIABLE
073761e0  mov w3, #1
073761ec  bl  COW.GameFacade::Send             ; send(144, msg, reliable)
```

**CONFIRMED: outbound 144 carries no position — it is a bare "server, please resend my
state" request and cannot teleport you.** PROVEN. (The two callers are
`RequestFoceSyncPosition+0x1a0` and `DANLOINAPHK+0x140`, `ff_outbound_registry_full.txt:67-68`.)

**The inbound-144 apply path (what a rejection does locally).** `BMJPKGGDEIB` @0x07a42b0c
(len 0x208):
- resolves the player by id: `w21 = [msg+0x14]` (entityId) → `BHGGAEEHJCO::LMCLIKOCCJM`
  → `EMKJHAJNPDH::ADNMDEDAEGN` (0x07a42c68) yields the Player object;
- `blr x8` @0x07a42d40 — virtual apply of the transform (vtable slot at obj+0x138);
- `Player::IsLocalPlayer` @0x07a42d50 gate → `Player::GetPhysXState` @0x07a42d60;
- then, only for the local player and only when **not** `get_IsInWater` (0x07a42dac) /
  `get_IsSwimming` (0x07a42dbc) / `IsInVehicleOrHelicopter` (0x07a42dcc), it stamps
  `CurrentGameSimulationTimer.tick` into `player+0x2084` (0x07a42de8-df4).

**So a server rejection = an inbound 144 that force-writes the corrected PhysXState/PhysXPose
onto the local player. That is the snap-back, applied client-side, gated to the local player
and skipped in water/vehicle.** PROVEN. (Consistent with `docs/TELEPORT.md §2`: no *plaintext*
inbound burst in snap windows — 144 is reliable+**encrypted**, the "10+8k channel", so it was
invisible to the plaintext echo analysis.)

### A.3 Cmd 145 `RUDP_TELEPORT_PLAYER` — server→client only, and carries no free position

**PROVEN server-only.** 145 appears in `ff_inbound_registry.tsv:40` (class `BIMJHNICFEF`,
handler `FFMOIGKIEPE.IAFPEDPGFID`) and has **no entry in the outbound registry** — grep of
`ff_outbound_registry_full.txt` for 145 / `BIMJHNICFEF` / `RUDP_TELEPORT_PLAYER` returns
nothing. There is no client send site.

**And even the payload cannot name a destination.** 145 layout prog `UBZBB`
(`ff_wire_layouts.json:14027-14073`): `entityId(uint)`, `bool`, `int`, `bool`, `bool`.
**No position triple at all** (contrast 144, which has one). The `int` (`KGFFNMIAIBE`, zigzag)
is a teleport reason/preset selector, not an XYZ. The class is even shared with Cmd 258
`RUDP_SYNC_GOD` (`ff_inbound_registry.tsv:129`) — a generic small-notification shape.

**So 145 is the server telling the client "entity X was teleported, kind=int"; the actual
new coordinates arrive via the 144 force-sync or `1413 RUDP_S2C_NOTIFY_TELEPORTPLAYER`. It
is not a client-sendable teleport-to-target, and if it were it could not specify where.**
PROVEN. This is the single most load-bearing negative in Part A, and it holds.

### A.4 The other position carriers, and the client-sendable teleport verbs

| cmd | name | dir | note (source) |
|---|---|---|---|
| 129 | `RUDP_FORCE_SYNC_VEHICLE_STATE` | S→C | class `AFOIDEILIGE`; vehicle correction, not seen on wire |
| 1370 | `RUDP_FORCE_SYNC_MOTION_PLATFORM_STATE` | **C→S** | `MatchGame::RequestForceSyncMotionPlatform+0xbc` (`ff_outbound_registry_full.txt:567`) — a resync *request* for a platform, not a destination |
| 1406 | `RUDP_FORCE_SYNC_SCOUT` | S→C | class `GPDHJPKGDOF`; scout-cam correction |
| 1413 | `RUDP_S2C_NOTIFY_TELEPORTPLAYER` | S→C | the teleport-position notify twin of 145 |
| 3583 | `RUDP_S2C_SERVER_AUTHORIZED_SWITCH_PHYSX_STATE` | S→C | 18 fields incl. full transform — physics transitions are server-gated |
| **1555** | `RequestUseIIVTeleportDoor` | **C→S** | `Player::RequestUseIIVTeleportDoor+0x218` (`:622`) — use a fixed in-world door |
| **1570** | `LevelAstrolGate::RequestFirstTeleport` | **C→S** | `:628` — fixed astral-gate endpoint |
| **1571** | `LevelAstrolGate::RequestTeleport` | **C→S** | `:629` — fixed astral-gate endpoint |

**PROVEN pattern: every client-sendable teleport verb is a request to use a *fixed,
server-defined* portal/door/gate. The destination is server-owned; the client picks *which*
portal, never *where*.** None is a free-target teleport. To also rewrite vehicle/platform
position you would need the undecoded outbound layouts of 2002/2006/2031 (and 1370 for
platforms) — see B.4.

### A.5 The gate, and the instant-vs-ramp verdict

**PROVEN (measured, `docs/TELEPORT.md §1`, n=52 release events):** a **distance** gate on the
server's held position — largest accepted **2.77 m**, smallest rejected **5.31 m**
(p=4.5e-5), rejection = snap-back at a hard **399-402 ms**. Not a speed gate (0.97 m/s
rejected at 12.9 m; 13.47 m/s accepted). Normal play never trips it because the server's
belief is refreshed every ~100 ms.

**INFERRED (server-side):** the accept/reject decision itself is not visible in the client;
what *is* visible (A.2) is the correction-apply — the inbound 144 that force-writes PhysX on
rejection.

> **VERDICT — Part A: true instant teleport is IMPOSSIBLE.** No client-outbound message
> carries a jumpable destination (A.1); the only destination-bearing messages are inbound and
> their outbound forms are empty (144) or nonexistent (145) (A.2, A.3); the sendable teleport
> verbs are fixed-portal requests (A.4); and the surface the client *can* author — the 2001
> position stream — is bounded by the ≤2.77 m distance gate per report (A.5). The ceiling is
> the ramp: **≤2.70 m/report hard cap, 2.5 m default = 25 m/s**, exactly what
> `filter/TeleportFilter.java:109-112` already encodes. Instant delivery does not change the
> gate — a jump refused as one packet is refused however it is delivered.

---

## B. Teleport-v2 architecture (Java design, no code)

### B.1 What the owner wants, mapped to primitives

Owner intent, verbatim: *"teleport is the definition of Ghost when turned ON at first (freeze
the reported position, you keep moving freely, everything still registers incl. fire shots);
when turned OFF it should go to wherever the user actually is now."*

That is exactly **ANCHOR (== Ghost freeze) → RAMP (walk to real position) → IDLE**, which the
current `TeleportState` machine already models (`filter/TeleportState.java:14-31`). The design
does **not** need a new mechanism; it needs (a) the re-arm/mounted kick bug fixed, (b) the
vehicle-blind case handled honestly, (c) the Ghost relationship made explicit, and (d) the
shots-from-anchor caveat surfaced in the UX.

### B.2 The state machine (states, transitions, what each emits, metre-delta bound)

```
        press(ON)              press(OFF)                 arrival
 IDLE ───────────► ANCHOR ───────────────► RAMP ───────────────────► IDLE
   ▲   emit: the      │  emit: hold at C      │  emit: rewrite 2001      ▲
   │   first real     │  (frozen, v=0),       │  to cursor along the     │
   │   2001 as the    │  live reports DROP,   │  recorded route, ≤stepM  │
   │   anchor (PASS)  │  route recorded       │  per report (PASS)       │
   │                  │                       │                          │
   └──────────────────┴───────── press = re-arm (RAMP→ANCHOR at C) ──────┘
                                  abort()/shutdown()/disableAll -> release into RAMP
```

| transition | emits on the next 2001 | metre-delta the server sees | button light |
|---|---|---|---|
| IDLE→ANCHOR | the real packet, verbatim (it *is* the anchor A) | 0 | ON |
| ANCHOR hold (each report) | the **held** state at the current belief, v=0 | 0 (server belief unchanged) | ON |
| ANCHOR→RAMP | first ramp step toward the route | ≤ stepM (≤2.70 m) | OFF (self-completing) |
| RAMP step | rewrite 2001 pos+vel to `cursor` | ≤ stepM per report (route-length budgeted, so bounded around corners too) | OFF |
| RAMP→ANCHOR (re-arm) | hold at **C = current cursor** (the belief), v=0 | **0** (must be — this is the bug, B.3) | ON |
| RAMP→IDLE (arrival) | the real packet, unmodified (residual ≤ LAND_EPS 0.75 m) | ≤0.75 m | OFF |

**Invariant that makes it safe:** *what the server currently believes* and *what the next
emitted packet reports* must never differ by more than the per-report budget. The kick (B.3)
is exactly a violation of this invariant on re-arm and on mount.

### B.3 The kick bug and the exact fix points

Root cause (from `docs/TELEPORT_KICK_ANALYSIS.md`, re-verified against the code): the ANCHOR
hold re-sends `anchorPacket` **verbatim**, and `anchorPacket` is assigned **only once**, at
`filter/TeleportFilter.java:304`, capturing position **A**. After a RAMP has walked the
server's belief to **C**, any path that re-enters the verbatim-replay hold sends **A** against
a belief of **C** — a one-packet backward jump of `|C−A|`, which crosses 5.31 m after ~3 ramp
reports and is a guaranteed session-ender after a pause.

Three code paths trigger it; all must hold at the **current belief** (`repX/repZ/repY`), never
at A:

**Fix 1 — re-arm (RAMP→ANCHOR). PRIME.** `filter/TeleportFilter.java:666-678`. Today it moves
`repX/Z/Y` and the route cursor to C (lines 675-678) but leaves `anchorPacket` = A and does
not touch `lastReplayMs`. Then the hold block (`:328-338`) replays A immediately
(`lastReplayMs` is stale → `:332` true on the first tick).
- **Recommended fix (rewrite-hold, cleanest):** add a boolean `holdByRewrite` set true in the
  re-arm branch. In the ANCHOR hold block (`:328`), when `holdByRewrite` is set, do **not**
  call `replayAnchor()`; instead rewrite each live 2001 to `(repX,repZ,repY)` with zero
  velocity via `writeState(repX,repZ,repY)` (`:406`) and PASS it. A rewrite to C is
  known-accepted — the ramp emitted exactly such a packet one tick earlier — and it carries a
  **fresh monotonic tick**, which the verbatim replay does not (`docs/TELEPORT.md §3`: a
  replayed stale tick is dedup-vulnerable).
- **Equivalent minimal fix (stash-last-ramp):** in the RAMP success path
  (`filter/TeleportFilter.java:375-380`, after `ctx.setOutLength(newLen)`), copy the just-
  rewritten bytes into a `lastRampPacket` field (`ctx.copyPayload()` + dip/dp/sp). In the
  re-arm branch (`:674-678`) set `anchorPacket = lastRampPacket` and `lastReplayMs = now`. Now
  the verbatim replay holds at C. (Downside: replays a stale tick, per above.)
- Prefer the rewrite-hold; it also unifies ANCHOR and RAMP on one emit mechanism.

**Fix 2 — mounted mid-ramp. SECONDARY.** `filter/TeleportFilter.java:254-263`. The mounted
branch runs before the ANCHOR/RAMP split, so during RAMP it calls `replayAnchor()` (A) while
the belief is at the cursor. Fix: while `state == RAMP`, **DROP without replaying** (the ramp
resumes on the next on-foot report); while `state == ANCHOR`, if `holdByRewrite` is set the
body is a mounted variant we cannot rewrite, so fall back to DROP-only there too (do not
replay A). Never emit A from this branch.

**Fix 3 — platform-relative mid-ramp.** `filter/TeleportFilter.java:281-290`, same defect and
same fix as Fix 2 (`sync.rawAt(V_PLATFORM_ID) != 0`).

**Fix 4 — the abort/shutdown re-anchor.** `abort()` (`:733-738`) and `shutdown()` (`:774-777`)
already release into the ramp rather than snapping to passthrough — **keep this**. But once
Fix 1 introduces `holdByRewrite`, make sure `land()` (`:748-754`) and the IDLE branch of
`press()` (`:697-700`) clear it, so a fresh ON starts a clean verbatim anchor.

**No change needed** to: `PositionSync.rebuild`'s stale-layout guard (`net/PositionSync.java:256-257`),
the CRC reseal path (`:201-204`, `:291`), or the RAMP route logic (`:451-608`) — those are
sound.

### B.4 The vehicle-blind case, honestly

Teleport can only **rewrite** 2001 (the sole decoded own-position body). While mounted the
position rides **2002/2006/2031** (undecoded), so the ramp cannot rewrite it
(`net/Cmd.java:383-386`, `filter/TeleportFilter.java:249-263`). Design stance:
- **ANCHOR while mounted:** holding still works (a DROP needs no body knowledge) — the belief
  stays pinned. Keep DROP; do not replay A (Fix 2).
- **RAMP while mounted:** cannot walk the belief. DROP and wait; the route keeps its last
  on-foot point (`filter/TeleportFilter.java:249-253` comment), so releasing after dismount
  still converges.
- **To make vehicle teleport work**, the owner must decode the outbound 2002/2006/2031 bodies
  (and 1370 for platforms) — they are unsolved. That is a capture-and-RE task: catch outbound
  2002/2006/2031 with the session key, RE `PNCPKGJGBPP::EAIKJCCNGMJ`'s mounted branches to get
  the field order, then extend `PositionSync` with per-carrier layouts. Until then, honest UX:
  teleport pauses (position frozen) while mounted and resumes on foot.

### B.5 Relationship to GhostFilter — teleport-v2 should subsume it

Today ghost and teleport are separate filters, mutually exclusive at the toggle but chained in
the pipeline: `filter/DefaultFilterEngine.java:59-61` runs **ghost first, then teleport** —
so if both were ever active, ghost's DROP (`filter/GhostFilter.java:270`) starves teleport's
rewrite. The toggles guard against that: `toggle(GHOST)` calls `teleport.abort()`
(`:93`) and `toggle(JITTER)` calls `ghost.stop()` (`:102-104`).

The owner's "teleport-on == Ghost" makes this explicit: **ANCHOR *is* the ghost freeze.**
Recommendation — **teleport-v2 subsumes ghost**:
- ANCHOR uses the ghost hold mechanism (which it already does: verbatim replay,
  `filter/TeleportFilter.java:315-338`; after Fix 1, a rewrite-hold that is behaviourally the
  same "server sees you standing at the anchor").
- "Ghost" as a standalone becomes "teleport that never releases" — i.e. press ON to freeze,
  and to move the frozen spot you press OFF-then-ON at the new location (exactly today's
  ghost off/on re-anchor, `filter/GhostFilter.java:29-33`). This is the same UX the owner
  describes.
- If the standalone GhostFilter is retained for now, the hard rule is **only one filter may
  own the position channel at a time.** Keep the mutual-exclusion in
  `DefaultFilterEngine.toggle` (`:87-107`); do not let both reach `onOutbound`. The ghost-first
  ordering (`:59-61`) is then harmless because ghost is inactive whenever teleport is.

### B.6 The shots-from-anchor UX caveat (state this to the user)

While ANCHORed the server believes you are at the anchor, because the outbound 2001 says so.
Fire, damage, reload and the input stream are never touched
(`filter/TeleportFilter.java:82-88, 239-242`), so **shots still leave the device and still
register** — but the server resolves them from **its** belief of your position, i.e. the
anchor (`ff-aim-bias-disproven`: rewriting the reported aim vector does nothing; the server
uses its own position for you; and `filter/GhostFilter.java:31-33`: "the server checks shot
origin against the reported position, so shooting works from wherever the anchor is").

**Honest UX line:** *"While frozen, you fire from where you froze, not from where you are now.
Close range from the anchor works; the further you walk from the anchor, the more your shots
originate from the wrong place."* This is a property of the server's position authority, not a
bug to fix. (The Cmd-106 hit *zone* is client-authored — see C.2 — but the hit *geometry* the
server may cross-check is tied to your believed position; INFERRED.)

---

## C. Dumper integration + test plans

The capture seam already exists and is sufficient — `dev/capture/CaptureEvent.java` carries
`decision {PASS/DROP/HOLD/REWRITE=3}` (`:22`), `teleType` (`:45`), `filterMask`
(FX_FREEZE/GHOST/JITTER, `:69-71`), `ctrlKind` (`:63`) and `note` (`:51`). The writer emits
one positional line per record ending in free-text `note`
(`dev/capture/CaptureWriter.java:497-567`), and the annotator decrypts+decodes bodies with the
lobby-sniffed key (`dev/capture/CaptureAnnotator.java:186-254`). No seam changes are required;
what follows is what each feature must *set*, and how the offline tools verify it.

### C.1 Teleport in the dump

**Per rewritten 2001 (the RAMP path, `filter/TeleportFilter.java:364-380`).** When the filter
integrates, the call site that records the outbound packet must set on the `CaptureEvent`:
- `decision = REWRITE` (3) — today a rewritten 2001 is recorded as PASS, which hides the edit.
- `filterMask |= FX_JITTER`.
- `teleType = state.ordinal()` (ANCHOR=1, RAMP=2) so the state is a column, not buried in text.
- `note` = before→after: `tele=ramp posA=<x,z,y> posB=<x',z',y'> vel=<vx,vz,vy>
  anchorDist=<|emitted − serverBelief|>m step=<stepM>m left=<dbgRemainM>m`. `serverBelief` is
  the self-echo position the ESP already parses; `anchorDist` is the live safety margin against
  the 2.77 m gate.

**Per held report (ANCHOR, `:328-338`).** `decision = DROP`, `filterMask |= FX_JITTER`,
`teleType = 1`, `note = "tele=anchor held x=<repX> z=<repZ> y=<repY>"`.

**Control events.** `logControl(...)` already emits `MODE_TELE_ANCHOR/RAMP/IDLE`
(`filter/TeleportFilter.java:310-311, 694-696, 753`) → these arrive as `SRC_CTRL` events with
`ctrlKind` (`CaptureEvent.java:63`). Extend the payload string to carry positions:
`TELE_ANCHOR x z y`, `TELE_RAMP fromX..toX budget`, `TELE_RELEASE residual`. The writer
already prints `kind=<ctrlKind>` (`CaptureWriter.java:546-549`).

**The one diagnostic counter (`docs/TELEPORT_KICK_ANALYSIS.md §H1`).** On every emit while
holding, compute `residual = |decode(emitted) − (repX,repZ,repY)| / 1000` m and put it in the
note as `selfEcho=<residual>m`. **It reads 0 during a correct hold and jumps to `|C−A|` the
instant an ON→OFF→ON re-arm replays the stale anchor.** This is the single line that makes the
kick visible in a capture before it disconnects you; a non-zero value on an ANCHOR row is the
bug firing. (After Fix 1 it must stay 0.)

**Offline verification (`tools/ffdump.py`, `tools/ffverify.py`).** Both re-parse the raw file,
solve the header, and re-check the packet the way the server would:
- `python ffdump.py decode <cap> --cmd 2001 --dir OUT -n 5 --hex` prints each rewritten 2001:
  MsgKey, CRC ok/BAD, Length, and the 23-varint body (`ffdump.py:165-197`). A well-formed
  rewrite shows `crc=ok`, Length matching, and the intended pos/vel reading back.
- `python ffverify.py <cap> --only 2001` re-measures the field table: `2001-out` checks the
  body consumes byte-exactly (23+outer), position looks like mm, velocity coherence, and the
  99 ms tick is monotonic (`ffverify.py:160-229`). The teleport-relevant success signature is
  **"0 withheld, N/N re-parse as 23 varints, N/N CRC7 valid, N/N Length valid, pos+vel read
  back as intended"** — the same standard `docs/TELEPORT.md §6b` already proved offline
  (50543/50543).
- `python ffdump.py diff <cap> --split-effect JITTER` splits the capture on the FX_JITTER
  suffix in the phase column (`ffdump.py:138-153`, `CaptureWriter.putPhase:569-590`) and shows
  what changed while teleport was live vs not — the honest before/after.

### C.2 Hit-rewrite (Cmd 106) in the dump — the hard one

106 outbound is **REL + TEA-encrypted**, so the dumper must decrypt before it can show the
rewrite. The machinery already exists:
- `CaptureAnnotator.annotate0` decrypts the body with the lobby key
  (`dev/capture/CaptureAnnotator.java:186-214`), sets `F_DECRYPTED`, and decodes it against the
  **outbound** 106 layout — which is present: `BodyDecoderTable` carries the 22-field outbound
  106 struct (`net/BodyDecoderTable.java:28`, program `>106:`), keyed on `(cmd, outbound)`
  (`:73-74, 182-183`). So a decrypted outbound 106 already renders its fields in `note`.

**What the 106-rewrite call site must record** (per `docs/HIT_REWRITE_SPEC.md`):
- `decision = REWRITE`, `note = "hit=106 zone: <old> -> <new> dmg=<idx3 low24> tick=<idx8>
  idx3hi=<zone> idx7=<zone> idx15=<bodyPart> idx16=<downgrade> token=<unchanged>"`.
- Show the three mutually-derived zone fields changing together: `GMNGCBJMDLB` high byte
  (idx3), `EHNFCMJMPMJ` byte (idx7), and — if the geometry variant is used —
  `LNOIFBAFGOK` (idx15, packed `hitType|colliderBodyId`).
- **Leave the token (idx18 `FHBHMKMHCHJ`) verbatim** and note it: it is a tick-XOR nonce
  (`System.Random`, key = `ASCII(tick)`, `docs/CHECKSUM_GFHPFJMGEKF.md §5a`), so a zone rewrite
  keeps it valid — record `token=intact` so the offline tool can confirm the bytes at +0x68
  were not touched.
- The rewrite path must **re-encrypt** the edited body and **reseal CRC-7** (the same
  reserialize discipline as 2001, `net/PositionSync.java:201-204`, `net/Crc7.java`). Record the
  final `crc` state.

**What the dump must let the owner confirm:** decision=REWRITE fired, old zone → new zone is
Body→Head, damage/tick present, token untouched, and the packet is well-formed
(decrypts, decodes byte-exactly, CRC valid). `ffdump.py decode --cmd 106 --dir OUT` and
`ffverify.py --only 106` (`ffverify.py:352-373`, checks the zone is a legal `ColliderType`
member and the body consumes exactly) do this offline **provided the capture carries the
session key** (`CaptureWriter.writeHeader:723-741` writes `secret_key=`).

**Flag (blocker for C.2):** no existing capture has the session key **and** an outbound 106
together — a fresh live-combat capture with the key present is required before the 106 rewrite
can be verified offline or tested live (C.4). This is a capture task, not a code task.

### C.3 Test plan 1 — teleport on/off/on repro + the counter

Purpose: prove Fix 1/2/3 close the kick, and that the counter reads it.
1. Build with the counter (C.1 `selfEcho` on every ANCHOR/RAMP emit) but **before** applying
   Fix 1, to capture the bug once. Enter a match, press ON, walk ~30 m, press OFF, wait ~1 s
   (let the ramp run), press ON.
2. **Bug signature (pre-fix):** one outbound 2001 on an ANCHOR row with `selfEcho ≈ |C−A|`
   (tens of metres), immediately followed by either a snap-back (an inbound 144, reliable+enc,
   ~400 ms later) or the session dropping to lobby. In the file: an ANCHOR-row 2001 whose
   decoded pos = the original A while the preceding RAMP rows reported ≈C.
3. Apply Fix 1 (rewrite-hold) + Fix 2/3. Repeat the exact sequence.
4. **Fixed signature:** every ANCHOR row shows `selfEcho ≈ 0`; no 2001 ever reports a backward
   jump > stepM; no inbound 144 correction; no disconnect. `ffverify.py --only 2001` reports
   0 withheld and N/N valid across the whole run.
5. Repeat with a vehicle: ON, walk, OFF, mount mid-ramp. Fixed signature: mounted rows are
   DROP (not a replay of A), `dbgMounted` increments, and dismount resumes the ramp with
   `selfEcho ≈ 0`.

### C.4 Test plan 2 — the Body→Head hit-rewrite live experiment

Purpose: settle whether the server recomputes damage from the client-claimed zone, and whether
it geometry-checks. Prerequisite: a capture with the key + outbound 106 (C.2 flag).
Setup (`docs/HIT_REWRITE_SPEC.md §7`): private/duo room, one cooperating victim, one weapon,
fixed engagement distance; land a genuine **Body** hit and rewrite that 106 in place.

- **Hold constant:** idx0 victim, idx4 attacker, idx5 weaponId, idx8 tick, idx9 hit point,
  idx10 hit dir, idx11 checkParams, idx15 bodyPart, idx16/17 markers, idx18 token. Keep firing
  cadence and distance identical trial to trial.
- **Vary (minimal 2a rewrite):** idx3 high byte 0x02→0x01 **and** idx7 0x02→0x01. Recompute
  CRC-7, re-encrypt. Nothing else.
- **Measure:** inbound Cmd **2010** `UDP_PLAYER_HURT` damage for that victim/tick, plus the
  victim's `EPRI_PLAYER_CUR_HP` delta in Cmd **1900**, and watch for a kick/force-sync.

Expected signatures:
- **ACCEPT (zone-only aim works):** 2010 damage ≈ pre-rewrite body value × head/body ratio
  (project prior **2.6–4.2×**). The server recomputes damage from the flipped zone.
- **SILENT-REJECT (geometry cross-check real):** 2010 damage == unchanged body value, no kick
  → the server clamps to body because idx9/idx11/idx15 still describe a body hit. Re-run adding
  the **2c** fields (idx9 head point, idx15 head collider, idx11 head checkParams) copied from
  a captured real headshot; if that is accepted while 2a-only was rejected, the geometry check
  is confirmed.
- **FLAG/KICK:** no 2010 for that shot and/or an inbound 144 `FORCE_SYNC_PLAYER_STATE` /
  transport-kick fingerprint. Distinguish from a route-fallback self-kick by confirming the
  tunnel stayed up.

**Open server-geometry risk (INFERRED, `docs/HIT_REWRITE_SPEC.md §4, §8`):** `checkParams`
(idx11) is a per-enemy, victim-PlayerID-keyed permuted float list (seed XOR `0xA3B1C6D9`),
the prime candidate for a geometry cross-check. If the server re-projects the hit point/collider
against the claimed zone, the hit **point** may need moving to head height too, not just the
zone byte — which is why the second variant copies a real head-shot's full geometry. The token
(idx18) is never touched in any variant; it survives a zone rewrite by construction (A/C2).

**Dumper records for this test:** every outbound 106 as `decision=REWRITE, note=zone old→new,
dmg, tick, token=intact, crc=ok`; every inbound 2010/1900 with decoded damage/HP so the
multiplier is read directly off the file. `ffverify.py --only 106,2010` gives the accept/reject
verdict as hits/total.

---

## Citations index

- Binary (capstone, `libil2cpp_dec.so`): outbound-144 sender `RequestFoceSyncPosition`
  @0x0737604c (ctor `message.PJEENOJINOA` @0x073761d4, `GameFacade::Send` cmd 0x90 @0x073761ec);
  inbound-144 handler `FFMOIGKIEPE::BMJPKGGDEIB` @0x07a42b0c (`IsLocalPlayer` @0x07a42d50,
  `GetPhysXState` @0x07a42d60, water/vehicle gates @0x07a42dac-dcc); 2001 sender
  `PNCPKGJGBPP::EAIKJCCNGMJ` @0x078cf1d4.
- Layouts: `ff_wire_layouts.json` outbound-144 `PJEENOJINOA` :54061 (empty), inbound-144
  `PGABPEBFLOK` :13699, 145 `BIMJHNICFEF` :14027; `ff_inbound_registry.tsv:39-40`;
  `ff_outbound_registry_full.txt:67-68, 567, 622, 628-629, 672-673`.
- Java: `filter/TeleportFilter.java` (:189-202 replayAnchor, :254-263 mounted, :281-290
  platform, :296-313 first-anchor, :304 anchorPacket assign, :328-338 ANCHOR hold, :340-380
  RAMP, :406-449 writeState, :662-701 press/re-arm :666-678, :733-738 abort, :774-777 shutdown);
  `filter/TeleportState.java:14-31, 75-81`; `net/PositionSync.java:53-77, 201-204, 235-295`;
  `filter/DefaultFilterEngine.java:59-61, 87-107`; `filter/GhostFilter.java:29-33, 270`;
  `net/Cmd.java:371-386`; `dev/capture/CaptureEvent.java:22, 45, 63, 69-71`;
  `dev/capture/CaptureAnnotator.java:186-254`; `dev/capture/CaptureWriter.java:497-590, 723-741`;
  `net/BodyDecoderTable.java:28, 73-74, 182-183`.
- Tools: `tools/ffdump.py:138-153, 165-197`; `tools/ffverify.py:160-229, 352-373`.
- Docs: `docs/TELEPORT.md §1-3, §6, §6b`; `docs/TELEPORT_KICK_ANALYSIS.md §H1-H2`;
  `docs/VALIDATION_AND_INBOUND.md §2.1, §9`; `docs/HIT_REWRITE_SPEC.md §2-8`;
  `docs/CHECKSUM_GFHPFJMGEKF.md §5-5a`.
