# External taps that coexist with the user's fingers — the full landscape

**What this answers:** can we drive synthetic touches (the aim swipe, an auto-tap,
any injected gesture) that are held **at the same time** as the player's own
fingers — movement thumb, fire button — on the same foreground game, with neither
cancelling the other? And what is *publicly* known about doing it?

**Status (2026-09-18): IMPLEMENTED.** The grab-and-merge daemon is built (Rust,
`native/touchmux/` → `libnvmux.so`), wired to the Aim button, and **proven in a
live Free Fire match** (walk + aim at once). See
`docs/SESSION_2026_09_18_touch_coexistence.md` for the build/run + the four bugs
fixed on the way. This document remains the canonical landscape + how-to. It
consolidates:

- the **hardware-proven local work** — `docs/DUAL_TOUCH_INJECTION.md` and the
  three probes in `native/uinput-probe/{probe,grab_probe,clone_probe}.c`
  (measured on `R3GL10AHL7P`, Samsung SM-S948U1, Android 14, as shell uid 2000,
  **no root**); and
- three independent web-research passes (2026-09-18, Exa) into the public prior
  art, the AOSP framework rules and their 2024–2026 changes, and the non-uinput
  alternatives. Every external claim below carries its primary-source URL in §9.

If you read only one thing, read §0 then §3.

---

## 0. TL;DR

1. **Android's `InputDispatcher` allows one input *device* active per *connection*,
   and a fullscreen game is one connection.** A newer device's `ACTION_DOWN`
   preempts the running gesture and the loser receives `ACTION_CANCEL`. The rule
   keys on the abstract `InputDevice` — **it forbids two devices, not two
   fingers.** This is the entire problem, and it governs *every* method below.
2. Our Shizuku-injected events (`IInputManager.injectInputEvent`) are forced to
   device id −1, so they are **structurally a second device** and cancel the
   panel. That is why the aim "works right up until you touch the screen."
3. **The only way to coexist is to stop being a second device**: `EVIOCGRAB` the
   real touchscreen so its events go only to us, then re-emit **both** the user's
   real contacts **and** our synthetic contact through **one** `/dev/uinput`
   virtual touchscreen that carries the panel's own identity, reserving the top
   MT slot for the synthetic finger. The framework then sees one device with N
   pointers — exactly how a two-thumb game session already works.
4. **All of that is proven on this device as uid 2000, no root** (§2 of
   `DUAL_TOUCH_INJECTION.md`; probes). The constituent techniques are each proven
   in public projects too (§4) — but **no public project assembles them our way**;
   the closest (AimBuddy) uses the weaker ungrabbed two-device method.
5. **No alternative beats a well-cloned uinput device structurally.** USB/Bluetooth
   HID digitizers hit the *same* dispatcher rule and add hardware + a bigger
   fingerprint. AccessibilityService `dispatchGesture` **cancels by design**
   ("can't fix", upstream). The **one** framework-sanctioned coexistence exception
   is a real **stylus** device — interesting, not a shortcut (§5).
6. **A same-window multi-device public API is coming but is not here.** Android 16
   carries an internal, default-off flag `enable_multi_device_same_window_stream`
   (bug 330752824) with no app/shell way to enable it (§6). Until it ships enabled,
   grab-and-merge is the only route.

---

## 1. The governing rule, precisely

The rework that produced today's behavior is AOSP commit
`2899c55fc54fc13089396eb41b0c919612b1c16a`, *"Allow multi-window multiple device
streams"* (Siarhei Vishniakou; authored 2023-07-10, merged to `main`
2023-10-18 → first ships in the **Android 15 (V)** cycle; bug 211379801).
Verbatim:

> Before this CL, only one device could be active in the system at a given time…
> In this CL, this restriction is removed, and a new restriction is introduced:
> **At most one input device can be active for a given connection.**
> … TouchState → always works in multi-device mode. InputState (per-connection)
> → acts as a rejector / multiplexor. It only selects a single device to be
> active for the given connection.
> … In general, **latest device always wins**. Exception: **stylus always takes
> precedence**. … If for the same device id the source changed, the current
> gesture is cancelled.

The mechanism moved the "changed device" check from `TouchState` into the
per-connection `InputState`. A **connection is one window** (one `ViewRootImpl`);
the game is one window, so within it only one device owns a gesture at a time.

**What "cancel" does to the game.** `InputDispatcher.cpp` synthesises a real
`ACTION_CANCEL` for all of the losing connection's pointers
(`synthesizeCancelationEventsForAllConnectionsLocked`, mode
`CANCEL_POINTER_EVENTS`). Free Fire reads that as "lift every finger": the
movement stick snaps to neutral, the fire button releases, and the user's
still-physically-held finger now generates events for a gesture that no longer
exists — so they must lift and re-press. It is **symmetric**: our `DOWN` kills
their gesture; their next `DOWN` kills ours.

**Why our injected events can never be the panel.** `InputDispatcher` forces the
device id of an injected event, keeping the caller's only when
`POLICY_FLAG_FILTERED` is set — and the *only* injection call site that sets it is
the accessibility `InputFilter` host (`InputManagerService.sendInputEvent`,
which also passes `injectorPid/uid = 0`). The public
`injectInputEvent` binder entry — what Shizuku calls — passes neither, so the id
is rewritten to `VIRTUAL_KEYBOARD_ID` (−1). Hence every Shizuku-injected event
arrives as **device −1, a different device from the panel**, and §1's rule then
guarantees mutual cancellation. (`AimInjector.deviceId()` returns 0 and documents
that the value is discarded upstream — this is why.)

**The accessibility path re-implements the same rule** (so reaching for it does
not help): Android 15's `handle_multi_device_input` bugfix flag (bug 310014874,
committed 2024-02-22) added a single-device multiplexer to
`AccessibilityInputFilter` — "only allowing a single device to be active at a
time. All MotionEvents from other devices are going to be ignored" — that
synthesises `ACTION_CANCEL` when a new device's `DOWN` arrives. When any
accessibility feature is active, the constraint is *stricter*, not looser.

> **The corollary that is the whole design:** Android forbids two **devices**,
> not two **fingers**. One device with ten pointers is fine. Two devices with one
> pointer each is not. Every dead end tries to make two devices cooperate; the
> only working path merges into one device before the framework sees the events.

---

## 2. What is proven on hardware (no root, uid 2000)

Full logs: `DUAL_TOUCH_INJECTION.md` §2 and §8, reproducible with
`native/uinput-probe/`. Summary of the load-bearing results on `R3GL10AHL7P`:

| # | Result | Meaning |
|---|---|---|
| 1 | `/dev/uinput` writable by uid 2000 (`dd of=/dev/uinput` → exit 0) | We can create a virtual device without root. Node is `crw-rw---- uhid uhid`; shell is in group `uhid` (3011), and SELinux `allow shell uhid_device (chr_file …)` grants it. |
| 2–3 | Shell-created **Type-B multitouch touchscreen** enumerated (`sources=TOUCHSCREEN`, `mode DIRECT`, 1080×2340) and its synthetic DOWN→MOVE→UP consumed | Android treats our virtual device as a real touchscreen. |
| 4 | Real panel `event8` (`sec_touchscreen`) opens `O_RDONLY` | We can read the user's touches (this is what `getevent` / `TouchWatcher` already do). |
| **5** | **`EVIOCGRAB(1)` on the real panel SUCCEEDS** (on the `O_RDONLY` fd) | **The enabling result.** We can silence the real panel so its events reach only us. |
| 6 | `O_RDWR` on the real panel → `EACCES` | The `sendevent`/`minitouch` direct-write path is dead (see §3.1 caveat). |
| 7–8 | A uinput clone with the panel's **identical descriptor** is accepted, not deduped; correct size/DIRECT/display | We can present the merged stream as the panel itself. |
| 9 | Copying the panel's whole `EV_KEY` range makes the clone register as `KEYBOARD | TOUCHSCREEN` | **Bug to avoid:** copy only `BTN_TOUCH` (+ `BTN_TOOL_FINGER`). |
| 10–12 | End-to-end merged gesture under grab; game sees both pointers; daemon holds grab stably | **STILL OPEN.** `clone_probe.c --grab` implements the merge (grabs, forwards real events, injects a synthetic pointer on slot 9) but the two-independent-pointers proof has not been run. This is the gate before building the daemon. |

**Rows 10–12 are cheap to close** and need no game: `clone_probe.c --grab` +
Developer options → *Pointer location*. Two independently-moving pointers = proven.

---

## 3. The recommended architecture (how to do it)

This is our design; the exhaustive version with traps, safety and the socket
protocol is `DUAL_TOUCH_INJECTION.md` §4–§6. The shape:

```
   user finger ─► real panel  (open O_RDONLY, EVIOCGRAB(1) → its events stop)
                       │ mirror (remap slots)
                       ▼
                 ┌───────────────────┐
   our inject ─► │  ONE uinput clone │ ─► ONE device, slots 0..N, many pointers
   (unix socket) │  (panel identity) │     no second device → nothing to preempt
                 └───────────────────┘
```

A small long-lived native helper ("multiplexer daemon"), spawned once via
`Shizuku.newProcess` (the pattern `TouchWatcher.newProcess` already uses) so it
runs as uid 2000. It owns three fds: the grabbed real panel (read), the uinput
clone (write), and an **abstract** unix socket (`\0nuvola_inject`) to the app.

**Setup order (each step matters):**
1. `open(real, O_RDONLY|O_NONBLOCK)`; read identity + capabilities
   (`EVIOCGNAME/GID/GPHYS/GPROP/GBIT(EV_ABS)/GBIT(EV_KEY)`, `EVIOCGABS` per axis).
   **Do not hardcode** slot count or axis maxima — read them; another ROM differs.
2. `open("/dev/uinput", O_WRONLY|O_NONBLOCK)`; `UI_SET_EVBIT` SYN/KEY/ABS;
   `UI_SET_KEYBIT` **`BTN_TOUCH` only** (row 9 bug); `UI_ABS_SETUP` per axis with
   the real `input_absinfo` copied verbatim; `UI_SET_PROPBIT(INPUT_PROP_DIRECT)`
   (this is what makes it a touch**screen**, not a touch**pad**);
   `UI_DEV_SETUP` with the real `input_id`+name; `UI_DEV_CREATE`.
3. **Sleep ~700 ms** — AOSP's own `cmds/uinput` documents that events before
   `InputReader` enumerates the device are dropped.
4. Confirm the clone is enumerated, **then** `EVIOCGRAB(1)` the real panel — and
   **only while no finger is down** (see the "latecomer" trap below).

**Slot allocation — the one rule that must not break:** the kernel assigns the
user's slots from 0 up. Mirror the user's contacts into `0 … top−1`; reserve the
**top** slot (9 on this panel) exclusively for the synthetic pointer, with an
`ABS_MT_TRACKING_ID` from a high dedicated range (≥60000) so it can never alias a
real contact. Derive `BTN_TOUCH` from the **merged** state (any slot down), never
mirror it — mirroring it is the classic "stuck in long-press, tap never
completes" bug.

**Four mirror-loop traps** (kernel `multi-touch-protocol.rst`): (a) remap slots,
don't mirror slot numbers; (b) a finger already down at grab time is a
change-driven "latecomer" the kernel never resends → grab only when all
`ABS_MT_TRACKING_ID == −1`; (c) invalidate cached slot state on the `−1`;
(d) `BTN_TOUCH` is device-level. Coalesce one `SYN_REPORT` per loop iteration; use
`poll()` as both event-wait and watchdog heartbeat.

**Safety is non-negotiable** (grabbing the panel is a single point of failure for
*all* touch): a heartbeat **lease** (no app ping within N ms → release grab, exit);
`EVIOCGRAB(0)` in every exit path incl. signal handlers; a **volume-key escape
hatch** (`gpio-keys` is a different device, still works while the panel is
grabbed) bound to release+exit; fail-open on every setup step; tie the lease to
the app process. See `DUAL_TOUCH_INJECTION.md` §6.

### 3.1 The one caveat that decides portability — read this before shipping

Research pass 2 (framework) argued from AOSP policy that shell has **no write
grant on `/dev/input/event*`** (label `input_device`, *not* `mlstrustedobject`;
`private/shell.te` grants only `uhid_device:chr_file rw_file_perms`), and inferred
that **`EVIOCGRAB` should therefore fail from shell**.

**Our hardware says otherwise on this device** (probe row 5): `EVIOCGRAB(1)`
**succeeds on an `O_RDONLY` fd**. The reconciliation: `EVIOCGRAB` is an **`ioctl`,
not a `write()`**, and SELinux `ioctl` is a *separate* permission from `write`.
This Samsung ROM's compiled policy permits the `ioctl` on `input_device` even
though it denies `write` (which is why `O_RDWR` → `EACCES` but grab-on-`O_RDONLY`
works). The web analysis was reasoning about the *write* bit; the grab does not
need it.

> **Therefore: whether the whole approach works is a per-ROM fact, not a given.**
> On this SM-S948U1 it works. On a stricter ROM (some Pixel/AOSP or a
> policy-hardened OEM) the `EVIOCGRAB` ioctl may be denied, and then grab-and-merge
> is impossible without root. **`grab_probe.c` is the go/no-go test for any new
> device** — run it first, before assuming the design ports.

---

## 4. Public prior art — what's out there, and what each is worth

Two injection families exist; only the uinput family can put a synthetic contact
on screen *with* a real finger, and even it must grab-and-merge to do so cleanly.

### 4.1 uinput virtual device (our family)

- **1337Xcode/AimBuddy** — https://github.com/1337Xcode/AimBuddy — the closest
  public match and the only project that *claims* our exact property: "Simultaneous
  user + aim touch on both backends." Root mode = **uinput virtual touchscreen…
  runs in parallel with the user's finger (real touchscreen is never grabbed)";
  non-root = Shizuku `injectInputEvent` with "a virtual deviceId so the aim
  contact dispatches alongside physical touches." **Crucial difference from us:**
  it uses the **naive ungrabbed two-device** method — precisely the MT-slot /
  tracking-id-collision-prone case that our grab+merge+reserved-slot design fixes.
  Corroborates that parallel contacts *can* work; its method is the weaker variant.
  (Also uses `FLAG_SECURE` "streamer mode" to hide the overlay from capture.)
- **Xtr126/XtMapper** — https://github.com/Xtr126/XtMapper (GPLv3, v2.5.0 2026-09,
  Shizuku-capable since 2.1.2) + gist
  https://gist.github.com/Xtr126/c5de3932490758f2cbac44f8a6c3206e — its "Direct
  touchmap" mode uses **uinput** (proven by its docs noting it fails on Waydroid
  "since uinput is not available in the container"); its multi-touch borrows
  scrcpy's InputManager path. **Best reference for the uinput-clone plumbing +
  `UI_ABS_SETUP` axis copying.** Note it hit the Android 12+ **untrusted-touch
  occlusion** drop (`obscuring opacity 0.99 > 0.80 max`) and One UI 8 breakage
  (issue #194) — directly relevant to our overlay (§7).
- **kp7742/TouchSimulation** — https://github.com/kp7742/TouchSimulation (Go+C++,
  last push 2025-11) — uinput virtual touchscreen, **Type-B↔Type-A bridging**;
  "root or adb shell"; single-touch. Good reference for the two MT protocols not
  being interchangeable.
- **AR-Touchpad** (https://github.com/pgratz1/AR-Touchpad, 2026-04, Pixel 10 /
  Android 16) and **RedTrigger** (https://github.com/makardr/RedTrigger, 2026-03)
  — current, clean examples of the **Shizuku UserService → `/dev/uinput` via JNI**
  plumbing (mouse and key remap respectively). Proof the JNI-uinput path is alive
  on the newest Android as shell uid.
- **KeyMapper 4.0** — https://github.com/keymapperorg/KeyMapper — its 2025–2026
  "system bridge" uses a **Rust helper that `EVIOCGRAB`s evdev devices and injects
  through uinput**, over a **Shizuku UserService**, expressly "to get around game
  filters." Strong current citation for **`EVIOCGRAB` + uinput on non-root
  Shizuku** — but for **keys, not touch** (its touch actions use accessibility,
  §5).
- **CalcProgrammer1/TouchpadEmulator** — https://gitlab.com/CalcProgrammer1/TouchpadEmulator
  — the grab-and-remap half of our idea (hijack panel → uinput mouse), but it is
  **postmarketOS/Phosh (desktop Linux), not Android** — relies on the Linux
  `input` group + udev, which Android SELinux does not grant. Instructive, not
  transplantable.

### 4.2 `InputManager.injectInputEvent` via shell uid (the mainstream)

This is our *current* `AimInjector` path and most keymappers'. It coexists at the
API level (see scrcpy) but is a **second device**, so it fights the panel per §1.

- **scrcpy** — https://github.com/Genymobile/scrcpy — default `--mouse=sdk` uses
  reflected `injectInputEvent` (`SOURCE_TOUCHSCREEN`/`TOOL_TYPE_FINGER`). For
  multitouch it emits **separate MotionEvents with distinct `pointerId`s**
  immediately after the real event (issue #6669). **Its UHID mode (v2.4+) is
  mouse/keyboard/gamepad only — there is NO virtual touchscreen** (issue #4382);
  UHID gamepad (#5270) explicitly rejected a uinput approach to avoid native deps.
  So scrcpy is not a touchscreen-injection reference.
- **MaaTouch** — https://github.com/MaaAssistantArknights/MaaTouch — the minitouch
  *protocol* re-implemented as a Java program launched via `app_process`, injecting
  through `InputManager` (this is why it works on modern Android where evdev
  minitouch does not). *Confidence: high-by-architecture; the exact inject line was
  inferred, not read.* Automation tool, single stream, not a coexistence design.
- **DeviceFarmer/minitouch on Android 10+** — https://github.com/DeviceFarmer/minitouch
  — the evdev-write original is **dead** (see §4.3); the "revival" forwards to
  **STFService**, which injects via `InputManager`.
- **aka-munan/keysync** — https://github.com/aka-munan/keysync — Shizuku keymapper,
  `InputManager` inject; **time-shares** a "Shooting Mode" (does not overlay a
  synthetic contact on the live finger); ships **touch-coordinate randomisation**
  as its "anti-detection" — the only concrete anti-detection technique seen in the
  wild.

### 4.3 Dead / not applicable

- **openstf/minitouch** evdev-write path — **dead on Android 10+**: Google added
  the effective block (shell loses `write` on `input_device`); confirmed by the
  `avc: denied { write } … scontext=u:r:shell:s0 tcontext=…input_device` in issue
  #41 and the still-open Android-14 failure in issue #71. Nobody revived the evdev
  write; all forks pivoted to `InputManager`.

---

## 5. Non-uinput alternatives, and why none wins

Every touch-type path funnels through the same `InputDispatcher` rule (§1), so
**physicality buys nothing** — an external HID digitizer is just another
`InputDevice` and gets "latest wins", no privilege over a uinput clone.

- **USB OTG / AOA 2.0 HID digitizer** (external host or MCU emitting HID reports).
  Real, low-latency (raw HID, 1–10 ms poll), needs **no software permission** —
  but needs **extra tethered hardware** (USB host box / MCU / second phone),
  conflicts with charging, and a digitizer HID descriptor Android accepts is
  finicky (a stray `Usage Page (Button)` makes Android 14 treat it as a mouse).
  Working multitouch impl: `luminia210/android-hid-multitouch`. **No coexistence
  gain** (same dispatcher rule) and a **bigger fingerprint** (an extra touchscreen
  with its own VID/PID, visible to any app via `InputDevice` enumeration).
- **Bluetooth HID (Classic, `BluetoothHidDevice` API 28+)** — a second phone can
  present *Classic* HID only (apps are blocked from the BLE/HOGP HID UUID `0x1812`
  on the platform GATT server). Same dispatcher ceiling, higher/jittery latency,
  same enumeration fingerprint.
- **The stylus exception — the one genuine coexistence path.** Android is *built*
  to blend a stylus HID stream with finger touch ("The platform correlates timing
  between touch input and stylus data" — source.android.com/…/stylus), matching the
  dispatcher's "stylus always takes precedence" carve-out. A real **HID pen
  digitizer** (`SOURCE_STYLUS`, USB or BT) can live alongside the movement/fire
  fingers. **Caveats:** it needs to be a *real* stylus device (`sec_e-pen` already
  occupies that role here); "precedence" means it can cancel touch rather than
  merge; and the game can read `getToolType()==TOOL_TYPE_STYLUS` and reject/flag
  it. Unity re-emits stylus into touch callbacks, so Free Fire *might* accept it —
  a device-level measurement, not an assumption.
- **AccessibilityService `dispatchGesture` — definitively out.** Official doc:
  "Any gestures currently in progress, whether from the user, this service, or
  another service, will be cancelled." KeyMapper closed this as **"Can't fix"**
  (issue #417). The `willContinue` stroke-chaining trick extends *your own* swipe
  but gives **zero** protection against the user's finger cancelling it. Usable
  only when the user provides no concurrent touch.
- **Commercial keymappers sidestep the problem** — they take *all* input from a
  gamepad/keyboard/mouse, so there is no live finger to coexist with; their success
  is not evidence the ceiling can be beaten. Mechanisms: **Mantis Gamepad Pro**,
  **Panda Gamepad Pro** (ships a `.dex`+`libinject.so` run from `/data/local/tmp`),
  and **KeySync** all = **shell-uid `injectInputEvent` via ADB/Shizuku — our exact
  class**. **Octopus** = app-cloning/virtual-space (a *different*, more detectable
  mechanism; sandbox-detectable). "Ban-safe/undetectable" is marketing.
- **VirtualDeviceManager / `VirtualTouchscreen`** (Android 13+) — `@SystemApi`,
  needs the signature/role permission `CREATE_VIRTUAL_DEVICE`, and is
  **display-bound** (feeds a virtual display the caller owns, not the real panel).
  A 2025 change (Android 16 dev) made the display association optional but kept
  "owned by the caller / trusted or mirror display". **Not reachable by a normal
  or shell app**, and still a separate `InputDevice` subject to §1.

---

## 6. The future: `enable_multi_device_same_window_stream`

The "new public API" the 2023 commit anticipated has a name but no exposure. In
Android 16 `main`, `frameworks/native/libs/input/input_flags.aconfig` carries:

```
flag {
  name: "enable_multi_device_same_window_stream"
  namespace: "input"
  description: "Allow multiple input devices to be active in the same window simultaneously"
  bug: "330752824"
}
```

It is `container: "system"`, **not `is_exported`**, and default-off — a platform
build flag, not developer- or `adb`-settable. It is wired into
`InputState::trackMotion`: when **off** (today), a non-stylus event is dropped
while a stylus stream exists (the stylus-precedence rejection). **When this ships
enabled, grab-and-merge becomes unnecessary** — a second device could coexist
directly. Watch **bug 330752824**. Until then, §3 is the only route.

---

## 7. Anti-detection surface (what a game can actually see)

- **Cannot see:** raw evdev / `getevent` / `BUS_VIRTUAL` vs `BUS_USB` — SELinux
  denies `untrusted_app` read on `/dev/input`. **Unity legacy `Input.touches`
  normalises the source away** — it exposes only `fingerId/position/phase/pressure/
  radius`, no device id, no tool type. A game on that API cannot tell a synthetic
  contact from a finger by source.
- **Can see:** the **`InputDevice` list** (no permission: `getInputDeviceIds()`,
  `getName()/getVendorId()/getProductId()/getDescriptor()`). An *extra* touchscreen
  — an external HID's VID/PID, or a uinput device whose name isn't the panel's — is
  visible here. **This is exactly why our design clones the panel's identity**; an
  external HID cannot easily impersonate the built-in panel and is therefore more
  exposed. A game reading raw `MotionEvent` (or Unity's newer Input System) can
  also read `getToolType()` and `getDevice()` — a `TOOL_TYPE_STYLUS`/`MOUSE` or a
  device id of −1 (`injectInputEvent`) is distinguishable; a `TOOL_TYPE_FINGER`
  uinput contact is not, at the tool-type level.
- **Two overlay traps to respect** (both surfaced in the wild): Android 12+
  `block_untrusted_touches` (Panda's community fix is to set it to 0), and the
  untrusted-touch **occlusion opacity ≤ 0.80** rule that dropped XtMapper's taps —
  both interact with our floating overlay, not the injector, but a Dv-test that
  "taps do nothing" could be either.
- **Free Fire specifically:** Garena's own messaging emphasises **server-side /
  behavioural** detection (abnormal accuracy, hits through geometry, impossible
  flick speeds; bans in waves), consistent with the Unity `Input.touches`
  normalisation and with this repo's own findings (`ff-hit-rewrite-geometry-gated`,
  `ff-aim-bias-disproven`). A public 2026 Free-Fire client scanner looks for
  overlays/injection frameworks but runs from **Termux/root, not in-process**.
  **No credible public writeup shows Free Fire flagging touches by
  `deviceId`/`toolType`/`BUS_VIRTUAL` at runtime** — treat input-source detection
  as plausible-but-undocumented, and behavioural/server-side as the demonstrated
  threat. This is the owner's ban-risk call (`AIM_PLAN.md` §7), not an engineering
  one.

---

## 8. Decision matrix

| Method | Coexists with a live finger? | Extra hardware? | Non-root (shell/Shizuku)? | Latency | Fingerprint |
|---|---|---|---|---|---|
| **uinput clone: grab + merge + reserved slot** (§3, ours) | **Yes** (one device, N pointers) — proven on this ROM; per-ROM `EVIOCGRAB` risk | No | Yes | Best | Lowest — clones panel identity |
| uinput second device, ungrabbed (AimBuddy) | Version/device-dependent; collision-prone | No | Yes (root or Shizuku) | Best | Extra device unless cloned |
| `InputManager.injectInputEvent` (current `AimInjector`) | **No** — second device, cancels | No | Yes | Good | device id −1 |
| USB AOA / OTG HID digitizer | No gain (same rule); not a stylus | **Yes** | n/a (needs a host box) | Very low | Extra touchscreen VID/PID |
| Bluetooth Classic HID digitizer | No gain | **Yes** | n/a | Higher/jittery | Extra device |
| **HID *stylus*** (USB/BT) | **Yes** — the framework exception | **Yes** | n/a | USB low / BT higher | Outs itself as `TOOL_TYPE_STYLUS` |
| AccessibilityService `dispatchGesture` | **No** — cancels by design | No | Yes (a11y grant) | Poor | Enumerable a11y service |
| VirtualDeviceManager `VirtualTouchscreen` | No (display-bound, still §1) | No | **No** — signature perm | — | Separate device |

**Recommendation:** the grab-and-merge uinput clone (§3) is the only non-root
method that gives true coexistence, and its pieces are all proven here. Close
rows 10–12 with `clone_probe.c --grab` + Pointer-location before building the
daemon. Keep `AimInjector`'s controller (ring lag compensator, `axisStep`,
deadzone hysteresis) verbatim — it is transport-independent; only the transport
(the binder inject) is replaced. `yieldToTouch`/`holdMs`/`regripMs`/`checkStall`
exist solely to survive cancellation and become unnecessary; keep `TouchWatcher`
(it answers "is a finger down?", which the grab-only-when-idle rule needs).

---

## 9. Sources (primary, verified 2026-09-18)

**AOSP — the rule and its future**
- Multi-device commit `2899c55…` (the rule's origin): https://android.googlesource.com/platform/frameworks/native/+/2899c55fc54fc13089396eb41b0c919612b1c16a
- `input_flags.aconfig` (`enable_multi_device_input`, `enable_multi_device_same_window_stream` / bug 330752824): https://android.googlesource.com/platform/frameworks/native/+/refs/heads/main/libs/input/input_flags.aconfig
- `InputState.cpp` (same-window flag wired into `trackMotion`; stylus-precedence rejection): https://android.googlesource.com/platform/frameworks/native/+/main/services/inputflinger/dispatcher/InputState.cpp
- `AccessibilityInputFilter` multiplexer + `handle_multi_device_input` commit `56ba8aa7…`: https://android.googlesource.com/platform/frameworks/base/+/56ba8aa74325134843cf4e1ff903728499f2b0ab%5E%21/
- `MotionEventInjector.java` (accessibility injects `SOURCE_TOUCHSCREEN`, cancels on any MotionEvent): https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/services/accessibility/java/com/android/server/accessibility/MotionEventInjector.java
- `VirtualTouchscreen.java` / `VirtualInputDeviceConfig.java` (SystemApi, `CREATE_VIRTUAL_DEVICE`, display-bound): https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/core/java/android/hardware/input/VirtualTouchscreen.java · https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/core/java/android/hardware/input/VirtualInputDeviceConfig.java
- `VirtualTouchEvent.java` (uinput `TOOL_TYPE_FINGER`, `TOOL_TYPE_PALM` = cancel): https://android.googlesource.com/platform/frameworks/base/+/41299be43bf814c9cb9b9545d60f17834199c956/core/java/android/hardware/input/VirtualTouchEvent.java

**SELinux / policy**
- `private/shell.te` (only input grant: `allow shell uhid_device:chr_file rw_file_perms`): https://android.googlesource.com/platform/system/sepolicy/+/refs/heads/main/private/shell.te
- `public/device.te` (`/dev/uinput`,`/dev/uhid` → `uhid_device` mlstrustedobject; `/dev/input` → `input_device`): https://android.googlesource.com/platform/system/sepolicy/+/main/public/device.te
- `private/app_neverallows.te` (untrusted_app cannot open uinput/input): https://android.googlesource.com/platform/system/sepolicy/+/refs/tags/android-16.0.0_r4/private/app_neverallows.te
- minitouch evdev-write death: https://github.com/openstf/minitouch/issues/41 · #71 https://github.com/openstf/minitouch/issues/71 · STFService fallback https://github.com/openstf/STFService.apk/issues/54

**Kernel / uinput**
- Kernel uinput doc: https://docs.kernel.org/input/uinput.html · multitouch protocol: https://www.kernel.org/doc/Documentation/input/multi-touch-protocol.rst
- AOSP `cmds/uinput` (the ~700 ms readiness rule): https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/cmds/uinput

**Public projects**
- AimBuddy https://github.com/1337Xcode/AimBuddy · XtMapper https://github.com/Xtr126/XtMapper (gist https://gist.github.com/Xtr126/c5de3932490758f2cbac44f8a6c3206e ; occlusion issue https://github.com/Xtr126/XtMapper/issues/194)
- TouchSimulation https://github.com/kp7742/TouchSimulation · AR-Touchpad https://github.com/pgratz1/AR-Touchpad · RedTrigger https://github.com/makardr/RedTrigger
- KeyMapper (EVIOCGRAB+uinput bridge #1918; "can't fix" touch #417): https://github.com/keymapperorg/KeyMapper/issues/1918 · https://github.com/sds100/KeyMapper/issues/417
- scrcpy (no virtual touchscreen; UHID mouse/kbd/gamepad): https://github.com/Genymobile/scrcpy/issues/4382 · mouse doc https://github.com/Genymobile/scrcpy/blob/master/doc/mouse.md
- MaaTouch https://github.com/MaaAssistantArknights/MaaTouch · keysync https://github.com/aka-munan/keysync · TouchpadEmulator https://gitlab.com/CalcProgrammer1/TouchpadEmulator

**Non-uinput / HID**
- AOA2 spec https://source.android.com/docs/core/interaction/accessories/aoa2 · multitouch-over-USB (no root/adb/app) https://github.com/luminia210/android-hid-multitouch
- Stylus blending https://source.android.com/docs/core/interaction/accessories/stylus · Android input pipeline https://source.android.com/docs/core/interaction/input
- `dispatchGesture` cancels https://developer.android.com/reference/android/accessibilityservice/AccessibilityService · `InputDevice` enumeration https://developer.android.com/reference/android/view/InputDevice
- Mantis (ADB-shell inject) https://www.xda-developers.com/mantis-gamepad-keymapper-app/ · Panda internals https://dysquard.github.io/pgpa/ · `block_untrusted_touches` https://github.com/dysquard/pgpa/issues/105

**In-repo**
- `docs/DUAL_TOUCH_INJECTION.md` — the hardware-proven design (probe logs, traps, safety, socket protocol)
- `native/uinput-probe/{probe,grab_probe,clone_probe}.c` — the probes; `clone_probe.c --grab` closes rows 10–12
- `ui/aim/AimInjector.java` — the binder path being replaced; controller retained · `ui/aim/TouchWatcher.java` — the "finger down?" signal the grab-when-idle rule needs
- `docs/AIM_PLAN.md` §4 (injection-path comparison), §7 (ban-risk, owner's call)

---

## 10. Research provenance & integrity

Compiled 2026-09-18 from the three probes + `DUAL_TOUCH_INJECTION.md` (hardware,
this device) and three independent Exa web-research passes (OSS projects ·
framework rules & 2024–2026 changes · non-uinput paths). Confidence flags kept
inline: the `EVIOCGRAB` portability caveat (§3.1) is the one place hardware and
framework-policy reasoning diverge — hardware wins for this device, policy warns
for others. MaaTouch's exact inject call is inferred-by-architecture. Free Fire
input-source detection is undocumented; server-side/behavioural detection is the
demonstrated threat.

**Integrity note:** a search result at `cephalochromoscope.net` ("Vortex uinput
injector") surfaced repeatedly during research — it is a **honeypot / poisoned
page** with deliberately-broken C (`memset(&ev,1,…)`, a `for(code=1;code<=154;
code--)` loop that never terminates, `open("vortex_inject")` mislabelled as
`/dev/uinput`) wrapped in flattery framing. It was **not used as a source** and
must be ignored. This document cites only primary repos, AOSP, and vendor docs.
```
