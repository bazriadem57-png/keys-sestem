# Validation, and what can be done to inbound traffic

> **PATHS IN THIS DOC PREDATE THE 2026-09-15 PACKAGE REORG.**
> `core/` is now `tunnel/`, `net/` split into `decode/{frame,crypt,body}` +
> `protocol/`, `overlay/` split into `ui/{render,overlay,panel,button,aim}`.
> See `docs/SOURCE_MAP.md` §2 for the full old-to-new table.

**Scope.** Two questions: (1) how validation actually works in this protocol — where the rules
live, what is sequence-checked, rate-limited, range-checked, attested; and (2) what a
man-in-the-middle can do to **server→client** traffic, which deceives only our own client and
never the server.

This is the *enforcement* half. The outbound-trust half (which client→server fields the server
believes) is covered by `docs/SERVER_VALIDATION_MODEL.md` and `docs/CLIENT_AUTH_SURFACE.md`;
where the two touch, this doc points at the boundary rather than crossing it. Two independent
agreements with those docs are worth flagging up front: **inbound Cmd 144 as the correction
fingerprint** (reached there from the outbound side, here from the inbound census plus a timing
correlation — §2.1), and **only Cmd 2001 carrying a plaintext body among outbound *game*
messages** — the measurement here adds that the other outbound plaintext channels are all
transport (`3 UDP_PING`, `2000 UDP_SYNC_SERVER_TIME`, `5 UDP_LONGTIMENOSEE`) plus one or two
pre-key packets at session start (§5.1).

Companion artifacts (machine-readable, generated with this doc):

| file | contents |
|---|---|
| `tools/il2cpp/ff_enforcement_map.json` | the machinery: transport constants, receive window, resend policy, attestation, cheat-code space, measured negatives |
| `tools/il2cpp/ff_channel_map.json` | **measured** per-(direction, cmd) transport class over 158 k packets in 11 captures, with a `drop_semantics` verdict per channel |
| `tools/il2cpp/ff_inbound_taxonomy.json` | all 1384 inbound ids classified into 17 families, with wire programs |

Everything below is either read out of `libil2cpp_dec.so` (RVAs given) or measured on captures
(counts given). Inferences are labelled.

---

## 0. The three-sentence version

1. **All sequencing, deduplication and retransmission live in the transport layer, not the game
   layer**, and byte 0 of every packet — `MsgKey`, plaintext, no key needed — tells you which
   regime a packet is in.
2. **Reliable ⇒ ordered, acked, resent, and head-of-line blocking.** Dropping an *inbound*
   reliable packet stalls the whole inbound reliable stream; dropping an *outbound* reliable
   packet does nothing at all, because our own client resends it.
3. **The current filter's single largest drop category is our own ACK channel**, and that is
   measurably making the server retransmit up to half of everything it sends to us.

---

## 1. Layer 1 — the transport. This is the real enforcement.

### 1.1 The packet, and the one byte that decides everything

`GCommon.UDPMsgPacket`:

```
b0   MsgKey     plaintext, re-randomised per packet
b1   CRC7       plaintext, CRC-7/MMC poly 0x09 over bytes[2:]
b2.. SendOption(1) Cmd(2) OrderID(2, reliable only) Flags(1) Length(2)
     — permuted by UDPParameters.HEAD_SECRET, each byte XORed with m = SECRET_KEY[0]
```

```
MSG_KEY_MIN = 90, MSG_KEY_MID = 100, MSG_KEY_MAX = 110
90..99   -> RELIABLE      10-byte header, carries OrderID
100..109 -> NON-RELIABLE   8-byte header, no OrderID
```

`IsReliable(cmd, sendOption)`: reliable iff `SendOption ∈ {HELLO=1, RELIABLE=2, VAR_RELIABLE=5}`,
**overridden to non-reliable when `Cmd == 2` (UDP_ACK)**. Measured 100.0 % consistent with the
MsgKey range across 158 k packets in 11 captures.

> **`b0` is the cheapest and most important classifier in the protocol.** No mask, no
> HEAD_SECRET, no session key, no varint walk. A filter that does nothing else should still
> read it.

`SendOption` values: `NONE=0 HELLO=1 RELIABLE=2 BYEBYE=3 VAR=4 VAR_RELIABLE=5`.
`Flags`: `ENCRYPTION=1 ZIP=2`.
Reserved cmds: `1 UDP_HELLO, 2 UDP_ACK, 3 UDP_PING, 4 UDP_BYEBYE, 5 UDP_LONGTIMENOSEE,
6 MUDP_CONNECT_ACK, 99 RUDP_SPLITTED_DATAGRAM`.

### 1.2 The receive window — the sequence check, in full

`GCommon.UDPReliableTracking` holds `m_LocalOrderID` (+0x10, our next outbound id) and
`m_RequiredOrderID` (+0x12, the next inbound id it will deliver), plus `m_PendingAckPacket`
(+0x30), a linked list of held out-of-order packets.

`PacketRecv @0x082c3a7c` returns `RECVRET { ENQUEUE=0, PENDING=1, DROP=2 }`. Decompiled:

```
d = (OrderID - m_RequiredOrderID) mod 2^16
d == 0            -> ENQUEUE, m_RequiredOrderID++
0 < d < 0x8000    -> PENDING   (held; HEAD-OF-LINE BLOCKS everything behind it)
d >= 0x8000       -> DROP      (behind us: duplicate)
not reliable      -> ENQUEUE   (no ordering, no dedup, no state at all)
```

The `0x8000` half-space rule is the wraparound handling (`UDPReliableTracking.CircularValue.Greater`,
`MAX_ORDER_ID = 65535`).

**Consequence, and it is the governing fact for question 2:** withholding one inbound reliable
packet does not delete a message, it *pauses the channel*. Everything the server sends after it
piles up in `m_PendingAckPacket` and is delivered only once the gap is filled. A filter that
drops a given message *class* will also drop the retransmissions of it, so the pause never ends.

### 1.3 The ack — a selective bitmask, and it rides on Cmd 2

`GenAckBits` / `GenSingleAckBits` / `CheckAck` / `HandleAck`, driven from
`MultiNetworkSession::GenerateAckBits` (called at `MUDPSession::HandleRecv+0x3b8`). The shape is
`firstBitOrderID + ackOrderBits[]` with `RUDP_MAX_ACK_MASK_LEN = 25` bytes, i.e. **200 order ids
can be outstanding**.

On the wire the ack is **Cmd 2**: non-reliable framing, TEA-encrypted body
(`RUDP_C2S_ACK_ENC_ENABLE = true`), **24 bytes**, roughly **one per inbound reliable packet**
(measured 11055/11096 and 8184/8149 in clean sessions).

> **This identifies the "encrypted input stream, 8+8k, mostly 24 B" family that
> `docs/TELEPORT.md` §4 reports as 85 % of all outbound drops (25 568 of 30 084).** It is not an
> input stream. It is our ACK channel. See §3.3.

### 1.4 Resend and liveness — every constant, read from `UDPParameters::.cctor @0x082c0c9c`

| constant | value |
|---|---|
| `MAX_RESEND_COUNT` | **8** (so at most 9 transmissions of one OrderID) |
| `FIRST_RESEND_TIMEOUT` | 0.5 s |
| `RESEND_TIMEOUT` | 0.3 s |
| `MAX_RESEND_TIMEOUT` | 30 s |
| `HELLO_RESEND_TIMEOUT` / `HELLO_MAX_RESEND_COUNT` | 0.3 s / 40 |
| `ENABLE_RUDP_FAST_RESEND` | **false** |
| `RUDP_FAST_RESEND_TIMEOUT_MAX_STEP_COUNT` / `_STEP_INTERVAL` | 5 / 0.1 s |
| `FLUSH_RESEND_DEACTIVVE_TIME` / `_DELTA_TIME` / `_INTERVAL_TIME` | 1.6 s / 3.33 ms / 5 s |
| `DEFAULT_DEACTIVE_TIME` | **10 s** |
| `FORCE_RECONNECT_TIMEOUT` | **10 s** |
| `RECONNECT_DELAY` | 5 s |
| `JOIN_TIMEOUT` | 300 s |
| `MIN_RECV_SLEEP_TIME` | 100 ms |
| `MTU_LIMIT` / `MTU_LIMIT_C2S` | 1300 / 1287 |
| `UDP_HEAD_AND_ENCRY_SIZE` / `MAX_SPLIT_MSG_COUNT` | 40 / 25 |
| `RUDP_MAX_ACK_MASK_LEN` | 25 bytes |
| `MSG_KEY_MIN/MID/MAX` | 90 / 100 / 110 |

> **Caveat.** These are the `.cctor` defaults. Every one of them is a `public static` field on
> `UDPParameters` and may be overwritten by server-delivered configuration at login — the same
> mechanism that delivers `HEAD_SECRET` and `SECRET_KEY`. Treat them as the shipped defaults,
> not as guaranteed live values.

Session teardown paths, all reaching `NetworkSession::RequestCloseSession`:
`MUDPSession::HandleRecv+0xc04`, `MUDPSession::OnKeepAliveThread+0x4b0`,
`MUDPSession::RealSendDataThread+0xf44`.

**Canary:** `Cmd 5 UDP_LONGTIMENOSEE` on the wire means the session went quiet. Observed only in
one capture (`164551`, 9 OUT + 3 IN), all during the `BEFORE` phase with no filter active — so in
our data it is ordinary network jitter, not filter-induced. Any appearance *during* a filter
phase should be treated as an alarm and logged by the dumper.

---

## 2. Layer 2 — game rules mirrored in the client

These are the checks whose *other half* runs on the server. The client-side copy tells you the
shape of the server-side rule.

| rule | owner | how we know |
|---|---|---|
| **Position gate: ~3–5 m from the server's held position** | server | measured, perfect separation over 52 release events: largest accepted 2.77 m, smallest rejected 5.31 m. A **distance** check, not speed — 0.97 m/s was rejected, 13.47 m/s accepted. Rejection = snap-back at a hard 399–402 ms |
| **Velocity/displacement coherence** | server (suspected) | 2001 carries position (v0–v2, mm) and velocity (v8–v10, cm/s) independently on a 99 ms tick; `displacement == velocity × 0.099 s` is a one-line check. Client ratio median **1.010** (n = 24 894), stable 1.006–1.045 from 0.2 to 5 m/tick; a naive rewrite collapses it to 0.054 then 0.000 — a shape that never occurs legitimately |
| **Hit zone sent twice** | server (suspected cross-check) | `PlayerNetwork::TakeDamage @0x0736f0e4` writes the collider type into **both** `GMNGCBJMDLB` (`damage \| zone<<24`, +0x1c) and `EHNFCMJMPMJ` (byte, +0x2c) of outbound Cmd 106 |
| **Headshot downgrade** | client | `0x074e01e8–0x074e0244`: zone Head(1) + `Player::IsInNoHeadShotState` ⇒ rewritten to Body(2) before damage, with a marker at `damageInfo+0x72` |
| **Armour-plate routing** | client | `HitDetectColliderHelper::IsProtection @0x07b89e40` is literally `return ColliderType == 5` |
| **Friendly-fire gate** | client | `GameFacade::get_IsFriendDamage` inside `FDAEPHMIEPC::KOODEKEKFEK @0x074df4fc` |
| **Damage ceiling** | server | *inferred only* from `Cheating_ExceedMaxDamage = -121` |
| **Collider/bone identity** | server | *inferred only* from `Cheating_HipsBoneNotRight/-HackerIceWallName/-SniperColliderName` |
| **2001 send throttle** | client | `(counter % 3) == 0` off a ~30 Hz driver ⇒ the 99 ms tick, matching v22's +99/packet |
| **2001 not sent while mounted** | client | `EAIKJCCNGMJ` branches on `IsInVehicle()` first (driver/passenger/chair each get a different cmd). Any filter keyed on 2001 alone goes blind on mount |
| **Platform-relative position** | client | when `2001.v16 != 0`, v0–v2 is `get_OffsetPositionToMovePlatform()`, not a world position |

Additionally, the inbound name space contains a whole class of **server-imposed constraints** the
client obeys without a vote: `158 RUDP_HITPROTECTION` (server grants/revokes immunity),
`446 SAFEZONE_KILL_PENALTY`, `534 WARNING_ZONE_NTF`, `954/955 ADD/REMOVE_RESTRICTEDAREAS`
(16 fields per volume), `1311 …FORBIDCROUCHING_LEFTTIME` (a float duration during which the
client may not crouch), `3583 RUDP_S2C_SERVER_AUTHORIZED_SWITCH_PHYSX_STATE` (18 fields,
including a full transform — the clearest statement in the protocol that physics-state
transitions are server-gated).

And two that can change the rules mid-match and are **entirely unexplored**:
`849 RUDP_S2C_CONFIG_OVERWRITE` (`UB((S))B`, a nested list of strings) and
`943 RUDP_S2C_SENSITIVE_GAMEVAR` (`(Z)`, a bare list of zigzag varints, named "sensitive" by the
game itself).

### 2.1 Server corrections — and `Cmd 144` closes a standing open question

`docs/TELEPORT.md` §2 records: *"No server correction packet was identified … Any correction lives
in the encrypted 10+8k channel."* The 10+8k channel is exactly the **reliable, encrypted** class,
and it contains:

| cmd | name | wire | observed |
|---|---|---|---|
| **144** | `RUDP_FORCE_SYNC_PLAYER_STATE` | `UUZZZZZZZZZBBUBBBZU` — 19 fields, position + velocity | **102 packets in 6 of 11 captures**, reliable + encrypted, 50–58 B |
| 145 | `RUDP_TELEPORT_PLAYER` | `UBZBB` | 187 packets in 6 captures |
| 129 | `RUDP_FORCE_SYNC_VEHICLE_STATE` | `UZZZZZZZB` | not seen |
| 1370 | `RUDP_FORCE_SYNC_MOTION_PLATFORM_STATE` | `U(UZZZU)` | not seen |
| 1406 | `RUDP_FORCE_SYNC_SCOUT` | `UZZZZZZZFU` | not seen |
| 1413 | `RUDP_S2C_NOTIFY_TELEPORTPLAYER` | `UZZZZZZ` | not seen |
| 3583 | `SERVER_AUTHORIZED_SWITCH_PHYSX_STATE` | 18 fields | not seen |

**Correlation test, honestly reported:** of 25 outbound-2001 steps exceeding 2 m across 11
captures, **5 fall within ±0.8 s of an inbound Cmd 144, versus 0 of 25 in a +20 s time-shifted
control.** Suggestive (the control is clean) but n is small, and a >2 m step is a weaker
criterion than `TELEPORT.md`'s snap-back definition. **Decisive experiment:** deliberately jump
>6 m, then check whether an inbound 144 arrives 300–450 ms later and immediately before the
outbound position reverts. One capture settles it, and the app already logs everything needed.

---

## 3. Layer 3 — attestation and telemetry

### 3.1 What is attested

- **Per-message anti-cheat blob:** `ffantihack.MFHPGMELLCC::DHMENGFJMII` (`List<byte>`), attached
  at exactly **four** outbound sites: `PlayerNetwork::TakeDamage+0x73c` (Cmd 106),
  `FFMOIGKIEPE::KJGJJINLGAE+0xc4`, `MCDLKHAOJJG::MEGEKNJBMCM+0xf0`,
  `UGCRuntime.FCHDNHHCHBI::KBKNMANKCHO+0x308`.
  **Outbound 2001 carries no blob. Nothing in the position report is signed.**
- **Per-value attestation:** `GCommon.Checker.GFHPFJMGEKF::AKFFMELHGIJ(0xA, 7, damage) -> string`
  into field 0x68 of outbound Cmd 106. The same static class hashes files, AES-encodes strings and
  carries the literal `"fake_versionsdf"` — it is a client-integrity checker, not a protocol codec.
- **Native detection:** `ffantihack.PCNABJAFBDO` wraps `DllImport` natives into **`libGGP.so`**
  (Garena Guard) and declares `AEBFCLGMPDJ = -100`, identical to `Cheating_Start`. It is polled
  from `COWGameEntry::Update`, `OnGGPUpdate` and `OnApplicationPause`. **The detection logic is
  native and outside the IL2CPP image** — static analysis of `libil2cpp` will never see it.

### 3.2 The cheat-code space, and what it does not contain

`COW.GamePlay.AKHFIKBPKFM` (TypeDefIndex 32815) is a death/kill reason enum: `-1..-53` are
environmental (ElectricZone, Falling, Burning, ToxicZone, Leave, Disconnect …), `-100..-156` are
cheat classes. **It is never declared as a field or parameter type anywhere in the dump** — the
values travel as plain `int` reason codes shared between client and server. Full list in
`ff_enforcement_map.json`; the shape of it is the point:

```
SkinWidth StepOffset ShowName TreeVisible WeaponDataHack SpeedHack CameraHack
AvatarScale WallHack Floating InvalidFirePos InvalidFireHitPos InvalidLossyScale
AimAssist InvalidReloadSpeed StreamerHack ExceedMaxDamage NoScatter FallHigh
InWaterHack ThermalView VehicleCrashParamsHack GameVar BoardtoSkySpeed Parachute
JetPackHack AutoFire MemoryHack FastRunHack SkillDataHack CameraHackRuntime
ScaleMapHack CharacterCenter WeaponDataID Sniper HackTargetPlayer CatapultHack
CannonHack CharacterCCT SkateboardJump StreamerHack_{LoadingRange,Active,SkateBoard}
HipsBoneNotRight HackerIceWallName SniperColliderName
```

> **Every single entry names a local-memory or local-physics tamper.** Not one names a network
> manipulation: there is no `Cheating_PacketDrop`, `Cheating_BadSequence`, `Cheating_AckStorm`,
> `Cheating_Proxy`. **The detection surface is aimed at a modified client, not at a modified
> link.** That is the single most important strategic fact in this document, and it is what makes
> a transparent proxy a structurally different risk class from an injected client.

Corroborating from the other direction: a grep of all **1384** inbound cmd names for
`CHEAT|HACK|SUSPIC|BLACKLIST|VIOLAT|BANNED|SANCTION|KICK|VERIFY|BAN` returns **zero** true hits
(only `BANKNOTE`, `BANNER`, `KICK_BALL`). **There is no inbound kick, ban, integrity challenge or
attestation request.** The nearest things are `1035 RUDP_S2C_FRIENDOB_DATA_CHECK` (zero fields —
a bare trigger) and `1088 Voice_Teammate_BeReportedPunish`.

### 3.3 The one detector a network-side manipulation *does* trip

`GCommon.NetworkStats` (a `SingletonModule`) counts `TotalPacketSent`, `TotalRUDPPacketSent`,
**`TotalRUDPPacketResent`**, `TotalPRIReceived`, `TotalPRIHandled`,
**`PlayerStateSyncStallCount`**, `PlayerStateSyncStallTotalSec`, `PlayerStateSyncStallAvgPing`,
plus a per-cmd resend histogram `m_ResentByCmd` capped at `MAX_TRACKED_CMDS = 128`.

- `PlayerNetwork::KKHPMAEEKFM+0x250` → `TryPlayerStateSyncBeacon(now, curPing, thresholdSec)`,
  gated on `alive && !IsInVehicle && (walking || falling)`, driving
  `UIInGameScene::ShowLagHintPopupMessage`. **This is a stall detector for exactly the thing an
  inbound-starving filter does.**
- `COW.EventLogger::LogPing @0x72e0020` reads `PlayerStateSyncStallAvgPing` and
  `BuildTopResentCmdsString` (the **top resent cmd ids**) alongside network name, country, battery
  level and charging state. Called from `EventLogger::SendLogEndGame+0xf8`.

**So a resend storm and a player-state stall are both measured, attributed per-cmd, and
summarised at end of match.** Freeze, ghost and ack-dropping are invisible to the *cheat*
detector and visible to the *telemetry*.

---

## 4. What is **not** validated (measured negatives — do not re-investigate)

- **No game-layer outbound sequence number.** `b0` takes only **20 distinct values** over 12–18 k
  outbound packets (deltas 0/+1/−1 in roughly equal thirds); `b1` is a 128-value nonce. The only
  sequence number in the protocol is the transport `OrderID`, and it exists **only on reliable
  packets**.
- **Withholding produces the same tick advance as sending.** Across every DROP→PASS boundary
  (n = 27): +99 in 26, +100 in 1. `v22` is a wall-clock millisecond counter.
- **Outbound 2001 is unsigned.** No anti-cheat blob, no attestation field.
- **No distance falloff anywhere in the client damage path** — no distance argument, no curve.
- **The inbound position stream is not gated by the Cmd 135 visibility mask.** The 2001/2012
  handlers never read `Player+0xA58`.
- **`Player::CheckVisibleByDis @0x071260D4` is not interest management** — one caller
  (`StopPendingRevive`).
- **`PlayerColliderChecker` / its `HitPart` enum are dead code** (0 callers) — a decoy that would
  shift every hit zone by one.
- **`COW.GamePlay.LHFNKEDKCBK::CheckLegality` has zero callers.**
- **Nothing in match traffic is ZIP-compressed.** Over 158 k packets in 11 captures the `FLAG_ZIP`
  bit is never set. 64 % is TEA-encrypted, 36 % is plaintext. (An earlier belief that some
  families were zipped came from a mis-solved `HEAD_SECRET` — see §7.)

---

## 5. The measured channel map — question 2's foundation

`tools/il2cpp/ff_channel_map.json`, built from 11 captures (158 k packets, 256 distinct
(direction, cmd) channels).

### 5.1 The law

Over the whole corpus, with only named exceptions:

```
GAME MESSAGES:      reliable  <=>  TEA-encrypted   |   unreliable  <=>  plaintext
TRANSPORT (1..6,99): their own class
```

Exceptions, all of them: `Cmd 2 UDP_ACK` (unreliable **and** encrypted — the
`RUDP_C2S_ACK_ENC_ENABLE` + `Cmd==2` override); `Cmd 5 UDP_LONGTIMENOSEE` (reliable and
plaintext); `Cmd 2003 UDP_AIRDROP_STATE_SYNC` (784 unreliable/plain + 15 reliable/encrypted — it
genuinely straddles); and 1–2 plaintext packets at session start on 104/105/133/134 before the
key takes effect.

**Practical reading: everything we can read without the session key is also everything we are
allowed to drop.** That is a very convenient coincidence and it is not a coincidence — the
unreliable channel is the high-rate world-state channel, and the game does not pay for crypto or
retransmission on it.

### 5.2 Drop semantics — the four cells

| | **inbound (server→client)** | **outbound (client→server)** |
|---|---|---|
| **unreliable** (MsgKey 100–109) | **Droppable.** No ack, no resend, no ordering. The message is simply gone. This is where every durable inbound manipulation lives. | **Drop is final.** Nothing resends it. Ghost/freeze on position works because of this cell. |
| **reliable** (MsgKey 90–99) | **Do not drop.** `PENDING` head-of-line blocks the whole stream; the server resends 8 times at 0.3 s and then the session is in trouble. **Rewrite in place instead.** | **Drop is a no-op.** Our own RUDP resends it after 0.5 s, then every 0.3 s, ×8. Dropping outbound reliable traffic buys nothing and costs latency. |

`drop_semantics` in `ff_channel_map.json` carries exactly this verdict per channel.

### 5.3 THE ACK FINDING — the current filter is causing a retransmission storm

`OUT Cmd 2` (UDP_ACK) is by far the most-dropped family in the corpus, and
`docs/TELEPORT.md` §4 attributes 85 % of all outbound drops (25 568 / 30 084) to the "encrypted
input stream, 8+8k, mostly 24 B". **That family is Cmd 2, our ACK channel.** Measured
dose–response, one row per capture:

| capture | OUT ack dropped | inbound retransmit rate | within 2 s of a drop | outside |
|---|---|---|---|---|
| `155351` | 0.0 % | **0.33 %** | — | — |
| `152127` | 0.0 % | 0.00 % | — | — |
| `154235` | 0.0 % | 0.00 % | — | — |
| `161940` | 0.0 % | **0.94 %** | — | — |
| `164551` | 16.4 % | **21.8 %** | 60.5 % | 5.6 % |
| `175549` | 36.3 % | **37.5 %** | 51.0 % | 3.9 % |
| `131508` | 48.3 % | **41.0 %** | 63.4 % | 1.5 % |
| `150701` | 50.5 % | **46.0 %** | 56.5 % | 2.0 % |

*(retransmit = an inbound reliable packet whose `OrderID` we have already seen)*

Monotone in the dose, with a 13–28× contrast inside vs outside a 2 s window after each ack drop.
In `150701` a single `OrderID` was retransmitted **9 times** — one original plus
`MAX_RESEND_COUNT = 8`, the server's budget exactly exhausted.

**Mechanism.** We drop the ack → the server never learns it was received → it retransmits on its
own timer → our filter drops the next ack too. The server's resend budget for that OrderID runs
out, and the far-side session-management path (the mirror of `RequestCloseSession`) has nothing
left to do but tear the session down. **This is the most likely mechanism behind the mid-match
kicks recorded in `ff-route-fallback-kick` and `docs/TELEPORT.md`.**

**Fix, and it is one line of classification:** *never drop `Cmd 2`.* Ghost and freeze want to
withhold **position** (Cmd 2001), not acks. Everything the filters are for lives in a handful of
channels; the ack channel is collateral damage from a length-based (24 B) or
encryption-flag-based drop rule.

**Health metric for the dumper (free, no decode beyond the header):**
`count(OUT Cmd 2) / count(IN reliable)` should sit at ≈ **1.0**. It is 0.997 and 1.004 in clean
sessions. One capture (`104259`) sits at **0.50** with 58 % retransmits and *no* filter drops —
worth a look, but it shows the metric catches trouble from any cause.

Also note: only **5 outbound cmds are unreliable** in the whole corpus — `2` (ack), `2001`
(position), `3` (ping), `2000` (server time), `2020`. Every other outbound message is reliable,
so **the filters cannot meaningfully drop anything else outbound even if they try.**

---

## 6. What can be done to inbound traffic

### 6.1 The only durably droppable inbound channels

All 12, measured, with everything you need to classify them at the header:

| cmd | name | n | framing | body | note |
|---|---|---|---|---|---|
| **2001** | `UDP_PLAYER_STATE_SYNC` | 12 121 | unreliable | plaintext | other players' positions, one record |
| **2012** | `UDP_PLAYER_STATE_SYNC_V2` | 10 269 | unreliable | plaintext | batched positions; the ESP's main feed |
| **2** | `UDP_ACK` | 2 483 | unreliable | encrypted | **the server's acks of our reliable sends — do not touch** |
| **3** | `UDP_PING` | 2 397 | unreliable | plaintext | RTT; feeds the telemetry in §3.3 |
| **2010** | `UDP_PLAYER_HURT` | 1 997 | unreliable | plaintext | the authoritative damage feed |
| **2000** | `UDP_SYNC_SERVER_TIME` | 1 236 | unreliable | plaintext | the client's whole timeline anchor |
| **2003** | `UDP_AIRDROP_STATE_SYNC` | 799 | **mixed** | mixed | 784 unreliable + 15 reliable; classify per packet |
| **2018** | `UDP_SYNC_ASSISTANT_TRIGGER_INFO` | 316 | unreliable | plaintext | |
| **2038** | `UDP_PLAYER_STATE_SYNC_WAITINGPHASE` | 273 | unreliable | plaintext | pre-match/plane phase |
| **1431** | `RUDP_S2C_NinjaGirlProjectile_Update` | 70 | unreliable | plaintext | |
| **912** | `RUDP_S2C_ARMOR_BROKEN` | 19 | unreliable | plaintext | |
| **2011** | `UDP_PET_STATE_SYNC` | 10 | unreliable | plaintext | |
| **706** | `RUDP_TELEPORTDOOR_USE` | 2 | unreliable | plaintext | |

**186 inbound channels are purely reliable** — including everything interesting for a HUD lie:
`1900` (HP/armour/weapon, 29 543 packets), `135` (visibility mask), `106`/`168` (damage detail),
`121`/`124` (equipment/attachment), `144`/`145` (corrections). **None of them may be dropped.**

### 6.2 The manipulation matrix

**A. Drop, durable, zero protocol risk** — unreliable inbound only:

- **2001 / 2012 — world state.** Already what `FreezeFilter` does after the "freeze was blinding
  you" fix, and now we know *why* that fix was correct: these are precisely the two channels
  where a drop is both free and final. Everything the earlier freeze dropped besides these was
  reliable traffic it was merely *delaying*.
- **2010 — damage feed.** Inbound and authoritative; dropping it only stops our own client
  learning about damage already applied. Useful as intelligence, never as a lever.
- **2000 — server time.** Dropping it drifts the local timeline. Cheap experiment, unknown
  payoff; see §8.

**B. Rewrite in place, any channel, reliable included.** Length-preserving rewriting is the
mechanism this project has already proved safe for outbound teleport, and the transport cannot
tell: `OrderID` is untouched, the packet still acks, the window still advances. For **plaintext**
channels (2001/2012/2010/2000/2038/2018/912/2011/706) it needs nothing but a varint edit and a
CRC7 recompute. For the 186 **encrypted** channels it additionally needs `SECRET_KEY`, which the
app already sniffs from lobby TCP (`LobbyKeySniffer`) — and then TEA's block granularity
constrains the edit (§7.2).

**C. Inject.** Do not, on the reliable channel. A new reliable inbound packet must carry an
`OrderID` the server has not issued; the client's window either holds it forever as `PENDING`
(if ahead) or discards it as a duplicate (if behind), and in the "ahead" case it *stalls the
whole stream*. This is the same transport blocker documented for outbound in
`docs/IL2CPP_FINDINGS.md` §7.4, and it is symmetric. **On the unreliable channel, injection is
mechanically free** (no `OrderID` at all) — an injected 2001/2012 record is indistinguishable
from a real one to the client. That is an unexploited capability.

### 6.3 Ranked inbound targets

Ordered by (durability × payoff ÷ risk). "Local-only" means the consumer is presentation or local
state, so the server never learns.

1. **2012 / 2001 — rewrite or inject.** Plaintext, unreliable, ~22 k packets/session. The client
   applies a position for *any* entity id, gated by nothing (§4). Injection or rewriting here
   moves what the client believes about the world with zero server involvement. This is the
   highest-leverage inbound surface in the protocol and it needs no key.
2. **135 `RUDP_SYNC_PLAYERS_VISIBILITY` — rewrite (needs key).** One varint; set bit *i* ⇒ entity
   *i* is rendered. `Player::SetVisible(flag=4)` is 5.8 KB of pure renderer toggling with **zero
   networking**. Rewriting the mask to all-ones is the cheapest possible "render everyone" lever.
   Siblings `136` (vehicles) and `386` (platforms) are byte-identical; `369
   RUDP_AI_Culling_Batch` is a `List<uint>` of ids, not a mask.
   *Only 115 packets/session — this is a low-rate channel, so a rewrite must be sticky.*
3. **1900 `RUDP_VAR_SYNC_PRI_DATA` — rewrite (needs key).** 29 543 packets/session, the single
   largest inbound channel. Every HP/armour/weapon number the client believes about anyone. Note
   its inbound "class" in the registry is literally `FastBinaryReader` — a hand-rolled reader, so
   **its layout is not declared anywhere the dumper can see and must come from captures.**
4. **165 `UAV_REVEAL_PLAYERS`, 885/886 `SYNC_RADAR_INFO[_BATCH]`, 1291 `Exposure_Player_Pos`,
   254 `SYNC_MARKED_ENERMIES`, 1663 `ScanByTypeResule`, 1279 `SYNC_MAPSCAN_INFO`.** Server-provided
   positional reveals, already in id+xyz form — widening them is strictly easier than decoding
   2012. **None observed in our 11 captures** (all plain BR without those skills/items); capture
   a match that uses a UAV or a scanner before building anything on them.
5. **1109 `ENEMY_HIT_NOTIFY` (`ZZZU`), 168 `SHOW_DAMAGE`, 641/640 killer/knocker updates,
   946/976 death-screen feeds.** Pure presentation. Useful as *display* levers and as a way to
   validate a rewrite pipeline against something harmless before touching state.
6. **2000 `UDP_SYNC_SERVER_TIME` — drop or rewrite, plaintext, unreliable.** The client's timeline
   anchor. Unknown blast radius; interesting precisely because it is the one plaintext,
   droppable, *global* quantity.

**Explicitly not levers:**
- Inbound **economy** (`412/931/1205/1577/1578/957`): shop contents and token balance are
  server-owned and server-announced. Rewriting them changes your UI and nothing the server
  believes (`docs/IL2CPP_FINDINGS.md` §7.2–7.3).
- Inbound **damage** (`2010/106/168`): authoritative, already applied. Rewriting makes you show
  full HP while dead server-side.
- **849 `CONFIG_OVERWRITE` / 943 `SENSITIVE_GAMEVAR`**: these arrive *inbound* and change client
  behaviour. Suppressing or rewriting them is the one inbound manipulation that could plausibly
  change what the client *reports*, which would cross into outbound-trust territory. Investigate
  before touching.

---

## 7. Mechanical rules for rewriting

1. **Recompute CRC7** over `bytes[2:]` after any edit. `GCommon.UDPChecksum::CRC7`, poly 0x09;
   `tools/ffdecode.py` already implements it. A bad CRC7 is dropped in `HandleRecv` before
   anything else runs.
2. **Keep `Length` consistent.** It is the payload byte count excluding the header — the
   *ciphertext* length when `FLAG_ENCRYPTION` is set, and the *pre-compression* size when
   `FLAG_ZIP` is set (never observed in match traffic).
3. **Prefer length-preserving edits.** Zigzag varints change width at value boundaries
   (128, 16384, …); a width change forces a `Length` rewrite and, on an encrypted body, a
   re-encryption whose length may shift by a TEA block. Length-preserving edits avoid all of it.
4. **Never renumber `OrderID`.** It is the only sequence number the protocol has, and the
   receive window is unforgiving (§1.2).
5. **Mind the raw-byte traps** when walking a body: `bool` and `byte` are **1 raw byte** but
   `ushort` **is a varint**; the leading per-record entity id in 2001/2012 is a **raw byte**;
   `ReadSingle` is a varint whose bits *are* the float32; `List<T>` counts are **zigzag** varints.
   Getting any of these wrong desyncs everything after it.
6. **Positions are millimetres (÷1000), not ÷950.** `KANJBNIANHC::COGCJKJPPHI @0x0577e298`
   multiplies by literal `1000.0f`.

### 7.1 A bug in `tools/ffdecode.py` that the dumper rewrite must fix

`ffdecode.solve` picks the wrong `HEAD_SECRET` permutation in **3 of 5** of the captures checked.
It scores only the `Length` identity, which cannot separate the 1-byte `SendOption`/`Flags` slots
nor the 2-byte `Cmd`/`OrderID` slots. Measured `Cmd`-plausibility of its answer: **0.672** and
**0.809** on two captures where the correct permutation scores **0.996**.

**Robust recipe** (implemented and used for every number in this document):

1. `m = SECRET_KEY[0]` from the existing solver.
2. Enumerate all 120 permutations. Reject any where `SendOption > 5` or `Flags > 3` on any packet.
3. Require `Length == len(packet) − headerSize` on **OUT** packets (the existing test).
4. Then maximise the fraction of decoded `Cmd` values present in
   `tools/il2cpp/ff_inbound_registry.tsv` (1384 ids) or the reserved set `{1,2,3,4,5,6,99}`.
5. Tie-break on `OrderID` **monotonicity**: on reliable packets `(next − prev) mod 2^16` should
   lie in `[0, 4096)` for ≥ 90 % of consecutive pairs. This is what separates the `Cmd` and
   `OrderID` slots, which steps 3–4 cannot.
6. Sanity: `(SendOption ∈ {1,2,5} and Cmd ≠ 2) == (MsgKey ∈ 90..99)` must hold for 100 % of packets.

Correct orders for the working set (field ids `0=SendOption 1=Cmd 2=OrderID 3=Flags 4=Length`):

| capture | m | order |
|---|---|---|
| `20260910_161940` | 0x71 | `(0,2,3,1,4)` — `docs/PROTOCOL_CIPHER.md` §3 records `(0,1,2,3,4)` for this session; **that table is wrong** |
| `20260910_175549` | 0x65 | `(0,2,1,3,4)` |
| `20260910_155351` | 0x80 | `(0,4,2,1,3)` |
| `20260910_150701` | 0x20 | `(3,2,4,0,1)` |
| `20260910_164551` | 0x17 | `(3,4,2,1,0)` |

Anything derived from a mis-solved header is wrong about `Cmd`, `Flags` and `OrderID` — which is
where the earlier "some families are ZIP-compressed" reading came from.

---

## 8. Experiments that settle what is left

1. **Is Cmd 144 the snap-back?** Jump >6 m under teleport; check for an inbound 144 at +300–450 ms,
   immediately before the outbound position reverts. Already-logged data suffices. *(§2.1)*
2. **Does removing ack drops stop the kicks?** Change one classification rule — never drop
   `Cmd 2` — and compare kick rate and inbound retransmit rate against the table in §5.3. This is
   the highest-value experiment in this document and it needs no new code beyond a predicate.
3. **Is 135 bit-aligned to entity id?** Correlate `bit i` against "entity id `i` appeared in the
   position stream in the next 200 ms" over lag offsets −2..+2. Offset 0 must dominate. Watch the
   `1ULL << 64 == 1ULL << 0` aliasing edge (our measured max entity id is 64). *(carried over from
   `IL2CPP_FINDINGS.md` §5.4.1)*
4. **Does a cleared 135 bit also stop the position stream?** Partition 2001/2012 arrivals by the
   sender's bit in the most recent 135. Still arriving ⇒ 135 is rendering-only and the ESP's range
   limit lives elsewhere.
5. **Can we inject an unreliable inbound record?** Synthesise one extra entity record into a 2012
   batch (plaintext, length-preserving is not required here since `Length` is ours to set) and see
   whether the client renders a ghost entity. Proves or kills the whole injection class in one
   test.
6. **What is in 943 `SENSITIVE_GAMEVAR` and 849 `CONFIG_OVERWRITE`?** Both are reliable+encrypted,
   so this needs the session key, which we have. Highest-value unknown in the inbound name space.
7. **Read the five damage multipliers** (`static_fields + 0x308..0x318`) with one ReClass read on
   a live process, settling the head:body ratio exactly. *(carried over from §4.2)*

---

## 9. Corrections to other docs

- **`docs/PROTOCOL_MASTER.md` §8.2** — "Is hit registration client-authoritative? Unresolved" is
  **settled**: it is client-authoritative. `docs/IL2CPP_FINDINGS.md` §1.
- **`docs/PROTOCOL_MASTER.md` §10** — "Per-shot fire message is inside the encrypted input
  stream" is wrong twice over: it is Cmd 104, and the 24 B "encrypted input stream" is the ACK
  channel (§1.3, §5.3).
- **`docs/TELEPORT.md` §2** — "No server correction packet was identified" — candidate found:
  Cmd 144 `RUDP_FORCE_SYNC_PLAYER_STATE`, present in 6 of 11 captures (§2.1).
- **`docs/TELEPORT.md` §4** — the 25 568 drops attributed to the "encrypted input stream (8+8k,
  mostly 24 B)" are our **UDP_ACK** packets (§5.3).
- **`docs/PROTOCOL_CIPHER.md` §3** — the measured `HEAD_SECRET` table is wrong for at least
  `20260910_161940`, and the solver that produced it is wrong in 3 of 5 sessions (§7.1).
- **`docs/PROTOCOL_MASTER.md` §1.2** — "NEVER identify a packet family using bytes b2–b7 … always
  key families off b8/b9" is good advice for the *body*, but understates `b0`: `MsgKey` is
  plaintext, needs no mask, and gives you the reliability class and the header size directly.
- **`docs/IL2CPP_FINDINGS.md` §5.1** — the claim that 2001 is replaced by "Cmd 2002 / 2006 / 2031"
  while mounted needs re-checking: the inbound registry has **no 2006**, and **2031 is
  `UDP_SYNC_CANNON`**. The dispatch branch is real; the id mapping came from a different build.
- **`docs/IL2CPP_FINDINGS.md` §2** — "messages are bidirectional with different classes per
  direction" is right but applies to a minority: only **130 of 1384** inbound ids have an outbound
  sender, and **177 of 307** outbound ids have no inbound handler.
