# IL2CPP extraction plan — Free Fire Max 2.131.1

Written 2026-09-11, after a live recon pass against the rooted LDPlayer instance.
Everything in §1 is **measured**, not assumed. §2 explains why the plan differs from
the one originally proposed. §3 onward is the plan.

---

## 1. Recon results (all verified this session)

| fact | value | how established |
|---|---|---|
| Emulator | LDPlayer, Android **14** (SDK 34), host **x86_64** | `getprop` |
| Root | **yes**, `su` → `uid=0(root)` | `su -c id` |
| Phone (SM_S948U1) | Android 16, arm64-v8a, **NOT rooted** | `su` absent |
| Game package | `com.dts.freefiremax` **2.131.1** | `dumpsys package` |
| Game ABI | **arm64-v8a** — the only config split | `primaryCpuAbi`, `split_config.arm64_v8a.apk` |
| `libil2cpp.so` | **195 971 312 B (187 MB)**, AArch64, ELF64 DYN | `llvm-readelf -h` |
| text segment | 0x7753894 (**125 MB**), `vaddr = file_off + 0x4000` | program headers |
| **`il2cpp_*` exports** | **259 present, all bridge-critical ones OK** | `llvm-readelf --dyn-syms` |
| `global-metadata.dat` | 56 201 276 B, **ENCRYPTED** | magic is `47 F3 59 12`, not `AF 1B B1 FA` |
| socket owner | **`libil2cpp.so`** — imports `socket`/`sendto`/`sendmsg`/`recvfrom`/`recvmsg` | dynsym UND scan |
| `libGGP.so` | SONAME **`libBifrost.so`**, 8.8 MB, **0 imported symbols**, strings encrypted | `objdump -p/-T`, `strings` |
| `libthor_utils.so` | only exports `JNI_OnLoad`, `global_func_ptr` — stripped shim | dynsym |
| `libFFWebRequest.so` | bundled **OpenSSL** (39 hits, SHA256, ChaCha20) | constant sweep |

### Crypto constant sweep — result: **negative, and that is informative**

Scanned `libil2cpp.so` for TEA/XTEA, Blowfish, AES (table *and* ARMv8 `AESE`
instructions), DES, CRC32, MD5, SHA-2, ChaCha, RC5.

- **ARMv8 AES instructions: 0.** SHA instructions: 49.
- A raw byte scan under-detects on ARM64 (constants are built with `MOVZ`/`MOVK`
  immediates), so the scan was redone over decoded instruction immediates.
- `0x9E3779B9` produced 8 co-located `MOVZ`/`MOVK` pairs, 7 clustered in
  `0xA7B7C48`–`0xA7B7DC4` (vaddr). **This is NOT TEA.** Disassembly shows:

  ```
  w8 = w1 + (w0 << 6);  w8 += (w0 >> 2);  w8 += 0x9E3779B9;  w0 = w8 ^ w0
  ```

  which is exactly `boost::hash_combine`, with its 2/3/4-argument chained overloads
  immediately following. 0x9E3779B9 is the golden-ratio constant that hash_combine
  shares with TEA — a known confounder, and this was it.
- Controls behaved correctly: Blowfish, CRC32 and TEA-sum-final each scored **0**
  co-located pairs against a chance baseline of 16.5 isolated hits per 16-bit value
  (1 082 891 total `MOVZ`/`MOVK` in the binary).

**Conclusion:** the UDP match cipher is **not a stock algorithm**. It is custom,
almost certainly inside `libil2cpp.so` (which owns the sockets). This is consistent
with the wire evidence — an 8-byte-block ECB-shaped transform (`len = 10+8k` /
`8+8k`) plus a rotating 6-byte XOR mask is a lightweight hand-rolled scheme, which
is what you would expect for a 10 Hz game protocol. `libFFWebRequest.so`'s OpenSSL
is for lobby HTTPS and is a separate concern.

---

## 2. Why this plan differs from the one proposed

Three corrections, in order of how much work they save:

**(a) The symbols are not hidden.** The premise was that `libil2cpp.so` conceals the
IL2CPP tables and that frida-il2cpp-bridge would need patching. It exports the
complete 259-function C API — `il2cpp_init`, `il2cpp_domain_get_assemblies`,
`il2cpp_image_get_class`, `il2cpp_class_get_methods`, `il2cpp_field_get_offset`, all
of it. **The bridge would run unmodified.** Finding `il2cpp_init` and hand-patching
the bridge is work that does not need doing.

**(b) The metadata *is* encrypted, so the runtime step is still required** — but not
necessarily via Frida. IL2CPP has to decrypt `global-metadata.dat` in memory to run.
With root we can read that decrypted copy straight out of `/proc/<pid>/mem`. That
needs **no injection, no ptrace attach, no Frida** — which matters a great deal given
(c).

**(c) `libGGP.so` is a packed protector (`libBifrost.so`).** Zero imported symbols
while declaring libc/libdl/libz means it resolves every syscall by hand at runtime,
and all its strings are encrypted. Frida is exactly what this class of module looks
for. Running frida-server against a logged-in account is the highest-risk action in
this whole plan, and it is avoidable for the structure dump.

**The single most important consequence:** IL2CPP metadata is decrypted during
process startup, **before login**. We can launch the game, let it reach the title
screen, dump memory, and kill it — no account, no match, minimal anti-cheat surface.

---

## 3. Route A — no-injection dump (do this first)

Goal: a complete `dump.cs` (every class, method, field, with RVAs) without ever
attaching a debugger to the game.

1. **Launch and settle.** `am start` the game on the emulator, wait for the title
   screen. Do **not** log in.
2. **Locate the decrypted metadata.** Read `/proc/<pid>/maps`, then scan the
   anonymous/private RW regions for the IL2CPP sanity magic `AF 1B B1 FA`
   (0xFAB11BAF) followed by a plausible version word (24, 27, 29, 31). Reading via
   `process_vm_readv` or `/proc/<pid>/mem` as root does **not** set `TracerPid`.
3. **Carve it out.** Dump from the magic for the metadata length implied by its own
   header; sanity-check that the string-literal and type-definition tables land
   inside the region.
4. **Cross-check the encryption.** With plaintext in hand, diff it against the
   on-disk `global-metadata-encrypted.dat` to recover the transform. The header
   already hints at it — plaintext `0x00` maps to `0xE8` in many positions, so it is
   likely byte-wise and position-dependent. Recovering it is a bonus, not a blocker.
5. **Run Il2CppDumper** with the *dumped* metadata + `libil2cpp.so`. Produces
   `dump.cs`, `script.json`, `il2cpp.h`.
   - The `il2cpp_*` exports being intact means its CodeRegistration /
     MetadataRegistration search should succeed without manual offsets.
   - 187 MB input: expect it to be slow and memory-hungry. If it chokes, fall back
     to Route B.

**Fallback if the memory scan fails** (e.g. metadata is decrypted lazily, in chunks,
or re-encrypted after load): hook the metadata loader instead — but that is Route B.

---

## 4. Route B — Frida (only if Route A fails, or when dynamic tracing is needed)

Route A gives static structure. It cannot give **call stacks**, which is what
ultimately pins down the send path fastest. Use B deliberately, not by default.

**Arch problem, stated honestly:** the game is arm64 running under LDPlayer's ARM
translation on an x86_64 host. This is the part most likely to fail. Ordered
attempts:

1. **arm64 `frida-server`**, run under the translation layer. Simplest; try first.
2. **`frida-gadget`** via `setprop wrap.com.dts.freefiremax "LD_PRELOAD=..."`. Needs
   root (have it), avoids ptrace injection entirely. Preferred if (1) is flaky.
3. **x86_64 `frida-server`** — expected to fail against a translated arm64 process;
   listed only for completeness.
4. **Google's Android Emulator with an arm64 system image** — genuinely ARM, `adb
   root` available, no translation layer. Slow but correct. This is the real fallback
   if LDPlayer cannot host Frida.

With Frida up, `Il2Cpp.dump()` from frida-il2cpp-bridge needs **no modification**
(§2a). Pin the bridge version to one matching this Unity/metadata version.

**Use a throwaway account, never the phone's.** Bifrost bans devices, not only
accounts — and the emulator is the sacrificial device precisely so the phone is not.

---

## 5. Static analysis strategy — do NOT auto-analyze 187 MB

125 MB of ARM64 text is on the order of a million functions. Full IDA auto-analysis
is a multi-hour-to-multi-day job producing a huge database, and it is unnecessary.

- Open with **`run_auto_analysis=False`**.
- Use the RVAs from `dump.cs` to jump **directly** to the handful of functions that
  matter, then `analyze_function` + `decompile` only those.
- `script.json` from Il2CppDumper names the methods; apply it if IDA handles it at
  this scale, otherwise resolve names by RVA lookup from `dump.cs` on demand.

Address translation for this binary: **`vaddr = file_offset + 0x4000`** in the text
segment.

---

## 6. Finding the send path

Three converging methods, cheapest first:

1. **Top-down from names.** Grep `dump.cs` for `Net`, `Socket`, `Session`, `Packet`,
   `Msg`, `Proto`, `Codec`, `Cipher`, `Encrypt`, `KCP`, `Enet`, `Udp`.
2. **Bottom-up from `sendto`.** Locate the `sendto` PLT stub, then scan the text with
   capstone for `BL` instructions targeting it, and walk callers upward 2–3 levels.
   This is a mechanical scan, no IDA required.
3. **Runtime stack trace (Route B only).** Hook `sendto`, take a backtrace,
   symbolize against `dump.cs`. Fastest and most certain when available.

**Ground truth we already hold makes verification easy.** We know the outbound
keepalive is 48–67 B at ~10 Hz with a 23-varint body, and we know the 6-byte mask
sits at b2–b7 and rotates per session. Any candidate function is confirmed or
refuted against captures we already have.

---

## 7. Cracking the encoding — and why it matters most

Once the encrypt/decrypt function is identified, a hook that logs
(plaintext, ciphertext) pairs settles the algorithm and key immediately; static
reading settles it more slowly but without injection.

**The payoff is the project's biggest open limitation.** `PROJECT_STATE.md` §4
records that the faster inbound families (**12.4 Hz and 8.0 Hz**) "scored 0 position
hits against a 4.6–19.8% chance baseline" — but those families are ECB ciphertext, so
a score of 0 against *encrypted bytes* is exactly what you would expect whether or not
they carry positions. **That test could not have succeeded, so it did not refute
anything.**

The ESP is currently bounded by a 198 ms tick plus ~230 ms staleness. If the 12.4 Hz
family carries position, decrypting it is worth roughly **2.5x** on the single
constraint that has driven this entire session's work — the lead/lag tuning, the dead
reckoning, the sawtooth smoothing, all of it.

Secondary: the "no bones on the wire" conclusion was settled four ways, one of which
was "every other match-server family is ECB ciphertext." Decryption legitimately
reopens that question. The other three arguments still stand, so treat this as
*worth re-testing*, not as overturned.

---

## 8. Risks

- **Bifrost detects Frida.** Route A exists to avoid this. When Route B is used:
  throwaway account, emulator only, never the phone.
- **LDPlayer is itself detected.** Free Fire flags emulators. Irrelevant for a
  title-screen memory dump; relevant the moment we log in.
- **The phone is not rooted**, so all runtime work happens on the emulator. Because
  both are arm64-v8a and it is the same APK, findings transfer — but *offsets are
  per-build*: a game update invalidates every RVA.
- **Do not commit the binaries.** They live in `C:\Users\Tonyt\Documents\FF-RE\bin`,
  deliberately outside the repo (187 MB + 56 MB).

---

## 9. Status

Recon complete; nothing injected, nothing modified on either device. Files staged at
`C:\Users\Tonyt\Documents\FF-RE\bin`: `libil2cpp.so`, `libGGP.so`, `libmain.so`,
`libthor_utils.so`, `libFFWebRequest.so`, `global-metadata-encrypted.dat`.

Next action is Route A step 1 — launch the game to the title screen and scan for the
decrypted metadata magic.

---

## 10. RESULTS — Route A succeeded (2026-09-11)

**The decrypted metadata was extracted with no injection, no Frida, and `libGGP.so`
never loaded.** Confirmed by `/proc/<pid>/maps`: only `libil2cpp.so`,
`libthor_utils.so` and `libunity.so` are mapped at the title screen. The protector
is not active before login.

### How it was found

The magic-byte scan returned **0 hits** — because **Free Fire zeroes the
`0xFAB11BAF` sanity word in memory after validating it** (anti-dump). The scanner was
validated against known memory first (it read `libil2cpp.so`'s ELF header correctly),
so the null result was the game's behaviour, not a broken instrument.

It was located **structurally** instead: a 53.6 MB region backed by `/dev/zero` at
`0x74e6c5752000`, whose size is exactly `global-metadata.dat` rounded up to a page.
Identified by the header's offset/size chain being perfectly contiguous:

```
word[0] 0x00000000  sanity (blanked)      word[1] 0x0000001F  version 31
word[2] 0x00000100  stringLiteralOffset   word[3] 0x00069AA0  size
word[4] 0x00069BA0  == 256 + 432800   OK  word[5] 0x00197B90  size
word[6] 0x00201730  == 433056 + 1670032  OK
```

### Validation

- All **22** header tables chain contiguously, none out of range.
- Struct sizes divide exactly: methods 12 585 600/36 = **349 600**;
  typeDefinitions 4 024 768/88 = **45 736**; fields 5 624 808/12 = **468 734**.
- images 2 960/40 = **74** and assemblies 4 736/64 = **74** — matching counts.
- 625 926 strings, real names (`FFWSTrophyCup`, `FFFBXEngine`).
- Sanity word restored to `0xFAB11BAF` in the saved file.

### Artifacts

| file | notes |
|---|---|
| `FF-RE/bin/global-metadata.dat` | **decrypted**, magic restored, 56 201 276 B |
| `FF-RE/bin/global-metadata-encrypted.dat` | on-disk original, for diffing the transform |
| `FF-RE/bin/dump_names.txt` | 59 MB — every type, method, field (no RVAs yet) |
| `scratchpad/memtool.c` | scan/dump tool, static x86_64, built with NDK r29 |

### Namespace map

| namespace | types | what it is |
|---|---|---|
| `COW` | 12 362 | the game codebase (Free Fire's internal name) |
| `proto` | 3 804 | **lobby** backend protobuf — readable |
| `message` | 3 467 | **fully Beebyte-obfuscated** — the sensitive one |
| `tcp` | 710 | **lobby** TCP protocol — readable |
| `COW.GamePlay` | 3 188 | gameplay |

**`tcp.*` and `proto.*` are the lobby protocol** (Achievement, AntiAddiction,
Leaderboard, Championship). They are *not* the in-match UDP stream. Note also that
our captured wire format is **positional** varints while protobuf is **tagged**, so
the match protocol is not protobuf.

`message.*` is obfuscated while the lobby namespaces are not — a deliberate choice
that points at it. One of its enums (`message.MHJLOKOOGNB`) kept readable members:
`entity, Property, EventID, TypeEnum, Bool, Int, Float, Int64, Number, BigFloat,
String, Color, UUID, …` — an entity-property replication type system.

### Corrections to earlier leads

Recorded so they are not re-chased:
- `CipherFunct` is `System.Security.Cryptography.DESTransform` — **mscorlib**, not
  Free Fire's packet crypto.
- `CopyAndEncrypt` is SharpZipLib zip encryption.
- `ClearGGPDecryptionState` is `GCommon.FileInfoEncryptionHelper` — **asset file**
  encryption, not packets.
- `DispatchAOIVisibleChanged` / `DispatchEntity*` belong to `COW.UGCEntityDataStore`
  — Craftland **UGC**, not the match protocol.

### Blocker

`dump_names.txt` has **names but no RVAs**, so nothing yet maps to an address in
`libil2cpp.so`. RVAs require `CodeRegistration`/`MetadataRegistration` from the
binary. Options: Il2CppDumper (standard, needs download), or implement the
`.data.rel.ro` pointer-table heuristic in Python.

---

## 11. RVAs recovered, and the netcode located

### Getting RVAs without Il2CppDumper

`.data.rel.ro` pointers are **zero in the file** — the dynamic linker fills them from
`.rela.dyn` (1 668 458 relocations). Rather than replay relocations, the already
relocated `.data.rel.ro` and `.data` were read out of the **live process**.

- `MetadataRegistration` @ **0xAE4DCA8** — found by `fieldOffsetsCount ==
  typeDefinitionsSizesCount == 45736` at struct offsets +0x50/+0x60.
- `codeGenModules` @ **0x40002E421738** (runtime) — found from the other end, via the
  72 `*.dll` strings in `.rodata`.
- **70 modules**; `Assembly-CSharp.dll` has **279 471** method pointers @
  `0x40002E437E28`. Total 331 976.
- Mapping: method token RID → `methodPointers[RID-1]`; type → image via the `images`
  table (74 entries × 40 B).

**322 920 method addresses resolved** → `FF-RE/bin/rva_map.txt`,
`addr_sorted.txt`. Verified against the independently derived `sendto` call chain:

```
0xA685740 -> System.Net.Sockets.Socket::Send            (+0x0)  EXACT
0xA68BD90 -> System.Net.Sockets.Socket::SendTo_internal (+0x0)  EXACT
```

libil2cpp load base in the live process: **0x400023200000**.

### Socket layer

Every socket syscall has 1–4 `BL` call sites and **all** lie in
`0xABB8028`–`0xABB9E90` — one compact `System.Net.Sockets` icall module. So all of
libil2cpp's networking is managed C#.

`Socket::SendTo` and `UdpClient::Send` have **zero** managed callers; the UDP path
runs over a *connected* socket via `Socket::Send`.

### THE NETCODE — `GCommon`

| class | role |
|---|---|
| **`GCommon.UDPSession`** | **in-match UDP transport** |
| **`GCommon.MUDPSession`** | multi//match UDP session (adds gzip + ClientState) |
| `GCommon.NetworkSession` | base: connect/send/recv threads |
| `GCommon.SocketClient` | thin socket wrapper (`CreateUDPSocket`/`ConnectUDPSocket`) |
| `COW.TCPSession2` | **lobby** TCP |
| `GCommon.TCPMsgPacket` | lobby packet serialize/unserialize |

### Why this matches the wire evidence exactly

`UDPSession` carries **two independent keys**:

```
m_TargetSecretKey        body key
m_TargetHeadSecretKey    SEPARATE key for the packet HEADER
m_SessionKey
```

with the API `SetSecretKey`/`GetSecretKey`, `SetHeadSecretKey`/`GetHeadSecretKey`,
`UpdateSessionKey`. **A distinct header key is precisely the structure measured on
the wire** — the rotating 6-byte mask at b2–b7 is independent of the body's 8-byte
block cipher. That is strong mutual corroboration between the binary and six sessions
of captures.

Other fields that line up with observations:

| field | wire observation |
|---|---|
| `m_PingKeepAliveMsg`, `m_KeepAliveInterval`, `m_LastPingSentTickcount` | the ~10 Hz outbound keepalive |
| `m_ReliableTracking`, `m_PacketToResend`, `m_RUDPSendLog`, `m_RUDPRecvLog` | reliable-UDP layer over raw UDP |
| `m_EncBuffer`/`m_DecBuffer`/`m_EncTempBuffer`/`m_DecTempBuffer` | encrypt/decrypt staging |
| `m_GZipInputStream`, `m_ZipOutputBuffer` (MUDPSession) | **compression** — a plausible reason some families look like opaque high-entropy blocks |
| `m_HelloPacket`, `SendHello`, `SendReconnect` | session handshake |

### Addresses to decompile next (vaddr; file_off = vaddr − 0x4000)

```
GCommon.UDPSession::Send                 0x082C83CC
GCommon.UDPSession::HandleRecv           0x082C8C88
GCommon.UDPSession::OnSendDataThread     0x082CA538
GCommon.UDPSession::SetSecretKey         0x082C8714
GCommon.UDPSession::SetHeadSecretKey     0x082C56A8
GCommon.UDPSession::UpdateSessionKey     0x082C5BEC
GCommon.UDPSession::GetUDPPackets        0x082B3F28
GCommon.MUDPSession::RealSendDataThread  0x082A8794
GCommon.MUDPSession::HandleRecv          0x082A613C
GCommon.MUDPSession::SendHello           0x082A3AD4
```

`UDPSession::Send` + `HandleRecv` are the two that should yield the cipher; the
`Set*SecretKey` pair and `UpdateSessionKey` give key derivation and the rotation.

### Artifacts added

`rva_map.txt`, `addr_sorted.txt` (322 920 methods), `modules.txt`,
`live_drelro.bin`, `live_data.bin`, `libunity.so`.
