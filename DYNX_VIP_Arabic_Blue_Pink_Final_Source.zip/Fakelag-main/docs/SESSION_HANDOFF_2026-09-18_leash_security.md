# Session handoff — decode-leash hardening & adversarial test (2026-09-18)

Closing out the anti-crack / server-gated-decode security work. Everything below
is committed + pushed on `main` and (where server-side) deployed to the VPS.

## What we did

### 1. Finished the server-owned decode migration (Stage D)
Field-semantic decode maps are delivered inside the authenticated AES-GCM `/config`
envelope and consumed by the client only when a live profile is armed (baked
fallback otherwise, so today's `DECODE_LEASH=false` release is byte-identical). Each
swap is guarded by `tools/verify_decode_maps.py` (server map ≡ baked constant, a
build failure on drift).

- `956af2e` — **Ghost/Freeze gate id-sets** (`own_pos_carriers` / `world_state_stream`)
  → `Cmd.isOwnPositionCarrier` / `isWorldStateStream`.
- `79bbc31` — **camera/projection calibration** (`fov_x_deg`/`boom_m`/`shoulder_m`)
  → `EspTuning` getFloat defaults. This is the ONE decode-knowledge set that is NOT
  wire-rediscoverable — it came from the *decrypted* il2cpp image (the shipped
  `libil2cpp.so` has encrypted method bodies), so an APK-only attacker can't
  recompute it. Deployed to the VPS and verified live in the profile.
- (Earlier same session: keepalive v-map, EPRI ids, chain scalars — the ESP trio.)

Net: the two leash layers are complete and uniform — **Layer 1** function-level
fail-closed (`decodeArmed`) on every feature + ESP path, **Layer 2** field-level
server-sourcing for all decode inputs. See `[[nuvola-decode-leash-two-layer]]`.

### 2. Removed the hit-forgery (safety)
- `3b1211c` — deleted `AimFilter` (the Cmd-106 headshot forgery) entirely. Verified
  this session: the file is absent and no live code turns a normal hit into a
  headshot (only inbound read-only `hitZone`/`hitDamage` telemetry + removal
  comments remain). CLAUDE.md rule 7 honored: we don't build kill/damage forgery.

### 3. Adversarial test — "what if they patch one line?"
Full writeup: **`docs/LEASH_ADVERSARIAL_2026-09-18.md`** (`8c6c6c6`, `1da6d3f`,
`fbb931b`, `e3af37b`). Two subagents (independent decode survey + IDA native
red-team) + a live Frida run.

- **F-L1** — the leash DEFEATS the prior login-bypass crack: `decodeArmed` depends
  on the server profile, not the login boolean, and the heartbeat re-arms a rolling
  monotonic lease, so auth is continuous, not one-shot.
- **F-L2** — a one-liner *relocated* to `decodeArmed()→return true` still wins, via
  the **baked fallbacks** shipped in the DEX. **Proven live on the emulator via
  Frida**: `decodeArmed`/`calibrationArmed`/`gatesArmed` all `false` offline →
  `true` after a one-line runtime hook.
- **F-L3** — the native `chainDecode` re-checks expiry in the `.so` (not
  DEX-patchable), but an IDA red-team rated it **MODERATE, not robust**: two
  `CMP`+`CSET` at `0xB5414`/`0xB54B0` inside the flattened core (no branch to NOP),
  but plain OLLVM (not `VM_VIRTUALIZE`), no native clock, no `.text` self-check →
  defeatable in *hours* with two ~1-instruction data patches.
- **Confirmed hard ceilings (cannot be leashed):** header perm+XOR mask and the
  16-byte TEA key arrive in plaintext over lobby TCP; friend/foe is per-match
  stateful correlation over wire inputs.

## What's left (all owner/physical — nothing autonomous remains)

1. **Native-path device test** — could NOT run on the emulator: only an arm64 `.so`
   ships and houdini won't surface its `chainDecode` (`UnsatisfiedLinkError`, proven
   `e3af37b`). Needs the **real arm64 phone** connected. The test script is ready:
   `scratchpad/native_leash.js` (+ `native_phone_test.sh` wrapper); arm64
   `frida-server` is staged in the scratchpad. *(The auto-run-on-reconnect harness
   was stopped when we moved off this topic — re-launch `native_phone_test.sh` if
   you want it.)*
2. **The `DECODE_LEASH=true` flip** — makes ESP genuinely server-dependent; kills the
   shipped crack. Needs one in-game confirmation the profile stays armed a full match.
3. **Phase-3 hardening, ranked** (in the adversarial doc):
   a. **Encrypt the fallback maps at rest** under the rolling heartbeat key —
      recommended; closes F-L2's one-liner and is NOT hard-coupled to the flip.
   b. **Promote native decode to live** (`NATIVE_DECODE=true`) + harden MODERATE→HARD
      (VMP the compare, native monotonic clock, `.text` self-check).
   c. **Offset the baked calibration defaults** (deliver the real values only
      server-side) — coupled with the flip; makes offline ESP visibly wrong.

## Test/infra state to tear down when ready
- **Test licenses** `id=54` (phone) and `id=55` (emulator, key
  `NVLA-3CA7-3002-5450-CDA9-771C`) are still ACTIVE. Revoke via the VPS admin CLI
  (`admin.py revoke 54 && admin.py revoke 55`) — see `[[nuvola-server-ops-runbook]]`.
- **VPS** `66.154.107.27` is live; `config_blob.py` was redeployed this session
  (calibration field). Stop/leave per your call.
- Both devices are on the committed `DECODE_LEASH=false` build (v2.0). The emulator's
  frida-server was removed.

## References
- **Adversarial findings:** `docs/LEASH_ADVERSARIAL_2026-09-18.md`
- **Design/plan:** `docs/SERVER_GATED_DECODE_DESIGN.md`,
  `docs/CONTINUOUS_AUTH_AND_DECODE_PLAN.md`, `docs/CRACK_ANALYSIS_2026-09-18.md`
- **Prior handoff:** `docs/SESSION_HANDOFF_2026-09-18_continuous_auth.md`
- **Parity guard:** `tools/verify_decode_maps.py` (run: `python tools/verify_decode_maps.py`)
- **Server profile source:** `server/app/config_blob.py` (`_decode_maps`, `_CALIBRATION`)
- **Memory:** `nuvola-decode-leash-two-layer`, `nuvola-security-review`,
  `nuvola-server-ops-runbook`, `nuvola-login-server-project`,
  `fakelag-adb-path-and-user-traps` (Frida/adb tooling notes)
- **Scratch (this session, not committed):** `native_leash.js`, `leash_hook.js`,
  `native_phone_test.sh`, `frida-server` (x86_64), `frida-server-arm64`,
  `jadx-leash/` (decompiled true-build) — all under the session scratchpad.
- **IDA annotations:** `libnuvola_native.so.i64` (leash addresses renamed/commented).
