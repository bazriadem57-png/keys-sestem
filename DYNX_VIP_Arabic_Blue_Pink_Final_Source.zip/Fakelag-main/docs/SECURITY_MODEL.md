# Security model — what Nuvola can and cannot protect

**2026-09-17.** Written before adding the login + server, from four research
passes (attacker playbook, client hardening, server/auth architecture, internal
crown-jewel inventory). Read this before touching anything under `auth/`, `net/`,
the backend, or the NDK port — it is the reasoning the whole design rests on.

The plan this implements: `docs/LOGIN_AND_SERVER.md` (protocol + client) and
`docs/SERVER_OPS.md` (the VPS).

---

## 1. The one inescapable truth

Nuvola is a `VpnService` that parses the game's UDP protocol **on-device, per
tick, in real time** (~10 Hz outbound, ~198 ms world-state tick). ESP/radar/aim/
packet-effects cannot tolerate a round-trip to our server per packet. Therefore:

- **The decode + manipulation logic must execute on the phone.** Anything the
  CPU executes, an attacker with root + Frida + Ghidra can eventually recover.
  You cannot move the parser server-side without destroying the product.
- So the crown-jewel logic is **slowable, never stoppable.** Hardening changes
  the attacker's cost from *hours* (jadx script kiddie) to *weeks* (skilled RE)
  and shrinks the population who can do it. It does not make the logic unliftable.
- **Access gating is different and genuinely defensible.** Whether someone is
  *allowed to use* the app, share a login, or reach our server is enforced
  server-side, where the attacker has no leverage.

**Design principle:** fight the piracy/sharing economics on the server (you can
win); buy time on the client (you can only slow); make whatever leaks
**traceable and killable**.

---

## 2. Attacker tiers (who we are actually pricing out)

| Tier | Tools | Cost today | Cost after full hardening |
|---|---|---|---|
| **T1 script kiddie** | jadx-gui, LuckyPatcher, mod Discord/Telegram | minutes–hours | blocked at jadx (needs native RE) |
| **T2 competent modder** | apktool + smali, uber-apk-signer, mitmproxy, hosts | hours | days–week (must beat integrity + server gate) |
| **T3 skilled RE** | Frida/objection, Ghidra/IDA, Magisk/LSPosed | hours (nothing stops them today) | weeks; recovers the jewels eventually |

~95% of the threat is T1/T2 and is defeatable-enough. The remaining T3 lifts the
protocol RE no matter what — plan for **detection + revocation + watermark**, not
prevention.

---

## 3. The three-bucket data split

Every valuable piece of the codebase classifies into exactly one bucket. This is
what decides what ships as Java, what is delivered from the server into RAM, and
what lives only server-side. Full file-level inventory is in the internal audit;
summary here.

### Bucket A — must stay client-side, hot path (executable, per-packet)
`decode/frame/*` (HeaderLayout masking, Crc7, PacketCodec reseal),
`decode/crypt/*` (Tea, BodyCrypt), the `PositionSync`/`VehicleSync`/`PriSync`
decode loops, all of `filter/*` (Teleport/Freeze/Ghost/Aim/Mark),
`tunnel/PacketLoop`, `tunnel/UdpSessionManager`, the `SessionKeySolver` runtime
observer. **Piece by piece this code is generic** — a LEB128 reader, a CRC-7
pass, a TEA cipher, a couple of state machines. None of that *is* the secret.

### Bucket B — deliverable as a server RAM blob (knowledge/tables/constants)
This is where the crown-jewel **value** actually concentrates — *which byte at
which index in which command means what*:
- `CmdCatalogue` (1974 ids) and `BodyDecoderTable`/`Text` (1604 wire layouts) —
  ~150 KB, and read **only** by `dev/capture/*`.
- `PositionSync` field indices, `PriSync` EPRI id table + grammar, `AimFilter`
  hit-zone/field indices + checkParams model, `MarkFilter` 9-field layout,
  `VehicleSync` layout/scales, header field set + permutation, `Crc7`/`Tea`
  constants, `LobbyKeySniffer` protobuf tags + the `mask=key[0]` fact, teleport
  per-state step budgets, ESP calibration constants.

Every one of these is a value or small table currently sitting in the APK as a
`static final` or packed string. Moved to a login-time RAM blob, a jadx
decompile of the shipped APK shows the *method* but not the *answer key*.

### Bucket C — fully server-side (not latency-sensitive)
Login / licensing / feature-entitlement (the `config/plugin` + `features/`
toggles are just RAM switches; the *entitlement decision* belongs on the server),
and the entire `dev/capture/*` analysis stack — which is the only real consumer
of the two big Bucket-B tables.

### How value splits
The A-code is reconstructable by any competent engineer; the B-knowledge is what
took the debugging cycles documented throughout this repo. **The majority of the
liftable value is Bucket B**, and its two largest assets are read only by the
dev/capture path — so they move server-side with near-zero runtime change. That
is why Phase 1 can withhold them immediately, before the native port.

---

## 4. What each defense actually buys (and its ceiling)

| Defense | Stops | Ceiling / bypass |
|---|---|---|
| Release build (no `debuggable`) | Frida-attach + memory dump **without root** | none — pure win, do first |
| R8 full-mode obfuscation | casual name-reading | protects names only; constants/algorithms stay readable |
| Server-authoritative session | patched/replayed/stripped local gate | a patched client still gets no valid token/config |
| Device-bound tokens (Keystore) | login sharing, token replay across devices | root can spoof the device id → treat as anomaly signal too |
| Withhold Bucket-B to RAM blob | the **static (jadx)** attacker | T3 dumps it from RAM or captures it once off the wire |
| Per-user watermark | anonymous leaks | identifies the leaker → revoke that one license |
| Versioned config rotation | long-lived leaked blobs | leaked version dies on next fetch |
| Native `.so` + O-MVLL (Phase 2) | all of T1/T2, most of T3's speed | T3 with Ghidra recovers it in weeks |
| Native tamper-evidence (cert-hash key) | repack + re-sign redistribution | patchable in principle, but non-branching so not a one-line NOP |

**Never do (for THIS app):** root / Play-Integrity / hardware-attestation gates,
aggressive anti-Frida/anti-root/emulator RASP, commercial packers. Our userbase
runs rooted/sideloaded devices — those checks reject our own paying customers
while experts bypass them, and they carry a perpetual maintenance treadmill. The
**only** RASP item we keep is a cheap native `ptrace`-self anti-attach (Phase 2).

---

## 5. The honest bottom line

- **Realistically stoppable** (server holds the leverage): login/account
  sharing, token replay, mass free redistribution, and revoking cracked builds /
  abusive accounts. Invest here — you can win.
- **Only slowable** (a VpnService parses locally): extraction of the on-device
  decode logic and any server-delivered config. A T3 with root+Frida+Ghidra
  recovers it. Native + obfuscation raises their cost from an afternoon to weeks
  and shrinks how many can do it — that is the entire achievable goal.
- **Two non-technical multipliers that beat most of the ladder:** (1) rotate the
  Bucket-B constants each release so a stolen snapshot rots; (2) compete on
  iteration — ship correct protocol updates faster than a copier can re-lift.

You are not building an unbreakable vault. You are pricing out the 95%, making
the 5% pay in weeks, and using the server to detect, revoke, watermark and
rate-limit whatever they eventually lift — so lifting the parser never yields a
free, redistributable, self-sufficient product.
