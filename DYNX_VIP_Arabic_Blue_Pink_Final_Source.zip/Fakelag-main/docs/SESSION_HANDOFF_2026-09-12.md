# Session handoff — 2026-09-12

**Read this first after a context clear.** Then `docs/IL2CPP_FINDINGS.md`, then
`docs/DUMPER_REWRITE_BRIEF.md`.

---

## 1. STATE: what is built, wired, and NOT committed

**Nothing in this session is committed.** `git HEAD` is `47b5854`. Everything
below is in the working tree only.

Build: **clean compile, zero errors.** APK installed to `R3GL10AHL7P` at
12:36:52 on 2026-09-12. **Never verified in a live match.**

### New Java (≈6,700 lines, all compiling)

| file | lines | what |
|---|---|---|
| `dev/capture/CaptureEvent.java` | 134 | the one event type (UDP + TCP + control) |
| `dev/capture/CaptureWriter.java` | 869 | streaming writer thread, rotation, byte-level encoder |
| `dev/capture/CaptureAnnotator.java` | 379 | fills cmd/flags/note on the writer thread |
| `dev/capture/LobbyCapture.java` | 733 | lobby TCP deframing + protobuf decode, own file |
| `dev/capture/PacketCapture.java` | 560 | rewritten hot-path intake |
| `dev/capture/CaptureRing.java` | 188 | byte-arena retro ring (135 MB → 11 MB) |
| `dev/DevLoggerImpl.java` | 307 | lock-free, string-free packet path |
| `net/SessionTimeline.java` | 1089 | phase machine, mode/match/round tracking |
| `net/BodyDecoderTable.java` | 201 | 1604 `(cmd, direction)` wire layouts |
| `net/BodyDecoderText.java` | 549 | decoder engine |
| `net/Cmd.java` | 489 | additive predicates |
| `net/LobbyKeySniffer.java` | 295 | extended with lifecycle events |
| `filter/GamePacketTaxonomy.java` | 923 | comments + `@Deprecated` only, no behaviour change |

### New Python: `tools/ffproto/` package + `ffdump.py` `ffverify.py` `fftest.py` `ffsweep.py`

- `python tools/fftest.py` → 65 checks passed, 0 failed
- `python tools/ffverify.py <capturedir>` → re-measures documented protocol facts on real packets
- `python tools/ffdump.py {info,timeline,hist,coverage,unknown,diff,decode,summary,schema,solve}`

### New docs
`IL2CPP_FINDINGS.md` (§7 added), `DUMPER_REWRITE_BRIEF.md`, `CLIENT_AUTH_SURFACE.md`,
`SERVER_VALIDATION_MODEL.md`, `VALIDATION_AND_INBOUND.md`, `CLIENT_TRUST_AUDIT.md`.

### New artifacts in `tools/il2cpp/`
`ff_wire_layouts.json` (937 KB), `ff_message_layouts.json`, `ff_channel_map.json`,
`ff_enforcement_map.json`, `ff_inbound_taxonomy.json`, `ff_trust_audit.json`,
`ff_outbound_registry_full.txt`, plus generator scripts.

---

## 2. THE WIRING I ADDED (the agents could not — `core/` was off-limits to them)

Every one of these had **zero callers** before. Without them the entire rewrite
is dead code that compiles and does nothing. If a future refactor drops one,
the symptom is silence, not an error.

| file | call |
|---|---|
| `core/TcpProxy.java` `queueToRemote` | `LobbyCapture.onLobbyBytes(c.clientPort, c.dstIp, c.dstPort, true, data, 0, data.length)` |
| `core/TcpProxy.java` relay reader, after `onServerBytes` | `LobbyCapture.onLobbyBytes(..., false, buf, 0, n)` |
| `core/TcpProxy.java` `teardown` | `LobbyCapture.onLobbyClose(clientPort)` |
| `core/VpnEngine.java` ctor | `((DevLoggerImpl) logger).setCaptureSink(capture)` |
| `core/VpnEngine.java` `startCapture` | `CaptureAnnotator.resetCounters()` + `LobbyCapture.start(dir)` |
| `core/VpnEngine.java` `stopCapture` | `LobbyCapture.stop()` |
| `core/VpnEngine.java` `stop()` | `LobbyCapture.shutdown()` + `SessionTimeline.reset()` |
| `core/PacketLoop.java` after dispatch | `SessionTimeline.observeUdp(parsed, true)` + `capture().setLayoutSolved(pipeline.isReady())` |
| `core/UdpSessionManager.java` after dispatch | `SessionTimeline.observeUdp(parsed, false)` |

> **`PacketPipeline` has `isReady()`, NOT `isSolved()`.** An agent's integration
> note said `isSolved()`; that does not exist and would not compile.

---

## 3. PROTOCOL FACTS ESTABLISHED THIS SESSION

### 3.1 "CS" is overloaded — two different meanings
- **RUDP namespace: `CS` = Clash Squad** (a game mode). Proven by
  `GameFacade::IsCSMode` called at the Cmd 413 send site, and by surviving enum
  member names `ECSItemBuyType_*`, `ECSShopItemFilter_*`. Siblings: CSGAMEZONE
  (411), CS_NOTIFY_TOKEN_NUM (957), CSSO = Clash Squad **Strike Out**
  (454/455/463-468), CSROUNDDRAGON, CSABILITYPOINT.
- **`proto.*` lobby namespace: `CS` = Client→Server** (`proto.CSPurchaseReq`).
  This is the real-money store, a completely different protocol.

### 3.2 The Clash Squad shop buys nothing (dead idea, do not retry)
Outbound Cmd 413 `RUDP_PURCHASE_CSITEMS`, class `message.DAFMJPEBBHI`:
`uint contextId`, `List<uint> itemIds`, `ECSItemBuyType {None,Normal,DoubleClick}`.
**No price field, no token field.** The server owns price and balance and
announces both (957 and 412 are S→C). `COW.CSShopItemData.price` is a
CLIENT-SIDE CONFIG TABLE — editing it changes only your own UI.

### 3.3 Cmd 144/145/146 — the position correction channel (NEW)
- **144 `RUDP_FORCE_SYNC_PLAYER_STATE`** — bidirectional.
  - inbound class `PGABPEBFLOK`: `uint playerId`, `uint tick`,
    `PMFGOGFPDHM` = **Vector3 of 3×int (millimetres)**,
    **two** `BDOPLCJODBN` = 3×short each (body facing + aim), 2 pose bytes,
    ushort, 3 bools, int, uint.
  - outbound class `PJEENOJINOA` (zero fields) from
    `PlayerNetwork::RequestFoceSyncPosition`.
  - handler `0x07a42b0c` resolves the player **by id**, null-checks, calls
    `IsLocalPlayer`, then forces `PhysXState`/`PhysXPose`/water/vehicle.
  - **This is the snap-back carrier** `TELEPORT.md` §2 could not identify.
- **145 `RUDP_TELEPORT_PLAYER`**, **146 `RUDP_CONFIRM_SERVERFORCE_SYNC`** (the ack).

> **144 does NOT help ESP.** No bones — one root position + two rotation
> triples, identical fidelity to Cmd 2001. And it is a rare correction event:
> ~47-102 packets per match vs ~76,000 position-stream packets. ~1000× too
> sparse to drive ESP, and redundant with the entity chain.

### 3.4 The manipulable surface is ONE message
Two agents reached this independently:
- **Cmd 2001 is the only outbound in-match message with a plaintext body.**
  Every reliable gameplay message (fire, reload, use-item, weapon-switch,
  purchase, hit-claim) is TEA-encrypted.
- **Clean law: reliable ⟺ TEA-encrypted; unreliable ⟺ plaintext.** Exceptions:
  cmd 2, cmd 5, cmd 2003, and 1-2 pre-key packets.
- So what we can read without the key is exactly what we may safely touch.
- USABLE: self position ≤2.77 m/tick, coherent velocity, withholding. That is
  what teleport/ghost/freeze already do. **No new usable lever was found.**
- Untested leads: 2001 v11/v12 state+pose, v18 self-reported ping,
  2002/2006/2031 vehicle twins.
- KICK-RISK: injecting ANY new reliable message mints an OrderID the
  reliability layer never issued → window desync → disconnect.
-damage/kill forgery, hit-zone spoof, fire
  blob. All behind the `GFHPFJMGEKF` checksum. **This is the unknow point , we ust cracked this is an unknow job we ust crack the checksu of what is it doing and can we replicate it?- > this cause and unlockeds alots of things**

### 3.5 Lobby TCP
- Framing `GCommon.TCPMsgPacket`: `[Cmd:1 byte][Length:4 bytes BIG-ENDIAN][Data]`.
  `Unserialize` @`0x082bf11c`. **101..150 = INIT** (`IsInitPackage` @`0x082bf3b4`),
  **151..255 = HEARTBEAT** (@`0x082bf3c4`), everything else = DATA (protobuf).
- **The uplink is AES-encrypted.** `TCPSession2::Send` @`0x06b52eb0` calls
  `Encrypt` @`0x06b55d3c`; exactly one caller in the whole image, and
  `TCPSession2` has **no `Decrypt` method at all**. Matches the measured
  6.31 bits/byte downlink entropy. So the request carrying mode *selection* is
  ciphertext.
- **The game mode arrives in plaintext on the downlink**, in the same message as
  the session key: `tcp.MatchmakingSussNtf` (`EMatchmaking.Proto_MATCHMAKINGSUSS_NTF = 5`).
  field 1 `match_id`, 2 `server_addr "ip:port"`, 3 `secret` (32 hex = SECRET_KEY),
  6 `map_id`, **7 `game_mode`**, **8 `match_mode`**, 21 `group_mode`, 42 `udp_mask`.
  - **Fields 2 and 3 are EMPIRICALLY PROVEN on our build** (the key sniffer reads
    them and the key decrypts the stream: TEA 2896/2896, CRC7 3462/3462).
  - **Fields 6/7/8/21 are INFERENCE-GRADE** — the `[ProtoMember]` numbers come
    from `dump.cs`, a different build. The parser is a self-describing protobuf
    walk, so a wrong guess logs an out-of-range mode LOUDLY. One real lobby
    capture settles it.
- Enums: `EMatch.GameMode` / `message.NIKKALKPIBO` (84 members; BattleRoyale=1,
  CS=15, TDM=24, StrikeOut=36, PDM=61, FPPCS=82, HippoCrisis=88,
  OfflineTraining=301). `EMatch.MatchMode` / `message.DLBMPCCFKKM` (18 members;
  CASUAL=1 RANKING=2 ROOM=3 TRAINING=5 CSRANKING=6 CS_PEAK=16 …).
  `EMatch.GroupMode` = SOLO/DUAL/TRIPLE/QUAD.

### 3.6 Reliability layer (recovered from the binary)
`GCommon.UDPReliableTracking::PacketRecv` @`0x082c3a7c` returns
`{ENQUEUE=0, PENDING=1, DROP=2}`. `d = (OrderID − m_RequiredOrderID) mod 2^16`;
`d==0` deliver+advance; `0<d<0x8000` **PENDING, head-of-line blocks everything
behind it**; `d≥0x8000` duplicate, discard. Non-reliable bypasses it entirely.
From `UDPParameters::.cctor` @`0x082c0c9c`: `MAX_RESEND_COUNT=8`,
`FIRST_RESEND_TIMEOUT=0.5s`, `RESEND_TIMEOUT=0.3s`, `FORCE_RECONNECT_TIMEOUT=10s`,
`RUDP_MAX_ACK_MASK_LEN=25`, `MTU_LIMIT_C2S=1287`.

**Byte 0 (`MsgKey`) is the classifier, plaintext, no key needed:**
90–99 = reliable (10-byte header, has OrderID), 100–109 = non-reliable (8-byte
header). 100.0% consistent across the corpus.

### 3.7 Anti-cheat surface
`COW.GamePlay.AKHFIKBPKFM` holds 46 `Cheating_*` codes (`WallHack`, `SpeedHack`,
`MemoryHack`…) — **every one names a local-memory or local-physics tamper.**
There is no `Cheating_PacketDrop`/`BadSequence`/`AckStorm`/`Proxy`. Detection is
native, in `libGGP.so` via `ffantihack.PCNABJAFBDO`. A sweep of all 1384 inbound
cmd names for CHEAT/HACK/KICK/BAN/VERIFY returns **zero** hits — no inbound kick,
ban, or integrity challenge message exists.
**But** `GCommon.NetworkStats` counts `TotalRUDPPacketResent` and stall stats, and
`COW.EventLogger::LogPing` uploads them **plus the top resent cmd ids** at match end.

---

## 4. BUGS FOUND AND FIXED THIS SESSION

1. **The whole dumper was dead code.** 10 entry points, 0 callers. Fixed (§2).
2. **`pipeline.isSolved()` does not exist** — an agent's integration note was
   wrong; it is `isReady()`.
3. **Ghost could starve ACKs.** Its pre-solver fallback called
   `GamePacketTaxonomy.isMovementStream()`, a 21–40 byte shape test — and on
   current traffic the only thing that fits is the **Cmd 2 ACK stream**. The
   exact-id path already set `isMove=false` for exactly this reason; the
   fallback did not. Also `isKeepalive` was gated on `!isMove`, so a shape
   collision suppressed the real position drop too. **Fixed: `isMove=false` in
   the fallback as well.**
   Measured dose-response justifying it: dropping 16/36/50% of ACKs produced
   21.8/37.5/46.0% inbound retransmission, with one OrderID resent **9 times =
   1 + MAX_RESEND_COUNT**, the server's budget exactly exhausted.
4. **TCP double-capture conflict** — agents 1 and 3 each built a TCP path.
   Resolved: `LobbyCapture` (deframes + decodes, own file) is wired;
   `PacketCapture.recordTcp` is left unwired.

### Defects the rewrite fixed (from the brief's D-list)
D1 lobby never captured · D2 `setFreezePhase` dead so every record stamped
BEFORE · D3 payload truncation · D4 nothing written until stop (220k records in
RAM; ring alone pre-allocated **135 MB inside a VpnService** — itself a reason
Android kills the process) · D5 shape-based classification · D6 no protocol
state on the record · D7 no lifecycle context · D8 `DevLoggerImpl` built a
String per packet inside a global lock on the hot path · D9 partial drop
accounting · D10 StringBuilder per record.

---

## 5. THE MOST IMPORTANT OPEN SIGNAL

`python tools/ffverify.py captures/phone_kick` reports:
```
outbound packets left the tunnel intact   453/481  94.2%   broken: {'UDP_PLAYER_STATE_SYNC': 28}
```
Every other capture is **100.0% intact over ~350,000 outbound packets**
(phone_pull 331838/331838, phone_pull10 6619/6619, phone_pull11 14065/14065).

**28 corrupt outbound position packets, exclusively in the session where the
player was kicked.** A packet with a stale CRC-7 is silently discarded by the
server, which presents as "teleport set me back". That capture predates the
teleport rewrite (`PositionSync.rebuild` now verifies the layout before writing),
so it may already be fixed — but this is the **fingerprint to watch for**, and
the new dumper records CRC validity per packet so it will surface immediately.

> **Operational trap, general:** edit any byte at offset ≥2 and you MUST
> recompute CRC-7, or the packet is silently dropped and it looks like a server
> correction.

---

## 6. UNVERIFIED CLAIMS — do not trust these until re-derived

An agent produced three "corrections" earlier in this project from `dump.cs`
that were ALL WRONG and had to be reverted against a 628-sample wire
correlation. Treat the following the same way:

1. **`net/PacketFlags` javadoc says "Flags is the authoritative encryption
   indicator." An agent claims it is NOT** — that ~16% of "plaintext" reliable
   bodies (183 observed, 147 then decoding byte-exactly) are actually TEA
   ciphertext with `Flags == 0`. If true, `net/PacketPipeline.dispatch` skips
   decryption for those, so ESP and the filters never see them — a
   one-condition change. **NOT VERIFIED BY ME.**
2. **`tools/ffdecode.py solve` picks the wrong `HEAD_SECRET` permutation in 3 of
   5 captures** (scores only the Length identity, which cannot separate
   SendOption/Flags nor Cmd/OrderID). Claimed fix: add a cmd-in-registry test
   then an OrderID-monotonicity tie-break. **NOT VERIFIED BY ME.**
3. **"Nothing in match traffic is ZIP-compressed"** (claimed 64% TEA, 36%
   plaintext), contradicting `PROTOCOL_CIPHER.md` §3. **NOT VERIFIED BY ME.**
4. **Cmd 106 is never sent outbound in 4/4 matches despite active fire.** If
   true this complicates the "client-authoritative hits" finding in
   `IL2CPP_FINDINGS.md` §1 and bears on the open §5.5 question. **NOT VERIFIED.**

---

## 7. WHAT IS LEFT TO DO

1. **Commit.** Nothing is committed. `HEAD` = `47b5854`.
2. **Live in-match verification** — never done. Specifically: does
   `LobbyCapture` actually catch `MatchmakingSussNtf` and log a correct game
   mode? That single test converts §3.5 fields 6/7/8 from inference to fact.
   Watch for an out-of-range mode value, which is the designed loud failure.
3. The tooling agent died before wiring its "effect-split diff" into the CLI.
4. Resolve the four unverified claims in §6.
5. `SessionTimeline.observeUdp` cannot see the peer endpoint (a `UdpPacket`
   carries no peer address), so match liveness is keyed on command identity
   (`Cmd.isWorldStateStream`) instead. This was deliberate and validated on 146
   captures: it removed 18 of 24 phantom match-splits, 140/146 files now yield
   exactly one match.

---

## 8. RULES THAT COST REAL DEBUGGING CYCLES — do not relearn these

1. **The shipped `libil2cpp.so` has ENCRYPTED method bodies.** Use
   `C:\Users\Tonyt\Documents\FF-RE\bin\libil2cpp_dec.so` (same RVAs, plaintext)
   via `tools/il2cpp/il2cpp_scan.py`. An empty or garbage body is the tell.
2. **`C:\Users\Tonyt\Videos\ZRT-Toolbox\Dump\dump.cs` is a DIFFERENT BUILD.**
   Structure only (field order, types, enum member names are build-stable and
   obfuscated names match across builds). Never its RVAs. **Never prefer its
   field order over a reading re-derived from our own image.**
3. **Enum member names survived obfuscation.** This is the single most
   productive lever in the binary. `COW.GamePlay` method and parameter names and
   Unity type names survived too; `message.*` field names did not.
4. **Messages are bidirectional with DIFFERENT classes per direction.** Key every
   decoder on `(cmd, direction)`, never on `cmd` alone.
5. **Never gate on a raw byte window or a roster-sized constant.** A freeze
   policy once dropped everything in a raw 21–450 B window and ate 88% of
   inbound including the player's own damage feed.
6. **Rewrite in place; never inject, never withhold reliable traffic.**
7. **Build with PowerShell alone**, not chained with other shell work:
   `cd fakelag/fakelag-beta; .\gradlew.bat assembleDebug`. Verify the APK
   timestamp. A build reporting `UP-TO-DATE` everywhere did not actually
   recompile — use `clean assembleDebug` to really check.
8. **Java 8 language level** — no records, no `var`, no switch expressions.
9. **Every claim gets a number.** "6709/6709", not "it works".
