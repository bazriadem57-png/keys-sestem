# Session 2026-09-18 — aim rebuild + coexisting synthetic touch (nvmux), Rust

**Read this first after a compact.** What changed today, what is proven on
hardware, how to build/run it, and what is left. Everything below is on the
working tree ready to commit; the touch-coexistence feature is **working in a
live Free Fire match on `R3GL10AHL7P`** (walk + aim at the same time).

---

## The arc of the day

1. **Dv-test prep** — surveyed the aim / ESP / freeze mechanics and the debug
   surface (dev-mode, ESP-debug HUD, always-on capture). Enabled dev mode +
   ESP-debug on the phone and emulator (prefs seeded, existing tuning preserved).
2. **Coexistence research** — three web-research passes → **`docs/EXTERNAL_TAP_COEXISTENCE.md`**
   (the public landscape + the Android one-device-per-window rule).
3. **Aim subsystem stripped** to nothing (owner's call, "full clean in one pass").
4. **New Aim button** — a Freeze-style toggle that runs an endless test swipe.
5. **The coexistence wall hit + fixed** — the Shizuku `injectInputEvent` path is
   a second input device, so it cancels the user's fingers (walk drops the moment
   aim starts). Built the **grab-and-merge daemon** that fixes it.
6. **Ported the daemon C → Rust**, added shared geometry utils, and simplified
   the Java control path.

---

## 1. Aim subsystem: DELETED, replaced by a coexistence tester

The old head-targeting aim (ring lag-compensator, FOV cone, calibrator, edit
overlay, `TouchWatcher` yield logic, ~30 tuning knobs) is **gone**:

- **Deleted classes:** `ui/aim/AimCalibrator.java`, `AimEditOverlay.java`,
  `TouchWatcher.java`.
- **`ui/aim/AimInjector.java`** rewritten (~980 → ~330 lines) into the driver for
  the nvmux daemon (below). Keeps only the Shizuku availability/permission
  plumbing.
- **`ui/render/EspRenderView.java`** — all aim-assist statics, paints, result
  fields, `selectAimTarget`, and the aim debug readout removed. **The ESP pose
  ray survives** (`AIM_RAY_M`, `aimPaint`, `bodyPaint`, `SHOW_POSE`) — it is ESP
  facing, not aim-assist; it was the one thing tangled in and was preserved.
- **`config/EspTuning.java`** — all aim load lines, `loadAimInjector`, ~30
  `setAim*` setters, `AIM_*` bounds and `DEF_AIM_*` removed. HP-bar/ESP/zoom
  knobs kept.
- **`ui/panel/EspTunePanel.java`** — aim imports, self-test, calibrate,
  edit-overlay teardown removed.
- **`ui/settings/UiBindings.java` + `res/layout/activity_main.xml`** — the dead
  "Aim assist" settings row removed; the **"Aim button"** visibility toggle kept.
- Left in place (harmless): `Prefs.KEY_AIM_*` strings (hard rule 5 — never rename
  persisted keys) and `Slot.AIM_INJECTED`/`AIM_INJECT_THREW` diag slots.

The **Aim floating button** (id 9) is now a **toggle** (like Freeze), not a hold.
On → an endless circle swipe; off → lifts. It is a **coexistence test harness**,
not targeting — the payoff is proving injected + real touch can coexist.

---

## 2. Why coexistence is hard (the wall), and the fix

Android's `InputDispatcher` allows **one input DEVICE active per window**; a
fullscreen game is one window. Two of the user's real fingers coexist because
they are **one device** (the panel). A Shizuku-injected event is forced to device
id −1 — a **second device** — so it and the user's finger cancel each other
(`ACTION_CANCEL`). That is exactly the reported "I can't walk while aiming; my
touch cancels the swipe." No flag or tuning changes it. Full analysis:
`docs/EXTERNAL_TAP_COEXISTENCE.md`, and the earlier `docs/DUAL_TOUCH_INJECTION.md`.

**The fix — `nvmux` (grab-and-merge):** a tiny native helper, spawned via Shizuku
(shell uid 2000, **no root**), that:

1. `EVIOCGRAB`s the real touchscreen (`/dev/input/event8`, `sec_touchscreen`) so
   its events reach only us;
2. re-emits **BOTH** the user's contacts **and** one synthetic contact through a
   single `/dev/uinput` clone that carries the panel's identity;

so Android sees **one device with many pointers** — like a two-thumb session,
nothing cancels. Proven on-device: user finger + synthetic circle move
independently, walk + aim work together in a live match.

### The four bugs found + fixed getting it to work
1. **SELinux abstract-socket `connectto` denial** (app→shell domain) — the daemon
   is driven over its **stdin pipe** (`ShizukuRemoteProcess.getOutputStream()`),
   which rides Shizuku's binder, not a socket.
2. **Respawn storm** — `ShizukuRemoteProcess.exitValue()` does not throw
   `IllegalThreadStateException` while alive, so the "is it dead?" poll read
   healthy as dead and killed + respawned it every ~320 ms (before it finished
   `setup_clone`). Fix: keep the daemon once spawned; detect death reactively
   when a stdin write fails.
3. **Slot cross-contamination** — the MT-B protocol is stateful; after the
   synthetic finger emits `ABS_MT_SLOT 9`, a real finger's next X/Y (sent without
   restating its slot) landed on slot 9, so the two pointers "switched back and
   forth" and taps on the Aim button/nav got corrupted. Fix: strict slot
   discipline — re-select the slot before every contact's attribute block
   (`set_slot` de-dups).
4. **Swipe landed on the button** — injecting at the button dragged the button.
   Fix: the swipe runs in the game's look region (right-centre), clear of the
   overlay button cluster.

Plus: **walk-then-aim needs no lift** — a finger already down at grab time is a
change-driven "latecomer" the kernel never resends, so `nvmux` re-injects the
held contacts via `EVIOCGMTSLOTS` right after grabbing.

### Safety rails (a grabbed panel is a single point of failure for touch)
Heartbeat lease (no `P` within ~1.5 s → release), **Volume-Down escape**
(different device, always works), release on every exit path + signal handlers +
fd close, and stdin-EOF (app died) → release + exit.

---

## 3. It is Rust now (was C)

The daemon started as `native/touchmux/nvmux.c` (proven), then was **ported to
Rust** in the existing native workspace, per the owner's ask.

- **`native/nuvola-core/src/geom.rs`** — shared screen-space Angle/Math utils
  (`norm`/`denorm` px↔0..65535 using ESP's screen dims, `circle_point_norm`,
  `clamp_circle_center`, `advance_angle`, `screen_offset_to_yaw_pitch_deg` for
  future real aim). Pure, `#![forbid(unsafe_code)]`-clean, **6 unit tests**.
- **`native/touchmux/`** — new Rust **bin crate `nuvola-touchmux`** → binary
  `nvmux`. It owns the `unsafe` evdev/uinput FFI (so `nuvola-core` stays
  unsafe-free) and self-drives the swipe circle via `geom`. It has its **own
  `[workspace]`** and is **excluded** from `native/Cargo.toml` so the host-only
  test workspace (Windows / CI) never compiles its Linux-only structs.
- **`ui/aim/AimInjector.java`** now spawns `nvmux` via `Shizuku.newProcess` (by
  reflection — it is `@hide`) and sends a line protocol over stdin:
  `S <cx_px> <cy_px> <r_px> <w> <h>` (start; ESP supplies the screen dims),
  `P` (heartbeat every ~400 ms), `U` (stop), `Q` (quit). The daemon owns the
  circle math.

### Build / ship
```
# host tests (excludes touchmux):
cd native && cargo test                     # 92 pass (incl. geom)

# the daemon, android-only, from its own workspace:
cd native/touchmux
ANDROID_NDK_HOME=<sdk>/ndk/29.0.13846066 \
  cargo ndk -t arm64-v8a --platform 21 build --release
cp target/aarch64-linux-android/release/nvmux \
   ../../fakelag/fakelag-beta/app/src/main/jniLibs/arm64-v8a/libnvmux.so
```
`libnvmux.so` ships in the APK (`android:extractNativeLibs` via
`packaging { jniLibs { useLegacyPackaging = true } }`, so it extracts to
`nativeLibraryDir` and Shizuku can `exec` it). It is a PIE arm64 executable, NOT
a JNI lib — it must run as a separate shell-uid process for the `EVIOCGRAB` /
`/dev/uinput` privileges the app process lacks.

---

## Verified on hardware (R3GL10AHL7P, Samsung SM-S948U1, Android 14/16)
- `nvmux` standalone selftest: panel → clone (slots=9, x/y 0..4095) → grabbed →
  released cleanly (C and Rust identical).
- In a live Free Fire match: **walk + aim swipe coexist**; toggling Aim off and
  exiting the app work normally (no stuck input); Volume-Down bail works.
- 92 host Rust tests green; debug APK builds + installs; Shizuku granted.

## Left for next time
- The swipe is a **test circle** in the look region. Turning it into **real aim**
  = feed ESP's target head-point (screen px) → `geom::screen_offset_to_yaw_pitch_deg`
  → a controlled swipe delta instead of a circle. `geom` already has the helper.
- The old aim controller (settle/gain/deadzone tuning) is gone; a real aim will
  want a small proportional controller again (in Rust this time).
- Decide whether `libnvmux.so` should also be **obfuscated / live-updated** like
  `libnuvola_native.so` (currently a plain source build; it's a separate binary).
- `Prefs.KEY_AIM_*` + `Slot.AIM_*` are orphaned but intentionally kept (rule 5 /
  diag). Prune later if desired.

## References
- `docs/EXTERNAL_TAP_COEXISTENCE.md` — the landscape + decision matrix.
- `docs/DUAL_TOUCH_INJECTION.md` — the hardware-proven design + probe log.
- `native/touchmux/src/main.rs` — the daemon (Rust).
- `native/nuvola-core/src/geom.rs` — the angle/math utils.
- `ui/aim/AimInjector.java` — the Shizuku spawn + stdin driver.
- Memory: `fakelag-touch-coexistence`, `nuvola-rust-native-port`,
  `fakelag-adb-path-and-user-traps`.
