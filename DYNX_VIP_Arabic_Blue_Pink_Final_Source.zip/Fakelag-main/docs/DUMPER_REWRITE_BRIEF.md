# Dumper rewrite — shared briefing

**Every agent working on the dumper rewrite MUST read this file first, then
`docs/IL2CPP_FINDINGS.md`, then `docs/PROTOCOL_MASTER.md`.** This file is the
contract between four parallel agents. The seams in §4 are FIXED — do not
redesign them, other agents are coding against them right now.

---

## 0. What we are building and why

The app is an Android `VpnService` that tunnels one game's traffic, parses its
UDP protocol, and runs filters (ghost / freeze / teleport / ESP) on it. The
"dumper" is the developer capture subsystem: it records what crossed the tunnel
so we can decode the protocol offline and improve the filters.

The current dumper is **not good enough**, in specific measurable ways listed in
§2. We are rewriting it so a single capture answers:

- every packet in both directions, on **both transports**, untruncated
- **what each packet is** — by real command name, not a size guess
- **what the app did to it** — pass / drop / rewrite, and which filter decided
- **where we were** — lobby, matchmaking, which game mode, which match, which
  server, which round
- **what we could not decode**, explicitly, so the unknown surface is a number
  instead of a silence

## 1. Ground truth about the protocol (do not re-derive)

Full detail is in `docs/IL2CPP_FINDINGS.md`. The essentials:

- **Transport A — lobby, TCP.** Protobuf. Class names in the binary are
  `proto.*Req` / `proto.*Res` (e.g. `proto.CSPurchaseReq`); there the `CS`
  prefix means *Client to Server*. **The UDP session key arrives in plaintext on
  this channel** — `net/LobbyKeySniffer.java` already recovers it. Handled by
  `core/TcpProxy.java`, which currently captures NOTHING.
- **Transport B — match, UDP.** Custom framing, fully solved:
  - byte 1 is a **CRC-7** over bytes 2..end (`net/Crc7.java`)
  - header fields are **XOR-masked with a per-session mask and cyclically
    permuted** by a `HEAD_SECRET` field permutation (`net/HeaderLayout.java`,
    solved at runtime by `net/SessionKeySolver.java`)
  - bodies may be **QQ-TEA** encrypted (16 rounds, LE, SALT_LEN=2, ZERO_LEN=7 —
    `net/Tea.java`)
  - body encoding is `FastBinaryReader`/`Writer`: **LEB128 varint**, zigzag for
    signed, float = float32-bits-as-varint, `List<T>` count = zigzag varint.
    **`ReadByte`/`ReadBoolean` are 1 RAW byte** and `ReadFixUInt16` is 2 RAW LE
    bytes — those two break a naive varint walk. See `IL2CPP_FINDINGS.md` §3.
- **Command ids.** `net/CmdCatalogue.java` holds **all 1974 command ids** with
  real names, **1384 marked receivable** (client registers an inbound handler).
  Generated from two independently derived sources that agreed with zero
  disagreements. API: `name(int)`, `nameOr(int)`, `describe(int)`,
  `isKnown(int)`, `isReceivable(int)`, `isTransport(int)`,
  `isReliableChannel(int)`, `isUnreliableChannel(int)`, `allIds()`.
  `COUNT = 1974`, `INBOUND_COUNT = 1384`.
- **`net/Cmd.java`** is the small enum for the ~60 ids the app *acts* on, and
  carries behaviour predicates: `isTransportLayer`, `isWorldStateStream`,
  `isCombatFeedback`, `isOwnPositionCarrier`, `isMountedPositionCarrier`,
  `nameOf`. Keep this split: `Cmd` = behaviour, `CmdCatalogue` = reference.
- **Messages are bidirectional with DIFFERENT classes per direction.** The same
  id means one struct outbound and another inbound. Any decoder MUST be keyed on
  `(cmd, direction)`, never on `cmd` alone.
- **Machine-readable artifacts in `tools/il2cpp/`** — use these, do not
  re-derive: `ff_inbound_registry.tsv` (1384 id to inbound class + handler),
  `ff_outbound_registry.txt` (461 send sites), `ff_outbound_classes.json`
  (field layouts for 288 outbound classes), `ff_deobfuscation_map.json` (1122
  obfuscated-to-original names shipped inside the binary), `il2cpp_scan.py`
  (capstone harness over the decrypted image).

### Two traps that have each cost hours

1. **The shipped `libil2cpp.so` has encrypted method bodies.** Use
   `C:\Users\Tonyt\Documents\FF-RE\bin\libil2cpp_dec.so` — same RVAs, plaintext.
   An empty or garbage function body is the tell.
2. **`C:\Users\Tonyt\Videos\ZRT-Toolbox\Dump\dump.cs` is a DIFFERENT BUILD.**
   Use it for *structure only* (field order, types, enum member names — those are
   build-stable, and obfuscated names match across builds). **Never** feed its
   RVAs to our image, and **never** prefer its field order over a reading
   re-derived from our own image. A previous agent trusted it and produced three
   wrong "corrections" that had to be reverted.

## 2. What is wrong with the dumper today — fix these, by name

Read the files before changing them: `dev/capture/PacketCapture.java` (383),
`CaptureRecord.java` (117), `CaptureRing.java` (94), `DecodedDumper.java` (1118),
`FreezeDiffAnalyzer.java` (523), `TelemetryCollector.java` (213),
`dev/DevLoggerImpl.java` (258).

| # | Defect | Evidence |
|---|---|---|
| D1 | **TCP/lobby is never captured.** Only `PacketLoop` (outbound) and `UdpSessionManager` (inbound) feed the capture. `TcpProxy` has no capture call at all. | grep for `recordOutbound`/`recordInbound` returns 2 call sites, both UDP |
| D2 | **`setFreezePhase()` has zero callers**, so `Phase` is derived only from `filterMask` and every record in a freeze-off capture is `BEFORE`. `FreezeDiffAnalyzer` splits on a field that never varies. | grep `setFreezePhase` finds only the definition |
| D3 | **Payloads are truncated** to `hexLimit` on write and to `MAX_PAYLOAD_BYTES = 2048` on capture. Entity chains reach ~630 B and survival chains more; past captures are unusable because the tail was cut. | memory `fakelag-capture-hexlimit-truncation` |
| D4 | **Nothing is written until `stop()`.** Records accumulate in a 220 000-entry `ArrayList` in RAM; a crash, an OOM kill or a long session loses everything. Android will kill a VpnService holding hundreds of MB. | `writeRawCapture` is only reachable from the stop path |
| D5 | **Classification is by byte-shape, not command id.** `modeKeeps` calls `GamePacketTaxonomy.kind(buf, off, plen, outbound)` — heuristics over raw bytes — even though the parsed `cmd` is available for the same packet. The catalogue makes every one of those heuristics obsolete. | `PacketCapture.modeKeeps`; `GamePacketTaxonomy` is 779 lines of heuristics |
| D6 | **The record carries no protocol state.** No cmd, no CRC-valid flag, no reliable/unreliable, no encrypted/zipped, no decrypt result, no order id — all already computed by `net/UdpPacket` and then discarded. | `CaptureRecord` field list |
| D7 | **No session/lifecycle context.** The capture cannot say which mode was joined, when the match started, when the key rotated, or when the server endpoint changed. | no such fields anywhere |
| D8 | **Two parallel redundant logging systems.** `DevLoggerImpl` builds a `String` per packet **inside a global `synchronized (devLock)` block on the hot path**, capped at 20 000 events / 512 payload bytes, while `PacketCapture` does the same job lock-free. The `DevLogger` path is a hot-path contention bug. | `DevLoggerImpl.logPacket` |
| D9 | **Drop accounting is partial.** `droppedByCap` counts ring-cap drops, but the `modeKeeps` filter discards silently, so "how many packets existed" is unknowable from the file. | `PacketCapture.record` |
| D10 | **`hex()` builds a `StringBuilder` plus a `String` per record** at write time; a 220 k-record capture does 220 k of each. Write bytes, not Java Strings. | `PacketCapture.hex` |

## 3. Hard constraints — violating any of these breaks the app in a live match

Learned at the user's expense. Not negotiable.

1. **The capture path must never change what the tunnel sends.** The dumper is an
   observer. It may not drop, delay, reorder or mutate a packet. If you need a
   payload, copy it.
2. **No blocking, no locks, no allocation storms on the hot path.** The tun read
   loop and the UDP recv threads are latency-critical — the game's own timing
   sits on top of them. Copy bounded bytes, hand off, return. File I/O,
   formatting, decoding and annotation belong on the writer thread.
3. **Never starve the transport layer.** Acks, pings, heartbeats and fragment
   reassembly must always flow; withholding them trips the client's disconnect
   logic and kicks the player out of a match. Not the dumper's job (see 1), but
   do not add a "capture pause" that stalls a recv thread either.
4. **Never gate on a raw byte window or a roster-sized constant.** A previous
   freeze policy dropped everything in a raw 21-450 B window and ate 88 % of
   inbound including the player's own damage feed. Mode-specific and
   roster-sized constants silently break in other game modes. Identify by
   command id; fall back to shape ONLY while the header encoding is unsolved.
5. **Handle the pre-solver window explicitly.** For the first few hundred packets
   of a session, and again after a key rotation, the header layout is unknown and
   `cmd` is unavailable. Records from that window must be *marked as such*, not
   guessed at and not silently dropped.
6. **The session key must land in the capture file.** Without it an encrypted
   capture is undecodable, and on a non-rooted phone there is no other way to
   obtain it. This already works — preserve it.
7. **Build with PowerShell alone**, never chained with other shell work:
   `cd fakelag/fakelag-beta; .\gradlew.bat assembleDebug`. Java 8 language level —
   no records, no `var`, no switch expressions, no streams in hot paths.
8. **Every claim in a report gets a number.** This project's standard is
   "6709/6709 decoded", not "decoding works". If you assert a layout, state the
   sample count you verified it over.

## 4. THE SEAMS — fixed interfaces between the four agents

Code against these exactly. If you believe a seam is wrong, say so in your
report — do not change it unilaterally.

### 4.1 `dev/capture/CaptureEvent.java` — owned by AGENT 1

The single event type for everything. Mutable and pooled; never shared across
threads except through the queue.

```java
public final class CaptureEvent {
    public static final int SRC_UDP = 0, SRC_TCP = 1, SRC_CTRL = 2;
    public static final int OUT = 0, IN = 1;
    public static final int PASS = 0, DROP = 1, HOLD = 2, REWRITE = 3;

    // flag bits, filled by AGENT 2
    public static final int F_PARSED    = 1 << 0;   // header layout resolved
    public static final int F_CRC_OK    = 1 << 1;
    public static final int F_RELIABLE  = 1 << 2;
    public static final int F_ENCRYPTED = 1 << 3;
    public static final int F_DECRYPTED = 1 << 4;   // TEA succeeded
    public static final int F_ZIPPED    = 1 << 5;
    public static final int F_LEN_MATCH = 1 << 6;
    public static final int F_PRESOLVER = 1 << 7;   // captured before layout known

    public long   seq;
    public long   tsMs;
    public long   tsNanos;      // monotonic, for inter-packet timing
    public int    src;
    public int    dir;
    public int    peerIp, sp, dp;
    public int    len;          // TRUE on-wire length even if payload is capped
    public byte[] payload;      // copied bytes, valid over [0, copyLen)
    public int    copyLen;
    public int    decision;
    public int    filterMask;
    public int    teleType;

    // filled by AGENT 2, on the writer thread
    public int    cmd = -1;
    public int    orderId = -1;
    public int    flags;
    public String note;         // decoded field dump, nullable

    // filled by AGENT 3, on the writer thread
    public int    phaseId;      // SessionTimeline phase at capture time
    public int    matchSeq;     // increments per match joined
}
```

### 4.2 `dev/capture/CaptureAnnotator.java` — owned by AGENT 2

```java
public final class CaptureAnnotator {
    /** Fills cmd/orderId/flags/note on the writer thread. Never throws. */
    public static void annotate(CaptureEvent e);

    /** Human-readable decode of one body; null when undecodable. */
    public static String decodeBody(int cmd, int dir, byte[] buf, int off, int len);

    /** Per-run coverage stats for the capture footer. */
    public static String coverageLine();
}
```

### 4.3 `net/SessionTimeline.java` — owned by AGENT 3

```java
public final class SessionTimeline {
    public static final int P_UNKNOWN = 0, P_LOBBY = 1, P_MATCHMAKING = 2,
                            P_LOADING = 3, P_MATCH = 4, P_POSTMATCH = 5;

    /** Feed every lobby TCP segment, both directions. Never throws. */
    public static void observeTcp(byte[] buf, int off, int len,
                                  boolean outbound, int peerIp, int port);

    /** Feed every parsed UDP packet. Never throws. */
    public static void observeUdp(com.fakelag.cryhard8.net.UdpPacket p, boolean outbound);

    public static int phaseId();
    public static String phaseName();
    public static int matchSeq();

    /** e.g. "MATCH mode=CS_RANKED srv=1.2.3.4:9001 round=3 t+184s" */
    public static String describe();

    /** Lifecycle events since the last drain, for the capture stream. */
    public static java.util.List<String> drainEvents();
}
```

### 4.4 Output format — owned by AGENT 1, consumed by AGENT 4

Line-oriented UTF-8, streamed, one record per line, `#` for header/comment lines.
Columns are **fixed and positional** up to `note`, which is free text and always
last:

```
seq ts_ms dt_us src dir decision phase match cmd cmdname flags peer sp dp len hexlen payload_hex note
```

`flags` is the hex of the `F_*` bitfield. `cmdname` is `CmdCatalogue.nameOr(cmd)`
or `-` when unresolved. `payload_hex` is the FULL payload. A `#` line may appear
between records carrying a lifecycle event from `SessionTimeline.drainEvents()`.

## 5. Work split — stay inside your files

| Agent | Owns (may create/edit) | Must NOT touch |
|---|---|---|
| **1 — capture core** | `dev/capture/CaptureEvent.java`, `CaptureRecord.java`, `CaptureRing.java`, `PacketCapture.java`, new `CaptureWriter.java` | `net/**`, `filter/**`, `core/**` |
| **2 — decode/annotate** | `dev/capture/CaptureAnnotator.java`, `net/BodyDecoder*.java`, `net/Cmd.java`, `net/CmdCatalogue.java` (additive only) | `dev/capture/PacketCapture.java`, `core/**` |
| **3 — lobby + lifecycle** | `net/SessionTimeline.java`, `dev/capture/LobbyCapture.java`, `net/LobbyKeySniffer.java` | `dev/capture/PacketCapture.java`, `filter/**` |
| **4 — offline tooling** | `tools/**`, Python only | all Java |

**The main session integrates.** Call sites in `core/PacketLoop.java`,
`core/UdpSessionManager.java`, `core/TcpProxy.java`, `core/VpnEngine.java` and
the dev panel in `overlay/EspOverlay.java` are NOT yours. If you need a call
there, state exactly which file, which line, and which call, in your report.

## 6. What to report back

1. Files created/changed, with line counts.
2. For every §2 defect you addressed: which one, and how you verified it.
3. Numbers, not adjectives. Decode coverage as `n/total`. Hot-path allocations
   as a count.
4. Anything you found that contradicts this brief, with the evidence.
5. Anything you left undone, and why.
