# Why the ESP dies in Clash Squad but not in Battle Royale

> **PATHS IN THIS DOC PREDATE THE 2026-09-15 PACKAGE REORG.**
> `core/` is now `tunnel/`, `net/` split into `decode/{frame,crypt,body}` +
> `protocol/`, `overlay/` split into `ui/{render,overlay,panel,button,aim}`.
> See `docs/SOURCE_MAP.md` §2 for the full old-to-new table.

Diagnosis, 2026-09-15. Written against the shipped tree at `0873617`, replayed
over 36 sessions of recorded wire traffic in `captures/`.

---

## 0. Verdict, in one paragraph

**This is a regression introduced by `0873617`, not an older bug.** That commit
made `resetMatch()` wipe our own identity (`ownTeam = 0`, `ownEntityId = -1`)
and added a rung-0 freshness gate that refuses to classify anything until a
fresh keepalive has named us again. But the match-boundary detector one screen
above computes

```java
// EspEngine.java:889
long ownHandleNow = ((long) ownTeam << 24) | (ownEntityId & 0xFFFFFFL);
```

and `ownEntityId == -1` gives `-1 & 0xFFFFFF == 0x00FFFFFF` — **not zero**. So
the wiped state does not read as "identity unknown", it reads as *a different
match*. The next chain packet therefore fires `resetMatch()` again, which wipes
identity again, and the engine enters a self-sustaining reset loop that clears
`entities`, `pri` and `roster` about ten times a second and blanks
classification the whole time. The loop breaks only on a network tick that
delivers exactly **one** chain packet instead of two. **Clash Squad almost never
delivers one** — measured median 17.4 s between such ticks, versus **0.6 s in
Battle Royale.** That 29× difference is the whole mode asymmetry: the same bug
fires in both modes, self-heals in well under a second in BR, and in CS locks
the ESP off for tens of seconds at a time, sometimes for an entire match.

A one-line change to line 889 removes it. Measured effect below (§7.4): the
post-match-boundary blackout in Clash Squad falls from a p90 of **24.15 s** to
**0.20 s**, and the "never recovers inside the session" rate from **10 %** to
**0 %**, with no regression in BR and no change to the friend/foe rule.

---

## 1. The failure chain, step by step

Every step is a line of shipped code.

1. **The boundary detector encodes "no identity" as a valid-looking handle.**
   `EspEngine.java:889`. With `ownTeam == 0` and `ownEntityId == -1` the
   expression yields `0x00FFFFFF`. The `ownHandleNow != 0` guard at
   `EspEngine.java:890` was clearly written to suppress exactly this case; it
   does not fire, because the sentinel is not 0.

2. **`resetMatch()` wipes identity** — `EspEngine.java:1639-1642`:
   ```java
   ownTeam = 0;
   ownTeamSeenMs = 0L;
   ownEntityId = -1;
   lastMatchResetMs = now;
   ```
   This is new in `0873617`. Before it, `resetMatch()` cleared `entities`, `pri`
   and `roster` only, and identity survived.

3. **`matchHandle` is then latched to whichever of the two values was current.**
   `EspEngine.java:897` — `if (ownHandleNow != 0) matchHandle = ownHandleNow;`,
   and `0x00FFFFFF` passes that test too.

4. **The two values alternate forever.** The outbound keepalive (`OUT 2001`)
   restores the real handle; the next chain packet sees `real != 0x00FFFFFF` and
   resets, wiping it back. The chain packet after that — which in Clash Squad
   arrives in the *same millisecond*, with no keepalive in between — sees
   `0x00FFFFFF != real` and resets again. Two resets per 198 ms tick.

5. **Rung 0 blanks classification while this runs.** `EspEngine.java:1283-1291`:
   ```java
   if (!isValidTeam(ownTeam) || ownTeamSeenMs < lastMatchResetMs) {
       return;                       // returns WITHOUT writing t.role
   }
   ```
   Every reset sets `lastMatchResetMs = now`, which is strictly after the last
   keepalive, so the gate holds. Tracks keep the default `ROLE_UNKNOWN`.

6. **What the user loses.** In order of how loud it is:
   * **Aim / target lock is dead.** `EspRenderView.java:1634` —
     `if (role == ROLE_UNKNOWN && !AIM_TARGET_UNKNOWN) continue;`, and
     `AIM_TARGET_UNKNOWN` defaults to **false** (`EspRenderView.java:420`).
     Every entity is `ROLE_UNKNOWN`, so the picker has nothing to lock.
   * **All colour, HP and names are gone.** `resetMatch()` also calls
     `pri.reset()` and `roster.reset()` (`EspEngine.java:1645-1646`) ten times a
     second, so the Cmd 1900 owner→entity binding never survives long enough to
     produce a health bar or a name.
   * **Boxes stop following.** `entities.clear()` (`EspEngine.java:1632`) ten
     times a second destroys `velValid`, so the renderer's dead-reckoning
     (`EspRenderView.java:1138-1153`) never arms and every box sits one tick behind.
   * **A box appears on our own body.** Rung 1 (`ROLE_SELF`) is below rung 0,
     so the self-echo is never labelled; only the `MIN_DIST_M` belt-and-braces
     filter keeps it off screen.
   * **Total blackout if `SHOW_UNCLASSIFIED` is off.**
     `EspRenderView.java:1172`. That toggle defaults to *true*
     (`EspRenderView.java:529`), so with stock settings you still get grey boxes;
     with it off — a state this project has shipped in before, see the
     `LATE_ARRIVAL_MS` javadoc's "reported solo blackout" — the screen is empty.

---

## 2. The oscillation is deterministic, and it is measured

Replaying the shipped logic byte-for-byte over `captures/device_pull_20260910/
dev_logs/capture_raw_20260910_205046.txt` (Clash Squad, own handle
`0x02000002`, 109 s):

| | shipped (`0873617`) | pre-`0873617` |
|---|---|---|
| `resetMatch()` calls | **789** | **1** |
| classify() samples gated at rung 0 | 1 465 / 1 858 (**78.8 %**) | 0 |
| longest continuous blackout | **78.2 s** (0.0 s → 78.2 s of the capture) | none |
| structural chain parses | 633 / 1 066 (59.4 %) | 1 027 / 1 066 (96.3 %) |

The reset log alternates exactly as the mechanism predicts, two per tick at
identical timestamps:

```
reset @ +0.20s  handle FFFFFF->2000002
reset @ +0.20s  handle 2000002->FFFFFF
reset @ +0.40s  handle FFFFFF->2000002
reset @ +0.40s  handle 2000002->FFFFFF
...
```

Two more sessions from the same evening, same shape:

| capture | resets | gated | blackout |
|---|---|---|---|
| `capture_raw_20260910_204856.txt` | 350 | **100.0 %** | the entire 34.6 s capture |
| `capture_raw_20260910_192806.txt` | 377 | 22.8 % | first 37.4 s |
| `capture_raw_20260910_203903/4.txt` | 894 | 92.7 % | 126.3 s |

Corpus-wide, **every** reset in **every** capture that has a readable keepalive
stream has the same first cause, printed by the replay as
`handle FFFFFF->XXXXXXX` — i.e. the `0x00FFFFFF` sentinel. Ten of forty sessions
enter the loop spontaneously, simply because a chain packet happened to arrive
before the first keepalive and seeded `matchHandle` with the sentinel.

---

## 3. Why Clash Squad and not Battle Royale

### 3.1 The escape hatch is a tick that carries one chain packet

Write the packet stream as a string, `K` = accepted outbound keepalive,
`C` = accepted chain packet. The loop state is `(identity, matchHandle)`;
it settles permanently the moment two consecutive `C` events see the *same*
handle, which requires a `K` between them — that is, a run of `C` of length 1.

The interleaving is wildly different by mode. First 90 events of four sessions:

```
CS  205046   CCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKKKCCKCCKKCCKK...
CS  161940   KKCCKKCCKKCCKCCKKCCKKKCCKKCCKKCCKKCCKKCCKKCCKKCKCKCKCCKKKCCKKCCK...
CS  192806   CCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKKCCKK...
BR  222258   CKCKKCKCKCKKCKCKCKKCKCKCKKCKCKCKKCKCKCKKCKCKCKKCKCKKCKCKCKCKKCKC...
```

Clash Squad runs a rigid `CCKK` cadence — the 8-player roster is fully
replicated every tick, so the server always sends both a multi-record `Cmd 2012`
chain *and* the single-record `Cmd 2001` position stream, and `EspBodyDecoders`
sends both to `observeChainPacket` (`EspBodyDecoders.java:95`,
`UdpSessionManager.java:326`). Battle Royale is interest-managed — the exact
mechanism already documented in `docs/FRIEND_FOE_AUTHORITATIVE.md` §1.4 — so the
per-tick packet count fluctuates and lone chain packets are common.

Measured over 36 sessions (CS = sessions whose observed team bytes are a subset
of `{1, 2}`, per `docs/FRIEND_FOE_AUTHORITATIVE.md` §3.4; BR = everything else):

| mode | n | lone-`C` runs, median | median seconds between escape opportunities |
|---|---|---|---|
| **Clash Squad** | 23 | **1.4 %** | **17.4 s** |
| **Battle Royale** | 13 | **49.7 %** | **0.6 s** |

Four Clash Squad sessions (`193144`, `204443`, `204551`, and `203903/4` with one
lone run in 140 s) offer essentially **no** escape opportunity at all.

### 3.2 The blackout distribution that follows

Injecting one `resetMatch()` — what every genuine match boundary does — at 60
evenly spaced points in each session and measuring how long classification stays
gated:

| mode | n | median p50 | median p90 | median worst | never recovers |
|---|---|---|---|---|---|
| **Clash Squad** | 23 | 0.18 s | **24.15 s** | **42.77 s** | **10 %** of injections |
| **Battle Royale** | 13 | 0.19 s | **2.27 s** | **10.10 s** | 12 % |

The medians are identical and the tails are an order of magnitude apart. That is
precisely the reported symptom: *most* boundaries recover instantly (so it is not
"always broken"), but in Clash Squad a large minority cost 25-80 s — one or two
whole rounds — and one in ten never recovers at all. **"It randomly works when
playing."**

### 3.3 Why it re-fires round after round

Once the engine has been knocked into the wiped state at least once, every
resumption of the outbound keepalive re-flips `ownHandleNow` from `0x00FFFFFF`
back to the real handle and draws the lottery again. In Clash Squad the keepalive
goes silent several times per match — you are dead and spectating for the rest of
each round — while the chain stream keeps flowing:

| capture | keepalive silences > 2 s |
|---|---|
| `capture_raw_20260910_173746.txt` (CS) | 17.7 s, 16.6 s, 5.5 s, 5.5 s, 5.4 s |
| `capture_raw_20260910_164551.txt` (CS) | 24.8 s, 8.2 s, 5.6 s, 5.6 s |
| `capture_raw_20260910_155351.txt` (CS) | 86.7 s, 26.8 s, 8.3 s |
| `capture_raw_20260910_161940.txt` (CS) | 8.2 s, 8.2 s |

In Battle Royale you die once and the match is over, so there is one such event,
at the end. (Independently of this bug, each of those silences already exceeds
`EspRenderView.OWN_STALE_MS = 2000` at `EspRenderView.java:1006` and blanks the
overlay outright — see §6.)

### 3.4 And why the boundaries themselves are more frequent

`resetMatch()` has exactly one caller, `observeChainPacket`
(`EspEngine.java:894`), driven by two conditions:

* `newByHandle` — our own handle changed. Measured: **constant within a match**
  (one distinct value per capture in all 40 sessions), so this fires only across
  matches.
* `newBySilence` — the chain stream was quiet for more than
  `MATCH_GAP_MS = 30000` (`EspEngine.java:1443`). Measured chain silences of
  **45 s to 584 s** between matches in the `20260907`-`20260909` corpus, where a
  single capture spans several matches.

So there is one guaranteed reset per match boundary in a continuously running
app. A Clash Squad match is a few minutes; a Battle Royale match is ~20. Per hour
of play, Clash Squad draws the blackout lottery several times as often, and each
blackout eats a much larger fraction of the match.

---

## 4. "Broken by `0873617`", not "broken before it"

Stated plainly, as requested: **the fix introduced this.**

* `resetMatch()` and the handle/silence boundary detector both predate the
  commit — they arrived in `332bfdb` (2026-09-11). Under that code the same
  captures produce **exactly one** `resetMatch()` call and **zero** gated
  samples, because identity survived a reset and `ownHandleNow` therefore never
  changed value on its own.
* `0873617` added both halves of the failure in one patch: the identity wipe
  (`EspEngine.java:1639-1641`) turns a stable value into an alternating one, and
  rung 0 (`EspEngine.java:1284-1291`) converts each alternation into a
  classification blackout. Neither is harmful alone.
* The complementary half is also real and should not be reverted: before
  `0873617`, classification in Clash Squad *worked* because the deleted rung 5
  proximity promotion had been tuned on Clash Squad captures and was inverted in
  BR. The commit fixed BR and regressed CS. Both halves are needed; only the
  handle arithmetic is wrong.

---

## 5. Hypotheses tested and refuted

Each of these was measured, not reasoned about.

**"`resetMatch()` fires on every Clash Squad round."** *Refuted.* A CS round
boundary is invisible to `observeChainPacket`. Across all 40 sessions the largest
gap in the chain stream inside a single match is **823 ms** — nowhere near
`MATCH_GAP_MS`'s 30 s — and the own handle takes exactly one value per session.
`capture_raw_20260910_161940.txt` covers 570 s of Clash Squad, clearly spanning
several rounds (the roster refills from 1-4 back to 8-11 repeatedly), with **zero**
resets. The round-vs-match asymmetry is real, but it acts on the *recovery* side
(§3.1) and the *keepalive silence* side (§3.3), not on the trigger.

**"A roster-sized constant kills it, like `ff-no-roster-sized-constants`."**
*Refuted.* Every roster-sized bound in the ESP path has already been widened:
`MAX_ENTITY_ID = 64` (`EspEngine.java:791`), `ID_CEILINGS = {8,16,32,64}` chosen
adaptively per packet against the b9 record-count oracle
(`EspEngine.java:1089`, `EspEngine.java:940-975`), `oid <= 127`
(`EspEngine.java:688`), `id <= 127` in `noteTeam`/`observeDamage`, `MAX_DRAW = 64`
(`EspRenderView.java:597`). None excludes Clash Squad.

**"The `v[i] in 1..8` record splitter misfires when real entity ids are also
1..8."** *Refuted.* That is the *first* candidate of an adaptive sweep that is
accepted only if `countStarts(...) == declared`, and in Clash Squad `idMax = 8`
is the correct ceiling. Measured structural-parse rate on healthy CS sessions:
100.0 %, 98.5 %, 96.3 %, 95.0 %. It does collapse — to 50-59 % — but only *as a
consequence* of the reset loop (§2 and §5 below), not as a cause.

**"The CS team byte is out of `isValidTeam`'s range, or absent from the
handle."** *Refuted.* Clash Squad sides are team bytes 1 and 2, both inside
`isValidTeam`'s `1..254` (`EspEngine.java:456`), and both appear in the keepalive
handle: own handles `0x01000001` and `0x02000002` observed. In a CS session with
no reset the classifier is provably correct — role split over
`capture_raw_20260910_161940.txt` is SELF 15.9 %, TEAM 41.3 %, ENEMY 42.8 %,
UNKNOWN 0.0 %, against the arithmetic truth for 4v4 of 12.5 % / 37.5 % / 50 %.

**"`ownEntityId` extraction fails in CS."** *Refuted.* CS own ids observed are 1
and 2, inside the `oid >= 1 && oid <= 127` guard.

**"Match/round id churn in the phase machine."** *Untestable with what is here* —
see §6.

---

## 6. What this evidence cannot settle

* **`EV PHASE` / `EV MATCH_ASSIGNED` lines do not exist in any capture in the
  repo.** `grep -c "EV PHASE"` returns 0 across all 1 359 `capture_raw_*.txt`
  files, so the phase machine's own view of a round boundary could not be
  cross-checked. `SessionTimeline.java` contains no reference to `resetMatch`, so
  it cannot be a second trigger today — but a capture recorded on the current
  build during a **multi-round Clash Squad match** would settle whether the phase
  machine now emits a per-round `MATCH_ASSIGNED` that some future caller could
  wire to `resetMatch()`.
* **There is no post-`0873617` capture of any mode.** The newest usable session is
  `phone_aim6/capture_raw_20260912_162908.txt`; `pull_20260913/capture_raw_
  20260913_142129.txt` has `out=1 in=10886 foreign=10886` — the "wrong app in the
  tunnel" signature from `docs/WHEN_NOTHING_WORKS.md` §1 — and is unusable. The
  replay is nonetheless valid, because the logic under test reads only packet
  order, timing and handle values, none of which the app influences.
* **Mode labelling is a proxy.** Sessions are called Clash Squad when every
  observed team byte is in `{1, 2}`. That matches `docs/FRIEND_FOE_AUTHORITATIVE.md`
  §3.4 and agrees with the `observeChainPacket` javadoc's own labels on five of
  six named captures, but it disagrees on `20260910_183716`, which that javadoc
  calls "CLASH 183716" while its wire traffic shows seven distinct team bytes and
  own team 8 — i.e. a squad lobby. Treat that javadoc label as wrong.
* **`SHOW_UNCLASSIFIED`'s live value is unknown.** Whether the CS symptom is
  "grey boxes with no HP, names or tracking" or "an empty screen" depends on a
  per-device preference this analysis cannot read. The aim-lock failure
  (§1.6) is unconditional either way.

---

## 7. Fix specification

### 7.1 Required — one line, `EspEngine.java:889`

```java
// An unknown identity is NOT a different match. ownEntityId's -1 sentinel
// masks to 0x00FFFFFF, which is non-zero, so the `ownHandleNow != 0` guard
// below never fired and a wiped identity read as a handle CHANGE -- which
// re-entered resetMatch(), which wiped it again. Encode "unknown" as the 0
// that guard is already written for.
long ownHandleNow = (isValidTeam(ownTeam) && ownEntityId > 0)
        ? (((long) ownTeam << 24) | (ownEntityId & 0xFFFFFFL))
        : 0L;
```

Why it is safe in both modes:

* While identity is unknown, `newByHandle` is false and `matchHandle` is not
  overwritten (`EspEngine.java:897` already guards on `ownHandleNow != 0`), so
  the engine simply holds its opinion instead of manufacturing a boundary.
* When the keepalive restores the **same** identity, `ownHandleNow == matchHandle`
  and nothing happens — the loop cannot start.
* When a genuine new match assigns a **different** handle, `newByHandle` fires
  exactly once, which is the behaviour `332bfdb` intended and the 62-match-pair
  measurement in the `resetMatch` javadoc validated.
* At app start `matchHandle` now stays 0 until the first keepalive, instead of
  being seeded with the sentinel — which removes the spontaneous storm seen in
  10 of 40 sessions.

### 7.2 Required companion — clear `matchHandle` in `resetMatch()`

Add to `EspEngine.java:1639-1642`:

```java
matchHandle = 0L;   // the next real handle seeds it; without this a genuine
                    // new match costs a SECOND reset one packet later
```

### 7.3 Recommended — rung 0 should suppress blue, not everything

`EspEngine.java:1283-1291`. Rung 0 currently returns without writing `t.role`,
so a missing own-team byte silently disables the entire ESP. Rungs 3, 4 and 6
conclude **ENEMY only**; they neither read nor need `ownTeam`. Narrow the gate to
the single rung that can say TEAM:

```java
// RUNG 0 -- FRESHNESS, NARROWED. Only rung 2 can produce TEAM and only rung 2
// needs a fresh own team. The ENEMY-only rungs below do not, and blanking them
// turns a missing team byte into a total blackout -- the CS failure mode.
if (ownEntityId <= 0) return;          // cannot even exclude our own echo
final boolean ownTeamFresh =
        isValidTeam(ownTeam) && ownTeamSeenMs >= lastMatchResetMs;
```

then guard **only** the rung-2 block with `ownTeamFresh`, and leave rungs 1, 3,
4 and 6 as they are. `ownSquadKnown()` (`EspEngine.java:1688`) is already inert
when `ownTeam == 0` because it requires `t.team > 0 && t.team == ownTeam`.

**This does not weaken the friend/foe rule.** The only path to `ROLE_TEAM`
remains `t.team == ownTeam` against a server-published byte, at
`EspEngine.java:1322/1327` and `EspEngine.java:1608`. Nothing geometric is
reintroduced. The worst case after a real match boundary is a teammate drawn red
for the fraction of a second until the keepalive lands — the safe direction, and
the same direction rung 6 already defaults to.

### 7.4 Verified effect

Replaying the injection lottery of §3.2 with §7.1 applied:

| mode | metric | shipped | fixed |
|---|---|---|---|
| Clash Squad (n=23) | median p90 blackout | 24.15 s | **0.20 s** |
| | median worst blackout | 42.77 s | **0.21 s** |
| | never recovers | 10 % | **0 %** |
| | resets per boundary | 124.5 | **0** |
| | mean samples gated | 22.15 % | **1.47 %** |
| Battle Royale (n=13) | median p90 blackout | 2.27 s | **0.23 s** |
| | never recovers | 12 % | **4 %** |
| | resets per boundary | 121.7 | **0** |
| | mean samples gated | 17.44 % | **5.26 %** |

The residual BR figures are genuine keepalive silences (vehicles, death) where we
really do not know our own team, and are correctly gated. No session gets worse.

Secondary, free: with `ownEntityId` no longer stuck at -1, `parseStructured`'s
self-echo branch (`EspEngine.java:1042`) works again and the structural chain
parse recovers from 59.4 % → 96.3 % (`205046`), 50.0 % → 99.7 % (`204856`),
85.9 % → 97.2 % (`192806`).

### 7.5 Recommended — make this class of failure loud

`teamLine()` (`EspEngine.java:1665`) already prints `reset=+Ns`. Add the reset
*count*:

```java
"... unk=%d reset=+%ds x%d", ..., age, matchResets
```

A reset counter climbing at 10/s on the HUD would have made this visible in
seconds rather than requiring a replay — the standing lesson of
`ff-silent-failure-is-the-pattern`.

---

## 8. Method and reproduction

No Java was modified. The measurements come from a Python replay of the shipped
logic over `capture_raw_*.txt`, driven at the same call sites the app uses
(`UdpSessionManager.java:326/333/338` inbound, `PacketLoop.java:126` outbound).

The core of it is the exact reset/gate state machine, small enough to restate:

```python
# K = accepted OUT 2001 keepalive, C = accepted chain packet
# I = identity known, M = matchHandle, R = lastMatchResetMs, K_t = ownTeamSeenMs
for ts, kind in events:
    if kind == 'K':
        I = True; K_t = ts; continue
    H = own_handle if I else 0x00FFFFFF          # <-- the bug
    if M != 0 and H != 0 and H != M:
        I = False; R = ts; resets += 1           # resetMatch()
    if H != 0: M = H
    gated = (K_t < R)                            # classify() rung 0
```

Validated against a full byte-level replay (varint decode, `parseStructured`,
the adaptive splitter, `observeKeepalive`, `observeHandleEvent`,
`observeDamage`, `noteTeam`) on `205046`: identical reset count and identical
gated fraction. `Cmd 118` (BIND) and `Cmd 101` (ROSTER) were not modelled — they
need header parse plus body decrypt — but they can only *add* team knowledge, so
their absence cannot create a blackout; the rung-0 gate sits above them.

Scripts live in the session scratchpad (`espsim.py`, `roles.py`, `lottery.py`,
`escape.py`, `verifyfix.py`) and are ephemeral; the state machine above is the
part worth keeping.

### Capture inventory used

* Clash Squad (23): `20260910_` `131508 150701 155351 161940 164551 173746
  175208 175549 183252 192806 193144 193808 194728 200049 203903 203904 204443
  204551 204715 204821 205046 214139 222646`, all under
  `captures/device_pull_20260910/dev_logs/`.
* Battle Royale (13): `20260910_182553 183716 221243 222258 225854`,
  `20260911_103217 104112`, `20260912_143420 150936 154937 155922 161312 162908`.
* Rejected: everything before `20260910` (no session key, `ka=0`), and
  `pull_20260913/capture_raw_20260913_142129.txt` (wrong app in the tunnel).
