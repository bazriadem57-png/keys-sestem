# ESP health and names — the wire sources, and the id joins

> **PATHS IN THIS DOC PREDATE THE 2026-09-15 PACKAGE REORG.**
> `core/` is now `tunnel/`, `net/` split into `decode/{frame,crypt,body}` +
> `protocol/`, `overlay/` split into `ui/{render,overlay,panel,button,aim}`.
> See `docs/SOURCE_MAP.md` §2 for the full old-to-new table.

Everything here is measured against `capture_raw_20260913_143415.txt` (a real
16.8-minute BR match, 88 903 records, mask recovered) and cross-checked against
`libil2cpp_dec.so`. Implemented in `net/PriSync.java`, `net/WireReader.java`,
`esp/PriTracker.java`, `esp/MatchRoster.java`.

## 0. What was actually wrong

The ESP **invented** health. `EspEngine.Track.hp` started at `MAX_HP` (200) and
was only ever decremented by damage *we* dealt, snapping back to 200 on death.
The code admitted it: *"HP is a lower bound"*. So an enemy we had never shot read
200 forever; damage from other players, healing, revives and armour were all
invisible. The reported symptom — "it shows 120, then 72, then a random value" —
was our own past hits subtracted from a fiction.

Names were never missing from the wire either. Nothing was reading them.

The common cause: **every one of these channels is reliable, therefore
TEA-encrypted**, and the live ESP only ever read plaintext channels. The capture
annotator had the decrypt path; the ESP did not. `net/BodyCrypt.java` now shares
it.

## 1. Health — Cmd 1900 `RUDP_VAR_SYNC_PRI_DATA`

14 197 packets in this match. Grammar in `net/PriSync.java`; the two traps are
that `blockLen` is **two raw LE bytes** and `varId` is **one raw byte** —
neither is a varint.

`EPRI_PLAYER_CUR_HP` is property **0**. From the binary: **UInt16, plain
(non-zigzag) varint, 1:1 scale** — 200 HP is 200 on the wire. Confirmed by the
value distribution in this capture, a clean 0-200 continuum:

```
200 199 198 197 196 195 194 193 192 191 189 188 185 184 182 180 176 174 173 171 139 ...
```

`EPRI_PLAYER_MAX_HP` (property 1) **is** trustworthy — but only on a confirmed
player. Ungated it looks like garbage (0/1/2, 6000, 201326641) and was briefly
written off as unreliable; restricted to the Cmd-118 type-1 player set it reads
**200 in 27/27**. Every junk value belongs to a non-player owner, where varId 1
is a different property entirely (201326610 is the entity handle 0x0C000012).

### The per-entity-type hazard

The EPRI key namespace is **per entity type**, selected by the entity's
`ReplicationEntityTag`. Sibling enums exist for vehicles, plants, the escort boss
and match globals. **varId 0 is CUR_HP only for a player** — on a crate it is
something else. This capture carries 181 non-player binds against 28 player ones,
so reading slot 0 off whatever arrives would be reading doors. `PriTracker`
refuses health from any owner Cmd 118 has declared a non-player.

## 2. The owner → entity join

Cmd 1900 keys on `ownerReplicationId`
(`GCommon.PRIDataPool::m_ReplicationID`), an arbitrary server-assigned int with
no relation to the ESP handle. **328 distinct owners, 270 with health**, against
a few dozen players — binding the wrong one puts a vehicle's health on a
player's box. Three sources, in priority order:

### a. Cmd 118 `RUDP_BIND_PRI` — authoritative, use this

Record is `(U owner, B type, U packedEntity)`. `type == 1` discriminates players
perfectly. Measured:

| | |
|---|---|
| type-1 records | 28 |
| distinct owners → distinct slots | **26 → 26, 1:1, zero collisions** |
| slot range | 15-53 (exactly the chain id range) |
| squad byte | 2-15 (0 for every non-player) |
| of those owners, reporting HP | 21/26 |

`packedEntity = (squad << 24) | slot`; the low 24 bits are the chain entity id.

### b. Equipment correlation — fallback

`EPRI_ITEM_ON_HAND` (property 4) is `(inventoryItemId << 32) | weaponId`. Its
**high half** equals Cmd 121 `RUDP_EQUIPMENT_CHANGED` field **v3**. Swept over
the real match:

| window | unique-match test | bound | collisions | unanimous |
|---|---|---|---|---|
| 150 ms | single field | 19 | 0 | 19/19 |
| 350 ms | single field | 15 | 0 | 15/15 |
| 350 ms | none | 47 | 1 | 6/47 |
| **350 ms** | **both halves of `onHand`** | **51** | **0** | 28/28 vs Cmd 118 |

The decisive refinement: match **both** halves of `EPRI_ITEM_ON_HAND` — the
inventory instance id *and* the weapon id — against the Cmd 121 varint set.
Strictness buys the window: one field needs ±150 ms to stay unambiguous and
binds 19, while both halves at ±350 ms bind 51 with zero ambiguity and perfect
agreement with the authoritative answer. Shipped: ±350 ms, both halves.

Resulting coverage: 43 of 51 bound players report HP, and **99.4% of entity
position samples (22 574 / 22 711) belong to an id we have health for**. If the
ESP can draw the box, it almost certainly has the number.

### c. Damage correlation — weakest

An HP drop of Δ on owner *O* matches a Cmd 2010 with the same Δ within ±250 ms.
Measured here: **9 bound, 0 collisions, 7/9 unanimous**, but only **8.5%** of
HP drops correlate — we only receive damage events for fights involving us
(22 distinct victims against 270 owners with health).

### Health is latched, not polled

Only **0.37%** of updates repeat the previous value — the stream is
change-driven — and the p99 gap between updates is **42.7 seconds**. So there is
no staleness rule: silence means "unchanged", not "lost". An earlier 15 s
cut-off sat below the normal quiet period and would have blanked the bar on
exactly the players who are at full health.

Integrating the damage feed instead could never work. On a knockdown the pool
resets to 200 and then bleeds `-3` every ~100 ms with **zero Cmd 2010 events**
for the entire bleed-out; revives, med kits and gloo-wall regen are equally
invisible to the damage feed. Only varId 0 sees them.

## 3. Names

No name exists anywhere in the 256 `EPRI_*` properties (all uint), so Cmd 1900
can never carry one. The roster does:

| cmd | name | nickname at | keyed to |
|---|---|---|---|
| **101** | `RUDP_PLAYER_JOIN` | field 3 | field 2 = entityId |
| 107 | `RUDP_DEAD` | field 2 | field 1 = **killer** |
| 139 | `RUDP_KNOCK_DOWN` | field 2 | field 1 = **killer** |
| 102 | `RUDP_PLAYER_QUIT` | — | field 0 = entityId |

Counts this match: 101 × 28, 107 × 114, 139 × 23, 102 × 1.
Cmd 195 `RUDP_TEAM_INFO` also carries names but **never appeared**.

Strings are **zigzag varint byte-length, then raw UTF-8**
(`FastBinaryReader::ReadString` @ 0x082901E8).

The id join is the same mask as Cmd 118: `entityId = (squad << 24) | slot`, low
24 bits are the chain id — verified 53/53 distinct with zero collisions, and the
high byte gives squad for free. Slots are unique only **within** a match, so the
roster is cleared on a match boundary.

107/139 name only the **killer**, never the victim (97/97 in the corpus).

## 4. Known coverage gap — the pre-key window

At match handover **224 inbound packets in one second decode as `cmd = -1`**,
49 of them PLAYER_JOIN-sized, because the header layout is not solved yet. So
roughly the first half of the roster burst is discarded: 101 named 25 of 53
players, with 107/139 recovering 17 more — **42/53 (79%)**.

The bodies are fine. One of the dropped packets decrypts perfectly and yields a
valid name; only the *cmd id* and *length16* were garbage. Solving the layout
faster at handover — or replaying the unresolved bodies once the key lands —
would take roster coverage near 100% and lift HP binding with it. **This is the
highest-value remaining fix.**

## 5. The "compressed" half was a header bug, not compression

**Nothing on the match wire is compressed.** The ZIPPED bit is set on **0 of
88 413** packets, and Flags only ever holds 0 or 1.

`SessionKeySolver` was electing the wrong `HEAD_SECRET` permutation, so it read
Flags from what is really `orderId >> 8` — a near-random byte. ~49% of packets
therefore appeared zipped and were discarded unread: **14 911 packets across
~40 commands** in this capture, including 6 941 of the 14 197 Cmd 1900 health
updates, plus 956 Cmd 121, 888 Cmd 170, 647 Cmd 204 and 115 Cmd 106.

The old tie-breaks could not catch it. The Length identity cannot separate the
two 1-byte or two 2-byte slots; SendOption sits at the same offset in both
candidates; and the `flags & ~0x03 == 0` test *passes* for the wrong candidate
because OrderID's high byte is 0 for the first ~1 060 reliable packets — long
past the 256-packet commit window. The wrong permutation scored a perfect
256/256 and won on every fresh match.

**Fix (shipped): OrderID monotonicity**, `(next − prev) & 0xFFFF == 1`, scored
above the older tests. Measured over 255 reliable packets:

| candidate | steps of exactly 1 |
|---|---|
| correct `(0,1,4,3,2)` | **229 / 255** |
| wrong `(0,1,2,4,3)` | **0 / 255** |

With the header read correctly, all 14 911 previously-discarded packets
TEA-decrypt cleanly and the 14 441 Cmd 1900/1901 bodies parse with exact
consumption and zero residue (100%). Semantic proof from recovered packets
alone, owner 404: `200 → 189 → 177 → 165 → 152 → 138 → 124 → 109` (a burst),
then `110, 111, 112 … 139` one per tick — damage, then heal regen.

`docs/VALIDATION_AND_INBOUND.md` §4 and §7.1 already said both of these things.
The solver never adopted them.
