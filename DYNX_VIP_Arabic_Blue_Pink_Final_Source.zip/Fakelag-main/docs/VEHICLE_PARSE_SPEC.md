# VEHICLE_PARSE_SPEC — parsing outbound Cmd 2002 / 2069 into ESP own-state

> **UPDATE 2026-09-15:** field 8 is confirmed **ONE RAW BYTE** on live wire
> (102/137 outbound and 115/592 inbound packets carry a value >= 0x80, on
> which a varint walk desyncs). `VEHICLE_DISPATCH_MAP.md` Sec 3.5 and Sec 9.6
> are wrong on this point. The 'no on-wire sample exists' caveat below is
> also now obsolete: see `MOUNTED_CAPTURE_ANALYSIS.md`.


**Status: implementable spec, NOT wire-verified.** Every wire fact below is restated
from two binary-derived investigations. **No genuine on-wire sample of outbound
2002 or 2069 exists in the repo's 330 capture directories** — every one of the
1 083 Cmd 2002 records found is *inbound*, which is a different class entirely
(`CHOIJILECHG`, the batched vehicle list). §10 says exactly which claims a single
capture would settle and how to take it.

**Inputs (read these; this spec does not re-derive them):**
- `docs/CMD_2002_VEHICLE_LAYOUT.md` — the 2002 body, address by address
- `docs/VEHICLE_DISPATCH_MAP.md` — the dispatch tree, the siblings, where a horse lands
- `docs/GAME_CLIENT_CONSTANTS.md` §"The third-person rig" — the per-state camera rig

**Scope.** Parse two outbound messages the game already sends, and feed the result
into `EspEngine` own-state. Nothing else.

---

## 0. The problem, in three sentences

`COW.GamePlay.PNCPKGJGBPP::EAIKJCCNGMJ` tests `Player::IsInVehicle()` at
`0x078cdf18` **before** it can reach the Cmd 2001 branch (`tbz w0,#0,#0x78cdfd4`),
so mounting anything stops 2001 dead. The ESP derives both own position and the
camera basis exclusively from outbound 2001, so both freeze at their last on-foot
values. The dispatcher does not go silent — it emits **2069** (vehicle grants
driver weapon fire → **this is where a horse lands**), **2002** (ordinary driver),
**2006** (passenger), **2015** (catapult), **2031** (cannon) or **2016** (chair)
instead, all unreliable ⇒ plaintext ⇒ readable without the session key.

This spec parses **2002 and 2069 only**. They are the two that carry our position.

---

## 1. Exact wire layouts

### 1.1 The reader contract — why a naive varint walk desyncs

`GCommon.FastBinaryReader` is **not uniform**. The repo already states the rule in
`net/WireReader.java:9-17`; restating it because field 8 below is the trap:

| declared type | on the wire |
|---|---|
| `U` unsigned / `Z` zigzag / `float` | **one LEB128 varint** (type changes interpretation, never length) |
| `B` byte | **one RAW byte** — not a varint |
| `S` string | zigzag varint byte-length, then that many raw UTF-8 bytes |
| `FixUInt16` | **two raw little-endian bytes** |

Zigzag decode is `(v >>> 1) ^ -(v & 1L)` — `EspEngine.zz`, `EspEngine.java:599`.

### 1.2 Cmd 2002 — `UDP_VEHICLE_STATE_SYNC`, class `message.JBECKHDPPOO`

Outer `JBECKHDPPOO::Serialize` @ `0x049d724c` writes the inner object then the
tick then flushes. The inner `OLEOJNOGCCN::Serialize` @ `0x047cec24` is
serialised **inline** — no length prefix, no tag bytes, a flat continuation of the
same stream. Body is everything after the packet header (8 bytes non-reliable).

| # | field | read as | transform | unit / meaning |
|---|---|---|---|---|
| 0 | `FAAMLGOPLAC` | **varint U** | — | vehicle `LevelVehicle` object id. **Not** a PlayerID, **not** an ESP entity id |
| 1 | `MOEFFAIDCBP.x` | **varint Z** | — | vehicle world **X**, millimetres |
| 2 | `MOEFFAIDCBP.y` | **varint Z** | — | vehicle world **UP**, millimetres |
| 3 | `MOEFFAIDCBP.z` | **varint Z** | — | vehicle world **Z**, millimetres |
| 4 | `LFCNHAJBHEE.x` | **varint Z** | `/1000.0` | quaternion **qx** |
| 5 | `LFCNHAJBHEE.y` | **varint Z** | `/1000.0` | quaternion **qy** |
| 6 | `LFCNHAJBHEE.z` | **varint Z** | `/1000.0` | quaternion **qz** |
| 7 | `LFCNHAJBHEE.w` | **varint Z** | `/1000.0` | quaternion **qw** |
| 8 | `JBOGMCKPKLJ` | **ONE RAW BYTE** | — | `Vehicle::GetCurrentPackedOp()`, an undecoded input bitfield |
| 9 | `AAPGPMPKMBD.x` | **varint Z** | `/100.0` | vehicle velocity **X**, m/s |
| 10 | `AAPGPMPKMBD.y` | **varint Z** | `/100.0` | vehicle velocity **UP**, m/s |
| 11 | `AAPGPMPKMBD.z` | **varint Z** | `/100.0` | vehicle velocity **Z**, m/s |
| 12 | `DNNFOOGPFHO` | **varint U** | — | `GameFacade::CurrentServerTick()` — a **server tick**, NOT a millisecond clock |

13 fields. Typical encoded body **~22–34 bytes**.

**Field 8 is the desync.** `Write(byte)` @ `0x08291c9c` tail-calls `WriteFixU8`
@ `0x08291ff4`, which does `DemandSpace(1)` then a single `strb` — exactly one raw
byte. A varint walk over it reads the same value while `op < 0x80` and then
silently eats the next byte the moment `op >= 0x80`, shifting fields 9–12 by one
byte. §6.2 specifies the defence.

There is **no checksum, no nonce, no client ms clock, no platform id, no
PlayerID and no player aim vector** anywhere in 2002. The outer `Serialize`
writes exactly two things and flushes.

### 1.3 Cmd 2069 — `UDP_VEHICLEWEAPONFIRE_STATE_SYNC`, class `message.OGHGHMCCKFK`

`OGHGHMCCKFK::Serialize` @ `0x049d74e4`. **2069 is a strict superset of 2002**:
fields 0–12 are byte-for-byte identical (the same nested `OLEOJNOGCCN` class, the
same `Serialize` body, then the same `CurrentServerTick`), followed by four more:

| # | field | read as | transform | unit / meaning |
|---|---|---|---|---|
| 0–12 | — | — | — | **exactly as 2002 above** |
| 13 | `DIPPKFBIILG.x` | **varint Z** | `/100.0` | **aim forward X** |
| 14 | `DIPPKFBIILG.y` | **varint Z** | `/100.0` | **aim forward UP** |
| 15 | `DIPPKFBIILG.z` | **varint Z** | `/100.0` | **aim forward Z** |
| 16 | `HMKGHANBCNJ` | **varint U** | — | `BJNKBGDPBAC()` **client millisecond clock** — the same quantity as 2001's `v22` |

17 fields. Typical encoded body **~36–46 bytes**.

"Aim forward" is `Quaternion::op_Multiply(Player::GetAimRotation(p), Vector3.forward)`
(`GetAimRotation` @ `0x070718a8`, built at `0x078ce14c`..`0x078ce1b4`) — i.e. **the
same physical quantity as 2001's `v13/v14/v15`**, only quantised to `int16 ÷ 100`
instead of raw float32.

**2069 is the horse.** `MountableAnimal` is the only class in the image that
overrides `Vehicle::CanDriverFire()` (slot 153, `0x0758f4c4`) to anything but
`return false`. See §10.1 for why that routing is still unverified.

### 1.4 Precision of the 2069 aim vector

Each component is `round(f * 100)` on an `int16`, so the absolute error per
component is ≤ 0.005 on a unit vector. Worst-case angular error ≈
`atan(0.005 / 1) ≈ 0.29°`.

| source | yaw resolution | cadence | staleness |
|---|---|---|---|
| Cmd 2001 `v13/14/15` | float32, exact | 99 ms | first-hand, 0 ms |
| **Cmd 2069 aim** | **≈ 0.29°** | **99 ms** | **first-hand, 0 ms** |
| inbound self-echo pose | 1.41° / LSB yaw, 1.29° pitch | 198 ms | ~230 ms |

2069 is roughly **5× better in angle and 2× better in cadence** than the self-echo
stopgap, with no round-trip staleness at all.

### 1.5 Axis convention — identical to Cmd 2001

Argument order is preserved verbatim through the quantisers
(`KANJBNIANHC::COGCJKJPPHI` @ `0x0577e298` for positions ×1000,
`JNMALNNFDLI` @ `0x0577de98` for vectors ×100,
`HDMMEFFMIJP` @ `0x0577e5e0` for the quaternion ×1000). `UnityEngine.Vector3`
is `(x, y, z)` in register order `s0..s2` and `Quaternion` is `(x, y, z, w)` in
`s0..s3`, so the wire order is **X, UP, Z** for every vector and **qx, qy, qz, qw**
for the quaternion — the same convention `EspEngine` already applies to 2001.

Mapping onto `EspEngine`'s field names (note the names are historical and
`posZ` is the **vertical** axis — `EspEngine.java:46`, and the renderer's
conversion at `EspRenderView.java:1014-1016` confirms it):

```
posX = (double) wire[1]      // world X
posZ = (double) wire[2]      // world UP / height   <-- vertical, despite the name
posY = (double) wire[3]      // world Z
```

**Scale: none.** Wire millimetres are already the engine's own units —
`EspEngine.UNITS_PER_METRE = 1000.0` (`EspEngine.java:485`), and 2001's
`v0/v1/v2` are the same ×1000 quantiser. Assign directly. Do **not** divide.

### 1.6 Vehicle basis from the 2002 quaternion

Unity is left-handed, Y-up, forward = `+Z`. For the unit quaternion
`(x, y, z, w)` reconstructed as `wire[i] / 1000.0`:

```
forward.x = 2*(x*z + w*y)
forward.y = 2*(y*z - w*x)
forward.z = 1 - 2*(x*x + y*y)
```

This is the **vehicle body's** forward — the horse's body yaw or the car's
heading. It is **not** the camera. See §5.2 for why it must not be used as one
by default.

---

## 2. Where the parser hooks in

### 2.1 The existing Cmd 2001 entry point

| what | file:line |
|---|---|
| outbound shape gate that feeds own-state | `fakelag/fakelag-beta/app/src/main/java/com/fakelag/cryhard8/core/PacketLoop.java:99-127` |
| the parse itself | `.../esp/EspEngine.java:669` (`observeKeepalive`) |
| the write of own position | `.../esp/EspEngine.java:700-702` |
| the write of the camera basis | `.../esp/EspEngine.java:709-713` |
| the freshness / history / echo-flag tail | `.../esp/EspEngine.java:732-736` |

2001 is fed by a **byte-shape gate** (`plen 32..96`, `b9 == 0x80`, `b10 == 0x80`,
`b8 & 0x80 != 0`) at `PacketLoop.java:101-104`, which runs **before** the exact
header parse. That gate works for 2001 because its shape is known from thousands
of measured packets. **No such shape is known for 2002/2069** — there is not one
sample — so the new carriers must be **command-gated**, not shape-gated.

### 2.2 The analogous entry point for 2002 / 2069

**Hook: `core/PacketLoop.java`, immediately after line 164** — inside the
`if (parsed.isCrcValid())` block that already assigns `cmd`, and **before**
`pipeline.dispatch(parsed, Direction.OUTBOUND)` at line 165.

```java
// PacketLoop.java, inside `if (parsed.isCrcValid()) { cmd = parsed.cmd(); ... }`
if (parsed.isPlaintext()) {
    switch (cmd) {
        case 2002:
        case 2069:
            engine.esp().observeVehicleState(cmd, parsed.buffer(),
                    parsed.payloadOffset(), parsed.payloadLength());
            break;
        default: break;
    }
}
```

This is the **exact outbound analogue of the inbound command switch** already in
`core/UdpSessionManager.java:259-270`, which feeds `observePriSync` / `observeEquipment`
/ `observeBindPri` / the roster by command id. Same pattern, same place in the
flow, opposite direction.

**Why here and not the `BodyDecoderRegistry`.** `PacketPipeline.dispatch` is live
(`PacketLoop.java:165`) and the registry is empty, so a `registerCode(2002, …)`
would also work. It is rejected because `EspBodyDecoders.register` (the only
existing registrar) also calls `setFallback(shapes)`, and `VpnEngine.java:94-102`
documents precisely why that must not be switched on piecemeal: it would hand
`EspEngine` every position twice, at a zero time delta, straight into dead
reckoning. An inline switch in `PacketLoop` touches one file and cannot
accidentally arm the fallback.

**Why the offsets are right.** `UdpPacket.payloadOffset()` / `payloadLength()`
give the body exactly, for both the 8-byte non-reliable and the 10-byte reliable
header form. The new parser takes a true body pointer — do **not** reuse the
`bodyOff - BODY_PREFIX` legacy-offset hack from `esp/EspBodyDecoders.java:45`;
that exists only so parsers written against an assumed 8-byte header keep working.

**Preconditions the hook must carry:**

| check | why |
|---|---|
| `parsed.isCrcValid()` | already enforced by the enclosing block. Foreign UDP lands in the MsgKey range ~8% of the time; without it `cmd` can be read out of somebody else's packet (`PacketLoop.java:149-161`) |
| `parsed.isPlaintext()` | 2002/2069 are proven `sendOption = 0` ⇒ never reliable ⇒ never TEA-wrapped. A packet claiming 2002 that is flagged encrypted or zipped is a mis-solved header, not our message |
| `Direction.OUTBOUND` | implicit — `PacketLoop` is the tun read loop, outbound only. **Inbound 2002 is a different class** (`CHOIJILECHG`, the batched list of *every visible vehicle*) and must never reach this parser |

### 2.3 Threading

`PacketLoop.loop` runs on exactly one thread (`VpnEngine.java:532`, the single tun
reader). `observeVehicleState` is therefore **single-threaded** and may use one
reusable per-`EspEngine` scratch holder with no locking and no per-packet
allocation. The inbound self-echo path (`refreshOwnFromEcho`) runs on a
`UdpSessionManager` receive thread, so the own-state fields are written from two
threads — exactly as they are today (`observeKeepalive` vs `refreshOwnFromEcho`),
with the same `volatile`-per-field model. **Do not add a lock on the packet path.**

### 2.4 No double-feed with the 2001 shape gate

Confirmed two ways, both of which must hold:

1. The gate needs `b8 & 0x80 != 0`, i.e. the first body byte is a multi-byte
   varint's continuation. Field 0 of 2002 is a `LevelVehicle` object id; the only
   observed value in the corpus is 37 (`0x25`), a single byte. The gate misses.
2. Even if it hit, `observeKeepalive` requires **exactly 23 varints**
   (`EspEngine.java:675-679`). A 2002 body decodes to ~13 fields and a 2069 body
   to ~17, both of which the exact-count check rejects, incrementing
   `keepaliveParseBad` and returning.

State this in the implementation's comment so nobody "simplifies" the count check
later.

---

## 3. How the parsed result feeds own state

### 3.1 New source identity

```java
public static final int OWN_SRC_NONE = 0;
public static final int OWN_SRC_2001 = 1;   // on foot, first-hand, float32 dir
public static final int OWN_SRC_2069 = 2;   // mounted, first-hand pos + real aim
public static final int OWN_SRC_2002 = 3;   // mounted, first-hand pos, NO aim
public static final int OWN_SRC_ECHO = 4;   // inbound self-echo, derived
```

New fields on `EspEngine`, all `volatile`:

```java
private volatile int  ownPosSrc = OWN_SRC_NONE;
private volatile int  ownDirSrc = OWN_SRC_NONE;
private volatile long ownStateMs   = 0L;   // last own POSITION write, ANY source
private volatile long ownMs2001    = 0L;   // mirror of ownLastUpdateMs, for the guard
private volatile long ownMs2069    = 0L;
private volatile long ownMs2002    = 0L;
private volatile long ownMsEcho    = 0L;
private volatile long ownVehicleId = 0L;   // 0 = on foot / unknown
private volatile long ownServerTick = 0L;  // 2002/2069 field 12; NOT a ms clock
private volatile float vehFwdX, vehFwdY, vehFwdZ;  // §1.6, vehicle body forward
private volatile boolean vehFwdValid = false;
```

### 3.2 Write matrix — what each carrier touches

| `EspEngine` field | 2001 (today) | **2069** | **2002** | echo (today) |
|---|---|---|---|---|
| `posX` / `posZ` / `posY` | write | **write** | **write** | write |
| `dirX` / `dirY` / `dirZ` | write | **write** | **NEVER** | write |
| `dirSampleMs` | write | **write** | **NEVER** | write |
| `computeCameraAngVel(...)` | call | **call** (§3.4) | **NEVER** | — |
| `camAngVelValid` | via the call | via the call | **force `false`** | force `false` |
| `ownStateMs` (new) | **write** | **write** | **write** | **write** |
| `ownLastUpdateMs` | write | **NEVER** | **NEVER** | never (already) |
| `pushOwnHistory(now)` | call | **NEVER** | **NEVER** | never (already) |
| `ownTeam` / `ownTeamSeenMs` | write | **NEVER** | **NEVER** | never |
| `ownEntityId` | write | **NEVER** | **NEVER** | never |
| `rttMs` | write | **NEVER** | **NEVER** | never |
| `tickMs` (client ms clock) | write | **write** (field 16) | **NEVER** | never |
| `ownServerTick` (new) | never | **write** (field 12) | **write** (field 12) | never |
| `airborne` / `stateEnum` / `slidePathPos` | write | **NEVER** | **NEVER** | never |
| `ownEcho` | `= false` | `= false` | (see §3.6) | `= true` |
| `ownSamples` / `updateCalibReadout()` | bump | **NEVER** | **NEVER** | never |

### 3.3 The three "NEVER"s that are load-bearing

**(a) `ownLastUpdateMs` — it IS the `mounted()` detector.**
`mounted()` (`EspEngine.java:108-111`) is literally
`now - ownLastUpdateMs > OWN_STALE_MS`. Refreshing it from a vehicle carrier would
make `mounted()` return false while mounted, which would in turn stop
`refreshOwnFromEcho` being called (`EspEngine.java:1192`) — and with 2002 the echo
is the *only* camera source. The state would flap between "mounted" and "not
mounted" on every packet. `ownLastUpdateMs` must continue to mean **"the last time
Cmd 2001 arrived"** and nothing else. This is the same trap already documented at
`EspEngine.java:117-119`.

**(b) `pushOwnHistory` — it feeds the lag cross-correlator.**
`measureLag` (`EspEngine.java:353`) matches the inbound self-echo position against
`histX/histY`, and the age of the matching entry *is* the round-trip staleness.
2002/2069 positions are genuinely first-hand (we sent them), so they are not
self-correlation in the way the echo would be — **but they are the wrong
quantity**: they report the **vehicle root**, while the echo reports whatever the
server publishes for our entity, and the seat offset between the two is never on
the wire (`CMD_2002_VEHICLE_LAYOUT.md` §7, §9 item 3). `LAG_MATCH_UNITS` is 1.2 m
(`EspEngine.java:333`); a seat offset can exceed that outright and would bias every
sample by a constant. Holding the last good lag figure while mounted is correct —
exactly what the code does today. Do not push. (Revisit only after capture item
§10.2.3 measures the offset.)

**(c) `ownTeam` / `ownTeamSeenMs` / `ownEntityId` — not on the wire.**
2002 and 2069 carry no PlayerID and no team byte at all. Field 0 is a
`LevelVehicle` object id from a different id space; writing it into `ownEntityId`
would make the self-echo matcher chase a stranger, and the friend/foe rule is
relational on `ownTeam` (`EspEngine.java:147-166`) — a wrong value inverts the
whole box colouring. Leave both alone; they persist correctly from the last 2001
before mounting.

### 3.4 Camera angular velocity from 2069

2069's aim arrives on the same 99 ms cadence as 2001 (the `(counter % 3) == 0`
throttle in `EFJEIMIIEJO` @ `0x078cdbf4` gates *all seven* msgids identically), so
`dt` falls inside the existing `CAM_DT_MIN_MS 60` / `CAM_DT_MAX_MS 160` band
(`EspEngine.java:1947-1948`) and `computeCameraAngVel` may be called normally.
Quantisation noise of 0.29° over 99 ms is ≈ 2.9°/s of spurious angular velocity —
negligible against `CAM_EXTRAP_MAX_DEG`.

**One guard:** on the **first** 2069 sample after `ownDirSrc` changes (mount, or
2001 falling silent), skip the measurement and set `camAngVelValid = false`
instead. Measuring across a float32→quantised source boundary, or across the
mount discontinuity itself, produces a meaningless axis. `CAM_CUT_RAD` (80°,
`EspEngine.java:1953`) catches the gross case; this catches the rest for free.

### 3.5 What 2002 does about the camera

**Nothing — deliberately.** 2002 carries no player aim vector. This is proven
negatively and precisely: `Player::GetAimRotation` (`0x070718a8`) has exactly five
call sites in the dispatcher — `0x078ce14c` (2069), `0x078ce59c` (chair/2016),
`0x078ce770` and `0x078ce810` (2006), `0x078cebd4` (2001) — and **none** on the
path `0x078ce3ec`..`0x078ce564` that builds 2002. Neither is `GetAuxAimRotation`
nor `Entity::get_Forward`.

So when the active position source is 2002:

* position comes from 2002 (millimetre-exact, first-hand, 99 ms);
* the camera basis continues to come from the **inbound self-echo**, exactly as
  today, with all its documented degradation;
* `camAngVelValid` is forced `false` on every 2002 sample, mirroring
  `refreshOwnFromEcho` (`EspEngine.java:141`) — a basis rebuilt from a 1.41°-quantised
  yaw on a 198 ms tick makes a nonsense angular velocity, and refusing to
  extrapolate it is the correct answer.

This split is the point of the whole change: **2002 fixes the position half
exactly and leaves the camera half where it already is; 2069 fixes both.**

### 3.6 `refreshOwnFromEcho` must be split

Today (`EspEngine.java:125-143`) it writes position *and* direction, and is called
unconditionally for the ROLE_SELF track while `mounted()` (`EspEngine.java:1192`).
With 2002 live it must stop writing position while a fresher first-hand source
exists, or it will fight the vehicle carrier at 198 ms against 99 ms.

```java
private void refreshOwnFromEcho(Track t, long now, boolean takePos, boolean takeDir) {
    if (t == null || !t.poseValid) return;
    if (takePos) {
        posX = t.x; posY = t.y; posZ = t.z;
        ownPosSrc = OWN_SRC_ECHO;
        ownStateMs = now;
        ownMsEcho  = now;
    }
    if (takeDir) {
        // ... existing yaw/pitch -> dirX/dirY/dirZ, unchanged ...
        dirSampleMs = now;
        camAngVelValid = false;
        ownDirSrc = OWN_SRC_ECHO;
    }
    ownEcho = (ownPosSrc == OWN_SRC_ECHO) || (ownDirSrc == OWN_SRC_ECHO);
    ownEchoMs = now;
}
```

and the call site becomes

```java
if (t.role == ROLE_SELF && mounted()) {
    refreshOwnFromEcho(t, now, !mountPosFresh(now), !mountDirFresh(now));
}
```

`ownEcho` keeps meaning *"some part of own state is echo-derived"*, which is what
the renderer's warning line at `EspRenderView.java:1261-1264` actually states. On
foot both sources are 2001 and `ownEcho` is `false` — unchanged.

### 3.7 A defect this change must also fix: the 2-second mounted blackout

**Found while specifying; not previously recorded.** Two different constants share
the name `OWN_STALE_MS`:

| constant | value | purpose |
|---|---|---|
| `EspEngine.OWN_STALE_MS` (`EspEngine.java:92`) | **400 ms** | the `mounted()` detector |
| `EspRenderView.OWN_STALE_MS` (`EspRenderView.java:590`) | **2000 ms** | the renderer's own-state gate |

`EspRenderView.update` bails out entirely at `EspRenderView.java:1005-1006`:

```java
long ownMs = esp.ownLastUpdateMs();
if (ownMs <= 0 || now - ownMs > OWN_STALE_MS) return;   // draws NOTHING
```

`ownLastUpdateMs` advances **only** in `observeKeepalive` (`EspEngine.java:733`),
and `refreshOwnFromEcho` deliberately does not touch it. So today the self-echo
stopgap keeps the ESP alive for at most **~1.6 s after mounting**, after which the
renderer returns early and the entire overlay goes dark — silently, and
indistinguishably from a mask failure.

**Fix, and the only renderer change in this spec:**

```java
// EspRenderView.java:1005
long ownMs = esp.ownStateMs();     // was esp.ownLastUpdateMs()
```

On foot this is **bit-identical**: `observeKeepalive` sets `ownStateMs = now` on
the same line it sets `ownLastUpdateMs = now`, so the two fields are equal
whenever 2001 is flowing. Mounted, it is the difference between a live ESP and a
blank screen. `ownLastUpdateMs()` stays exported and stays 2001-only, because
`mounted()` depends on it.

---

## 4. Coordinate frame, and what to expose for a later rig correction

### 4.1 What the position actually is

Cmd 2002/2069 field 1–3 is `GCommon.Entity::get_Position` of
`Player::GetVehicleIAmIn()` (`x21`, set at `0x078ce0e8`) — the **vehicle root**,
in millimetres, in the same absolute world frame as 2001. The player's own
transform is never read on these paths. There is also **no moving-platform rule**:
`OLEOJNOGCCN` has no analogue of 2001's `v16` (`LPKKPCBKEBA`), and
`get_FootMovePlatfromID` / `get_OffsetPositionToMovePlatform` are called only on
the on-foot path (`0x078cf088`, `0x078cf09c`, `0x078cf0c8`). **2002/2069 positions
are always absolute world space.**

The seat offset between the vehicle root and the rendered player body is **not on
the wire and not recoverable from the packet**. Under a rider it is within about a
metre.

### 4.2 The camera rig differs per mounted state

From `docs/GAME_CLIENT_CONSTANTS.md` (`FollowCamera::SetOffestRightAndBack`
@ `0x07222344`), in that document's `(right, back, up)` convention, metres:

| state | right | back | up | our carrier |
|---|---|---|---|---|
| default / on foot | 0.40 | 2.50 | −0.05 | 2001 |
| **vehicle driver, not firing** | *(no explicit branch — inferred: the default)* | | | **2002** |
| **vehicle driver firing** | GameVar `+0x4084` | `+0x408c` | `+0x4088` | **2069** |
| vehicle passenger who can fire | 0.60 | 1.50 | 0.40 | 2006 (not parsed) |
| in catapult | 0.40 | 6.00 | −0.05 | 2015 (not parsed) |
| in cannon | 0.40 | 1.15 | 0.25 | 2031 (not parsed) |

Two honest caveats the implementer must carry into the code comment:

* **The 2002 row is an inference.** `SetOffestRightAndBack` has no branch labelled
  for a non-firing driver, so it presumably takes the default. Unverified.
* **The 2069 row is unknowable from the binary.** Those three offsets come from
  `GameVarDef` — *server-delivered asset data*, not code. They cannot be read out
  of the image at all.
* The repo's shoulder constant has the **opposite sign** to the document's table
  (`EspTuning.DEF_SHOULDER = −0.40` vs `C_OFFSET_RIGHT = +0.40`); the sign is
  explicitly recorded as not settled by the binary. Expose the document's values
  verbatim and let the caller reconcile.

### 4.3 What to expose — and what NOT to do with it

Add read-only accessors on `EspEngine`:

```java
public int     ownPosSource();          // OWN_SRC_*
public int     ownDirSource();          // OWN_SRC_*
public long    ownStateMs();            // last own-position write, any source
public boolean ownPosIsVehicleRoot();   // true for 2002/2069, and for the echo while mounted()
public long    ownVehicleId();          // LevelVehicle object id, 0 on foot
public long    ownServerTick();         // 2002/2069 field 12
public boolean ownVehicleForward(float[] out3);  // §1.6; false when not valid
/** Rig for the CURRENT own-state source, in (right, back, up) metres.
 *  Returns false and leaves out3 untouched when the rig is unknown
 *  (2069 = server GameVars). Caller reconciles the shoulder sign. */
public boolean ownCameraRig(float[] out3);
```

**The renderer must not call any of these in this change.** `EspRenderView`
continues to apply `TPS_BOOM_M` / `TPS_PIVOT_H_M` / `TPS_SHOULDER_M` exactly as it
does at `EspRenderView.java:1361-1371`. Rendering behaviour is out of scope; these
accessors exist so the correction can be written later against measured data
rather than guessed at now. Say so in the Javadoc, or a reviewer will "helpfully"
wire them up and change the projection with no way to tell whether the result
improved.

---

## 5. Precedence

### 5.1 The rule

Position and direction are resolved **independently**, because 2002 supplies one
and not the other.

**Position:** `2001 > 2069 > 2002 > self-echo`
**Direction:** `2001 > 2069 > self-echo > (2002 vehicle-forward — OFF, §5.2)`

A source may write only if every higher-priority source is **stale**:

| source | staleness window | justification |
|---|---|---|
| Cmd 2001 | **400 ms** | 99 ms cadence; the existing `EspEngine.OWN_STALE_MS`, unchanged |
| Cmd 2069 | **400 ms** | identical cadence — the `%3` throttle in `EFJEIMIIEJO` gates all seven msgids off one counter |
| Cmd 2002 | **400 ms** | same |
| self-echo | **600 ms** | 198 ms entity tick; three missed ticks |
| *renderer bail-out* | *2000 ms on `ownStateMs`* | `EspRenderView.OWN_STALE_MS`, §3.7 |

Implemented as a branch-free guard, no locking:

```java
private boolean mayWritePos(int src, long now) {
    if (src == OWN_SRC_2001) return true;
    if (now - ownMs2001 <= OWN_STALE_MS)   return false;
    if (src == OWN_SRC_2069) return true;
    if (now - ownMs2069 <= MOUNT_STALE_MS) return false;
    if (src == OWN_SRC_2002) return true;
    if (now - ownMs2002 <= MOUNT_STALE_MS) return false;
    return true;   // echo, the last resort
}
// mayWriteDir(): same ladder with 2002 removed entirely.
static final long MOUNT_STALE_MS = 400L;
```

### 5.2 Why the 2002 vehicle quaternion is not a camera fallback

> **RETRACTED for the mounted case, 2026-09-15.** This section rejected the
> vehicle quaternion on the grounds that it is the body, not the view. That is
> still true, but the section assumed a better source existed. Measurement says
> none does: while mounted the self-echo's moving aim field **is** the vehicle
> rotation re-encoded (median 0.5 deg from the quaternion we ourselves sent,
> N=64) and the echo's 3-D camera vector is **byte-identical to its last
> pre-mount value in 67 of 67 samples**. There is no player look direction
> anywhere on the wire while riding. The real choice is "vehicle heading" vs
> "camera frozen at the instant of mounting", and the frozen basis was the
> reported bug. The heading is now used, taken from our own outbound
> quaternion rather than the echo's lagged copy, behind `MOUNT_VEHICLE_CAMERA`
> (default on) and named in the HUD as `2002q(heading!)`.
> See `MOUNTED_CAPTURE_ANALYSIS.md` Q1.



It is *available* (§1.6) and it is *wrong*. The vehicle rotation is the body yaw,
not the view. Free Fire's horse aim is explicitly decoupled from the body — that
is exactly what `GameVarDef`'s `HorseAimAngleRightLeft` / `HorseAimAngleUp` /
`HorseAimAngleDown` / `EnableHorseAimForwardDeflect` / `HorseAimForwardKeepAngle`
exist for. A basis built from the body quaternion is wrong by up to the full
configured aim cone the instant the player free-looks, and — worse — it is wrong
*smoothly and plausibly*, which is the failure mode that costs a debugging session.

Expose it via `ownVehicleForward()` for diagnostics and for the eventual free-look
residual estimate. Do not select it as `ownDirSrc`. If it is ever wired in, it
must be behind an explicit tune-panel toggle that defaults off, and the OWN HUD row
must name it.

### 5.3 In practice there is almost no contention

The mount transition is seamless: the dispatcher's send counter and its
`(counter % 3) == 0` throttle sit at the very top of `EAIKJCCNGMJ`
(`0x078cdef0`..`0x078cdf08`), **before** any branching, so the very next tick after
mounting emits 2002/2069 in place of 2001, 99 ms later. `mounted()` still only
fires at 400 ms, but own **position** never degrades at all. The ladder exists for
the dismount edge and for a mis-solved header, not for steady state.

### 5.4 States with no carrier at all

`EFJEIMIIEJO` returns false — **nothing is sent, no substitute msgid** — for
`IsOnBoard`, `IsOnFerrisWheel`, `IsFollowing`, `IsPassiveMoving`,
`IsOnlineBotAgent`, `IsDead`, and a disable flag at `this->[0x65c]`
(`0x078cdb4c`..`0x078cdbdc`). Also unparsed by this spec: 2006 (passenger — aim
but **no position at all**), 2015, 2016, 2031. In every one of these the self-echo
remains the only source, which is exactly why §7's fallback is mandatory rather
than optional.

---

## 6. Validation

### 6.1 The checks, in order

Run all of them **before** any field reaches own state. A half-parsed record must
never be written — a wrong position is worse than a stale one, because the stale
one is at least where we last actually were.

| # | check | reject when |
|---|---|---|
| 1 | reader never overran | `reader.bad` |
| 2 | quaternion magnitude | `qx² + qy² + qz² + qw²` outside **900 000 … 1 100 000** |
| 3 | quaternion component range | any `|qi| > 1200` (int16 by construction; a unit quaternion ×1000 cannot exceed 1000) |
| 4 | velocity component range | any `|vi| > 32767` (int16 by construction) |
| 5 | **terminal cursor** | cursor after the last field `!=` body end |
| 6 | position sanity | any `|p| >= 1e8` — see the warning below |

**Check 2 is the cheapest self-check in the whole record** and is the one
`CMD_2002_VEHICLE_LAYOUT.md` §9 nominates. The ±10% band is deliberately generous:
rounding four `int16` components each by ≤0.5 moves the sum of squares by up to
~±2 000, and the game's own quaternion is not exactly unit (the inbound corpus
sample `(22, 366, −6, 930)` gives ‖q‖ = 0.9997 → 999 400). A desynced parse reads
four unrelated varints and misses the band by orders of magnitude.

**Check 5 is the discriminator.** Field 0–7 are read identically under both
readings of field 8, so the quaternion check passes either way; only the terminal
cursor distinguishes them. It is also the check that catches a wrong field count
outright, which is what makes parsing a message with zero wire samples tractable
at all.

**Warning on check 6.** Do **not** gate on map-plausible coordinate ranges. That
exact mistake — "`X ≤ 1.3e6, Z ≤ 65535`" — is the documented cause of the
phantom-entity / million-unit-jump bug (`EspEngine.java:849-862`); those bounds are
map-specific and this map already reaches X 1 394 820 and Z 166 214. Use a bound so
loose it can only catch a catastrophic mis-parse, and let checks 2 and 5 do the
real work.

### 6.2 The raw-byte / varint ambiguity on field 8

The two input documents disagree, and both cite the same class:

* `CMD_2002_VEHICLE_LAYOUT.md` §3.2/§3.3 quotes the instructions —
  `0x047ced80 ldrb w1,[x20,#0x28]` → `0x047ced8c bl #0x8291c9c` = `Write(byte)` →
  `WriteFixU8` @ `0x08291ff4` → `DemandSpace(1)` + one `strb`. **One raw byte.**
* `VEHICLE_DISPATCH_MAP.md` §3.5 footnote claims the same field is written through
  the `uint` overload, i.e. a varint.

Both cannot be true: 2002 and 2069 share `OLEOJNOGCCN::Serialize` @ `0x047cec24`.
The address-level disassembly is the stronger evidence, and the dispatch document
explicitly defers this record's field semantics to the other one. **Treat
raw-byte as canonical.**

It does not matter while `op < 0x80`, where both encodings are byte-identical —
and the only observed value anywhere in the corpus is 8. Resolve it defensively
instead of betting:

```
parse with field 8 = RAW BYTE   -> run checks 1..6
   pass -> accept
   fail -> re-parse the same body with field 8 = VARINT -> run checks 1..6
              pass -> accept, and bump a distinct counter (op>=0x80 seen,
                      documents disagree, varint reading won)
              fail -> REJECT the sample entirely
```

The retry can only ever fire when `op >= 0x80`, i.e. exactly the ambiguous case.
It costs nothing in the common path and it self-documents which reading the wire
actually uses — the counter in the OWN HUD row (§8) is the answer to the open
question, obtained for free the first time a horse presses a button.

### 6.3 What a rejected sample does

Nothing. Bump the per-carrier `bad` counter and the per-reason sub-counter, return.
Own state is untouched, the precedence ladder therefore lets the next-best source
(ultimately the self-echo) keep supplying it, and the OWN HUD row shows the reject
count climbing. **Never write a partial record.**

---

## 7. Fallback, and what is deliberately unchanged

* If the header solver has not converged, `parsed` is null or `cmd` is
  unresolved, the hook never fires, and everything behaves exactly as it does
  today. This is how every exact-cmd consumer in the repo is written
  (`PacketContext.java:35-40`) and it is correct: the solver needs a few hundred
  outbound packets and re-arms after every match/room transition.
* If neither 2069 nor 2002 ever validates — wrong mode, unparsed state (§5.4),
  layout drift — the precedence ladder falls straight through to the self-echo and
  the current stopgap runs unchanged. **Nothing regresses.**
* **On foot, nothing changes at all.** The hook does not fire (no 2002/2069 is
  sent), `observeKeepalive` is untouched apart from the one added
  `ownStateMs = now`, and `ownStateMs == ownLastUpdateMs` makes the renderer's
  gate bit-identical.

---

## 8. The diagnostic row

The recurring lesson in this repo is that a silent no-op is indistinguishable
from a working feature. This feature has **four** distinct silent-failure modes —
solver not converged, carrier never arrives, every sample rejected, and the
fallback quietly carrying everything — so the row must separate them.

Add to `overlay/EspOverlay.java` `buildDebugText`, next to the `HP` row at
`EspOverlay.java:283-286`, in the same style:

```java
sb.append("OWN   ").append(e == null ? "engine off" : e.ownSourceLine()).append('\n');
```

`EspEngine.ownSourceLine()` mirrors `teamLine()` (`EspEngine.java:1701`) — a plain
`String.format`, built ~2 Hz off the UI thread, allocating nothing on a packet
path.

**Format:**

```
OWN   pos=2069 dir=2069 age=41ms cam=41ms | 2001:1284 2069:311/2 2002:0/0 echo:57 | veh=37 mnt=Y
```

| token | meaning |
|---|---|
| `pos=` / `dir=` | active source per axis: `2001` / `2069` / `2002` / `echo` / `none` |
| `age=` | `now - ownStateMs` |
| `cam=` | `now - dirSampleMs` |
| `2001:N` | accepted keepalives (`ownSamples`) |
| `2069:ok/bad`, `2002:ok/bad` | accepted / rejected vehicle records |
| `echo:N` | echo-derived refreshes |
| `veh=` | `ownVehicleId`, `-` on foot |
| `mnt=Y/N` | `mounted()` |

**Loud states, appended verbatim when they hold:**

| condition | text |
|---|---|
| `!pipeline.isReady()` | `  CMD UNRESOLVED (solver not converged — hook idle)` |
| `mounted()` and `2069:ok + 2002:ok == 0` | `  NO VEHICLE CARRIER — falling back to echo` |
| any `bad > 0` | `  bad: quat=N tail=N range=N` |
| the §6.2 retry ever won | `  OP>=0x80: field 8 is a VARINT (docs disagreed; wire says varint)` |

That last line is the only place the field-8 question gets answered, and it
answers itself the first time it matters.

---

## 9. Constraints — restated because each has a specific failure mode here

* **No new outbound packets, ever.** This is parsing only. Injecting a reliable
  message mints an OrderID the reliability layer never issued and drops the
  session. Nothing in this spec constructs, resends or rewrites a packet.
* **Do not rewrite 2002/2069 either.** `TeleportFilter.java:254` already stands
  down on `Cmd.isMountedPositionCarrier(ctx.cmd)` for exactly this reason. Parsing
  a body is not licence to edit it.
* **Java 8, minSdk 21.** No `var`, no lambdas on the packet path, no `switch` on
  strings, no `Optional`, no streams.
* **No per-packet allocation beyond the 2001 path's.** The 2001 path allocates one
  `long[]` in `varints`. The vehicle parser should allocate **zero**: single-threaded
  (§2.3), so read into one reusable `EspEngine`-owned holder with an `int` cursor
  field. Do not `new WireReader(...)` per packet.
* **Rendering behaviour unchanged** apart from the single one-line staleness-source
  fix in §3.7, which is bit-identical on foot.

---

## 10. Honest unknowns — what is unverified, and the capture that settles it

### 10.1 What rests on no wire evidence at all

| claim | basis | status |
|---|---|---|
| Field order and per-field encoding of 2002 | address-level disassembly of `OLEOJNOGCCN::Serialize` @ `0x047cec24` and `JBECKHDPPOO::Serialize` @ `0x049d724c` | **strong, binary-proven, zero wire samples** |
| Field 8 is one raw byte | `Write(byte)` @ `0x08291c9c` → `WriteFixU8` @ `0x08291ff4` | **contradicted by the other input doc**; §6.2 resolves it at runtime |
| 2069 = 2002 + aim + client-ms | `OGHGHMCCKFK::Serialize` @ `0x049d74e4`; both docs agree | strong, zero wire samples |
| A horse routes to 2069 | `MountableAnimal::CanDriverFire` @ `0x0758f4c4` returns `vehicleData->bool@0x59` | **rests on a CSV flag that is NOT in the binary** — it lives in an asset bundle |
| `GameModeSetting.EnableVehicleDriverWeaponFire` (`+0x23`) is set in the played mode | read at `0x070839c8` | **per-mode; BR and Clash Squad may differ** |
| 2002/2069 are plaintext | `sendOption = 0` at `0x078ce674`; `IsReliable` @ `0x082c0c04` returns true only for `sendOption ∈ {1,2,5}` | strong; independently corroborated — `docs/CMD_CATALOGUE.md` already lists 2002 as observed unencrypted |
| Cadence is 99 ms | shared `(counter % 3) == 0` gate @ `0x078cdbf4`, identical to 2001's | exact **ratio** proven; the absolute 30 Hz driver is inherited from the repo's 2001 measurement |
| `v7`/field 8 semantics (`GetCurrentPackedOp`) | not decoded; a per-subclass virtual, slot 119 | **unknown**; constant 8 in every inbound sample |
| The 2002 camera rig is the default branch | no branch exists for a non-firing driver | **inference** |
| The 2069 camera rig | `GameVarDef` — server-delivered | **unknowable from the binary** |

`VEHICLE_DISPATCH_MAP.md` §9.3 also warns that
`phone_aim6/capture_raw_20260912_162908.txt` *appears* to contain five packets from
this family. They are header-decode false positives — wrong session (`MATCH 2`,
`148.222.88.45`, mask solved against `MATCH 1`), reliable header form, high-entropy
payloads, nonsense varints. **Do not treat them as evidence.**

### 10.2 The capture that settles it

**One mounted capture answers everything.** Take it in **`MODE_FULL` or
`MODE_MATCH`** — *not* `MODE_COMBAT`: that mode keeps only
`Cmd.isOwnPositionCarrier` / `isMountedPositionCarrier`
(`dev/capture/PacketCapture.java:383-387`), and `Cmd.isOwnPositionCarrier`
(`net/Cmd.java:371-382`) **does not list 2069**, so a combat-mode capture would
drop the horse packet on the floor. Capture truncation is off (`hexLimit` is
recorded but ignored, `PacketCapture.java:161`), so the full ~40-byte body lands.

1. **Which msgid replaces 2001 while mounted.** Mount a horse, watch the outbound
   stream. `0x815` (2069) ⇒ `CanDriverFire` is true for that row and the mode flag
   is on. `0x7d2` (2002) ⇒ one of them is false. Test in the mode that matters —
   BR and CS can differ. **Sixty seconds of play.**
2. **Byte-level confirmation of the layout.** Drive in a straight line. Expect:
   one roughly constant leading varint (the vehicle id), three zigzag varints
   stepping smoothly by hundreds to thousands per tick (mm), **four small zigzag
   values whose squares sum to ≈ 1 000 000**, one byte, three small zigzag values
   (cm/s), then a monotonically rising varint.
3. **The seat offset** between the vehicle root and the player body — compare a
   2002 position against the inbound entry for our own entity, or against the last
   2001 position at the instant of mounting. This is the gate on §3.3(b).
4. **`GetCurrentPackedOp`'s bit layout** — diff field 8 while pressing
   throttle / brake / handbrake / horn. Also the only way to force the §6.2 retry.
5. **Whether the server keeps publishing a mounted player in the inbound 2001
   list** — correlate a remote player's Cmd 125 `RUDP_GETON_VEHICLE` against their
   subsequent inbound 2001 entries. Pure offline analysis of captures the repo
   already has; it decides whether the self-echo fallback is viable at all while
   mounted, which is the assumption §5.1's bottom rung rests on.

### 10.3 Related defects found while specifying — OUT OF SCOPE, do not fix here

Recorded so they are not lost. Each changes filter behaviour and belongs in its
own change with its own in-game validation.

* **`Cmd.isOwnPositionCarrier` (`net/Cmd.java:371-382`) is missing 2069, 2015 and
  2016.** Consequences today: `GhostFilter.java:151` does not recognise 2069 as a
  keepalive, `TeleportFilter.java:254` does not stand down while riding a horse
  (it stands down on 2002 but not 2069), and `PacketCapture` `MODE_COMBAT` drops
  outbound 2069 entirely. Adding them changes ghost and teleport behaviour, so it
  is not part of this spec.
* **`Cmd` has no enum constants for 2069 / 2006 / 2015 / 2031.** `CmdCatalogue`
  already carries all four names correctly
  (`2069:UDP_VEHICLEWEAPONFIRE_STATE_SYNC`, `2006:UDP_PASSENGER_STATE_SYNC`,
  `2015:UDP_SYNC_CATAPULT`, `2031:UDP_SYNC_CANNON`), so the hook in §2.2 should
  switch on the **literals `2002` / `2069`** rather than adding enum constants and
  pulling them into the helper predicates above by accident.
* **`tools/il2cpp/ff_outbound_registry_full.txt`** is missing 2002 / 2015 / 2031 /
  2069 (they all reach `Send` through the shared tail-call at `0x078ce684`, and the
  scanner only recovered the immediately preceding `mov w0, #0x7e0`), and it
  mislabels 2001's class. Noted in `VEHICLE_DISPATCH_MAP.md` §2.

---

## 11. Implementation checklist

1. `EspEngine`: add the source constants, the timestamp/source fields, and
   `ownStateMs` (§3.1). Set `ownStateMs = now` in `observeKeepalive` on the same
   line as `ownLastUpdateMs = now` (`EspEngine.java:733`) and set
   `ownPosSrc = ownDirSrc = OWN_SRC_2001`.
2. `EspEngine`: add `observeVehicleState(int cmd, byte[] buf, int off, int len)` —
   the allocation-free parser of §1, the validator of §6, the write matrix of §3.2,
   gated by `mayWritePos` / `mayWriteDir` of §5.1.
3. `EspEngine`: split `refreshOwnFromEcho` per §3.6 and update its one call site
   (`EspEngine.java:1192`).
4. `EspEngine`: add the accessors of §4.3 and `ownSourceLine()` of §8.
5. `PacketLoop.java`: add the command switch of §2.2 after line 164.
6. `EspRenderView.java:1005`: `esp.ownLastUpdateMs()` → `esp.ownStateMs()` (§3.7).
7. `EspOverlay.java`: add the `OWN` row after the `HP` row (§8).
8. Verify on foot first: the `OWN` row must read `pos=2001 dir=2001`, `2069:0/0`,
   `2002:0/0`, `mnt=N`, and every other HUD row must be unchanged.
9. Then mount something and read the row. If it says `NO VEHICLE CARRIER`, the
   answer to §10.2.1 is in the capture, not in the code.
