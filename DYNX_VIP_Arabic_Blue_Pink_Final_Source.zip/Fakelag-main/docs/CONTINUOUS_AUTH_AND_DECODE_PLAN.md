# Continuous-auth + server-owned decode — implementation plan (2026-09-18)

Unifies two design passes: the **continuous-auth/heartbeat** design and the
**decode server-porting** spec. Goal (owner): the server is no longer a one-shot
gate — it must keep agreeing (heartbeat), and the client must not carry the
decode *knowledge* (field maps) in a form a cracked offline build can use.
Everything ships staged behind flags (like `DECODE_LEASH`/`NATIVE_SHADOW`) and is
validated on device before enforcing. Companions: `SERVER_GATED_DECODE_DESIGN.md`,
`SECURITY_MODEL.md`.

## The two ideas converge on ONE object: the `decode_profile`

- **Heartbeat** changes the profile's *validity*: from a static 6 h `valid_until`
  to a **rolling** short `valid_until` (start 12 min) re-armed by a `/auth/heartbeat`
  every 4 min, keyed to a monotonic clock. One-line login patch → never armed;
  stubbed heartbeat → lapses within one TTL; date-rollback → defeated by
  `elapsedRealtime()`.
- **Decode-porting** changes the profile's *content*: it also carries the
  field-semantic **maps** (which `v[i]` means what) that are currently baked in
  the client — `chain.record_fields`, `keepalive_v_map`, `hit106_field_map`,
  `pri_key_layout`, `mark148_layout`, `vehicle_layout`, feature id-`gates`. Zero
  wire cost (decode-side interpretation only); a jadx/IDA of the client shows the
  walker but not the answer key.

Both ride the existing authenticated AES-GCM envelope; no new crypto, no
per-packet round-trip.

## Ordered, staged implementation (each step: build/test → commit → validate)

### Stage A — Server (safe to deploy; unblocks everything)
1. **M2 revocation fix** — `/config` (and later `/heartbeat`) re-check `devices.active`
   for `claims["did"]`, not just `_license_ok`. Cuts revocation from ≤6 h to ≤1 beat.
2. **Server hardening nits** (from the review) — pydantic `max_length` caps (M3),
   rate-limit `/version` (L4), indexes on `refresh_tokens(family_id)/(device_id)`,
   `devices(license_id)` + prune (L3), Caddyfile XFF guard comment (M1).
3. **`POST /auth/heartbeat`** — sibling of `config()`, Bearer access token, sealed
   like `/config`, NO one-time-jti (a token drives several beats). Returns a
   rolling `{valid_until = now+ROLLING_TTL_SEC, server_now, epoch, chain, <maps>}`.
   `build_rolling_profile()` in `config_blob.py`. New `ROLLING_TTL_SEC` (12 min)
   + `HEARTBEAT_ENFORCE` (default off) in `settings.py`. `HeartbeatRequest/Response`
   in `models.py`.
4. **Extend `decode_profile`** — add the field-maps to `_CHAIN_DECODE_PARAMS`/
   `build_blob` (and the rolling profile): `record_fields`, `keepalive_v_map`,
   `hit106_field_map`, `pri_key_layout`, `mark148_layout`, `vehicle_layout`,
   `gates`. (Schema in the decode-porting spec.)
5. Deploy to the VPS (`git pull` + restart `nuvola.service`); existing clients ignore new fields.

### Stage B — Client (behind flags; shadow first)
6. `ConfigStore`: parse the extended profile + all maps RAM-only, zeroed on
   `clear()`; add `armRolling(valid_until, server_now, epoch, …)`; switch
   `decodeArmed()` + the native call sites to the **monotonic** `elapsedRealtime()`
   domain.
7. `SessionManager`: unified auth state machine (UNACTIVATED→SESSION→ARMED⇄DISARMED,
   OFFLINE_LEASE never arms decode) + `heartbeat(ctx)`.
8. `PacketVpnService`: a `ScheduledExecutorService` heartbeat loop (start in
   `onCreate`, stop in `onDestroy`/`onRevoke`), off the packet thread, app→server
   HTTPS only (never the game socket). New Diag slot for arm/lapse.

### Stage C — Native (generalize the leash to carry maps; QEMU-gate each)
9. `ChainProfile → DecodeProfile`: chain gains `record_fields`, `self_echo_varints`,
   `pose` scales; `possync`/`aim`/`pri`/`mark`/`vehicle` take their map by ref and
   fail-closed (`-1`/None) when absent. Production consts become `#[cfg(test)]`.
10. `armDecodeProfile(ByteBuffer json)` JNI (parse once, per-session), + per-packet
    entries reference it. Non-fatal registration (like `chainDecode`).

### Stage D — Wire the live Java paths + gate everything (behind `DECODE_LEASH`)
11. `EspEngine`/`AimFilter`/`MarkFilter`/`PriSync`/`PositionSync` source their
    field-maps from `ConfigStore` and fail-closed when null. Every feature no-ops
    (renders nothing / passes the packet byte-identical) without a live profile.

### Stage E — Adversarial validation (rooted LD emulator + phone)
12. On the rooted emulator: reproduce the crack (patch `SessionManager.authorized`
    one-liner / repackage) and IDA-patch attempts; confirm ESP stays dark
    (leash fail-closed) and revocation bites within a beat. Document what a full
    binary-patch RE can still do (freeze armed RAM for the process lifetime — the
    plaintext-ESP ceiling) and the phase-3 answer (fold the rolling epoch into the
    keyed reliable-channel decrypt).
13. On the phone: flip `NATIVE_SHADOW` → confirm native decode parity in a live
    match; ratchet `ROLLING_TTL_SEC` 6 h→30 min→12 min watching `ESP_LEASH_CLOSED`;
    then flip `DECODE_LEASH`/`HEARTBEAT_ENFORCE`.

## Honest security bound
This converts "one login → permanent offline ESP" into "ESP dies within one
heartbeat unless the server keeps agreeing," and makes revocation bite in minutes.
It does NOT make a fully-patched client uncrackable (2012 chain is plaintext; a
determined RE can freeze armed RAM for the process lifetime). The strong follow-up
(phase 3) is binding the rolling secret into the TEA/bodycrypt keyed decrypt.
