# Module health — reading a `# DIAG` block

**The capture tells you what arrived. This tells you what the code did with it.**

Every multi-hour bug in this project was a *decision*, not a packet — a guard
bailing, a rule firing, a parse refused, a state reset. None of them leave a
trace in the packet stream, which is why each one was diagnosed by replaying
logic offline against a capture and guessing. This block exists so the next one
is a glance.

---

## 0. The 10-second read

Scroll to the end of a `capture_raw_*.txt` and look for `# DIAGALARM` lines
first. If there are none, the subsystems believe they are healthy and the
problem is elsewhere — go to `WHEN_NOTHING_WORKS.md`.

If there are alarms, **read only those**. Each one names the failure and what
the user would see. The counters above them are the evidence; the alarm is the
verdict.

```
# DIAGALARM RESET_LOOP match reset fired 789 times this window (max 2). ...
# DIAGALARM NO_OUTBOUND in=6247 out=1. The game's traffic is not entering the tunnel...
```

The HUD carries the worst current alarm on one line, so a failure is visible
in-game without pulling a file at all:

```
DIAG RESET_LOOP
```

`DIAG ok` means no invariant is violated.

---

## 1. Format

```
# DIAG window_ms=15000
# DIAG <SLOT_NAME> total=<cumulative> d=<delta this window> rate=<per second>
# DIAGEV <wall_ms> <SLOT_NAME> <detail>
# DIAGALARM <TAG> <what is wrong and what the user sees>
```

* **`total`** is cumulative for the process, never reset by a match boundary.
* **`d`** is the delta since the previous block — this is the number that
  matters. A large total with `d=0` is history, not a problem.
* Slots that have never fired are omitted entirely, so the block stays short.
* `DIAGEV` lines are rare events with detail, consumed once. They are capped at
  64 per window; a `dropped=` line means an event is wired onto a hot path and
  should be a counter instead.

Blocks are written every ~15 s while capture is running, and once more in the
footer — so a dump that ends abruptly still carries its last window.

---

## 2. The slot families

| prefix | subsystem | what it tells you |
|---|---|---|
| `TUNNEL_` | the VPN transport | is the game's traffic reaching us at all |
| `PROTO_` | header layout, keys, decrypt | can we read what arrived |
| `DEC_` | body parsing | is the wire format being walked correctly |
| `ESP_` | the entity engine | what the engine decided about each player |
| `ESP_CLS_` | the friend/foe ladder | **which rung decided, and to what** |
| `ESP_OWN_` | own position/camera source | 2001, 2069, 2002, or the self-echo |
| `FLT_` | packet filters | did a rewrite fire, and if not why |
| `RENDER_` | the overlay | **which layer gave up when nothing was drawn** |
| `AIM_` | touch injection | **which precondition refused** |

The three bold rows are the ones worth knowing exist. Each replaces a question
that previously had no answer short of a debugging session.

---

## 3. The three reason ladders

### 3.1 "Why is this box that colour?" — `ESP_CLS_*`

The friend/foe classifier is a priority ladder, and **which rung decided** is
the single most valuable diagnostic in this codebase. Reconstructing it offline
is exactly what found both the BR proximity inversion and the CS blackout.

| slot | meaning |
|---|---|
| `ESP_CLS_NO_OWN_ID` | bailed before deciding: we do not know our own entity id |
| `ESP_CLS_R1_SELF` | identified as us |
| `ESP_CLS_R2_TEAM` / `_R2_ENEMY` | decided by the **server's own team byte** — the only rung allowed to say TEAM |
| `ESP_CLS_R2_NO_OWN_TEAM` | could not compare: own team unknown or stale |
| `ESP_CLS_R3_CLOSURE_ENEMY` | our squad is full, so this cannot be a squadmate |
| `ESP_CLS_R4_LATE_ENEMY` | appeared too late in the match to be a squadmate |
| `ESP_CLS_R6_DEFAULT_ENEMY` | nothing decided; red by default |

**Healthy Battle Royale:** `R2` should dominate once Cmd 118 binds land, with
`R6` carrying the early match. **`R6` dominating for a whole match means the
authoritative team source never arrived** — check `ESP_TEAM_SRC_BIND` and
`ESP_TEAM_SRC_ROSTER`, which should be non-zero within seconds of match start.

### 3.2 "Why is the ESP blank?" — `RENDER_*`

A chain of early returns that previously all looked identical from outside:

| slot | the gate that closed |
|---|---|
| `RENDER_NO_ENGINE` | the engine is not running |
| `RENDER_MASK_NOT_READY` | the header layout has not solved |
| `RENDER_NO_OWN_STATE` | own position/camera older than 2 s — **this is the one that blanked the overlay 1.6 s into every vehicle ride** |
| `RENDER_ENTITY_STALE` | that entity's last update is too old (normal, high volume) |
| `RENDER_ROLE_FILTERED` | self or a hidden role (normal) |
| `RENDER_DREW_BOX` / `RENDER_DREW_NOTHING` | the outcome |

### 3.3 "Why did the aim do nothing?" — `AIM_*`

Roughly eight independent preconditions that used to collapse into one boolean
the user saw as "not ready": `AIM_NO_SHIZUKU`, `AIM_NO_PERMISSION`,
`AIM_BINDER_DEAD`, `AIM_NO_TARGET`, `AIM_YIELD_TO_TOUCH`, `AIM_PARKED_IDLE`,
`AIM_TRAVEL_CAPPED`, `AIM_INJECT_THREW`.

---

## 4. The alarms, and where each threshold comes from

Every threshold is derived from a measurement in `docs/`, not guessed.

| alarm | fires when | provenance |
|---|---|---|
| `RESET_LOOP` | match reset > 2 per window | the CS regression fired **789 times in 109 s** (`CS_MODE_ESP_FAILURE.md`) |
| `NO_OUTBOUND` | in > 100 with out < 3 | measured **out=1 / in=6247** with the wrong build targeted, vs 972/870 healthy (`WHEN_NOTHING_WORKS.md` §1) |
| `LOPSIDED` | in/out ratio > 20:1 | healthy is near 1:1 |
| `CLASSIFIER_BLIND` | every classify bailed, none decided | the CS blackout signature |
| `NO_AUTHORITATIVE_TEAM` | 200+ classified, zero Cmd 118/101 team bytes | friend/foe running purely on the red default |
| `RENDER_BLIND` | engine classified entities, renderer drew zero | engine/view divergence |
| `DECRYPT_FAILING` | failures > 4x successes | key wrong or stale |
| `SEED_REJECTED` | lobby layout seed rejected > 2 times | field 42 mis-parse or wrong mask |
| `AIM_CANNOT_ACT` | 500+ ticks, 0 injections, Shizuku refusing | burning binder calls with no chance of working |
| `SESSION_CHURN` | > 5 UDP sessions closed per window | each close re-NATs onto a new source port mid-match — the kick fingerprint |
| `DECODER_THREW` | any inbound decoder exception | our own parsing bug dropping packets |

**The rule for adding one:** an invariant must be *impossible* in healthy
operation, not merely unusual. A rule that fires during normal play trains the
reader to ignore alarms, which is worse than having none.

---

## 5. Cost

`Diag.hit()` is one `AtomicIntegerArray` CAS — about 10 ns, no allocation, no
lock, no string. The worst realistic aggregate across packets, entities and
frames is ~10 000 hits/sec, so under 0.1 ms per second of wall clock.

`int` not `long`: `minSdk 21` admits 32-bit ARM, where a non-atomic 64-bit write
can tear. `int` wraps at 2.1 billion — 24 days at 1000/sec.

**Counters are always live**, capture on or off, because they are free. Only the
*emission* is gated on capture running.

---

## 6. Adding a slot

1. Add the `int` constant to `diag/Slot.java` **at the end of its block** —
   never renumber an existing one; old dumps are read against these ids.
2. Register the name in the `static` block. An unnamed slot prints as
   `SLOT_UNNAMED_n`, which is deliberate: the gap is visible rather than blank.
3. Call `Diag.hit(Slot.X)` at the bail site. **Never change control flow to add
   a counter** — if a site cannot be instrumented without altering behaviour, it
   does not get instrumented.
4. Use `Diag.event(slot, detail)` only for things that happen a handful of times
   per session. On a per-packet path it will show up as `dropped=`.

---

## 7. Related

- `WHEN_NOTHING_WORKS.md` — the packet-level triage this complements
- `CS_MODE_ESP_FAILURE.md` — the bug `RESET_LOOP` exists to catch
- `FRIEND_FOE_AUTHORITATIVE.md` — what the `ESP_CLS_*` distribution should look like
- `PERF_AUDIT.md` — the hot-path measurements the cost budget above rests on
