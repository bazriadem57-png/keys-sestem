# Game client constants, recovered from the binary

Every number here came out of `C:\Users\Tonyt\Documents\FF-RE\bin\libil2cpp_dec.so`
(the **decrypted** image — the plain `libil2cpp.so` has encrypted method bodies)
on **2026-09-13**, cross-checked against `addr_sorted.txt` / `rva_map.txt`. Each
one **replaces a value that was previously tuned by eye or guessed**.

Addresses are RVAs. idalib was never needed; all of it came from ripgrep over
the dumps plus disassembly of specific functions.

> **Two standing caveats that apply to everything below.**
> 1. Every function in these paths is wrapped in an
>    `IFix.WrappersManagerImpl::IsPatched` / `GetPatch` prologue. Garena can
>    hot-replace any of them server-side without an APK update, so these are
>    *shipped defaults*, not guarantees.
> 2. Several values load from CSV config or Unity serialized asset data. Those
>    are called out explicitly — do not treat them as compiled constants.

---

## 1. Camera and projection

### FOV — this was the far-target drift

`COW.GamePlay.FollowCamera::GetFovNormal` @ **`0x0722320c`** is a single static
read:

```
07223288  ldr  x8, [x0, #0xb8]      ; Il2CppClass->static_fields
07223290  ldr  s0, [x8, #0x20]      ; FollowCamera::C_FOV_NORMAL
```

The `.cctor` @ `0x07228174` fills slot `+0x20` from the 16-byte literal at
`0x18bfeb0` = `[60.0, 60.0, 0.2, 2.5]`.

> **`C_FOV_NORMAL = 60.0°`, and it is a Unity VERTICAL FOV.**

Three independent confirmations that it is vertical:

- `Camera.set_projectionMatrix` is never called on the gameplay camera (only
  `CameraPanZoom` and two reflection scripts call `0x0a7ee044`).
- `Camera.set_usePhysicalProperties` has exactly one caller, and it is
  Cinemachine, not gameplay.
- `Camera.set_aspect` is never called, so `aspect` is the live backbuffer.

The game's own vertical→horizontal conversion is visible in
`COW.Graphics.GrassSystem::UpdateVisibleCell` @ `0x06c39a50`:

```
atan( tan(fieldOfView * 0.5 * Deg2Rad) * camera.aspect )     // = hFOV/2
```
(`0x18ba7d8` = 0.0174533 = `Deg2Rad`; `0x18baf74` = 57.29578 = `Rad2Deg`.)

So exactly:

```
tanHalfY = tan(30°) = 0.5773503        (fixed, aspect-independent)
tanHalfX = tanHalfY * (viewW / viewH)
```

| aspect | true hFOV | `tan(hFOV/2)` |
|---|---|---|
| 4:3 (1.333) | 75.18° | 0.7698 |
| 16:9 (1.778) | **91.49°** | 1.0264 |
| 19.5:9 (2.167) | 102.72° | 1.2509 |
| 20:9 (2.222) | 104.13° | 1.2830 |

**What was wrong.** `EspRenderView` already implements the HOR+ model correctly
— it derives an implied vertical half-tangent from `FOV_X_DEG` at a 16:9
reference and re-derives horizontal from the real aspect. But the default
`FOV_X_DEG = 90` gave

```
ours : tan(45°) / (16/9) = 0.5625
true : tan(30°)          = 0.57735      →  2.6% too small
```

A **multiplicative** horizontal scale error is ~zero at the crosshair and grows
with angle from centre — precisely the reported "far targets drift right, and it
gets worse with distance".

**Fixed:** `DEF_FOV = 91.49f`, the value satisfying `tan(FOV/2)/(16/9) == tan(30°)`.
`FOV_Y_SCALE = 1.0` was already correct (square pixels).

### Is FOV dynamic? Not for aiming

All 85 callers of `UnityEngine.Camera::set_fieldOfView` (`0x0a7ecefc`) were
enumerated. Gameplay-relevant paths:

| path | trigger | value |
|---|---|---|
| `FollowCamera::OnCameraChanged` / `RefreshState` | camera (re)activated | `C_FOV_NORMAL` = 60 |
| `FollowCamera::SetZoomDest` | grapple, faith jump, cannon, jump pad, catapult, weapon swap | `FovNormal + FOVOffset` |
| `FollowCamera::SetOffestFOV` | space shield | `C_OFFSET_FOV_SKILLSHIELD` = 30 |
| `SkydivingCamera::SetOffset` | glide / skydive / parachute | `ParachuteParam::FOV` (config) |
| `VehicleDriver/PassengerCamera` | vehicles | `Min/MaximumFOV` prefab fields, speed-lerped |
| `ActiveSkillCamera::GetFovNormal` @ `0x07213034` | active skill | GameVar `ActiveSkillCameraFOV` (**server-driven**) |

> **ADS / scope does NOT change FOV.** No aim/sight/scope FOV path exists in
> code outside UGC. `COW.ESightAmplifyRatio` (X1/X2/X4/X8) never reaches a
> camera; `GameVarDef::X1/X2/X4/X8ScopeMaxSetting` are *sensitivity* settings.
> No sprint, prone, crouch or per-weapon FOV change either.

**Caveat, must be tested in game:** a Unity `AnimationClip` animating the
serialized `field of view` property bypasses `set_fieldOfView` entirely and is
invisible to this analysis. If 4x/8x visibly magnifies, that is the remaining
explanation, and it is asset data in a bundle.

### The third-person rig

`FollowCamera::SetOffestRightAndBack` @ **`0x07222344`** rewrites the rig from
static constants on every camera change, so prefab-serialized values never
survive — the code wins. Default branch @ `0x072226a8`:

| slot | constant | value |
|---|---|---|
| `RightOffset` `[inst+0x64]` | `C_OFFSET_RIGHT` | **0.40 m** |
| `BackOffset` `[inst+0x6c]` | `OFFSET_FOR_NORMAL` | **2.50 m** |
| `UpOffset` `[inst+0x68]` | `C_OFFSET_UP` | **−0.05 m** |

Cross-checked three ways: `.ctor` @ `0x072196e8` seeds the same three statics
into the same three slots; `get_OffsetForNormal` @ `0x07222a24` returns
`statics[0x2c]`; and `GetMaxDistanceToTarget` @ `0x07226c88` computes
`sqrt(0.4² + 0.05² + 2.5²) = 2.5323` — which is only meaningful if those three
*are* the rig vector.

**Per-state variants** (same function, other branches):

| state | right | back | up |
|---|---|---|---|
| default | 0.40 | 2.50 | −0.05 |
| camera mode | 0 | 2.50 | 0 |
| vehicle passenger who can fire | 0.60 | 1.50 | 0.40 |
| in catapult | 0.40 | 6.00 | −0.05 |
| in cannon | 0.40 | 1.15 | 0.25 |
| vehicle driver firing | GameVar `+0x4084` | `+0x408c` | `+0x4088` |

Skydive / parachute / sky-surf / on-board read `SkydivingCamera::SetOffset` @
`0x072352cc` from `GameVarDef` — **server-delivered, not in the binary**.

**Spring arm: yes.** `FollowCamera::Start` @ `0x07222204` copies the desired
offsets to `[+0x8c]`/`[+0x98]`; `AHCBLOCABDP` @ `0x07225ca0–0x07225d84` lerps the
*current* back offset toward the desired one at an FPS-revised rate and clamps
it, and `CameraCollisionOffsetBack/Right` confirm a collision trace shortens it.
**Treat 2.50 m as the maximum, not the instantaneous, boom.**

**Fixed:** `DEF_BOOM = 2.50` (was 3.0), `DEF_SHOULDER = −0.40` (was −0.70).
The sign of the shoulder is **not** settled by the binary — the composition sits
behind virtual slots in `AHCBLOCABDP` @ `0x0722519c`. One strafing observation
settles it. Adopt boom + shoulder + FOV **together**: the hand-tuned values had
absorbed part of the FOV error.

### Near clip

`FollowCamera::OnCameraChanged` @ `0x07217914` loads `0x18ba780` = `0x3dcccccd`
= **0.1 m** into `set_nearClipPlane`. At 1000 units/m that is **100 wire units**.
`NEAR_UNITS` was 30 — harmless (it only gates the behind-camera test) but now
matches the game.

### NOT in the binary: the pivot height

The honest negative result.

- `FollowCamera::GetCapSuleOffsetZ` @ `0x072234d4` returns literal `0.0f`.
- `Player::GetCameraReferenceTransform` @ `0x07171054` returns a **Transform
  reference** — a GameObject placed in the prefab — and its only caller is
  `ExecutionSkillCamera`, so it is not the follow pivot anyway.
- `Player::GetCharacterHeight` @ `0x070b4098` returns
  `CharacterController.height`, a **serialized component value**.
- Every float literal in `FollowCamera`'s helpers was scanned: no 1.4/1.5/1.6/1.7
  height constant exists.

> **The pivot is `TargetEntity.position` (the player root/feet) plus a rig
> defined by prefab hierarchy and `CharacterController.height` — Unity
> serialized asset data.** `TPS_PIVOT_H_M = 1.6` must stay an in-game
> measurement, or be lifted from the APK bundles.

---

## 2. The outbound Cmd 2001 send path

### Call chain

```
PNCPKGJGBPP::OPHFNKPJOCI(float,float)          0x078CF588   entity tick, virtual
 └─ PNCPKGJGBPP::EAIKJCCNGMJ(this, Player)     0x078CDD78   (len 0x1640)
      ├─ 0x078CDF04  EFJEIMIIEJO 0x078CDADC → send gate
      │    0x078CDBF4: cnt*0xAAAAAAAB < 0x55555556  ⇒ (cnt % 3) == 0   ← the ~10 Hz throttle
      ├─ 0x078CDF18  Player::IsInVehicle → 2002 / 2006 / 2031 instead
      └─ 0x078CF1D4  GameFacade::Send(0x7D1 = 2001, msg, unreliable)
Serializer: ACDHGKMPIDJ::Serialize 0x047CB4C4   writer GCommon.FastBinaryWriter::Write 0x08291898
```

`Serialize` walks fields in ascending offset order, so **offset order == wire
order**, re-derived field by field.

### Direction v13–v15 — the source, named

```
0x078CEDD4  bl Player::GetAuxAimRotation   0x070E231C
0x078CEE20  ldp s4,s5,[x8,#0x48]           ; Vector3 static_fields
0x078CEE24  ldr s6,[x8,#0x50]              ; => Vector3.forward = (0,0,1)
0x078CEE28  bl Quaternion::op_Multiply
0x078CEE30  bl KANJBNIANHC::JMELIEOFFHJ    0x0577E1D8
0x078CEE38  str x0,[x23,#0x40]!            ; = v13-v15
```

`Vector3.forward` is **proved**, not inferred: `Vector3::get_forward` @
`0x0A82AC78` reads the same class slot at the same static offset `0x48`
(`get_up`=0x18, `get_back`=0x54 corroborate).

`GetAuxAimRotation` = `IsLocalPlayer() ? Player+0x5C4 : Player+0x5B4`. Our own
packet always takes the local branch ⇒ **`Player+0x5C4` (`m_AuxAimRotation`)**.
`GetAimRotation` @ `0x070718A8` = `Player+0x5B4` (`m_AimRotation`), which is the
source of **v3–v5**.

**v13–v15 is a lag-filtered copy of v3–v5.** `Player::GPFMCMHMHKO` @
`0x070739C4`, block `0x07074970–0x07074A70`:

```
if (!Player[+0x5F2])                Aux = Aim
a = |quatDot(Aux, Aim)| clamp 1
if (a > 0.9999990)                  Aux = Aim
if (2*acos(a)*57.29578 <= 0.5°)     Aux = Aim
else Aux = Quaternion.Lerp(Aux, Aim, GetRevisedValueBySystemFPS(Player[+0xDB8]))
```

So **v3–v5 is the un-lagged vector** (shorts ×100, ~0.57° resolution) and may
track better through fast turns, at lower angular resolution. Not currently
decoded — a candidate if camera-turn drift persists.

**What the rotation is:** the look/aim orientation (yaw + pitch), i.e. the
**camera / view forward axis** — not a bone, not the muzzle. Supporting
evidence: `Player::PDOHIMIJJMM` @ `0x070DF034` integrates the look input through
euler + pitch clamp into it; in camera-driven modes `GPFMCMHMHKO` sets it *from*
`get_MyFollowCamera` → `Transform::get_forward` → `Quaternion::LookRotation`; and
`GetWeaponTraceStartPos` @ `0x07071728` computes
`AimStartPos + (m_AimRotation * forward) * MyFollowCamera[+0x6C]`, a camera-boom
compensation that only makes sense if this is the camera axis.

`Player::NMNGKBCINMB` @ `0x070E06BC` decomposes `+0x5C4` to euler, clamps pitch
to **[−90°, +40°]** standing (`0xC2B40000` / `0x42200000`), and feeds the
*flattened* version to `Entity::set_Rotation` — so the **body is derived from the
aim**, not the reverse.

### Handedness — there is no conversion

The packer `KANJBNIANHC::JMELIEOFFHJ` @ `0x0577E1D8` is the entire transform:

```
0x0577E25C  stp s10,s9,[x0,#0x14]   ; .x, .y
0x0577E260  str s8,[x0,#0x1C]       ; .z
```

A plain float32 copy. **No negation, no axis swap, no scale, no per-axis case.**
The wire vector is literally Unity world space: left-handed, Y-up, x/y/z.

> So the 8-way `VIEW_MODE` × `MIRROR_X` search was only ever compensating for a
> **local sign convention in our own renderer**, not for anything the game does.

**The sign trap, now documented in `EspRenderView`:** our right vector is
written as `(-fZ, 0, fX)`, which is the *negation* of Unity's
`cross(up, f) = (fZ, 0, -fX)`, and `MIRROR_X` (default true, `xSign = -1`)
negates it back. The pair is self-cancelling and the net result is correct.
**"Fixing" either half alone silently mirrors the whole ESP.**

Note the camera analysis does **not** kill `VIEW_MODE`: it settles that once the
world frame is genuinely Unity's, no mirror or swap is needed. The wire-axis ↔
Unity-axis mapping lives in the packet decode, not the camera.

### Position v0–v2

```
0x078CE9CC  bl Player::GetSyncStatePos   0x071C3DAC
0x078CE9D4  bl KANJBNIANHC::COGCJKJPPHI  0x0577E298
```

`GetSyncStatePos` default on-foot branch → `GCommon.Entity::get_Position` @
`0x08216BDC` = `Entity.CachedTransform.position`, a plain
`Transform::get_position`. (Team-flight, `IsFlightAsParent` and
`IsSkateboarding` have their own branches.)

`COGCJKJPPHI` per axis: `v += 1.0e-4f` → `v *= 1000.0f` (`0x447A0000`) →
`Math.Round` (banker's) → `(int)`.

> **UNITS_PER_METRE = 1000, confirmed at instruction level. No negation, no swap.**

**It is the root/feet, not the capsule centre.** No centre offset exists anywhere
in the send path, and the game treats that point as the ground reference —
`Player::get_AimStartPostion` @ `0x070E2BB0` *adds* eye height to it:

```
crouching: Entity.Position + up * 0.77f          (const @0x18BA3B4)
standing:  Entity.Position + up * <static+0x1F74>   (runtime config)
swim:      Entity.Position + up * <static+0x770>    (runtime config)
```

So the ESP's ground/feet assumption is **correct**; boxes are not off by half a
character. The standing eye height is a runtime config static — **not**
recoverable from the binary.

### Sampling

Position (`0x078CE9CC`), aim (`0x078CEBD4`) and aux-aim (`0x078CEDD4`) are all
read inside **one synchronous call**, from already-committed fields.

> **Nothing in a 2001 packet is a frame stale relative to anything else in it.**
> The only lag is the `m_AuxAimRotation` lerp described above.

---

## 3. Touch input, sensitivity, and aim assist

### The pipeline

```
Input.GetTouch()
  → UserControlHandler::UpdateSingleAxis        0x082208a4
  → UserControlAxisData
  → Player::UpdateRightAxisAndDoRotation        0x070a4668
  → Player::GPFMCMHMHKO                         0x070739c4
  → Player::GMJBBLKJJBM                         0x070de608   ← the sensitivity pipeline
```

That single 2604-byte function calls every sensitivity getter, the axis delta,
and both aim-assist functions. Output goes to `Player+0x2dc..0x2e4`, returned by
`get_CurFrameRotDeltaEulerAngles` @ `0x07078ae4` as **degrees of Euler rotation
per frame** (pitch negated on the way out, `fneg s1,s10` @ `0x070defb0`).

### The formula, in evaluation order

```
rate   = lerp(LO, HI, sens)                              @0x70dec5c / 0x70dec84
yaw    = clamp(dx/300, -1, +1) * rate                    @0x70debe4 .. 0x70dec74
pitch  = clamp(dy/300, -1, +1) * rate

yaw   *= 1 + 3.0 * |(dirX - dx*0.5) * (326/dpi) * K / 300|    @0x70decf4..0x70ded60
pitch *= 1 + 3.0 * 0.8 * |(dirY - dy*0.5) * (326/dpi) * K / 300|

if finger stationary and |v| > 3.0:  v *= 0.7            @0x70ded64
if scoped:   v *= 0.2 * scopeAttachmentFactor            @0x70dee00
if aim assist engaged: yaw,pitch *= damp; pitch *= yAssistSens  @0x70def08 / 0x70def20
if FPP firing: yaw *= GetFPPFiringDampRadio              @0x70def58
if fast-running: v *= 0.4                                @0x70def98
```

Sourced constants: `300.0f` = `0x43960000` @ `0x70debd0`; `326.0f` =
`0x43a30000` @ `0x70de8bc`; `0.8` @ `0x18ba6cc`, `0.7` @ `0x18ba7e8`,
`0.2` @ `0x18badb4`, `0.4` @ `0x18bace8`.

### px per degree

Sliders return a **normalised 0–1 float** (the UI multiplies for display);
`GameSettingData::GetSensitivity` @ `0x08905e54` defaults to 0.5. `LO`/`HI` come
from `COW.GameVarDef` statics, baked defaults read from its `.cctor` @
`0x06e183b4`:

| static | value |
|---|---|
| `+0x1068` = LO | **15.0** |
| `+0x106c` = HI | **35.0** |
| `+0x1070`/`+0x1074` (alt path) | 10.0 / 20.0 |

```
px_per_deg = 300 / (15 + 20 * sens)        sens = slider/100
```

| sens | px/deg |
|---|---|
| 0 | 20.0 |
| 50 | 12.0 |
| **75** | **10.0** |
| 100 | 8.57 |

> The hand-calibrated `AIM_SWIPE_PX_PER_DEG = 10` lands **exactly** on
> sensitivity 75/100. That is independent corroboration, not curve-fitting.

Shipped as the `GAME SENS` knob: enter the in-game sensitivity and px/deg is
derived; 0 falls back to the manual value.

**Config caveat:** `COWGameEntry::LoadGameVar` @ `0x06d1ab14` ends in
`ConfigDataManager::LoadCSVNoCache`, so 15/35 are compiled-in *fallbacks* and
the shipped values live in APK asset data or a hot-update package.

### Pixels, not DPI — the decisive answer

The delta comes from `Input::GetTouch` / `Touch::get_position` and
`UserControlAxisData::UpdateDirection` @ `0x08221ac4` computes
`current − origin` with **no scaling**. The acceleration term computes
`dirX − dx*0.5`, so delta and direction are provably the same units.

`Screen.dpi` appears **only** in the acceleration term (class global
`0xafef020` = `GCommon.AndroidDisplayMetricsUtil`, `get_DensityDPI` @
`0x08233440`). Therefore:

- **Base px/deg is DPI-independent** — a value tuned on one phone transfers.
- The **acceleration term is DPI-scaled**, so long swipes differ per device.
- The real per-device variable is **render resolution**: `K` is written by
  `SceneGraphicsQuality::ResetScreenSize` @ `0x07d56d50` as
  `nativeWidth / ScreenWidth`. Touch coords live in render-resolution space.

### The acceleration term is a controller bug, not a detail

The trailing term grows with distance from the touch-down point. At ~300 px on a
400 dpi panel the effective sensitivity is about **3.4×**.

> A held-pointer controller with a fixed px/deg that lets its finger wander that
> far **will overshoot badly and blame its own gain**.

Shipped as `MAX TRAVEL` (default 100 px): re-grip once the finger has travelled
that far from where it planted, keeping the response in the linear region.

### AIM ASSIST IS FRICTION, NOT SNAP

`Player::GetAimAssistDampCoefficient` @ **`0x07102a20`**:

```
score = GetHeuristicTargetInfoScore()
damp  = weapon[0x448][0x20] / clamp(score, weapon[0x448][0x28], weapon[0x448][0x2c])
```

applied to yaw *and* pitch @ `0x070def14`; `GetAimAssisYSensitivity` @
`0x07102ad8` then multiplies pitch only. Gated by `HasHeuristicTarget()`.

> **Assist multiplies YOUR rotation down near a target. It never moves the
> crosshair. There is no cone angle anywhere in code.**

A separate snap system exists (`COW.WeaponAimAssistAutoAbsorbData`:
`auto_type, max_range, scale_start/end_distance, scale_param, max_count,
priority_algorithm_space`) but it is a **datatable** loaded from
`INGAME_WEAPON_AIM_ASSIST_AUTOABSORB_CONFIG`.

**This invalidated a shipped design.** The aim controller had
`DEADZONE X = 25 px (~2.5°)` on the premise of "hand off inside FF's assist cone
and let the assist close it". There is no cone, and nothing closes the error
inside a wide deadzone — the aim simply stopped short and waited for help that
never comes. Corrected to **6 px** (matching Y) with **`GAIN X` raised 6 → 12**.
The real consequence of assist is the opposite of a handoff: our authority is
*reduced* exactly when on target.

### Scoping

`× 0.2` (`0x18badb4`) plus a per-attachment factor from
`GetWeaponSightingAttachmentData()` → `[+0xC0]` → `[+0x68]` (`0x070de754`).
Per-scope sensitivities are separate stored 0–1 values via the
`GetScopeSensitivity` 8-way jump table @ `0x0890ca4c`. The 0.2 is recoverable;
the per-attachment factor is datatable data.

### NOT in the binary: the pitch clamp

No pitch-limit constants exist in `Player::LMNGOJOJFNM` (whole 0x2128-byte body
scanned for degree-range literals — zero hits) or in `GameVarDef`. The only
pitch limits in code are `VehicleCameraBase::get_Min/MaxPitchAngle` — **instance
fields, serialized in prefab data**. Must be measured in game.

---

## 4. What changed in the tree

| constant | was | now | source |
|---|---|---|---|
| `DEF_FOV` | 90 | **91.49** | `C_FOV_NORMAL` 60° vertical @ `0x18bfeb0` |
| `DEF_BOOM` | 3.0 | **2.50** | `OFFSET_FOR_NORMAL` @ `0x07222344` |
| `DEF_SHOULDER` | −0.70 | **−0.40** | `C_OFFSET_RIGHT`, same function |
| `NEAR_UNITS` | 30 | **100** | `nearClipPlane` 0.1 m @ `0x07217914` |
| `deadzoneXPx` | 25 | **6** | assist is friction, not a cone |
| `gainXPerSec` | 6 | **12** | same |
| `maxTravelPx` | — | **100** (new) | acceleration term @ `0x70decf4` |
| `AIM_SENSITIVITY` | — | **new knob** | `px_per_deg = 300/(15+20·sens)` |

**Reset the ESP tuning** after taking this build: saved slider values override
the defaults, and the old boom/shoulder had absorbed part of the FOV error.

---

## 5. Still must be measured in game

1. **`TPS_PIVOT_H_M`** — asset data, not in the binary.
2. **Sign of the 0.40 shoulder offset** — one strafing observation.
3. **Overlay vs game viewport** — confirm the overlay's `viewW/viewH` equals the
   game's render aspect and the centres coincide. A display cutout or nav-bar
   inset would produce a second horizontal error with the *same* signature as
   the FOV bug.
4. **Pitch clamp** (min/max look angle).
5. **Shipped sensitivity bounds** — verify 15/35 by sweeping the slider and
   measuring degrees per fixed-length swipe. If px/deg at sens 0.75 measures
   10.0, the CSV matches the baked defaults.
6. **Scope magnification** — if 4x/8x visibly zooms, it is an animated
   `fieldOfView` AnimationClip (asset data).
7. **Instantaneous boom** — 2.50 m is the maximum; collision shortens it.
8. **Render-resolution factor `K`** — test at two graphics-quality settings.

## 6. Doc corrections made

- `docs/IL2CPP_FINDINGS.md` §1 cites `Player::get_EAimAssit` @ `0x074E55AC` and
  `GetAuxAimRotation` @ `0x074E5A24`. **Both are wrong for this image** —
  `rva_map.txt` gives `0x0707F458` and `0x070E231C`. Looks like dump.cs
  contamination (the known Trap 2: `dump.cs` is a *different build*).
- `docs/ESP_RENDERER.md` §2 and §7.4/§8.2 are superseded by §1 here.
