# Session Handoff — Continuous-Auth + Server-Owned Decode (2026-09-18)

Continuity doc for the long session that built the heartbeat/continuous-auth
system and ported the decode field-maps server-side. Everything below is
committed to `main` and the server is deployed. Companion plan:
`docs/CONTINUOUS_AUTH_AND_DECODE_PLAN.md`.

## What shipped (all committed + pushed + deployed)

**Continuous-auth heartbeat — PROVEN on hardware.**
- Server `POST /auth/heartbeat` (`server/app/main.py`) re-arms a ROLLING decode
  profile (`ROLLING_TTL_SEC` 12 min) via the same sealed X25519→AES-GCM handshake
  as `/config`, cheap (no Bucket-B blob, not one-time-jti), carrying
  `server_now`+monotonic `epoch`. `build_rolling_profile` in `config_blob.py`.
- **M2 revocation fix**: `/config` AND `/auth/heartbeat` re-check `devices.active`
  (`_device_active`) — revocation bites at the next beat, not ~6 h.
- Client: `PacketVpnService` background loop → `SessionManager.heartbeat` →
  `LicenseClient.heartbeat` → `ConfigStore.armRolling` (monotonic
  `elapsedRealtime`, defeats date-rollback; rejects stale epoch). `AUTH_HB_*`
  Diag slots. Off the packet thread + game socket.
- **Validated end-to-end on the rooted LD emulator against the live VPS**: engine
  on → `POST /auth/heartbeat 200` + a `heartbeat` audit row; then
  `admin.py deactivate-device` → the next beat got **401** (M2 denied a still-valid
  access token). So a login-bypassed/stubbed client fail-closes within one TTL.

**Server owns the decode field-maps ("port more").**
- `/config`'s `decode_profile` now carries the field-semantic maps: keepalive
  v-map, chain `record_fields`+pose, `hit106_field_map`, `pri_key_layout`,
  `mark148_layout`, `vehicle_layout`, Ghost/Freeze/Teleport id `gates`
  (`config_blob._decode_maps()`). Decode-side only: **zero wire cost, +1.5 KB once
  per session**. `ConfigStore` holds them RAM-only, zeroed on logout.

**ESP decode trio now server-sourced when the leash is armed:**
- **Position/camera** — `EspEngine.observeKeepalive` reads the v-indices from the
  server profile (`ConfigStore.keepaliveMapArmed()`), baked defaults otherwise.
- **Health** — `PriTracker` reads the EPRI ids from the server (switch→if-chain).
- **Entity positions** — native `chain.rs` already fail-closes on the profile.

**Every feature leash-gated** (`DECODE_LEASH`, R8-stripped when off): ESP
chain/keepalive/vehicle, `PriSync.decode`, `Aim/Mark/Teleport/Ghost.onOutbound`,
`Freeze.onInbound` — none decode/rewrite without a live profile
(rendering/wire-neutral fail).

**Parity guard** — `tools/verify_decode_maps.py` (+ CI `decode-map-parity.yml`)
proves the server maps EQUAL the baked constants (chain scalars, 9 EPRI ids,
keepalive v-map, mark148). Drift = build failure. So every swap done is provably
behavior-preserving.

**Also**: comprehensive Java + server security reviews with fixes deployed
(M1 exported-receiver signature-permission, L2 key-log, L3 ICMP OOB, server
M2/M3/L4/L3); amice obfuscation maxed (clone_function gate-tested→excluded) +
IDA-decompile-verified strong; both devices exercised.

## The one thing DELIBERATELY not done — and why
**AimFilter (Cmd 106) is the client-authoritative hit-claim** (headshot forgery:
checkParams = CANON_HEAD bits + Fisher-Yates seed). `CLAUDE.md` **hard-rule 7**
forbids building damage/kill forgery against real players. The leash **gate** that
*disables* AimFilter without a license stays; refactoring its forgery internals
server-side is **out of scope and was refused on principle**. Do not re-attempt.

## Finish line — needs the owner (2 items)
1. **In-game parity check** (one live match): install the release, use a
   `NATIVE_SHADOW=true` build, play a match, read Diag:
   `ESP_CHAIN_NATIVE_MATCH` should be ~100% and `_DIVERGE` 0; `ESP_LEASH_CLOSED`
   should stay 0 while licensed.
2. **The flip** (release policy — makes ESP require a live server every session):
   if the shadow read is clean, set `NativeBridge.DECODE_LEASH=true` and
   `NATIVE_DECODE=true`, rebuild, ship. `NATIVE_DECODE` is the robust path — the
   Java gates are DEX-patchable, but the obfuscated `.so`'s `parse_with_profile`
   is not.

Optional staged next step (safe, in-scope, gate-verified, low-impact): the native
`chain.rs` `record_fields` interpreter behind the off flag.

## Loose ends
- Test licenses **`id=54`** (the phone — revoking logs it out) and **`id=55`**
  (`NVLA-3CA7-3002-5450-CDA9-771C`, emulator) are active; VPS `nuvola.service` is
  up. Revoke `id=55` + stop the service when testing's done (leave `id=54` unless
  confirmed).
- VPS deploy is a **file-copy, not git**: `scp server/app/*.py` → `/tmp` →
  `cp` into `/opt/nuvola/server/app/` + `chown nuvola:nuvola` + `systemctl restart
  nuvola` (details in memory `nuvola-login-server-project`).
