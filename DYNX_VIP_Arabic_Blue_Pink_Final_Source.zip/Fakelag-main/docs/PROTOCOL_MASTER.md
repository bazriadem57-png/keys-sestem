# Free Fire Max — protocol master reference

> **PATHS IN THIS DOC PREDATE THE 2026-09-15 PACKAGE REORG.**
> `core/` is now `tunnel/`, `net/` split into `decode/{frame,crypt,body}` +
> `protocol/`, `overlay/` split into `ui/{render,overlay,panel,button,aim}`.
> See `docs/SOURCE_MAP.md` §2 for the full old-to-new table.

> **Read this first.** It supersedes every earlier doc where they disagree:
> `PROTOCOL_KNOWLEDGE.md`, `captures/REPORT_blob_grammar.md`,
> `captures/REPORT_entity_census.md`, `captures/PROTOCOL_MAP.md`.
> Companion docs: `PROTOCOL_VARINT_DISCOVERY.md` (how the varint framing was
> found), `captures/REPORT_combat_packets.md` (damage feed),
> `captures/REPORT_netcheat_apk.md` (how a competing cheat does it).
>
> Everything here is measured on full-payload captures from 2026-09-10
> (`phone_pull12`, `14`, `15`, `16`, `17`), cross-validated across 3-5 matches.

---

## 1. Frame layout

```
b0        rolling counter
b1        per-packet nonce
b2 .. b7  6-byte per-session XOR mask window
b8 ..     MESSAGE (starts at b8, NOT b12)
```

### 1.1 The mask

A per-session 6-byte XOR applied at b2-b7 only. Identical in both directions
and across all families, constant for the whole session.

**Recovery is free:** OUT len-24 packets decode to all zeros at b2-b7, so the
wire bytes *are* the mask. Take the mode of bytes 2-7 over ~100 such packets
and you have it with 100% confidence.

```python
cnt = [Counter() for _ in range(6)]
for r in packets:
    if r.dir == 'OUT' and r.plen == 24:
        for i in range(6): cnt[i][r.payload[2+i]] += 1
mask = bytes(c.most_common(1)[0][0] for c in cnt)
```

### 1.2 THE ROTATION TRAP — read this before writing any family test

The decoded b2-b7 window holds three 16-bit LE fields:

```
[flags16] [length16] [channel16]      length16 = UDP payload length + 8
```

**They are cyclically rotated by a per-session constant.** The length field's
low byte has been observed at **b3, b4, b5 and b6** across sessions.

> **NEVER identify a packet family using bytes b2-b7.** This single mistake
> has broken the entity tracker twice — a hard-coded `b2==0x00 && b3==0x01`
> test matched *zero* packets in ~5 sessions out of 6, and the ESP went
> silently dark with no error.
>
> **Always key families off b8/b9**, which sit outside the mask window.

To find the rotation when you do need it, scan for the length:

```python
for j in range(2, 8):
    if (wire[j] ^ mask[j-2]) == ((plen + 8) & 0xff):
        length_lo = j    # session constant; confirm over >100 packets
```

### 1.3 b8..b11 is an OBJECT HANDLE, not a connection token

> **CORRECTED 2026-09-10 — see §5.1.** The high field is a **squad index**
> assigned per match (1..14 observed), NOT a binary `1 = own team /
> 2 = enemy` flag, and ids run to 55, not 8. Friend/foe is **relational**:
> an entity is a friend iff its team index equals the one in our own
> keepalive handle. The old absolute rule is exactly inverted whenever our
> own team is not 1.

Earlier docs called this a "connection token". It is the message's first
varint, and for every plaintext game message it is an object handle:

```
handle = (type << 24) | id          always exactly 4 bytes on the wire:
bytes  = (0x80|id) 0x80 0x80 tt     tt = 0x08 own team | 0x10 enemy team
```

* `id` = 1..8, stable for the whole match, **identical to the entity-chain
  record id**
* `type` 1 = own team, 2 = enemy team — **this is the authoritative friend/foe
  source** (see §5)

Consequence: the local player's keepalive is *"any id, own team"*, not a
literal `b8 == 0x81`. `0x81` only ever worked because our own id happened to
be 1 in the first few captures. Correct test:

```
b9 == 0x80 && b10 == 0x80 && b11 == 0x08 && 0x80 <= b8 <= 0xBF
```

---

## 2. Body encoding

The message body is an **untagged LEB128 varint stream** — protobuf-style
varints, but with no field tags: identity is purely positional.

```python
def varints(buf):                 # None if truncated mid-varint
    out, i = [], 0
    while i < len(buf):
        v = s = 0; ok = False
        while i < len(buf):
            c = buf[i]; v |= (c & 0x7f) << s; i += 1; s += 7
            if not (c & 0x80): ok = True; break
            if s > 63: return None
        if not ok: return None
        out.append(v)
    return out
```

### 2.1 ZIGZAG — the second trap

**Numeric fields are zigzag-encoded signed ints (protobuf `sint32`):**

```python
zz = lambda v: (v >> 1) ^ -(v & 1)
```

Reading them raw mirrors the world on whichever axis is currently negative.
This is why the ESP boxes were wrong for a long time and why every
camera-mapping experiment came back ambiguous — we were fitting a rotation to
a reflected coordinate system.

**Proof:** `|zz(v3), zz(v4), zz(v5)|` = 100.000 on **100%** of keepalives in
two full matches (p1 99.37, p50 100.00, p99 100.65). A unit vector scaled by
100. Nothing else explains it.

**Effect:** fraction of nearby enemies within 30° of the view axis (chance
0.167) went 0.226 -> 0.438 (capture 155351) and 0.341 -> 0.480 (161940)
purely from decoding zigzag.

**Encoding is PER FIELD. Do not apply zigzag blindly:**

| Field kind | Encoding |
|---|---|
| positions, velocities, direction triples, damage source | **zigzag** |
| `v13/v14/v15` camera vector | raw **float32 bit patterns** |
| `v22` ms tick, server tick, damage amount | **plain** unsigned |

Read a float field with `struct.unpack('<f', struct.pack('<I', v))[0]`.

---

## 3. OUT keepalive — own state (~10 Hz)

**Select:** `b9==0x80 && b10==0x80 && b11==0x08 && 0x80<=b8<=0xBF`.
Body from **b12** parses to **exactly 23 varints** (3758 ok / 71 bad on a full
match). Our own entity id = `b8 & 0x7F`.

| idx | meaning | encoding |
|---|---|---|
| v0 | world **X** | zigzag |
| v1 | world **height** | zigzag |
| v2 | world **Y** | zigzag |
| v3,v4,v5 | body/movement facing unit vector x100 | zigzag |
| v6,v7 | movement 2-vector (0 when still) | zigzag |
| v8,v9,v10 | velocity triple (matches d(position)) | zigzag |
| v11 | airborne flag 0/1 | plain |
| v12 | state enum (6 values, max 13) | plain |
| **v13,v14,v15** | **camera unit vector** | **float32 bits** |
| v16,v19,v20,v21 | ~always 0 | — |
| v17,v18 | small flags (weapon/loadout-ish) | plain |
| v22 | millisecond tick, +99 per packet | plain |

**Body facing (v3/v4/v5) is NOT the camera.** It tracks the velocity heading
to a median of 0.8°; the camera differs from it by a median of 16.7°
(p90 = 105°). For ESP you must use the float triple.

`|camera| = 1.000000` on 100% of packets — a free integrity check.

---

## 4. IN entity chains — everyone's positions (~2-5 Hz per entity)

**Family:** `b8 == 0x00` and `b9` even, with **`b9 = 2 x record count`**.
Body from **b10** is one flat varint stream.

**Record splitting** — split the *decoded stream*, never raw bytes:

```
a record starts at index i where
    v[i] in 1..8  AND  v[i+1] >= 10000  AND  v[i+2] >= Zmin
record = [id][X][height][Y][trailing state fields...]
```

Use `Zmin = 500`; if that does not reproduce `b9/2` records, retry with
`Zmin = 0` and keep whichever matches. **Never gate on coordinate maxima** —
they are map-specific (one map reaches X 1 394 820 and height 166 214 while
another sits entirely below 40 000). Hard-coded ceilings caused merged records,
~60 phantom entity ids (128, 130 … 254 — mid-varint continuation bytes read as
ids) and million-unit position jumps.

Measured exact-split rate with the adaptive rule: **100.0% / 99.0% / 99.4%**
across three matches.

* Entity ids **1..8**, stable for the whole match (4v4 Clash Squad).
* Record layout = the keepalive layout with a 1-byte id prefix. Long (21-field)
  records carry that entity's **camera vector at slots 14-16** as
  `zigzag(round(100 x camera))` — remote players' aim is visible.
* One id is the **server's echo of the local player**, byte-identical to the
  keepalive at matched timestamps. That is the proof enemy coordinates share
  our exact frame, axes, units and origin — identity mapping, no transform.

---

### 4.1 GAME-MODE PORTABILITY — the fourth trap

**Every roster-sized constant is a mode-specific landmine.** The chain parser
was written against Clash Squad (4v4, 8 players, ids 1-8) and three separate
limits quietly hard-coded that lobby:

| limit | was | effect outside Clash Squad |
|---|---|---|
| entity id ceiling (`MAX_ENTITY_ID`) | 8 | **fatal** — survival ids run to 64; record splitter found nothing |
| declared records per chain | 8 | rejected the large multi-player updates |
| outer packet length gate | 38-170 B | survival chains reach ~630 B; never reached the parser |
| `DecodedDumper.isChain` | `b9 <= 16` | made the DUMPS mode-specific too, so analysis of them was circular |

Symptom: in survival, ghost and freeze worked perfectly (they ride the OUT
keepalive, which is mode-independent) while **ESP and radar went completely
dark**. That split — own-player features fine, entity features dead — is the
fingerprint of a chain-parsing failure, not a mask or session problem.

Measured on survival capture `20260910_221243`, 1639 chain packets, sweeping
the id ceiling:

| ceiling | exact record split | records recovered | max id seen |
|---|---|---|---|
| 8 | 0.0% | 14.7% | 6 |
| 16 | 0.8% | 18.0% | 13 |
| 32 | 0.8% | 33.1% | 26 |
| **64** | **94.8%** | **98.1%** | 64 |
| 127 | 94.9% | 98.1% | 123 |

64 is the knee. Clash Squad regression: 100.0% -> 99.8% on `20260908_205830`,
and 0.0% -> 100.0% on `20260908_105542`.

The `<= 8 records` cap is replaced by an **arithmetic** plausibility test —
`plen >= 10 + declared*4`, since a record is at minimum an id plus three
1-byte varints. Every session contains small (26-42 B) packets with `b8 == 0`
and a `b9` implying 100+ records; those are rejected because they cannot
physically hold the count they declare, not because of an assumed roster.

**Rule for future work: never bound anything by player count.** Bound it by
what the bytes can physically contain, or choose it adaptively per packet.

### 4.2 The keepalive type byte b11 is NOT constant — never test it

A second, independent mode-portability bug, found the same day and with the
same fingerprint (ESP + radar dark, ghost + freeze fine).

The OUT keepalive was identified by `b9==0x80 && b10==0x80 && b11==0x08 &&
0x80<=b8<=0xBF`. `b11` is the object-handle TYPE field, and it is **not
stable**: measured across six sessions it is `0x08`, `0x10` and `0x40` — and
the variation is per SESSION, not per game mode (a Clash Squad match shows
`0x40`). Whenever it differed, **zero** keepalives matched, `ownLastUpdateMs`
never advanced, and `EspRenderView.update()` returned at its staleness check
before drawing anything at all.

| session | b11 | own id | old gate recall |
|---|---|---|---|
| CLASH 150701 / 155351 / 161940 / 173746 | 0x08 | 1 | 100% |
| CLASH 183716 | 0x40 | 11 | **0%** |
| CLASH 205046 | 0x10 | 2 | **0%** |
| SURVIVAL 221243 | 0x68→type 13 | 45 | **0%** |
| SURVIVAL 222258 | 0x30→type 6 | 12 | **0%** |

What IS invariant is the **shape**: an id below 128 zero-padded into a 4-byte
varint, so `b9 == 0x80 && b10 == 0x80` and `b8` carries its continuation bit —
combined with the body being exactly 23 varints, which the decoder already
enforces. That pair scored **100% recall and 100% precision on all six
sessions**, both modes, every observed type byte.

Note the own entity id column: 1, 2, 11, 12, 45. Any `id <= 8` assumption is
wrong here too, and when our own id was not identified the self-echo was drawn
as an enemy.

### 4.3 The record split must be adaptive, not a constant

A fixed id ceiling is wrong in both directions and no single value works:

| session | id<=8 | id<=64 | adaptive |
|---|---|---|---|
| CLASH 150701 | 100.0% | 100.0% | 100.0% |
| CLASH 155351 | 99.0% | 99.1% | 99.1% |
| CLASH 161940 | 99.4% | **87.8%** | 99.4% |
| CLASH 173746 | 40.7% | 39.6% | 42.2% |
| CLASH 183716 | **0.0%** | 100.0% | 100.0% |
| CLASH 205046 | 100.0% | 100.0% | 100.0% |
| SURVIVAL 222258 | **0.0%** | 73.1% | 73.1% |
| SURVIVAL 221243 | **0.0%** | 94.8% | 94.8% |

Raising 8 to 64 fixed survival and broke Clash 161940; the ceiling is a
property of the **session's id assignment**, not of the game mode.

The fix: `b9` is a free per-packet oracle for the correct record count, so try
each `(id ceiling, Z floor)` pair from tightest to loosest and keep the first
that reproduces it. Tightest-first matters — a loose pair can also hit the
count by counting one false start and missing one real record. Adaptive is
best-or-equal on all eight sessions.

### 4.3.1 SOLVED: b8/b9 is a CHANNEL ID for the encrypted transport

Session 173746's 42% had nothing to do with the id ceiling.

**`b8, b9` has two overlapping namespaces.** For an entity chain it means
`(0, 2 x record_count)`. For the ECB-encrypted transport of §6 it is a
**per-session channel id** — and when that channel id happens to be
`(0, even)` the ciphertext is indistinguishable from a chain by header alone.
In 173746 the channel id is `(0, 6)`, so **6 490 ciphertext packets
masqueraded as 3-record chains**. Elsewhere it is `(135,129)`, `(97,113)`,
`(76,39)`, `(215,222)`, `(87,60)` — `b9` odd or `b8` non-zero, so no
collision. 173746's genuine chains split at 100.0%.

It was **corrupting live tracks**, not merely scoring low: 522 phantom records
with ids colliding on real players 4, 7 and 8, X values to 1.06e12.

**The separator is a byte-fit floor of 16 bytes per declared record.** Real
records measure 19.29 B at the floor across eight sessions; the encrypted
cluster 5.33. Selective, not blunt: rejects 91.1% of 173746's collision set
and **0.0%** in five of the other six sessions. Rejecting every `10+8k`-length
packet instead would discard 455/844/838/343 genuine chains elsewhere.

Ciphertext confirmed three independent ways: lengths exactly `10+8k`; varint
validity **50.0%** (a coin flip — a random stream parses iff its last byte has
bit 7 clear); and only 835 distinct first blocks across 6 490 packets.

### 4.3.2 SOLVED: the X gate deleted the aeroplane phase

`X >= 10000` rejected **real** records wherever the lobby sits near map
origin — which is the entire pre-drop plane phase of a survival match, where
X ~ 4 000 and every player shares a Z of ~1 474 m.

Replaced with **`X >= 500`**, chosen on a physical metric rather than split
rate: implied teleports over 100 m summed across eight sessions —
10000 -> 109, 1000 -> 123, **500 -> 139**, 200 -> 165, 100 -> 274, 0 -> 1243.
Clean knee at 500.

Combined effect of 4.3.1 + 4.3.2, with no session regressing:

| session | before | after |
|---|---|---|
| CLASH 150701 | 100.0% | 100.0% |
| CLASH 155351 | 99.1% | 99.9% |
| CLASH 161940 | 100.0% | 100.0% |
| **CLASH 173746** | **41.1%** | **99.1%** |
| CLASH 183716 | 100.0% | 100.0% |
| CLASH 205046 | 100.0% | 100.0% |
| **SURVIVAL 222258** | **73.1%** | **99.8%** |
| SURVIVAL 221243 | 94.8% | 99.6% |

Independent check not used to fit either constant: median implied entity speed
in 222258 falls **17.72 -> 2.82 m/s** while recovering 65% more samples. The
old figure was physically impossible (sprint p90 is 5.8 m/s) — the parser was
reading missing-record gaps as motion.

Residual 0.9% in 173746 is long encrypted survivors. The durable fix is to
**learn** the session's channel id (the `b9` of `10+8k` packets is a
per-session constant — take its mode and reject it), which needs no key and no
b2-b7 access, but needs a warm-up. Details in
`captures/REPORT_chain_split_failures.md`.

---

### 4.3.3 THE BODY DOES NOT START AT A FIXED OFFSET

**Never hard-code the body offset to b12 (keepalive) or b10 (chain).** The
message begins with an object-handle varint at b8, and how many bytes that
takes depends on its value.

Found in a **training / lobby match**, where the local handle is
`0x10000010` (id 16, type 0x10) and therefore needs **five** bytes. Parsing
from a fixed b12 starts in the middle of the handle: the keepalive decodes to
24 varints instead of 23, the exact-count check rejects every one, own
position never updates, and `EspRenderView.update()` bails at its staleness
check — **the entire ESP renders nothing**.

| offset | keepalives accepted |
|---|---|
| fixed b12 | **0 / 190** |
| derived from the handle | **190 / 190** |

All 190 then carry a unit direction vector and a clean ~99 ms tick, so the
decode is unambiguously right.

Same reasoning applies to chains: records start after the *two* leading
varints (the zero handle and the record count). Identical to `off+10` while
both are single bytes, but `b9 == 0x80` (64 records) is a legal two-byte count
that would shift the whole parse by one byte.

Own entity ids observed so far: **1, 2, 11, 12, 16, 45.** Take the id from the
decoded handle (`handle & 0xFFFFFF`), never from `b8 & 0x7f`.

**Regression-verified across all 11 sessions.** Deriving the offset produces a
byte-identical varint stream to the old fixed offset wherever the old one
happened to work (chains 100.0% identical in every session; keepalive
acceptance counts unchanged), and recovers 190/190 where it did not. It is a
strict improvement, not a trade.

### 4.3.4 Training / lobby matches carry NO plaintext entity positions

A 19 s training capture (`20260910_230417`, own player moving ~65 m):

- **0** inbound packets with `b8 == 0` — not a single entity chain.
- **361 / 411** inbound packets have the `10 + 8k` encrypted-transport shape,
  channel id `b9 = 0x35`.
- A strict self-echo scan (every parse offset, every consecutive zigzag pair,
  5 m tolerance) found **0** matches against our own position — and **0** in a
  time-shifted control, so it is not a tolerance artifact.

So in training mode the bots are either simulated client-side or carried
inside the encrypted channel. **A packet-based ESP cannot show them**, and no
amount of parser work will change that without the session key. Own state,
radar self/facing and any genuine networked entity still work once §4.3.3 is
fixed.

Caveat: this is one short capture. A longer one, taken well inside the
training area, would be worth re-checking before treating it as final.

### 4.4 Timing: a hard 198 ms tick, 230 ms stale, velocity in the packet

Measured over ~49 000 inter-arrival samples across six sessions. Full method
and tables in `captures/REPORT_realtime_position.md`.

**The entity broadcast is a hard tick, not a rate:** 198 ms per entity
(5.05 Hz), inter-quartile range **2 ms**, 75% of all gaps in one 25 ms bin.
Every tracked entity arrives inside the same sub-millisecond burst — there is
no per-entity staggering. **Cadence does not degrade with lobby size:** the
median is 198 ms at every concurrency from 1 to 8 live entities.

**Entity data is 230 ms stale on arrival** (per-session 200–260 ms), measured
by cross-correlating the server's echo of our own player against our own
keepalive. Residual at the optimum is 0–6 cm, and the optimum is **sharp**:
half-width 15–35 ms, ~4 units/ms penalty outside it.

**The server does send velocity.** A remote-player (COMPACT, 11–15 varint)
record is `[id][X][height][Y][vx][vz][vy][…]`; the self-echo (FULL21, 21
varint) carries the same triple after its state fields, plus a monotonic
33.0 ms server tick at field 20. Units are displacement per **99 ms sub-tick**
— the median ratio of field to per-record delta is exactly **0.500**, because
a record interval is two sub-ticks. Scale ≈ 10.1 units/s per LSB.

**But do not use it as the estimator.** RMS relative to a naive hold: finite
difference **0.553**, server field at its best scale 0.681, every blend in
between. The field covers one sub-tick so it is noisier. Use it only to *seed*
a newly-seen entity, which the finite difference cannot do from one record.

**There is no faster position channel.** Only `b8 == 0x00` carries
coordinates. Faster inbound families exist (12.36 Hz, 7.97 Hz) but an
exhaustive scan — every consecutive zigzag triple in every inbound packet,
tested against every known player position within ±300 ms at 3 m tolerance —
scored **0 hits** against a 4.6–19.8% chance baseline. They are ECB-encrypted
(entropy 7.60–7.90 vs 4.85–5.11 for plaintext chains; zero near-constant byte
offsets; `len = 10 + 8k` with 37–73% block repetition) and their rate is
uncorrelated with movement (−0.03 to −0.06). **The 198 ms tick is the floor.**

**Extrapolation is worth it and three intuitions about it are wrong.**
Constant-velocity prediction beats holding the last position by RMS ratio
0.573 / 0.622 / 0.679 at one / two / three ticks, and 0.60 end-to-end. But
measured against the data: **smoothing hurts** (latest tick 0.574 beats every
EMA and multi-tick average), **clamping speed hurts** (no clamp 1044 RMS,
every clamp worse — 12.57 m/s players are real), and **capping the horizon
hurts** (no cap 1044, 250 ms cap 1201). Handle staleness by fading confidence
with age, not by truncating the prediction.

Shipped: lead = `record age + 215 ms`, velocity = latest single-tick finite
difference, sample gate dt ∈ [185, 260] ms, teleport reset at |Δ| > 20 000
units, absurdity guard at 13 000 u/s, fade at 260 ms, freeze at 600 ms, drop
at 1 500 ms.

**Staleness is not rare.** 96.6% of gaps are ≤260 ms but they cover only 63%
of wall-clock time; 28.7% of render instants see data older than one second.
At the p99 dropout (1 782 ms) a moving player has travelled a median 7.2 m.
That is why the fade schedule exists.

---

### 4.5 THE ENTITY RECORD IS NOT A PURE VARINT RUN — and it carries POSE

**Bytes 7, 8 and 9 of a remote-player record are FIXED WIDTH.** Varint-decoding
them is wrong and was the reason the "trailing fields" looked like noise.

The giveaway is byte accounting: the trailing region is invariably **7 bytes**
wide while the varint count read out of it varies from 5 to 7. A varint run
cannot do that; a fixed block can. Those bytes often decode as *non-canonical*
(zero-padded) varints — `8a 8a 00` = 1290 where canonical would be 2 bytes —
which the old scanner silently accepted. Control: the self-echo record and the
OUT keepalive contain **zero** non-canonical varints, so this is specific to
the remote record, not a decoder artifact.

```
varint [0]   entity id
varint [1]   X            zigzag
varint [2]   height       zigzag
varint [3]   Y            zigzag
varint [4]   vX           zigzag, units per 99 ms sub-tick
varint [5]   vHeight      zigzag
varint [6]   vY           zigzag
byte   [7]   BODY YAW     u8    <-- FIXED WIDTH
byte   [8]   AIM  YAW     u8    <-- FIXED WIDTH
byte   [9]   AIM PITCH    int8  <-- FIXED WIDTH
varint [10]  movement mode  enum
varint [11]  action state   enum
varint [12]  reserved, 0 in 99.50%
varint [13]  reserved, 0 in 100.00%
```

The **self-echo** record is different: 20 plain varints, no byte block. The
packet then ends with one trailing tick varint — which is the validation:
after `declared` records the remainder must be 1-3 bytes.

Parse rate: **100.00%** in six of ten sessions, 99.77 / 99.82 / 99.45 / 98.85%
in the rest (the residual in 173746 is the known ECB survivors of §4.3.1).
Unlike the heuristic scanner it **never invents phantom ids** — the scanner
produced up to 40 per session.

#### Pose decode

| field | encoding | scale | accuracy |
|---|---|---|---|
| body / leg yaw | u8 | 360/256 = 1.406 deg/LSB | **1.49 deg** median vs own-velocity heading, 90.1% within 5 deg (n=33 754); 2.16 deg vs own keepalive facing |
| aim / head yaw | u8 | 1.406 deg/LSB | **1.44 deg** median vs own keepalive camera; **3.5 deg** median to the victim at damage time (n=1 822) |
| aim pitch | **int8** | ~1.29 deg/LSB, range +/-64 | r = **+0.976** vs own camera pitch at the 230 ms lag, +0.998 at 320 ms |

Yaw 0 points along **+Y** and increases toward **+X** — i.e. `atan2(x, y)`,
with **no offset term**.

```
bodyFwd = ( sin(bodyYaw), 0, cos(bodyYaw) )
aimFwd  = ( cos(pitch)*sin(aimYaw), sin(pitch), cos(pitch)*cos(aimYaw) )
```

**Aim is genuinely independent of body.** |aimYaw - bodyYaw| is p50 4.2 deg but
p90 **113.9** and p99 **173.0** — about 12% of samples have the head and torso
turned more than 90 deg off the legs, matching our own keepalive's
|camera - facing| distribution.

`mode` (varint 10): 0 ground, 1 jump, 2 descending, 4 parachute, 7/19 vehicle
(15.9-18.1 m/s). `state` (varint 11): 0 idle, 1 slow, 2 sprint (p50 5.79 m/s),
8 crawl (tightly clamped 0.59-0.74 m/s), 11 airborne, 5 falling. Both match the
own-keepalive fields v11/v12 (94.4% / 87.2% agreement).

**Crouch and prone do NOT change the transmitted height.** Over 37 543 near-
stationary consecutive pairs, no state transition produces the predicted
-475 u (crouch) or -1235 u (prone) drop; the only significant moves are +465 u
and +403 u, which are jumps. The reported height is the character root.
Posture height must be applied client-side from the state enum.

**Staleness, not resolution, is the accuracy limit.** Over one 198 ms tick aim
yaw already moves p90 **16.9 deg** and body yaw p90 **42.2 deg**; over two
ticks body yaw p90 is 71.7 deg. The 1.4 deg quantisation is irrelevant beside
that.

### 4.6 NO PER-BONE DATA EXISTS — settled, do not re-investigate

**Skeleton ESP with real bones is impossible from packets.** Four independent
lines of evidence:

1. The remote record is **structurally complete**: 14 fields, 99.45-100% exact
   parse over 89 062 records, and two of the 14 are constant zero in 100% of
   samples. There is no unexplained region left to hold bones.
2. **Byte budget:** 20.4-21.3 B per player per update. Fifteen bones at two
   bytes per axis is 90 B minimum. It does not fit.
3. **Exhaustive sweep:** every IN packet, every offset, every consecutive
   zigzag triple, against every known entity root within +/-300 ms — 4 958 671
   candidates. Body-scale offsets (0.2-1.8 m) occur at **0.0214%** against a
   time-shifted chance control of **0.5141%**, i.e. **24x BELOW chance**, and
   not one forms a stable per-entity offset.
4. **No other plaintext family exists.** Everything else from the match server
   is ECB ciphertext (entropy 7.67-7.93, `len = 10+8k`, zero near-constant
   byte offsets). The one fast plaintext-looking family (19-20 Hz) resolves by
   endpoint as **voice traffic from a different server**.

What a reconstructed skeleton can therefore show: a correctly oriented
humanoid — root, velocity, legs on body yaw, torso/head twisted to the aim,
head pitched, and a pose class driving a canned animation. What it cannot:
any limb articulation at all, no lean/peek, no weapon pose, no ragdoll.

## 5. IN damage feed — the authoritative combat channel

**Family:** dir IN; `b8 = 0x80|victim_id`; `b9 = b10 = 0x80`;
`b11 = 0x08` (victim on own team) or `0x10` (enemy); len 23-27.
Varints from **b8** = exactly 8 fields.

| idx | meaning | encoding |
|---|---|---|
| v0 | victim handle `(type<<24)\|id` | plain |
| v1 | **attacker** handle | plain |
| v2 | damage source: >0 weapon, <0 hazard (zone/fall) | zigzag |
| v3 | server tick — **16.500 ms**, 60.60 Hz | plain |
| v4 | flag (0 in 1574/1577) | plain |
| v5 | **DAMAGE in HP** | **plain, not zigzag** |
| v6,v7 | flags | plain |

Counts: 265 / 532 / 565 / 215 events across four matches, **0 on a clean
lobby capture**. Tick rate measured 60.603 and 60.604 Hz.

**Victim vs attacker** was proved geometrically, not assumed: the angle from
the claimed attacker's camera to the victim has a median of **3.8-6.3°**,
versus 28-141° for the reverse assignment. Confirmed a second time using only
remote players' cameras (median 5.9°, 95% under 15°).

**HP = 200.** Accumulating v5 per victim and resetting at >=200 gives exactly
200 as the modal cumulative-at-death. `HP = 200 - sum(damage)` is a **lower
bound** (EP regenerates HP, medkits exist), exact right after a burst.

**Do NOT deduplicate identical consecutive damage messages** — they look like
retransmits but they are individual shotgun pellets; keeping them *increases*
exact-200 lives.

### 5.1 Friend/foe — the handle high field is a SQUAD INDEX

**This was wrong for months and it is the single most important field in an
ESP.** The handle decodes as `(team << 24) | id`, so `b11 = team << 3`. The
high field is a **squad index assigned per match**, not an own/enemy enum.

| session | mode | own (team, id) | b11 | teams | squad sizes |
|---|---|---|---|---|---|
| 150701 | CLASH | t1 / id1 | 0x08 | 2 | 4, 4 |
| 155351 | CLASH | t1 / id1 | 0x08 | 2 | 4, 4 |
| 161940 | CLASH | t1 / id1 | 0x08 | 2 | 4, 4 |
| 173746 | CLASH | t1 / id1 | 0x08 | 2 | 4, 4 |
| 183716 | CLASH | **t8 / id11** | 0x40 | 7 | 1,1,2,3,4,4,4 |
| 205046 | CLASH | **t2 / id2** | 0x10 | 2 | 2, 2 |
| 221243 | SURV | **t13 / id45** | 0x68 | 6 | 1,2,2,3,4,4 |
| 222258 | SURV | **t6 / id12** | 0x30 | 4 | 1,3,3,3 |
| 222646 | SURV | **t2 / id5** | 0x10 | 2 | 4, 4 |
| 225854 | SURV | t1 / id1 | 0x08 | 9 | 1,1,1,1,2,2,2,4,4 |

The old "verified 32/32" used the first four captures, which all happen to put
us on team 1. **This also explains the §4.2 `b11` table** — those values are
simply `team << 3`.

**The correct rule:**

```
friend  <=>  (handle >> 24) == (own keepalive handle >> 24)
```

Evidence it is real: 107 entities with handles, 106 seen twice or more,
**0 ever reported two different teams**. Max squad size **4**, never exceeded.
**99.92%** of damage events are between different teams (2 429 cross-team vs 2
same-team, both tiny splash values). Independent geometric check: squads
derived from the handle travel together — median same-team separation 15.7 m
vs 67.1 m cross-team, **AUC 0.889** from pure co-location, which the handle
never saw.

**Three bugs this replaces**, all measured:

1. `if (tt != 0x08 && tt != 0x10) return;` discarded **20.5%** of all damage
   events and **100% of them in three of ten sessions**, silently disabling
   the authoritative path. `b11` is any non-zero multiple of 8.
2. `victim > 8` / `attacker > 8` / `noteTeam id > 8` — the roster trap of
   §4.1 again, a further 228 events.
3. `type == 1 ? TEAM : ENEMY` — the inversion itself. Where our own team is 2,
   teammates render as enemies and **our own self-echo is drawn as a target**.

Scored over 87 585 chain samples, 10 sessions, both modes:

| classifier | decided | accuracy | friend→enemy | enemy→friend |
|---|---|---|---|---|
| old (shipped until now) | 95.8% | **88.3%** | 8 898 | 918 |
| pure proximity | — | 87.7% | — | — |
| **relational handle + fallbacks** | **92.9%** | **100.000%** | **0** | **0** |

Four sessions scored at or below a coin flip under the old rule (205046
43.9%, 225854 45.4%, 222646 51.2%, 183716 64.0%) — exactly the reported
"inverted and seemingly random".

**Fallback ladder, in priority order** (only while no handle names the id):

1. `id == ownEntityId` → SELF. Available on the **first keepalive**, retiring
   the 40-update self-echo heuristic.
2. **Squad closure** → ENEMY. Once 4 own-team ids are known, everything else
   must be hostile. 71 entities decided this way, **0 wrong**.
3. **Proximity → TEAM only, never ENEMY.** 22 promotions, 0 wrong. Letting it
   call ENEMY raises coverage to 97.4% but costs **1 217 friends painted as
   enemies** — the wrong trade.
4. Otherwise UNKNOWN, drawn in a neutral colour. The residue is 64.1%
   enemies, so a neutral box is still usually a box on a foe.

**A free teammate label:** the small inbound handle-event family (len 15-17,
≤ 4 varints from b8) carries a handle that is own-team in **355/356 = 99.7%**
of cases, and needs no combat — the damage feed's median time-to-first-handle
is 20.2 s.

**No roster packet exists in plaintext.** All 124 333 inbound packets were
scanned at every offset: no packet anywhere contains more than 2 handles, and
every 2-handle packet is a damage event.

**The entity chain carries no team information.** Every trailing varint was
inventoried across record lengths 11/12/13/14/21 over six sessions: the
candidates with low cardinality have 0-59% per-entity stability, and the one
perfectly stable field has exactly one distinct value.



Byte `b11` gives the team directly. Verified against an independent geometric
classifier (proximity-based): **32/32 entities across four matches**. Each team
always has exactly 4 ids.

This replaces the old proximity heuristic entirely — no 40-sample warmup, no
threshold tuning, correct from the first damage event.

---

## 6. What is encrypted, and how

Roughly **54%** of traffic. Two transports, **both ECB with an 8-byte block**
— *not* a stream cipher:

| transport | length rule | header |
|---|---|---|
| "short" OUT/IN (input stream) | `len = 8 + 8k` (24, 32, 40, 48) | 8 bytes |
| "channelled" | `len = 10 + 8k` (26, 34, …, 442) | 10 bytes (`b8,b9` = channel) |

**Proof it is ECB:** in one match, OUT len-24 has 8160 distinct 16-byte
payloads over 8184 packets, but its **first 8-byte block takes only 299
distinct values**. The channelled transport repeats one block up to 526 times,
and the same ciphertext block appears in both directions and at several packet
lengths. The 0.81-0.99 mean consecutive byte-difference looks like a stream
cipher only if you ignore block structure.

**Exploitable without the key — a codebook oracle.** Several specific block0
values co-occur with a damage packet within 15 ms in **100%** of their
appearances (e.g. 19/19, 26/26, 27/27, 67/70 in different captures). These are
the hit-effect messages — floating damage number, blood decal, impact sound —
and they are the most likely home of the **hitzone** and the **impact point**.
block0 differs per capture (session key) and there are several per capture,
consistent with block0 encoding `[msgtype][victim][attacker]`.

### 6.1 What is NOT in plaintext

Exhaustively searched and confirmed absent:

* ~~**HP on the wire**~~ — **RETRACTED 2026-09-13. This was wrong, and being
  wrong in the "read this first" doc cost real time.** Absolute HP *is* on the
  wire: Cmd 1900 `RUDP_VAR_SYNC_PRI_DATA`, property 0 `EPRI_PLAYER_CUR_HP`,
  UInt16, plain varint, 1:1 scale. Measured n=4 662 on confirmed players: min 0,
  max 200, 199 distinct values, none out of range; `CUR_HP == 0` at the death
  notice in 41/43 cases. The original 11 498-slot scan only covered **plaintext**
  families, and Cmd 1900 is reliable and therefore TEA-encrypted — so the search
  could never have found it. See `docs/ESP_HEALTH_AND_NAMES.md`.

  The general lesson worth keeping: "exhaustively searched and confirmed absent"
  is only as strong as the search space. State the space.
* **Bullet impact coordinates** — every decodable packet, three body offsets,
  every consecutive zigzag triple inside map bounds: only own position and
  entity positions exist. Every hit was within 3 m of a known player.
* **Hitzone enum** — five separate hypotheses falsified (see
  `REPORT_combat_packets.md` §6.1). Damage magnitude *is* cleanly bimodal
  (a tail at 4-8x the burst median), consistent with headshots, but the
  geometric confirmation was underpowered (n=9, P=0.51). Current fallback:
  flag a probable headshot when `damage >= 2.5 x median(damage | same
  attacker, same source)` — fires on 4.6% of hits, **unvalidated**.
* **Per-shot fire message** — plaintext OUT traffic is fully accounted for
  (keepalive, a 0.5 Hz tick ping, a 1 Hz RTT probe, a NAT beacon). The trigger
  is inside the encrypted `8+8k` input stream.

---

## 7. Scale and geometry

**~950 game units per metre** (zigzag-decoded units).

Pinned by measuring gravity from airborne frames: **-9313 units/s²**, which at
g = 9.81 m/s² gives 950. Corroborated by a jump apex of 699 units = 0.74 m and
a sprint p90 of 5548 u/s = 5.8 m/s.

> Historical note: 236 came from the superseded fixed-offset decode and was
> wrong by ~7x. 1670 was measured on *raw* (un-zigzagged) values — zigzag
> halves the numeric range, so the same physical scale is ~835-950. Four raw
> estimates (1663, 1678, 1679, 1669) all correspond to ~835 after halving;
> the gravity method gives 950 and is the more direct measurement.

### 7.1 World→screen projection

Free Fire is a **Unity** title and, critically, **THIRD PERSON**. The camera
is not at the player — it orbits on a boom arm behind and above the character.
Projecting from the character's own coordinates makes the whole scene shear as
the view rotates, with error equal to the boom length (worse the closer the
target). This was the long-standing "boxes move when I move my camera" bug.

```
forward = (f32(v13), f32(v14), f32(v15))      # already a unit vector
camera  = player + up*PIVOT_H - forward*BOOM + right*SHOULDER   # over-the-shoulder, not centred
right   = normalize(cross(world_up, forward))
camUp   = cross(forward, right)

d     = target - camera
depth = dot(d, forward)                        # cull if <= near
sx    = w/2 + (dot(d, right) / depth) * (w/2) * K
sy    = h/2 - (dot(d, camUp) / depth) * (h/2) * K
```

**Do not convert the camera vector to yaw/pitch and rebuild it with sin/cos.**
That round-trip is mathematically identical but every sign and quadrant
convention in it is a chance to be wrong. Use the vector directly.

Static analysis of a competing cheat corroborates this: its ESP libraries
import **no libm symbol at all** (no `sinf`/`cosf`/`tanf`/`atan2f` in any of
four ABIs), proving its world→screen is dot products and one divide against a
basis taken straight from the packet, with FOV folded into a single
compile-time scalar. **FOV is therefore one constant `K` to calibrate
empirically, not a matrix to reconstruct.**

**SOLVED 2026-09-10: `right` is mirrored.** `MIRROR_X = true` (equivalently
`right = -right`) is correct and is now the shipped default. This single sign
was the cause of the entire "ESP renders crap" history — with it flipped the
boxes immediately track the right targets along the right path. It was never
recoverable from captures; one toggle in the in-game panel settled it in
seconds. Do not re-derive it, and do not let a future refactor quietly fold it
back into the basis without migrating the saved preference (that would
double-flip and undo it).

### 7.2 The projection is calibrated in game, not from captures

Two of the numbers the transform needs are **not in the stream and never will
be**: the client's FOV and the handedness of the horizontal axes. The server
sends positions and a unit forward vector; it does not send a projection
matrix. Every attempt to recover them statistically from captures produced a
guess wearing a measurement's clothes — the view-axis scoring table
(`EspRenderView.VIEW_MODE`) is the record of that: the best of eight mappings
scored only **1.6× above chance** on the cleaner of two full matches, and the
runner-up was within noise of it. Do not spend another session on it.

They are solved by eye instead, through the in-game panel
(`overlay/EspTunePanel`, persisted by `esp/EspTuning`). Every knob writes
straight into the renderer's volatile statics, so a change lands on the next
frame with the game still running.

**Each knob has a distinct signature, so they can be solved one at a time
rather than searched jointly.** This is the whole reason tuning by eye
converges:

| Symptom | Knob |
|---|---|
| Box on the **wrong side** of the screen | `VIEW_MODE` (8 values), `MIRROR_X` — discrete; no continuous knob fixes it |
| Error ~0 at the crosshair, **grows with angle from centre** | `FOV_X_DEG` (outward = FOV too small) |
| Same but **vertical only** | `FOV_Y_SCALE` (1.0 = square pixels) |
| **Constant** offset, unchanged when you look around | `OFFSET_X_PX` / `OFFSET_Y_PX` (cutout insets, letterboxing) |
| Error **grows as the target gets closer**, swings when you rotate | `TPS_BOOM_M` — the third-person arm |
| **Horizontal** bias that shrinks with distance | `TPS_SHOULDER_M` — the over-the-shoulder camera offset |
| Constant **vertical** offset at all distances | `TPS_PIVOT_H_M` |

The panel shows `EspRenderView.calibHint()` — the nearest tracked enemy's
projected position in normalised screen coordinates (0,0 = crosshair,
±1 = screen edge). **Aim at that enemy: a correct projection reads ~0.00,
0.00.** That turns calibration from "does this look right" into a number to
drive to zero, and it is what makes the order in the table above work.

Solve handedness first (it is discrete), then the constant offsets with the
target centred, then FOV with the target at the screen edge, then boom by
walking toward the target.

---

## 8. Filters — what the server does and does not trust

**Freeze and ghost work because position is client-authoritative.** The server
builds its picture of where you are from what you tell it; withhold your
position reports and it genuinely believes you are elsewhere. Verified: during
FREEZE the server's own echo of us moved in only **4/96** transitions.

**The damage feed is the opposite — inbound and authoritative.** Dropping it
would only stop your own client from learning about damage the server has
already applied. You would show full HP while being dead server-side. It is
useful as *intelligence*, not as a lever.

### 8.1 The ghost range problem and the leash

The server validates your shots from the position it believes you occupy — the
anchor. A **fixed** anchor means the further you walk from your body, the
further off your shots are judged from, until hit registration stops entirely
(range check, or line-of-sight from the anchor through a wall).

Measured on capture 175549: ghost dropped **376/381** position keepalives
(99%), so the anchor really does hold — which is precisely why walking away
breaks hit registration.

**Current behaviour: a fixed anchor**, re-anchored only when the user toggles
ghost off and on. An automatic "leash" (re-anchor once the real body drifts
past N metres) was implemented and then reverted at the user's request — it
trades away the thing ghost is for. If the range problem is revisited, the
measurement to make first is the actual cutoff: ghost, then shoot from
progressively greater distances from the anchor, and read off which shots
registered from the damage feed. That gives a real threshold instead of a
guessed one.

### 8.2 Is hit registration client-authoritative?

Unresolved, and it matters. Large outbound packets (>300 B) precede **39/39
and 76/78** of the damage *we* deal but only 27/226 and 49/487 of damage dealt
by others — a ~9x asymmetry — and lead the server's confirmation by 102-283 ms
(about one RTT). That is consistent with *either* the client claiming hits
(server trusts us — exploitable) or the client reporting the trigger and the
server simulating (not exploitable). The contents are encrypted.

**Decisive experiment:** in a private room, fire ~20 rounds into a wall hitting
nobody, pause, then ~20 rounds into a real player. If the >300 B packets appear
in both bursts it is fire input and there is no lever; if they appear only when
you actually hit someone, the client is claiming hits.

---

## 9. Capture pipeline

**Three dump bugs that will mislead analysis (dump-only; the shipped ESP is
unaffected):**
1. `own_*.csv` `dx/dz/dy/speed_units_per_s` are computed from RAW varints, not
   zigzag-decoded — every speed there is ~2x too large.
2. `varints_*.csv` is unusable for chain packets: `writeVarints` tries offset
   12 before 10, and 12/12 chain rows in every session land on `start=12`,
   i.e. parsed from the middle of the first record's X field. Use
   `entities_*.csv` or the raw capture.
3. `entities_*.csv` `x,z,y` are RAW — apply `zz()` before any analysis.


`DecodedDumper` writes eight files at capture-stop next to the raw dump:
`frames_` (every packet + header decode), `varints_` (every decoded body
field), `own_` (23-field keepalive + derived), `entities_`, `pairs_` (entity
records joined to time-aligned own state), `bytemap_` (per-offset variability),
`unknown_` (full hex of families that never decode), `summary_`.

Raw line format:
`seq ts phase dir decision dip sp dp len type family kind payload_hex`

* `ts` epoch ms; `phase` = `BEFORE` / `FREEZE` / `GHOST` / `FREEZE|GHOST`;
  `decision` = PASS/DROP.
* **Ignore `type`/`family`/`kind`** — an obsolete heuristic classifier. `type`
  is just FIRE/MOVE from a length test and means nothing.

**Pitfalls that have cost whole captures:**

1. **Snapshot once.** The stop path must take `capture.snapshot()` before
   writing the raw file. Starting a new capture while the 6 MB write is in
   flight clears the record list — one capture's raw file had 37 513 records
   while its decoded dump saw 7.
2. **hexLimit.** Payloads must not be clipped. Captures before `phone_pull9`
   used 32 or 64 bytes and cannot be body-parsed at all.
3. **Gradle must not run sandboxed** — a daemon started under the sandbox
   silently discards its writes while still reporting BUILD SUCCESSFUL. Always
   verify the APK's timestamp actually changed.

---

## 10. Open questions

| question | status |
|---|---|
| ~~`right`-vector handedness~~ | **CLOSED 2026-09-10** — mirrored; `MIRROR_X = true` is the default (§7.1) |
| FOV scalar `K` | not transmitted; tune in game via the panel (§7.2), not from captures |
| ~~Hitzone / body part~~ | **CONFIRMED ABSENT 2026-09-10** — the packet is exactly 8 varints consuming every byte with no padding, so no hidden field exists; and damage is continuous per (attacker, weapon), so no headshot multiplier exposes one either. `hitZone()` was reading the server tick 76.5% of the time. Encrypted hit-effect messages remain the only candidate home. |
| Bullet impact point | not in plaintext |
| Per-shot fire message | inside the encrypted input stream |
| Client-authoritative hits? | see §8.2 — one experiment settles it |
| ECB codebook attack | several block0 values map 1:1 to damage events; unexplored |
