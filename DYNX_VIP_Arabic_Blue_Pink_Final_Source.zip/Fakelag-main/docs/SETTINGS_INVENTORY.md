# Settings inventory — what the plugin system has to absorb

Measured 2026-09-16 from `config/Prefs.java` and `config/EspTuning.java`.
This is the input to the plugin refactor: every one of these must keep working,
and **no key string may change** — they are persisted on the user's device.

## The numbers

| | count |
|---|---|
| `Prefs` key constants declared | **99** |
| loaded through `EspTuning`'s central path | **65** |
| read ad-hoc elsewhere (`MainActivity`, `FloatingOverlayService`, services) | **34** |
| public mutable statics on `EspRenderView` | 54 |

Of the 65 centralised loads: 37 float, 28 boolean. Owners:

| owner | keys |
|---|---|
| `ui/render/EspRenderView` | 47 |
| `ui/aim/AimInjector` | 9 |
| `filter/AimFilter` | 6 |
| `esp/EspEngine` | 2 |
| `filter/MarkFilter` | 1 |

## The actual problem

It is not that there are 99 settings. It is that a setting is currently
**declared in four places at once**:

1. a key string in `Prefs`
2. a mutable `public static` on whichever class consumes it
3. a load line in `EspTuning.load()`
4. a save method in `EspTuning`, plus a hand-written row in `EspTunePanel`
   or `activity_main.xml`

Adding one setting means touching all four, and the 34 orphans above are what
happens when someone touches only some of them — those keys have **no load
site in `EspTuning` at all** and are read directly from `SharedPreferences`
wherever they happen to be needed:

```
KEY_ESP_BOXES        esp_boxes          KEY_CROSSHAIR       show_crosshair
KEY_ESP_RADAR        esp_radar          KEY_CROSSHAIR_SIZE  crosshair_size
KEY_ESP_DEBUG        esp_debug          KEY_FLOAT_ALPHA     float_alpha_percent
KEY_ESP_TUNE         esp_tune_panel     KEY_FLOAT_SIZE      float_size_percent
KEY_FREEZE           show_freeze        KEY_CAPTURE_MODE    capture_mode
KEY_GHOST            show_ghost         KEY_DEV_MODE        dev_mode
KEY_TELE             show_tele          KEY_HIT_ZONE        hit_target_zone
KEY_AIM_BUTTON       aim_button         KEY_TARGET_PACKAGE  target_package
… 18 more
```

That divergence is the same failure shape as every other long bug in this
project: **the four declarations drift apart silently.** Nothing fails at
compile time when a setting is saved but never loaded, or loaded but never
shown.

## What a plugin declaration must therefore do

One declaration, four behaviours derived from it:

- the persisted key (**reusing the existing string, verbatim**)
- the typed accessor the hot path reads
- the load/save wiring
- the settings row, generated rather than written

## Non-negotiables for the migration

1. **Key strings are frozen.** All 99 stay exactly as they are. A plugin's
   setting names its key explicitly; it never derives one from a field or
   class name, because any rename silently resets a user's tuning to default.
2. **Hot paths keep direct field access.** `EspRenderView.onDraw` runs at
   120 Hz and `classify()` runs per entity per packet. A plugin setting
   resolves to a plain `static` (or a final field read) at the point of use —
   no map lookup, no reflection, no boxing on those paths.
3. **`esp/` must not import `ui/`.** The plugin registry and the setting
   descriptors live where both can see them: `config/`.
4. **Migration is incremental.** The registry and the old statics coexist;
   a plugin is migrated one at a time and the build stays green throughout.
