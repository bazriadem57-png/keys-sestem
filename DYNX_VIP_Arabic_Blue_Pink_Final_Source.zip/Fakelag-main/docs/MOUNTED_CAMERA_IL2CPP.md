# MOUNTED_CAMERA_IL2CPP — binary answers for the "ESP/radar die in a vehicle" bug

**Binary:** `C:\Users\Tonyt\Documents\FF-RE\bin\libil2cpp_dec.so` (the decrypted image).
Symbolisation via `bin/rva_map.txt`; field layouts via
`tools/il2cpp/ff_message_layouts.json`; cmd→class via
`tools/il2cpp/ff_inbound_registry.tsv`.
All addresses below are **RVAs in `libil2cpp_dec.so`** and were read as raw ARM64,
not decompiled (the shipped IDB has no functions defined; a capstone reader over
the ELF was used instead).

Confidence vocabulary used throughout:
**PROVEN** = read off the instruction stream at the cited address ·
**INFERRED** = follows from structure/naming, not directly executed ·
**UNKNOWN** = not decidable from the image.

---

## 0. The message map this report rests on (all PROVEN)

The repo has been treating "the entity chain" as one thing. It is **two different
commands carrying two different record classes**:

| dir | cmd | message class | UnSerialize | record class | record UnSerialize |
|---|---|---|---|---|---|
| IN | **2001** `UDP_PLAYER_STATE_SYNC` | `message.KGHDCJFHGNP` | `0x049d4d7c` | `message.ALCBKBHIOAJ` (**FULL**) | `0x047cbfcc` |
| IN | **2012** `UDP_PLAYER_STATE_SYNC_V2` | `message.IHLNDLHCGLM` | `0x049d6180` | `message.FLPGKKGLKOG` (**COMPACT**) | `0x047cd560` |
| IN | 2038 `..._WAITINGPHASE` | `message.IHLNDLHCGLM` (same class) | `0x049d6180` | `FLPGKKGLKOG` | — |
| IN | **2002** `UDP_VEHICLE_STATE_SYNC` | `message.CHOIJILECHG` | `0x049d7a94` | `message.OLEOJNOGCCN` | `0x047cee20` |
| IN | **125** `RUDP_GETON_VEHICLE` | `message.JKOLBBEFDIB` | `0x04ac7118` | — | — |
| IN | **126** `RUDP_GETOFF_VEHICLE` | `message.LPIKFAGLDFD` | `0x04ac75d4` | — | — |
| IN | **147** `RUDP_INIT_VEHICLE_STATE` | `message.MLFPDLONONK` | `0x04ac7d4c` | `message.LAAIKOJOOMC` | `0x048a0954` |
| OUT | 2002 | `message.JBECKHDPPOO` | Serialize `0x049d724c` | `OLEOJNOGCCN` | Serialize `0x047cec24` |
| OUT | 2069 | `message.OGHGHMCCKFK` | Serialize `0x049d74e4` | `OLEOJNOGCCN` + aim + ms | — |

### 0.1 Reader primitives — one correction to the repo's table

`GCommon.UDPClientMessageBase::Read*` are interface stubs onto
`GCommon.FastBinaryReader`. Measured bodies:

| API | address | on the wire |
|---|---|---|
| `ReadByte` `0x082bfac4` → `FastBinaryReader::ReadByte` `0x082902fc` | | **one raw byte** |
| `ReadUInt16` `0x082bfaf4` → `FastBinaryReader::ReadUInt16` `0x0828fc6c` | `0x0828fc70` | **`ReadVariant`** — an unsigned LEB128 varint, **not** two raw bytes |
| `ReadInt16` `0x082bfa40` → `0x0828fc4c` | | `ReadVariant` + zigzag |
| `ReadInt32` `0x082bfa6c` → `0x0828fbfc` | | `ReadVariant` + zigzag |
| `ReadUInt32` `0x082bfb20` → `0x0828fba4` | | `ReadVariant` |
| `ReadBoolean` `0x082bfba4` | | one value (varint-class) |

`FastBinaryReader::ReadVariant` is `0x0828fbb4`; the zigzag fold is inline
(`and w8,w0,#1 / neg / lsr x9,x0,#1 / eor`) at `0x0828fc04`.

**Practical consequence:** a C# `ushort` field is a *varint*; a C# `byte` field is
*one raw byte*. This is the same trap as outbound 2002 field 8 — see Q1.2.

---

## Q1 — Does the server publish the LOCAL player in the inbound entity chain while mounted, and does that record still carry pose/aim?

### 1.1 Answer, short

* **The self-echo exists and lives in inbound Cmd 2001, not 2012** — PROVEN.
  Inbound 2001 is a batched list like 2012, and the client **explicitly detects and
  skips its own record** in it (`0x07a293b4`), which is only meaningful if its own
  record is there. Inbound 2012 (the COMPACT chain) is dictionary-keyed on the
  entity byte with no self-exclusion at all (`0x07a284d0`).
* **(a) Whether a *mounted* player is still in either list is a SERVER decision and
  is not decidable from the image.** But the client's own code says it expects the
  answer to be **no** — see 1.4. Confidence: **strong circumstantial, not proof.**
* **(b) The COMPACT record has no aim vector at all** — only three raw pose bytes,
  and they are unconditionally consumed. The FULL record does carry a real aim
  vector. PROVEN — see 1.2/1.3.
* **(c) There is NO per-entity "is mounted" or "vehicle id" field in either record.**
  The one unexplained `ushort` (`LPKKPCBKEBA`) is a **MovePlatform** LevelObject id
  (enum `OPICPDCLKAG`: `MovePlatform = 27`, `Vehicle = 3`) with a second life as a
  UGC/Craftland custom state. PROVEN — see 1.5. This is the single most likely
  thing the repo would have mistaken for a vehicle link; it is not one.

### 1.2 COMPACT record `FLPGKKGLKOG` — exact wire order (PROVEN, `0x047cd560`)

| # | field | read call site | primitive | meaning |
|---|---|---|---|---|
| 0 | `GDKHFHLAIPJ` @+0x11 | `0x047cd5c0` | **raw byte** | entity id |
| 1–3 | `MOEFFAIDCBP` (`PMFGOGFPDHM`) @+0x18 | `0x047c304c` ×3 `ReadInt32` | zigzag varint | X, height, Y |
| 4–6 | `AAPGPMPKMBD` (`BDOPLCJODBN`) @+0x20 | `0x047c2e3c` ×3 `ReadInt16` | zigzag varint | velocity |
| 7 | `GHJHDHNKMMA` @+0x28 | `0x047cd694` | **raw byte** | body yaw |
| 8 | `AGNKNMCBOOE` @+0x29 | `0x047cd6a8` | **raw byte** | aim yaw |
| 9 | `AADHODPAEDJ` @+0x2A | `0x047cd6bc` | **raw byte** | aim pitch |
| 10 | `BGDMAEFKAFK` @+0x2B | `0x047cd6d0` | **raw byte** | movement mode |
| 11 | `LADGDMGAMBG` @+0x2C | `0x047cd6e4` | **raw byte** | action state |
| 12 | `LPKKPCBKEBA` @+0x2E | `0x047cd6f8` | **unsigned varint** | MovePlatform object id / UGC state (see 1.5) |
| 13 | `MNAFFIEBGAD` @+0x30 | `0x047cd70c` | **raw byte** | unidentified |

> **Contradicts `docs/PROTOCOL_MASTER.md` §4.5.** That section says fields `[10]
> movement mode` and `[11] action state` are varints. They are **raw bytes**
> (`UDPClientMessageBase::ReadByte`). Today this parses correctly only because both
> enums happen to be < 0x80; the first value ≥ 0x80 in either field desyncs the rest
> of the record and the whole remainder of the packet — the identical failure mode
> to the outbound-2002 field-8 bug just measured. §4.5 is right that the trailing
> region is fixed-width; it is **six raw bytes plus one varint**, i.e. the fixed
> block is bytes 7–11 (5 bytes) then a varint then one more byte.

### 1.3 FULL record `ALCBKBHIOAJ` — exact wire order (PROVEN, `0x047cbfcc`)

| # | field | primitive | meaning |
|---|---|---|---|
| 0 | `GDKHFHLAIPJ` @+0x11 | raw byte | entity id |
| 1–3 | `MOEFFAIDCBP` @+0x18 | 3 × zigzag varint (`ReadInt32`) | position |
| 4–6 | `LFCNHAJBHEE` @+0x20 (`BDOPLCJODBN`) | 3 × zigzag varint | **body forward vector** |
| 7–8 | `CCLCIJGALBH` @+0x28 (`FOENPKFAEOC`) | 2 × zigzag varint | 2-component pair |
| 9–11 | `AAPGPMPKMBD` @+0x30 | 3 × zigzag varint | velocity |
| 12 | `BGDMAEFKAFK` @+0x38 | raw byte | movement mode |
| 13 | `LADGDMGAMBG` @+0x39 | raw byte | action state |
| 14–16 | `DIPPKFBIILG` @+0x40 | 3 × zigzag varint | **AIM FORWARD vector** |
| 17 | `LPKKPCBKEBA` @+0x48 | unsigned varint | MovePlatform id / UGC state |
| 18 | `MNAFFIEBGAD` @+0x4A | raw byte | unidentified |

**19 values.** `PROTOCOL_MASTER.md` §4.5 calls the self-echo "FULL21 / 20 plain
varints". The class has 19 reads. The discrepancy is unresolved — most likely the
repo's scanner was counting the trailing packet tick and/or the message-level
fields. Flagging it rather than asserting either number.

`PlayerNetwork::PushPlayerSyncedStateData` `0x0735e8b4` converts `LFCNHAJBHEE` and
`DIPPKFBIILG` via `message.KANJBNIANHC::GOEODCJNMPF` (`0x0577e198`, BDOPLCJODBN →
Vector3) and `GCommon.MathUnity::LookRotation` (`0x082314e8`) at `0x0735ea74` and
`0x0735eb34`. **So the FULL record does carry a genuine camera-grade aim vector.**
`PushPlayerSyncedOptimizedStateData` `0x0735cf1c` instead decodes the three pose
*bytes* (`0x0735d0b0`, `0x0735d10c`, `0x0735d154`) via
`message.KANJBNIANHC::JBDCIFPOHLF` (`0x0577d718`) into three
`UnityEngine.Quaternion::AngleAxis` calls and multiplies them.

### 1.4 The strongest evidence on (a): the game suppresses its own lag telemetry while mounted

`COW.GamePlay.PlayerNetwork::KKHPMAEEKFM` @ **`0x0735d2b8`** is called as the first
statement of **both** `PushPlayerSyncedOptimizedStateData` (`0x0735cfe4`) and
`PushPlayerSyncedStateData` (`0x0735e950`). It measures the gap since the previous
state sync for that player and reports it. It contains two guards:

```
0x0735d420   bl  Player::IsInVehicle          ; 0x0706a2ec
0x0735d424   tbnz w0,#0, 0x0735d50c           ; in a vehicle -> skip the
                                              ; NetworkStats::TryPlayerStateSyncBeacon
                                              ; report entirely (0x0735d508)
...
0x0735d53c   bl  Player::IsInVehicle
0x0735d540   tbnz w0,#0, 0x0735d674           ; in a vehicle -> skip
                                              ; UIInGameScene::ShowLagHintPopupMessage
                                              ; (0x079a65c4)
```

**The client treats "this player's state sync has stopped arriving" as normal and
non-reportable precisely when that player is in a vehicle.** That is the game's own
statement that per-player state sync is not expected to continue while mounted.
Confidence: **high that the chain is unreliable/absent for mounted players**;
it is not literal proof that the server omits them.

Supporting structural facts, all PROVEN:

* Outbound 2002 (`0x078ce3ec`–`0x078ce55c`) sends the **vehicle's** ObjectID,
  position, rotation, packed-op and velocity, **and nothing about the player** — no
  player position, no aim. The server therefore has no fresh player pose to echo for
  a car driver; anything it published would be derived from the vehicle.
* Neither applier (`HNNFPNPLGLB` `0x0735d69c`, `PushPlayerSynced*`) has any
  in-vehicle guard on the position write. If the server did keep publishing chain
  records for a mounted player, the client would apply them and fight the seat
  attachment. That argues the server does not.

### 1.5 (c) The only candidate "mount" field is a MovePlatform id — PROVEN

`PlayerNetwork::LFNIHKPENOF` `0x0735cce8` up-converts COMPACT → FULL; the tail at
`0x0735ce8c`–`0x0735cf08` maps `+0x2E→+0x48`, `+0x2B→+0x38`, `+0x2C→+0x39`,
`+0x11→+0x11`, `+0x30→+0x4A`, zeroes `CCLCIJGALBH`, and never fills `DIPPKFBIILG`
(the COMPACT record has no aim vector to fill it from).

Then in `PlayerNetwork::HNNFPNPLGLB` `0x0735d69c`:

```
0x0735d884   ldrh w2, [x21,#0x48]      ; LPKKPCBKEBA
0x0735d888   mov  w1, #0x1b            ; level-object TYPE 27
0x0735d890   bl   NAHFMFGGCDN::DPKIBJDOOLD      ; 0x076c4228  (LevelObjectManager lookup)
0x0735d8d4   ldrh w8, [x21,#0x48] ; if 0 -> skip the whole block
0x0735da0c   bl   Player::ForceEnterMovePlatform ; 0x0718e250
0x0735da1c   bl   Player::ForceExitMovePlatform  ; 0x0710ba64
0x0735d99c   bl   Transform::InverseTransformPoint  ; local offset -> Player+0x1B68..0x1B70
```

Enum `OPICPDCLKAG` (namespace `COW.GamePlay`, 333 members) has **`3 = Vehicle`**,
**`27 = MovePlatform`**, `28 = Train`. The lookup passes **27**, so
`LPKKPCBKEBA` is a *moving platform* object id (train/boat/conveyor), **not** a
vehicle id.

Second use of the same field, in `PushPlayerSyncedOptimizedStateData`:

```
0x0735d264   ldr  x0,[x19,#0x2188]     ; the UGCCustomPlayer, if any
0x0735d270   ldrh w1,[x22,#0x48]
0x0735d278   bl   UGC.UGCCustomPlayer::SetCustomPlayerState   ; 0x06d6b860
```

and the MovePlatform branch is skipped when that UGC object exists
(`0x0735d838 cbnz → 0x0735daf0`) or when the record is the local player's
(`0x0735d848 IsLocalPlayer`). So `LPKKPCBKEBA` is **dual-purpose: MovePlatform id
in normal modes, UGC custom state in Craftland**. That fully explains
`PROTOCOL_MASTER.md`'s measured "0 in 99.50 %".

`MNAFFIEBGAD` (+0x30 / +0x4A) is copied to shadow-state `+0xB4` at `0x0735d81c`;
its consumer was not traced. **UNKNOWN.**

### 1.6 Bonus, and it is the most immediately useful thing in this document

**`chainEntityByte == (PlayerID & 0xFF)`.** PROVEN.

`COW.GamePlay.BHGGAEEHJCO::LMCLIKOCCJM(uint packed)` @ **`0x07c49ca4`** is the
PlayerID unpacker; its non-patched body at `0x07c49cfc` is:

```
lsr  w8, w20, #0x18        ; teamByte  = packed >> 24        -> struct+0x08
and  w9, w20, #0xffffff    ; slot24    = packed & 0x00FFFFFF -> struct+0x04
strb w20, [x19,#9]         ; low byte  = packed & 0xFF       -> struct+0x09
lsl  x8, x10, x20          ; bitmask   = 1 << (packed & 63)  -> struct+0x10
stp  w20, w9, [x19]        ; packed                          -> struct+0x00
```

and `COW.GamePlay.BHGGAEEHJCO::FJDKADFHAAE(PlayerID*)` @ **`0x07c5e100`** is a
one-instruction accessor: `ldrb w0,[x19,#9]` — i.e. **the low byte of the packed
PlayerID**.

The inbound-2001 handler uses exactly that to find its own echo:

```
0x07a29380  bl  GameFacade::CurrentLocalPlayerID   ; 0x07541440
0x07a293ac  bl  BHGGAEEHJCO::FJDKADFHAAE           ; -> my chain byte
0x07a293b4  ldrb w8,[x21,#0x11]                    ; record entity id
0x07a293b8  cmp  w8, w0, uxtb
0x07a293bc  b.eq -> continue                        ; skip my own record
```

Check against today's capture: PlayerID `167772177 = 0x0A000011` ⇒ team `0x0A`,
chain entity byte `0x11 = 17`. **The tool can join Cmd 125/126/101/147 PlayerIDs to
chain entity ids with one AND — no Cmd 118 lookup needed for the identity link.**
The `1 << packed` mask implies slot < 64, so the low byte never truncates a real
slot.

Note the guard: the self-skip only runs when the message-level bool
`IDNHFFFKDFB` is **false** (`0x07a29364 tbnz w22,#0`). When it is true the client
*does* apply its own record — that bool is the force-resync flag.

### 1.7 Verdict for the tool's design

**The self-echo camera fallback is not viable while driving a car**, on two
independent grounds:

1. Even if the server does publish us, the COMPACT record has no aim vector, and
   the aim/body yaw bytes it does carry can only have been derived from data the
   client never sent (2002 has no aim), so they are at best the vehicle's heading.
2. The client's own lag telemetry declares the mounted state-sync gap normal
   (`0x0735d420`, `0x0735d53c`).

On a **horse that is emitting 2069**, the aim vector is first-hand in the outbound
packet and no echo is needed. On a **horse emitting 2002**, the same negative as
the car applies.

### 1.8 The capture that would settle (a) definitively

Offline, from captures the repo already has — no new play needed:

1. Find an inbound Cmd **125** and take `INCOILICADJ.BHGGAEEHJCO` (uint).
2. Compute `chainId = playerId & 0xFF`.
3. Scan inbound **2012** (and **2001**) records for that `chainId` in the window
   between that 125 and the matching **126**.
   *Absent* ⇒ the server drops mounted players from the chain.
   *Present but with position equal to the vehicle's inbound-2002 position* ⇒ the
   server derives it from the vehicle; pose bytes are then vehicle-derived.
   *Present and independent* ⇒ the echo is live and §1.7(1) is wrong.

A new capture is only needed if no existing capture contains a 125/126 pair with a
decoded body.

---

## Q2 — Horse in BR vs CS: 2069 or 2002?

### 2.1 The dispatch tree, re-read instruction by instruction (all PROVEN)

`COW.GamePlay.PNCPKGJGBPP::EAIKJCCNGMJ` spans **`0x078cdd78`–`0x078cf3b8`**.

```
0x078cdf04  EFJEIMIIEJO()                      ; cadence gate -> false: silent skip
0x078cdf18  Player::IsInVehicle()              ; false -> 0x078cdfd4 (catapult/cannon/chair/foot)
0x078cdf28  Player::IsPassengerInVehicleCanFire()  ; true -> KOEDKEJGCEP/JGGMLMNCMAA
0x078ce0d8  Player::IsVehicleSupportDriverWeaponFire()   -> w22
0x078ce0e8  Player::GetVehicleIAmIn()                    -> x21
0x078ce0f0  tbz w22,#0 -> 0x078ce3ec                     ; NOT fire-capable -> the 2002 branch
            ;  ---- 2069 branch ----
0x078ce100  Vehicle::IsLocalAuth()      false -> 0x078ce8cc   ** SILENT SKIP, sends NOTHING **
0x078ce110  Player::get_WaitForForceSync()  true -> 0x078ce8cc ** SILENT SKIP **
0x078ce14c  Player::GetAimRotation()  -> Quaternion::op_Multiply -> DIPPKFBIILG
0x078ce2e0  mov w0,#0x815                                  ; 2069
            ;  ---- 2002 branch ----
0x078ce3f4  Player::get_IsDriver()      false -> 0x078ce688 ; passenger, mov w0,#0x7d6 (2006) @0x078ce8b4
0x078ce408  Vehicle::IsLocalAuth()      false -> 0x078ce8cc ** SILENT SKIP **
0x078ce418  Player::get_WaitForForceSync()  true -> 0x078ce8cc ** SILENT SKIP **
0x078ce558  mov w0,#0x7d2                                  ; 2002
0x078ce684  b GameFacade::Send(w0=msgid, x1=msg, 0,0,0)    ; 0x075488ac, shared tail
0x078ce8cc  plain epilogue — no Send
```

Other leaves: catapult `mov w0,#0x7df` (2015) `0x078ce0c8`; cannon `mov w0,#0x7ef`
(2031) `0x078ce3e4`; chair `mov w0,#0x7e0` (2016) `0x078ce644`; on-foot path begins
`0x078ce8fc` (and its own `WaitForForceSync` silent skip at `0x078ce908`).

**Answer to "can anything else route a firing-capable driver to 2002": NO.**
`IsVehicleSupportDriverWeaponFire` is the sole discriminator between the 2069 and
2002 branches. The other conditions (`IsLocalAuth`, `WaitForForceSync`) route to
**silence**, not to 2002. Confidence: PROVEN.

### 2.2 What `IsVehicleSupportDriverWeaponFire` actually tests (PROVEN, `0x07083924`)

```
0x070839c0  GameFacade::CurrentGameModeSetting()   ; 0x0753969c ; null -> false
0x070839c8  ldrb w8,[x0,#0x23]                     ; EnableVehicleDriverWeaponFire
0x070839cc  cbz  w8 -> 0x07083aac (return false)
0x070839f8  Object::op_Inequality(this->+0x8b0)    ; vehicle != null, else false
0x07083a10  Vehicle::get_Driver()                  ; 0x07f9fe94
0x07083a7c  BHGGAEEHJCO::EEOFJDHOLBP(driver, myPlayerID)  ; 0x07c4b84c ; driver must be me
0x07083aa4  blr [vtable+0xac8]                     ; Vehicle::CanDriverFire()  <- the answer
```

`COW.GamePlay.Vehicle::CanDriverFire` @ `0x07fc2d38` **returns 0**
(`0x07fc2d70 mov w0,wzr`). `COW.GamePlay.MountableAnimal::CanDriverFire` @
`0x0758f4c4` is the **only** override in the image (the only other symbol is the
IFix base proxy `0x07591c0c`):

```
0x0758f50c  Vehicle::GetVehicleData()   ; 0x07fad55c -> plain `ldr x0,[this,#0x1E0]`
0x0758f514  ldrb w0,[x0,#0x59]
```

`COW.MiniMapVehicleHorse::IsMountableAni` (`0x05c441bc`) confirms the horse is a
`MountableAnimal`. So:

* **A car is always 2002, in every mode.** Its `CanDriverFire()` is the base
  `return false`. PROVEN. No capture can change this.
* **A horse is 2069 iff** `EnableVehicleDriverWeaponFire` is on for the mode **and**
  the horse's config byte `+0x59` is 1 **and** `Vehicle::IsLocalAuth()` **and**
  `!WaitForForceSync`.

### 2.3 Where those two flags come from — both are DATA, not code

**`GameModeSetting.EnableVehicleDriverWeaponFire` (+0x23):**

* Compile-time **default is TRUE**: `COW.GameModeSetting::.ctor` `0x06f088ec` does
  `mov w28,#1` at `0x06f08c98` and `strb w28,[x19,#0x23]` at **`0x06f08cfc`**.
  (This is the only store to +0x23 anywhere in the image.)
* Runtime value comes from a **CSV**: `GameModeSettingManager::LoadModeSetting`
  `0x06f0a1a4` → `GCommon.ConfigDataManager::LoadCSVNoCache` `0x08238ba4`, keyed by
  `GetModeSettingKey(GameServerMapID, GameServerGameMode)` (`0x06f0a6b4`,
  `0x07539dd4`, `0x07539e54`).
* And the **server can overwrite it at runtime**:
  `GameModeSettingManager::OverwriteKeyValueList` `0x06f0b1e8` →
  `PostSetGameModeSetting` `0x06f0a72c` → a `GameModeSettingOverwriteFinish` event.

**The horse's `vehicleData->byte@0x59`:**

* `Vehicle::SetVehicleData` `0x07fad5ec` stores the object into `+0x1E0`.
* The only producer is `LevelVehicle::SetVehicleData` `0x077ee868`, which calls
  `COW.VehicleConfigDataManager::GetConfigData` **`0x06c1acb0`** with
  `GameFacade::get_GameServerMapID` (`0x07539dd4`) and
  `get_GameServerGameMode` (`0x07539e54`).
* `VehicleConfigDataManager::LoadAndStoreConfigData` `0x06c1aec0` /
  `0x06c1b224` resolve it through **`GCommon.ResourceManager::GetResourceIDByName`
  `0x08325bb4`** and **`GetResource` `0x083204bc`** — i.e. an **asset bundle**.

> **Verdict, stated plainly as requested: the horse's driver-fire flag is
> asset/config data, keyed by map id and game mode, and is NOT in `libil2cpp.so`.
> It is unknowable from the binary.** The mode flag is likewise CSV + server
> overwrite; only its *default* (true) is a code constant.
> This **confirms** `docs/VEHICLE_PARSE_SPEC.md` §10.1's two "rests on a CSV flag
> that is NOT in the binary" rows and upgrades them from suspicion to proof, and it
> adds the specific loader addresses so the values can be pulled from the APK
> bundles or read at runtime.

### 2.4 Why today's capture saw 137 × 2002 and 0 × 2069

Consistent with all of the above without needing the config:

* If the user rode a **car**, 2002 is the only possible outcome. PROVEN.
* If a **horse** and still 2002, then one of: the mode CSV/overwrite turned
  `EnableVehicleDriverWeaponFire` off for BR/CS, or that horse's config byte is 0.
  INFERRED; not separable from the binary.

**Capture that separates them (60 s):** mount a horse in `MODE_FULL`/`MODE_MATCH`
(not `MODE_COMBAT` — `Cmd.isOwnPositionCarrier` omits 2069) and log the msgid.
Then repeat in the other mode. Two runs answer both halves. If the horse also emits
2002, the answer to "can we ever get aim while mounted" is **no, in any vehicle**.

### 2.5 Two silent skips that likely contribute to the user's bug

`Vehicle::IsLocalAuth()` false or `Player::get_WaitForForceSync()` true ⇒
**the dispatcher returns without sending anything at all** (`0x078ce8cc`). Both
conditions are live right after mounting and after any authority handoff
(Cmd 186 `RUDP_VEHICLE_CHANGE_AUTH`, class `LLANHGLPCDL`). During those windows
there is no outbound own-position carrier of any kind — not 2001, not 2002, not
2069. Any tool logic that says "2001 stopped, so read 2002" will still see nothing.
This matches the repo's standing lesson that the recurring failure is a silent skip
one layer upstream.

---

## Q3 — What supplies the camera basis client-side while mounted?

**Answer: the FollowCamera's own transform. It exists the whole time, and on the
2002 path it is never serialised. This is a definitive negative.** PROVEN.

### 3.1 The aim rotation is a plain Player field, and the camera drives it

* `COW.GamePlay.Player::GetAimRotation` **`0x070718a8`** is nothing but four loads:
  `ldr s0,[x19,#0x5b4] / s1,#0x5b8 / s2,#0x5bc / s3,#0x5c0` (`0x070718e0`).
  The look rotation is a `Quaternion` at **`Player+0x5B4`**.
* `Player::SetAimRotation` `0x07081b68` writes it (`0x07081c84`) or tail-calls
  `Player::BOFEIBOLHEC` `0x0707e9a4`, which also writes it (`0x0707ea50`).
* The **per-frame producer** is `COW.GamePlay.Player::GPFMCMHMHKO` `0x070739c4`:

```
0x070741ec  Player::get_MyFollowCamera     ; 0x0707fb60
0x070741f8  Component::get_transform
0x07074204  Transform::get_forward
0x0707420c  MathUnity::Vector3ZeroY        ; 0x082239d8
0x07074300  Quaternion::LookRotation
0x0707430c  Player::BOFEIBOLHEC            ; -> Player+0x5B4
```

So the camera is authoritative and the player's aim follows it, not the reverse.

### 3.2 The camera stays attached and merely changes rig while mounted

`Player::OnGetOnVehicle` `0x0710a8ac` calls `get_MyFollowCamera` (`0x0710af48`,
`0x0710af84`) and `COW.GamePlay.FollowCamera::SetOffestRightAndBack` **`0x0710af90`
→ `0x07222344`** — the same function `docs/GAME_CLIENT_CONSTANTS.md`
§"The third-person rig" already documents, which has explicit
*vehicle-passenger-who-can-fire*, *catapult*, *cannon* and *vehicle-driver-firing*
branches. `Player::OnGetOffVehicle` `0x0710e1ec` restores the aim quaternion
directly (`0x0710e6c4` writes `+0x5b4`..`+0x5c0`, then
`Quaternion::Internal_FromEulerRad` into `+0x5c4`..`+0x5d0`).

Independent confirmation that aim is live while mounted:
`COW.GamePlay.Player::TryGetHorseAutoDriveSteerByAim` calls `GetAimRotation` at
`0x07184a90`, and `COW.UIHudCrosshairsController::FrameTick` at `0x04ef4328` /
`0x04ef9034`.

### 3.3 Which outbound paths serialise it

| path | `GetAimRotation` call | serialised field |
|---|---|---|
| **2001** (on foot) | **`0x078cebd4`** (+ `GetAuxAimRotation` `0x078cedd4`) | yes |
| **2069** (driver who can fire) | **`0x078ce14c`** | `DIPPKFBIILG` |
| **2016** (chair) | **`0x078ce59c`** | yes |
| 2006 / 2015 / 2031 | present on their branches | yes |
| **2002 (ordinary driver)** | **NONE anywhere in `0x078ce3ec`–`0x078ce55c`** | **no** |

The 2002 branch builds `OLEOJNOGCCN` exclusively from the *vehicle*:
`BaseLevelObject::GetObjectID([vehicle+0x120])` `0x078ce480`,
`Entity::get_Position(vehicle)` `0x078ce498`,
`Entity::get_Rotation(vehicle)` `0x078ce4c4`,
`PNCPKGJGBPP::INCBJGDHGOA(vehicle)` `0x078ce4e8` (velocity), and the packed-op
virtual `blr [vehicle_vtable+0x8a8]` `0x078ce528` stored with **`strb`**
(`0x078ce530`) — independently re-confirming today's one-raw-byte measurement of
field 8 and **contradicting `docs/VEHICLE_DISPATCH_MAP.md` §3.5**, in agreement
with `docs/CMD_2002_VEHICLE_LAYOUT.md` §3.2.

### 3.4 Consequence

**No amount of packet parsing can recover the camera basis while driving a car.**
The information is never transmitted in any direction. The only options are:

1. Freeze the camera at its last on-foot value and mark it stale (honest).
2. Substitute the **vehicle's quaternion** from outbound 2002 fields 4–7 as a *body*
   heading and accept that the player's head/camera yaw is unknown — acceptable for
   a **radar** (which only needs relative bearings from our position) but wrong for
   a screen-space ESP box projection.
3. Disable screen-space ESP while `mounted && lastCarrier == 2002` and keep the
   radar alive off the vehicle position. This is the only correct behaviour.

Confidence: **PROVEN** for "never sent"; the mitigation choice is engineering.

---

## Q4 — Cmd 125 / Cmd 126 layouts

Both **PROVEN** from the deserialisers, and both match today's capture exactly.

### 4.1 Cmd 125 `RUDP_GETON_VEHICLE` — `message.JKOLBBEFDIB`, `0x04ac7118`

| # | field | primitive | call site | capture | meaning |
|---|---|---|---|---|---|
| 0 | `FAAMLGOPLAC` (ushort) | **varint** `ReadUInt16` | `0x04ac716c` | 34 | **VehicleID** — confirmed by name: `ff_deobfuscation_map.json` maps `FAAMLGOPLAC → "VehicleID"` |
| 1 | `INCOILICADJ.BHGGAEEHJCO` (uint) | **varint** `ReadUInt32` | `0x048a05a0` | 167772177 | **packed PlayerID** of the rider (`0x0A000011`) |
| 2 | `INCOILICADJ.AENCMNOFNKN` (byte) | **raw byte** | `0x048a05b4` | 0 | **seat index** — passed as `w3` to the mount event at `0x07a418c0`/`0x07a418dc` |
| 3 | `OKIMMBDNKOC` (uint) | **varint** `ReadUInt32` | `0x04ac71e8` | 908036004 | **vehicle skin item id** (INFERRED, see below) |
| 4 | `FLONCGDLDKA` (bool) | boolean | `0x04ac71fc` | 0 | flag; read at `0x07a41940` next to `GameFacade::IsMetropolisMode` `0x0754ecac`. UNKNOWN. |

`INCOILICADJ` is a nested `message.ONMHJGMIJGM` (`UnSerialize 0x048a058c`) —
a `{uint playerId, byte seat}` pair, the same struct used by Cmd 187
`RUDP_VEHICLE_CHANGE_SEAT` (twice: from-seat and to-seat) and by the Cmd 147
occupant list.

**On `v3 = 908036004`:** INFERRED, not proven. The field name `OKIMMBDNKOC` appears
in exactly the messages you would expect a skin id in — `950
RUDP_SWITCH_WEAPON_SKIN` (`OMDLIEJHMHM`), `469 RUDP_S2C_SET_COLLECTION_SKIN`
(`KLKBNANMCLO`), `107 RUDP_DEAD` (`DOENGLMMFID`), `139 RUDP_KNOCK_DOWN`
(`FKEKGMFJALP`) — and 908036004 sits squarely in Free Fire's 9-digit item-id space.
The de-obfuscation table also carries `JPILFCBIPLH → VehicleSkinID` for the
lobby-side name. In the handler it is forwarded verbatim as `w4` into the mount
event payload (`0x07a418b4`, stored to event `+0x34` at `0x077fcb8c`), which is
consistent with cosmetic data and inconsistent with a tick. **To settle it:** mount
the same vehicle twice with two different vehicle skins equipped and diff the field.

### 4.2 Cmd 126 `RUDP_GETOFF_VEHICLE` — `message.LPIKFAGLDFD`, `0x04ac75d4`

| # | field | primitive | call site | meaning |
|---|---|---|---|---|
| 0 | `FAAMLGOPLAC` (ushort) | varint | `0x04ac75e8` | VehicleID |
| 1 | `BHGGAEEHJCO` (uint) | varint | `0x04ac75fc` | packed PlayerID of the dismounting rider |
| 2 | `DNNFOOGPFHO` (uint) | varint | `0x04ac7610` | server tick |

Exactly the capture's `VehicleID=34, entityId=167772177, tick=…`. Note 126 has **no
seat byte** — dismount needs only the player.

### 4.3 Broadcast for all players, or only local?

**Broadcast for all players in scope.** PROVEN by the handlers:

* 125 handler `FFMOIGKIEPE::CBOJPDICJNA` `0x07a41724` resolves an **arbitrary**
  PlayerID (`BHGGAEEHJCO::LMCLIKOCCJM` `0x07c49ca4` at `0x07a41894`) and the
  VehicleID through `GameFacade::CurrentLevelObjectManager` `0x0753f328`, then fires
  a global mount event (`LOBCKAJGCAC::BLJEIAHKEPL` `0x077fcaf8`) and a 3-D
  positional sound (`AudioManager::Play3DShot` `0x081dc6fc` at `0x07a41a6c`) at the
  vehicle's position — meaningless for a local-only message.
* 126 handler `FFMOIGKIEPE::NHCGGCAAMLM` `0x07a41a9c` resolves the PlayerID, looks
  the `Player` up via `EMKJHAJNPDH::ADNMDEDAEGN` `0x0725ed14`, and then *branches on*
  `Player::IsLocalPlayer` `0x07064838` at `0x07a41c30` — a branch that only exists
  because the message is usually about someone else.

### 4.4 Why this matters to the tool

Combined with §1.6 (`chainId = playerId & 0xFF`), Cmd 125/126 give an authoritative,
reliable, per-player mount state machine:

```
on 125: mounted[playerId & 0xFF] = { vehicleId = FAAMLGOPLAC, seat = AENCMNOFNKN }
on 126: mounted[playerId & 0xFF] = none
```

and for **our own** player, `playerId == CurrentLocalPlayerID` is the ground-truth
mount/dismount edge the tool currently infers from "2001 stopped arriving".

---

## Q5 — Inbound Cmd 2002: class, record layout, and whether `id` is a vehicle or a player

### 5.1 Class and layout — PROVEN, and the capture matches field for field

`message.CHOIJILECHG`, `UnSerialize` **`0x049d7a94`**, handler
`FFMOIGKIEPE::JFLKBFKJICO` `0x07a2a48c`.

```
ReadInt16                      -> record count (zigzag varint)   0x049d7b18
count × OLEOJNOGCCN            -> OGNIOAAHLEN (+0x18)
ReadBoolean                    -> IDNHFFFKDFB (+0x20)            0x049d7c80
ReadUInt32                     -> DNNFOOGPFHO (+0x24)            0x049d7c98
```

Each record is **the exact same class as the outbound 2002 inner object**,
`message.OLEOJNOGCCN` (`UnSerialize 0x047cee20`, `Serialize 0x047cec24`):

| # | field | primitive | meaning |
|---|---|---|---|
| 0 | `FAAMLGOPLAC` uint | varint | **VehicleID** |
| 1–3 | `MOEFFAIDCBP` (`PMFGOGFPDHM`) | 3 × zigzag varint | position, mm |
| 4–7 | `LFCNHAJBHEE` (`BJIPILEFOGL`) | 4 × zigzag varint | quaternion ÷1000 |
| 8 | `JBOGMCKPKLJ` byte | **one raw byte** | `GetCurrentPackedOp` |
| 9–11 | `AAPGPMPKMBD` (`BDOPLCJODBN`) | 3 × zigzag varint | velocity, cm/s |

So the capture's `{id, pos.x, pos.y, pos.z, quat.x..w, op=8, vel.x..z} × N`, then
`v12=1`, `v13=tick` is **exactly** `IDNHFFFKDFB` and `DNNFOOGPFHO`.

* **`v12` / `IDNHFFFKDFB`** is the same field name as inbound 2001's trailing bool
  (`KGHDCJFHGNP+0x20`), where it is the **force-apply / resync flag** that makes the
  client stop skipping its own record (§1.6). In 2002 its consumer is read at
  `0x07a2a5d0` (`ldrb w24,[x19,#0x20]`) and carried through the per-record loop.
  Best reading: **"this is an authoritative snapshot, apply it even where you
  normally hold local authority."** INFERRED, medium confidence.
* **`v13` / `DNNFOOGPFHO`** is the server tick. PROVEN by name identity with the
  outbound 2002 field written from `GameFacade::CurrentServerTick` (`0x0754978c`,
  stored at `0x078ce55c`).

### 5.2 The `id` is a VEHICLE object id, not a player/entity id — PROVEN

Three independent proofs:

1. **Name.** `tools/il2cpp/ff_deobfuscation_map.json` maps
   `FAAMLGOPLAC → "VehicleID"`. It is the same field name used by Cmd 125, 126, 128
   `RUDP_VEHICLE_DEAD`, 171 `RUDP_VEHICLE_EXPLODE`, 129
   `RUDP_FORCE_SYNC_VEHICLE_STATE`, 186, 187, 179/180/181 (vehicle inventory), etc.
2. **Producer.** The outbound writer fills it from
   `BaseLevelObject::GetObjectID(vehicle->+0x120)` at `0x078ce480` (2002) /
   `0x078ce22c` (2069).
3. **Consumer.** The inbound handler resolves it through
   `GameFacade::CurrentLevelObjectManager` `0x0753f328` (`0x07a2a708`) before
   dispatching the per-vehicle event `KLGEOFMEHBH::BLJEIAHKEPL` `0x077fcd3c`
   (`0x07a2a758`).

Also note the handler **skips the record for the vehicle the local player is
driving** — `CurrentLocalPlayer` `0x07540158` → `Player::get_IsDriver` `0x07065824`
(`0x07a2a648`) → `Player::VehicleIAmIn` `0x0708325c` (`0x07a2a670`) — because the
client holds local authority over it.

### 5.3 Nothing in Cmd 2002 links a vehicle to its rider — PROVEN

`OLEOJNOGCCN` has five fields and none of them is a player id. The vehicle→rider
join must come from elsewhere. The complete set of sources in the image:

| cmd | class | what it gives | address |
|---|---|---|---|
| **147 `RUDP_INIT_VEHICLE_STATE`** | `MLFPDLONONK` → `List<LAAIKOJOOMC>` | **full vehicle roster with occupants** | `0x04ac7d4c` / `0x048a0954` |
| **125 / 126** | `JKOLBBEFDIB` / `LPIKFAGLDFD` | mount / dismount deltas | §Q4 |
| **187 `RUDP_VEHICLE_CHANGE_SEAT`** | `JNMEAHFMNFO` | `{vehicleId, ONMHJGMIJGM from, ONMHJGMIJGM to, byte, tick}` | — |
| **101 `RUDP_PLAYER_JOIN`** | `COEDKLIGPPD.KPOMIJFAIAO` (`DJBGFKDPBKM`) | the joining player's `uint FAAMLGOPLAC` — the vehicle they are already in | — |
| **186 `RUDP_VEHICLE_CHANGE_AUTH`** | `LLANHGLPCDL` | `{vehicleId, bool, tick}` — authority handoff | — |
| **129 `RUDP_FORCE_SYNC_VEHICLE_STATE`** | `AFOIDEILIGE` | `{vehicleId, pos, quat, byte}` | — |

**Cmd 147 is the one the ESP is missing.** `LAAIKOJOOMC::UnSerialize` `0x048a0954`,
wire order PROVEN:

```
ReadUInt16   -> FAAMLGOPLAC   VehicleID                       0x048a09f8
ReadUInt16   -> FIJLNNANNAN                                   0x048a0a0c
PMFGOGFPDHM  -> MOEFFAIDCBP   position, 3 zigzag varints
BJIPILEFOGL  -> LFCNHAJBHEE   quaternion, 4 zigzag varints
ReadBoolean  -> DBELGKKHKJP                                   0x048a0ae0
ReadInt16    -> occupant count                                0x048a0af8
count × ONMHJGMIJGM { uint playerId (varint), byte seat }
ReadString   -> AJMEEOHBMDO                                   0x048a0c58
ReadString   -> JMMCMBLKOBB                                   0x048a0c78
ReadByte     -> DIDLGNILOKP                                   0x048a0c98
```

and the Cmd 147 envelope `MLFPDLONONK::UnSerialize` `0x04ac7d4c` is
`ReadInt16 count / count × LAAIKOJOOMC / ReadBoolean`.

### 5.4 How to draw a box on an enemy who is driving

1. Build `vehicleId → [playerId, seat]` from Cmd **147** (snapshot on join / scene
   load) and keep it current with **125** / **126** / **187**.
2. Take the vehicle's world position and quaternion from inbound **2002**
   (`OLEOJNOGCCN`), which is published for every visible vehicle at the chain rate.
3. Map each occupant's `playerId` to its chain entity byte with
   `chainId = playerId & 0xFF` (§1.6) to reuse the existing team/HP/name bindings —
   **without** needing that entity to appear in the 2012 chain at all.
4. Apply a seat offset. The seat offset is **not** in the binary (it is prefab
   hierarchy), so it must be measured in game, exactly as `TPS_PIVOT_H_M` was.

This path is robust to the server dropping mounted players from the entity chain,
which is the whole point.

---

## 6. Summary of contradictions with existing docs

| doc | claim | correction |
|---|---|---|
| `PROTOCOL_MASTER.md` §4.5 | entity record fields `[10] movement mode` / `[11] action state` are varints | **raw bytes** (`ReadByte` at `0x047cd6d0`, `0x047cd6e4`). Latent desync the moment either enum reaches 0x80. |
| `PROTOCOL_MASTER.md` §4.5 | one "entity chain" with two record shapes | **two commands, two classes**: inbound 2001 = `KGHDCJFHGNP`/`ALCBKBHIOAJ` (full, carries aim), inbound 2012 = `IHLNDLHCGLM`/`FLPGKKGLKOG` (compact, no aim). |
| `PROTOCOL_MASTER.md` §4.5 | fields `[12]`/`[13]` "reserved, ~always 0" | `[12]` = `LPKKPCBKEBA`, a **MovePlatform LevelObject id** (type 27) — or a UGC custom state in Craftland. `[13]` = `MNAFFIEBGAD`, still unknown. |
| `VEHICLE_DISPATCH_MAP.md` §3.5 | outbound 2002 field 8 is a varint | **one raw byte** — `strb` at `0x078ce530`. Agrees with `CMD_2002_VEHICLE_LAYOUT.md` §3.2 and with today's live measurement. |
| `VEHICLE_PARSE_SPEC.md` §10.1 | "a horse routes to 2069" rests on a CSV flag not in the binary | **Confirmed and upgraded to proof.** The config is loaded via `ResourceManager::GetResource*` per map + game mode (`0x06c1acb0`, `0x06c1aec0`, `0x06c1b224`). Also: a **car can never emit 2069** (`Vehicle::CanDriverFire` returns 0, `0x07fc2d70`). |
| `VEHICLE_PARSE_SPEC.md` §10.1 | `EnableVehicleDriverWeaponFire` is per-mode | Confirmed, plus: the **code default is TRUE** (`0x06f08c98`/`0x06f08cfc`), it is loaded from a **CSV** (`0x06f0a1a4` → `0x08238ba4`) and can be **overwritten by the server at runtime** (`0x06f0b1e8`). |
| `VEHICLE_PARSE_SPEC.md` §0 | "the dispatcher does not go silent" | **It does, in two cases**: `Vehicle::IsLocalAuth()` false or `Player::get_WaitForForceSync()` true both fall through to the no-Send epilogue at `0x078ce8cc` (`0x078ce100`/`0x078ce110` on the 2069 branch, `0x078ce408`/`0x078ce418` on the 2002 branch, `0x078ce908` on the on-foot branch). |

---

## 7. Open questions and the exact capture for each

| # | question | capture |
|---|---|---|
| 1 | Does the server keep a mounted player in inbound 2012 / 2001? | **Offline**, from existing captures: find a 125, compute `playerId & 0xFF`, look for that entity byte in the chain until the matching 126. §1.8. |
| 2 | Does a horse emit 2069 or 2002, in BR and in CS? | 60 s mounted, `MODE_FULL`/`MODE_MATCH` (never `MODE_COMBAT`), one run per mode. §2.4. |
| 3 | Is Cmd 125 `OKIMMBDNKOC` a vehicle skin id? | Mount the same vehicle twice with different vehicle skins; diff the field. §4.1. |
| 4 | What is `MNAFFIEBGAD` (record byte 13)? | Not traced past shadow-state `+0xB4` (`0x0735d81c`). Correlate against prone/parachute/knocked states in a capture. |
| 5 | What is `IDNHFFFKDFB` in inbound 2002? | Should be 1 only on force-resync frames. Log its distribution over a match; if it is 1 on every packet the "force-apply" reading is wrong. |
| 6 | The seat offset (vehicle root → rider body) | In-game measurement. Prefab data, not in the binary — same class of unknown as `TPS_PIVOT_H_M`. |

---

## 8. Reproducing this analysis

The shipped IDB for `libil2cpp_dec.so` has essentially no functions defined, so
`decompile` fails on every il2cpp address. The workable path used here:

* `bin/rva_map.txt` is a complete `RVA \t Namespace.Class::Method` table — use it as
  the symbol source and to get function bounds (next symbol address).
* Disassemble ranges with `capstone` over the ELF (`lief` for the LOAD segment
  mapping); annotate `bl`/`b` targets from `rva_map.txt`.
* Cross-reference with a numpy scan for `BL`/`B` (`(word>>26) == 0x25` / `0x05`,
  `imm26` sign-extended ×4) and for field accesses (`LDRB`/`LDRH`/`STR` with a
  masked `imm12`).
* Field names and offsets for every `message.*` class are already in
  `tools/il2cpp/ff_message_layouts.json` (`classes` and `enums`); use it before
  reading any deserialiser.
