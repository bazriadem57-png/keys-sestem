# The enemy-mark / reveal / scan message surface

What exists, which way it travels, what it actually marks, and which of it this
tool can read or drive.

Every structural claim carries an address in
`C:\Users\Tonyt\Documents\FF-RE\bin\libil2cpp_dec.so` (the **decrypted** image;
symbols from `rva_map.txt`). Field-offset tables and enum member names that come
only from `C:\Users\Tonyt\Videos\ZRT-Toolbox\Dump\dump.cs` — a **different
build** — are flagged `[dump.cs]`; every offset used below was independently
confirmed against our own image by reading the `Serialize`/`UnSerialize` body.

Wire layouts were then **proved end to end**: real packets from
`captures/phone_aim7/capture_raw_20260912_161312.txt` were TEA-decrypted with the
session key from that capture and parsed with the grammar derived here. Counts
come from a sweep of **1 359 capture files / 24.9 M records**.

Not covered here on purpose: the Moco / Hacker's-Eye skill mechanism and its
authority model — a separate trace owns that. Where skill internals surfaced they
are noted in one line and dropped.

---

## 0. The answer in one paragraph

The game's own *marked-enemy* presentation is written by exactly one client-side
call, `PlayerAttributes::AddMarkState` (`0x07c4291c`), and only **four** things in
the whole binary call it — three inbound message handlers (Cmd 254, 866, 513) and
one local system fed by inbound Cmd 788/789. **Nothing the client sends can set
it.** There is no client→server message in the catalogue that names an enemy to be
marked. What the client *can* send is the ordinary squad ping, Cmd 148
`RUDP_MAPMARK_CHANGED`, whose type byte includes
`EItemMarkPointType_NoticeEnemy = 1` — a squad-visible "enemy here" pin at a
**world position**, not bound to an entity. That is the entire writable surface.
On the reading side the prize is Cmd 165 `RUDP_UAV_REVEAL_PLAYERS`: a 5-second
broadcast of `(entityId, x, y, z)` for revealed players **including other
squads**, confirmed decoded from a real match.

---

## 1. Summary table

`R` = `RUDP_` = reliable = TEA-encrypted (still readable — the session key is
recovered from the lobby TCP downlink). `U` = `UDP_` = unreliable = plaintext.

| id | name | direction | rel. | what it marks | seen live? | reachable for us? |
|---:|------|-----------|:----:|---------------|-----------|-------------------|
| **148** | `RUDP_MAPMARK_CHANGED` | **both** (distinct classes) | R | a **world position** + a 51-value type enum incl. `NoticeEnemy`; squad-scoped | **yes** — 26 IN / 7 OUT over 3 captures | **YES — rewrite in place.** The only writable enemy-ish mark |
| **423** | `RUDP_Assistant_MarkItem` | **both** | R | a world position + **arbitrary UTF-8 label** + object/item id | yes — 21 IN / 3 OUT over 5 captures | **YES — rewrite in place** |
| **424** | `RUDP_Assistant_RemoveMarkItem` | **both** | R | removes the above | yes — 8 IN / 3 OUT | yes (removal only) |
| **165** | `RUDP_UAV_REVEAL_PLAYERS` | **S→C only** | R | **list of (entityId, world pos, flag)** — revealed players, cross-squad | **yes** — 28 records / 3 captures, every **5.0 s** while a UAV flies | **read-only: best free intel in the set** |
| **254** | `RUDP_SYNC_MARKED_ENERMIES` | **S→C only** | R | one marked entity + the list of entities marking it → `AddMarkState(Moco)` | **never** in 1 359 captures | read-only, and mode/character-gated |
| **866** | `RUDP_SYNC_SantinoMarkInfo_Sync` | S→C only | R | same shape → `AddMarkState(SanitinoBombMarkEnemy)` | never | read-only, mode-gated |
| **513** | `RUDP_SYNC_DELIVERYMARKENEMYSKILL_STATE` | S→C only | R | one entity → `AddMarkState(DeliveryMarkEnemy)` | never | read-only, mode-gated |
| **788 / 789** | `..._MARK_ICE_WALL_INFO` / `..._BE_MARK_...` | S→C only | R | ice-wall proximity marks → `AddMarkState(MarkIceWallNearbyEnemy)` | never | read-only, mode-gated |
| **351** | `RUDP_DETECTIVE_MARK_ENEMIES` | S→C only | R | list of (entityId, pos, flag) + duration float | never | read-only, Detective mode |
| **352** | `RUDP_DETECTIVE_BEMARKED_NOTIFY` | S→C only | R | *you* were marked: a position + duration | never | read-only |
| **669** | `RUDP_DETECTIVE_ENEMIES_FOR_DAMAGER` | S→C only | R | list of (entityId, pos, flag) + duration | never | read-only |
| **887** | `RUDP_SYNC_RADAR_SCAN_POSTIONS` | S→C only | R | centre pos + **list of bare positions** (no ids) → `LevelInGameRadar::OnRadarUpdatePlayerPos` | never | read-only, radar modes |
| **1278** | `RUDP_SYNC_SCAN_POSTIONS` | S→C only | R | identical shape to 887 | 1 record, 1 capture | read-only |
| **885 / 886** | `RUDP_SYNC_RADAR_INFO` / `_BATCH` | S→C only | R | radar object: entityId + **two** positions + 19 scalars | never | read-only |
| **241** | `RUDP_USE_BOUNTY_SCANNER` | **S→C only** (despite the verb) | R | one (entityId, pos, flag) + 4 scalars | never | read-only |
| **970** | `RUDP_S2C_Sync_Common_Mark_Info` | S→C only | R | **who has marked YOU** — subject = our own entity id, list = markers | **yes** — 348 records / 7 captures | read-only; a "who is hunting me" feed |
| **1141** | `RUDP_S2C_Sync_Common_BeMark_Info` | S→C only | R | one marker record, same element shape as 970 | yes — 28 / 5 captures | read-only |
| **867** | `RUDP_SYNC_ASSISTANT_MARK_NOTIFY_TEAMMATE` | — | — | — | never | **no handler and no send site found** — see §9 |
| **875** | `RUDP_SYNC_SLOWDOWN_MARK` | — | — | — | never | **no handler and no send site found** — see §9 |
| **142 / 143** | `RUDP_START/STOP_RESCURE` | both | R | teammate revive, not a mark | 2 / 1 IN | irrelevant to marking |
| **883 / 884** | `RUDP_C2S_RADAR_START_SCAN` / `_REFRESH` | **C→S** | R | asks the server for a radar sweep | never | C→S but never emitted in our modes |
| **1458/1461/1464** | `RUDP_C2S_ROUTEPLANNING_*_MARKER_*` | **C→S** | R | personal route waypoints | never | C→S, not enemy marks |
| **12** | `EPRI_PLAYER_SIGHTING_ID` | S→C (rides Cmd 1900) | R | **not a mark** — the scope/optic the player is aiming through; 0 = not ADS | **yes** — 676 records, 46 owners in one BR match | **read it today, for free** (see §7) |

---

## 2. Serializer primitives — the encodings, confirmed in our image

| routine | address | wire |
|---|---|---|
| `FastBinaryWriter::Write(uint)` | `0x08291898` → `AppendVarint` `0x08290f64` | **U** — plain LEB128 varint |
| `FastBinaryWriter::Write(int)` | `0x08290ef4` | **Z** — zigzag varint |
| `FastBinaryWriter::Write(bool)` | `0x08291c10` → `WriteFixU8` `0x08291ff4` | **one raw byte** (`and w1, w20, #1`) |
| `FastBinaryWriter::Write(byte)` | `0x08291c9c` → `WriteFixU8` | **one raw byte** |
| `FastBinaryReader::ReadUInt32` | `0x0828fba4` | varint |
| `FastBinaryReader::ReadInt32` | `0x0828fbfc` | varint, then zigzag |
| `FastBinaryReader::ReadInt16` | `0x0828fc4c` | varint, then zigzag — **this is what reads every list count** |
| `FastBinaryReader::ReadSingle` | `0x0828fc7c` | varint whose 32 bits *are* the float32 |
| `FastBinaryReader::ReadString` | `0x082901e8` | zigzag varint byte-length, then raw UTF-8 |

Wrappers the message classes actually call: `UDPClientMessageBase::ReadUInt32
0x082bfb20`, `ReadInt32 0x082bfa6c`, `ReadInt16 0x082bfa40`, `ReadByte
0x082bfac4`, `ReadBoolean 0x082bfba4`, `ReadSingle 0x082bfb78`, `ReadString
0x082bf9e4`.

Shared sub-records, both verified by disassembly:

| class | fields | wire | addresses |
|---|---|---|---|
| `message.PMFGOGFPDHM` (a position) | `int x @0x14, int y @0x18, int z @0x1C` | `Z Z Z`, units **1000 per metre** | `Serialize 0x047c2ff0`, `UnSerialize 0x047c304c` |
| `message.NHOLKEHDONN` (entity + pos) | `uint entityId @0x14`, `PMFGOGFPDHM @0x18`, `bool @0x20` | `U Z Z Z B` | `Serialize 0x04bb6ba4`, `UnSerialize 0x04bb6c9c` |
| `message.OJIMIIDLEDA` | `uint @0x14`, `int @0x18` | `U Z` | `Serialize 0x048a995c`, `UnSerialize 0x048a99a8` |

Entity ids everywhere in this family use the project's established mask:
`entityId = (squad << 24) | slot`. Confirmed empirically below.

Sends go through `COW.GameFacade::Send(w0 = msgId, x1 = msg, w2 = sendOption, w3,
x4)` at `0x075488ac`; every mark-family send passes `w2 = 2`.

---

## 3. The client-side "marked enemy" state — and why nothing we send reaches it

`PlayerAttributes` holds the marked state that drives the game's own
marked-enemy presentation:

```
COW.GamePlay.PlayerAttributes::AddMarkState     0x07c4291c
COW.GamePlay.PlayerAttributes::RemvoeMarkState  0x07c42ae8   (sic)
COW.GamePlay.PlayerAttributes::ClearMarkState   0x07c42bc8
```

Signature `[dump.cs]`: `AddMarkState(PlayerAttributes.NHJPEJNGDHE source, uint who)`.
The source enum `[dump.cs]` is complete at five members:

```
Moco = 0
DeliveryMarkEnemy = 1
MarkIceWallNearbyEnemy = 2
SanitinoBombMarkEnemy = 3
SlowDownMarkEnemy = 4
```

A full-image caller scan of all three entry points returns **four** callers and
no others:

| caller | which message | source enum passed |
|---|---|---|
| `FFMOIGKIEPE::CJCDICCKJKB+0x440` (`0x07a686cc`) | **Cmd 254** handler | `w1 = 0` → `Moco` |
| `FFMOIGKIEPE::LKKNGAHHBEN+0x228` (`0x07a219d8`) | **Cmd 866** handler | `w1 = 3` → `SanitinoBombMarkEnemy` |
| `FFMOIGKIEPE::DCIIAPEFDGG+0x404` (`0x07a87730`) | **Cmd 513** handler | `w1 = 1` → `DeliveryMarkEnemy` |
| `BJNJMBNMHGE::LKAMMABJNPN+0x430` (`0x07ceaa7c`) | the `"MarkIceWall"` system (`[dump.cs]`: `class BJNJMBNMHGE : HBLKLJHFJDK`, `const string CMFDMLAAKBG = "MarkIceWall"`), fed by Cmd 788/789 | `w1 = 2` → `MarkIceWallNearbyEnemy` |

`SlowDownMarkEnemy = 4` has **no writer at all** in this image, matching the fact
that Cmd 875 `RUDP_SYNC_SLOWDOWN_MARK` has no registered handler.

**This is the load-bearing finding.** The marked-enemy visual is a pure
server→client effect. There is no client-callable path, and the four inbound
messages that drive it are all skill-/mode-gated and appear in **zero** of 1 359
captures.

### Cmd 254 decoded from the handler

`message.DHCNILPAODO` — `Serialize 0x04cae2ac`, `UnSerialize 0x04cae470`.
Wire: **`U ( U Z )`**

| # | field `[dump.cs name]` | off | wire | meaning |
|---|---|---|---|---|
| 0 | `BHGGAEEHJCO` | 0x14 | U | **the entity being marked** |
| 1 | `PICGANFMDNN`, list of `OJIMIIDLEDA` | 0x18 | `(U Z)` | the set of **markers**: `(markerEntityId, int)` |

Proof of the roles, in `FFMOIGKIEPE::CJCDICCKJKB`: `0x07a6850c ldr w20,[x19,#0x14]`
takes field 0 → `BHGGAEEHJCO::LMCLIKOCCJM` (`0x07c49ca4`, an EntityId ctor) →
compared against the local player (`PDJKLNDADFO 0x07c49d34`; equal takes the
"it's me" branch at `0x07a6877c`) → otherwise resolved to a `Player` via
`EMKJHAJNPDH::MBEDKMKBFIE` (`0x0725e110`) → `Player::get_Attributes`
(`0x07061b60`) → `ClearMarkState(Moco)` once at `0x07a68660`, then for each list
element `ldr w2,[x22,#0x14]` (the element's entity id) → `AddMarkState(Moco, that
id)` at `0x07a686cc`.

Cmd 866 (`message.BOOHIHOOMGA`, `UnSerialize 0x04f6ffe0`, wire `U (U F)`) has the
identical shape with `w1 = 3`. Cmd 513 (`message.KOKPCHAONLO`, `UnSerialize
0x04f6ded4`, wire `B U Z Z U`) passes its field `OLLKNOBMEFH @0x14` with `w1 = 1`
at `0x07a87724`–`0x07a87730`.

---

## 4. Cmd 148 `RUDP_MAPMARK_CHANGED` — the one writable path

### 4.1 Classes and layout

Two classes, one per direction, **identical shape**:

| direction | class | Serialize | UnSerialize |
|---|---|---|---|
| client → server | `message.PAOAHDNENHN` | `0x04acbd48` | `0x04acbe80` |
| server → client | `message.DDCJLNHHHMO` | `0x04acc09c` | `0x04acc1d4` |

Wire, read straight off `PAOAHDNENHN::Serialize` and `DDCJLNHHHMO::UnSerialize`:

**`U B B (Z Z Z) B B B`** — 9 elements.

| # | off | field `[dump.cs name]` | wire | writer / reader used | meaning |
|--:|----:|---|---|---|---|
| 0 | 0x14 | `BHGGAEEHJCO` | **U** | `Write 0x08291898` / `ReadUInt32` | **the author's entity id** — `(squad<<24)\|slot` |
| 1 | 0x18 | `PEHDNDJKFGN` | **B** raw | `Write 0x08291c10` / `ReadBoolean` | `isDel` — 1 removes the mark |
| 2 | 0x19 | `BKDGKPMMBJM` | **B** raw | `Write 0x08291c9c` / `ReadByte` | **`EILKGGIDJEH` mark type** — see 4.2 |
| 3-5 | 0x20 | `KPDJGLMHLDM` (`PMFGOGFPDHM`) | **Z Z Z** | nested | world position, 1000/m |
| 6 | 0x28 | `EBPGIBLHIOP` | **B** raw | `Write 0x08291c9c` | author's **slot index within the squad**, 0-3 (measured 16/16) |
| 7 | 0x29 | `NDEFBBKKGNG` | **B** raw | `Write 0x08291c10` | `playMarkSound` |
| 8 | 0x2A | `IAIMINIGMBC` | **B** raw | `Write 0x08291c9c` | 0 in every observed record — unresolved |

Offsets `[dump.cs]` agree byte for byte with the loads/stores in our image.

### 4.2 The type byte is where "mark an enemy" lives

`[dump.cs]` `enum message.EILKGGIDJEH` (TypeDefIndex 3006), 51 members. The ones
that matter:

```
0  EItemMarkPointType_Location
1  EItemMarkPointType_NoticeEnemy          <-- squad-visible "enemy here"
2  EItemMarkPointType_NoticeHere
3  EItemMarkPointType_MapLocation
4..9, 13..47  MapLocationWith<thing>
10 EItemMarkPointType_NoticeEnemyKnockDown
11 EItemMarkPointType_NoticeEnemyDead
12 EItemMarkPointType_NoticeSAPPortal
48 EItemMarkPointType_UAVRevealMultiEnemy
50 EItemMarkPointType_NB
```

### 4.3 Real decoded packets (proof)

`captures/phone_aim7/capture_raw_20260912_161312.txt`, 10-byte reliable header,
32-byte QQ-TEA body, key `27fd2864…`. All 16 records parsed with zero residue:

```
IN   entity=0x0B000024 isDel=0 type=35 pos=(166088,9897,-167962)  slot=01 sound=01 x=00
IN   entity=0x0B000024 isDel=1 type=0  pos=(156066,9897,-210589)  slot=01 sound=00 x=00
IN   entity=0x0B00002F isDel=0 type=35 pos=(430984,22130,155992)  slot=03 sound=01 x=00
IN   entity=0x0B00002A isDel=0 type=3  pos=(145750,9897,-187822)  slot=02 sound=01 x=00
IN   entity=0x0B00002A isDel=0 type=6  pos=(3164,9093,293180)     slot=02 sound=01 x=00
IN   entity=0x0B000024 isDel=0 type=1  pos=(218018,3316,88847)    slot=01 sound=01 x=00
OUT  entity=0x0B000022 isDel=0 type=0  pos=(186532,8377,71020)    slot=00 sound=01 x=00
OUT  entity=0x0B000022 isDel=0 type=1  pos=(203323,9475,-85690)   slot=00 sound=01 x=00
OUT  entity=0x0B000022 isDel=0 type=1  pos=(203323,9475,-85690)   slot=00 sound=00 x=00
IN   entity=0x0B00002F isDel=0 type=1  pos=(-29605,71567,-5724)   slot=03 sound=01 x=00
IN   entity=0x0B00002A isDel=0 type=1  pos=(-29766,72099,-4251)   slot=02 sound=01 x=00
IN   entity=0x0B00002A isDel=0 type=5  pos=(-30138,73558,-15508)  slot=02 sound=01 x=00
```

What this settles:

* Every OUT record carries **our own** entity id `0x0B000022`; every IN record
  carries a **different member of our own squad** `0x0B`. The server does not echo
  our own marks back to us, and it never relays another squad's marks.
  **Cmd 148 is squad-scoped, both ways.**
* We ourselves already sent **`type = 1` (`NoticeEnemy`) twice** in a single
  match. The enemy mark is an ordinary, routinely-emitted client message.
* Field 6 tracks the author exactly: `0x…22 → 00`, `0x…24 → 01`, `0x…2A → 02`,
  `0x…2F → 03`. That is the squad member index (probably the mark colour slot),
  16/16.
* Positions are 1000/m zigzag, consistent with the rest of the protocol.

### 4.4 What emits it, and on which trigger

Six `Send` sites, all reached from a UI action:

| site | address | what it sets |
|---|---|---|
| `UIBigMapController::SendMapMarkChangedByMarkSelf+0x590` | `0x04928cb4` | `[0x14]` = local player id; `[0x18] = 0`; **`[0x19] = 3`** (`mov w8,#3` at `0x04928acc`); position from `Transform::get_position`. Called only from `OnBtnMarkSelfClick+0x388` (`0x04927f98`) |
| `UIBigMapController::SendMapMarkChanged+0xd5c` | `0x04929a3c` | the general overload — `[dump.cs]` `SendMapMarkChanged(Vector3 realPos, bool isDel, EILKGGIDJEH pointType = 0, uint levelObjectID = 0, bool playMarkSound = true)`. `[0x14]` ← `GameFacade::CurrentLocalPlayerID` (`0x07541440`) at `0x0492911c`/`0x04929134`; `[0x19]` ← the `pointType` parameter at `0x049297a8`. **Callers include `TapDuringDefaultMode+0x450` (`0x0493362c`) — the ordinary tap-the-big-map ping** |
| `UIBigMapController::SendMapMarkChanged+0x670` | `0x04930b24` | the `(localPos, posType, playMarkSound)` overload `[dump.cs]`, called from `OnAddLocalAssistantMark+0x194` |
| `UIHudItemMarkPlayerDeadBtnController::OnClick+0x438` | `0x050835b8` | `[0x14]` = local id; **`strh w8,[x20,#0x18]` with `w8 = 0x100`** at `0x05083560`/`0x05083568` → `isDel = 0`, **`type = 1` = `NoticeEnemy`** |
| `UIHudItemMarkShowController::UpdateCheckPlayerInArea+0x328` | `0x0508916c` | `strh w8,[x21,#0x18]` with `w8 = 1` → `isDel = 1`, `type = 0`. **Deletion only** — the periodic tick that retires a stale mark |
| `COW.GamePlay.OHHNNBCNBCK::MIPGOJICCIL+0x1ec` | `0x06fd6f98` | the "assistant" subsystem; also sends 424 at `+0x290` |

So: a mark is emitted **once per user gesture**. Nothing re-sends it on a timer;
the only periodic path sends deletions.

### 4.5 Server validation — what the binary can and cannot tell us

Client-side gates only, all in the sender: `GameFacade::IsOnlineGame`
(`0x07548770`), `GetLocalObserverNotRoomSpectator` (`0x07541c3c`), and a batch of
`IsUGCInfectionMode` / faction checks. **Whether the server re-derives the author
id, bounds-checks the position, or restricts the type byte cannot be determined
from the client image.** See §10 for the experiment that would settle it. One
thing is visible: the author id we send is our own real id, and the server echoes
each squad member's own id, so if the server does overwrite it nothing changes —
and either way the field names the author, not a target, so it is not a useful
lever.

---

## 5. Cmd 423 / 424 `RUDP_Assistant_MarkItem` / `RemoveMarkItem`

The second writable marker, and the more expressive one.

| direction | class | Serialize | UnSerialize | wire |
|---|---|---|---|---|
| 423 C→S | `message.FLFPKIIOLAI` | `0x04d9b818` | `0x04d9b944` | `B U S U Z Z Z B` |
| 423 S→C | `message.EDAEMDNNMOB` | `0x04d9bb54` | `0x04d9bc90` | `B U S U U Z Z Z B` |
| 424 C→S | `message.CINIAKEHPJM` | `0x04d9beb4` | `0x04d9bf20` | `B U U U` |
| 424 S→C | `message.GMCDOPBFFCA` | `0x04d9bfe0` | `0x04d9c04c` | `B U U U` |

Outbound field order `[dump.cs]`: `HKPMPNBBFGM` byte (`EMEFBBBEPDG` item-mark
type), `KABOOAIIMOK` uint, `EMAPKGIHKHA` **string**, `EMBHLGCABNN` uint,
`PFMNEKODLFB` position, `NDEFBBKKGNG` bool.

`[dump.cs]` `enum EMEFBBBEPDG` (TypeDefIndex 3005): `EItemMarkType_PickUp = 0`,
`LevelObject = 1`, `Point = 2`, `LuckyDrawBox = 3`, `NB = 4`.

Decoded from a real OUT record in the same capture:

```
OUT 423  type=1 (LevelObject)  objId=131  name="Treasury"  itemId=1003
         pos=(247060, 4650, 44610)   bool=1
```

So 423 carries an **arbitrary UTF-8 label at an arbitrary world position**,
squad-broadcast. It marks *loot and level objects*, never a player entity. Sent
from `OHHNNBCNBCK::JOHPOACMIFC+0x378` (`0x06fd51ac`).

---

## 6. The reading side — what the server volunteers

### 6.1 Cmd 165 `RUDP_UAV_REVEAL_PLAYERS` — the prize

`message.OHJJAMDGCGD` — `Serialize 0x04bb6e64`, `UnSerialize 0x04bb7048`.
Wire: **`U ( U Z Z Z B ) U U`**

| # | off | field | wire | meaning |
|--:|----:|---|---|---|
| 0 | 0x14 | `OHMAPLMPFPA` | U | the UAV's object id |
| 1 | 0x18 | `EFDCLFDDABI`, list of `NHOLKEHDONN` | `(U Z Z Z B)` | **(entityId, x, y, z, flag)** per revealed player |
| 2 | 0x20 | `CCMIGEAPLPC` | U | 0 in every observed record — probably a duration |
| 3 | 0x24 | `EBALBBMKGIM` | U | 0 in every observed record |

Handler `FFMOIGKIEPE::PBODLCIKJOG` (`0x07a4d6f0`) → `LGBPPLOIEON::LODHKHIHNBO` →
`FEPEBNPFODG::AFEADPHONPA`. The UI renders these as map pins of type
`EItemMarkPointType_UAVRevealMultiEnemy = 48` `[dump.cs]`.

Decoded live, same capture — entity ids span **three different squads** (`0x0B…` =
ours, `0x01000034`, `0x0A00002B`):

```
IN uav=217 n=2 [(0x0b00002a,176103,9760,-96321,0), (0x0b000022,164168,9897,-144312,0)]  tail=(0,0)
IN uav=217 n=5 [(0x0b000022,154895,9937,-210507,0), (0x0b00002f,156066,298887,-210589,0),
                (0x1000034, 229229,116493,-120237,0), (0x0b00002a,183349,9673,-101336,0),
                (0x0b000024,156066,300000,-210589,0)]  tail=(0,0)
IN uav=217 n=3 [(0x0b000022,172764,9710,-84822,0), (0x0b00002f,133246,9897,-138968,0),
                (0xa00002b, 145702,3668,10888,0)]      tail=(0,0)
```

Cadence, measured: **14 packets, gaps of 5041/5017/4989/5016/5017 ms**, one 125 s
idle gap between two UAV episodes. So: exactly one broadcast per 5 s while a UAV
is aloft, with an absolute world position per revealed player. Compare the 198 ms
entity chain — 165 is 25× slower but **authoritative, absolute, and not subject to
the chain's relevance filtering**; the two `0x01…` / `0x0A…` entries are enemies
from other squads.

Related and unreliable (plaintext, no key needed): `UDP_UAV_STATE_SYNC` (2005),
wire `U B Z Z Z U U U B F U U U`, **5 575 records, median gap 165 ms** — the UAV's
own position stream. Useful for knowing a UAV is up and where it is.

### 6.2 Cmd 970 / 1141 — who has marked *us*

`message.DCNGPGPCDHG` (handler `FFMOIGKIEPE::HEABPKIIPGG`), wire **`U ( U B U U )`**;
`message.DEIINJIGKAC` (handler `FFMOIGKIEPE::KMBLGNINOMM`), wire **`U B U U`**.

Decoded live:

```
IN 970  subject=184549410 (= 0x0B000022, OUR OWN entity id)
        list = [(0x07000018, 1, 2, 2)]
IN 970  subject=0x0B000022  list = [(0x0100002C, 1, 18, 0)]
IN 970  subject=0x0B000022  list = []          <- the "cleared" edge
```

The subject is always our own entity and the list holds **enemy** entity ids
(squads 0x01, 0x07). So 970 is a "you are currently marked by these players" feed,
with 1141 as the single-record variant. 348 records over 7 captures — genuinely
live. It yields enemy *identities*, never positions.

### 6.3 The rest, layouts for completeness

All verified against our image except where noted.

| id | class | UnSerialize | wire |
|---:|---|---|---|
| 351 | `BAFAHAKEPEN` | `0x04e95d38` | `( U Z Z Z B ) F U B U` — list of (entity,pos,flag), duration float, uint, byte, uint |
| 352 | `EDAPKJEFNFP` | `0x04e96734` | `Z Z Z U B F U` — position, uint, byte, duration float, uint |
| 669 | `PDJKMCKKBLC` | `0x04e962ac` | `( U Z Z Z B ) U F` |
| 887 | `CKLNNAPOHNN` | `0x0537315c` | `U Z Z Z ( Z Z Z )` — id, centre, then **bare positions with no entity ids**. Handler `FFMOIGKIEPE::KABNMPPENFC` (`0x07ab7b0c`) → `LevelInGameRadar::OnRadarUpdatePlayerPos` — they are player positions |
| 1278 | `EMAEEACAKMF` | `0x05255f70` | `U Z Z Z ( Z Z Z )` — same shape |
| 241 | `NBGAHCLFPAK` | `0x04abdc94` | `U Z Z U U Z Z Z B` — inbound only; the last five are one `NHOLKEHDONN` |
| 866 | `BOOHIHOOMGA` | `0x04f6ffe0` | `U ( U F )` |
| 513 | `KOKPCHAONLO` | `0x04f6ded4` | `B U Z Z U` (`bool` at off 0x11 `[dump.cs]`) |
| 885 | `EEEOGMECLEE` `[dump.cs layout]` | — | `U U (U U)(U U) Z Z U Z B B B Z Z Z Z Z Z` — carries an entityId and **two** positions |
| 886 | `FLKGPGMDKGD` `[dump.cs layout]` | — | a list of the 885 record |
| 873 | `AJCCLDKJAOH` `[dump.cs layout]` | — | `( U Z Z Z B ) F F` — same reveal element as 165, "permanent scan" |
| 1663 | `POMLMOINLFA` `[dump.cs layout]` | — | `( U U Z Z Z )` — scan-by-type results |

---

## 7. EPRI property 12 — settled, and it is not a mark

The brief flagged `EPRI_PLAYER_SIGHTING_ID = 12` as possibly the highest-value
item. It is **not a mark**. "Sighting" in this codebase means *aiming down
sights*.

**Binary proof.** `COW.GamePlay.Player::SetSightingPRIData` (`0x071bef9c`)
tail-calls the generic PRI setter with `mov w1, #0xc` at `0x071bf09c` — i.e. it
writes EPRI index **12** — passing the caller's value in `w2`. The control is its
neighbour `Player::SetFireStatePRIData` (`0x071bee8c`), which uses `mov w1, #0x15`
at `0x071bef8c` = 21 = `EPRI_PLAYER_FIRING_STATUS`. The index mapping is therefore
certain.

Its writers are the handlers for **1522 `RUDP_START_SNIPER_FOR_CLIENT_REPLAY`**
(`FFMOIGKIEPE::BIFFBJLLPCB+0x170`, `0x07afd4ac`) and **1523
`RUDP_STOP_SNIPER_FOR_CLIENT_REPLAY`** (`MGJDJILJHDP+0x16c`, `0x07afd630`); the
fire-state pair comes from 1520/1521. Supporting names throughout `[dump.cs]`:
`OnSightingStateChanged`, `UI_SIGHTING_FIRED`,
`SNIPER_PULLBOLT_UNDER_SIGHTING_CHANGED`, `EAimAssist.OffOnSighting`,
`VISIBILITY_STATE_NoSighting`.

**Capture proof.** From the decoded PRI stream of the 16.8-minute BR match
(`captures/pull_20260913b/pri2.txt`):

```
EPRI_PLAYER_SIGHTING_ID records: 676    distinct owners: 46
value histogram: 0 x348, 535 x215, 536 x60, 534 x21, 532 x16,
                 577 x6, 546 x5, 537 x3, 530 x2      (9 distinct values)
```

A small closed set of ids in the 530-577 band plus a dominant `0`. That is a
**scope/optic item id, with 0 meaning "not aiming down sights"** — exactly what the
binary says.

**Still worth reading**, just for a different reason: it is a free, per-enemy *ADS
indicator with the optic identity*, already arriving on a channel `PriSync`
decodes today. An enemy whose property 12 goes non-zero is scoped in right now.
That is a real ESP improvement; it just is not a mark.

---

## 8. The three practical questions

### Q1 — Can we mark for OURSELVES only?

**Yes trivially, and no usefully — and no protocol work helps either way.**

Drawing our own highlight on a chosen target needs nothing from the network; the
tool already owns its ESP overlay. Reproducing the *game's* mark styling would
mean driving `PlayerAttributes::AddMarkState`, which is a **local method call
inside the game process** — not a rendering fed by anything we can synthesise on
the wire. No inbound message and no EPRI property gives us a "mark" we can
retarget:

* EPRI 12 is ADS state, not marking (§7).
* The only inbound messages that mean "this entity is marked" are 254 / 866 / 513
  / 788-789, and **none of them appeared in any of 1 359 captures**. They are
  Detective / Santino / delivery-skill / ice-wall content.
* Cmd 970 tells us who has marked *us*, not who we have marked.

Honest answer: a self-only mark is a **pure overlay feature** — pick a target in
the tool's own ESP and draw it differently. The protocol contributes nothing and
there is nothing to wait for.

### Q2 — Can we mark for TEAMMATES?

**Yes, but only as a world-position pin, not as a bound enemy marker.**

The only client→server path that names anything markable is **Cmd 148**, and it
qualifies on both tests the never-inject rule demands:

* **(a) The game already emits it.** 7 OUT records over 3 captures; the trigger is
  a UI gesture — tapping the big map (`TapDuringDefaultMode+0x450`), the mark-self
  button, or the mark-dead-player button. Two of our own captured OUT records
  already carry `type = 1` (`NoticeEnemy`). So the rewrite target is a message the
  player produces naturally, and the field we would change (the type byte and the
  three zigzag position varints) is one the game itself already varies across its
  full range.
* **(b) Server validation is unknown from the client.** Only client-side gates are
  visible (§4.5). This has to be measured, not guessed — see §10.

What a rewrite buys and what it does not:

* **Buys:** a squad-visible "enemy here" pin (`type = 1`, or 10/11 for
  knocked/dead) at **any world position we choose** — e.g. the position of an enemy
  our packet-derived ESP is tracking. Cmd 423 gives the same reach with an
  **arbitrary text label** attached.
* **Does not buy:** any binding to an enemy *entity*. Cmd 148 has no target-id
  field; field 0 is the author. The pin is static. Following a moving enemy would
  need a fresh 148 per update, and **that is injection, which the never-inject rule
  forbids** — a new reliable message mints an OrderID the reliability layer never
  issued and desyncs the window. So the realistic product is a one-shot pin per
  player gesture, not a live tracker.
* Mechanics note: 148 is reliable and therefore TEA-encrypted, unlike the Cmd 2001
  rewrite the teleport path already does in plaintext. A rewrite must decrypt
  (`BodyCrypt.decrypt`), edit, re-pad to an 8-byte multiple, re-encrypt
  (`Tea.qqTeaEncrypt` already exists), and fix `length16` + CRC7. The body is a
  fixed 32 bytes in every observed record and the plaintext is 17-18 bytes inside
  a 22-byte budget, so small varint growth fits without changing the ciphertext
  length at all — a same-length rewrite is available for most edits.

### Q3 — Free intel worth reading today

Ranked by value:

1. **Cmd 165 `RUDP_UAV_REVEAL_PLAYERS` — read this.** Absolute
   `(entityId, x, y, z)` for revealed players **across squads**, every 5.0 s while
   any UAV is up. Decoded and proven above. A better position source than the
   198 ms entity chain for the entities it covers, because it is
   server-authoritative reveal data rather than relevance-filtered replication.
   Cost: reliable/encrypted, so it needs the existing `BodyCrypt` path — the same
   one Cmd 1900 already uses. Grammar is nine lines.
2. **EPRI property 12 — read this.** Zero new protocol work; it already flows
   through `PriSync`. Gives a per-enemy "scoped in right now, through optic N"
   flag. 676 records / 46 owners in one match (§7).
3. **Cmd 970 / 1141 — cheap, modest value.** "These enemy entity ids currently have
   you marked." 348 records over 7 captures. A threat warning, not a position
   source.
4. **`UDP_UAV_STATE_SYNC` (2005) — plaintext, free.** 5 575 records at a 165 ms
   median. Tells you a UAV is airborne and where, which is exactly the predicate
   for expecting Cmd 165 traffic.
5. **Everything else in the family is mode-gated and never fired in 1 359
   captures** — 254, 351, 352, 669, 866, 887, 885/886, 513, 241, 1278. Decoding them
   is speculative work for game modes the user is not playing. If Detective or a
   Santino/radar mode ever comes up, the layouts in §6.3 are ready.

---

## 9. Mode reachability — which of this is live in ordinary BR/CS

Measured over 1 359 captures / 24.9 M records. "Live" means the id appeared with a
clean header. The singleton OUT hits on 254/351/352/669/241/513 were all in the
pre-key window with garbage flags (`5F`) and neighbouring nonsense ids such as
`CMD_4290`; they are **mis-decodes, not real sends**.

* **Live in ordinary play:** 148, 423, 424, 165, 167, 2005, 970, 1141, and
  EPRI 12.
* **Never observed:** 254, 351, 352, 669, 866, 875, 867, 887, 885, 886, 513, 241,
  1014, 873, 1244, 1263-1265, 1726, 1730. Detective mode, Santino, bounty, radar
  modes, Clash-Squad-specific and pet-skill content.
* **867 `RUDP_SYNC_ASSISTANT_MARK_NOTIFY_TEAMMATE` and 875
  `RUDP_SYNC_SLOWDOWN_MARK` have no inbound handler in
  `tools/il2cpp/ff_inbound_registry.tsv` (1 384 ids mapped) and no
  `GameFacade::Send` site in `ff_outbound_registry_full.txt` (731 sites).** Both
  ids exist in the `KLINFKFBIKB` Cmd enum `[dump.cs]`. The corroborating signal for
  875 is that `SlowDownMarkEnemy = 4` has no `AddMarkState` caller anywhere in the
  image (§3). Best reading: **not wired in this build.** Not proven — a
  registration-table walk over `global-metadata.dat` would settle it.

---

## 10. What remains unknown, and the experiment that settles each

1. **Does the server validate Cmd 148's type byte and position?** Not determinable
   from the client. **Experiment:** in a squad with a second device, tap the big
   map once and rewrite the outbound 148 in place — `type` 0 → 1 and the position
   to a point 300 m away — then look at the second device. Three outcomes: the pin
   appears as an enemy mark at the rewritten position (no validation), appears at
   the real tap position (server re-derives position), or nothing appears / a
   disconnect (rejected). One match, and it settles Q2 completely.
2. **What is byte 8 (`IAIMINIGMBC`, offset 0x2A) of Cmd 148?** 0 in all 16 observed
   records and never written by any of the six senders. Would need a capture
   containing a mark placed on a level object (`levelObjectID` is a parameter of
   the general overload `[dump.cs]` but does not obviously land in any of the seven
   fields) — likely an airdrop or treasury mark in a mode we have not captured.
3. **Are Cmd 165's two trailing uints a reveal duration?** Both 0 in all 28
   observed records. A capture containing a longer-duration reveal (a different UAV
   tier, or `RUDP_GAMEGLOBALMISSIONEVENT_PERMANENTSCAN` 873) would show non-zero
   values.
4. **The exact meaning of Cmd 254's per-marker `int`
   (`OJIMIIDLEDA.GCDBDKPFOAP`, offset 0x18).** It is not passed to `AddMarkState` —
   only the entity id is (`ldr w2,[x22,#0x14]`). Whatever it carries is consumed
   elsewhere or dropped. Needs a Detective-mode capture; no such capture exists.
5. **Whether 867 / 875 are registered by a path the two registry scans missed**
   (§9). A metadata walk of the id→class registration table would settle it.
6. **Cmd 887/1278 position lists carry no entity ids.** If a radar mode is ever
   captured, the open question is whether the positions are ordered stably enough
   to correlate with chain entities, or whether they are deliberately anonymised.

---

## 11. One line on skill internals (out of scope here)

`AddMarkState(Moco = 0, …)` is driven solely by inbound Cmd 254, and the handler
`FFMOIGKIEPE::CJCDICCKJKB` (`0x07a6828c`) has a distinct "the marked entity is me"
branch at `0x07a6877c`. The authority model behind that — who the server lets
originate a Moco mark — belongs to the separate Hacker's-Eye trace and is not
analysed here.
