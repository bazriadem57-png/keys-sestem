# Release + online-update design (2026-09-18)

How to make releases better and push new logic to every device in minutes with
no APK reinstall. Grounded in a source-cited research pass (amice + Android
14/17 behaviour changes + Chrome/Lyft/Unleash updater practice) — see the
citations at the bottom. Companion to `docs/NATIVE_LIVE_UPDATE.md`.

## What we already do (and it's close to best practice)

`NativeLoader` already downloads a replacement `libnuvola_native.so` from the
VPS, verifies **Ed25519 signature + SHA-256** against a pinned key, marks it
**read-only before load** (the Android 14/17 requirement), stores it in
`getNoBackupFilesDir()`, and has: crash-loop quarantine (an "attempting"
breadcrumb survives a load-time SIGSEGV), two-phase promote (candidate →
active on first clean launch), a signed validity window, a downgrade/high-water
guard, a per-install **staged rollout** bucket, a **kill switch** (`kill` in the
signed manifest), and the APK-bundled copy as a fail-closed fallback. Bucket-B
(CmdCatalogue/decode-profile) already updates live inside the authenticated
`/config`. So "update the decoder without reinstalling" is **already true** for
the native `.so` and for data.

## The real, research-backed improvements

### 1. Same-process hot-swap is NOT possible — keep stage + next-launch
There is no reliable `dlclose`; JNI symbols and `RegisterNatives` bindings and
any live pointers persist for the process life. "Hot" in practice = stage now,
bind on next process start. Our two-phase promote is exactly right; don't try to
swap a loaded `.so` mid-session (the only alternative — versioned sonames in a
fresh linker namespace behind a dispatch shim — is heavyweight and fragile).

### 2. Delta/patch updates (bandwidth) — the biggest genuine win
Ship a full `.so` **plus** patches from the last few versions. bsdiff alone gets
a one-version diff to ~6.7% of full size; **Courgette** (disassembly-aware
diffing) drops it to ~0.76%. For our *obfuscated* `.so`, whose addresses churn
every build (amice), Courgette-style structural diffing pays off far more than
raw bsdiff. Client applies the patch, then **re-verifies SHA-256 + Ed25519** on
the reconstructed file exactly as today; a failed apply falls back to the full
image. This is real new infra (server-side patch generation + client bspatch/
Courgette-apply) — **owner decision** on whether the bandwidth win is worth it
at current fleet size.

### 3. Faster kill-switch propagation
Today `kill`/rollout are only checked at launch (`checkForUpdate`). A kill switch
that only lands on next launch "is not a kill switch." Add a **low-frequency
background re-check** (e.g. every 15–30 min, off the packet thread) so a `kill`
or a rollout halt propagates within minutes to a running install. This touches
the running `VpnService`'s network behaviour, so it is an **owner decision**
(battery/jitter vs. response time); design it as a jittered, cheap `/version` +
`/native/manifest` poll that only acts on a signed manifest.

### 4. Crash-loop rollback → server-side rollout halt (Lyft "Safe Mode")
We already auto-revert on a load-time crash streak (client side). Add the server
half: the client reports a `safe_mode_engaged` event to a telemetry endpoint;
the server watches the new version's crash rate and **halts the staged rollout /
trips the kill switch for everyone** when it crosses a threshold. Needs a small
telemetry endpoint — **owner decision**.

### 5. Shipping *code* (not just the `.so`) without a reinstall
- **Primary channel stays: native `.so` + signed data blob.** Keep all volatile
  decode logic in the downloadable `.so` (now including the VMP'd `nuvola-vmp`)
  and pure params/tables in the signed Bucket-B blob. This sidesteps the whole
  DEX/Play question and is the least fragile path — and it's what we do.
- **If new *managed* (Java/Kotlin) logic is ever needed**, prefer
  `InMemoryDexClassLoader` (DEX lives only in a buffer, never hits disk, no
  read-only dance, smaller tamper surface, re-loaded each launch) over
  `DexClassLoader` from storage. We are **sideloaded, not on Play**, so Play's
  "no downloading executable code" policy is not a store blocker — but treat the
  platform security model (W^X, read-only, injection risk) as real regardless.
  Google's own guidance: avoid dynamic code loading whenever possible.

### 6. Android 14→17 constraints to bake in now
- API 34: dynamically-loaded **DEX/JAR/APK** must be `setReadOnly()` or the
  system throws. (We already do this for the `.so`.)
- API 37: the read-only requirement **extends to native libraries** loaded via
  `System.load()` — writable → `UnsatisfiedLinkError`. targetSdk < 37 only warns.
  Our "read-only before load" is already correct; keep it and set read-only
  *before* the hash to close the TOCTOU (already done).

## Recommended architecture (target state)
1. **Artifacts per release:** full `libnuvola_native.so` + Courgette/bsdiff
   patches from the last N versions, each Ed25519-signed, behind an Omaha-style
   manifest encoding the staged-rollout cohort. (We have the signed-manifest +
   cohort; add patches.)
2. **Client updater:** background-fetch manifest → pick patch (fallback full) →
   download → verify Ed25519 → apply → **re-verify** → `setReadOnly()` → stage.
   (We have all but patch apply.)
3. **Activation:** flip active-version pointer; bind at next launch. Wrap the
   decode entry points behind the remote kill-switch flag + version pin. (We have
   the pointer + kill flag; add the running-process re-check for speed.)
4. **Safety:** launch-crash counter before first decoder use → client Safe-Mode
   revert to last-known-good/bundled `.so`; report to the server so it can halt
   the rollout / trip the kill switch fleet-wide. (We have client half; add
   server half.)
5. **Bucket-B** stays for pure data/param changes — cheapest, safest path.

**Net:** we already deliver no-reinstall updates + rollback + kill switch. The
prioritized additions are (a) delta patches for bandwidth, (b) a running-process
kill-switch re-check for speed, (c) a server-side crash-rate rollout halt — each
an owner call, none blocking today's release.

## Sources
Android [behavior-changes-14](https://developer.android.com/about/versions/14/behavior-changes-14),
[behavior-changes-17](https://developer.android.com/about/versions/17/behavior-changes-17);
[bionic NDK W^X notes](https://android.googlesource.com/platform/bionic/+/master/android-changes-for-ndk-developers.md);
Chromium [Courgette](https://www.chromium.org/developers/design-documents/software-updates-courgette/) +
[Component Updater](https://chromium.googlesource.com/chromium/src/+/lkgr/components/component_updater/README.md);
[Lyft Safe Mode](https://www.infoq.com/news/2022/10/lyft-safe-mode/);
[Unleash canary vs kill switch](https://www.getunleash.io/blog/canary-release-vs-kill-switch).
