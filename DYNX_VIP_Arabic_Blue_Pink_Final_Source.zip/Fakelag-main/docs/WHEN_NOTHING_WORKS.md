# When nothing works — the diagnostic playbook

> **PATHS IN THIS DOC PREDATE THE 2026-09-15 PACKAGE REORG.**
> `core/` is now `tunnel/`, `net/` split into `decode/{frame,crypt,body}` +
> `protocol/`, `overlay/` split into `ui/{render,overlay,panel,button,aim}`.
> See `docs/SOURCE_MAP.md` §2 for the full old-to-new table.

**Read this first when ESP, radar, ghost and freeze all stop together.**

Every feature reads the same packet stream, so a single upstream break kills all
of them at once while the app still reports the engine running. That failure mode
has now been diagnosed **four separate times from four different angles**, each
time costing an evening. The point of this doc is that it should take two minutes.

---

## 0a. Everything reliable is empty (health, names, binds, damage) — 2026-09-17

**Symptom.** ESP draws nothing or draws boxes with no health/names. The capture
footer shows no `PRI`/`HP` counters at all. Ghost/freeze still work (they act on
plaintext world state). The app reports healthy; no alarm fires.

**The one-line test.** Count the `DECRYPTED` bit (capture flag `0x10`) on inbound
reliable packets. Healthy is ~100%; broken is **exactly 7 per match**:

```
python plan/tools/repro_rekey.py <capture_raw_*.txt>
```

**Root cause (server-side, PROVEN 2026-09-19).** The match server **re-keys the
reliable body cipher at `RUDP_JOIN_MATCH` (cmd 100)**. The lobby-advertised
`SECRET_KEY` from `tcp.MatchmakingSussNtf` is still completely correct and still
drives:

- the UDP header XOR mask (`mask == SECRET_KEY[0]`), and
- the TEA body cipher for the handshake only — `UDP_HELLO`(1) x2,
  `RUDP_JOIN_MATCH_PREPARE`(447) x2, `RUDP_JOIN_MATCH_POST`(448),
  `RUDP_JOIN_MATCH`(100), cmd 130. **Exactly 7 packets.**

The packet immediately after cmd 100 — measured 1 ms later — is opaque, and so is
everything after it. The post-join key is **constant for a whole app run**, not
per match: one run rotated `SECRET_KEY` 15 times and all 15 matches produced the
*identical* dominant ciphertext block 0 for the same command (block 0 is key-only,
no chaining). In the pre-2026-09-17 era that block 0 changed with `SECRET_KEY`,
as it should.

**It is not us, and not a game update.** Ruled out with measurements, not
reasoning: CRC-7 validates on 38,232/38,232 stored bodies (so `payload_hex` is
verbatim wire bytes and nothing mutated the buffer); the header permutation was
re-solved independently from the Length identity and is correct; the wire Flags
byte is only ever 0 or 1, so ZIPPED is never set; a 2,688-config TEA parameter
sweep found nothing; and the client build in `cmd 448`'s plaintext is
**identical** either side of the boundary (`2.132.6`, build `2019118525`).

**Where the key is NOT.** Not derivable from `SECRET_KEY`/`HEAD_SECRET`/the
account id; not in any handshake plaintext (3,990 candidate windows); not any of
63 historical keys; and **not anywhere in 7 MB of lobby TCP at any byte
alignment** (brute force validated with a planted-key positive control: 1
survivor, 0 false positives out of 2.7 M candidates). `LobbyKeySniffer` is not
buggy — its contract simply became partial.

**Leading hypothesis (NOT yet measured):** `GCommon.UDPParameters` holds a second
key slot, `SECRET_KEY_PROXY` (static field +0x58, beside `SECRET_KEY` at +0x48),
and all four PROXY symbols exist in the live build's metadata.

**Why it stayed silent for two days.** `Invariants` has always had a
`DECRYPT_FAILING` alarm reading `PROTO_DECRYPT_OK`/`PROTO_DECRYPT_FAILED` — and
**nothing ever wrote those counters**, so it was comparing two permanent zeroes.
The call site in `UdpSessionManager` is now wired (2026-09-19), separating
"no key yet" (`PROTO_NO_KEY`, the ordinary pre-match state) from "failed WITH a
key" (`PROTO_DECRYPT_FAILED`, the alarm). This is the
`ff-dumper-wiring-is-the-trap` pattern again: the alarm compiles and does nothing
until its call site is wired, and the failure is silence.

---

## 0. The 30-second triage

Open the newest `capture_raw_*.txt` and read the footer:

```
# by_dir out=972 in=870
# coverage annotated=1842 ... foreign=0 ... decrypted=1334 ...
```

| what you see | what it means | go to |
|---|---|---|
| `out` ≈ `in`, `foreign=0`, `decrypted` > 0 | **healthy** | the problem is elsewhere |
| `out` = 0–3, `in` = thousands, `foreign` = everything | **wrong app in the tunnel** | §1 |
| `out` ≈ `in` but `decrypted=0` | no session key | §2 |
| `out` ≈ `in`, `decrypted` > 0, but ~half of packets have `flags=0` | header solve wrong | §3 |
| everything healthy but the roster is thin | pre-key window | §4 |

The single most diagnostic number is the **out/in ratio**. A healthy match is
roughly balanced. One outbound packet against thousands inbound is not a subtle
bug — it means the game's traffic never entered the tunnel at all.

Also check the HUD's first line:

```
TGT   freefiremax(stopped) << PLAYING kgvn — NOT TARGETED
```

---

## 1. The wrong app is in the tunnel (most common by far)

### Signature

```
# by_dir out=1 in=6247
# coverage ... foreign=6248 ... decrypted=0
MASK: NOT RECOVERABLE (too few OUT/24 samples)
OWN STATE: 23-varint parse: 0 ok / 0 bad
ENTITY CENSUS: chain packets 0, records 0
```

### Cause

`VpnService.Builder.addAllowedApplication(pkg)` carries **only** the packages
listed and nothing else. Free Fire ships under several package names:

| package | build |
|---|---|
| `com.dts.freefiremax` | MAX |
| `com.dts.freefireth` | global |
| `com.garena.game.kgvn` | Garena Vietnam |
| `com.garena.game.kgth` / `kgid` | other regionals |

Point the tunnel at one and play another and the result is **total, silent
failure**. Inbound keepalives from the targeted (idle) app still arrive, which is
why the capture is not empty — that traffic is what you are looking at, and it is
all classified `foreign` because nothing outbound ever taught the taxonomy what
the match stream looks like.

### Why every feature dies together

No outbound → `GamePacketTaxonomy.learnMovement` never confirms → `matchServerIp`
is never set → everything is foreign. Separately, the OUT/24 movement stream is
the **mask oracle**, so without it the header layout never solves and no body can
be read. ESP, ghost, freeze and the aim all depend on that chain.

### Fix (shipped 2026-09-13)

`VpnEngine.run()` now expands the allow-list: if the target set contains **any**
known Free Fire build, every *installed* Free Fire build is added. See
`app/GameTargets.java`. The `TGT` HUD line names any known game that is running
but not targeted.

### Evidence

Two sessions minutes apart on the same device:

| session | out | in | foreign | decrypted |
|---|---|---|---|---|
| targeted build (Training Ground) | 972 | 870 | 0 | 1334 |
| untargeted build (BR) | 1 | 6247 | 6248 | 0 |

---

## 2. No session key

### Signature

`out` and `in` are balanced, but `decrypted=0` and no packet has flag `0x10`.

### Cause

The UDP cipher key arrives **in plaintext over lobby TCP**, in
`tcp.MatchmakingSussNtf` — field 2 is `server_addr` (`"ip:port"`), field 3 is the
32-hex-char secret. `LobbyKeySniffer` scans the downlink for that adjacency:

```
0x12 <len> "<ip>:<port>"     field 2
0x1A 0x20 <32 ASCII hex>     field 3
```

It is fed from `TcpProxy` at `core/TcpProxy.java:282`, on the same bytes the
lobby capture logs one line later — so if the capture has the frames and the
sniffer has no key, they are the same bytes and the difference is in the scan.

### How to check

The key is in the lobby log if a scan finds it:

```python
# over each frame's payload hex in lobby_*.txt
for i in range(len(b)-34):
    if b[i]==0x1A and b[i+1]==0x20 and all(c in b'0123456789abcdef' for c in b[i+2:i+34]):
        print(b[i+2:i+34].decode())
```

### Trap: the header is written at capture START

`# secret_key=UNKNOWN` at the top of a capture means the key was not known **at
the moment the file opened** — not that it was never found. Check the *flags
distribution* instead:

```
awk 'NF>14 && ($5=="IN"||$5=="OUT") {print $11}' capture_raw_*.txt | sort -n | uniq -c
```

`0x5F` / `0x5B` carry the `DECRYPTED` bit (`0x10`). If they are present, the key
was working. This cost a wrong conclusion once — do not repeat it.

### Note

The key is sent once per match, at matchmaking success. If the engine starts
*after* that moment it is missed for the whole match, and you stay blind until
the next lobby round-trip.

---

## 3. The header solve elected the wrong permutation

### Signature

Roughly half of all packets appear to carry the `ZIPPED` flag and are discarded
unread; the rest decode fine.

### Cause — and it is NOT compression

**Nothing on the match wire is compressed.** The ZIPPED bit is set on **0 of
88 413** packets once the header is read correctly, and Flags only ever holds 0
or 1.

`SessionKeySolver` was electing the wrong `HEAD_SECRET` permutation, so it read
Flags from what is really `orderId >> 8` — a near-random byte. The old tie-breaks
could not catch it:

- the **Length identity** cannot separate the two 1-byte or the two 2-byte slots
  (on non-reliable packets two candidate permutations give *identical* offsets);
- **SendOption** sits at the same offset in both candidates;
- the **`flags & ~0x03 == 0`** plausibility test *passes* for the wrong candidate,
  because OrderID's high byte is 0 for the first ~1 060 reliable packets — long
  past the 256-packet commit window.

So the wrong permutation scored a perfect 256/256 and won on **every fresh
match**. Cost: 14 911 packets across ~40 commands discarded in a single capture,
including 6 941 of 14 197 health updates.

### Fix (shipped)

**OrderID monotonicity**, `(next − prev) & 0xFFFF == 1`, scored above the older
tests. Measured over 255 reliable packets:

| candidate | steps of exactly 1 |
|---|---|
| correct | **229 / 255** |
| wrong | **0 / 255** |

### The general lesson

When a discriminator "passes perfectly", check whether the **wrong** answer also
passes for a boring reason. A near-constant field (a counter starting at zero)
makes a range/plausibility test useless. **Prefer a *sequence* property over a
*range* property.**

`docs/VALIDATION_AND_INBOUND.md` §4 and §7.1 already said both of these things.
The solver never adopted them — check the docs before trusting solver heuristics.

---

## 4. The pre-key window at match handover

### Signature

Everything healthy, but the roster is incomplete and HP bindings are thin.

### Cause

At match handover roughly **224 inbound packets in one second decode as
`cmd = -1`**, 49 of them `PLAYER_JOIN`-sized, because the header layout is not
solved yet for the new session. Roughly the first half of the roster burst is
discarded: `RUDP_PLAYER_JOIN` named 25 of 53 players, with the kill notices
recovering 17 more — **42/53 (79%)**.

The bodies are fine. One of the dropped packets decrypts perfectly and yields a
valid name; only the *cmd id* and *length16* were garbage.

### Not yet fixed

Solving the layout faster at handover — or buffering unresolved bodies and
replaying them once the key lands — would take roster coverage near 100% and
lift HP binding with it. **This is the highest-value remaining fix.** The
OrderID tie-break in §3 may improve it on its own; check a fresh capture before
building anything.

---

## 5. Quick command reference

Device serial `R3GL10AHL7P`. **Always** export these before any adb command with
an `/sdcard` path, or MSYS mangles it:

```bash
export MSYS_NO_PATHCONV=1 MSYS2_ARG_CONV_EXCL='*'
DEV=/sdcard/Android/data/com.fakelag.cryhard8/files/dev_logs
```

```bash
# newest sessions
adb shell "ls -lt $DEV/capture_raw_*.txt | head -5"

# the 30-second triage
adb shell "tail -6 $DEV/capture_raw_<stamp>.txt | grep -E 'by_dir|coverage'"

# direction balance  (col 5 = dir)
adb shell "awk 'NF>14 {print \$5}' $DEV/capture_raw_<stamp>.txt | sort | uniq -c"

# who are we talking to  (col 12 peer, 13 sp, 14 dp)
adb shell "awk 'NF>14 {print \$5, \$12, \$13}' $DEV/capture_raw_<stamp>.txt | sort | uniq -c | sort -rn | head"

# decrypted? 0x10 bit — 5F/5B good, 0 bad   (col 11 = flags)
adb shell "awk 'NF>14 && (\$5==\"IN\"||\$5==\"OUT\") {print \$11}' $DEV/capture_raw_<stamp>.txt | sort -n | uniq -c"

# which commands are actually decoding  (col 9 id, col 10 name)
adb shell "awk 'NF>10 && \$9 != \"-1\" {print \$9, \$10}' $DEV/capture_raw_<stamp>.txt | sort | uniq -c | sort -rn | head -20"

# what the tunnel is scoped to vs what is running
adb shell "run-as com.fakelag.cryhard8 cat /data/data/com.fakelag.cryhard8/shared_prefs/xevpn_prefs.xml" | grep -A4 target_packages
adb shell "ps -A -o USER,PID,NAME | grep -iE 'freefire|kgvn'"
```

### capture_raw column layout

```
seq ts_ms dt_us src dir decision phase match cmd cmdname flags peer sp dp len hexlen payload_hex note
 1    2     3    4   5     6       7     8    9    10     11    12  13 14  15   16       17      18
```

flags: `01`=PARSED `02`=CRC_OK `04`=RELIABLE `08`=ENCRYPTED `10`=DECRYPTED
`20`=ZIPPED `40`=LEN_MATCH `80`=PRESOLVER

---

## 6. Related docs

- `ESP_HEALTH_AND_NAMES.md` — where HP and names live, and the id joins
- `GAME_CLIENT_CONSTANTS.md` — camera, rig, sensitivity and aim assist, from the binary
- `AIM_CONTROL_TUNING.md` — the drag controller, measured against real capture timing
- `PROTOCOL_MASTER.md` — start here for protocol work (note §6.1 was retracted)
- `VALIDATION_AND_INBOUND.md` — §4 and §7.1 predicted §3 above
