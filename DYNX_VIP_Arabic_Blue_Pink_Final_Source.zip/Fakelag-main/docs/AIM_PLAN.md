# Aim system — research findings and plan

Status: **research complete, build not started.** Three parallel investigations
(Android input injection, the GameHub reference implementation, Free Fire's own
aim assist) plus one measurement over our own captures.

---

## 1. What changed, and why the original plan was wrong

The first plan assumed we had to aim precisely ourselves. Measured against our own
captures, that plan fails:

**Target speed at real engagement moments** (victim speed at the instant of each of
2 094 damage events, all 10 sessions):

| | p25 | p50 | p75 | p90 |
|---|---|---|---|---|
| at damage time | 0.46 | **2.00** | 3.81 | 5.32 m/s |

Combined with the measured prediction accuracy (~330 ms mean horizon,
constant-velocity cutting RMS error to 0.60 of naive):

| target speed | predicted error | head (0.25 m) | torso (0.5 m) |
|---|---|---|---|
| 0 m/s | 0.00 m | hit | hit |
| 1 m/s | 0.20 m | marginal | hit |
| 2 m/s | 0.40 m | miss | marginal |
| 4 m/s | 0.79 m | miss | miss |
| 6 m/s | 1.19 m | miss | miss |

**A precision aimbot from packet data is not achievable.** 198 ms tick + 230 ms
staleness is a hard floor, not a tuning problem.

**The correct design instead exploits Free Fire's own aim assist.** We do not need
to aim — we need to get the crosshair inside the game's acquisition envelope and
then control *height*. That inverts the difficulty, because angular error shrinks
with range:

| target speed | linear error | @10 m | @20 m | @50 m |
|---|---|---|---|---|
| 2 m/s | 0.40 m | 2.3° | 1.1° | 0.46° |
| 4 m/s | 0.79 m | 4.5° | 2.3° | 0.90° |
| 6 m/s | 1.19 m | 6.8° | 3.4° | 1.4° |

Note this *inverts* the earlier "distance cancels" claim. Distance cancels when
hitting a hitbox directly; it does **not** cancel for triggering a lock, so close
range is the hard case, not long range.

And the height nudge is pure geometry on a quantity staleness barely touches —
range. Chest→head ≈ 0.6 m, nudge = `atan(0.6 / range)`:

| range | 5 m | 10 m | 20 m | 30 m | 50 m | 100 m |
|---|---|---|---|---|---|---|
| nudge | 6.8° | 3.4° | 1.7° | 1.15° | 0.69° | 0.34° |

A 1 m position error at 20 m changes the required nudge by 0.08°. **This is the
reliable part of the system.**

---

## 2. Free Fire's aim assist — what is actually established

Sourcing warning: almost all 2025–2026 "Free Fire aim assist mechanics" articles are
AI-generated SEO that contradict each other on basic facts (AWM base damage given as
both 90 and 150; headshot multiplier as 2x, 2.5x and 3.25x). None of it is used
below as evidence. There is no Free Fire equivalent of the datamining communities
that exist for other shooters — **no public dump of aim-assist constants exists.**

### Established from Garena's own patch notes

- **The subsystem exists and does target selection with a priority function.**
  3volution patch notes, 27/07/2020: *"aim assist currently prioritize targets who
  are downed instead of the ones that are still in combat… Aim assist will now
  prioritize players who are in combat (Clash Squad only)."* That is lock-on
  architecture, not bullets merely bending.
- **It applies to hip-fire and to scopes.** 18/12/2017: *"Added aim assist to
  red-dot sights and scopes."*
- **It is a flag on a firing context** — OB47: *"Passengers can shoot from the
  vehicle (without aim assist)."*
- **A distinct head hitbox with its own damage channel exists** — proven by the
  0.85 s post-uncrouch headshot damage debuff.

### Established as settings (high confidence, many independent sources)

- The control is **Aim Precision**: Default / Precise on Scope / Full Control.
- **Six independent sensitivity sliders**: General, Red Dot, 2x, 4x, AWM, Free Look.
  **Each scope state has its own sensitivity** — so a pixels-per-degree calibration
  made while hip-firing does **not** transfer to any scoped state. We need one
  calibration per state.
- There is **no** in-game auto-aim or auto-fire toggle. Aim Precision is the only
  aim-related switch.

### The drag headshot, as players actually perform it

- Start at **chest-to-neck** height, not legs.
- **Drag during the burst, not before it.** *"You're not aiming at the head, then
  shooting. You're firing first, then dragging your crosshair up through the
  enemy's head mid-spray."*
- The drag is done **on the fire button itself**, because the thumb is already there.
- Fast and sharp at close range; gentle at long range or you overshoot.

This is credible as folk *practice*. Players' explanations of *why* it works are
unverified rationalisation.

### Strong indirect evidence the assist YIELDS to deliberate input

The acquisition-only vs continuous-pull question is **not answered by any credible
source**. But the crouch-headshot exploit history is informative:

- 14/08/2019: *"Crouch-Headshot Bug Fix — Added new mechanics to avoid instant
  headshot… **Added a random crosshair movement when un-crouching.**"*
- 27/07/2020: *"some players are setting up scripts to hit an instant headshot by
  un-crouching really quickly after scoping in… **Headshot will do reduced damage
  shortly after un-crouching (0.85s)**."*

Three inferences:
1. A deterministic, scriptable posture change reliably converted an assisted
   body-level aim into a head hit. **If the assist clamped the reticle back to the
   chest, that exploit could not have existed** — and would not have needed two
   fixes a year apart.
2. Garena's first countermeasure was **injecting randomness into crosshair
   position** rather than strengthening the assist's hold. That is a tell about the
   architecture.
3. Their second was a **damage debuff in a time window** — they gave up on the aim
   geometry and nerfed the payoff.

Label: **moderate confidence, inferred.** Treat as a hypothesis to test, not a fact.

### The premise that snipers are excluded is probably wrong

No patch note carves out any weapon class; the only documented exclusion is
contextual (vehicle passenger). The 2017 note explicitly added assist to *scopes*.
Sources that recommend Full Control for snipers do so precisely *because* the torso
pull is unwanted — which only makes sense if the assist is present. **Do not build
on sniper exclusion.** It is directly testable in Training Ground.

---

## 3. The five unknowns — and why we can measure all of them

The numbers we need do not exist publicly. But **we have an instrument no player
has: our own keepalive carries our exact camera direction as a float32 unit vector
at ~10 Hz.** Every open question becomes a measurement.

| # | Unknown | Experiment using the keepalive as ground truth |
|---|---|---|
| 1 | **Crosshair magnetism or bullet magnetism?** | Point near a bot, fire, and watch our own yaw/pitch in the keepalive. If the assist moves the *camera*, we see **uncommanded yaw/pitch change** while no touch is active. If we see nothing but still hit, it bends bullets. **Decisive, and it decides whether a px/deg model predicts where rounds land at all.** |
| 2 | **Does the assist fight an upward drag?** | Lock onto a bot, then drag up a known amount. Read back the achieved pitch. If the assist pulls back, pitch decays toward the start after the drag ends — directly visible in the trace. |
| 3 | **Pixels per degree, per sensitivity state** | Inject a known horizontal drag, read the yaw delta from the next keepalives, divide. Repeat for General / Red Dot / 2x / 4x / AWM. This is the same closed-loop method already used for the ping measurement. |
| 4 | **Sensitivity acceleration / non-linearity** | Same drag distance at several speeds; if deg/px varies with speed, there is acceleration and a single constant is wrong. Completely undocumented publicly. |
| 5 | **Sensitivity slider max (0–100 or 0–200)** | Read it off the device. Sources from the same period contradict each other and there is no official patch note — this would silently break a calibration constant. |

Everything else in the plan depends on #1 and #2. **They should be run first, in
Training Ground against a stationary bot, before any aim code is written.**

---

## 4. Injection path — Shizuku, and why not the alternatives

### AccessibilityService `dispatchGesture` is architecturally disqualified

From the Android docs: *"Any gestures currently in progress, whether from the user,
this service, or another service, will be cancelled."* Confirmed publicly by an
Android accessibility framework engineer: only one input stream is allowed through
at a time.

Concretely: you are holding the movement stick and the fire button. The instant a
gesture dispatches, **your touches are cancelled** — you stop moving and stop
firing. If you are already touching, the gesture is cancelled instead. They are
never merged as separate pointers. KeyMapper closed this exact request as
"Can't fix".

Since the drag headshot is performed *while firing*, this API cannot do the one
thing the technique requires. It is out — not a tuning problem.

### Shizuku is the only viable software path

Injected events form their own pointer stream (own device id), so they coexist with
a real finger. Crucially, `injectInputEvent` lets us **construct the MotionEvent
ourselves** — device id, tool type, pressure, source — which matters because of the
GameHub finding below.

Correcting the original premise: **Wi-Fi is needed only to START Shizuku, not to run
it**, and USB from a PC works with no Wi-Fi at all. The real fragility is different:
Shizuku's process is a child of `adbd`, so anything that restarts `adbd` kills it —
including a phone auto-toggling wireless debugging when leaving Wi-Fi. Device
dependent. It never survives a reboot without root.

### Every no-root software injection is trivially detectable

Google's own CTS asserts the values. Injected events carry `deviceId == -1`
(`VIRTUAL_KEYBOARD`), `FLAG_IS_ACCESSIBILITY_EVENT` (0x800), and `pressure` exactly
`1.0`. Three lines in the receiving app spots it. The only genuinely
indistinguishable option is a **USB OTG HID device** — AOA 2.0 lets a host register
a real HID digitizer with no app and no root, it *is* a real input device to the
kernel, it coexists properly and has the lowest latency of anything. It needs
hardware.

### Comparison

| | A11y dispatchGesture | Shizuku injectInputEvent | adb shell input | Root /dev/input | USB OTG HID |
|---|---|---|---|---|---|
| Setup | one toggle | pairing, redo each reboot | needs PC each session | unlock+wipe | external hardware |
| Coexists with real finger | **NO** | yes | interrupts | yes | **yes** |
| Survives reboot | yes | **no** | no | yes | yes |
| Needs Wi-Fi | no | to start only | for wireless only | no | no |
| Distinguishable | trivially | yes | yes | nearly not | **not** |
| We control the MotionEvent | no | **yes** | no | yes | n/a |

---

## 5. What the GameHub reference actually gives us

Two corrections up front: it is **C++20 + CMake, not Rust**, and **`Module/Aim`
contains no aim logic at all**. Its `CMakeLists.txt` line 1 reads
`SCAFFOLD ONLY`; its README says "no real aim-ASSIST decision logic (nothing here
decides where to aim/what to hit)". A grep across the repo for
`fov|aimbot|target_select|bone|smoothing|prediction|velocity|lead` returns **zero
matches**. What exists is a circular autoclicker that hijacks the user's finger.

It is an **internal hook** — IL2CPP metadata scanning, inline hooks, struct reads at
hardcoded offsets — and it gets screen projection for free by calling the game's own
`Camera.WorldToScreenPoint`. Its injection calls `UnityPlayer.injectEvent` by
reflection or `Activity.dispatchTouchEvent`, both only possible in-process. **None of
the injection path transfers.** There is also no aim algorithm to borrow.

### But four findings transfer and each saves a debugging cycle

1. **A Unity game may silently ignore malformed MotionEvents.** GameHub's first
   attempt did nothing at all — no crash, no exception, dispatch returned normally.
   Cause: the minimal `MotionEvent.obtain()` overload defaults `deviceId` to 0 and
   source to `SOURCE_CLASS_POINTER`, so `isFromSource(SOURCE_TOUCHSCREEN)` was
   false. Fix: the full 14-argument `obtain()` with `TOOL_TYPE_FINGER`,
   `pressure=1f`, explicit `SOURCE_TOUCHSCREEN`, and a **real enumerated device id**
   from `InputDevice.getDeviceIds()`. **This is the strongest argument for Shizuku
   over accessibility** — it is the only path where we control these fields.
2. **One clock for every timestamp.** `downTime` and `eventTime` must both come from
   `SystemClock.uptimeMillis()`. Mixing in Choreographer's nanotime is structurally
   valid and semantically garbage: `VelocityTracker` computes `eventTime - downTime`.
   Symptom is a swipe that visibly does nothing.
3. **Never inject from inside a touch callback** — caused total input lockup
   requiring a force-close. Defer with `post { }`.
4. **`onTouchEvent` returning false does not hand the touch to another window**, and
   `touchableRegion` is hidden API. The fix is resizing the overlay window to its
   interactive bounds. Our floating buttons already work this way.

---

## 6. The design

**Not a tracking aimbot. A lock assist plus a height nudge.**

1. **Acquire** — get the crosshair inside Free Fire's acquisition envelope. Coarse
   and tolerant; the angular table in §1 says this is achievable even against a
   sprinter at range.
2. **Let the game hold it** — its assist keeps the torso.
3. **Nudge up** by `atan(HEAD_OFFSET_M / range)`, computed per frame from a range
   that staleness barely degrades.
4. **Timing** — during the burst, matching how the technique actually works, not
   before it.

Whether step 3 is a single nudge or a sustained bias **depends entirely on
unknown #2** and must not be guessed.

### Confidence gate

Rather than "wait until they stand still", compute the expected error live from
target speed and data age, and refuse to engage when it exceeds the body width being
aimed at. Same shape of solution as the auto-lead work: measure the thing instead of
assuming it. This is also what makes an honest on-screen indicator possible — the
user can see *why* it did not engage.

### Phases

- **Phase 0 — measurement harness.** Answer unknowns #1–#5 using the keepalive as
  ground truth. No aim code. This is the gate for everything else; if #1 comes back
  "bullet magnetism", most of the rest is void.
- **Phase 1 — visual only (already built and installed).** FOV circle, aim point,
  target ring, drag guide. Verifies the geometry with nothing injected.
- **Phase 2 — px/deg calibration** via Shizuku, closed-loop against the keepalive,
  per sensitivity state.
- **Phase 3 — the nudge**, shape determined by #2.

---

## 7. Risks, stated plainly

- **Garena bans devices, not just accounts.** *"Devices used for cheating will also
  be banned from playing Free Fire again using any other accounts."* Recent ban
  waves explicitly list virtual machines and app-cloning apps as standalone
  bannable conditions. This is a materially larger exposure than an account ban.
- **Injection is a much louder signal than anything built so far.** The VPN only
  reads and delays our own packets. Synthetic touches are marked by the OS.
- **There is no public evidence Free Fire specifically detects accessibility
  services, overlays or injected touch** — but the absence of evidence here is weak,
  since the only sources making claims either way are SEO farms and cheat vendors.
  The one *documented* Garena response to input automation was mechanical, not
  detection-based: random crosshair movement, then a damage debuff.
- **Latency floor persists.** Even with the game's assist doing the aiming, our
  decision to engage is based on data ~330 ms old.
- **Six sensitivity states means six calibrations**, and any in-game sensitivity
  change silently invalidates them.

---

## 8. Immediate next step

Run Phase 0 experiments #1 and #2 in Training Ground against a stationary bot with a
capture running. They need no new code beyond a capture and a careful procedure, and
they decide whether the rest of this plan is worth building. Everything downstream
is guesswork until they are answered.
