# Free Fire Max (com.dts.freefireth / FF Max) — Network Protocol Knowledge Base

> **SUPERSEDED — do not act on this file.**
> Read [`PROTOCOL_MASTER.md`](PROTOCOL_MASTER.md) instead, and
> [`PROJECT_STATE.md`](PROJECT_STATE.md) for orientation.
>
> This predates five findings that each invalidate parts of it: zigzag encoding,
> the b2-b7 rotation trap, the roster-size trap, the variable body offset, and the
> fixed-width pose bytes. It is kept only as a record of how the protocol was
> first mapped. **Where it disagrees with PROTOCOL_MASTER.md, it is wrong.**


> **!! SUPERSEDED IN PART (2026-09-10) !!** Sections 2 (mask validation),
> 4 (own-state field map), 5 (enemy blob grammar) and 5b/5c (aim) are based on
> fixed byte offsets. The bodies are actually **untagged LEB128 varint streams**.
> Read `docs/PROTOCOL_VARINT_DISCOVERY.md` FIRST; it replaces those field maps
> and `captures/REPORT_blob_grammar.md`. Sections 1, 3, 6, 7, 8, 10 still hold.


> **Purpose**: Complete engineering knowledge for the Fakelag VPN project
> (`com.fakelag.cryhard8`, repo `C:\Users\Tonyt\Documents\GitHub\Fakelag`,
> build dir `fakelag\fakelag-beta`). Written so a fresh session with zero
> conversation context can continue the reverse-engineering work.
> Everything here was established empirically from packet captures
> (2026-09-07 → 2026-09-09) by the user + agent collaboration.
>
> **Status**: verified unless marked otherwise. Confidence noted inline.

---

## 1. Transport & Session Architecture

- Android `VpnService` TUN captures the game's UDP traffic; the app runs a
  userspace relay (TCP via `TcpProxy`, UDP via `UdpSessionManager`).
- Match traffic: UDP to Garena servers (`148.222.88.x:10012`, also
  `:6008`, `:10011`, `:9008`, `:15008` — port varies per match/session).
- Two endpoints observed per session: a "movement/session" server and a
  "world/state" server (e.g. IN sp=6008 AND sp=10011 in the same capture).

## 2. The XOR Mask (CONFIRMED, high confidence)

**Every packet family** (both directions) applies a per-SESSION 6-byte XOR
mask at payload positions **2–7** (0-indexed):

```
plaintext[i] = wire[i] XOR K[i]   for i in 2..7
K[0], K[1]      = NOT part of this mask
K[i] = 0        for i >= 8   (bytes 8+ are PLAINTEXT)
```

Properties (all capture-proven):
- Identical mask both directions, all families, whole session.
- `K[1]` (position 1... wait — position 3, see below) — see "nonce" note.
- **Position 1 (byte 1) is a per-packet 7-bit nonce** (K there is 0; the
  byte changes every packet; it's a rolling value the protocol uses for
  replay protection).
- Historical session masks (first byte = K[2]):
  `DEDFCFDFDDDF` (13:43), `717072706070` (14:50), `4F5F4F4D4F4E` (14:58),
  `FAEAFAF8FAFB` (15:46), `C8D8C8CAC8C9` (16:10),
  `223222202223` (22:37 Sep 9). Masks have a visible structure:
  high nibble constant, low nibble varies by ±1 per position (e.g. 22 32
  22 20 22 23 — deltas +0,+1,+0,-2,+0,+1 from a base).

### Mask recovery (fast, < 3 s)
Take OUT/**24 B** packets ("input stream", ~30 Hz — these are the player's
own input/aim samples). Bytes 2–7 of the *decoded* stream are
session-constant, so the **mode (most common value)** of wire bytes 2–7 over
~96 samples recovers K with near-100% votes (547/547 in one capture).

### Mask validation
Decode IN/**11–13 B** packets with the candidate mask; if
`plaintext[3] == plen + 2` the mask is confirmed (this length-echo invariant
holds for the whole 11–13 B family).

### The nonce (byte 1)
Byte 1 changes every packet (7-bit counter or similar). When XOR-diffing
consecutive packets, **ignore byte 1**; also bytes 0 and 8+ are plaintext
(or stable headers) so diffs there are real.

## 3. Packet Families (CONFIRMED taxonomy)

All lengths are payload (UDP) lengths.

| Len | Dir | Name | Content |
|-----|-----|------|---------|
| 24 | OUT | Input stream | ~30 Hz player input/aim. **Bytes 8–23 are HASH-DIFFUSED** (16/16 bytes change on any input change) — NOT decodable by XOR. This is the mask oracle (bytes 2–7 constant). |
| 45–64 | OUT | Keepalive / own state | ~100 ms. Length varies with state (57 = idle, 58–61 = extra state while moving/airborne, 60+ during motion). **Bytes 8+ PLAINTEXT.** THE own-position carrier (see §4). |
| 11–13 | IN | Small ack | Length-echo (pt[3] == len+2). Mask validator. |
| 26, 34 | IN | Entity streams | Header decodes (entity ID at b14–15 BE); **payload per-packet ENCRYPTED** (avalanche) — useless for ESP. |
| 42 | IN | Entity streams | Same as 26/34: header + [nonce][0x22-decoded][4-byte key] framing, payload encrypted. ~3 keys per match (squad channels). |
| 100–170 | IN | **Slot blobs** | ~6/s. **byte 10 = slot index 02–08** (7 multiplexed entities). Payload weakly obfuscated — **XOR-consecutive within a slot cancels the residual masking, leaving small position deltas**. THE enemy carrier (see §5). |
| 24, 23, 31, 32, 39, 40, 43, 50, 58, 74 | IN | Misc heartbeat/state | Payloads mostly constant (heartbeats) — carry squad/round state, not positions. |

## 4. Own-State Decode (OUT 45–64 B keepalive) — CALIBRATION-PROVEN

From the 2026-09-09 calibration match (user walked forward/right/left/
backward, jumped, rotated 360° while firing, pitched camera up/down while
firing; capture `phone_pull8/capture_raw_20260909_211019.txt`):

Bytes are plaintext past the mask region (b8+). Ten 16-bit LE fields live at
bytes 12–31:

| Bytes | Field (PROVEN) | Evidence |
|-------|----------------|----------|
| b12–13 | **X position** (wraps mod 65536) | −1535/packet (~100 ms) during right strafe; +1500 during left |
| b14–15 | unknown (frozen in all tests) | |
| b16–17 | **Z height** | 434 on ground at spawn; jump arc 434→445→434; ~0.42 units/cm scale estimate |
| b18–19 | **Y position** (wraps) | −1520/packet forward; +1100 backward |
| b20–21, b22–23 | **Facing pair (A,B)** | ~51200 = 1.0 scale (fixed-point unit vector). Sweeps during rotation-while-firing. **Frozen during camera-only rotation** — it's the character-model facing, updated on movement or fire events. FOLDED to non-negative magnitudes: `atan2(A,B)` ∈ [0°, 90°]. Quadrant signs NOT in bytes 0–31 — expected in bytes 32+ (hexLimit-64 captures pending). |
| b24–25, b26–27 | **Movement direction pair** | SIGNED, honest vector (matches measured dX/dY). During left strafe while facing north: (−14335, 257). Shares world frame with facing. |
| b28–29 | **\|vertical velocity\|** | V-shape during jump: 1252→930→480→30 (apex) →419→741→1191 |
| b30 | **airborne flag** | 1 while jumping, else 0 |
| b31 | unknown/padding | |

Position scale: ~236 units ≈ 1 meter (est. from run speed ~6.5 m/s at
1535 units/100 ms). Exact calibration pending a known-distance walk.

**Key behavioral quirk**: camera-only movement changes NOTHING in the
keepalive (user verified live) — the game sends facing updates only when
the character fires or moves. For ESP this means: during idle aim, use last
known facing; full 360° yaw needs the sign bits (bytes 32+) or inference
from movement direction during strafes.

## 5. Enemy-State Decode (IN 100–170 B slot blobs) — PARTIALLY PROVEN

From the 2026-09-09 fight captures (`phone_pull9/...212718` 32B visible,
`phone_pull10/...231055` 64B visible, 670 blobs, full match):

- **byte 10 = slot index** (02..08; 7 slots = up to 7 nearby entities).
- Each slot refreshes ~6/s; blob length 131-163 B varies with content.
- **Blob = [static identity region b12-29][dynamic state region b30-63]**:
  the static region stays byte-identical across different standing
  positions of the same entity (verified slot 05: "DD0BFCAD08BFD803
  000000 3535 0000000000" unchanged between two still positions) — it
  carries entity identity, not position. Position lives in b30+.
- The dynamic region contains **sub-records**. Grammar (validated ~85%):
  `[idx 1B (06/07/08)][P 2B BE][len 1B (1-9)][key 2B][type 1B][value 2B BE][flag 1B]`
  Records sit at variable offsets (middle sections change length); find
  them by scanning for anchor bytes (idx in 6..8 AND following len in 1..9).
  Up to 3 records per blob (idx 6/7/8).
- **ENEMY POSITION (CORRECTED — subagent reconciliation 2026-09-10, supersedes
  the record-region hypothesis):**
  - **b12-13 BE = enemy X** (mod 65536 world coordinate)
  - **b17-18 BE = enemy second horizontal axis (Z)**
  - **b23-24 BE = third-axis candidate** (slot8-verified only; may be Y)
  - Identity block b12-29 frozen = entity did not move (freeze = no update,
    do NOT interpolate); world-frame (stays frozen while the player moves).
  - Validations: bit-frozen through all 4 verified still-windows incl. two
    where the player moved 70-162 m; walk-scale steps in genuine move
    windows; distance-to-own 100% within 0-50 ku (medians 81-114 m).
  - The earlier "(P, value) = (x,y)" claim was REFUTED: its "value" 46517
    was the 0xB5B5 doubled-byte flag pair; "walk-scale steps" were a
    monotonic counter (b33-35) plus misaligned record reads.
  - Y (height) NOT FOUND: all blobs truncated at 64B (declared 113-165B) —
    the unseen tail b64-164 is the top target for the next capture.
  - Record region b30-63: stats/flags/counters only (a record VALUE
    hovering ~2187-2301 matches the terrain band — possible Y/health hint).
  - Full report: captures\REPORT_blob_grammar.md (with pseudocode decoder
    and 5 confirmation-capture tests).
- **Both records' P fields track the same quantity** (P1 and P2 moved by
  nearly identical deltas -7668/-7656 across an 8s movement window) —
  world-coordinate range (33k-64k). Candidate: two squad-mates or two
  encodings of one coordinate.
- **VALUE fields evolve smoothly while an enemy walks**: high byte +6 per
  ~400ms (BEB9→C4B9→CAB9→E6B9), P and key constant during small drift;
  larger moves change P and key too.
- When a slot's enemy is STILL: payload repeats verbatim (b12-31 visible
  region: only b24-25 tick a small counter, b31 occasionally).
- Round transition (~+150s): blob static region changes completely (new
  entity IDs).
- Slot blobs flow only while enemies are within range (a 231s match had
  670; a 105s one had 6 — presence depends on enemy proximity).

## 5b. The IN/29 aim-echo channel (calibration-proven)

IN/29-byte packets (sp=match server, ~10s cadence idle / 200ms when
active) carry the **camera/aim handshake**:
- Idle shape: `[nonce][04][D8 CA][DF DF][counter 2B][01 02 46 00 00 00
  94 A4 08 D8 B2 01 8C 88 02 BC 01 00 43]` — counter increments ~10s,
  payload frozen.
- Active shape (b2 wire=0x48): payload = 3-byte triplets
  `[val 2B][idx 1B]` with idx bytes (01,04,07,08,09...) separating
  fields; leading values evolve smoothly (+6/200ms) during camera
  movement; constant tail = loadout/weapon state.
- Fires when: camera moves while firing, movement continues, or aim
  state changes — exactly the events where the keepalive facing pair
  also updates. Silent during true idle AND during camera-only drift
  unless firing (user verified live: camera-only didn't change values).
- The +6/200ms cadence matches the enemy-blob VALUE field cadence —
  likely the same tick-counter family.

## 5c. Aim/view direction status for ESP

- The keepalive facing pair (b20-23) is the CHARACTER-MODEL facing:
  updates only on movement/fire events, frozen during idle camera drift.
  Folded to [0°,90°] (magnitudes only). NOT sufficient alone for a view
  matrix; camera pitch/yaw must come from the IN/29 echo or inference.
- OUT/24 input stream (30Hz, would carry true camera angles) is
  hash-diffused — undecodable.
- Practical ESP path: render boxes offset from last-known view direction,
  refreshed on fire/move events (when facing updates arrive).

## 6. The Cipher Families (what is and is NOT breakable)

| Family | Encryption | Breakable? |
|--------|-----------|------------|
| Keepalive OUT 45–64 B | None past b8 (mask only) | YES — decoded (§4) |
| Slot blobs IN 100–170 B | Constant session mask + weak per-slot obfuscation | YES — XOR-consecutive (§5) |
| Input stream OUT 24 B | Hash-diffusion (avalanche over b8–23) | NO — inputs are hashed, only b2–7 constant (mask oracle) |
| Entity streams IN 26/34/42 B | Per-packet keystream (XOR of consecutive ≈ random) | NO — payload avalanche-proven |

## 7. Filter Engineering (freeze/ghost — what the app does today)

- **Freeze**: drops the movement learner stream OUT/24 (and 45–64 keepalive
  toward match server) while keeping heartbeats alive — player appears
  frozen to server but session stays live. Lobby gate prevents arming in
  lobby (stale-stream detection `MATCH_STALE_MS=10000`).
- **Ghost v6 (current, working)**: freezes the ENTIRE 45–64 B keepalive
  window (spans lengths 53–60 B — single-length lock was the v5 bug that
  leaked 75% of position) + learned 24 B stream; anchors position at
  toggle-on; replays saved anchor state every 500 ms; firing passes through
  instantly (ghost shots register at the anchor — capture-proven 74/74 near
  anchor, 0 far); re-anchor = toggle off/on.
- Server hit-validation model: server accepts shots near the *last reported
  position*; ghost exploits this by pinning that report.

## 8. Methodology (how to analyze a capture)

Capture file format (one line per packet):
`seq ts phase dir decision dip sp dp len type family kind payload_hex`
- `ts` = epoch ms; `phase` = BEFORE/FREEZE (freeze filter state);
  `decision` = PASS/DROP; hex truncated at `hexLimit` bytes (default now 64)
  with `..` suffix when truncated.
- Analysis scripts live in `captures/analyze_*.ps1` (PowerShell, run from
  repo root: `powershell -NoProfile -ExecutionPolicy Bypass -File
  captures\analyze_espN.ps1 2>$null`). Careful: `[math]::Min(a,b,c)`
  silently fails in PS — chain two-arg Min or if-chains.
- Standard pipeline for a new capture:
  1. Recover mask from OUT/24 mode-of-bytes (b2–7).
  2. Verify via IN/11–13 length-echo.
  3. Decode keepalive own-state (b12–31 fields).
  4. Group blobs by byte-10 slot; XOR-consecutive per slot.
  5. Correlate with user-reported actions (jump/move/fire timings).

## 9. Open Questions / Next Steps

1. **Enemy slot blob field map** — need a hexLimit-64 capture of a fight
   with moving enemies; map bytes 32–63 to enemy X/Y/Z. → unlocks radar.
2. **Own facing quadrant signs** — during rotate-while-firing, `atan2(A,B)`
   folded to [0°,90°]; sign bits expected in keepalive bytes 32+ (now
   captured with hexLimit 64). → unlocks view matrix → screen-space boxes.
3. **Units-per-meter exact scale** — walk a known distance (e.g. 50 m
   straight) and measure ΔX.
4. Zone calibration (arm vs leg damage zones) — user offered a calibration
   match "for later".
5. Git: work since f69472f (ghost v5/v6 + ESP engine/overlay + capture
   upgrades) is UNCOMMITTED — commit when convenient.

## 10. Key File Map (repo)

- `fakelag\fakelag-beta\app\src\main\java\com\fakelag\cryhard8\`
  - `esp\EspEngine.java` — mask recovery + own-state decode + slot blob
    tracking (XOR-delta popcount per slot for live "moving" indicator).
  - `overlay\EspOverlay.java` — SYSTEM_ALERT_WINDOW readout (POS/AIM/DIR/
    JUMP/SLOTS lines), 500 ms poll.
  - `core\PacketLoop.java` — feeds EspEngine OUT/24 + keepalive.
  - `core\UdpSessionManager.java` — feeds EspEngine blobs (100–170 B) +
    small IN.
  - `core\VpnEngine.java` — engine wiring, capture start/stop pipeline.
  - `filter\GhostFilter.java` — ghost v6. `filter\GamePacketTaxonomy.java`
    — classification + learners.
  - `dev\capture\PacketCapture.java` — recorder (queue + writer thread +
    retro ring). `CaptureRecord.java` — immutable record.
  - `dev\capture\TelemetryCollector.java`, `FreezeDiffAnalyzer.java`.
- `captures\` — all pulled captures + analysis scripts + reports.
- `analysis\` — earlier subagent reports (MASK_FINDINGS.md,
  REPORT_own_position_decode.md).
- Device: R3GL10AHL7P; captures on-device at
  `/storage/emulated/0/Android/data/com.fakelag.cryhard8/files/dev_logs/`;
  pull to `captures\phone_pullN\`.
- Build: `cmd /c "gradlew.bat assembleDebug > build_out.txt 2>&1"` in
  `fakelag\fakelag-beta`; install `adb install -r
  app\build\outputs\apk\debug\app-debug.apk`. ADB sometimes drops at
  install — recheck `adb devices`.
