# MOUNTED_CAPTURE_ANALYSIS — what is actually on the wire while the local player rides

Written 2026-09-15. Capture-only analysis; no source was changed.

**Primary corpus**: `captures/pull_20260915_post_reorg/capture_raw_20260915_151018.txt`
(32 MB) + `..._001.txt` (4 MB) — two BR matches, pulled today. This is the **first
capture in the repo that contains the user driving**: 137 outbound Cmd 2002.

**Secondary corpus** (Q3 only): every `.txt` under `captures/` — **2 836 files,
3 569 MB**, scanned in full.

Scripts: `<scratchpad>/ffpkt.py` (parsers), `validate.py`, `q1_q2_q4_q5.py`,
`q3_corpus_scan.py`, `q3b_family.py`, `quant.py`, `final.py`, `final2.py`, `final3.py`.

---

## 0. Parser oracle — established before any claim below

Every number in this document comes from a decoder written here, not from the capture's
`note` column. Two independent oracles were required to pass on **every** packet:

1. **Terminal cursor** — the varint walk must land exactly on the body end.
2. **Quaternion identity** — `qx²+qy²+qz²+qw²` within ±10 % of 1 000 000.

Result over the whole 2026-09-15 capture:

| stream | packets | parse OK | notes |
|---|---|---|---|
| OUT 2001 | 12 905 | 12 905 (100 %) | handle + position |
| IN 2001 (self-echo chain) | 6 887 | 6 887 (100 %) | |
| IN 2012 (other-entity chain) | 6 843 | 6 843 (100 %) | |
| OUT 2002 | 137 | 137 (100 %) | field 8 read as a **raw byte** |
| IN 2002 (vehicle list) | 592 | 592 (100 %) | field 8 read as a **raw byte** |

Quaternion norm across all 1 048 quaternions (137 outbound + 911 inbound records):
min 998 817, median 999 690, max 1 001 204 — inside 0.12 %. Both oracles pass
everywhere, so the layouts below are settled, not hypothesised.

**Framing fact used throughout (measured, N = 14 322):** the inbound chains (2001, 2012)
and the inbound 2002 vehicle list all begin with a **list header varint equal to
`recordCount << 1`**. It was even in 592/592 and 13 730/13 730 packets and `hdr >> 1`
matched the terminal cursor every time. For 2001/2012 the header is preceded by one
varint that was `0` in 13 730/13 730 packets.

---

## Q1 — Does our own entity keep appearing in the inbound chain while mounted, and do its pose/aim bytes keep changing?

### Method

Local identity taken from the outbound Cmd 2001 handle:

| match | handle | team | slot | N |
|---|---|---|---|---|
| 1 | `0x01000001` | 1 | 1 | 6 737 |
| 3 | `0x02000004` | 2 | 4 | 6 168 |

Rides = runs of outbound Cmd 2002 ≤ 300 ms apart. Two rides, both in match 1, both
corroborated by an outbound Cmd 125 immediately before and Cmd 126 immediately after:

| ride | vehicleId | packets | duration | median dt |
|---|---|---|---|---|
| 0 | 6 | 18 | 1 656 ms | 100 ms |
| 1 | 37 | 119 | 11 684 ms | 100 ms |

Outbound Cmd 2001 is **completely absent** inside both windows (0 in-ride vs 4 167 in
the ±60 s around them); the OUT 2001 cadence gaps are 1 905 ms and 11 884 ms, matching
the rides exactly. This confirms `docs/PROTOCOL_MASTER` / memory "2001 is never sent
while mounted".

### Result

**The entity keeps appearing. The bytes that change are the VEHICLE's facing, not the
player's camera.**

**1. Presence — 100 %.** (measured)

| ride | IN 2001 packets in window | containing our own record |
|---|---|---|
| 0 | 8 | **8 (100 %)** |
| 1 | 59 | **59 (100 %)** |

The inbound Cmd 2001 chain is, in this capture, a **pure self-echo**: 1.00 records per
packet, 1 distinct id, across 3 529 on-foot packets and 67 mounted ones. Our own entity
does **not** appear in the Cmd 2012 chain during either ride (0/67).

**2. Cadence is untouched.** (measured)

| ride | IN 2001 | IN 2012 | IN 2002 |
|---|---|---|---|
| 0 | 207 ms/pkt (8) | 207 ms/pkt (8) | 207 ms/pkt (8) |
| 1 | 198 ms/pkt (59) | 198 ms/pkt (59) | 198 ms/pkt (59) |

The server does **not** go quiet while we ride. Everything still arrives on the normal
198 ms entity tick.

**3. Position is live and correct.** (measured) See Q5 — the self-echo position tracks
the vehicle to within a few hundred millimetres at a fixed ~300 ms lag.

**4. `aim` changes — but it is the vehicle's facing.** (measured, the key result)

Angle between the self-echo `aim` xz-vector and the **forward vector of the quaternion we
ourselves sent in Cmd 2002**, evaluated at a 300 ms server lag:

| ride | N | median | p90 | fraction < 20° |
|---|---|---|---|---|
| 0 | 7 | **0.2°** | 0.2° | 100 % |
| 1 | 57 | **0.5°** | 3.5° | 100 % |

At zero lag the same statistic is 0.2° / 3.6° median — the lag only tightens it. The
self-echo `aim` while mounted **is** the vehicle rotation, re-encoded as a horizontal unit
vector ×100. It contains no independent player look direction.

**5. `aimAux` — the 3-D camera vector with pitch — is FROZEN.** (measured)

| ride | mounted samples | byte-identical to the last pre-mount value | distinct values |
|---|---|---|---|
| 0 | 8 | **8/8** — `(52, 15, 84)` | 1 |
| 1 | 59 | **59/59** — `(7, -4, -100)` | 1 |

It stays frozen for roughly 1.3 s *after* dismount before it starts moving again.
Control: on foot the same field changes on 1 452 of 3 380 consecutive sample pairs, and
its angle to the direction of travel has a median of 10.1° (N = 2 553) — i.e. on foot it
genuinely is the camera; while mounted it is a stale constant.

**6. Everything else in the self-echo record is zeroed while mounted.** (measured, 67/67
mounted samples in both rides)

* `aim.y` = 0 (67/67) — the aim triple never carries pitch.
* velocity `(vx, vy, vz)` = `(0, 0, 0)` (67/67).
* `moveDir` `(mvx, mvz)` = `(0, 0)` (67/67).
* `physState` = 0 and `pose` = 0 (67/67). On foot the same fields take 5 and 7 distinct
  values respectively over 3 314 samples, so this is *not* a usable mounted flag on its
  own — only a weak necessary condition.

**7. A live orientation does exist — in the inbound Cmd 2002 list.** (measured) Our own
vehicle appears in the inbound vehicle list throughout both rides: 8/8 and 59/59 records,
with 7 and 58 distinct quaternions. Its yaw agrees with the quaternion we sent
(median 0.0° / 1.6°, N = 8 / 59). This is the same information as (4), from a second
channel, and it is *full 3-D* rather than a flattened xz pair.

### Verdict and confidence

**The tool's mounted fallback assumption — "the self-echo gives a live camera
direction" — is FALSE.** The self-echo gives a live *vehicle heading* and a frozen
camera vector. **High confidence** on the freeze (67/67 byte-identical samples, two
independent rides, plus a clear on-foot control). **High confidence** on
aim ≡ vehicle-forward (median 0.5°, p90 3.5°, N = 64, 100 % within 20°). Sample count
is the weakness: **N = 2 rides**; the result is consistent across both, but both are cars
in one match.

**Practical consequence:** while mounted there is **no player look direction anywhere on
the wire**. A camera-direction-dependent overlay (world-to-screen ESP) has nothing
authoritative to use and must either (a) render off the vehicle heading and accept that
it is wrong whenever the player looks away from the direction of travel, (b) hold the
last on-foot camera, or (c) fall back to a heading-independent view (radar in
vehicle-relative frame). A **radar** driven off position alone loses nothing: position is
fully live.

---

## Q2 — Every mount/dismount in the capture, and what happens to remote riders

### Method

Cmd 125 `RUDP_GETON_VEHICLE` / 126 `RUDP_GETOFF_VEHICLE`, decoded from the capture's
decrypted `note` (these are reliable/encrypted; the tool already decrypts them).
Today's capture: **17 IN 125, 16 IN 126, 2 OUT 125, 2 OUT 126** → **16 paired
mount/dismount intervals**, 1 left open at capture end.

`entityId` is a PlayerID: `team = id >>> 24`, `slot = id & 0xFFFFFF`.

### Result — the roster (measured, N = 16 intervals)

| # | VehicleID | team | slot | who | duration |
|---|---|---|---|---|---|
| 0 | 34 | 14 | 51 | remote | 23 025 ms |
| 1 | 9 | 8 | 11 | remote | 986 ms |
| 2 | 9 | 8 | 11 | remote | 26 067 ms |
| 3 | 34 | 10 | 17 | remote | 14 750 ms |
| 4 | 34 | 10 | 15 | remote | 17 759 ms |
| 5 | 34 | 10 | 17 | remote | 32 072 ms |
| 6 | 6 | 1 | 1 | **LOCAL** | 1 838 ms |
| 7 | 34 | 10 | 17 | remote | 15 836 ms |
| 8 | 34 | 10 | 15 | remote | 14 686 ms |
| 9 | 34 | 10 | 17 | remote | 15 235 ms |
| 10 | 40 | 5 | 32 | remote | 17 463 ms |
| 11 | 21 | 5 | 5 | remote | 32 250 ms |
| 12 | 21 | 5 | 32 | remote | 8 904 ms |
| 13 | 21 | 5 | 5 | remote | 4 580 ms |
| 14 | 21 | 5 | 5 | remote | 27 955 ms |
| 15 | 37 | 1 | 1 | **LOCAL** | 11 788 ms |

14 remote intervals, 2 local. Note **#7 and #8 overlap on VehicleID 34** — two different
players (slots 15 and 17) in the same car at the same time, so Cmd 125 is emitted per
occupant, not per vehicle. The local player's own mount is announced **twice**: our
outbound 125 and the server's inbound 125 echo carrying our own PlayerID.

Extra fields: Cmd 125 carries `VehicleID, entityId, 0, 0, 0`; Cmd 126 carries
`VehicleID, entityId, tick`. The local outbound 125 has no `entityId` (the server fills it
in on the echo) and ends with a `1`.

### Result — do remote riders vanish from the entity chain? **No.** (measured)

| # | slot | IN 2012 presence during the ride | control: same entity, 10 s before, on foot |
|---|---|---|---|
| 7 | 17 | **43/80 (53.8 %)** | 50/50 (100 %) |
| 8 | 15 | **36/74 (48.6 %)** | 50/50 (100 %) |
| 9 | 17 | **44/77 (57.1 %)** | (100 % in its own before-window) |
| 0,1,2,3,4,5,10,11,12,13,14 | — | 0/N | **also 0/N in the 6 s before and after** |

The eleven 0 % rows are **not** mount-culling: those players were equally absent from the
chain before and after their rides, i.e. simply outside visibility range. The three rows
where the player was visible at all show the rider present in roughly half the packets.

**This halving is real, and it is specific to the rider.** In the *same* 80 packets,
non-riding entities 14, 33 and 36 were present in **80/80 (100 %)** each. Records per
packet was normal (4.08, 3.97, 3.57 — on-foot baseline 4.30). So the chain was not
truncated; the rider's own record was simply emitted on about every other tick.

The records that do arrive are fully live: position changed on 41/42, 34/35 and 43/43
consecutive pairs, with 17, 20 and 28 distinct `(bodyYaw, aimYaw, aimPitch)` triples.
`physState`, `pose` and `platform` were **0, 0, 0 in 123/123** mounted remote-rider
samples versus a wide spread on foot (`pose = 0` in only 1 973 of 5 515 on-foot samples),
so the all-zero triple is a necessary but not sufficient mounted hint.

### Verdict and confidence

**Not a missing feature.** A remote player in a car remains visible in the normal entity
chain at ~50 % of the usual update rate. The inbound Cmd 2002 list is a *complement*, not
the only route. **Medium-high confidence**: N = 3 usable intervals (the other 11 give no
data because the player was never visible), but the within-packet control (100 % for
co-present non-riders) is clean.

**Actionable**: raise the ESP staleness tolerance for entities whose update rate halves,
or the boxes for mounted enemies will flicker at ~2.5 Hz instead of 5 Hz.

---

## Q3 — Is there ANY outbound Cmd 2069 anywhere in the corpus?

### Method

Full byte-level scan of every `.txt` under `captures/`: **2 836 files, 3 569 MB**.
Cheap substring reject, then a field-9 check on the `cmd` column. A second pass
censused the whole mounted-state msgid family.

### Result — **zero.** (measured)

```
IN   cmd=125   RUDP_GETON_VEHICLE                    N=99
OUT  cmd=125   RUDP_GETON_VEHICLE                    N=3
IN   cmd=126   RUDP_GETOFF_VEHICLE                   N=98
OUT  cmd=126   RUDP_GETOFF_VEHICLE                   N=3
IN   cmd=2002  UDP_VEHICLE_STATE_SYNC                N=3068
OUT  cmd=2002  UDP_VEHICLE_STATE_SYNC                N=137
IN   cmd=2006  UDP_PASSENGER_STATE_SYNC              N=1
IN   cmd=2015  UDP_SYNC_CATAPULT                     N=1
IN   cmd=2016  UDP_SYNC_AIM_ROTATION                 N=1
IN   cmd=2031  UDP_SYNC_CANNON                       N=1
IN   cmd=2069  UDP_VEHICLEWEAPONFIRE_STATE_SYNC      N=1
```

**OUT 2069 = 0 across the entire corpus.** Only two files contain any outbound member of
the family at all:

* `phone_aim6/capture_raw_20260912_162908.txt` — one OUT 125 and one OUT 126
* `pull_20260915_post_reorg/capture_raw_20260915_151018.txt` — 2× OUT 125, 2× OUT 126, **137 OUT 2002**

The five singleton inbound rows (2006/2015/2016/2031/2069) are all in
`phone_aim6/capture_raw_20260912_162908.txt`, seq 3994–4150, peer `148.222.88.45`,
`match=2`, `flags=5F` (PARSED|CRC_OK|RELIABLE|ENCRYPTED|LEN_MATCH). **All five fail the
oracle at both header offsets (8 and 10).** This *confirms* the false-positive call in
`docs/VEHICLE_DISPATCH_MAP.md` §9.3 with an independent test.

### Verdict and confidence

**High confidence that no 2069 has ever been sent in any capture we hold.** Both rides in
today's capture took the **2002** path, so for those two vehicles the `CanDriverFire`
route was not taken — which answers `VEHICLE_DISPATCH_MAP.md` §9.1/§9.2 **for cars**.

**No data on horses.** Nothing in the corpus identifies a vehicle as a horse, and the
user's two rides were VehicleID 6 and 37 with no type field on the wire. The absence of
2069 therefore does **not** disprove the IL2CPP-derived claim that
`MountableAnimal::CanDriverFire()` routes a horse to 2069 — it only proves the two
vehicles we captured are not driver-fire vehicles.

**Exact capture needed to settle it:** one BR match, mount a **horse** (not a car),
ride for ≥ 15 s while turning and while looking away from the direction of travel,
dismount. Then check for `OUT cmd=2069`. If 2069 appears, the horse has a real aim vector
and the mounted ESP can be correct on horses and only degraded in cars. If it is 2002
again, the design must assume **no aim vector in any mounted state** and Q1's verdict is
universal.

---

## Q4 — The inbound Cmd 2002 batched vehicle list

### Method

Decoded from the 8-byte unreliable header. 592 packets, 911 records, both oracles.

### Result — layout (measured, 592/592 exact)

```
body := listHdr:varint            ; == recordCount << 1  (even in 592/592)
        record × recordCount
        v12:varint                ; 1 in 564/592, 0 in 28/592
        tick:varint

record := id      : varint          ; VEHICLE id
          x, y, z : zigzag varint   ; millimetres
          qx,qy,qz,qw : zigzag varint ; quaternion ×1000
          op      : RAW BYTE        ; <-- not a varint
          vx,vy,vz: zigzag varint
```

**Record count framing**: `recordCount = listHdr >> 1`, never odd, always consistent with
a cursor landing exactly on the body end. Distribution: `{1: 394, 2: 106, 3: 69, 4: 17,
5: 6}` — at most 5 vehicles visible at once in this capture.

**Quaternion oracle validates**: N = 911 records, norm min 998 817 / median 999 652 /
max 1 001 204.

**`v0` is a vehicle id, not a player id.** (measured) 13 distinct values, all in 6..45,
**none above 65 535**, so none is PlayerID-shaped. Four of the seven `VehicleID` values
seen in Cmd 125/126 appear in the list (`6, 21, 34, 37`); `8, 9, 40` never do — those
riders were never in visibility range. Both of our own outbound 2002 `vehicleId` values
(6 and 37) appear in the inbound list, which **resolves `VEHICLE_DISPATCH_MAP.md` §9.5**:
the id space is shared between outbound 2002 and the inbound vehicle list.

### Result — field 8 is a raw byte INBOUND as well (measured)

* **Outbound 2002**: 102 of 137 packets (74.5 %) have `op ≥ 0x80`.
* **Inbound 2002**: **115 of 592 packets (19.4 %)** contain at least one record with
  `op ≥ 0x80`.

A naive varint walk desyncs on exactly those. This **corrects
`docs/VEHICLE_DISPATCH_MAP.md` §9.6**, which records `GetCurrentPackedOp` as "constant 8
in the inbound samples we have".

### Result — `op` carries an occupancy bit (measured, new)

Cross-tabulating every inbound record against whether that VehicleID was inside a
Cmd 125..126 window:

| occupied | moving | `op & 0x80` | N |
|---|---|---|---|
| no | no | no | 741 |
| no | yes | no | 15 |
| yes | no | no | 9 |
| yes | no | **yes** | 2 |
| yes | yes | no | 31 |
| yes | yes | **yes** | 113 |

* `op & 0x80` set: **0 of 756 unoccupied records (0.0 %)**, 115 of 155 occupied (74.2 %).
* `op & 0x7F` on unoccupied vehicles is `8` in 750/756 and `2` in 6/756 — effectively a
  constant. On occupied vehicles it takes 20 distinct values.

So **`op & 0x80` ⇒ the vehicle has an occupant**: 100 % specificity at N = 756 negatives,
~74 % sensitivity. Good enough to tint an occupied car differently without waiting for a
Cmd 125. **Medium-high confidence** — the negative set is large and perfectly clean, but
all 155 positives come from four vehicles in one match.

### Result — can a listed vehicle be tied to its rider? **Yes, two ways.** (measured)

**(a) Explicitly, via Cmd 125/126.** `VehicleID` in 125/126 is the same id space as `v0`.
Confirmed for 4 of 7 VehicleIDs; the other 3 never became visible.

**(b) Positionally, with no 125 needed.** Distance between a rider's entity-chain record
and its vehicle's record in the inbound 2002 list, nearest in time within 120 ms:

| pair | VehicleID | slot | N | median | p90 | max |
|---|---|---|---|---|---|---|
| #7 | 34 | 17 | 43 | 254 mm | 618 mm | 911 mm |
| #8 | 34 | 15 | 36 | 295 mm | 625 mm | 911 mm |
| #9 | 34 | 17 | 44 | **157 mm** | 775 mm | 1 038 mm |
| #6 (local) | 6 | 1 | 9 | 134 mm | 324 mm | 324 mm |
| #15 (local) | 37 | 1 | 59 | 301 mm | 636 mm | 730 mm |

Control for #9: the nearest **non**-riding chain entity to that vehicle was **47 386 mm**
away (min 7 038 mm, N = 44). Pairs #7/#8 are confounded — slots 15 and 17 were in
vehicle 34 simultaneously, so the "nearest other entity" is the co-passenger (min 0 mm).

A ≤ 1 m proximity join is therefore reliable for identifying *which vehicle* a rider is
in, but it cannot separate two occupants of the same vehicle. Use Cmd 125/126 for that.

---

## Q5 — Seat offset

### Method and result

**As literally asked** (last outbound 2001 position before the mount vs first outbound
2002 position). **N = 2** — the corpus contains exactly two mounts by the local player.

| ride | dt | Δ(x, y, z) mm | ‖Δ‖ |
|---|---|---|---|
| 0 | 161 ms | (241, 515, −2 299) | 2 368 mm |
| 1 | 100 ms | (599, 705, −1 025) | 1 381 mm |

**These two numbers are not a seat offset.** The player was still running in the 100–161
ms gap; ride0's −2 299 mm on z is simply one sprint tick. The measure is dominated by
motion, not geometry.

**A better measure**, using the server's own echo of our mounted position. Minimum
distance from each self-echo sample to **any** vehicle position we reported during that
ride:

| ride | N | median | p90 | max | implied lag |
|---|---|---|---|---|---|
| 0 | 8 | **25 mm** | 177 mm | 177 mm | 275 ms |
| 1 | 59 | **324 mm** | 639 mm | 655 mm | 307 ms (p10 299, p90 313) |

The implied lag is tight and constant (ride1: 299–313 ms at the 10th/90th percentile),
which is the signature of a pure transport delay, and the residual millimetres are what
interpolation between 100 ms outbound and 198 ms inbound samples costs at driving speed.

Cross-check against the **inbound** 2002 list rather than our own outbound: median
134 mm (N = 9) and 301 mm (N = 59), with 5 exact zero matches.

### Verdict and confidence

**The seat offset is zero.** The server reports the mounted player's entity position as
the vehicle root position — the two are the same point, not two points a seat apart.
Ride0 pins it to within 25 mm median / 177 mm max.

**Medium confidence.** N = 2 rides is thin and both were cars. But the ride0 figure
(25 mm median over 8 samples, max 177 mm) is far below any plausible seat offset, and
ride1's larger residual is fully explained by the constant ~300 ms lag times a higher
speed. If a real seat offset existed it would appear as a *constant bias vector*, not as a
lag-proportional residual — and no such bias is present.

**Practical consequence:** do **not** apply a seat-offset correction. Draw the mounted
player's box at the vehicle position. If the rendered model looks offset, that is a model
pivot in the game client, not a wire offset, and cannot be measured from packets.

---

## 6. Bonus — what the tool's own `# DIAG` counters did during the rides

Per-DIAG-block deltas (blocks are ~15 s), ride blocks vs the four blocks on each side:

| slot | ride1 per block | control per block | ratio |
|---|---|---|---|
| `ESP_CHAIN_PKT` | 151.0 | 152.5 | 0.99 |
| `ESP_CHAIN_PARSE_STRUCTURED` | 151.0 | 143.6 | 1.05 |
| `ESP_OWN_FROM_2001` | 92.0 | 134.9 | 0.68 |
| `ESP_OWN_FROM_2002` | **59.5** | **0.0** | only while mounted |
| `ESP_OWN_FROM_ECHO` | **29.0** | **0.0** | only while mounted |
| `ESP_CLS_R2_ENEMY` | 3.5 | 203.5 | **0.02** |
| `ESP_CLS_R2_TEAM` | 75.5 | 169.4 | 0.45 |
| `RENDER_NO_OWN_STATE` | 0.0 | 85.8 | 0.00 |

Reading:

* **The chain never stops being received or parsed** (`ESP_CHAIN_PKT` flat) — matching the
  wire measurement in Q1.
* `ESP_OWN_FROM_2001` falls by exactly the ride duration's worth of ticks (deficit 57 and
  63 over 5.5 s and 6.2 s of riding at 10.1/s) — i.e. it goes to **zero** during the ride,
  as expected.
* The mounted own-state fallbacks (`ESP_OWN_FROM_2002`, `ESP_OWN_FROM_ECHO`) **do fire**,
  only while mounted. The mounted path is wired and alive.
* `ESP_CLS_R2_ENEMY` collapsing to 2 % is **partly confounded**: the IN 2012 chain carried
  1.36 records/packet while mounted vs 4.22 on foot in this capture, because ride1 drove
  into an empty part of the map. Treat the 0.02 ratio as suggestive, not proof of a
  classifier bug.

### Important caveat about this capture

`RENDER_DREW_NOTHING` equals `RENDER_FRAME` (901–902) in **every** DIAG block of the whole
session, on foot and mounted alike, and the capture carries **167 `# DIAGALARM` lines**
including repeated `RENDER_BLIND` ("classified 304 entities but the renderer drew 0 boxes
in 901 frames") and `NO_AUTHORITATIVE_TEAM`.

**So the ESP drew nothing at any point in this capture.** This session cannot, by itself,
reproduce a *mounted-specific* render failure — there was a pre-existing full blackout. The
wire-level findings above are unaffected (they are measured off the packets, not off the
renderer), but anyone using this capture to confirm a mounted-only fix will get a false
negative. Re-capture with the ESP demonstrably drawing on foot first.

Outbound traffic during the 13.3 s of riding, for completeness: 2002 ×137, ACK ×281,
PING ×12, `2028 UDP_C2S_VEHICLE_GEARVFX` ×9, `322 RUDP_MANUAL_ZONE_ENTEROREXIT` ×5,
`365 RUDP_VEHICLE_BRAKE` ×2, `126` ×2, `1593 RUDP_C2S_Vehicle_Overdrive_Req` ×1,
`127 RUDP_VEHICLE_TAKE_DAMAGE` ×1 — and **zero** Cmd 2001. None of these carries an aim
vector.

---

## 7. Corrections to existing docs

| doc / section | claim | correction |
|---|---|---|
| `docs/VEHICLE_DISPATCH_MAP.md` §9.3 | "the user has never yet captured themselves driving or riding"; "every one of the 1 083 Cmd 2002 records found is inbound" | **Stale.** `pull_20260915_post_reorg` has **137 outbound Cmd 2002** and 2 outbound 125/126. Corpus totals are now 3 068 inbound / 137 outbound 2002. The §9.3 *false-positive* call on the five `phone_aim6` packets is **confirmed** — all five fail the quaternion + terminal-cursor oracle at both header offsets. |
| `docs/VEHICLE_DISPATCH_MAP.md` §9.4 | "Whether the server keeps a mounted player alive in the inbound 2001 list" — open | **Resolved: yes.** 67/67 mounted packets contain our own record, at the unchanged 198 ms tick, with a live position. |
| `docs/VEHICLE_DISPATCH_MAP.md` §9.5 | "it matters only if the id in outbound 2002/2069 turns out not to match the ids seen in the inbound 2002 vehicle list" — open | **Resolved: they match.** Our outbound `vehicleId` 6 and 37 both appear as `v0` in the inbound list, and both appear as `VehicleID` in Cmd 125/126. One id space. |
| `docs/VEHICLE_DISPATCH_MAP.md` §9.6 | "`GetCurrentPackedOp` … it is constant `8` in the inbound samples we have" | **Wrong now that we have 911 inbound records.** It is 8 only on *unoccupied* vehicles (750/756). On occupied vehicles it takes 20 values and sets bit 0x80 in 115/155 records — 19.4 % of inbound packets contain a byte ≥ 0x80. The **raw-byte** reading is mandatory inbound as well as outbound. |
| `docs/VEHICLE_DISPATCH_MAP.md` §0 / §4 | 2069 is the horse path and "2069 is the only driver message that carries the player's aim vector" | **Not contradicted, but untested.** Zero OUT 2069 in 2 836 files / 3 569 MB. Both captured rides were cars and took 2002. A horse ride has never been captured. |
| memory `ff-mounted-kills-own-state` | "Cmd 2001 stops in vehicles; ESP/radar lose position and camera; self-echo is the recovery" | **Half right.** Position *is* recovered by the self-echo, exactly (Q5: no seat offset). **Camera is not** — `aimAux` is frozen byte-for-byte and `aim` is the vehicle's own facing. |

---

## 8. What to do with this

1. **Position while mounted is solved.** Self-echo (IN 2001) *or* our own vehicle's record
   in the inbound 2002 list; both land on the vehicle root with no seat offset. A radar
   needs nothing else.
2. **Camera while mounted does not exist on the wire.** Any world-to-screen ESP must pick
   a documented degradation. Do not ship a mounted camera derived from `aimAux` — it is a
   frozen constant and will silently point wherever the player last looked on foot.
3. **Remote riders are still in the chain**, at ~half rate. Loosen the staleness window for
   entities inside a live Cmd 125..126 window, or they will flicker.
4. **`op & 0x80` in the inbound 2002 list marks an occupied vehicle** (0/756 false
   positives). Cheap way to highlight cars with people in them.
5. **Read field 8 as a raw byte in *both* directions**, or 19.4 % of inbound vehicle
   packets and 74.5 % of outbound ones decode as garbage.
6. **Capture a horse ride.** It is the one open question that changes the design.
