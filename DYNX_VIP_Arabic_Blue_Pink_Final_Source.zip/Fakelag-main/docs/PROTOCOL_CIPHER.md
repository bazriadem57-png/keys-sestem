# Free Fire UDP match protocol — framing and cipher

**Authoritative and complete for framing.** Derived from `libil2cpp.so` (Free Fire
Max 2.131.1), cross-validated against real captures, and implemented in
[`tools/ffdecode.py`](../tools/ffdecode.py). Every percentage is measured.

Binary sources: `GCommon.UDPMsgPacket`, `UDPParameters`, `UDPChecksum`,
`NetworkCryptologyUtil`, `NetworkZipUtil`, `UDPSession`/`MUDPSession`.

---

## 1. Finding the match traffic

Identify the match server by **byte 0 (MsgKey) in 90..110**. Do **not** hardcode the
port — 10013 and 10014 are both observed. A capture also contains other UDP services
(one with fixed MsgKeys 0x41/0x51/0x71, and a probe on 8001) which must be excluded.

---

## 2. MsgKey — the framing discriminator

```
IsValidMsgKey(k) = MSG_KEY_MIN <= k <= MSG_KEY_MAX
IsMsgKeyRUDP(k)  = MSG_KEY_MIN <= k <  MSG_KEY_MID
GenMsgKey        = reliable ? Random.Next(MIN, MID) : Random.Next(MID, MAX)
```

**MSG_KEY_MIN = 90, MSG_KEY_MID = 100, MSG_KEY_MAX = 110** — established three
independent ways: measured from captures, recovered from `.rodata:0x18BB4E0`
(`5a 00 00 00 64 00 00 00 6e 00 00 00`), and **read live** out of the running process.

- **90..99 → reliable**, header **10 bytes**
- **100..109 → non-reliable**, header **8 bytes**

MsgKey is re-randomised per packet, so byte 0 carries **no stable identity** — only
its range is meaningful. It is also the *only* thing that tells the receiver the
header size, because every other field is masked and may be permuted.

Verification: all 16 078 packets with MsgKey 90..99 have `len % 8 == 2` — **100.0%**
for each of the ten keys.

`IsReliable(cmd, sendOption)`: reliable iff `sendOption ∈ {HELLO=1, RELIABLE=2,
VAR_RELIABLE=5}`, overridden to non-reliable when `Cmd == 2` (UDP_ACK).

---

## 3. Header layout — field ORDER is per-session

Header = 2 plaintext bytes + five fields, **all XOR-masked with a single byte `m`**:

| field | enum | width |
|---|---|---|
| SendOption | 0 | 1 |
| Cmd | 1 | 2 LE |
| OrderID | 2 | 2 LE (reliable only) |
| Flags | 3 | 1 |
| Length | 4 | 2 LE |

```
b0   MsgKey   plaintext
b1   CRC7     plaintext
b2.. the five fields, in HEAD_SECRET order, each byte ^ m
```

**`UDPParameters.HEAD_SECRET` is an `int[5]` permutation, not a key.** It reorders
the fields on the wire. Built by `NetworkUtils.ParseUDPHeadSecret(hexString)`, so it
arrives as configuration. When null/not length 5, the default order
`[SendOption, Cmd, OrderID, Flags, Length]` is used. `OrderID` contributes 0 bytes on
non-reliable packets, so widths sum to 6 (header 8) or 8 (header 10).

**This is the true source of the long-standing "b2–b7 mask rotates per session"
observation** — the bytes are not rotating, the *fields* are permuted.

`Length` is the **payload byte count**, excluding the header. When encryption is on
it is the *ciphertext* length.

### Measured across three sessions — solved from the capture alone

| capture | m | HEAD_SECRET order | Length fit | CRC7 |
|---|---|---|---|---|
| 20260908_205830 | 0x2C | `[SendOption, Cmd, OrderID, Length, Flags]` | 100.0% | 25 596/25 596 |
| 20260908_105542 | 0xDA | `[SendOption, Length, Cmd, OrderID, Flags]` | 100.0% | 27 252/27 252 |
| 20260910_161940 | 0x71 | `[SendOption, Cmd, OrderID, Flags, Length]` | 100.0% | 37 100/37 100 |

---

## 4. The mask — one byte, and it is SECRET_KEY[0]

From `Unserialize` (0x82C1248–0x82C143C):

```c
v18 = UDPParameters.static_fields[+72];   // SECRET_KEY (byte[])
v30 = *(byte*)(v18 + 32);                 // m = SECRET_KEY[0]   (fallback 10 if empty)
v43 = v30 | (v30 << 8);                   // m16 -- BOTH bytes identical
```

So the mask is **a single byte replicated**, and it is the **first byte of the TEA
key**. It changes per session only because `SECRET_KEY` does.

### Solving m and HEAD_SECRET from a capture, with no key and no handshake

`Length` is a known plaintext (`len - headerSize`). For each of the 120 permutations,
`Length`'s byte offset is fixed; solve `m = b[off] ^ (payLen & 0xFF)` and require
`b[off+1] ^ m == payLen >> 8`. Vote across packets. This yields **both** `m` and the
permutation. `tools/ffdecode.py solve` does exactly this — 100% on all sessions tried.

**Use the OUT direction.** Inbound `Length` is the *pre-compression* size when
`FLAG_ZIP` is set, so it will not equal the wire length.

> An earlier reading of this data as a "6-byte position-indexed key, cyclically
> rotated" was **wrong**. Session 105542 looked like a two-byte key `0xC8,0xDA`; it is
> actually mask `0xDA` with `Length` permuted into a different slot.

---

## 5. Body cipher — TEA, 16 rounds, Tencent QQ-TEA framing

`NetworkCryptologyUtil` statics, from `.rodata:0x18BC950` =
`02 00 00 00 07 00 00 00 b9 79 37 9e 10 00 00 00` plus a `4`:

```
SALT_LEN = 2   ZERO_LEN = 7   DELTA = 0x9E3779B9   ROUNDS = 16   LOG_ROUNDS = 4
```

**DELTA is a static field, not an instruction immediate.** A scan of the code for
`0x9E3779B9` therefore finds only `boost::hash_combine` and misses the cipher — a
mistake made and corrected during this work.

Block function (`TeaEncryptECB` @0x082AE6F0 / `TeaDecryptECB` @0x082ADDD8) is
textbook TEA over **little-endian** words (`BitConverter.ToInt32` compiles to a direct
native load), key = first 16 bytes of `SECRET_KEY` as 4 LE int32:

```c
// decrypt
sum = DELTA * ROUNDS;                         // 0xE3779B90
for (n = 0; n < 16; n++) {
    v1 -= ((v0<<4)+k2) ^ (v0+sum) ^ ((v0>>5)+k3);
    v0 -= ((v1<<4)+k0) ^ (v1+sum) ^ ((v1>>5)+k1);
    sum -= DELTA;
}
```

Outer framing: `[padCount byte][padCount zeros][SALT_LEN zeros][plaintext][ZERO_LEN zeros]`,
CBC-chained 8-byte blocks, `padCount = plain[0] & 7`.

```
encLen = align8(plainLen + SALT_LEN + ZERO_LEN + 1) = align8(plainLen + 10)
```

`encLen` is always ≡ 0 (mod 8) — **that, plus the 8- or 10-byte header, is the entire
explanation of the `8+8k` / `10+8k` "ECB families"**. They are not cipher-block
artifacts; they are header + ciphertext.

**`rand()` @0x082ADFA0 is stubbed to `return 0`**, so the salt bytes are always zero
and encryption of a given plaintext is fully deterministic.

If `UDP_HEAD_AND_ENCRY_SIZE + encLen > MTU_LIMIT` the encryption bit is **silently
cleared** and the packet goes out in plaintext.

---

## 6. Flags

`BitArray.HasFlag(v, f)` is `(f & v) != 0`. `FLAG_ENCRYPTION = 1`, `FLAG_ZIP = 2`.

| Flags | receive | send |
|---|---|---|
| 0 | payload verbatim | plaintext |
| 1 | TeaDecrypt whole payload | TeaEncrypt |
| 2 | Unzip whole payload | never produced by the client |
| 3 | **Unzip then TeaDecrypt** | n/a |

`Flags` is the authoritative encryption indicator — **not** `len % 8`. Measured: 744
plaintext packets happen to satisfy `len % 8 == 0` and must not be decrypted.

`NetworkZipUtil.ZipXORHeader` XORs the first `min(len, key.Length)` payload bytes with
`SECRET_KEY` (an XOR'd gzip header). `Unzip` itself is obfuscated in the image and has
no analysable body — only its call contract is known (returns new length, `< 0` = drop).

---

## 7. CRC7 — solved, 100%

```
packet[1] == crc7(packet[2:], seed = 0)
```

**25 596 / 25 596 = 100.0%** in one session and 100% in every other tested session,
across both directions, encrypted and plaintext. Rejected alternatives: `b0 + b2..end`
0.0%, header only 0.9%, payload only 57.8%.

Table is **CRC-7/MMC, poly 0x09**, 7-bit — the Linux `crc7_syndrome_table >> 1`:
`00 09 12 1B 24 2D 36 3F 48 41 5A 53 6C 65 7E 77 ...`. Recovered from
`global-metadata.dat` (initialiser blobs live in `fieldAndParameterDefaultValueData`,
**not** `.rodata`) and verified cryptographically — Roslyn names
`<PrivateImplementationDetails>` fields by SHA-256 of the blob, and the hash matched.

The CRC is computed over the bytes **as transmitted** (masked and encrypted), in wire
order, and covers the header fields **plus the whole payload**. `MsgKey` and the CRC
byte itself are excluded. `Unserialize` does **not** verify it.

### Act on this

> Any filter that rewrites a packet byte at offset >= 2 **must recompute CRC7 over
> `packet[2:]` and rewrite byte 1**. `GhostFilter`, `FreezeFilter` and the teleport
> rewrite do not do this today — a strong candidate explanation for teleport's
> "server sets us back" behaviour and the distance-budget rejections in
> `TELEPORT.md`.

---

## 8. Proxy framing

`ProxySerialize` emits a different **5-byte header with no MsgKey and no masking**:

```
b0      CRC7            (seed 0, over Cmd + Length + payload)
b1,b2   Cmd    LE16     raw
b3,b4   Length LE16     raw
b5..    payload
```

Only `Cmd ∈ {1 (UDP_HELLO), 5 (UDP_LONGTIMENOSEE)}` carry a body
(`NeedProxyUnSerialze(cmd) = (cmd & ~4) == 1`). `DestinationIP` is never serialised —
it is consumed by the transport layer.

---

## 9. Decode procedure

```
1. match traffic: 90 <= b0 <= 110
2. hdr = (90 <= b0 <= 99) ? 10 : 8
3. solve (m, HEAD_SECRET) from the capture (section 4) or read SECRET_KEY live
4. unmask bytes b2..hdr-1 with m; read fields in HEAD_SECRET order
5. verify crc7(pkt[2:]) == pkt[1]
6. payload = pkt[hdr : hdr + Length]
7. Flags&2 -> Unzip ; Flags&1 -> TeaDecrypt(SECRET_KEY)
8. plaintext = the untagged positional LEB128 varint body (PROTOCOL_MASTER.md)
```

---

## 10. Reading the live keys (rooted device)

```
klass = *(void**)(libil2cpp_base + 0x0B4D4AB8)      // UDPParameters
sf    = *(void**)(klass + 184)                      // static_fields
SECRET_KEY  = *(void**)(sf + 72)   // byte[]: len @+24, data @+32
HEAD_SECRET = *(void**)(sf + 80)   // int[5]: data @+32
MSG_KEY_MIN/MID/MAX = *(int*)(sf + 104/108/112)
```

`NetworkCryptologyUtil` klass is at `+0x0B4CFCC8`; its `sf + 8/12/16/20` give
`SALT_LEN/ZERO_LEN/DELTA/ROUNDS`.

Verified live (title screen, pid 4693, base `0x400023200000`):
`MIN=90 MID=100 MAX=110`, `SECRET_KEY = 01 02 … 10` (the default `TestKey`),
`HEAD_SECRET = null`. In a real match both are replaced by session values.

---

## 10b. ARCHIVE-WIDE BATTLE TEST

`ffdecode.solve()` was run blind over **every capture in `captures/`** — 229 files,
each a separate session with its own `SECRET_KEY` and its own `HEAD_SECRET`
permutation, none of them supplied to the solver.

| result | count |
|---|---|
| contained match traffic | **199** |
| **solved** | **199 / 199 (100%)** |
| DATALEN fit >= 99% | **199 / 199** — median **100.0%** |
| CRC7 valid >= 99% | **199 / 199** — median **100.0%** |
| sessions with fit < 99% | **0** |
| no match-server traffic (lobby-only/empty) | 30 |

The solver has no failure case in the archive. This is what justifies putting it in
the app as a runtime component: it converges on every session observed, with no key
and no handshake.

---

## 11. LIVE END-TO-END VERIFICATION (2026-09-11, BR match)

Keys read out of the running process mid-match (pointers differed from the
title-screen read, confirming they are session values):

```
SECRET_KEY  = 2b 96 41 85 fe 29 55 c4 fa 7c 7e c6 eb 15 38 89
HEAD_SECRET = [3, 2, 0, 4, 1]  = [Flags, OrderID, SendOption, Length, Cmd]
MSG_KEY_MIN/MID/MAX = 90 / 100 / 110
```

703 packets captured with `tcpdump` on the emulator against
`156.227.242.89:10014`, then decoded:

| test | result |
|---|---|
| blind-solved mask vs live `SECRET_KEY[0]` | **0x2B == 0x2B** |
| blind-solved HEAD_SECRET vs live | **[3,2,0,4,1] == [3,2,0,4,1]** |
| CRC7 | **703 / 703 = 100.0%** |
| **TEA decrypt with live key (7-zero-byte oracle)** | **138 / 138 = 100.0%** |

Decrypted samples:

```
IN  len=50 Cmd=231 plain(29) = 02 db 08 07 a0 99 7f 94 d0 02 cf 83 04 00 00 00 d0 0f 64 64 64 ...
OUT len=24 Cmd=2   plain(2)  = 7b 03          (UDP_ACK, sequence)
```

**The cipher and framing are confirmed correct against live traffic.**

### Solver caveat — 1-byte field ambiguity

`SendOption` and `Flags` are both 1 byte, so swapping them leaves every byte offset
unchanged and the `Length` identity cannot distinguish them. The first solver version
got this wrong on the live session. It is broken with the reliability rule —
`IsReliable` is true iff `SendOption ∈ {1,2,5}`, and MsgKey already tells us whether
the packet is reliable — plus `Flags & ~3 == 0`. With that, blind solving reproduces
the live `HEAD_SECRET` exactly.

---

## 12. What is still missing

**The 16-byte `SECRET_KEY` is not on the wire.** For `UDPSession` it is provisioned
from a config singleton populated over the TCP login channel; for `MUDPSession` it is
negotiated in a handshake whose parser (`HandleRecv`) is **encrypted-at-rest in the
APK** and only exists at runtime.

Consequences:

- **Header framing, packet classification and CRC7 need no key at all** — fully
  solved from a capture. This includes every plaintext family, i.e. the ESP position
  data.
- **Encrypted payloads need `SECRET_KEY`**, obtainable by reading it live (section 10)
  on a rooted device during a match.
- Tested and refuted: the default key `01 02 … 10` does **not** decrypt real traffic.
  24 configurations (that key and its reverse × LE/BE × 16/32 rounds × QQ-chain/CBC/ECB)
  scored **0/300** against a 7-zero-byte oracle. The session key is genuinely in use.
