# The pre-key window at match handover — root cause, measurement, and fix spec

**Status:** specification only. No source file was changed.
**Scope:** `fakelag/fakelag-beta/app/src/main/java/com/fakelag/cryhard8/`
**Supersedes the "not yet fixed" note in** `docs/WHEN_NOTHING_WORKS.md` §4.

---

## 0. The headline, before the detail

The window was framed as *"buffer the unresolved bodies and replay them once the
solver converges."* That works, and §6 specifies it. But the measurement turned
up something that makes the buffer the **fallback** rather than the fix:

> **The header layout does not have to be solved at all.**
> The XOR mask *and* the `HEAD_SECRET` field permutation are both sent to us in
> **plaintext over the lobby TCP downlink**, in the same `tcp.MatchmakingSussNtf`
> message that already gives us the `SECRET_KEY` — and they arrive
> **231–274 ms before the first UDP packet of the new session**, measured on four
> paired lobby/UDP captures.

- `mask = SECRET_KEY[0]` — field 3, the string `LobbyKeySniffer` already scans for.
  **6/6** sessions; already documented in `docs/PROTOCOL_CIPHER.md` §4 and never wired up.
- `HEAD_SECRET` — field 42 (`udp_mask`), a 5-character ASCII permutation of `0`–`4`.
  **4/4** exact agreement with the permutation the solver elects from traffic
  2 seconds later. Named in `net/LobbyKeySniffer.java:48` and
  `net/SessionTimeline.java:47`; **parsed by nothing**.

Adopting that layout at packet 1 reads **every** packet in the window correctly:
the `Length` identity holds on 1 744/1 750 header-bearing records across the four
paired captures, and the 6 failures are packets addressed to the *previous*
session's endpoint (§5.3).

So the fix is three independent pieces, in this order of value:

| | fix | closes | cost |
|---|---|---|---|
| **A** | Seed `HeaderLayout` from the lobby message | the window, entirely, in the normal case | small; one new scan + one setter |
| **B** | Bounded retain-and-reparse of unresolved inbound | the residual case where the lobby message was missed (engine started mid-match) | ~70 KB measured, 256 KB bounded |
| **C** | Reset the solver on key rotation | a second, currently-undocumented hazard: a *stale* layout produces CRC-valid packets with a garbage `cmd` for ~24 outbound packets after a handover (§7) | 3 lines; `PacketPipeline.resolveSession()` already exists and has **no callers** |

---

## 1. Root cause, precisely

### 1.1 The mechanism

`PacketPipeline.observeAndParse` returns `null` while the solver is unconverged:

```java
// net/PacketPipeline.java:189-199
public UdpPacket observeAndParse(byte[] buf, int off, int len, Direction direction) {
    solver.observe(buf, off, len, direction);
    HeaderLayout l = solver.layout();
    if (l == null) return null;                    // <-- :192, the whole window
    ...
}
```

Every inbound consumer that needs a command id is gated on that return being
non-null, at `core/UdpSessionManager.java:213-215` (the call) and `:216-272`
(the `cmd == 1900 || 121 || 118 || 101 || 107 || 139 || 102` switch that feeds
`EspEngine` and `MatchRoster`). While `layout()` is null the switch never runs,
the datagram is forwarded to the game unchanged, and the bytes are gone.

### 1.2 Why the layout is unknown

Both halves of the encoding rotate per game-server session:

- **mask** — one byte, `SECRET_KEY[0]` (`net/HeaderLayout.java:33,68`);
- **`HEAD_SECRET`** — a permutation of the five header fields
  (`net/HeaderField.java:6-20`, `net/PacketCodec.java:47-51`).

Only packet byte 0 (`MsgKey`) is plaintext, and it carries nothing but the
header *size* (`net/MsgKey.java:61-74`). Bytes 2.. are masked and permuted, so
`cmd` and `length16` are unreadable until both are known.

### 1.3 Why convergence is slow

`net/SessionKeySolver.java`:

| constant | line | value | meaning |
|---|---|---|---|
| `VOTE_MIN_PACKETS` | 76 | 64 | **outbound** packets before a mask may be elected |
| `TIE_BREAK_PACKETS` | 78 | 256 | packets (either direction) scored before commit |
| `RESOLVE_FAILURE_RUN` | 80 | 24 | consecutive outbound `Length` failures that mean "session changed" |

`elect()` is only attempted at multiples of 16 at or above 64
(`SessionKeySolver.java:289`), then `scoreCandidates` must see 256 more packets
before `commit()` (`:371-373`). That is ~320 observations minimum, and inbound
packets do not count toward the first 64.

### 1.4 What the window is not

It is **not** a *key* window. The name in `WHEN_NOTHING_WORKS.md` §4 is a
misnomer inherited from §2. The key is already present — see §5.2: it leads the
first UDP packet by a quarter of a second. It is a **pre-layout** window, and
that is the whole reason the fix in §5 is possible.

---

## 2. Method

Measured, not quoted. Everything below is reproducible from the repository.

- **Corpus.** `captures/` holds 330 directories but only **7** contain a v2
  (18-column) `capture_raw_*.txt` with a real match; the rest are the older
  13-column format, or the "wrong app in the tunnel" failure of
  `WHEN_NOTHING_WORKS.md` §1. The 7 are `phone_aim1..7`, all 2026-09-12.
  6 of them reach a solved layout; 1 (`phone_aim2`) starts with the pipeline
  already solved from the previous capture and has no window at all.
- **The `PRESOLVER` flag is the production signal.** `CaptureAnnotator` reads
  `PacketPipeline.current().layout()` (`dev/capture/CaptureAnnotator.java:120-128`)
  and stamps `F_PRESOLVER` + `cmd = -1` when it is null. So the window boundary
  in the capture file *is* the live window boundary, not a reconstruction.
- **Solver port.** `SessionKeySolver` was ported to Python in both its pre- and
  post-2026-09-13 forms and replayed over the capture bytes. It reproduces the
  live convergence packet exactly in all 6 sessions (`seq` 429/436/443/442/1480/319
  against capture `PRESOLVER` boundaries 429/436/443/442/1483/319).
- **TEA / `WireReader` port.** `net/Tea.java` `qqTeaDecrypt` and
  `net/WireReader.java` ported verbatim, then `MatchRoster.observeJoin`,
  `observeKill` and `EspEngine.observeBindPri` reimplemented on top, to decode
  the bodies that were dropped.
- **Keys.** A capture header records the key that was current *at capture start*
  (the trap in `WHEN_NOTHING_WORKS.md` §2). Keys were instead harvested per
  **endpoint** across all capture headers and all `lobby_*.txt` files, which
  yields the correct key for 4 of the 6 sessions.
- Python 3.14, numpy 2.4.6, pandas 3.0.5 present; only stdlib was needed.
  Scripts named by hypothesis, in the session scratchpad:
  `h1_window.py h3b_solver.py ffwire.py h6_gain.py h7_roster_sim.py h8_bound.py`
  plus the lobby probes `h9`–`h13`.

---

## 3. Measured cost

### 3.1 Window size — 6 sessions

| capture | window | inbound lost | bytes lost | records (both dirs) |
|---|---|---|---|---|
| `20260912_143420` | 1 347 ms | 212 | 43 963 (42.9 KB) | 423 |
| `20260912_150936` | 2 631 ms | 221 | 44 837 (43.8 KB) | 436 |
| `20260912_154937` | 1 517 ms | 223 | 48 160 (47.0 KB) | 443 |
| `20260912_155922` | 1 750 ms | 220 | 46 304 (45.2 KB) | 442 |
| `20260912_161312` | 2 321 ms | 228 | 67 973 (66.4 KB) | 440 |
| `20260912_162908` | 1 086 ms | 0 | 0 | 319 (all outbound) |

**Window duration 1.1–2.6 s; 212–228 inbound packets; 43–66 KB.** The
`WHEN_NOTHING_WORKS.md` §4 figure of "224 inbound packets in one second" was one
session and it generalises: the packet count is almost invariant (mean 220.8,
σ ≈ 5.6) because the window is bounded by the solver's own packet constants, not
by time. The *duration* is what varies — it stretches when outbound is sparse
(the 79 s figure visible in a naive scan of `20260912_161312` is a capture that
began in matchmaking; the match-server portion of that window is still only
2 321 ms).

### 3.2 What is lost, by command — aggregate over all 6 sessions

Inbound, match server only, `cmd` recovered offline with the correct layout.

| cmd | name | lost | delivered | **live coverage** |
|---|---|---|---|---|
| **101** | `RUDP_PLAYER_JOIN` | **121** | 31 | **20.4 %** |
| 99 | `RUDP_SPLITTED_DATAGRAM` | 22 | 17 | 43.6 % |
| **118** | `RUDP_BIND_PRI` | **29** | 456 | 94.0 % |
| 2038 | `UDP_PLAYER_STATE_SYNC_WAITINGPHASE` | 18 | 367 | 95.3 % |
| 2 | `UDP_ACK` | 68 | 1 680 | 96.1 % |
| 121 | `RUDP_EQUIPMENT_CHANGED` | 52 | 2 885 | 98.2 % |
| 107 | `RUDP_DEAD` | 3 | 224 | 98.7 % |
| **1900** | `RUDP_VAR_SYNC_PRI_DATA` (health) | 61 | 15 509 | 99.6 % |
| 102 / 139 | quit / knockdown | 0 | 36 | 100 % |
| **2001 / 2012** | **position streams** | **0** | **10 153** | **100 %** |

Two facts decide the rest of this document.

1. **`RUDP_PLAYER_JOIN` is catastrophically affected and nothing else is.**
   It is a one-shot burst at match start that lands squarely inside the window.
   Four fifths of it is thrown away.
2. **The position streams lose nothing — zero packets, in every session.**
   Cmd 2001/2012 have not started yet when the window is open, *and* the ESP's
   position feed is shape-gated and layout-independent anyway
   (`core/UdpSessionManager.java:326-338`, `observeChainPacket` /
   `observeSmallInbound` / `observeDamage` / `observeHandleEvent`). This is why
   the consumer allow-list in §8 costs nothing.

### 3.3 Packet counts understate the damage — measure distinct entities

`Cmd 118` looks fine at 94 % of *packets*. It is not fine at all, because the
binds are not spread across the match — the authoritative burst is in the window
and the later messages re-state a handful of the same owners. Decoding the
bodies (2 sessions with a recovered key):

| capture | distinct 118 binds delivered live | union with the window | live coverage |
|---|---|---|---|
| `20260912_143420` | 5 | 22 | **23 %** |
| `20260912_155922` | 4 | 22 | **18 %** |

**About four fifths of the authoritative owner→entity binds are lost**, against
a packet-count figure that says 94 % survived. Any future measurement of this
channel must count *distinct entities*, never packets.

### 3.4 Roster coverage on the `42/53` terms

Full `MatchRoster` simulation — Cmd 101 joins **plus** Cmd 107/139 kill-notice
recovery, exactly the metric behind the documented 42/53 = 79 %:

| capture | live-only | with the window recovered |
|---|---|---|
| `20260912_143420` | 20/23 = **87 %** | 23/23 = **100 %** (+3) |
| `20260912_155922` | 13/22 = **59 %** | 22/22 = **100 %** (+9) |

Both are Clash Squad (22–23 players). The documented 79 % came from a 53-player
BR match; the spread here (59–87 %) brackets it, and confirms the baseline
generalises rather than being a one-off.

---

## 4. Is a retained packet still decodable later? **Yes — nothing is time- or sequence-dependent.**

This is the load-bearing question for §6, and it resolves cleanly on all four
components.

| component | state it carries | verdict |
|---|---|---|
| `MsgKey` framing | none — pure function of byte 0 (`net/MsgKey.java:61-74`) | replayable |
| CRC-7 | computed over the transmitted bytes (`net/Crc7.java:73-75`); explicitly **stays valid across keys** (`net/PacketPipeline.java:48-52`) | replayable |
| `HeaderLayout` parse | pure function of `(mask, permutation, bytes)` (`net/PacketCodec.java:36-57`) | replayable |
| TEA body | QQ-TEA CBC chain is **contained inside one message** (`net/Tea.java:127-162`): block 0 seeds the chain, the 7-zero tail closes it. No cross-packet IV, no counter | replayable |
| key lookup | `BodyCrypt.schedule()` reads `LobbyKeySniffer.lastKeyHex()` (`net/BodyCrypt.java:35-51`) — the **latest** key, not the packet's | **the one hazard; see below** |

**Empirical confirmation.** Re-parsing all **1 104** lost inbound packets with
the layout the solver later elects gives:

- `Length` identity `len16 == len - headerSize`: **1 104 / 1 104**, zero failures;
- `Flags` ∈ {0, 1} on every one — never the phantom `ZIPPED` bit of §3 of
  `WHEN_NOTHING_WORKS.md`;
- TEA decrypt of the retained Cmd 101/118 bodies: **121 / 121** successful,
  producing valid nicknames and type-1 binds.

**The hazard, and its fix.** `BodyCrypt` is keyed on "the last key seen by any
instance". A buffer that outlives a key rotation would decrypt its contents with
the *next* match's key, and the 7-zero tail check would reject it — a silent
loss, not a corruption, but still wrong. The buffer must therefore be **stamped
with the session identity it was captured under** (endpoint + key hex) and
**discarded, never replayed, if that identity has changed** (§6.4).

---

## 5. The better fix: take the layout from the lobby

### 5.1 The permutation is on the wire, in ASCII

`tcp.MatchmakingSussNtf` field 42 (`udp_mask`) is a 5-character ASCII string
listing the `HeaderField` ids in wire order. Measured against the permutation
elected independently from UDP traffic by the post-fix solver:

| match server | `SECRET_KEY[0]` | solver mask | field 42 | solver permutation | agree |
|---|---|---|---|---|---|
| `148.222.80.83:10012` | `0x6C` | `0x6C` | `32014` | `(3,2,0,1,4)` | yes |
| `148.153.206.156:10013` | `0x6A` | `0x6A` | `32041` | `(3,2,0,4,1)` | yes |
| `148.222.80.41:10013` | `0xF3` | `0xF3` | `32401` | `(3,2,4,0,1)` | yes |
| `148.222.80.22:10012` | `0x87` | `0x87` | `03412` | `(0,3,4,1,2)` | yes |

**4/4 on both halves.** Two further sessions (`148.153.206.168:10012` →
`04231`, `162.128.80.10:10013` → `32041`) carry the same field with no paired
UDP capture to check against.

The digits index `HeaderField` by ordinal (`net/HeaderField.java:22-33,52-55`),
so `"32014"` is `[FLAGS, ORDER_ID, SEND_OPTION, CMD, DATA_LEN]` and feeds
`new HeaderLayout(mask, order)` directly.

### 5.2 It arrives before the first UDP packet — and it must

| capture | key seen on lobby TCP | first UDP to the match server | lead | lead over convergence |
|---|---|---|---|---|
| `phone_aim1` | `…698095` | `…698369` | **274 ms** | 1 621 ms |
| `phone_aim3` | `…796468` | `…796735` | **267 ms** | 2 898 ms |
| `phone_aim4` | `…199668` | `…199899` | **231 ms** | 1 748 ms |
| `phone_aim5` | `…784494` | `…784738` | **244 ms** | 1 994 ms |

This is not luck, and it does not need to be re-confirmed per build: **field 2
of that same message is `server_addr`.** The client cannot address the match
server before it has read the message that names it, so the key and the
permutation are *necessarily* known before the first UDP byte of that session.
The measured 231–274 ms is just the client's own setup latency.

### 5.3 Adopting it at packet 1 reads the whole window

Applying the lobby-declared `(mask, permutation)` from the first packet of the
capture, `Length`-identity fit:

| capture | inside the window | after convergence |
|---|---|---|
| `phone_aim1` | 423 / 429 | 8 118 / 8 118 |
| `phone_aim3` | 436 / 436 | 4 018 / 4 018 |
| `phone_aim4` | 443 / 443 | 6 878 / 6 878 |
| `phone_aim5` | 442 / 442 | 3 037 / 3 037 |

The 6 misses are `seq 0-5` of `phone_aim1`, all addressed to
`148.222.88.163:10011` — the **previous** session's endpoint, correctly refused
by a layout scoped to `148.222.80.83:10012`. Which is the design note: the
layout is per-endpoint, and field 2 of the same message tells us which endpoint.

### 5.4 Fix A — specification

**Where.** `net/LobbyKeySniffer.java` (recovery) → `net/PacketPipeline.java`
(adoption). Fed from the existing call at `core/TcpProxy.java:282`; no new
plumbing.

**Recovery.** In `LobbyKeySniffer.scan` (`:200-254`), alongside the existing
`0x12 <len> "<ip>:<port>"` / `0x1A 0x20 <32 hex>` adjacency, add a second,
independent signature scan:

```
D2 02 05 <5 bytes, each in '0'..'4', all distinct>      // field 42, len-delimited
```

*Specificity, measured:* over **3 086 lobby frames / 2.1 MB** of real downlink,
that pattern matched **7 times and all 7 were inside a key-carrying frame — zero
false positives.** The `"find a 32-char hex string"` trap that produced 13 false
positives (`LobbyKeySniffer.java:32-36`) does not recur here: the constraint is
~64 bits.

*Why a separate scan and not an adjacency.* Field 42 sits **2 125–5 060 bytes**
after the key field in the same frame. The class deliberately does not
reassemble frames (`:19-24`), and the 96-byte carry (`:71-79`) cannot span that.
Scan each read independently; the existing carry already covers the 8-byte
signature straddling a read boundary. Attach the most recent permutation and the
most recent key to the endpoint they were seen with.

**Adoption.** Add to `PacketPipeline`:

```java
/** Seeds the layout from the lobby message instead of solving it. */
public void seedLayout(int mask, HeaderField[] order, String endpoint);
```

Rules, in order:

1. Build the `HeaderLayout`; on `IllegalArgumentException`
   (`net/HeaderLayout.java:35`) ignore and fall through to voting.
2. Install it **provisionally**. `isReady()` stays false until it is confirmed.
3. **Confirm on the wire before trusting it.** The `Length` identity is free and
   per-packet (`SessionKeySolver.checkIdentity`, `:434-447`). Require **8
   consecutive outbound successes**; the solver's existing 24-failure rule then
   governs abandonment. Measured, the true layout scores 100 % of outbound, so
   8 costs ~50 ms; a wrong one fails on the first packet.
4. Parse with the provisional layout from packet 1 **but only dispatch to
   consumers once confirmed** — otherwise a hypothetical bad seed feeds garbage
   commands into `MatchRoster`. In practice confirmation lands well before the
   Cmd 101 burst.
5. If no seed arrives (engine started mid-match, or the lobby socket was not
   proxied), the solver runs exactly as today and Fix B covers the window.

**Do not delete the solver.** It is the only path when the engine starts
mid-match, and step 3 uses its identity check. Keep the OrderID tie-break: it is
what makes the fallback correct.

---

## 6. Fix B — the retain-and-reparse buffer

Needed only when Fix A has no seed. Specified fully because that case is real:
every capture in the corpus is one (the engine was started after matchmaking).

### 6.1 Name it so it cannot be confused with the existing one

The package `replay/` already exists and means **re-transmitting packets onto
the network** (`replay/ReplayEngine.java:50-52`, `filter/TeleportFilter`,
`filter/FreezeFilter`). This feature must not live there and must not use that
word in its type names. Use `net/PendingHeaderBuffer` and the verb **reparse**.

### 6.2 Where it lives

In `PacketPipeline`, because that is the one place that knows the transition
from "no layout" to "layout" and is already shared by both transport loops
(`core/PacketLoop.java:147` outbound, `core/UdpSessionManager.java:213` inbound).

```java
// PacketPipeline
public interface ReparseSink { void onReparsed(UdpPacket p, Direction dir); }
public void setReparseSink(ReparseSink sink);   // VpnEngine installs one
```

`observeAndParse` gains a single branch at the existing `if (l == null)`:

```java
if (l == null) {
    if (direction == Direction.INBOUND) pending.retain(buf, off, len, sessionTag);
    return null;
}
```

and the transition to non-null (both in `SessionKeySolver.commit()` via a
callback, and in `seedLayout` confirmation) drains it.

### 6.3 Bound and eviction

Measured inputs:

- window need: **228 packets / 66.4 KB** worst observed;
- largest inbound match packet: **1 258 B**;
- worst 1-second inbound match-traffic burst in the corpus: **549 packets / 64.3 KB**.

| bound | value | why |
|---|---|---|
| bytes | **256 KB** | 3.9× the worst observed window; ~4 s of the worst measured burst |
| packets | **768** | 3.4× the worst observed window; above one worst-case second |
| age | **10 s** | ~4× the longest measured window; a window longer than this means the solver is not converging, and stale roster data has no value |

**Storage.** One flat `byte[256*1024]` arena plus a parallel index of
`(offset, len, rxMs)` — not 768 small arrays. The insert is on the per-session
receive threads (`UdpSessionManager.RecvRunnable`), so it must be `synchronized`
like `replay/PacketBuffer`, and it must **copy**: `pkt.getData()` is the reused
`rbuf` of the receive loop.

**Eviction policy: oldest-first, and this matters.** The valuable content is the
*front* of the window (the Cmd 101 burst at match start); the tail is ACKs. But
oldest-first is still correct, because hitting the bound at all means the window
has become pathological and the roster burst is long gone. Do **not** use
`tryAdd`-style refusal (`replay/PacketBuffer.java:65-73`): a full buffer that
refuses new packets would freeze on lobby junk. Count evictions and surface them
in `PacketPipeline.describe()` — a non-zero count is a bug report.

**Filtering at insert.** Retain only what `MsgKey.headerSizeOf` accepts
(`net/MsgKey.java:68-74`). This is free and it is what kept the buffer at **0
packets** in the "wrong app in the tunnel" capture (`capture_raw_20260913_142129`,
10 886 inbound packets over 170 s, never converges) — all of it is foreign UDP
outside the `MsgKey` range. Confirmed by replay: the buffer never allocates in
that failure mode.

### 6.4 What happens when convergence never comes

Four exits, all of which must free the arena:

1. **Age.** Any entry older than 10 s is dropped on the next insert. A
   never-converging session therefore holds at most 10 s of traffic and then a
   steady state, never a leak.
2. **Session change.** Each entry carries a `sessionTag` = the
   `(endpoint, keyHex)` current at capture. On a key rotation
   (`LobbyKeySniffer.java:242-243` already computes `rotated`) **discard the
   whole buffer**. Do not attempt to reparse across a rotation: §4 shows the
   body would fail its TEA tail check anyway, and the header mask is different.
3. **Solver give-up.** `SessionKeySolver` already abandons a tally at
   `VOTE_GIVEUP_PACKETS = 4096` (`:82, :281-288`). Clear the buffer on the same
   event — if the solver has thrown away 4 096 outbound packets of evidence,
   the retained inbound belongs to a session that no longer exists.
4. **Tunnel teardown.** `PacketPipeline.reset()` (`:133-140`) must free the
   arena, and `VpnEngine` already calls the surrounding resets at `:432` / `:459`.

### 6.5 The drain

At the instant the layout becomes non-null, **before** the packet that caused
convergence is itself dispatched:

1. Take the buffer under its lock and snapshot it (so a concurrent insert cannot
   interleave).
2. Walk it **in capture order**, `PacketCodec.parse` each entry with the new
   layout, drop anything whose CRC-7 fails (the same gate the live path applies
   at `UdpSessionManager.java:222`), and offer it to the sink.
3. Only then resume the live path.

This ordering is what makes the consumer analysis in §8 tractable: every
reparsed packet precedes every subsequent live packet, and the reparsed packets
are in wire order among themselves. **Global order is preserved exactly**, so no
consumer sees an inversion it would not have seen on a healthy wire.

**Re-arming.** `EspEngine.resetMatch` (`:1700-1729`) clears `roster` and `pri`,
and is driven by the shape-gated chain stream (`:940-945`). If it fires *after*
the drain it wipes the recovered roster, and Cmd 101 never comes again. The
buffer must therefore be **retained after the drain, within the same
`sessionTag`**, and re-drained if `EspEngine` clears match state before the age
bound expires. This is cheap (the arena is already held) and it also repairs
roster loss from any spurious mid-match reset — the failure mode that made the
2026-09-13 `0873617` regression so destructive (789 resets in 109 s).

---

## 7. Fix C — the stale-layout hazard, found while specifying the above

Not in the original brief, cheap, and strictly worse than the window it sits next to.

`PacketPipeline.resolveSession()` (`:147-150`) exists to abandon a layout at a
known session change. **It has no callers.** The only session-change detectors
in production are reactive:

- `SessionKeySolver.checkIdentity` — `RESOLVE_FAILURE_RUN = 24` consecutive
  **outbound** `Length` failures (`:434-447`);
- `PacketPipeline.noteChecksum` — `CRC_FAILURE_RUN = 256`, which cannot fire
  here at all, because CRC-7 stays valid across keys (`:44-55`).

So after a handover the **old** layout stays committed for 24 outbound packets.
During that time `PacketCodec.parse` returns a packet whose CRC is valid
(CRC-7 is layout-independent) and whose `cmd` is garbage — and
`UdpSessionManager.java:222` trusts `cmd` on exactly that condition. Meanwhile
`BodyCrypt` already holds the **new** key, so the body decrypts correctly. The
result is a correctly-decrypted body handed to the **wrong decoder**.

That is a corruption, not a loss, and it is worse than the window.

Measured outbound rate at match start is 145–157 packets/s (211–220 outbound
packets across the 1 347–1 517 ms windows), so 24 outbound is roughly
**155–165 ms**, or about **20–25 inbound packets mis-dispatched per handover**.
No capture in the corpus exercises a handover *within* one tunnel session — every
capture begins with a fresh, unsolved pipeline — so this figure is derived, not
observed. §12 names the capture that would confirm it.

**Fix.** `LobbyKeySniffer` already computes `rotated` (`:242-243`) and already
notifies `SessionTimeline.onSessionKey(hex, ep, rotated)` (`:245`, handler at
`net/SessionTimeline.java:469-481`). Call
`PacketPipeline.current().resolveSession()` on `rotated`. With Fix A in place,
the same event carries the *new* layout, so the sequence becomes
"drop old layout, install new layout" with no unsolved interval at all.

---

## 8. The consumer allow-list

### 8.1 The rule

> **A consumer may receive reparsed packets if and only if its state is a
> function of packet *content* alone. A consumer whose state is a function of
> packet *arrival time* — or which is already fed by a layout-independent path —
> must not.**

The second clause is not a refinement of the first; it is an independent veto.
`VpnEngine.java:93-101` records why:

> *"registering it while `PacketLoop` and `UdpSessionManager` still run their own
> shape-gated feeds would hand `EspEngine` every position twice — duplicate
> samples at a zero time delta, straight into dead reckoning."*

A reparse sink that fed positions would recreate that bug, not from
double-registration but from double-*time*.

### 8.2 The list

| consumer | call site | verdict | reason |
|---|---|---|---|
| `MatchRoster.observeJoin` (101) | `UdpSessionManager.java:252` | **ALLOW** | `names.put(slot, nick)` is a pure content map (`MatchRoster.java:125-138`). No clock. |
| `MatchRoster.observeKill` (107/139) | `:253-254` | **ALLOW** | guarded by `containsKey` (`:110`); idempotent. |
| `MatchRoster.observeQuit` (102) | `:255` | **ALLOW — but only under §6.5 ordering** | it *removes* (`:116-123`). Order matters: a reparsed JOIN landing after a live QUIT resurrects a departed player. The §6.5 drain (all reparsed packets, in wire order, before any further live packet) makes this safe. It is **not** safe under a lazy or interleaved drain. |
| `EspEngine.observeBindPri` → `PriTracker.onBind` (118) | `:251` | **ALLOW** | `onBind` (`PriTracker.java:348-372`) writes `slotSquad`, `owners`, `byHandle` from body content only. `votes = Integer.MAX_VALUE` makes an authoritative bind terminal, so a later live bind cannot be demoted by a reparsed one. No clock. |
| `EspEngine.observeEquipment` (121) | `:250` | **DENY** | `PriTracker.onEquipment(handle, vals, n, nowMs)` correlates two Cmd 121 messages **within `EQUIP_MS` of each other** (`PriTracker.java:280`, `matchEquip` at `:301-316`). Reparsing collapses every gap to ~0 ms and manufactures correlations that did not happen. It is also only a *heuristic* for the binding that Cmd 118 states outright — and 118 is on the allow-list, so denying 121 costs nothing. |
| `EspEngine.observePriSync` (1900, health) | `:249` | **DENY by default** | `PriTracker.onProperty(owner, varId, value, nowMs)` timestamps every property (`:192`) and `hpFor(handle, nowMs)` (`:441`) reads them against the clock. Health is *latched*, not polled (`SESSION_2026-09-13.md`), so a reparsed 1900 would stamp a 2-second-old HP as current. **And it buys nothing: measured live coverage is 99.6 %** (§3.2). If it is ever wanted, pass the packet's captured `rxMs` rather than `System.currentTimeMillis()`; do not reparse it with a synthetic now. |
| `EspEngine.observeChainPacket` / `observeSmallInbound` / `observeDamage` / `observeHandleEvent` (positions, damage) | `:326`, `:328`, `:333`, `:338` | **DENY, absolutely** | Two independent reasons. (a) These are **shape-gated and layout-independent** — they already ran on every packet in the window, so a reparse is a literal double-feed of the exact bug `VpnEngine.java:97` warns about. (b) `updateTrack` → `updateVelocity` (`EspEngine.java:1162, 1230-1259`) computes `dt = now - t.prevMs` and unconditionally writes `t.prevX/Y/Z` and `t.prevMs = now` at `:1258`. The `VEL_DT_MIN_MS = 185` / `VEL_DT_MAX_MS = 260` gate (`:289-290`) would reject the reparsed *sample*, but the assignment at `:1258` happens **outside** the gate, so the next genuine tick would see a corrupted `prevMs` and a corrupted baseline. Measured loss on these commands in the window: **zero packets, all six sessions.** |
| `PacketPipeline.dispatch` → `BodyDecoderRegistry` | `:273` | **DENY** | `EspBodyDecoders` registers the *position* decoders (`EspBodyDecoders.java:54-55`) and is currently uninstalled. Routing reparse through `dispatch` would silently re-enable the denied class the day someone calls `install()`. Reparse must target the explicit `cmd` switch, never the registry. |
| `aimExperiment.observe` | `:274` | **DENY** | an A/B timing harness; injecting a batch of stale observations invalidates the experiment. |
| `SessionTimeline.observeUdp` | `:280` | **DENY** | a phase machine over arrival order and wall-clock (`:487-489`). Replaying match-start packets after the phase has already advanced would drive it backwards. |
| `filterEngine.onInbound` | `:286` | **DENY** | it decides whether to *forward a datagram to the game*. The datagram was already forwarded. See §9. |
| `capture().recordInbound` | `:340` | **DENY** | the capture already recorded these packets once, flagged `F_PRESOLVER`. Re-recording would double-count. Instead, emit **one** capture event summarising the drain (`n` packets, `bytes`, per-cmd counts) so the window becomes visible in the footer. |

**Net allow-list: Cmd 101, 102, 107, 118, 139.** Exactly the roster and
authoritative-bind channels — which is also, per §3, the only place the loss
actually hurts.

---

## 9. Reparse must never touch the network

Stated so it cannot be misread:

> **These are inbound datagrams that the tunnel has already written to the tun
> interface and the game has already received.** Reparsing means decoding a
> retained *copy* into our own state. It must not re-inject anything into the
> tunnel, must not call `PacketBuilder.buildPkt`, must not write to `out`, and
> must not touch `filter/PacketSender` or `replay/ReplayEngine`.

Concretely, the reparse path must not reach:

- `core/UdpSessionManager.java:351-354` — `PacketBuilder.buildPkt(...)` +
  `out.write(ip)`, the tun writer;
- `filterEngine.onInbound` (`:286`) — the forward/drop decision;
- anything in `replay/` — `ReplayEngine.replayPacketList` (`:54`) sends through
  `PacketSender` to the real socket. That package's meaning of "replay" is the
  opposite of this one, which is why §6.1 forbids reusing the word.

**And the related hard rule, which this feature must not be mistaken for a way
around.** Injecting a *reliable* message desynchronises the server's OrderID
window and drops the session:

- `docs/SERVER_VALIDATION_MODEL.md` §5 — *"we cannot mint an OrderID the game's
  own reliability layer has not issued. Rewrite-in-place of an already-issued
  packet keeps its OrderID and is safe."*
- `docs/VALIDATION_AND_INBOUND.md` §C — *"Do not, on the reliable channel."*
- `docs/CLIENT_AUTH_SURFACE.md:61` — *"you may rewrite in place but never inject
  or withhold (the documented desync-kick)."*

Every command on the allow-list in §8 — 101, 102, 107, 118, 139 — is
**reliable**. A reparse implementation that re-sent them would be the exact
kick mechanism the corpus already documents.

---

## 10. Did the OrderID tie-break shorten the window? **No. Not by one packet.**

The brief asked whether the recent OrderID monotonicity tie-break
(`WHEN_NOTHING_WORKS.md` §3) may already have closed this. It did not, and the
answer is provable two ways.

**From source.** The change (commit `bc0c8bf`, 2026-09-13, +56 −3 in
`SessionKeySolver.java`) adds `orderScore` accumulation inside
`scoreCandidates` and reorders the comparison in `commit()`. It touches neither
`VOTE_MIN_PACKETS` (64) nor `TIE_BREAK_PACKETS` (256) nor the `elect()`
schedule. It changes **which candidate wins**, never **when the vote closes**.

**From captures.** Both solver forms were replayed over the same bytes:

| capture | pre-fix commit | post-fix commit | permutation differs |
|---|---|---|---|
| `20260912_143420` | seq 429, t+29.52 s | seq 429, t+29.52 s | yes — `(2,3,0,1,4)` vs `(3,2,0,1,4)` |
| `20260912_150936` | seq 436, t+2.63 s | seq 436, t+2.63 s | yes |
| `20260912_154937` | seq 443, t+1.52 s | seq 443, t+1.52 s | yes |
| `20260912_155922` | seq 442, t+1.75 s | seq 442, t+1.75 s | no |
| `20260912_161312` | seq 1480, t+79.12 s | seq 1480, t+79.12 s | no |
| `20260912_162908` | seq 319, t+1.09 s | seq 319, t+1.09 s | no |

**Identical convergence packet and identical convergence time in all six.** The
fix was necessary and it is correct — in 3 of 6 sessions the pre-fix solver
elects a permutation with `ORDER_ID` and `FLAGS` swapped, which is the ~49 %
phantom-`ZIPPED` bug — but it is orthogonal to this window.

> **Caveat, stated plainly.** All usable v2 captures are from 2026-09-12; the
> OrderID fix shipped 2026-09-13 15:31. The only 09-13 capture on disk,
> `pull_20260913/capture_raw_20260913_142129.txt`, is both pre-fix by clock
> (14:21) and a "wrong app in the tunnel" failure (`out=1 in=10886 foreign=10887`).
> The comparison above is therefore a faithful **replay** of both solver forms
> over real bytes, not two live builds. Given that the constants are untouched,
> a live A/B would be measuring the same arithmetic.

---

## 11. Expected improvement

Against the documented **42/53 = 79 %** baseline and measured on the corpus:

| metric | now | with Fix A | with Fix B alone |
|---|---|---|---|
| Cmd 101 packets delivered | 20.4 % | ~100 % | ~100 % |
| Distinct players named (joins + kill recovery) | 59–87 % measured, 79 % documented | **100 %** | **100 %** |
| Distinct Cmd 118 authoritative binds | **18–23 %** | **100 %** | **100 %** |
| Cmd 1900 health packets | 99.6 % | ~100 % | 99.6 % (1900 is denied, §8) |
| Position samples | 100 % | 100 % | 100 % (denied, and nothing is lost) |
| Window duration | 1.1–2.6 s | **0 ms** | 1.1–2.6 s, then recovered |

**Friend/foe.** `docs/FRIEND_FOE_AUTHORITATIVE.md:532` measures the entire
residual error of the new classifier as *"0 enemies blue, 12.43 % of samples
friend-red, of which 99.6 % is the single teammate whose Cmd 118 bind was lost
to the pre-key window."* §3.3 shows that bind loss is not one teammate in one
match — it is **77–82 % of all authoritative binds, every match.** Recovering
them removes the mechanism behind that residual outright rather than patching
around it with the Cmd 101/107/139 fallback that doc proposes. (Both should
still be wired: the roster path is independent, and §8 allows it.)

**Health binding.** Cmd 1900 loses almost nothing directly (99.6 %), but HP is
only *usable* once the owner is bound to an entity. Restoring binds from ~20 %
to 100 % is what lifts health coverage, exactly as `ESP_HEALTH_AND_NAMES.md`
predicts — the win comes through 118, not through 1900.

---

## 12. What captures alone cannot settle

| # | question | why it is open | the capture that settles it |
|---|---|---|---|
| 1 | Does field 42 always carry `HEAD_SECRET`, on every mode and region? | 6 samples, one region, mostly Clash Squad. The default-order fallback exists in the game (`HeaderField.java:82-85`), so a session with the field **absent** must be possible. | Any `lobby_*.txt` from BR, from a second region, and across a mid-session re-key. Fix A already degrades correctly (fall through to voting), so this is a coverage question, not a correctness one. |
| 2 | Is field 42 ever a *hex* string rather than decimal digits? | `PROTOCOL_CIPHER.md:66` documents the parser as `NetworkUtils.ParseUDPHeadSecret(hexString)`. All 6 observed values are ASCII `0`–`4`, consistent with both readings. | Settle in the binary, not a capture: decompile `ParseUDPHeadSecret` in `libil2cpp_dec.so`. Until then the §5.4 signature must require all five bytes in `'0'..'4'` and reject anything else. |
| 3 | The §7 stale-layout corruption rate | No capture contains a handover *within* one tunnel session; every one starts with a fresh pipeline. | One capture spanning **two consecutive matches without stopping the tunnel**. Look for a run of CRC-valid packets whose `length16` disagrees with the wire length, between the last packet of match 1 and the solver's re-commit. |
| 4 | Whether a mid-match `resetMatch` really wipes a reparsed roster (§6.5) | Requires the boundary detector to fire after a drain; not observed in a healthy capture. | Any capture with a Clash Squad round transition plus `esp` debug output showing `roster.reset()` after convergence. |
| 5 | Keys for `148.153.206.156:10013`, `148.222.80.41:10013`, `148.222.88.204:10012` | Their capture headers say `secret_key=UNKNOWN` (written at capture start) and no paired lobby file survives for the last. §3.3/§3.4 are therefore exact on 2 of 5 sessions and packet-count proxies on the rest. | Nothing new is needed going forward — `LobbyKeySniffer` records per-endpoint keys. Retrospectively, unrecoverable. |
| 6 | Whether the buffer bound is right for BR with 50+ players | The one BR-shaped window in the corpus (`20260912_161312`, 228 packets / 66.4 KB) is the largest, but it is a single sample. | Three BR match-start captures. The §6.3 bound has 3.4–3.9× headroom over it; re-check the eviction counter rather than re-deriving the bound. |

---

## 13. Reproducing the measurements

Scripts are in the session scratchpad, named by hypothesis. They read
`captures/**/capture_raw_*.txt` and `captures/**/lobby_*.txt` directly; no build
is required.

| script | hypothesis |
|---|---|
| `h1_window.py` | the `PRESOLVER` flag delimits the production window |
| `h3b_solver.py` | faithful port of `SessionKeySolver`, pre- and post-fix |
| `ffwire.py` | ports of `Tea.qqTeaDecrypt`, `WireReader`, `MatchRoster`, `observeBindPri` |
| `h6_gain.py` | per-command loss and re-parse validity with the elected layout |
| `h7_roster_sim.py` | roster coverage live-only vs live+reparse, on the 42/53 terms |
| `h8_bound.py` | buffer occupancy, fill rate, and the never-converges case |
| `h9`–`h13` | lobby key/permutation recovery, timing lead, signature specificity |

Two rules that cost time if ignored, both already in `WHEN_NOTHING_WORKS.md`:
read the capture **footer** (`by_dir`, `coverage`) before analysing anything, and
never trust the `secret_key=` header line — it is written at capture start.

---

## 14. Related

- `docs/WHEN_NOTHING_WORKS.md` §4 — the original report; §2 and §3 for the two
  adjacent failure modes this is routinely confused with
- `docs/FRIEND_FOE_AUTHORITATIVE.md` §3.3 — the 12.43 % residual this closes
- `docs/ESP_HEALTH_AND_NAMES.md` — where names and HP live, and the id joins
- `docs/PROTOCOL_CIPHER.md` §3–§4 — `HEAD_SECRET` and `m = SECRET_KEY[0]`
- `docs/SERVER_VALIDATION_MODEL.md` §5 / `docs/VALIDATION_AND_INBOUND.md` §C —
  why nothing here may be re-injected
