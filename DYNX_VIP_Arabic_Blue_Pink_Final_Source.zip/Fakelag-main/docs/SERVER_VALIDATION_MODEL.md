# Server validation model — what stops a manipulated field

**The question:** when the client sends a manipulated field in a live match (BR/survival
and Clash Squad), *what stops it?* For each class of client-sent data this doc records
the check the server applies (or does not), what it does on a violation, and therefore
which manipulations "100% work" versus which get corrected or get the player kicked.

Sibling deliverable: a separate agent enumerates the outbound SEND surface (the fields
we *could* rewrite). This doc supplies the other half — the **verdict** on whether each
survives. The two are meant to be cross-read; verdicts here are keyed to a specific
field of a specific message so they attach to that agent's rows.

Scope: **in-match only**. No lobby `proto.*`. "CS" = Clash Squad in RUDP (not the
real-money `proto.CSPurchaseReq` store — IL2CPP_FINDINGS §7.1).

Last updated 2026-09-12. Read-only survey; no code was changed.

---

## 0. How to read a verdict — the evidence discipline

The binary is **client-side only**. We cannot read the server, so every server check is
**inferred**, and each verdict names the inference it rests on. Basis codes (from the
brief):

- **(a) reconciliation** — the client has an inbound handler that receives the server's
  correction/rejection. A handler that overwrites your own state is proof the server
  asserts authority over that field.
- **(b) measured wire** — a capture shows what actually happens (accept / snap-back /
  freeze / disconnect).
- **(c) client plausibility code** — client-side logic that mirrors what the server
  almost certainly re-checks (e.g. the headshot-downgrade gate, "price never leaves the
  server").
- **(d) transport framing** — a forged packet must satisfy CRC-7 / header mask / TEA /
  the reliability window before any field is read at all.

Confidence tags used below: **MEASURED** (from captures), **INFERRED** (from client
code), **ASSUMED** (neither — flagged as an open experiment). No verdict asserts a
server check we did not evidence.

Verdict vocabulary:

| verdict | meaning |
|---|---|
| **USABLE** | server trusts the field (self-affecting); the manipulation takes effect |
| **CORRECTED** | server overrides it — silent correct / snap-back / reject-and-ignore; harmless but useless |
| **KICK-RISK** | the manipulation desyncs transport or trips a guard that disconnects you — a trap, not an exploit |

| **INERT** | takes effect only on your own client; the server never believed the value, so nothing changes for anyone else |

---

## 1. Layer 1 — the TRANSPORT GATE (outermost; runs before any field is read)

A datagram that fails any transport check is discarded before the body is parsed, so
**any forgery must reproduce all of these**. Spec: `PROTOCOL_MASTER.md` §1,
`docs/PROTOCOL_CIPHER.md`, memory `ff-udp-framing-solved`.

| # | check | what a forged/edited packet must satisfy | can WE satisfy it? | basis |
|---|---|---|---|---|
| 1 | **CRC-7** `packet[1] == crc7(packet[2:], seed 0)` (poly 0x09) | recompute over bytes 2..end after any edit at offset ≥2 | **YES** — no key needed; verified 25 596/25 596. **But shipped Ghost/Freeze/Tele do NOT recompute it** — a prime suspect for teleport rejections | (b)(d) |
| 2 | **Header field XOR mask** — every header byte ≥2 XORed with single byte `m = SECRET_KEY[0]` | know `m` | **YES** — recoverable from OUT len-24 packets with no key, or from the TCP-sniffed SECRET_KEY | (b)(d) |
| 3 | **HEAD_SECRET permutation** of `[SendOption, Cmd, OrderID, Flags, Length]` | emit header fields in the session's permuted order | **YES** — solvable per session from the known `Length` plaintext; 100% on 3 sessions | (b)(d) |
| 4 | **TEA body cipher** (16 rounds, DELTA 0x9E3779B9, QQ-TEA framing) on encrypted channels (`8+8k` input stream, `10+8k` control) | hold the 16-byte `SECRET_KEY` | **YES, now** — key arrives in plaintext over lobby TCP (`MatchSuccessLoading` field 3); `ff-key-is-on-the-wire`. Plaintext channels (position keepalive, damage feed, liveness) need no key at all | (b)(d) |
| 5 | **Reliability OrderID window** — reliable packets (`SendOption ∈ {1,2,5}`, MsgKey 90..99, 10-byte header) carry a 2-byte LE `OrderID` the server sequences | a reliable packet must carry an OrderID inside the server's expected window | **NO for injection** — we cannot mint an OrderID the game's own reliability layer has not issued. Rewrite-in-place of an already-issued packet keeps its OrderID and is safe | (c)(d) + (b) via route-fallback |

**The load-bearing transport fact for exploitation:** the position keepalive (Cmd 2001)
is **unreliable** (`SendOption=0`, MsgKey 100..109, 8-byte header, **no OrderID**). So
rewriting it in place touches no reliable sequence window — which is exactly why
teleport/ghost/freeze are viable and why *injecting a brand-new reliable message is
not*. This is the mechanism behind IL2CPP_FINDINGS §7.4 and `TELEPORT.md`.

> **Verdict — new reliable message injection (any Cmd): KICK-RISK.** Inventing an
> OrderID desyncs the client/server reliability windows. This is the precise failure the
> teleport work spent three iterations eliminating and is the same class as the
> route-fallback kick (§4). Basis (c)(d), corroborated (b). The proven-safe primitive is
> **rewrite in place, never inject and never withhold a reliable packet**.

---

## 2. Layer 2 — the OWNERSHIP GATE

**Fingerprint: the server addresses *your* player from the session, not from a field you
send.** The outbound position message (Cmd 2001, class `ACDHGKMPIDJ` via `DAIDIMLOEPL`)
carries a leading PlayerID handle, but that handle is *your own* — the sender is
`PNCPKGJGBPP::EAIKJCCNGMJ` and it is dispatched on `IsInVehicle()`/`IsLocalPlayer`
state, i.e. the message describes the local player by construction (IL2CPP_FINDINGS
§5.1). There is no outbound message whose body names a *foreign* entity as the subject
of a state assertion:

- The interest/visibility masks (Cmd 135/136/386/369) have **zero outbound send sites**
  among the 461 catalogued (IL2CPP_FINDINGS §5.4). You cannot tell the server what to
  show you.
- The only outbound messages that name another entity are **claims about an interaction
  you initiated** — the hit claim (Cmd 106, victim+attacker) and the fire events — and
  those are anti-cheat-signed (§3, Layer 3).

> **Verdict — "move / teleport another player" by rewriting a subject id: NOT POSSIBLE
> (server ignores).** There is no field on the wire that lets you assert another
> entity's position; the position sender only ever describes the session's own player.
> Basis (c)(d). Confidence INFERRED — no capture attempted it because no such field
> exists to rewrite.

---

## 3. Layer 3 — the PLAUSIBILITY GATE (per-field checks)

This is where the interesting verdicts live. Each entry is a field or field-class with
the check, the consequence, and the verdict.

### 3.1 Position (Cmd 2001 v0–v2, self) — the WORKED EXAMPLE of a live plausibility gate

- **Check:** a **distance-from-held-belief gate**, MEASURED with perfect separation.
  The server compares the first reported position after any gap against the position it
  last believed. Accepted ≤ **2.77 m**; rejected ≥ **5.31 m**; threshold in (2.77, 5.31]
  m (`TELEPORT.md` §1). It is **not** a speed check — a 0.97 m/s move over 13 s / 12.9 m
  was rejected while 13.47 m/s was accepted. The discriminant is distance from the
  server's (100 ms-refreshed) belief.
- **Consequence on violation:** **snap-back.** The echo stays pinned to the anchor; a
  correction lands at a hard **399–402 ms** (~one RTT), after exactly 4 keepalives at
  the rejected position (`TELEPORT.md` §2). No inbound correction packet was seen in
  plaintext — it rides the encrypted `10+8k` channel, or the correction is the inbound
  **`RUDP_FORCE_SYNC_PLAYER_STATE` (Cmd 144)** / **`RUDP_TELEPORT_PLAYER` (Cmd 145)**
  family (see §4).
- **Verdicts:**
  - Rewrite self position **within ≤2.77 m/tick budget** → **USABLE**. MEASURED. This is
    teleport/ghost/freeze. Walk the belief at ≤2.77 m per 99 ms tick and it tracks.
  - Single jump **> ~3–5 m** → **CORRECTED** (snap-back +400 ms). MEASURED.
  - Withholding position (freeze/ghost) → **USABLE** — the server holds its last belief;
    verified the echo moved in only 4/96 transitions during FREEZE (`PROTOCOL_MASTER`
    §8). MEASURED.

### 3.2 Velocity (Cmd 2001 v8–v10) — the coherence check

- **Check (INFERRED):** velocity is sent independently of position, so
  `displacement ≈ velocity × 0.099 s` is a trivial cross-check the server can run.
  The tell is on the wire: legitimate traffic holds `v8v9v10 / next-tick-displacement`
  ratio at **1.010** (n≈12–25k); a naive position rewrite that leaves velocity alone
  collapses that ratio to **0.054** (5–20 m band) and **0.000** above 20 m — "position
  moved, declared velocity ≈ 0", **a shape that never occurs in real traffic**
  (`TELEPORT.md` §2, §6b).
- **Consequence:** unproven directly, but this incoherence is the most likely trigger a
  server-side plausibility check would key on, and it co-occurs with the snap-backs.
- **Verdict — rewrite position but not velocity: CORRECTED / detectable.** INFERRED. The
  shipped teleport therefore rewrites both v0–v2 and v8–v10 so the step matches. Rewrite
  both coherently and within budget → USABLE.

### 3.3 Aim / view vectors (Cmd 2001 v3–v5 body facing, v13–v15 camera) — TRUSTED-BUT-INERT

- **Check:** *none that matters.* The aim vector is **reported pose, consumed only to
  render your avatar on other clients**. Your own client's bullet ray comes from the
  camera/weapon transform plus client-side aim assist; the server never reads the
  reported aim back because the client hands over the finished hit claim (§3.6).
- **Consequence:** MEASURED — rotating the aim vector 30° (`AimBias`, which locked the
  correct float32 triple, confirmed in COMBAT_AND_HEALTH §8 correction) produced a
  **null result**: nothing changed server-side.
- **Verdict — rewrite reported aim: INERT.** The server accepts it (no correction, no
  kick) but it changes only how your character *looks* to others, not aim/hit outcomes.
  MEASURED. Useless as a combat lever; harmless.

### 3.4 Fire events (Cmd 104 START_FIRE / 105 STOP_FIRE) — fire input, anti-cheat-signed

- **Contents:** Cmd 104 outbound class `PHLCCJAAHIH` = `{u32 handle, u32 weaponId,
  u32 tick, fireState, f32, List<byte> antihack (DOBMKBAFODF @0x28), u16, f32}` — **no
  shot origin, no direction vector** (COMBAT_AND_HEALTH §7, `ff-client-authoritative-hits`).
  It carries a **`List<byte>` anti-cheat blob**.
- **Check (INFERRED):** the presence of the antihack blob means the server validates the
  fire event's integrity; "a server does not checksum data it ignores"
  (`ff-client-authoritative-hits`). Rate/cooldown enforcement (fire-rate cap) is
  plausible but **not evidenced** in the client path.
- **Verdicts:**
  - Rewriting the reported fire fields (weaponId/tick) → the geometry isn't there to
    exploit, and the blob is over the payload → **ANTI-CHEAT-GATED** for any forgery.
  - Fire-rate / no-recoil / cooldown bypass via faster/altered fire messages →
    **ASSUMED unknown**; the cooldown check is not visible client-side. Experiment: emit
    104s faster than the weapon's cadence in a private room and read the damage feed.

### 3.5 Ammo / inventory / weapon-on-hand — SERVER-AUTHORITATIVE

- **Check (INFERRED, strong):** health, armour durability, and **weapon-on-hand** are
  server-owned replicated state pushed down in **Cmd 1900 `RUDP_VAR_SYNC_PRI_DATA`**
  (`EPRI_PLAYER_CUR_HP`, `VEST_DURABILITY`, `ITEM_ON_HAND`; COMBAT_AND_HEALTH §1). These
  are **inbound** — the server announces them. `ITEM_ON_HAND.lo32` equals the weapon id
  the damage feed attributes to you, so the server, not the client, decides your held
  weapon for damage purposes.
- **Verdict — spoofing your HP/armour/weapon by editing local state: INERT.** The server
  never reads a client-sent HP; "the server sends deltas, never HP" and HP is absent
  from the outbound wire entirely (`PROTOCOL_MASTER` §6.1). Editing it changes only your
  own HUD. INFERRED.

### 3.6 Hit claim / damage (Cmd 106 outbound `MMJPICCOJOM`) — ANTI-CHEAT-GATED

This is the single most important "server DOES check" finding, and the standing project
line makes it a hard boundary.

- **Contents:** the client raycasts, resolves the collider owner and the body part, and
  sends the **finished claim** (IL2CPP_FINDINGS §1, `ff-client-authoritative-hits`).
  Class `MMJPICCOJOM` carries victim, attacker, weapon, tick, hit point
  (`PMFGOGFPDHM EPCMOGEBEKM @0x38`), hit direction (@0x40), a `List<float>` checkParams
  (`MPECMNGCKJN @0x48`), the hit zone (sent twice — see below), and **two anti-cheat
  blobs**: `ffantihack.MFHPGMELLCC::DHMENGFJMII` and
  `GCommon.Checker.GFHPFJMGEKF::AKFFMELHGIJ(0xA, 7, damage)` → `List<byte> FHBHMKMHCHJ
  @0x68`.
- **Check (INFERRED, strong):** the damage value is fed through the `GFHPFJMGEKF`
  checksum before send; the server validates that checksum. This is corroborated by the
  anti-cheat enum `AKHFIKBPKFM` carrying `Cheating_HipsBoneNotRight = -154`,
  `Cheating_HackerIceWallName = -155`, `Cheating_SniperColliderName = -156`
  (IL2CPP_FINDINGS §4.1) — the server rejects geometrically impossible hits and names
  the cheat.


### 3.7 Hit-zone spoofing (Cmd 106 zone) — cross-checked AND anti-cheat-gated

- **Check (INFERRED):** the zone is sent **twice** in the same message —
  `GMNGCBJMDLB` packs `damage | (zone << 24)` at +0x1c, and `EHNFCMJMPMJ` (a plain byte,
  = `HitBodyPart`) at +0x2c (IL2CPP_FINDINGS §4.1). "Almost certainly a server-side
  tamper cross-check: the two must agree." A client-side **downgrade gate** rewrites
  Head→Body when `IsInNoHeadShotState`, mirroring server logic.
- **Verdict — spoof a body hit into a headshot: 
### 3.8 Clash Squad shop purchase (Cmd 413 `RUDP_PURCHASE_CSITEMS`) — the WORKED EXAMPLE of server ownership

- **Contents:** class `DAFMJPEBBHI` = `{uint context, List<uint> itemIds,
  ECSItemBuyType}`. **No price field, no token field, and no anti-cheat blob**
  (confirmed in `ff_outbound_classes.json`; IL2CPP_FINDINGS §7.3).
- **Check (INFERRED, strong):** the client names item ids; **the server looks up the
  cost and debits the balance it alone owns.** Shop contents (Cmd 412 et al.) and your
  token balance (Cmd 957) are server-announced, inbound. `COW.CSShopItemData.price` is a
  **client-side config table** for display only — editing it changes your UI and nothing
  the server believes (IL2CPP_FINDINGS §7.2).
- **Verdict — send a purchase / edit local prices to buy for free: CORRECTED / INERT.**
  A hand-built 413 is exactly the buy button — "there is no `price = 0` to write because
  the price never leaves the server." The server debits real cost or rejects for
  insufficient balance. INFERRED. (Note: 413 is a *reliable* message — building a
  standalone one also incurs the OrderID KICK-RISK of Layer 1; the only safe way to send
  it is to let the game send it, which buys nothing anyway.)

### 3.9 Interest management / visibility (Cmd 135 `SYNC_PLAYERS_VISIBILITY`) — no client lever

- **Check:** Cmd 135 is a **server→client** 64-bit relevance bitmap (SET bit = visible
  to you; IL2CPP_FINDINGS §5.4). It is a *rendering* directive consumed by
  `Player::SetVisible` with **zero networking**. There is **no outbound send site** for
  135/136/386/369.
- **Verdict — force the server to stream/reveal more entities: NO LEVER EXISTS.** You
  cannot express an interest change; the nearest outbound message (Cmd 144
  `FORCE_SYNC_PLAYER_STATE`) has zero fields. Whether cleared-bit entities are still
  *streamed* (so ESP sees them anyway) vs *gated* is server policy and is the open
  experiment in IL2CPP_FINDINGS §5.4.1. INFERRED (no lever) / ASSUMED (streaming policy).

---

## 4. Layer 4 — CONSEQUENCE map (what a violation does)

The server has a graded response. Mapping which manipulation lands where is half the
deliverable — a manipulation that "works" but kicks you is a trap.

| consequence | mechanism | which manipulations trigger it | basis |
|---|---|---|---|
| **Silent accept** | field is trusted (self pose) or ignored (reported aim) | position within budget; reported aim vector | MEASURED |
| **Snap-back** | server holds its belief; correction at hard **399–402 ms**; likely the inbound `FORCE_SYNC_PLAYER_STATE` (144) / `TELEPORT_PLAYER` (145) family | position jump > ~3–5 m; position moved without matching velocity | MEASURED (gate) / INFERRED (which packet) |
| **Reject-and-ignore** | server debits real cost / discards impossible claim | CS purchase (charges real price or fails); local HP/price edits | INFERRED |
| **Anti-cheat flag** | `GFHPFJMGEKF` checksum mismatch; `AKHFIKBPKFM` cheat enum (`Cheating_*`) | forged damage, hit-zone spoof, tampered fire blob | INFERRED |
| **Disconnect / kick** | reliability-window desync (injected/withheld reliable packet) or transport starvation | injecting a new reliable message; minting an OrderID; withholding reliable traffic | INFERRED (c)(d) + MEASURED signature |

**Empirical kick fingerprint (MEASURED):** captures `phone_kick/*_20260911_2209/2210`
show the disconnect signature — own position frozen at a constant (969879 / 955230),
entities 99–100% frozen, path length 0, then silence. That is the *transport-starvation*
kick (the disabled `scheduleLobbyRouteFallbackIfNoUdp` tore down the tun interface
mid-match; `ff-route-fallback-kick`). It confirms what a kick looks like on the wire —
everything stops, no ban — but it was caused by our own tunnel restart, **not** by a
server validation trip. We have **no capture of a server anti-cheat kick**; that gap is
the biggest "inferred → confirmed" upgrade available (§6).

---

## 5. The verdict table (keyed to message/field)

| # | message / field | check applied by server | basis | consequence | **verdict** |
|---|---|---|---|---|---|
| 1 | **transport** CRC-7 / mask / HEAD_SECRET / TEA | packet dropped if any fails | (b)(d) | discard | reproducible → **USABLE** (we hold key + can recompute); forget to recompute CRC-7 after an edit → silent **CORRECTED/drop** |
| 2 | **reliable OrderID window** (any reliable Cmd) | sequence must be in server window | (c)(d)+(b) | desync → disconnect | inject/mint → **KICK-RISK**; rewrite-in-place keeps OrderID → safe |
| 3 | **Cmd 2001 v0–v2** self position, ≤2.77 m/tick | distance-from-belief gate | (b) | accept | **USABLE** (teleport/ghost) |
| 4 | **Cmd 2001 v0–v2** jump > ~3–5 m | same gate | (b) | snap-back +400 ms | **CORRECTED** |
| 5 | **Cmd 2001 v8–v10** velocity (must match Δpos) | position/velocity coherence | (c)(b) | incoherent shape → correction | **CORRECTED** if left stale; USABLE if rewritten coherently |
| 6 | **withhold** position keepalive (unreliable) | server holds last belief | (b) | belief frozen | **USABLE** (freeze/ghost) |
| 7 | **Cmd 2001 v3–v5 / v13–v15** aim/camera | none (render-only) | (b) | accept, no effect | **INERT** |
| 8 | **subject id** in any outbound (move another entity) | server addresses your player from session | (c)(d) | ignored | **NOT POSSIBLE** |
| 9 | **Cmd 104** fire event + antihack blob | fire integrity checksum | (c) | — | **ANTI-CHEAT-GATED** (no geometry to exploit anyway) |
| 10 | **fire rate / cooldown** (send 104 faster) | rate cap — not visible client-side | — | unknown | **ASSUMED** (experiment in §6) |
| 11 | **local HP / armour / weapon** edits | server owns replicated state (Cmd 1900) | (c) | ignored | **INERT** |

| 13 | **Cmd 106 zone** (sent twice, downgrade gate) | two-copy agreement + checksum | (c) | flag/reject | **ANTI-CHEAT-GATED** |
| 14 | **Cmd 413** CS purchase (item ids only) | server owns price + balance | (c) | debit real cost / reject | **CORRECTED / INERT** |
| 15 | **`COW.CSShopItemData.price`** local table | client-side display config | (c) | ignored | **INERT** |
| 16 | **Cmd 135/136/386/369** visibility interest | no outbound send site exists | (c) | — | **NO LEVER** |

**Validation classes modelled: 16** (across the four layers: 2 transport, 1 ownership,
12 plausibility/field, plus the consequence map that binds them).

### The two lists the user most needs

**USABLE (server trusts it — self-affecting, in-place rewrite of unreliable position):**
1. Self position rewrite within ≤2.77 m/tick budget (teleport/ghost) — **MEASURED**
2. Velocity rewritten coherently with position — **MEASURED/INFERRED**
3. Withholding the position keepalive (freeze/ghost) — **MEASURED**
4. (Trusted-but-INERT, harmless) reported aim/camera vector; local HP/weapon/price edits
   — take effect only on your own client, never believed by the server.

**KICK-RISK (traps — "work" only to disconnect you):**
1. Injecting *any* new reliable message (invents an OrderID) — **INFERRED (c)(d)**, and
   this is the documented failure mode behind three teleport iterations and the
   route-fallback kick.
2. Withholding reliable traffic / OrderID-desyncing edits — same window.
3. Position jumps > ~3–5 m/tick are **CORRECTED not kicking**, but chaining them while
   also mangling reliable channels moves you into KICK-RISK.
4. (Adjacent operational trap) forgetting to recompute CRC-7 after a byte edit at
   offset ≥2 — silently dropped, reads as a mysterious "server sets us back."


**CORRECTED / INERT (do not bother):** CS shop free-buy (server owns price/balance),
local HP/armour/weapon/price edits, reported-aim rewrites.

---

## 6. What would upgrade an "inferred" verdict to "confirmed"

Ranked by value. Each is cheap because the pipeline already logs everything.

1. **The MAC / body-integrity test (gates everything).** Rewrite `v0` by +1 unit on one
   keepalive per second for 10 s and watch the self-echo. Echo tracks the offset ⇒ no
   body integrity check on position ⇒ the entire rewrite design is sound
   (`TELEPORT.md` §8). Confirms verdicts 3–6.
2. **Bracket the distance threshold** in (2.77, 5.31] m: ghost, walk to a marked
   distance, release; binary-search 3.0/3.5/4.0/4.5/5.0 m, 3 trials each, read
   accept/reject off the echo. Upgrades verdict 4 from a range to a number.
3. **Identify the correction packet.** Repeat a 15 m rejection ~20× and look for an
   inbound `10+8k` block0 value present in ≥19/20 pre-snap windows, *or* decode the
   inbound **Cmd 144 `FORCE_SYNC_PLAYER_STATE` / Cmd 145 `TELEPORT_PLAYER`** bodies
   around a snap-back (we have the key now). Confirms the snap-back mechanism in Layer 4.
4. **Capture a real anti-cheat kick.** We have none. In a private room, deliberately
   send one out-of-window reliable OrderID (or an obviously bad Cmd 106) once and capture
   the disconnect — distinguishes the transport-desync kick from an anti-cheat kick and
   validates verdicts 2, 9, 12.
5. **Fire-rate cap (verdict 10, currently ASSUMED).** Emit Cmd 104 faster than the
   weapon cadence in a private room; read the damage feed (Cmd 2010) to see whether
   extra shots register.
6. **CS purchase economy (verdict 14).** Send a Cmd 413 for an item you cannot afford
   and watch Cmd 957 (token balance) — no debit + no item confirms server rejection;
   real debit confirms server-owned pricing.
7. **Visibility streaming policy (verdict 16).** Partition 2001/2012 arrivals by whether
   the sender's bit was set in the most recent Cmd 135 (IL2CPP_FINDINGS §5.4.1). Decides
   whether interest management gates the stream or is render-only.

---

## 7. Consistency check against IL2CPP_FINDINGS.md and TELEPORT.md

Re-derived before asserting; **no contradictions found.** Everything here composes from
those two plus COMBAT_AND_HEALTH.md, PROTOCOL_CIPHER.md and the framing/key memories.

Two points worth flagging as *already-resolved-in-source* rather than contradictions:

- **Cmd 135 "inverted" sense.** COMBAT_AND_HEALTH §8 notes the mask "appears inverted";
  IL2CPP_FINDINGS §5.4 shows the code never inverts (SET = visible) and flags the capture
  hunch as a probable bit-alignment artifact with a decisive experiment. This doc sides
  with the code (it is not a validation lever either way) and defers to §5.4.1's
  alignment test. Not a new contradiction.
- **Cmd 144 direction.** IL2CPP_FINDINGS §5.4 describes the *outbound* Cmd 144 class as
  having **zero fields** ("resend my state" ping); the inbound registry lists Cmd 144
  `RUDP_FORCE_SYNC_PLAYER_STATE` with class `PGABPEBFLOK` carrying the server's forced
  state. These are the two directions of one bidirectional id (IL2CPP_FINDINGS §2) — the
  inbound one is the correction channel referenced in Layer 4. Consistent, not
  conflicting.
