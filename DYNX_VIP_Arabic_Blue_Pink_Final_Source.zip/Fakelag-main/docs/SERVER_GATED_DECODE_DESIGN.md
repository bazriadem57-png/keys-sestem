# Server-gated decode — making the server a hard dependency of ESP

Goal (owner, 2026-09-18): the crack works because the whole decode/ESP path is
self-contained in the client — flip two booleans and it runs offline forever
(see `CRACK_ANALYSIS_2026-09-18.md`). Fix: make a **required, first-line piece
of decode depend on a per-session secret that only the server delivers**, so an
attacker who bypasses the login gate still cannot decode anything without a live,
licensed session. It must be **fail-closed and must not affect the rendering
path**: when legitimate, behaviour is byte-identical to today; when the server
material is absent, the decoder yields *no records* (nothing to draw) — never
wrong coordinates, never a crash.

## Why the current model leaks

The 2012 entity-chain decoder (the ESP's position source) is **plaintext and
self-contained**: it interprets the wire by a fixed set of structural parameters
that are *hardcoded in the APK* — the field order within a record, the 3
fixed-width pose bytes, the record floors (`MIN_RECORD_X`, id/count caps), the
header semantics (b8=0, b9=count·2). Nothing in it comes from our server. So the
APK alone is sufficient to decode; cracking the login gate is enough.

## The leash: a server-delivered Decode Profile

Move those structural parameters **out of the APK** and into a **Decode Profile**
that the server ships inside the existing authenticated `/config` envelope
(X25519 → HKDF → AES-256-GCM, per-call ephemeral key, one-time `jti`, AAD-bound —
see the security review). Only a client that completed a real, licensed login
receives a blob it can open. The native decoder **requires** a valid profile and
**fails closed** without one.

```
login (valid license) ─▶ /config (AES-GCM sealed) ─▶ ConfigStore ─▶ armed profile
                                                                         │
raw 2012 packet ───────────────────────────────────────────────────────▼
                                          chain::parse_with_profile(pkt, …, profile, now)
                                          · profile absent/expired  ⇒ None   (fail-closed)
                                          · profile valid           ⇒ records (as today)
```

Authenticity/secrecy of the profile is inherited from the AES-GCM channel — the
native core does **not** need to verify a signature itself, so **no new crypto
dependency is added to the shipped `.so`.** The profile carries a `valid_until`
(unix seconds) so a captured blob cannot be reused past its short window, and the
one-time `jti` already blocks replay of the envelope.

### Why this actually stops the crack

- The cracked APK has **no profile and no way to obtain one** (no valid license →
  the server never hands it a blob it can open). There is nothing to patch: the
  data simply is not in the binary.
- Re-deriving the profile means reverse-engineering the game's wire protocol from
  scratch (high effort) — the licensing leash is meant to stop *APK crackers*
  (flip-a-boolean redistribution), and it raises their cost from "two bytes" to
  "RE the protocol yourself or buy a license."
- Putting the requirement in the obfuscated native `.so` (Phase-2 port) means the
  gate is not a patchable Java boolean.

### Why rendering is unaffected

The renderer consumes the decoded record list. With a valid profile the list is
exactly what it is today. Without one the list is empty — identical to "no
packets arrived." The overlay/rendering gateway, camera math, and every
`onDraw` path are untouched: they never see the profile and never change.

## Phased implementation

1. **nuvola-core (this change, host-verifiable, no live impact):**
   `ChainProfile` holding the structural params + `valid_until`; a
   `chain::parse_with_profile(pkt, off, len, own_id, &profile, now)` that
   fail-closes on an absent/expired profile and otherwise decodes exactly as the
   existing `parse`. The hardcoded constants become **test-only**
   (`#[cfg(test)]`), so a production build carries no baked profile — the only
   source is the server. The 1139-packet golden is re-verified through the gated
   path with a test profile that equals the real game params.
2. **Server:** add the Decode Profile to the `/config` payload (a new
   `decode_profile` section), signed into the existing sealed envelope, with a
   `valid_until` a few minutes past the config TTL. Rotate freely.
3. **Client `ConfigStore`:** expose the profile bytes to the native layer
   (RAM-only, never persisted).
4. **JNI + EspEngine:** the native chain decode is armed from `ConfigStore`; the
   Java `EspEngine.observeChainPacket` calls the armed native decoder. Behind the
   existing native fallback flag, enabled only after on-device verification (this
   is the device-blocked step — it must not be wired blind).

**Status:** Steps 1–3 are done.
- Step 1 — `nuvola-core`: `chain::parse_with_profile` (2012) and
  `BodyCrypt::arm` + `decrypt_into(..,now)` (reliable channel) both fail-close
  without a live profile. Verified on the 1139-packet golden + leash tests.
- Step 2 — server: `config_blob.build_blob` emits a `decode_profile`
  (`valid_until` = config expiry + 300 s grace, plus the chain params), only
  inside the sealed `/config` envelope.
- Step 3 — client: `ConfigStore` parses `decode_profile` into RAM-only fields
  (`decodeArmed(now)`, `chain*` accessors), zeroed on `clear()`.

Step 4 is split:
- **4a (staged, done):** the `chainDecode` JNI entry (`nuvola-native`) decodes a
  raw 2012 packet under the profile and serializes records into a direct
  `ByteBuffer` (`Chain::serialize`), and `NativeBridge.chainDecode` declares it.
  It is bound in a **separate, non-fatal** `RegisterNatives` step so an unverified
  contract can never break the core `nnSelftest`/`crc7Seal`, and it is gated by
  `NativeBridge.NATIVE_DECODE = false`. Cross-build clean; `chainDecode` stays
  unexported; Java compiles. It is NOT on the live path.
- **4b — shadow compare (landed 2026-09-18, behind `NativeBridge.NATIVE_SHADOW`,
  default off):** when the flag is on, `EspEngine.observeChainPacket` calls
  `chainDecode` in PARALLEL with the Java parse it just committed and compares the
  two record sets **field-for-field** (id, raw x/z/y, pose bytes, self-echo flag)
  via the `ESP_CHAIN_NATIVE_{MATCH,DIVERGE,REFUSED,UNARMED}` Diag slots. Java
  stays authoritative, so this is **risk-free to enable in a live match** — it
  turns "does the native decode match?" into a Diag counter to read, replacing a
  blind flag-flip. Being a compile-time-constant flag, R8 strips it from release.
- **4b-authoritative / `NATIVE_DECODE` (still waits for the device):** once the
  shadow compare reads MATCH 100% / DIVERGE 0% across a live match, `EspEngine`
  consumes the native records instead of its Java parse and `NATIVE_DECODE` flips
  on — never blind.

- **The live-path leash (landed 2026-09-18, behind `NativeBridge.DECODE_LEASH`,
  default off):** the three live Java decode entries
  (`observeChainPacket`/`observeKeepalive`/`observeVehicleList`) fail-closed —
  return without decoding, hitting `ESP_LEASH_CLOSED` — unless
  `ConfigStore.decodeArmed(now)`. This is the direct fix for the 2026-09-18
  security review's CRITICAL finding (the leash existed but nothing on the live
  path consulted it, so a login-bypassed client still decoded). It is
  rendering-neutral (no profile ⇒ no entities ⇒ nothing drawn, no crash).
  Default off pending a single in-game confirmation. The mid-match-expiry risk is
  now RESOLVED server-side (2026-09-18b): the decode profile's `valid_until` was
  `config-expiry + 300 s` = ~7 min (CONFIG_TTL is 2 min), which would have blacked
  out ESP ~7 min into a 20-30 min match. It is now decoupled from the short config
  TTL and set to `now + DECODE_PROFILE_TTL_SEC` (6 h) — a daily login keeps a
  legit device armed all session, while an offline/cracked client still gets NO
  profile (anti-crack property unchanged). So flipping `DECODE_LEASH` true is now
  gated only on one live-match confirmation (watch `ESP_LEASH_CLOSED` stays 0),
  not on a `/config` refresh-cadence question. That flip is the release step that
  makes ESP genuinely server-dependent.

Until `DECODE_LEASH`/`NATIVE_DECODE` are flipped (post-device), the leash is
fully built, unit-verified, host+QEMU-gated, and wired behind default-off flags
that R8 strips from release — but the shipping default still decodes in Java.

### The leash also covers outbound manipulation (not just decode)

The same fail-closed gate is applied to every OUTBOUND rewrite entry, so a
cracked client can't teleport / aim / mark without a live server profile either:

- `mark::rewrite_packet` and `aim::rewrite_packet` take `(valid_until, now)` and
  return their `-1` no-op (packet left byte-for-byte untouched) when
  `!entitled(valid_until, now)`.
- `PosSync` (Cmd-2001 teleport) gains `arm(valid_until)`; `set_signed` and
  `rebuild` no-op unless armed-and-live for `now`.

A no-op rewrite is inherently safe: the original, correctly-CRC'd packet passes
through unchanged, so an unlicensed client simply has no teleport/aim/mark — no
desync, no kick, no render impact. `nuvola_core::entitled(valid_until, now)` is
the one shared leash test used by decode and rewrite alike. Leash tests:
`chain::no_profile_or_expired_decodes_nothing`,
`bodycrypt::leash_fail_closed_without_live_entitlement`,
`possync::leash_no_teleport_without_live_entitlement`,
`mark::leash_no_mark_without_live_entitlement`,
`aim::leash_no_aim_rewrite_without_live_entitlement`.

## Threat notes / honest limits

- This does not stop an attacker who fully reverse-engineers the game protocol —
  nothing client-side can. It stops **APK crack redistribution**, which is the
  actual observed threat.
- A licensed attacker can still capture their own profile during its short
  validity window; `valid_until` + rotation bound the value of a leaked profile,
  and the one-time `jti` blocks envelope replay.
- The profile must never be persisted to disk (RAM-only), or it becomes an
  offline artifact a crack could ship.
