# Diagnostic inventory — `filter/` and `ui/`

Research only. **Nothing in this document has been applied to any source file.** It is the
input for a later instrumentation pass.

Scope: `app/src/main/java/com/fakelag/cryhard8/filter/` (15 files + `filter/replay/` 2) and
`.../ui/` (`aim/` 4, `button/` 4, `overlay/` 3, `panel/` 1, `render/` 1, `settings/` 4).
`tunnel/`, `protocol/`, `esp/` and `decode/` are covered by sibling documents.

All paths below are relative to `fakelag/fakelag-beta/app/src/main/java/com/fakelag/cryhard8/`.

---

## 0. How to read this

| column | meaning |
|---|---|
| **visibility** | `silent` = no log, no counter. `logs` = a line goes to logcat / `DevLogger` / a HUD string but nothing is countable. `counted` = an existing `AtomicLong`/`AtomicInteger` already tracks it. |
| **sev** | `fatal` = the feature produces nothing at all. `degraded` = it still works but worse or later. `benign` = expected, correct, and only needs a denominator. |
| **mark** | `counter` = numeric only, safe on a hot path. `event` = rare enough to deserve a logged line with context. `both` = count every occurrence, log on the 0↔n edge transition only. |
| **rate** | expected events/sec at steady state. `120 Hz` = the `Choreographer` render loop (`ui/overlay/EspOverlay.java:184-195`). `125 Hz` = the aim controller (`ui/aim/AimInjector.java:137`, `TICK_MS = 8`). Filters see ~1000 pkt/s total, of which the position channel is ~10/s, outbound Cmd 106 is <20/s in a fight, and Cmd 148 is user-initiated (<1/min). |

**The hot-path rule.** Anything marked `counter` must be an `AtomicLong.incrementAndGet()` and
nothing else. A `Log.*` call at 120 Hz costs a string build plus a binder write per frame and
will itself become the frame-budget problem — `docs/PERF_AUDIT.md` §"Tier 2" already flags the
120 Hz loop as the place where a single allocation becomes 600/sec. Two existing sites violate
this today and are called out in §7.

---

## 1. Reason ladder A — "the aim did nothing"

`ui/aim/AimInjector.java` collapses at least **nineteen** independent preconditions into one
`boolean available()` plus a single `lastBail` string that the next tick overwrites. A dump can
currently say "off"; it cannot say *which* of these is true. One counter each, in the order the
code reaches them.

### A1 — setup, before the controller ever runs

| # | file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|---|
| 1 | `ui/aim/AimInjector.java:358-360` | `catch (Throwable t)` around `new HandlerThread("aim-inject")` — `worker` stays `null` | silent (`lastError` only) | `ensureLoop()` returns forever; the controller **never ticks**. Panel says "Shizuku: READY". | fatal | `AIM_NO_WORKER` | once | event |
| 2 | `ui/aim/AimInjector.java:367-369` | `HiddenApiBypass.addHiddenApiExemptions` threw, `catch (Throwable ignored)` | silent | `ensureInput()` later fails on Android 9+; reported only as the generic "no IInputManager" | fatal | `AIM_HIDDENAPI_BYPASS_FAIL` | once | event |
| 3 | `ui/aim/AimInjector.java:371-373` | `Shizuku.addRequestPermissionResultListener` threw | silent | a later grant is never observed; `permGranted` stays false until the 500 ms `available()` TTL happens to re-ask | degraded | `AIM_PERM_LISTENER_FAIL` | once | event |
| 4 | `ui/aim/AimInjector.java:375-378` | `addBinderReceivedListenerSticky` / `addBinderDeadListener` threw | silent | the binder arriving **after** the overlay started is never noticed → the app must be restarted. This is the documented "I can't turn the toggle on" symptom (class javadoc `:295-301`). | fatal | `AIM_BINDER_LISTENER_FAIL` | once | event |
| 5 | `ui/aim/AimInjector.java:381-383`, `:309-312` | `TouchWatcher.start()` threw, `catch (Throwable ignored)` | silent | `yieldToTouch` silently never yields — see ladder A3 | degraded | `AIM_TOUCHWATCH_START_FAIL` | once | event |

### A2 — `available()`, the single boolean that hides four answers

`ui/aim/AimInjector.java:395-411`. Cached for 500 ms (`AVAIL_TTL_MS`), asked ~125×/s.

| # | file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|---|
| 6 | `:401` | `!Shizuku.pingBinder()` | silent | aim does nothing; user must start Shizuku over wireless ADB | fatal | `AIM_SHIZUKU_NOT_RUNNING` | ≤2/s (TTL) | counter |
| 7 | `:401` | `Shizuku.isPreV11()` | silent | aim does nothing; Shizuku app too old | fatal | `AIM_SHIZUKU_TOO_OLD` | ≤2/s | counter |
| 8 | `:404` | `!(permGranted \|\| checkPerm())` | silent | aim does nothing; the user never tapped "grant" | fatal | `AIM_NO_PERMISSION` | ≤2/s | counter |
| 9 | `:406-408` | `catch (Throwable t) { ok = false; }` | silent | binder transaction threw — indistinguishable from "not running" today | fatal | `AIM_SHIZUKU_THREW` | ≤2/s | both |
| 10 | `:418-425` | `checkPerm()` `catch → permGranted = false` | silent | same as #8 but a different cause | fatal | `AIM_PERM_CHECK_THREW` | ≤2/s | both |
| 11 | `:429-434` | `refreshPermission()` whole body in `catch (Throwable ignored)` | silent | a manual re-check silently does nothing | degraded | `AIM_PERM_REFRESH_THREW` | rare | event |
| 12 | `:439` / `:440` / `:443-446` | `requestPermission()` bails: not running / too old / threw | `logs` (`lastBail`, one `Log.w`) | tapping GRANT in the panel appears to do nothing | degraded | `AIM_REQ_NOT_RUNNING`, `AIM_REQ_TOO_OLD`, `AIM_REQ_THREW` | user-initiated | event |

### A3 — the binder path

| # | file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|---|
| 13 | `ui/aim/AimInjector.java:494` | `SystemServiceHelper.getSystemService("input")` returned null | `logs` (`lastError = "no input svc"`) | no injection on this ROM | fatal | `AIM_NO_INPUT_SERVICE` | see note | counter |
| 14 | `ui/aim/AimInjector.java:504-508` | `catch (Throwable t)` around the whole `IInputManager$Stub.asInterface` reflection | `logs` — **`Log.w` fires on every failing call** | no injection; the ROM's hidden API differs | fatal | `AIM_IINPUTMANAGER_RESOLVE_FAIL` | **125 Hz while broken** | counter + rate-limited event |
| 15 | `ui/aim/AimInjector.java:316-329` | `BINDER_DEAD` → `permGranted=false`, `inputManager=null`, `lastBail="binder died"` | `logs` | the aim stops mid-match; only the HUD string says so | fatal | `AIM_BINDER_DIED` | rare | event |
| 16 | `ui/aim/AimInjector.java:519-528` | `inject()` `catch (Throwable t) { failCount++; }` | `counted` (`failCount`) but not split by cause | events rejected; the drag does not move the view | fatal | `AIM_INJECT_REJECTED` (keep `failCount`, add a per-`Throwable`-class tag) | up to 125/s | counter |

> **#14 is the one log line in this scope that is unaffordable.** `Log.w(TAG, "IInputManager
> resolve failed…")` at `:506` is inside `ensureInput()`, which `tick()` calls every 8 ms
> (`:614`). While the ROM path is broken that is 125 logcat writes per second, forever. It must
> become a counter plus a once-per-state-change event.

### A4 — the controller tick (`tick()`, `:606-714`), 125 Hz

| # | file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|---|
| 17 | `:609-613` | `!available()` → `abortGesture()`; `bailCount++` **only if `hasTarget`** | partly counted | a bail with no target locked is entirely invisible | fatal | resolves to #6-#10 | 125 Hz | counter |
| 18 | `:614-618` | `!ensureInput()` → `bailCount++`, `lastBail="no IInputManager"` | counted (conflated) | as #13/#14 | fatal | `AIM_NO_IINPUTMANAGER` | 125 Hz | counter |
| 19 | `:628-633` | `yieldToTouch && TouchWatcher.userTouching()` → `endGesture`, `lastBail="user touching"` | counted (conflated in `bailCount`) | aim stands off while a finger is down — **correct and expected** | benign | `AIM_YIELD_USER_TOUCH` | **125 Hz while touching**; healthy = 0–125/s, sustained 125/s for >10 s means a stuck slot count (see B-note on `TouchWatcher`) | counter |
| 20 | `:635-643`, `:637` | `!fresh` and `now - targetAtMs > holdMs` → `endGesture` | silent | the pointer lifts; the next target costs a fresh DOWN (which cancels the user's touches) | benign | `AIM_TARGET_LOST_RELEASED` | ~1/lock | counter |
| 21 | `:639-641` | `!fresh` but inside `holdMs` → `idleMove` | silent | holding through a brief loss — correct | benign | `AIM_TARGET_STALE_HOLD` | up to 125/s | counter |
| 22 | `:680-683` | `!correcting && !correctingX` (both deadzones satisfied) → `idleMove` | silent | settled on target — correct | benign | `AIM_IN_DEADZONE` | up to 125/s; healthy = the **majority** of ticks while locked | counter |
| 23 | `:694-701` | `travel > maxTravelPx` or within `EDGE_MARGIN_PX` of a screen edge → lift + re-plant | counted (`regripCount`, shared) | a re-plant cancels the user's other pointers | degraded | `AIM_REGRIP_EDGE` (split out of `regripCount`) | ~1–3/s under sustained correction | counter |
| 24 | `:729-733` | `regripMs > 0 && now - lastRegripMs >= regripMs` → forced re-plant | counted (`regripCount`, shared) | same | benign | `AIM_REGRIP_FORCED` | 1000/`regripMs` | counter |
| 25 | `:744-748` | `ratio < 0.25` — injected px did not move the measured error → `lastStallOk = false`, `regrip` | `logs` (`lastBail="regrip(stalled)"`, a HUD flag) | the gesture is dead and being rebuilt; usually the user's finger cancelled it | degraded | `AIM_STALL_DETECTED` | ≤4/s (`STALL_CHECK_MS = 260`) | both |
| 26 | `:584-588` | `TICKER` `catch (Throwable t) { lastError = … }` | silent | a persistent exception makes the controller a 125 Hz no-op with **no counter at all** | fatal | `AIM_TICK_THREW` | up to 125/s | counter + one event |
| 27 | `:593-600` | loop parks after `LOOP_IDLE_MS` with no target and no gesture | silent | correct — this is the fix for the 125 Hz binder-ping-forever bug | benign | `AIM_LOOP_PARKED` | ≤1/s | event |
| 28 | `:572-575` | `ensureLoop()` — `worker == null` | silent | see #1; the loop can never start | fatal | folds into `AIM_NO_WORKER` | — | — |
| 29 | `:929` | `rawDrag()` — `!available() \|\| !ensureInput()` → `return false` | silent (the calibrator turns it into text) | calibration reports `AimInjector.status()` instead of the real reason | degraded | `AIM_RAWDRAG_UNAVAILABLE` | user-initiated | event |
| 30 | `:970`, `:973` | `selfTest()` `catch (InterruptedException ignored)` — `break` / swallow | silent | the self-test ends early and reports "nothing sent (…)", misattributing the cause | degraded | `AIM_SELFTEST_INTERRUPTED` | user-initiated | event |

### A5 — `ui/aim/TouchWatcher.java`, the `getevent` subprocess

Four distinct ways this dies, all currently indistinguishable from "the user is not touching".

| # | file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|---|
| 31 | `ui/aim/TouchWatcher.java:96` | `if (!AimInjector.available()) return;` — and `started` is **not** set, so nothing retries except the `BINDER_RECEIVED` listener | silent | `supported` stays false → `userTouching()` always false → the aim never yields → it fights the user's movement thumb | degraded | `TOUCH_START_NO_SHIZUKU` | on attach | event |
| 32 | `ui/aim/TouchWatcher.java:124-128` | `newProcess(...)` returned null → `error = "no shell"; return;` | `logs` (`debugLine()` only) | same as #31 | degraded | `TOUCH_NO_SHELL` | once | event |
| 33 | `ui/aim/TouchWatcher.java:187-198` | `Shizuku.newProcess` reflection threw → `error = "newProcess"` + one `Log.w` | `logs` | same; a Shizuku API signature change presents as "the aim is jittery" | degraded | `TOUCH_NEWPROCESS_UNAVAILABLE` | once | event |
| 34 | `ui/aim/TouchWatcher.java:135` → `:167-170` | `readLine()` returns null (the `getevent` process died) → `finally` sets `supported=false, activePointers=0`, **`started` stays true so `start()` can never restart it** | silent | mid-session the watcher dies and the aim silently stops yielding for the rest of the match | degraded | `TOUCH_STREAM_DIED` | once | event |
| 35 | `ui/aim/TouchWatcher.java:164-166` | `catch (Throwable t)` → `error = SimpleName` + `Log.w` | `logs` | same as #34 | degraded | `TOUCH_LOOP_THREW` | once | event |
| 36 | `ui/aim/TouchWatcher.java:67-69` | `userTouching()`: `if (!supported) return false;` | silent | **fails open** — "watcher broken" and "no finger down" return the same answer, which is the whole reason #31-#35 are invisible | degraded | `TOUCH_UNSUPPORTED_ASSUMED_UP` | up to 125/s (asked from the tick) | counter |

> **Latent defect found while reading, no change made.** `userTouching()` at `:72-73` reads
> `return SystemClock.uptimeMillis() - lastEventMs < 2000L || activePointers > 0;`. The guard at
> `:69` has already returned false unless `activePointers > 0`, so the right-hand side is always
> true and the 2 s sticky window is dead. A drifted slot count therefore parks the aim
> permanently, which is exactly what the comment at `:70-71` says it exists to prevent. Worth a
> `TOUCH_STICKY_EXPIRED` counter once the expression is fixed — flagging only, not fixing.

### A6 — `ui/aim/AimCalibrator.java`

Every bail here already produces human-readable text in `status()`, which is the right design
for a one-shot user-initiated action. One counter with a reason tag is enough.

| file:line | trigger | vis | consequence | sev | counter | mark |
|---|---|---|---|---|---|---|
| `:79` | `if (running) return;` | silent | a second tap does nothing and `status` does not change — reads as a dead button | benign | `CAL_ALREADY_RUNNING` | event |
| `:80`, `:81` | engine null / `!AimInjector.available()` | `logs` (status) | already covered | — | — | — |
| `:89-90` | `catch (Throwable t) → "FAIL: " + SimpleName` | `logs` | already covered | — | — | — |
| `:117-119`, `:167-170`, `:171-174`, `:178-181`, `:202-205` | camera did not move / too noisy / no samples / `rawDrag` refused / no response | `logs` | already covered | — | `CAL_FAIL{reason}` | event |

---

## 2. Reason ladder B — "the ESP drew nothing"

This is the single most requested diagnostic in the project. `ui/render/EspRenderView.java`
has **eight** early returns in `update()` and `onDraw()` that blank the entire overlay, plus
**nine** per-entity `continue`s that blank one box. All are silent today. The `hasState` flag
(`:1006`, `:1116`) is the union of the first group and is the only observable, and it only
surfaces as the string `"VIEW -- (no view state)"` at `:1319`.

### B1 — whole-overlay bails (`update()`, `ui/render/EspRenderView.java:1002-1267`), 120 Hz

| # | file:line | trigger | vis | consequence | sev | counter | normal in play? | mark |
|---|---|---|---|---|---|---|---|---|
| 1 | `:1009` | `esp == null` | silent | nothing drawn | fatal | `RENDER_NO_ENGINE` | **yes** — the whole time you are outside a match | counter |
| 2 | `:1009` | `!esp.maskReady()` | silent | nothing drawn | degraded | `RENDER_MASK_NOT_READY` | **yes** — the first seconds of every match, and again after a key rotation | counter |
| 3 | `:1017` | `ownMs <= 0` | silent | nothing drawn | fatal | `RENDER_NO_OWN_STATE` | at match start only | counter |
| 4 | `:1017` | `now - ownMs > OWN_STALE_MS` (`:592`, 2000 ms) | silent | **the entire overlay blanks** | fatal | `RENDER_OWN_STALE` | brief gaps only. **This is the field the vehicle blackout was reading** — the comment at `:1011-1015` records that using `ownLastUpdateMs` here blanked everything ~1.6 s into every ride while a working self-echo fallback sat unused. A sustained non-zero here with `esp.ownFromEcho()` true is that bug returning. | both |
| 5 | `:1024` | `!sane(px) \|\| !sane(py) \|\| !sane(pz)` (`sane` at `:1269`) | silent | nothing drawn | fatal | `RENDER_OWN_INSANE` | never | both |
| 6 | `:1032` → `:1101` | `!full.yawKnown()` → folded-yaw fallback, `pitch = PITCH_FALLBACK_RAD` | silent | boxes still draw but with a guessed pitch and no camera extrapolation (`:1110`) | degraded | `RENDER_YAW_FOLDED` | briefly at match start | counter |
| 7 | `:1095-1100` | `ln <= 1e-6` → `fwdValid = false` | silent | falls back to the `theta`/`pitch` basis at `onDraw:1356-1362`; a degenerate direction vector reads as a calibration error | degraded | `RENDER_FWD_DEGENERATE` | never | both |

### B2 — whole-overlay bails (`onDraw()`, `:1345-1628`), 120 Hz

| # | file:line | trigger | vis | consequence | sev | counter | normal? | mark |
|---|---|---|---|---|---|---|---|---|
| 8 | `:1346` | `!hasState` | silent | **nothing at all is drawn — not boxes, not the radar, not the aim circle.** The union of B1. | fatal | `RENDER_NO_STATE` | yes, outside a match | counter |
| 9 | `:1349` | `w <= 0 \|\| h <= 0` | silent | nothing drawn; the window has no surface | fatal | `RENDER_NO_SURFACE` | at attach only | both |
| 10 | `:1383` | `rLen < 1e-6 \|\| uLen < 1e-6` — degenerate right/up basis | silent | **everything blanks, including the radar**, and `hasState` is still true so the debug panel claims the view state is fine | fatal | `RENDER_BASIS_DEGENERATE` | never | both |
| 11 | `:1433` | `SHOW_BOXES` false | silent | no boxes; radar and aim still drawn | benign | `RENDER_BOXES_OFF` | yes, user choice | counter |
| 12 | `:781-783` | `refreshViewport` — WindowManager call threw, `catch (Throwable ignored)` → falls through to the view's own `w`/`h` at `:784` | silent | silently reintroduces the inset-as-wrong-FOV bug the whole `vpW/vpH` mechanism exists to kill (see `:734-746`) | degraded | `RENDER_VIEWPORT_FALLBACK` | never | both |
| 13 | `:791-792` | `getLocationOnScreen` threw → origin assumed `0,0` | silent | same class of error | degraded | `RENDER_ORIGIN_FALLBACK` | never | both |

### B3 — per-entity bails (the `update()` loop, `:1148-1255`), up to 120 Hz × 64

| # | file:line | trigger | vis | consequence | sev | counter | normal? | mark |
|---|---|---|---|---|---|---|---|---|
| 14 | `:1149` | `n >= MAX_DRAW` (`:599`, 64) `break` | silent | every entity past the 64th is dropped, order-dependent on the map's key iteration | degraded | `RENDER_DRAW_CAP` | never in BR; possible in a 50-player lobby | counter |
| 15 | `:1151` | `t == null` (map race) | silent | one box missing for one frame | benign | `RENDER_TRACK_NULL` | rare | counter |
| 16 | `:1152` | `now - t.updateMs >= STALE_MS` (`:589`, 1500 ms) | silent | **the box disappears.** This is the per-entity twin of B1#4 and the `docs/CS_MODE_ESP_FAILURE.md` signature: the engine reports live entities, the renderer draws none. | degraded | `RENDER_ENTITY_STALE` | yes at the edge of the visibility mask; healthy = a small fraction. **`RENDER_ENTITY_STALE ≈ engine live count` for >2 s is the blackout alarm (§9).** | counter |
| 17 | `:1156` | `!sane(e1) \|\| !sane(e2)` | silent | box missing | degraded | `RENDER_ENTITY_INSANE` | never | both |
| 18 | `:1197` | `role == ROLE_SELF` | silent | correct — never draw yourself | benign | `RENDER_ROLE_SELF` | yes, ~1/frame | counter |
| 19 | `:1198` | `role == ROLE_TEAM && !SHOW_TEAM` | silent | teammates hidden | benign | `RENDER_ROLE_TEAM_FILTERED` | yes, user choice | counter |
| 20 | `:1199` | `role == ROLE_UNKNOWN && !SHOW_UNCLASSIFIED` | silent | **unclassified entities are invisible.** The comment at `:1190-1195` says the classifier needs 40 samples to commit; if it never commits (the friend/foe relational rule, `docs/FRIEND_FOE_AUTHORITATIVE.md`), every entity dies here and the ESP is blank with a healthy engine. | degraded | `RENDER_ROLE_UNKNOWN_FILTERED` | yes for the first ~8 s of a match; **not** for a whole match | counter |
| 21 | `:1203` | `t.dead` | silent | correct — the server keeps streaming dead players | benign | `RENDER_ENTITY_DEAD` | yes, grows through a match | counter |
| 22 | `:1208` | `distM < MIN_DIST_M` (`:602`, 1.0 m) | silent | belt-and-braces self filter | benign | `RENDER_TOO_CLOSE` | rare | counter |
| 23 | `:1211` | height implausible (`\|eZ - pz\| >= HEIGHT_REL_MAX`) → substitutes `ownY` | silent | the box is drawn at *your* ground level — visibly wrong rather than absent, which is worse | degraded | `RENDER_HEIGHT_SUBSTITUTED` | never | both |

### B4 — per-entity bails (`onDraw` / `selectAimTarget` / `project`)

| # | file:line | trigger | vis | consequence | sev | counter | normal? | mark |
|---|---|---|---|---|---|---|---|---|
| 24 | `:1445` (via `project` `:1838`, `depth < NEAR_UNITS` = 100) | `!feetVis \|\| !headVis` | silent | the box is skipped — "behind the camera". With a wrong third-person boom (`:1391-1396`) a target *in front of you* can land behind the derived eye and vanish. | degraded | `RENDER_BEHIND_CAMERA` | yes for anyone behind you; healthy ≈ half of all tracked entities | counter |
| 25 | `:1560`, `:1572` | pose ray endpoints not both visible | silent | the pose ray is not drawn | benign | `RENDER_POSE_CLIPPED` | yes | counter |
| 26 | `:1585` | `ni < 0` — no nearest target | silent | `calibHint()` says "no target tracked" | benign | already surfaced by `calibHint()` | — | — |
| 27 | `:1611-1617` | `mi < 0` → `MarkTarget.clear()` | silent | the Cmd 148 rewrite then passes every mark — pairs exactly with `MarkFilter.passedNoTarget` | degraded | `RENDER_MARK_NO_TARGET` | yes when nothing is tracked | counter |
| 28 | `:1659`, `:1660` | aim role filters (`AIM_TEAM_CHECK`, `!AIM_TARGET_UNKNOWN`) | silent | an enemy is never aim-targetable | benign | `RENDER_AIM_ROLE_FILTERED` | yes | counter |
| 29 | `:1663-1664` | `!project(...)` for the aim point | silent | target skipped | benign | `RENDER_AIM_BEHIND_CAMERA` | yes | counter |
| 30 | `:1678` | `err > gate` (`AIM_FOV_DEG`, widened by `AIM_HYSTERESIS` when locked) | silent | target outside the cone | benign | `RENDER_AIM_OUT_OF_FOV` | yes, the common case | counter |
| 31 | `:1700-1703` | `bestIdx < 0` → `aimValid = false; lockedId = 0` | `logs` (`statusLine()` `:1316`) | "AIM no target in N°" | benign | `RENDER_AIM_NO_TARGET` | yes | counter |
| 32 | `:1715` / `:1737-1739` | `!(AIM_INJECT && aimValid)` → `AimInjector.aimRelease()` | silent | **this is where "the aim does nothing" starts** when the toggle is armed but the renderer never publishes an error. Ladder A cannot distinguish it from "Shizuku down" today. | degraded | `RENDER_AIM_INJECT_OFF` / `RENDER_AIM_NO_TARGET` | yes | counter |
| 33 | `:1723`, `:1729` | `dy`/`dx` clamped to `halfH` | silent | a huge error is silently truncated; the controller then under-corrects and the stall detector may fire | degraded | `RENDER_AIM_ERR_CLAMPED` | rare | counter |
| 34 | `:1619-1625` | `!AIM_ON` → `aimValid=false`, `lockedId=0`, `aimRelease()` | silent | correct | benign | `RENDER_AIM_OFF` | yes, user choice | counter |

**Ladder B, read as a dump.** In order: `RENDER_NO_ENGINE` → `RENDER_MASK_NOT_READY` →
`RENDER_OWN_STALE`/`RENDER_NO_OWN_STATE` → `RENDER_BASIS_DEGENERATE` → `RENDER_NO_SURFACE` →
`RENDER_ENTITY_STALE` → `RENDER_ROLE_*_FILTERED` → `RENDER_BEHIND_CAMERA`. The first one that is
non-zero *and* accounts for the whole entity population is the layer that gave up.

---

## 3. `filter/` — the packet path

### 3.1 `filter/AimFilter.java` (Cmd 106 hit-zone rewrite)

Already the best-instrumented file in scope (§7), but `dbgPassSafe` is a **seven-way** bucket
and `rebuildBody` has **six** completely silent `-1` returns.

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `:411` | `!active` | silent | correct | benign | — (leave silent) | — | — |
| `filter/DefaultFilterEngine.java:81` | `ctx.hasCmd()` false → `AimFilter` is **never called** | silent | every hit in the pre-solver window and after each key rotation passes unrewritten, and `dbgSeen` does not move — indistinguishable from "no one is shooting" | degraded | `FILTER_CMD_UNRESOLVED` (shared with mark) | up to 1000/s during the window | both |
| `:426-430` | `headerSize != HEADER_RELIABLE` | logs + `dbgPassSafe` | hit passes | degraded | `AIM_NOT_RELIABLE` | rare | counter |
| `:435-439` | `schedule() == null` | logs + `dbgNoKey` | **already covered** | — | — | — | — |
| `:443-447` | `payLen < MIN_CIPHERTEXT \|\| (payLen & 7) != 0` | logs + `dbgPassSafe` | hit passes | degraded | `AIM_BAD_PAYLEN` | rare | counter |
| `:452-455` | `plainLen <= 0` (wrong key / not QQ-TEA) | **`dbgPassSafe` only, no log** — the one member of this family with no line | wrong key silently in use; every hit passes | fatal | `AIM_DECRYPT_FAIL` | up to 20/s | both |
| `:458-465` | `!walk(...)` or any of the seven required `fStart[] < 0` | logs + `dbgPassSafe` | the body program no longer matches this build → **every** hit passes | fatal | `AIM_WALK_FAIL` | up to 20/s | both |
| `:498-503` | zone not Body/Limb, or already the target zone | logs + `dbgSkipZone` | correct | benign | **already covered**; healthy = a large fraction (head hits, vehicle, protection) | — | — |
| `:508-512` | `zone3hi != zone7` (two-copy disagreement) | logs + `dbgPassSafe` | field map wrong for this variant | degraded | `AIM_ZONE_DISAGREE` | rare | both |
| `:531-534` | upper-body gate: `residual < floorMm` | logs + `dbgUbSkipped` | correct — a leg shot is not rewritten | benign | `AIM_UB_TOO_LOW` (split) | up to 20/s | counter |
| `:536-538` | upper-body gate: victim **not tracked**, cannot measure | logs + `dbgUbSkipped` (**same counter as above**) | a *legitimate* head-height hit is refused because the ESP lost the victim — a very different fault | degraded | `AIM_UB_NO_TRACK` (split) | up to 20/s | counter |
| `:556` → `:573-575` | harvested `idx15` too wide for the field → mode fallback | **log only, no counter** | #8 harvest silently degrades to the generic mode | benign | `AIM_HARVEST_IDX15_WIDE` | rare | counter |
| `:579-584` | `varintWidth(newVal3) > fWidth[idx3]` or idx15 overflow | logs + `dbgPassSafe` | hit passes | degraded | `AIM_WIDTH_OVERFLOW` | rare | counter |
| `:596-604` | `esp == null` or `headPointForVictim` false → zone flip only | logs + `dbgNoVictim` | **already covered** | — | — | — | — |
| `:623-626` | cp patch on but `cfgTargetZone != ZONE_HEAD` | **log only** | knob #7 silently does nothing | benign | `AIM_CP_SKIP_TARGET_NOT_HEAD` | rare | counter |
| `:636-638` | permuted slot out of range | **log only** | cp patch silently skipped | degraded | `AIM_CP_SKIP_SLOT_OOR` | rare | both |
| `:639-641` | `cpCount < CANON_ZONE_MAX + 1` (fewer than 34 entries) | **log only** | cp patch silently skipped | degraded | `AIM_CP_SKIP_FEW_ENTRIES` | rare | counter |
| `:691-693` | `rebuildBody` returned ≤0 → in-place fallback | logs + `dbgHitKept` | counted, but the *reason* is one of the six below | degraded | keep `dbgHitKept`, add the six | up to 20/s | counter |
| `:835` | `PacketPipeline.current() == null` | **silent** | rebuild refused | degraded | `AIM_RB_NO_PIPELINE` | rare | counter |
| `:837` | `pipe.layout() == null` | **silent** | rebuild refused (no solved header yet) | degraded | `AIM_RB_NO_LAYOUT` | rare | counter |
| `:841` | `reg9 < 0 \|\| endIdx9 > plainLen` | **silent** | rebuild refused | degraded | `AIM_RB_BAD_IDX9` | rare | counter |
| `:847-856` | checkParams region validation failed → `effCp = CP_NONE` | **log only** | the cp patch silently downgrades to a verbatim copy | degraded | `AIM_CP_REGION_BAD` | rare | counter |
| `:914` | `changed != 3` after the zone-triple write | **log only** | a partial zone triple — a *worse* packet than no patch | degraded | `AIM_CP_PARTIAL` | rare | both |
| `:923` | `ctx.off + newTotal > ctx.buf.length` | **silent** | rebuild refused | degraded | `AIM_RB_NO_ROOM` | rare | counter |
| `:930` | `declared != ctx.plen - headerSize` — the layout does not decode this packet | **silent** | rebuild refused. **This is the key-rotation detector** and it currently reports nothing. | degraded | `AIM_RB_LAYOUT_STALE` | spikes at match/room transitions | both |
| `:935` | `cl != encLen` | **silent** | rebuild refused | degraded | `AIM_RB_ENCLEN_MISMATCH` | never | both |
| `:708-712` | `cipherLen != payLen` on the in-place path | logs + `dbgPassSafe` | hit passes; the buffer still holds the untouched original | degraded | `AIM_CIPHERLEN_MISMATCH` | never | both |
| `:1123` | `hex == null \|\| hex.length() != 32` | silent (surfaces as `dbgNoKey`) | correct before the key is sniffed | benign | `AIM_KEY_ABSENT` | — | counter |
| `:1129` | `hi < 0 \|\| lo < 0` — malformed hex → `return null` **without caching**, so it is re-parsed per packet | silent | indistinguishable from "no key yet" | degraded | `AIM_KEY_MALFORMED` | up to 20/s | both |

> **Asymmetry, no change made.** `MarkFilter` wraps `Tea.qqTeaDecrypt` in `try/catch`
> (`filter/MarkFilter.java:213-219`) and `Tea.qqTeaEncrypt` likewise (`:283-289`). `AimFilter`
> does not (`:451`, `:707`). Whatever the right answer is, the two should agree; noting it as a
> robustness gap rather than a diagnostic one.

### 3.2 `filter/MarkFilter.java` (Cmd 148 map-mark retarget)

`passedBad` is a **twelve-way** bucket. The `lastNote` string carries the reason but only for
the most recent packet, and `status()` — the only reader of it — **has no caller anywhere in the
app** (§8).

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `:149` | `!ENABLED` | silent | correct (default OFF by design, `:105-108`) | benign | — | — | — |
| `filter/DefaultFilterEngine.java:89` | `!ctx.hasCmd()` → `MarkFilter` never called | silent | a mark tapped in the pre-solver window is never retargeted and `seen` does not move | degraded | `FILTER_CMD_UNRESOLVED` (shared) | — | counter |
| `:158-162` | `!MarkTarget.isValid() \|\| age > 3000` | note + `passedNoTarget` | **already covered**; pairs with `RENDER_MARK_NO_TARGET` (B4#27) | — | — | <1/min | — |
| `:166-170` | `headerSize != HEADER_RELIABLE` | note + `passedBad` | mark not retargeted | degraded | `MARK_NOT_RELIABLE` | <1/min | counter |
| `:172-177` | `BodyCrypt.schedule() == null` | note + `passedNoKey` | **already covered** | — | — | — | — |
| `:179-185` | no `PacketPipeline` / no layout | note + `passedBad` | mark not retargeted | degraded | `MARK_NO_LAYOUT` | <1/min | counter |
| `:189-193` | payload length invalid | note + `passedBad` | mark not retargeted | degraded | `MARK_BAD_PAYLEN` | <1/min | counter |
| `:203-208` | `declared != payLen` — layout stale | note + `passedBad` | mark not retargeted; the **only** place a key rotation is detectable on this channel | degraded | `MARK_LAYOUT_STALE` | <1/min | both |
| `:213-219` | `Tea.qqTeaDecrypt` threw | note + `passedBad` | mark not retargeted | degraded | `MARK_DECRYPT_THREW` | <1/min | both |
| `:220-224` | `plainLen <= 0` | note + `passedBad` | wrong key | fatal | `MARK_DECRYPT_FAIL` | <1/min | both |
| `:229`, `:231`, `:238`, `:244` (via `passBad`, `:315-319`) | body parse failures (author / flags / pos0-2 / tail) | note + `passedBad` | the `U B B Z Z Z B B B` layout no longer matches | fatal | `MARK_PARSE_FAIL` + a reason tag | <1/min | both |
| `:248-252` | `plain[isDelPos] != 0` — an *unmark* | note + `passedBad` | **correct and expected**, but it pollutes the "bad" bucket with a healthy outcome | benign | `MARK_IS_DEL` (split out) | <1/min | counter |
| `:274-278` | `ctx.off + newTotal > ctx.buf.length` | note + `passedBad` | mark not retargeted | degraded | `MARK_NO_ROOM` | never | both |
| `:285-289` | `Tea.qqTeaEncrypt` threw | note + `passedBad` | mark not retargeted | degraded | `MARK_ENCRYPT_THREW` | never | both |
| `:290-294` | `cl != encLen` | note + `passedBad` | mark not retargeted | degraded | `MARK_ENCLEN_MISMATCH` | never | both |

### 3.3 `filter/TeleportFilter.java`

Well counted on the drop paths; the **write** path is not. `writeState()` returns `-1` from four
distinct places and they all land in one counter.

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `:241-244` | `!isPositionReport(ctx)` | silent | correct — fire, damage, input, control untouched | benign | — (leave silent; ~1000/s) | — | — |
| `:246` | `state == IDLE` | silent | correct | benign | — | — | — |
| `:256-265` | mounted (2002/2006/2031) → DROP | `dbgMounted` + `dbgDropped` | **already covered** | — | — | ~10/s while mounted | — |
| `:267-276` | `!sync.parse(...)` → DROP | logs + `dbgParseDrop` | **already covered**. Sustained = a key rotation or an unknown variant; the ramp stands down. | — | — | — | — |
| `:283-292` | `sync.rawAt(V_PLATFORM_ID) != 0` → DROP | `dbgPlatform` + `dbgDropped` | **already covered** | — | — | — | — |
| `:191-196` | `replayAnchor()`: `anchorPacket == null` → **silent return** | silent | while mounted or platform-gated *before* any on-foot anchor exists, the 2 Hz liveness replay sends **nothing at all** — the server gets no position for the whole ride | fatal | `TELE_REPLAY_NO_ANCHOR` | ≤2/s | both |
| `:201` | `sender.send(...)` return value **discarded**, then logged as `REPLAY_TELE_ANCHOR` regardless | silent | a failed replay is recorded as a successful one. `ReplayEngine:63-73` checks this; this path does not. | degraded | `TELE_REPLAY_SEND_FAIL` | ≤2/s | both |
| `:366-375` | `writeState(...) < 0` → DROP | logs + `dbgWidthDrop` | counted, reason unknown → the four below | degraded | keep `dbgWidthDrop`, add four | ~10/s | counter |
| `:429` | `!sync.seal()` on the in-place path | **silent** | report withheld | degraded | `TELE_SEAL_FAIL` | rare | counter |
| `:438` | `PacketPipeline.current() == null` | **silent** | report withheld; the ramp degrades to "frozen" | degraded | `TELE_RB_NO_PIPELINE` | rare | counter |
| `:440` | `pipeline.layout() == null` | **silent** | as above — the documented pre-convergence case (`:433-435`) | degraded | `TELE_RB_NO_LAYOUT` | spikes at session start | counter |
| `:448-450` | `sync.rebuild(layout) <= 0` | **silent** | report withheld | degraded | `TELE_REBUILD_REFUSED` | rare | both |
| `:644-655` | `isPositionReport` fell to the shape heuristic (`!ctx.hasCmd()`) | `dbgExact` boolean only — no count, and it is overwritten every packet | the pre-solver window is invisible in the dump | degraded | `TELE_HEURISTIC_PATH` | up to 1000/s during the window | counter |
| `:522-537` | `pathN >= PATH_MAX` → the route is halved by dropping every other point | silent | the replayed route coarsens from 0.4 m to 0.8 m spacing; at the third halving it can start cutting corners through scenery — the exact failure `:453-464` exists to prevent | degraded | `TELE_PATH_DECIMATED` | rare | both |
| `:765-767` | `onTunnelRestart()` intentionally empty | documented | **correct, leave silent** | benign | — | — | — |

### 3.4 `filter/GhostFilter.java`

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `:183-190` | `!active` → refresh saved state, PASS | silent | correct | benign | — | — | — |
| `:224-227` | `!isMove && !isKeepalive` | silent | ghost recognises nothing. `dbgKeepalive`/`dbgMove` are only incremented while active (`:201-202`), so a zero there is the signal — but it cannot separate "saw traffic, matched none" from "saw no traffic". | degraded | `GHOST_UNRECOGNISED` | up to 1000/s | counter |
| `:237-239` | `!exact && !GamePacketTaxonomy.isMatchStreamLive(...)` | **silent** | **this is the documented historical killer**: the panel read `live=N` and every drop was blocked here with no counter (see `:126-140`, `:228-236`). | fatal | `GHOST_NOT_LIVE` | up to 10/s | both |
| `:245-261` | anchor slot already populated → `else if` falls through | silent | correct — never overwrite the frozen state | benign | — | — | — |
| `:293-305` | `replaySavedState()` with both `savedKeepalive` and `savedMove` null → sends nothing | silent | the 2 Hz liveness replay is a no-op; the server gets no position | fatal | `GHOST_REPLAY_NO_STATE` | ≤2/s | both |
| `:308`, `:313` | `sender.send(...)` return **discarded**, logged as success either way | silent | a failed replay reads as a successful one | degraded | `GHOST_REPLAY_SEND_FAIL` | ≤2/s | both |
| `:159`, `:178` | `isMove` is hardwired `false` on **both** paths | n/a | `dbgMove` can never increment — a permanently-zero counter in the HUD (`:97`) that reads as a fault | benign | retire `dbgMove` or document it as always-zero | — | — |
| `:194-222` | the 1 Hz `Log.i("FakelagGhost", …)` diagnostic block | logs | a temporary trace (`:191`) that builds a ~200-char string once a second while ghost is on | benign | fold into counters; the string build is the cost, not the log | 1/s | — |

### 3.5 `filter/FreezeFilter.java`

Four of the five heuristic-path bails and the endpoint gate are completely silent. `debugLine()`
(`:94-99`) reports only `drop` and `dmgthru`, so "freeze did nothing this match" has no reason.

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `:123-125` | `!active` | silent | correct | benign | — | — | — |
| `:129-131` | `!GamePacketTaxonomy.isFromMatchServer(ctx.dip, ctx.sp)` | **silent** | if the match server is never learned, freeze withholds **nothing for the whole match** and the panel shows `drop=0` with no explanation | fatal | `FREEZE_NOT_MATCH_SERVER` | up to 1000/s | counter |
| `:140-142` | `Cmd.isTransportLayer(ctx.cmd)` | silent | correct — acks/pings/fragments must never be dropped | benign | `FREEZE_PASS_TRANSPORT` (denominator only) | high | counter |
| `:143-150` | `!Cmd.isWorldStateStream(ctx.cmd)` | partly counted (`dbgCombatPassed` for combat only) | correct; the non-combat remainder has no denominator | benign | `FREEZE_PASS_NON_WORLD` | high | counter |
| `:156-158` | heuristic path, `!isMatchStreamLive(...)` | **silent** | same class as `GHOST_NOT_LIVE` | degraded | `FREEZE_NOT_LIVE` | up to 1000/s | counter |
| `:159-161` | `plen < SHAPE_MIN(20) \|\| plen > SHAPE_MAX(1400)` | **silent** | a chain outside the window is never frozen | degraded | `FREEZE_SHAPE_LEN` | high | counter |
| `:162-165` | `family(...) == FAMILY_R` | **silent** | correct — the reliability family must pass | benign | `FREEZE_FAMILY_R` | high | counter |
| `:166-168` | `!looksLikeEntityChain(ctx)` | **silent** | pre-solver freeze does nothing | degraded | `FREEZE_SHAPE_MISS` | high | counter |
| `:189` | `off + 10 > buf.length` inside `looksLikeEntityChain` | silent | folds into `FREEZE_SHAPE_MISS`; worth its own tag only if it is ever non-zero | benign | — | — | — |

### 3.6 `filter/DefaultFilterEngine.java`

| file:line | trigger | vis | consequence | sev | counter | mark |
|---|---|---|---|---|---|---|
| `:81`, `:89` | `ctx.hasCmd()` gate — aim and mark are not consulted at all when the command id is unresolved | **silent** | the pre-solver window and every post-rotation window are invisible: `AimFilter.dbgSeen` and `MarkFilter.seen` both stay flat and look like "nothing happened" | degraded | `FILTER_CMD_UNRESOLVED` (one counter, shared) | both |
| `:158-164` `disableAll()` | `mark.shutdown()` is **not** called (freeze/ghost/teleport/aim are) | silent | `MarkFilter.ENABLED` survives a network change or app switch — the one filter that rewrites a packet *other players see* stays armed after everything else is disarmed | degraded | `FILTER_MARK_STILL_ARMED` (assert, §9) | event |
| `:184-190` `shutdown()` | same omission | silent | as above | degraded | same | event |
| `:28` | `executor` (`Executors.newCachedThreadPool()`) is created and `shutdownNow()` at `:190`, but **nothing is ever submitted to it** | n/a | a thread pool allocated per tunnel for no consumer | benign | not a diagnostic — a cleanup candidate | — |

### 3.7 `filter/replay/` — **dead code, do not instrument**

`ReplayEngine` is constructed (`DefaultFilterEngine:39`) and `setTeleReplayDelayMs` is called
(`:42-43`), but `replayTelePackets`, `replayPacketList` and `teleReplayTask` have **no production
caller**. `PacketBuffer` is never constructed outside its own file. The hold-and-replay design
was replaced by the anchor/ramp model (`filter/TeleportFilter.java:15-46`) and this package is
its residue.

For the record, if it is ever revived:

| file:line | trigger | vis | proposed counter |
|---|---|---|---|
| `filter/replay/ReplayEngine.java:57-62` | abort gate or thread interrupt mid-replay | logs | `REPLAY_ABORTED` |
| `filter/replay/ReplayEngine.java:69-73` | `sender.send` returned false | logs | `REPLAY_SEND_FAIL` |
| `filter/replay/ReplayEngine.java:77-79` | `InterruptedException` swallowed, documented as deliberate | silent | **correct, leave silent** |
| `filter/replay/PacketBuffer.java:39-41` | `add()` evicts the oldest entry when full | silent | `REPLAY_BUF_EVICTED` |
| `filter/replay/PacketBuffer.java:67-69` | `tryAdd()` refuses when full | silent (caller drops) | `REPLAY_BUF_FULL` |

### 3.8 `filter/PacketClassifier.java`

`:22-36` returns `TYPE_NONE` silently for anything that is not a movement stream. The class
javadoc says it is kept only for the jitter replay path (now dead) and dev-capture labelling, so
this bail is correct and should stay silent. No counter.

---

## 4. `ui/overlay/` and `ui/panel/` — windows that fail to attach

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `ui/overlay/EspOverlay.java:121-127` | `wm.addView(renderView)` threw → `renderView = null`, `renderAdded` stays false | **silent** | **no ESP at all** and the app looks perfectly normal | fatal | `OVERLAY_RENDER_ADDVIEW_FAIL` | once | event |
| `ui/overlay/EspOverlay.java:165-171` | `wm.addView(debugPanel)` threw | **silent** | no debug readout — the diagnostic surface itself is the thing that vanished | fatal | `OVERLAY_DEBUG_ADDVIEW_FAIL` | once | event |
| `ui/overlay/EspOverlay.java:173` | `!renderAdded && !debugAdded` → return before the handler, the frame callback and the ticker are created | silent | nothing runs, and there is no retry path | fatal | `OVERLAY_BOTH_FAILED` | once | event |
| `ui/overlay/EspOverlay.java:88` | `if (renderAdded \|\| debugAdded) return;` | silent | a partial previous `show()` (one window up, one failed) makes every later `show()` a no-op — the missing window can never be recovered without `hide()` | degraded | `OVERLAY_SHOW_REENTRY` | rare | event |
| `ui/overlay/EspOverlay.java:187` | `doFrame`: `if (!renderAdded) return;` — **without re-posting the callback** | silent | the 120 Hz loop terminates permanently the first time this is false; it cannot restart even if `renderAdded` becomes true | fatal | `OVERLAY_FRAME_LOOP_STOPPED` | once | event |
| `ui/overlay/EspOverlay.java:62-65` | `AimInjector.init()` in the constructor, `catch (Throwable ignored)` | silent | aim dead, overlay fine — exactly the split the comment at `:60-61` intends, but with no record | degraded | `OVERLAY_AIM_INIT_THREW` | once | event |
| `ui/overlay/EspOverlay.java:336`, `:345`, `:350` | `removeFrameCallback` / `removeView` catches during `hide()` | silent | **correct, leave silent** — teardown | benign | — | — | — |
| `ui/overlay/CrosshairView.java:60-68` | `wm.addView` threw → `view = null; params = null` | **silent** | the crosshair silently never appears | degraded | `CROSS_ADDVIEW_FAIL` | once | event |
| `ui/overlay/CrosshairView.java:102-105` | `updateCrosshair` retries `makeCrosshairView`, then `if (view == null) return;` | silent | retried on every appearance broadcast, silently, forever | degraded | `CROSS_UNAVAILABLE` | per broadcast | counter |
| `ui/overlay/CrosshairView.java:115-117` | `wm.updateViewLayout` threw | silent | the size/alpha slider silently does nothing | degraded | `CROSS_UPDATE_FAIL` | per broadcast | counter |
| `ui/overlay/DevPopup.java:64-71` | `wm.addView` threw (`// ignore`) → `added=false`, but `view = tv` is still assigned at `:73` | **silent** | the DEV LOG button never appears; `remove()` (`:96`) then returns early because `!added`, leaving `view` non-null so `make()` (`:35`) refuses to retry — **permanently wedged** | degraded | `DEVPOPUP_ADDVIEW_FAIL` | once | event |
| `ui/overlay/DevPopup.java:83-87`, `:97-101` | `updateViewLayout` / `removeView` catches | silent | benign | benign | — | — | — |
| `ui/panel/EspTunePanel.java:202-211` | `wm.addView(container)` threw → `added=false, root=null; return;` — **before** the drag listener, `setExpanded(false)` and the hint ticker are wired | **silent** | the whole tune panel is missing; every knob, every status row and the calibration hint go with it | fatal | `PANEL_ADDVIEW_FAIL` | once | event |
| `ui/panel/EspTunePanel.java:145` | `if (added) return;` in `show()` | silent | correct (idempotent) | benign | — | — | — |
| `ui/panel/EspTunePanel.java:1390-1392` | header drag `updateViewLayout` threw | silent | the panel stops following the finger | benign | `PANEL_DRAG_UPDATE_FAIL` | rare | counter |
| `ui/panel/EspTunePanel.java:1371`, `:1381` | `params == null` / `root == null` → `return false` | silent | the header is inert after a failed attach | degraded | folds into `PANEL_ADDVIEW_FAIL` | — | — |
| `ui/panel/EspTunePanel.java:828-833`, `:835-842` | `saveOpenSection` / `loadOpenSection` `catch (Throwable ignored)` | silent | the panel silently forgets which section was open | benign | `PANEL_PREF_THREW` | rare | counter |
| `ui/panel/EspTunePanel.java:978-983`, `:1000-1005` | `wm.getDefaultDisplay().getRealSize(p)` threw → hardcoded `1080×2400` | silent | the self-test and the calibrator run against a **fabricated screen size**, so the injected anchor lands in the wrong place and the result is wrong rather than absent | degraded | `PANEL_SCREEN_SIZE_FALLBACK` | user-initiated | event |
| `ui/panel/EspTunePanel.java:1007-1010` | `PacketVpnService.espEngine()` threw → `esp = null` | silent | the calibrator reports "engine off (join a match)" for a *different* reason | degraded | `PANEL_ENGINE_LOOKUP_THREW` | user-initiated | event |
| `ui/panel/EspTunePanel.java:1040-1044` | `action()` row: `catch (Throwable ignored)` around `onTap.run()` | **silent** | tapping a panel action button does nothing at all, with no feedback | degraded | `PANEL_ACTION_THREW` | user-initiated | both |
| `ui/panel/EspTunePanel.java:1339-1341` + `:274` | `refreshAll()` is called **only** from `setExpanded(true)`; the hint ticker (`:252-263`) repaints `hintView` only | **silent** | every `info()` status row — `AimInjector.debugLine()` (`:429-431`), `TouchWatcher.debugLine()` (`:540-542`), the self-test result (`:440-442`), `AimCalibrator.status()` (`:450-452`) — is **frozen at the value it had when the panel was expanded**. Start Shizuku after opening the panel and the status row still says NOT RUNNING until you collapse and re-expand. | degraded | not a counter — a real defect; the `info()` rows need the hint ticker's cadence | — | event |
| `ui/aim/AimEditOverlay.java:139-142` | `wm.addView(v, p)` threw, `catch (Exception ignored)` — but `show()` still sets `shown = true` and `EspRenderView.AIM_EDIT = true` at `:87-88` | **silent** | the renderer draws the "AIM"/"SWIPE" labels (`EspRenderView:1764-1767`, `:1777-1779`) with **no grab handles behind them** — the editor looks open and cannot be used | fatal | `EDIT_ADDVIEW_FAIL` | once | event |
| `ui/aim/AimEditOverlay.java:55-63` | `setVisible` `catch (Throwable t) → shown = false` | silent | the editor silently refuses to open | degraded | `EDIT_SHOW_THREW` | user-initiated | event |
| `ui/aim/AimEditOverlay.java:183-186` | drag `updateViewLayout` threw | silent | the handle stops following the finger but `publish()` still writes the new position to `EspTuning` — **the drawn marker and the stored value diverge** | degraded | `EDIT_UPDATE_FAIL` | per move | counter |
| `ui/aim/AimEditOverlay.java:216-225` | `getRealSize` threw → `getSize` (itself unguarded); `p.x <= 0` → hardcoded `1080×2400` | silent | handles land in the wrong place and `publish()` (`:199-209`) stores coordinates computed against a fabricated screen | degraded | `EDIT_SCREEN_SIZE_FALLBACK` | once | event |
| `ui/aim/AimEditOverlay.java:101-107` | `removeSafely` catch | silent | **correct, leave silent** | benign | — | — | — |

---

## 5. `ui/button/` — controls that miss

| file:line | trigger | vis | consequence | sev | counter | rate | mark |
|---|---|---|---|---|---|---|---|
| `ui/button/OverlayButton.java:135-140` | `wm.addView(tv, p)` threw → `added = false`, returned in `ButtonResult` | silent here (the caller is told, but nothing logs it) | the button is absent; no touch listener is attached (`:142-144`) | fatal | `BTN_ADDVIEW_FAIL` | once/button | event |
| **`ui/button/OverlayButton.java:172-175`** | `updateButtonLayout` recomputes `int sizePx = Math.max(72, Math.round(160 * scale));` — **raw pixels**, contradicting the dp fix applied to `makeBtn` at `:90-98` | **silent** | resizing from the settings panel reverts every button to the density-blind sizing the comment at `:90-94` describes: on a 3× screen the floor is 72 px = **24 dp**, half the 48 dp minimum touch target. No error — just a control pressed mid-match that misses. This is the live half of that bug. | degraded | `BTN_SIZE_BELOW_MIN` (assert `sizePx >= 48dp`) | per broadcast | both |
| `ui/button/OverlayButton.java:181-183` | `wm.updateViewLayout` threw | silent | the size/alpha change is silently dropped | degraded | `BTN_UPDATE_FAIL` | per broadcast | counter |
| `ui/button/OverlayButton.java:150`, `:170` | `tv == null` / `params == null` → return | silent | a button that failed to attach is silently skipped forever | degraded | folds into `BTN_ADDVIEW_FAIL` | — | — |
| `ui/button/OverlayButton.java:235` | `activePointerId != -1` → ignore a second pointer | silent | correct | benign | — | — | — |
| `ui/button/OverlayButton.java:250-252` | `findPointerIndex(activePointerId) < 0` → `return false` | **silent** | the drag is abandoned mid-gesture and `activePointerId` is never reset, so the button is **dead until the next ACTION_CANCEL** | degraded | `BTN_POINTER_LOST` | rare | both |
| `ui/button/OverlayButton.java:261-263` | drag `updateViewLayout` threw | silent | the button stops following the finger but `p.x/p.y` were already mutated — the stored position and the drawn position diverge | degraded | `BTN_DRAG_UPDATE_FAIL` | per move | counter |
| `ui/button/OverlayButton.java:270` | `pointerId != activePointerId` on UP → `return true`, the click is swallowed | **silent** | a two-finger release loses the tap; reads as "the button didn't respond" | degraded | `BTN_UP_WRONG_POINTER` | rare | counter |
| `ui/button/OverlayButton.java:275-277` | `!drag` gate — an 8 px (raw px, density-blind) twitch during a press cancels the click | **silent** | on a 4× screen 8 px is 2 dp; a normal finger roll suppresses the tap | degraded | `BTN_CLICK_SUPPRESSED_BY_DRAG` | occasional | counter |
| `ui/button/OverlayButton.java:282-291` | ACTION_CANCEL releases a hold-style button | silent | correct — the comment at `:285` is right, a lost gesture must not leave aim latched | benign | `BTN_HOLD_CANCELLED` | rare | counter |
| `ui/button/OverlayButton.java:298-394` | `BtnTouchListener` is **never instantiated** | n/a | dead code; do not instrument | benign | — | — | — |
| `ui/button/OverlayTouchListener.java:64-66` | `activePointerId == -1` / `findPointerIndex < 0` → `return false` | silent | same class as above, for the stat/mask-bar views | degraded | `TOUCHLIS_POINTER_LOST` | rare | counter |
| `ui/button/OverlayTouchListener.java:78-80`, `:165-167` | `updateViewLayout` threw | silent | the view stops following the finger | degraded | `TOUCHLIS_UPDATE_FAIL` | per move | counter |
| `ui/button/OverlayAnimations.java:69-72` | `wm.addView(tv, p)` threw → `bannerAdded = false`, **but `topBanner = tv` is still assigned at `:74` and returned** | **silent** | the banner — the "is the engine armed / learning / ready" indicator (`:184-213`) — is absent, while `setBannerStatus` and three animators keep running against a detached view | degraded | `ANIM_BANNER_ADDVIEW_FAIL` | once | event |
| `ui/button/OverlayAnimations.java:79`, `:98` | `ringDrawables.isEmpty()` → return | silent | no ring animation; usually means no buttons attached | benign | `ANIM_NO_RINGS` | once | counter |
| `ui/button/OverlayAnimations.java:118` | `topBanner == null` → return | silent | correct | benign | — | — | — |
| `ui/button/OverlayAnimations.java:185` | `topBanner == null \|\| status == bannerStatus` → return | silent | correct (idempotent) | benign | — | — | — |
| `ui/button/AnimatedCircleDrawable.java:76` | `bounds == null \|\| bounds.isEmpty()` → return | silent | correct — pre-layout | benign | — | — | — |

---

## 6. `ui/settings/`

| file:line | trigger | vis | consequence | sev | counter | mark |
|---|---|---|---|---|---|---|
| `ui/settings/PermissionController.java:64-67` | `startActivityForResult(ACTION_MANAGE_OVERLAY_PERMISSION)` threw, `catch (Exception e) { }` | **silent** | the overlay-permission screen does not open and nothing is said — the single most user-visible dead button in the app, and without that permission **every** overlay in §4 fails to attach | fatal | `PERM_OVERLAY_INTENT_FAIL` | event |
| `ui/settings/PermissionController.java:51-55` | `VpnService.prepare(activity)` threw | **silent** | the VPN consent dialog never opens | fatal | `PERM_VPN_PREPARE_THREW` | event |
| `ui/settings/PermissionController.java:108-110` | `refresh()`: `VpnService.prepare` threw → `vpnOk = false` | **silent** | the dot reports "not granted" even when it is — a **wrong** answer, not a missing one | degraded | `PERM_VPN_CHECK_THREW` | event |
| `ui/settings/PermissionController.java:77-80` | `requestPermissions(POST_NOTIFICATIONS)` threw | silent | no notification permission; the foreground service notification may be suppressed | degraded | `PERM_NOTIF_REQUEST_FAIL` | event |
| `ui/settings/PermissionController.java:89-100` | storage `requestPermissions` threw | silent | captures cannot be written | degraded | `PERM_STORAGE_REQUEST_FAIL` | event |
| `ui/settings/PermissionController.java:76`, `:90` | on SDK < 33 the notification branch does nothing at all | silent | an inert toggle with no feedback | benign | a status string, not a counter | — |
| `ui/settings/AppPicker.java:62` | `pm.getLaunchIntentForPackage(pi.packageName) == null` → `continue` | **silent** | a package with no launcher intent — or hidden by API 30+ package visibility — **never appears in the picker**, so the user cannot target the Free Fire build they are playing. The VPN then carries the wrong package set, which `ui/overlay/EspOverlay.java:232-239` records as "1 outbound packet against 10 886 inbound, all unparsed". Every feature dies at once with no other symptom. | fatal | `PICK_NO_LAUNCH_INTENT` | both |
| `ui/settings/AppPicker.java:96-98` | `catch (Exception e) { e.printStackTrace(); }` — `loaded` is never set true | **silent** (a stack trace nobody reads) | the picker shows "No app!" forever, and `isLoaded()` never flips | fatal | `PICK_LOAD_FAILED` | event |
| `ui/settings/AppPicker.java:105-108` | `appInfos.isEmpty()` → Toast "No app!" | `logs` (a toast) | conflates "still loading" with "load failed" — two different user actions | degraded | split the toast text; `PICK_SHOW_EMPTY` | event |
| `ui/settings/AppPicker.java:64-68` | `getApplicationLabel` threw → falls back to the package name | silent | correct | benign | — | — |
| `ui/settings/AppearanceBroadcaster.java:99-124` | `context.sendBroadcast(intent)` — **no delivery confirmation** | **silent** | if `FloatingOverlayService` is not running or its receiver is not registered, **every settings change is silently lost**: the switch moves, the pref is written, nothing happens on screen | fatal | `BCAST_SENT` here, paired with a `BCAST_RECEIVED` on the service side; alarm on divergence (§9) | counter |
| `ui/settings/AppearanceBroadcaster.java:51-95` | eight silent clamps on stored prefs | silent | a clamp firing means a stale or corrupt pref; the user's stored value is discarded without a word | benign | one `PREF_CLAMPED{key}` | counter |
| `ui/settings/UiBindings.java:148` | `bindSeek`: `seek == null \|\| value == null` → return | **silent** | the seekbar is inert; a renamed layout id produces a control that does nothing, forever, with no error | degraded | `UI_BIND_MISSING_VIEW{id}` | event |
| `ui/settings/UiBindings.java:174` | `setupFloatingToggle`: `toggle == null` → return | **silent** | same, for a toggle | degraded | `UI_BIND_MISSING_TOGGLE{id}` | event |
| `ui/settings/UiBindings.java:44-86` | 25 unchecked `findViewById` calls | silent | the two guards above are the only thing standing between a layout change and a silently dead settings screen | degraded | one `UI_BIND_NULL_COUNT` at the end of the constructor | event |
| `ui/settings/UiBindings.java:201`, `:211`, `:230`, `:264` | `applyToggleState` / `animateToggle` / `setOptionalGroupVisible` / `animateMainEntrance` null guards | silent | correct defensive guards | benign | — | — |

---

## 7. Existing ad-hoc counters in scope

These fold into the registry as-is. Names are the current field names.

**`filter/MarkFilter.java`** (`AtomicInteger`, `:114-118`) — `seen`, `rewritten`,
`passedNoTarget`, `passedNoKey`, `passedBad`. `passedBad` is a twelve-way bucket (§3.2) and
includes one *healthy* outcome (`isDel`, `:248-252`).

**`filter/AimFilter.java`** (`AtomicLong`, `:237-265`) — `dbgActive` (bool), `dbgSeen`,
`dbgRewritten`, `dbgNoKey`, `dbgSkipZone`, `dbgPassSafe`, `dbgHitMoved`, `dbgHitRebuilt`,
`dbgNoVictim`, `dbgHitKept`, `dbgCpPatched`, `dbgZonePatched`, `dbgHarvestHits`,
`dbgHarvestUsed`, `dbgUbSkipped`. `dbgPassSafe` is a seven-way bucket; `dbgUbSkipped` is a
two-way bucket mixing a correct skip with a tracking failure.

**`filter/TeleportFilter.java`** (`:147-168`) — `dbgState` (string), `dbgExact` (bool),
`dbgSeen`, `dbgRewritten`, `dbgWidthDrop`, `dbgInPlace`, `dbgRebuilt`, `dbgParseDrop`,
`dbgDropped`, `dbgMounted`, `dbgPlatform`, `dbgRemainM` (double). `dbgWidthDrop` is a four-way
bucket. Note `press()` resets nine of them (`:683-691`) on every fresh anchor, so they are
per-engagement, not per-session — the registry must not treat them as monotonic.

**`filter/GhostFilter.java`** (`:69-87`) — `dbgActive`, `dbgLive`, `dbgEndpointMatch`,
`dbgShape`, `dbgExact` (all `boolean`, overwritten every packet — **last-value, not counters**),
`dbgKeepalive`, `dbgMove`, `dbgDropped`. `dbgMove` can never increment (`:159`, `:178`).

**`filter/FreezeFilter.java`** (`:83-91`) — `dbgActive`, `dbgExact` (bools), `dbgDropped`,
`dbgCombatPassed`. Reset on `start()` (`:199-200`).

**`ui/aim/AimInjector.java`** (`:97-104`, `:273-277`) — `okCount`, `failCount`, `bailCount`,
`lastBail` (string), `lastError` (string), `lastDy`, `lastDx`, `lastInjectAtMs`, `gestureCount`,
`regripCount`, `lastRegripMs`, `lastStallOk`. `bailCount` is the nineteen-way bucket of ladder A;
`regripCount` mixes edge re-grips with stall re-grips.

**`ui/render/EspRenderView.java`** (`:862-905`) — `lastLeadMs`, `lastLeadEcho`,
`lastCamExtrapDeg`, `lastMeasLagMs`, `lastOwnEcho`, `lastOwnSource`, `lastLayoutSource`,
`nearValid`/`nearId`/`nearDistM`/`nearNdcX`/`nearNdcY`/`nearOnScreen`, `aimValid`/`aimId`/
`aimScreenX`/`aimScreenY`/`aimYawErrDeg`/`aimPitchErrDeg`/`aimDistM`, `enemyCount`. **These are
all last-value gauges, not counters** — there is not one monotonic counter anywhere in the
renderer, which is precisely why ladder B is unanswerable today.

**`ui/aim/TouchWatcher.java`** (`:57-62`) — `started`, `supported`, `activePointers`,
`lastEventMs`, `device`, `error`. All gauges.

Nothing in `ui/button/`, `ui/overlay/`, `ui/panel/` or `ui/settings/` counts anything.

---

## 8. Existing status strings — keep, or counters in costume

| string | verdict |
|---|---|
| `ui/render/EspRenderView.java:1274-1322` `statusLine()` | **Keep as HUD text.** It is a calibration narrative (view mode, FOV, boom, lead, axis map) that a human reads while turning knobs; none of it is countable. Called at 2 Hz from `EspOverlay:198-209`. |
| `ui/render/EspRenderView.java:1801-1810` `calibHint()` | **Keep as HUD text.** `"scr +0.02,-0.01 ✓"` is a *measurement*, and the whole calibration procedure at `:1795-1799` depends on watching it move. Its three bail strings (`:1802`, `:1803`, `:1804`) should additionally set `RENDER_NO_STATE` / `RENDER_MARK_NO_TARGET` / `RENDER_BEHIND_CAMERA`. |
| `ui/render/EspRenderView.java:802-810` `viewportHint()` | **Half and half.** `VP 1080x2400 org 0,0` is text; `exact` vs `INSET-CORRECTED` is a **boolean gauge that belongs in the registry** (`RENDER_VIEWPORT_INSET`) — it is the difference between a calibrated projection and one that is compensating, and today it is buried mid-string. |
| `ui/aim/AimInjector.java:467-481` `debugLine()` | **A counter in a costume.** Every field is already numeric (`ok=`, `fail=`, `bail=`, `g=n/m`) and the only genuinely textual part — `lastBail` — is the nineteen-way string that ladder A replaces with nineteen counters. Keep the rendered line for the panel, but source it from the registry rather than from private statics. |
| `ui/aim/AimInjector.java:450-459` `status()` | **Keep as HUD text** — it is the human instruction ("start Shizuku", "grant permission"). Back it with `AIM_SHIZUKU_*`. |
| `ui/aim/TouchWatcher.java:85-91` `debugLine()` | **A counter in a costume.** `DOWN x2 dev=touchscreen` is `activePointers` plus a device name. `error` should become `TOUCH_*` counters; the device name stays as text. |
| `filter/MarkFilter.java:137-145` `status()` | **Dead.** It has **no caller anywhere in the app** — `MarkFilter` is reachable from `DefaultFilterEngine.mark()` (`:53-55`) but nothing calls `status()`, and `EspOverlay.buildDebugText` (`:219-313`) prints ghost, tele, freeze, aim, INJ, HP and VIS but not mark. So the mark filter is the only filter with counters no human ever sees. Fold the counters into the registry and add a `MARK` line to the debug panel. |
| `filter/AimFilter.java:287-310` `debugLine()` | **Counters in a costume** — 14 numeric fields plus the current config. Keep the line, source from the registry. |
| `filter/TeleportFilter.java:170-183` `debugLine()` | Mostly counters; `dbgState` (`anchor`/`ramp`/`off`) and `left=%.1fm` are genuine gauges worth keeping as text. |
| `filter/GhostFilter.java:90-99`, `filter/FreezeFilter.java:94-99` `debugLine()` | The `live=/ep=/shape=/EXACT` booleans are **last-decision gauges** and should become both a gauge and a counter (`GHOST_NOT_LIVE` etc., §3.4/§3.5) — a boolean sampled at 2 Hz cannot tell you that it was false for 400 packets. |
| `ui/panel/EspTunePanel.java:935-963` `info()` rows | The mechanism is right; the cadence is broken (§4, `refreshAll` only fires on expand). |

---

## 9. Invariants worth alarming on

Thresholds are stated with their source so they can be re-derived rather than re-guessed.

1. **The CS blackout signature.** `RENDER_ENTITY_STALE ≥ 0.9 × (engine live entity count)` while
   `enemyCount == 0` for **> 2 s**. Source: `STALE_MS = 1500` (`ui/render/EspRenderView.java:589`)
   against the 198 ms world tick and 230 ms stale bound (`docs/CS_MODE_ESP_FAILURE.md`); an
   entity refreshed every 198 ms can never be 1500 ms stale unless the stream stopped. *"The
   engine reports live entities and the renderer draws zero boxes"* is exactly the divergence
   named in the brief.

2. **The vehicle blackout returning.** `RENDER_OWN_STALE > 0` sustained for > 1 s while
   `esp.ownFromEcho()` is true. Source: the comment at `ui/render/EspRenderView.java:1011-1015` —
   the self-echo fallback advances when Cmd 2001 stops, so a stale own-state *with* a live echo
   means something is reading the wrong clock again. `OWN_STALE_MS = 2000` (`:592`).

3. **The controller ticking with nothing to do.** `AIM_TICK_COUNT > 0` while
   `RENDER_AIM_NO_TARGET` accounts for every frame, for > 5 s. The loop is supposed to park after
   `LOOP_IDLE_MS = 1500` (`ui/aim/AimInjector.java:579`), so a live tick with no target past
   ~1.5 s means `aimTo` is still being called with a stale `hasTarget` — the 125 Hz binder-ping
   regression the parking logic exists to prevent (`:589-592`).

4. **A filter that never sees its command.** `AimFilter.dbgSeen == 0` for a whole match while
   `active` is true **and** `FILTER_CMD_UNRESOLVED == 0` (i.e. the solver *did* converge). Cmd 106
   is emitted on every hit; zero across a match with the feature on means the engine gate at
   `filter/DefaultFilterEngine.java:81` never matched. Same shape for `MarkFilter.seen` after a
   confirmed mark tap, and for `FreezeFilter.dbgDropped == 0` with `FREEZE_NOT_MATCH_SERVER > 0`.

5. **Ghost armed and recognising nothing.** `GHOST_UNRECOGNISED > 500` with
   `dbgKeepalive == 0` over 60 s, or `GHOST_NOT_LIVE > 0` while `dbgActive`. Source:
   `filter/GhostFilter.java:126-140` — the shape test verifies 47 664/47 664 offline, so a live
   zero means the learned chain broke, not that the test is wrong.

6. **Replay sending nothing.** `TELE_REPLAY_NO_ANCHOR > 0` or `GHOST_REPLAY_NO_STATE > 0` for
   > 2 consecutive intervals. `REPLAY_INTERVAL_MS = 500` on both
   (`filter/TeleportFilter.java:127`, `filter/GhostFilter.java:54`), chosen to feed the server's
   liveness timers against a ~10 Hz natural rate — two missed intervals is 1 s of silence on the
   position channel while the filter believes it is holding.

7. **ACK-starvation guard.** `FreezeFilter` drop rate > 5 % of inbound, or any
   `GHOST_*`/`TELE_*` drop counter rising on a packet the exact-id path did not classify.
   Source: the measured dose-response in `filter/GhostFilter.java:170-177` — dropping 16/36/50 %
   of ACKs produced 21.8/37.5/46.0 % inbound retransmission with one OrderID resent 9 times
   (1 + `MAX_RESEND_COUNT`, the server's full budget). This is the mid-match disconnect
   mechanism; it deserves the loudest alarm in the set.

8. **The aim is armed but never injects.** `okCount` flat for > 3 s while `aimValid` is true and
   `AIM_INJECT` is on. Resolve through ladder A: exactly one of `AIM_SHIZUKU_*`,
   `AIM_NO_IINPUTMANAGER`, `AIM_YIELD_USER_TOUCH`, `AIM_IN_DEADZONE` or `AIM_TICK_THREW` must be
   the majority. If none is, the tick is not running at all (`AIM_NO_WORKER`).

9. **Yield stuck on.** `AIM_YIELD_USER_TOUCH` at ~125/s for > 10 s. Either the user really is
   holding the screen, or `TouchWatcher`'s slot count drifted and the dead sticky window
   (`ui/aim/TouchWatcher.java:72-73`, §A5 note) is not rescuing it. Pair with
   `TOUCH_STREAM_DIED`.

10. **A touch target below the floor.** Assert `sizePx >= 48dp` in
    `ui/button/OverlayButton.java:172-175`; `makeBtn` already enforces 52 dp at `:96-98`. Source:
    the comment at `:90-94` — the old 72 px floor is 24 dp on a 3× panel and 18 dp on a 4×.

11. **Settings that go nowhere.** `BCAST_SENT > BCAST_RECEIVED` over any 5 s window
    (`ui/settings/AppearanceBroadcaster.java:123` paired with the service-side receiver). Every
    divergence is one user action that silently did nothing.

12. **Mark left armed.** `MarkFilter.ENABLED == true` after `disableAll()` or `shutdown()` —
    `filter/DefaultFilterEngine.java:158-164` and `:184-190` shut down freeze, ghost, teleport and
    aim but not mark. This is the one filter that rewrites a packet *other players see*, and its
    own javadoc (`filter/MarkFilter.java:105-108`) says it should never turn itself on.

13. **Layout staleness across a rotation.** `AIM_RB_LAYOUT_STALE + MARK_LAYOUT_STALE > 0` is the
    only observable that a match/room transition rotated the key before the solver caught up.
    Expect a burst at every transition and zero in between; a sustained non-zero means the solver
    is not re-converging.

---

## 10. Bails that are correct and should stay silent

Listed so a later pass does not pad the registry with them.

- `filter/TeleportFilter.java:241-244` — `!isPositionReport` passes ~1000 pkt/s. A counter here
  is just a packet counter; the transport already has one.
- `filter/TeleportFilter.java:765-767` — `onTunnelRestart()` deliberately empty, with a javadoc
  explaining why nothing stale is held.
- `filter/GhostFilter.java:245-261` — the `else if` that refuses to overwrite a populated anchor
  slot. Silence *is* the correct behaviour; a counter would fire ~10/s for the whole engagement.
- `filter/FreezeFilter.java:140-142` — transport-layer passthrough. Worth a denominator, not an
  alarm.
- `filter/PacketClassifier.java:22-36` — legacy, dev-labelling only.
- `filter/replay/ReplayEngine.java:77-79` — `InterruptedException` swallowed with the abort check
  one line later doing the real work.
- `ui/aim/AimInjector.java:872-876` — `idleMove` throttle.
- `ui/aim/AimEditOverlay.java:101-107` — `removeSafely` during teardown.
- `ui/overlay/EspOverlay.java:336`, `:345`, `:350` — teardown `removeView` catches.
- `ui/button/OverlayButton.java:235`, `:324` — second-pointer rejection.
- `ui/button/AnimatedCircleDrawable.java:76` — pre-layout empty bounds.
- `ui/render/EspRenderView.java:762` — the 1 Hz `refreshViewport` rate limit.
- `ui/settings/UiBindings.java:201`, `:211`, `:230`, `:264` — defensive null guards on views that
  are legitimately optional.
- `ui/settings/AppPicker.java:64-68` — label lookup falling back to the package name.

---

## 11. Summary of proposed counters by module prefix

| prefix | count | where |
|---|---|---|
| `AIM_` | 31 | `ui/aim/AimInjector.java` (ladder A) |
| `TOUCH_` | 6 | `ui/aim/TouchWatcher.java` |
| `CAL_` | 2 | `ui/aim/AimCalibrator.java` |
| `RENDER_` | 34 | `ui/render/EspRenderView.java` (ladder B) |
| `AIM_` (filter) | 26 | `filter/AimFilter.java` — **name-clash with the injector**; suggest `AIMF_` for the filter or `INJ_` for the injector before either is written |
| `MARK_` | 12 | `filter/MarkFilter.java` |
| `TELE_` | 8 | `filter/TeleportFilter.java` |
| `GHOST_` | 4 | `filter/GhostFilter.java` |
| `FREEZE_` | 7 | `filter/FreezeFilter.java` |
| `FILTER_` | 2 | `filter/DefaultFilterEngine.java` |
| `OVERLAY_`/`PANEL_`/`CROSS_`/`DEVPOPUP_`/`EDIT_` | 17 | `ui/overlay/`, `ui/panel/`, `ui/aim/AimEditOverlay.java` |
| `BTN_`/`ANIM_`/`TOUCHLIS_` | 12 | `ui/button/` |
| `PERM_`/`PICK_`/`BCAST_`/`UI_`/`PREF_` | 13 | `ui/settings/` |

Of these, **11 are on a 120 Hz path** (ladder B), **9 on a 125 Hz path** (ladder A4), and
**~15 on the ~1000 pkt/s filter path**. Every one of those is marked `counter` — numeric only.
The `event` markings are all on once-per-session or user-initiated paths, where a logged line
with context is affordable and much more useful than a number.

**Name collision to settle first:** `filter/AimFilter.java` (the hit-zone rewrite) and
`ui/aim/AimInjector.java` (the touch injector) are two unrelated subsystems that both want the
`AIM_` prefix. They fail for entirely different reasons and a dump that mixes them is worse than
no dump.
