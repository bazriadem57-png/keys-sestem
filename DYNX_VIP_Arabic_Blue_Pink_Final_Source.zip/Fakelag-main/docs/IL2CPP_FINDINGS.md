# IL2CPP binary analysis — state of knowledge

> **PATHS IN THIS DOC PREDATE THE 2026-09-15 PACKAGE REORG.**
> `core/` is now `tunnel/`, `net/` split into `decode/{frame,crypt,body}` +
> `protocol/`, `overlay/` split into `ui/{render,overlay,panel,button,aim}`.
> See `docs/SOURCE_MAP.md` §2 for the full old-to-new table.

**READ THIS FIRST before any static analysis work on `libil2cpp`.** It records the
tooling (including two traps that each cost hours), what is settled, what conflicts
with our wire measurements, and what is still open.

Last updated 2026-09-12.

---

## 0. Tooling — the two traps

### TRAP 1: the shipped binary has ENCRYPTED METHOD BODIES

`C:\Users\Tonyt\Documents\libil2cpp.so` — the image bound to the IDA session — has
**selectively encrypted method bodies**: ciphertext head, plaintext tail, per
method. This is worse than an obvious failure, because a function can decompile
into something *plausible* while its prologue is garbage. IDA also silently
refuses to create functions at some of those addresses.

Measured cost: scanning for `GameFacade::Send` call sites finds **461 in the
decrypted image versus 365 in the encrypted one** — ~21% of the entire outbound
surface was invisible, including `PlayerNetwork::StartFiring`, the main fire
sender. `message.GMDJLCGLDCH::UnSerialize` disassembles to **zero instructions**
from the encrypted image and to a clean 180-byte body from the decrypted one.

> **An empty or garbage body is the tell.**

**USE `C:\Users\Tonyt\Documents\FF-RE\bin\libil2cpp_dec.so`.** Byte-identical
layout, same RVAs, same segments, all bodies plaintext. Reading it directly with
capstone from Python, resolving symbols via `rva_map.txt`, is faster and more
reliable than going through the IDA session at all.

### TRAP 2: `dump.cs` is a DIFFERENT BUILD

`C:\Users\Tonyt\Videos\ZRT-Toolbox\Dump\` holds a full Il2CppDumper output, but of
a **different build**. Verified: `COW.GamePlay.AttackableBaseLevelObject::TakeDamage`
is `0x0703c2cc` in our `rva_map.txt` but `0x6F6FF00` in `dump.cs`.

- **Use it for STRUCTURE** — class hierarchies, field offsets and types, method
  signatures, parameter names, enum members. Structure is build-stable.
- **Never feed a `dump.cs` RVA to IDA or to our own image.**
- Bridge the two **by name**. Obfuscated names are stable across both builds
  (verified: `message.KLINFKFBIKB` has exactly 1877 members in each).

That folder also contains **two different games** — `com.dts.freefireth` and
`com.garena.game.kgvn`. `dump.cs` describes freefireth (its VAs fall in that
module's range). It also ships `com.dts.freefireth-...bin`, a **runtime memory
dump**, whose method bodies are plaintext by construction — a third, independent
source that was never affected by Trap 1.

### The name → address map

| file | contents |
|---|---|
| `FF-RE\bin\rva_map.txt` | 322,920 lines, `0xRVA<TAB>Type::Method`. **The RVA IS the address in our image.** |
| `FF-RE\bin\dump_names.txt` | 864,070 lines: `TYPE`, `F` (fields), `M` (methods + token + midx) |
| `ZRT-Toolbox\Dump\stringliteral.json` | all string literals — **use instead of IDA's `find_regex`, which times out at 60 s on this binary** |
| `ZRT-Toolbox\Dump\il2cpp.h` | C structs for every type |

### THE BINARY SHIPS A REVERSE NAME TABLE — check it first

Beebyte renamed identifiers but **not string literals**. `message.FMOGMHIHJMO` and
~1121 similar classes are static classes of
`public const string <Obfuscated> = "<Original>";` — a **partial de-obfuscation map
shipped inside the binary**. Extracted to
**`tools/il2cpp/ff_deobfuscation_map.json`, 1122 entries.** Confirmed:
`EHNFCMJMPMJ -> HitBodyPart`, `FDAEPHMIEPC -> Weapon`, `GAKJDFEMCND -> BuffType`.
It is partial (`LNOIFBAFGOK`, `LJIIDMHPFEH`, `GMNGCBJMDLB` are absent) but it is one
lookup and can save hours. **Unexploited: a systematic pass over the outbound class
list and the 1384-row registry would name a large slice of the protocol for free.**

### Obfuscation pattern

Beebyte-style. **Type names AND `message.*` field names are obfuscated.** What
survived: **enum member names**, `COW.GamePlay` method and **parameter** names, and
Unity type names. (An earlier belief that `message.*` member names were intact was
wrong.)

The practical technique: because the obfuscation map is global and consistent, an
obfuscated member name can be identified by finding any class where it carries a
readable type or is passed to a named parameter.

### Committed artifacts — do not re-derive

| `tools/il2cpp/` | contents |
|---|---|
| `ff_inbound_registry.tsv` | **1384 ids → inbound class + handler method** |
| `ff_outbound_registry.txt` | 454 rows, msgid → message class → send site |
| `ff_outbound_classes.json` | field layouts for all 288 outbound classes |
| `il2cpp_scan.py` | the capstone harness |

---

## 1. The headline finding: hits are CLIENT-AUTHORITATIVE

This overturned the project's central assumption.

The client raycasts, resolves which player owns the collider it struck, decides the
body part, and sends the finished claim. `FDAEPHMIEPC::KOODEKEKFEK` @ `0x074df4fc`
does it all locally — `HitDetectColliderHelper::GetOwner`,
`GameFacade::get_IsFriendDamage`, `Player::IsInNoHeadShotState` (@`0x074e0210`),
`HitDetectColliderHelper::IsProtection` (@`0x074e0250`), then:

```asm
074dfea8  ldr  w8, [x22, #0x20]   ; HitDetectColliderHelper.ColliderType
074dfeb0  str  w8, [x23, #0x14]   ; damageInfo.DNFNNJMHNEK = the HIT ZONE
```

> **CORRECTION.** An earlier pass reported the zone as `LNOIFBAFGOK` (`short` @0x70),
> OR-accumulated via `KFEOBAJJFEF`. **That is wrong.** Those three helpers are one
> instruction each — `KFEOBAJJFEF` = `orr` (a|b), `CCAIEDHAMOL` = `and`+`tst`
> ((a&b)!=0), `FOKPBJBDCOK` = `bic` (a&~b) — so `LNOIFBAFGOK` is a **damage-flags
> bitmask**, paired with a `LazyDictionary<short,...>` keyed by the same bits.
> The hit zone is `DNFNNJMHNEK` at **+0x14**, a plain field copy from the collider.

The claim is **`message.MMJPICCOJOM` (Cmd 106 outbound)**, built inside `TakeDamage`
overrides (31 construction sites, all of them `TakeDamage`), carrying victim,
attacker, weapon, tick, **hit point**, **hit direction**, checkParams, the
**hit zone** (see §4.1 — it is sent TWICE), the damage-flags bitmask
(`short LNOIFBAFGOK` @0x60), ping, and two anti-cheat blobs
(`ffantihack.MFHPGMELLCC::DHMENGFJMII`,
`GCommon.Checker.GFHPFJMGEKF::AKFFMELHGIJ(0xA, 7, damage)` → field 0x68).

No outbound class anywhere contains a `Vector3` — vectors are always the packed
int3 `PMFGOGFPDHM`.

Same message reused per victim type: 106=Player, 127=Vehicle, 166=LevelUAV,
222=IceWall, 240=Landmine, 865=SantinoDummy, 394=generic level object.

### This explains the 30° aim-bias null result

The aim vector in outbound 2001 is **reported pose, consumed only for rendering our
avatar on other clients**. Our own client never reads it back — the bullet ray comes
from the camera/weapon transform plus a *client-side* aim assist
(`Player::get_EAimAssit` @`0x074e55ac`, `Player::GetAuxAimRotation` @`0x074e5a24`).
The server does not need it because the client hands over the finished answer.

So rotating it 30° changed what our character *looked* like it was aiming at and
nothing else. The experiment was sound; the old conclusion ("the server resolves the
body part itself") was wrong. **The client resolves it.**

---

## 2. The dispatch mechanism

**No static table.** `GCommon.NetworkMessageDispatcher` holds
`Dictionary<uint, NetworkMessageHandlerPair> m_Handlers` (field +0x20), built at
runtime by `NetworkClient.RegisterHandler<T>(uint cmd, handler)`. `T` is always a
reference type, so IL2CPP emits **one shared implementation** — all 1384
registrations pass through it. Recover the table by scanning `BL` sites to it,
walking back ≤40 instructions for `MOVZ w1,#cmd` and the `ADRP/LDR` type slot, then
resolving through `script.json`.

Inbound decode: `UDPClientMessageBase.UnSerializeMessage(reader, type)` → construct →
virtual `UnSerialize`. **Vtable slots: Serialize=6, UnSerialize=7, CanCache=8,
Recycle=9.**

Every handler for our ids is a method on one god-class `COW.GamePlay.FFMOIGKIEPE`.

### Messages are BIDIRECTIONAL with different classes per direction

| cmd | inbound class | outbound class |
|---|---|---|
| 104 | `DGDJJJEENII` (2 fields) | `PHLCCJAAHIH` (8 fields) |
| 105 | `PGPOKCIGELG` (3 fields) | — |
| 106 | `GMDJLCGLDCH` (8 fields) | `MMJPICCOJOM` (22 fields) |
| 2001 | `KGHDCJFHGNP` | **UNIDENTIFIED — see §5** |

**Any single-layout decoder is wrong in one direction.** This resolves the
long-standing "106 is inbound-only in captures but has an outbound sender in code"
contradiction, and explains our own "OUT is 8 varints, IN is 3" observation.

### `GameFacade::Send` @ `0x075488ac` is STATIC

`w0 = messageID, x1 = msg, w2 = sendOption, w3 = cacheMsgAnyWay`.

`w3` is **not** a channel selector. **`w2` is the reliability selector**: 2001 sends
`w2=0` (NONE/unreliable), 104 and 106 send `w2=2` (RELIABLE). Matches the
reliable/unreliable split we measured on the wire.

---

## 3. Encoding — confirmed, with two additions

| method | behaviour |
|---|---|
| `ReadUInt32/16/64` | plain LEB128 varint |
| `ReadInt32/16/64` | varint then zigzag |
| `ReadSingle` | one varint whose bits ARE the float32 (`fmov s0,w0`) |
| `ReadByte` | **1 RAW byte** |
| **`ReadBoolean`** | **1 RAW byte** (new) |
| `ReadFixUInt16` | **2 RAW little-endian bytes** |
| strings | `[zigzag varint length][UTF-8]` |
| **`List<T>` count** | **zigzag varint short** (new) |

**Desync traps, in order of damage:**
1. `bool` and `byte` are raw 1 byte but **`ushort` IS a varint** — in the 2001/2012
   record a `ushort` sits mid-run of raw bytes. Treat it as a byte and everything
   after desyncs for any value ≥ 128.
2. The leading per-record entity id in 2001/2012 is a **RAW BYTE**, not a varint.

### Quantisation — position is MILLIMETRES

`message.KANJBNIANHC` is the net-vector helper and **its parameter names survived**:
`ABCDGNELDNN(int DJOGCAJNMNC, int IKOAGHHEHNL, int HDAKKOIKINN)` proves component
order is **X, Y, Z** with Y = height.

| net type | shape | scale |
|---|---|---|
| `PMFGOGFPDHM` | 3 × int zigzag | **/1000** (millimetres) |
| `BDOPLCJODBN` | 3 × short zigzag | /100 |
| `FOENPKFAEOC` | 2 × short zigzag | /100, **Y forced to 0** (ground-plane X,Z) |
| scalar short | 1 × short | /100 |

`IMODKMCKNED(int,int,int) -> Quaternion` confirms `BDOPLCJODBN` used as a rotation
is an **Euler triple**, not a quaternion.

> **Open:** we use `UNITS_PER_METRE = 950`, derived from a measured −9313 u/s²
> gravity and assuming g = 9.81. If the scale is really 1000, game gravity is
> 9.313 m/s² and **our distances are ~5% too large**. 950 sits inside our own stated
> ±60 error bar. Not yet changed.

---

## 4. Hit zone — CONFIRMED, and our statistical guess was right

The enum is `LLEDPGIGCMO`, named `ColliderType` elsewhere in the game:

```
None=0  Head=1  Body=2  Limb=3  Vehicle=4  Protection=5  UAV=6  Shoal=7
OilDrum=8  IceWall=9  Landmine=10  MiniSentry=11  Shield=12 ...
Glass=71  Fragment=72  WukongIllusion=73
```

**Head=1, Body=2, Limb=3 — exactly what we derived from damage grouping.**
There are TWO enums with identical values where they overlap: the wire enum
`message.FMGIHBIIMHL` (`EHITBODYPART_*`) and the client enum
`COW.GamePlay.LLEDPGIGCMO`, a strict superset. Values are **not densely
sequential** (22→33→39→46).

> **TRAP: `PlayerColliderChecker` and its `HitPart` enum (`Head=0, Neck=1, Chest=2,
> Hips=3 …`) are DEAD CODE — 0 callers.** Do not map wire data onto it. It is a
> plausible-looking decoy that would shift every zone by one.

Confirmed slots: `106.v7` (byte) and `168.v3` — both the slots we already had.

### 4.1 The zone is sent TWICE, and there is a downgrade gate

**How a collider becomes a zone:** not bone names, not a lookup table — a per-collider
MonoBehaviour with an author-time field.
`HitDetectColliderHelper.ColliderType` (`LLEDPGIGCMO` @0x20), copied straight into
`damageInfo+0x14`.

**Headshot eligibility gate** (`0x074e01e8`-`0x074e0244`): if zone == Head(1) and
`Player::IsInNoHeadShotState`, the zone is **rewritten to Body(2) before damage is
computed** and `damageInfo+0x72` is set as a downgrade marker.

**Armour-plate gate**: `HitDetectColliderHelper::IsProtection` @`0x07b89e40` is
literally `return ColliderType == 5`. When true the hit is routed to
`damageInfo+0x74` instead of `+0x10`.

**On the wire the client sends the zone twice** — `PlayerNetwork::TakeDamage`
@`0x0736f0e4`:
```asm
0736f4fc  ldr  w8, [x20, #0x14]      ; damageInfo zone
0736f504  orr  w27, w27, w8, lsl #24 ; damage | (zone << 24)
0736f518  str  w27, [x21, #0x1c]     ; GMNGCBJMDLB
0736f51c  strb w8,  [x21, #0x2c]     ; EHNFCMJMPMJ
```
**Almost certainly a server-side tamper cross-check: the two must agree.**

Corroborating that the server validates geometry, the anti-cheat enum
`COW.GamePlay.AKHFIKBPKFM` contains `Cheating_HipsBoneNotRight = -154`,
`Cheating_HackerIceWallName = -155`, `Cheating_SniperColliderName = -156`.

### 4.2 Damage formula and armour

Pipeline: `KOODEKEKFEK` @`0x074df4fc` → `LKHKGOFALIB` @`0x074e208c` →
`IOHEFKPFCML` @`0x078e44e0` (thin wrapper) → **`LEFKMLFNPIE` @`0x078e467c`, the real
0x12F0-byte formula** → `OFKCCJIDAGD`/`JBJDLGPLAPB` for the zone multiplier.

**The zone multipliers are NOT hardcoded floats** — they are five `float` statics on
a game-wide config singleton at `static_fields + 0x308/0x30C/0x310/0x314/0x318`
(head / body / limb / vehicle / sniper-extension), dispatched by a jump table on
`hitPart-1`. **They could not be recovered statically** (the values live on the
IL2CPP heap). Our empirical 2.6-4.2x head:body ratio remains the only source and is
not contradicted by anything in the code. **One ReClass read of those five
consecutive floats on a live process would settle it exactly.**

**Armour**: `AMLCCGLPKKK` @`0x078e621c` picks equipment **slot 6 = helmet** for zone
mask `{1,16,46,47,50}` (head + shooting-target-head + dragon heads — exactly the same
set as the multiplier table, an independent cross-validation) and **slot 8 = vest**
otherwise. Reduction scales with remaining durability and the attacker's penetration
attribute:
```
D    = (flags & 1) ? maxDurability : currentDurability   ; bit0 of IHINCLBOJEC (NOT LNOIFBAFGOK)
red  = clamp01(baseRate + (1 - penetration))             ; penetration = GetDamageCalcValue(attacker, 6)
damage *= (1 - coverage * red)
```
**No distance-falloff term exists anywhere in the client damage path** — no distance
argument, no curve evaluation. If falloff exists it is upstream in weapon-damage
selection, or server-side. Unverified.

`EPRI_PLAYER_ARMOR_REDUCEDAMAGE_INCREMENT` (83) is **not used in the damage path** —
the math reads `PlayerAttributes::GetDamageCalcValue(id)` instead. Hypothesis
(SPECULATIVE): EPRI 83 is a replicated *mirror* of the computed reduction, an output
not an input.

---

## 5. STILL OPEN

Ranked by value to the project.

### 5.1 Outbound 2001 — SOLVED 2026-09-12

Class **`message.DAIDIMLOEPL`** wrapping **`message.ACDHGKMPIDJ`**. `Serialize`
@ `0x047cb4c4` / `0x049d4900`. Sole sender proven: of 461 `GameFacade::Send` sites,
**exactly one passes 2001** — `0x078CF1D4`.

| idx | meaning | encoding |
|---|---|---|
| h | PlayerID | LEB128 |
| v0-v2 | **position X, UP, Z — millimetres** | zigzag int |
| v3-v5 | **aim direction #1** = `GetAimRotation()*forward` x100 | zigzag short |
| v6-v7 | ground move direction X,Z x100 | zigzag short |
| v8-v10 | **VELOCITY, cm/s** | zigzag short |
| v11 | `EPHYSXSTATE_*` (WALKING 0 … PASSIVEMOVING 21) | **RAW byte** |
| v12 | `EPHYSXPOSE_*` (STANDING 0, CROUCHING 1, DASHING 2, CREEPING 3 …) | **RAW byte** |
| v13-v15 | **aim direction #2** = `GetAuxAimRotation()*forward`, **3 raw float32** | varint of f32 bits |
| v16 | moving-platform id | LEB128 ushort |
| v17 | low-gravity area | **RAW byte** |
| v18 | ping ms | LEB128 ushort |
| v19 | UGC only | **RAW byte** |
| v20 | bezier-slide path pos \| slideId<<24 | LEB128 uint |
| v21 | snowslide side / lobby voice | **RAW byte** |
| v22 | client ms clock | LEB128 uint |

**THREE BUGS IN SHIPPED CODE:**

1. **`UNITS_PER_METRE = 950` is wrong — it is exactly 1000.**
   `KANJBNIANHC::COGCJKJPPHI` @`0x0577e298` multiplies by literal `1000.0f`. Our
   distances are **5.3% too large**; game gravity is really **-9.313 m/s²**, which
   is where 950 came from.
2. **Outbound 2001 is NEVER SENT while mounted.** `EAIKJCCNGMJ` dispatches on
   `IsInVehicle()` first: driver → **Cmd 2002**, passenger → **Cmd 2006**, another
   case → **Cmd 2031**, `IsOnChair()` → another class. **Ghost and teleport key on
   2001 alone and go blind the moment the player mounts anything.**
3. **Position is PLATFORM-RELATIVE when v16 != 0** — v0-v2 becomes
   `get_OffsetPositionToMovePlatform()`, a small offset, not a world position.

**Refinements to our wire readings:**
- v8-v10 is velocity, but our "next-tick displacement" number was right for a
  reason: `field/displacement = 0.1/dt`, and our measured p50 **1.010 ⇒ dt = 99.0 ms**
  independently matches v22's +99/packet.
- **v20 is NOT a mount handle** — there is no mount field at all.
- **v18 caveat:** before `m_StartShowTime` the game sends `Random.Range(0,100)`.
  Early-match RTT samples are garbage by design.
- Send is throttled `(counter % 3) == 0` off a ~30 Hz driver ⇒ the 99 ms tick.
- **Outbound 2001 carries no anti-cheat blob.** Nothing in it is signed.
- **v21 can exceed 127 in lobby** and is a RAW byte — a varint decoder desyncs.

**THE FLOAT32 TENSION — RESOLVED.** Inbound and outbound declare the *same member
name* with *different types*: inbound `ALCBKBHIOAJ+0x40` is `BDOPLCJODBN` (3 shorts),
outbound `ACDHGKMPIDJ+0x40` is `DECDPFHCEDH` (**3 raw float32**, no quantisation).
Both our measurements were correct simultaneously.

**AND A CONFOUND IN THE AIM-BIAS EXPERIMENT.** There are **two** aim vectors here.
`AimBias` searched for a unit-length *float32* triple, so it found v13-v15 and
**left v3-v5 carrying the true pose**. The 30° null result does not cleanly prove
what we claimed. The client-authoritative conclusion stands on its own evidence
(§1), but this experiment no longer supports it.

**Testable lead on the teleport distance gate:** velocity is sent independently of
position, so `displacement = velocity x 0.099 s` is a trivial server-side check.
Our teleport already rewrites both, which may be why it works at all.

### 5.2 Conflicts between the binary and our wire measurements — UNRESOLVED

Do not overwrite either side; settle empirically.

**RESOLVED 2026-09-12 in our favour.** The conflicting readings came from
`dump.cs`, a *different build*. A later pass re-derived every layout from **our own
image's `UnSerialize` methods** and confirmed our wire measurements exactly:

- **2010**: `v2` = weapon (zigzag, passed as `HPPACPHIPCP` to `Player::PlayHurt`),
  `v3` = tick, `v5` = damage to HP. Our 628-vs-4 correlation stands.
- **106**: `v0` attacker, `v1` victim, `v2` damage, `v4` weapon (zigzag),
  `v7` = **hit zone, CONFIRMED** with sender-side proof.
- **168**: our layout was right except the filler run is **eight** values (v5..v12),
  not seven.

**Lesson: prefer re-deriving from our own image over any `dump.cs` field order.**

### 5.3 Field identifications — ALL SOLVED 2026-09-12

**`LNOIFBAFGOK` = `message.EGFPOJKDIBI` = `ESpecialHitType`, a bitmask** (Cmd 106
v6, zigzag short). Named from `UIHudHurtHintController::IsPenetrateHit(short
specialHitType)` @`0x04ffa0d8`, which computes `(x & 1) || (x & 0x10)` — exactly
`Penetrate=1` and `PenetrateIceWall=16`. All 27 call sites use enum members and
nothing else:
```
None=0  Penetrate=1  HayatoDecrease=2  (bit 2 unused)  DWShield=8
PenetrateIceWall=16  WeaponShield=32  ContinueFire=64  DamageBlock=128
IceWallPenetrated=256  NinjaGirlProjectile=512  AutoFlightBomb=1024
```
Its paired `LazyDictionary<short, LAGLGLHKHJJ>` is a **shield registry** keyed by
the same bits; `LAGLGLHKHJJ` is an interface whose method names survived —
`GetShieldOwnerID()`, `GetReduceDamageRate()`.

> **Do not confuse it with `GLLLEDKLLDA.IHINCLBOJEC`** (`None=0,
> UseEquipmentMaxDurability=1, IsTrainingHitInfoTarget=2`), the *other* short flag
> word travelling the same call chain — that is the one in §4.2's armour formula.

**The damage-attribute enum is `COW.GamePlay.KOBBCCENPBG`** (21 members), *not*
the 107-member wire enum `EDamageCalcType`. Both our prior confirmations land on
semantically correct names:
```
WeaponDmgRatio=1 WeaponDmgValue=2 HitBodyRatio=3 HitHeadRatio=4 HitLimbRatio=5
BitArmorRatio=6      <- the "armour penetration" of §4.2
DmgIncreaseRatio=7 DamageFixScale=8 DmgIncreaseValue=9 DmgDecreaseValue=10
SPIncreaceRatio=11 [sic] SPHitBodyRatio=12 SPHitHeadRatio=13 SPHitLimbRatio=14
BeDamageFixScale=15 BeDmgIncreaseRatio=16 ArmorDamageIncRatio=17
ArmorDamageDecRatio=18  ArmorReduceIncRatio=19   <- the "coverage term" of §4.2
```
**Accumulation mode matters:** `DamageFixScale` is the *only* multiplicative slot,
and penetration, both shield reductions, the UGC headshot decrease, graffiti
monitor and AI injured scale all multiply into it. Everything else sums.

**Cmd 106 inbound, fully named** (`message.GMDJLCGLDCH::UnSerialize` @`0x049dc7d8`):
```
v0 u32 attacker | v1 u32 victim | v2 u16 DAMAGE (HP)
v3 u16 SHIELD DAMAGE (SP)       | v4 i32-zz weaponDataID (NEGATIVE = environmental)
v5 i32-zz BUFF ID (>0 => this tick came from a damage-over-time buff)
v6 i16-zz ESpecialHitType       | v7 byte HitBodyPart
```
`v3` traced four hops into `HandleAccumulatedDamageBase(int damage,
LLEDPGIGCMO colliderT, int shieldDamage, int weaponID, ...)`. `v5 > 0` sets
`hasDotBuff` and suppresses the impact VFX/vibration — right for a DoT tick.
**Negative weapon ids are environmental: `-10` = burning, `-45`/`-46` two others.**

> Caveat kept honest: `v3`'s identity is **CONFIRMED for Cmd 168 v12** but only
> **PLAUSIBLE for Cmd 106 v3** — the client decodes the 106 field and never reads
> it, so there is no code-level proof, only the shared obfuscated name and the
> HP/SP pairing precedent. Outbound 106's equivalent is **never written at all**.

### 5.3.1 The Cmd 107 dispute — SETTLED, it was a handler mix-up

The reported contradiction (`EHNFCMJMPMJ` passed as `KnockedDownCount`) came from
reading a **Cmd 139** call site against the **Cmd 107** class. `OnKnockOtherDown`
@`0x06243a94` has four callers and **none is in `NNOJJMHNKPL`** (Cmd 107's
handler); the real caller is `MGDEJKBECAJ` @`0x07a32d04`, Cmd 139
`RUDP_KNOCK_DOWN`. The two classes share an identical four-field prefix and then
diverge — 107 has `EHNFCMJMPMJ` at +0x2C, 139 has `EBDDCMPLNLH` there.

**`EHNFCMJMPMJ` is `HitBodyPart` in all seven of its declarations** — now
independently confirmed by the binary's own name table. Cmd 107 carries the body
part and the client simply never reads it. **Our hit-zone conclusion stands.**

### 5.3.2 Superseded

- ~~`MNLCCJOLFGL` / 2010.v4~~ — **SOLVED: damage absorbed by SP (shield/armour
  points).** Handler `0x07a64988`: `ldrh w8,[x19,#0x24]`, `cbz` skips the whole
  block when zero, then `Player::PlayHitSPEffect` @`0x712c0c0`. `v5` gates the HP
  path instead. Corroborated by `Player::get_CurTempSP`/`get_CurPermSP` inside the
  damage formula. Both v4 and v5 are **plain u16 varints, not zigzag**.
- **`LJIIDMHPFEH`** — 106 item 4, a `ushort`. The same member name appears in 168
  at item 13, feeding argument 11 of the damage-number call next to the icon
  string. **PLAUSIBLE: a damage-type / display-style id.** Unconfirmed. Also
  unverified whether the two occurrences are genuinely the same quantity.
- **`EHNFCMJMPMJ`, `LNOIFBAFGOK`** in the inbound classes — no readable-typed
  occurrence anywhere in the dump.

### 5.4 Cmd 135 visibility — SOLVED 2026-09-12

**SET bit = that player IS VISIBLE to you.** Confirmed three independent ways; the
value is never inverted anywhere. **Our capture-side hunch that the sense "appears
inverted" is contradicted by the code** — see the re-check below.

**Bit `i` = the player whose entity id is `i`.** No `+1`, no roster indirection.
`BHGGAEEHJCO::LMCLIKOCCJM(uint)` @`0x07C49CA4` packs one uint into five views and
**precomputes `1ULL << id` into a dedicated field at +0x10** — you do not write that
unless the mask is first-class protocol. ARM64 shifts are mod 64, so
`1ULL << id` and `1ULL << (id & 0xFFFFFF)` are identical: **bit = id mod 64**.

The chain, closed end to end: handler `JKBHKCGHFFE` @`0x07A31CAC` tail-calls
`IDKKMAHGGAF` @`0x07A297DC`, which does an IL2CPP interface-offset walk to
**slot 24 of `JKADJKOFGEM`** = `PlayerNetwork::SyncPlayersVisibility(ulong)`
@`0x073678F4`. The cleanest statement is the vehicle path (Cmd 136),
`EMKJHAJNPDH::PENEMOOGFDF` @`0x0727BE54`:
```asm
0727bfac  lsr  x8, x19, x23      ; mask >> id
0727bfb0  and  w2, w8, #1        ; bit
0727bfc0  bl   LevelVehicle::SetVisibility(4, bit)
```
And the player path ORs in `IsLocalPlayer` — **you are always visible to yourself**,
expressed by forcing the value to 1, which settles the polarity on its own.

**THE CONSUMER IS LOCAL PRESENTATION ONLY.** `Player::SetVisible(uint flag, bool)`
@`0x070923F0` (vtable slot 146) writes a `GCommon.BitArray` at `Player+0xA58` —
visibility is a multi-source mask of *reasons*, and **flag 4 is the network/PVS
slot**. Its entire 5.8 KB body is renderer toggling, shader keywords, avatar/FPP
model, plus `EnableCharactorController`, `Register/UnRegisterDynamicPVS` (a baked
client-side occlusion system) and a 3P asset preload. **Zero networking: no
`GameFacade::Send`, no message construction, nothing outbound.**

**The inbound position stream is NOT gated by the mask** — verified. The 2012 and
2001 handlers route to `EMKJHAJNPDH::JIHHGKLIMDO` / `CNHJFPDCJKO`, and there is
**no `IsVisible`, no `HasFlag`, no read of `Player+0xA58` anywhere on that path**.
A position for a cleared-bit entity is still applied to the `Player` object; it is
merely not rendered.

Also ruled out: `Player::CheckVisibleByDis` @`0x071260D4` is an axis-aligned box
test against a config singleton, but it has **exactly one caller in the whole
binary** (`StopPendingRevive`). **It is not interest management.**

**Siblings:** 136 and 386 are byte-identical single-u64 masks with the same
semantics and even the same field name at the same offset. **369
`RUDP_AI_Culling_Batch` is NOT a mask** — it carries `List<uint>` of entity ids,
so the AI/bot id space is not capped at 64. It is the one message that proves
explicit per-id culling exists in this protocol.

**No client-sendable interest lever — now verified by reading code, not name
matching.** Ids 135/136/386/369 have **no outbound send site at all** among the 461
catalogued. The only adjacent client messages are Cmd 144
`RUDP_FORCE_SYNC_PLAYER_STATE`, whose class **has ZERO fields** (a bare
"resend my state" ping that cannot express an interest change), Cmd 146 (an ack),
and the spectator-only target switches 235/1155.

### 5.4.1 What this gives us, and the one experiment that decides it

**Cmd 135 is a direct read-out of the server's relevance set** — once per update, as
a 64-bit bitmap indexed by entity id. `popcount(mask)` IS the number of players the
server currently considers relevant to us; the cleared bits name exactly who it has
decided we should not see. No inference needed.

What the client cannot answer: whether "not relevant for rendering" also means
"not streamed". That is server policy.

**The experiment**, and it is cheap because we already log everything:
1. **Check bit alignment first.** Correlate `bit i` against "id i appeared in the
   position stream in the next 200 ms", over lag offsets -2..+2. Offset 0 must
   dominate. If the "inverted" finding reappears at offset 0, that is a real
   contradiction with the code and worth reporting. If it vanishes once aligned, it
   was a misalignment — most likely indexing against roster position instead of
   entity id, or not masking the composite id's high-byte type tag.
2. **The actual question.** Partition 2001/2012 arrivals by whether the sender's bit
   was set in the most recent 135. Never arriving for cleared bits => the server
   really does gate the stream. Still arriving at the usual 198 ms tick => 135 is
   only a rendering directive, the ESP was never range-limited by it, and the range
   limit we are chasing lives elsewhere.
3. **Free bonus:** `max(popcount)` over a session gives the server's relevance-set
   size, and `max(i : bit i ever set)` settles `0..63` vs `1..64`.

> **Edge case to watch:** `1ULL << 64 == 1ULL << 0`. Our measured maximum entity id
> is 64, which would alias onto bit 0.

### 5.5 Does the shooter's client call `TakeDamage` on a remote HUMAN victim?

Proven: the code *can* claim hits. Not proven: that it does so for PvP in a real
match. The dispatch is virtual and was not resolved.

> **Warning recorded from a failed attempt:** vtable byte offsets are NOT comparable
> across classes here. Using offset `0xC88` from `Player::TakeDamage` produced a
> false match (`FDAEPHMIEPC::AMBIBKLKGNB` @`0x074d44b8`, a zero-arg weapon virtual at
> the same offset). That approach was correctly discarded.

**Cheapest way to settle it: look for Cmd 3532 outbound.** `message.OINOHHNMFKJ`,
4 uints `{shooter, victim, int, tick}`, sent from the same hit path at `0x074e14dc`,
gated on `IsLocalPlayer`. Its presence in a capture proves the client-hit path runs
in our build and mode.

### 5.6 Lower priority

- `107`'s tail: the "second name" is a **repeated record behind a zigzag count** —
  `List<KBNEBFFLGDA>` of `[string][i32][i32][u32]`, almost certainly an assist list.
  Field 44 of the class is not fully enumerated.
- `GMNGCBJMDLB` is a **packed composite**: low 24 bits = id, high 8 bits = a weapon
  sub-field (`orr w27,w27,w8,lsl #24`). We were treating it as a flat weapon id.
- The other ~1374 ids: the registry TSV has class + handler for each; per-class
  layouts are one `dump.cs` lookup away using declared-field-order = wire-order,
  which was verified on 11 independent classes across two builds.
- The damage formula (zone multipliers, armour reduction) — a third agent is
  working on this as of 2026-09-12 08:25; check before duplicating.

---

## 6. Corrections to older docs

- `PROTOCOL_MASTER.md`: "the per-shot fire message is inside the encrypted input
  stream" is **wrong**. It is Cmd 104 in the plain varint stream. The encrypted
  24 B stream decrypts with the session key and carries ~2 bytes, a counter.
- `PlayerNetwork::SyncStartFire` is **not** an RPC. `Sync*` means "apply inbound
  state", not "send". The sender is `StartFiring` @ `0x0737025c`.
- Cmd 104 outbound really is 8 fields with no geometry — confirmed field-by-field
  against serializer `0x049da3c8`. `FastBinaryWriter::Write(float)` does
  `fmov w1,s8` then falls into the varint writer, so **a float is its IEEE bits in
  LEB128 and `0.0f` costs one byte** — which is why the fists case is 11 bytes.
- `NMCBIHOOFFF` fire states: `NONE=0 READY=1 FIRE=2 CHARGE=3 CANCEL=4 WARMUP=5
  COMBINED_DOUBLE_FIRE=6 COMBINED_LEFT_FIRE=7 WEAPON_ABILITY_START=8 _END=9`.

---

## 7. The Clash Squad shop (Cmd 411-414, 607/608, 931, 957, 1205, 1474/1475, 1492, 1577/1578)

### 7.1 "CS" means CLASH SQUAD, not cash shop

Settled three independent ways:

1. The Cmd 413 sender calls `COW.GameFacade::IsCSMode` on the next instruction
   (`0x07398b8c`).
2. Enum member names survive obfuscation (§0), and they read:
   `message.OHEMKKOKJKL` = `ECSItemBuyType_{None,Normal,DoubleClick}`;
   `message.EGOPGIEPMJK` = `ECSShopItemFilter_{Weapon,Armor,Attachment,Prop,
   MystoryBox,Buff,TechPoint,BattleStyle,BooyahBounty,KingSword,Ghost,
   CSAbilityPont,ReplacePool,...}` — in-match gear categories.
3. Sibling ids in the same block are all Clash Squad: `RUDP_SYNC_CSGAMEZONE_INFO`
   (411), `RUDP_CS_NOTIFY_TOKEN_NUM` (957), `RUDP_SYNC_CSABILITYPOINT_*`
   (1563/1564/1567/1600/1601), the CSSO = *Clash Squad Strike Out* family
   (454/455/463-468), `RUDP_S2C_CSROUNDDRAGON_*` (1043/1045/2040).

> **The real-money store is a DIFFERENT protocol.** It is `proto.CSPurchaseReq` /
> `proto.CSPurchaseRes` (`0x0594eda8` / `0x0594ee00`) — protobuf over the
> **lobby TCP** channel, where the `CS` prefix means *Client→Server*, a naming
> collision with the Clash Squad `CS`. Siblings: `CSPurchaseClanPrivilegeReq`,
> `CSPurchaseWorkshopProductReq`, `CSPurchaseLimitedChestReq`. None of the RUDP
> ids in this section touch diamonds or real currency.

### 7.2 Inbound — the shop contents are FULLY readable

All server→client, all on the tracked match endpoint, all already traversing our
tunnel. Decoding is a plain `FastBinaryReader` varint walk (§3).

| Cmd | Name | Class | Body |
|---|---|---|---|
| 412 | `RUDP_SYNC_CSSHOPITEMS_LIST` | `NDLHKGONHKC` | `List<CAPCJBGAKPB>` + `string` + 2×`bool` + `uint` |
| 1034 | `RUDP_SYNC_ADD_CSSHOPITEMS_LIST` | `NDLHKGONHKC` | same class, append semantics |
| 931 | `RUDP_UPDATE_CSSHOPITEMS_LIST` | `DFIANINLEBF` | `List<LOAKHLDECDM>` = 4×`uint` each |
| 1205 | `RUDP_S2C_SYNC_CSSHOP_ITEMDATA_CHANGE` | `IBKMBMEPIFA` | `List<CAPCJBGAKPB>` |
| 1577 | `RUDP_SYNC_REPLACE_CSSHOPITEMS_LIST` | `AJIGIAJMDKG` | `List<MCEEPHBOJPD>` |
| 1578 | `RUDP_SYNC_REPLACE_CSSHOPITEM` | `GNMPBBMJPJH` | one `MCEEPHBOJPD` |
| 957 | `RUDP_CS_NOTIFY_TOKEN_NUM` | `NLFBKMGEOKB` | 2×`uint` — your token balance |

`MCEEPHBOJPD` = `{ uint slotIndex; CAPCJBGAKPB item; }`.

`CAPCJBGAKPB` is one shop entry, **23 fields** (TypeDefIndex 3423): 4×`uint`,
3×`byte`, 2×`bool`, a `string` at 0x30, then `byte`/`uint` alternating to 0x5C,
a `DKGCKAAGBIG` enum at 0x60 and a trailing `bool`. Field names are obfuscated —
map them by correlating against `COW.CSShopItemData`, whose names did NOT get
obfuscated: `iID, originalPrice, price, filter, limitation, TeamLimitation,
stack, hideCheckItemList, quickBuy, maxLevel, onlyShow, bonus, faction,
resetTime, maxCount, TechPointLimit, requiredBattleStyle,
requiredBattleStyleAbility, BooyahBountyLimit`.

> **`COW.CSShopItemData` is a CLIENT-SIDE CONFIG TABLE**, not a wire type — it has
> `ParseData`/`GetPrimaryKey` like every other datatable row. Its `price` field is
> for display. Editing it changes your own UI and nothing the server believes.

**Open, and worth one capture:** whether 1205 / 931 / 1578 are broadcast
match-wide or scoped to your own squad. If match-wide, the enemy's per-round
purchases are readable — a loadout ESP for Clash Squad. Pure observation either
way; nothing needs to be sent to find out.

### 7.3 Outbound — you CAN send a purchase, and it buys you nothing

Cmd 413 `RUDP_PURCHASE_CSITEMS` is genuinely client→client-sendable. Send site
`COW.GamePlay.IHFFDJIDIAA::NMPDDOPCHBN+0x16c` @ `0x07398b84`, class
`message.DAFMJPEBBHI` (TypeDefIndex 4261):

```
uint            JPOBFBNAMHM   // 0x14  shop/round context id
List<uint>      KIJJKKOEEMB   // 0x18  the item ids being bought
ECSItemBuyType  LGKOKLCLEGN   // 0x20  Normal(1) | DoubleClick(2)
```

> **There is no price field and no token field on the wire.** The client names
> item ids; the server looks up the cost and debits the balance it alone owns.
> A hand-built 413 is exactly the buy button — there is no "price = 0" to write,
> because the price never leaves the server.

The balance is server-owned and server-announced (957 is S→C). The shop contents
are server-owned and server-announced (412 et al. are S→C). Every lever is on the
far side.

Related outbound:

| Cmd | Name | Class | Body | Send site |
|---|---|---|---|---|
| 607 | `RUDP_ASK_PURCHASE_CSITEMS` | `ODAFMPDAEIL` | `List<uint>` | `UIModelMatch::AskCSPurchase+0x118` |
| 608 | `RUDP_PURCHASE_CSITEMS_FOROTHERS` | `FDDGNOMMIGP` | `uint target` + `List<uint>` | `UIModelMatch::PayForOther+0x4c8` |
| 1492 | `RUDP_C2S_SYNC_USE_CSSHOP` | `NNHMKOLHBCL` | one `bool` | `UIHudCSShopController::Show/Hide` |

608 spends **your** tokens on a teammate — still your balance.

`UIHudCSShopController::OnCoinBtnClick` sends 551 `RUDP_SYNC_QUICK_CHAT` and 957.
That is the *coin* button broadcasting your token count to the squad, not a
purchase — do not mistake it for one.

### 7.4 The transport blocker, which applies to any new outbound message

These are all reliable-channel messages. Emitting a *new* one means inventing a
sequence number the game's own reliability layer has not issued, which desyncs
the client and server windows — the precise failure mode behind the mid-match
kicks that the teleport work spent three iterations eliminating (see
`ff-route-fallback-kick`, `docs/TELEPORT.md`).

The mechanism this project has actually proved safe is **rewrite in place, never
inject and never withhold** — which costs whatever message you overwrite. That
trade is worth it for position (teleport/ghost). It is not worth it to press a
button the game will press for free.
