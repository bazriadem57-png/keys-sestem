# Aim drag controller — measured tuning

Everything below is output from `tools/aim_control_sim.py`, which replays the
loop against the **real** outbound Cmd 2001 timestamps in
`captures/device_pull_20260910/dev_logs/own_20260910_200050.csv` (7 082
samples) and uses a real pitch trace from the same capture as the moving
target. Nothing here is a guess.

## 1. The sampling delay, measured

```
Cmd 2001 sampling: n=7082  mean=99.0ms  median=100.0ms  p90=101.0ms
                   p99=103.0ms  max=117.0ms
```

The camera feed is a metronome: 100 ms, ±3 ms at the 99th percentile. So the
dead time is

```
L = 25 ms (inject->game + VPN decode->render)  +  50 ms (half a sample)  =  75 ms
```

For a velocity-command loop through dead time `L`, `ė(t) = −K·e(t−L)` is stable
only while `K·L < π/2`:

| | value |
|---|---|
| stability limit | `K < 20.9 /s` |
| well damped (`K·L ≈ 0.5`) | `K ≈ 6.7 /s` |

## 2. Controller comparison

Static target 8° off, 0.3° measurement noise (the ESP dead-reckons the head
point between 5 Hz entity updates, so the error really is noisy — without
modelling that, the deadzone suppresses all chatter and every controller
scores the same).

| controller | K | settle | tail rms |
|---|---|---|---|
| no compensator | 3.0 | 544 ms | 0.03° |
| no compensator | 6.0 | 312 ms | 0.59° |
| **exp-decay (what shipped)** | 4.5 | 704 ms | 0.75° |
| **exp-decay (what shipped)** | 6.0 | **1736 ms** | 0.14° |
| ring-buffer predictor | 6.0 | 400 ms | 0.04° |
| ring-buffer predictor | 10.0 | 288 ms | 0.21° |
| **ring-buffer predictor** | **16.0** | **248 ms** | **0.09°** |
| ring-buffer predictor | 24.0 | 232 ms | 0.35° |

The shipped exponential-decay compensator is the worst of the three. Its decay
constant is not the delay — it is a fudge that keeps subtracting long after the
feedback has arrived, so the controller believes it has already done work it
has not done, and crawls. **Predictor at K=16 settles 7× faster than the
shipped controller at K=6, and lands more accurately.**

On the real capture trace (target swinging at a mean 11.8 °/s) the ordering
holds: tail rms 1.70° for the predictor at K=16 versus 2.31° for exp-decay at
K=6, and tail peak-to-peak 6.85° versus 8.59°.

## 3. Gain margin

Tail peak-to-peak, static target with noise. `0.00` = settled and quiet.

| K | no-comp | exp-decay | predictor |
|---|---|---|---|
| 2–24 | 0.00 | 0.00 | 0.00 |
| 32 | **9.36** | 0.00 | 0.00 |
| 48 | **10.38** | 0.00 | 0.00 |

The uncompensated loop breaks up between K=24 and K=32, consistent with the
predicted `K_crit = 20.9 /s` (the rate cap delays the onset a little). The
predictor is still clean at K=48 — which is the whole point: removing the dead
time from the loop removes the gain limit that dead time imposes.

## 4. Deadzone

Predictor K=10, static + noise.

| dz px | dz deg | settle | tail rms | judder | travel |
|---|---|---|---|---|---|
| 2 | 0.20° | 296 ms | 0.12° | **2** | 116 px |
| 4 | 0.40° | 288 ms | 0.40° | 0 | 85 px |
| **6** | **0.60°** | **304 ms** | **0.07°** | **0** | **79 px** |
| 10 | 1.00° | 280 ms | 0.31° | 0 | 77 px |
| 16 | 1.60° | 288 ms | 0.87° | 0 | 71 px |
| 24 | 2.40° | never | 1.71° | 0 | 63 px |

6 px is the sweet spot for Y and the current default is already right. Below
4 px the loop starts chasing noise (judder appears, travel jumps 47%). Above
~2° it cannot settle on its own — which is exactly the regime we *want* for X,
where Free Fire's own aim assist closes the last couple of degrees.

## 5. Speed cap

Predictor K=10 on the real trace: anything from 400 px/s up tracks equally
well (tail rms 1.89–1.99°); 200 px/s is too slow to keep up with an 11.8 °/s
target. Lower is less visible, so **700 px/s** is the pick — the bottom of the
flat part of the curve.

## Shipping values

| knob | value | why |
|---|---|---|
| controller | ring-buffer predictor | 7× faster settle, higher gain margin |
| `GAIN` Y | 12 /s | see §6 — measured against the shipped code, not the idealised model |
| `GAIN` X | 6 /s | assist leads, we only trim |
| `DEADZONE` Y | 6 px (0.6°) | quiet and accurate; noise-chasing below 4 px |
| `DEADZONE` X | 25 px (2.5°) | hand off inside FF's assist cone |
| `SPEED` | 700 px/s | bottom of the flat part of the tracking curve |
| `TRANSPORT` | 25 ms | inject→game + decode→render, the irreducible part |

Re-run with `python tools/aim_control_sim.py [capture.csv]` after any change to
the sampling rate or the ESP pipeline.

## 6. Re-tuned against the SHIPPED controller

The table in §2 scored an idealised predictor at a 900 px/s cap. The Java that
actually ships has a finite 256-entry ring, a 700 px/s cap and applies the 1 px
floor after the cap, so `JavaShippedController` in the simulator is a literal
port of `AimInjector.tick()` and the gain was re-picked against that:

| K | static settle | static overshoot | static tail rms | real-trace tail rms | real-trace tail p-p |
|---|---|---|---|---|---|
| 8 | 328 ms | 0.0% | 0.17° | 2.01° | 10.19° |
| 10 | 288 ms | 0.0% | 0.26° | 1.86° | 9.66° |
| **12** | **272 ms** | **0.0%** | **0.05°** | **1.76°** | **9.02°** |
| 14 | 256 ms | 3.1% | 0.25° | 1.73° | 8.64° |
| 16 | 248 ms | 6.1% | 0.49° | 1.69° | 8.23° |
| 20 | 240 ms | 7.1% | 0.57° | 1.49° | 7.52° |

12 is the knee: the last gain with **zero overshoot**, the best steady-state
accuracy in the whole sweep, and already most of the tracking benefit. Every
gain above it trades overshoot for a little more tracking — and overshoot on a
settled target is exactly what reads as the view "going wild". Shipped default:
`GAIN = 12`.
