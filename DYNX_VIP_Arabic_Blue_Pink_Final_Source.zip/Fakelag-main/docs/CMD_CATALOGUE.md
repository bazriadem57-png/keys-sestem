# Free Fire UDP message IDs — recovered from the game's own metadata

**These are the game's real names, not guesses.** Recovered from `global-metadata.dat`
by parsing the enum default-value blobs. Full listing (1876 Cmd members + 252 PRI
property ids + the reserved enum + packet constants): [`tools/ff_cmd_catalogue.txt`](../tools/ff_cmd_catalogue.txt).
Reusable parser: [`tools/il2cpp_meta.py`](../tools/il2cpp_meta.py).

---

## The decoding trap (cost real effort, do not repeat)

This image's `fieldAndParameterDefaultValueData` is **not raw little-endian**. It
stores IL2CPP *compressed* integers (ECMA-style big-endian prefix: `0x80` → 2-byte,
`0xC0` → 4-byte), and **signed int32 enums are additionally zigzag-encoded** while
other underlying types are plain.

Decoding it as plain int32 yields values that look superficially plausible
(`x128 = 129`, message ids marching `+50/−51/+51/−52`) but are garbage. The underlying
type must be pinned per enum via mscorlib's marker enums (`System.UInt32Enum`,
`ByteEnum`, …). Validated end-to-end against `DayOfWeek` 0-6, `FileMode` 1-6,
`BindingFlags` powers-of-two, `CorElementType` (byte), `BsonType` (sbyte), and
`AK_INVALID_PLUGINID = 4294967295`. All exact.

## Namespace split

| range | enum | channel |
|---|---|---|
| 0 | `INVALID_MESSAGE_ID` | — |
| **1..99** | `GCommon.UDPMessageIDReserved` | transport |
| **100..3586** | `message.KLINFKFBIKB` (type name obfuscated, members intact) | application |

`RUDP_*` members (1820) ride the reliable channel; `UDP_*` members (55) the
unreliable state-sync channel. That split matches `SENDOPTION_RELIABLE` vs
`SENDOPTION_VAR` on the wire, which is one of the cross-checks that confirms the
identification.

```
UDP_HELLO=1  UDP_ACK=2  UDP_PING=3  UDP_BYEBYE=4
UDP_LONGTIMENOSEE=5  MUDP_CONNECT_ACK=6  RUDP_SPLITTED_DATAGRAM=99
```

---

## Observed commands — what they actually are

### Corrections to earlier guesses in this project

| Cmd | I previously called it | it actually is |
|---|---|---|
| **106** | "fire event, 412 B" | **`RUDP_TAKE_DAMAGE`** |
| **107** | "player names" | **`RUDP_DEAD`** — the ASCII names in it are the death notice |
| **230** | "damage/state snapshot" | **`RUDP_UPDATE_PICKUPLIST`** — loot, not damage |
| **231** | "damage event, HP values" | **`RUDP_ADD_CONTAINER`** — a loot container. The `100/200/300` values I read as HP were container/item numbers |

The real health and damage path is §"Health" below. **Do not build HP bars on 230/231.**

### Confirmed movement / state (plaintext)

| Cmd | name | rate |
|---|---|---|
| **2012** | **`UDP_PLAYER_STATE_SYNC_V2`** | 5.06 Hz — **the ESP entity chain** |
| **2001** | `UDP_PLAYER_STATE_SYNC` | OUT 10 Hz / IN 5 Hz — own position |
| 2000 | `UDP_SYNC_SERVER_TIME` | 0.5 Hz |
| 2002 | `UDP_VEHICLE_STATE_SYNC` | low |
| 2003 | `UDP_AIRDROP_STATE_SYNC` | 0.86 Hz |
| 2009 | `UDP_AI_STATE_SYNC` | — |
| 2010 | **`UDP_PLAYER_HURT`** | — |
| 3 | `UDP_PING` | 1 Hz |

### Combat

| Cmd | name |
|---|---|
| **104** | **`RUDP_START_FIRE`** |
| **105** | **`RUDP_STOP_FIRE`** |
| **106** | **`RUDP_TAKE_DAMAGE`** |
| **107** | **`RUDP_DEAD`** |
| **168** | `RUDP_SHOW_DAMAGE` |
| **1109** | `RUDP_S2C_ENEMY_HIT_NOTIFY` |
| 2010 | `UDP_PLAYER_HURT` |
| 133 / 134 | `RUDP_START_RELOAD` / `RUDP_STOP_RELOAD` |

**The user's hunch about 104/105/106 was right** — 104/105 are the fire events.

### Inventory / loot

| Cmd | name |
|---|---|
| 108 | `RUDP_CHANGE_INVENTORY_ON_HAND` |
| 111 / 112 | `RUDP_PICKUP_INVENTORY` / `RUDP_DROP_INVENTORY` |
| 113 | `RUDP_USE_INVENTORY` |
| 115 | `RUDP_DEL_PICKUP` |
| 121 | `RUDP_EQUIPMENT_CHANGED` |
| 124 | `RUDP_ATTACHMENT_CHANGED` |
| 131 / 132 | `RUDP_TRYUSE_INVENTORY` / `RUDP_CANCELUSE_INVENTORY` |
| 229 / 230 | `RUDP_ADD_PICKUPLIST` / `RUDP_UPDATE_PICKUPLIST` |
| 231 | `RUDP_ADD_CONTAINER` |
| 855 | `RUDP_CONTAINER_PICKUPSTATE` |

### Visibility, zone, match

| Cmd | name |
|---|---|
| **135** | **`RUDP_SYNC_PLAYERS_VISIBILITY`** |
| 136 | `RUDP_SYNC_VEHICLES_VISIBILITY` |
| 117 | `RUDP_SAFE_ZONE_CHANGE` |
| 322 | `RUDP_MANUAL_ZONE_ENTEROREXIT` |
| 154 | `RUDP_AIRDROP_START` |
| 751/752/753 | airdrop flare / light sync |
| 170 | `RUDP_UPDATE_BUFFBEHAVIOR` |
| 204 | `RUDP_PLAYER_DO_ACTION` |
| 872 | `RUDP_MATCH_EVENT_ACHIEVEMENT` |
| 1094 | `RUDP_S2C_ShowUIFXFollowPlayer` |
| 1715 | `RUDP_S2C_SYNC_GAMEEVENT_BLOODMOON_GP_INFO` |

`RUDP_SYNC_PLAYERS_VISIBILITY` (135) is worth attention — it is the server's
interest-management message and likely governs which entities you are told about
at all.

---

## Health and armour — the real source

**Cmd 1900 = `RUDP_VAR_SYNC_PRI_DATA`** (0.72 Hz) carries per-player property
updates, keyed by ids from `message.NIPHKJAOKGI` — **252 `EPRI_*` members**:

```
EPRI_PLAYER_CUR_HP              = 0
EPRI_PLAYER_MAX_HP              = 1
EPRI_PLAYER_VEST_DURABILITY     = 2
EPRI_PLAYER_HELMET_DURABILITY   = 3
EPRI_PLAYER_CAMOUFLAGE_HP       = 16
EPRI_PLAYER_Reaper_HP           = 49
EPRI_PLAYER_ARMOR_REDUCEDAMAGE_INCREMENT = 83
```

Cmd 1901 = `RUDP_VAR_SYNC_GRI_DATA` is the game-wide (match) equivalent.

**This is where HP and armour live** — a keyed property-update stream, not a fixed
field in a state packet. That is consistent with the user's report that the app shows
a static value: nothing was ever reading this channel.

---

## Packet constants (full, from `GCommon.UDPMsgPacket`)

```
UDPMESSAGE_HEADER_MINI_SIZE        = 5
UDPMESSAGE_HEADER_RELIABLE_SIZE    = 10
UDPMESSAGE_HEADER_NONRELIABLE_SIZE = 8
SENDOPTION  NONE=0 HELLO=1 RELIABLE=2 BYEBYE=3 VAR=4 VAR_RELIABLE=5
FLAG_ENCRYPTION = 1   FLAG_ZIP = 2
```

Field types: `MsgKey`, `CRC7`, `SendOption`, `Flags` are **byte**; `Cmd`, `OrderID`,
`Length` are **ushort**; `DestinationIP` is **uint**; `Data` is `byte[]`.
Header field order comes from `GCommon.UDPMSG_BITTYPE`:
`SENDOPTION=0, CMD=1, ORDERID=2, FLAGS=3, DATALEN=4, COUNT=5`.

There is no `SendOption` *enum* — it is this const set on `UDPMsgPacket`.

## Confidence

High. `message.KLINFKFBIKB` is the **only** enum among 45 736 types containing both
`UDP_PLAYER_STATE_SYNC` and `RUDP_TAKE_DAMAGE`; its 100..3586 range exactly
complements the reserved enum's 1..99; the only two observed values it lacks (2, 3)
are precisely `UDP_ACK`/`UDP_PING` from that reserved enum; and its `RUDP_`/`UDP_`
prefixes mirror the reliable/unreliable channel split seen on the wire.

Caveat: `Cmd` is a plain `ushort` on the wire, so the enum link is by value and
namespace partition, not by declared type. Two larger enums exist but are unrelated
(`IFix.IDMAP0`, `COW.EventID`).
