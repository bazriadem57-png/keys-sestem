# Cmd 2002 — `UDP_VEHICLE_STATE_SYNC` — outbound wire layout

> **CONFIRMED ON THE WIRE 2026-09-15.** Sec 3.2's raw-byte reading of field 8 is
> correct and is now measured on 137 outbound and 592 inbound packets, both
> oracles clean. See `MOUNTED_CAPTURE_ANALYSIS.md`.

**Status: SOLVED from the binary.** Every structural claim below carries an address.
Not yet confirmed against a live capture — see §9 for exactly what a capture would settle.

Image: `C:\Users\Tonyt\Documents\FF-RE\bin\libil2cpp_dec.so` (decrypted).
Symbols: `rva_map.txt`. Address convention: `file_offset = vaddr - 0x4000` for `.text`
(verified against ELF PT_LOAD #3: `off=0x351f92c vaddr=0x352392c`).
Structure-only facts taken from `dump.cs` (a **different build**) are labelled `[dump.cs]`.

---

## 1. Answer in one paragraph

Cmd **2002** is `message.JBECKHDPPOO`, wrapping `message.OLEOJNOGCCN`. It is built in the
`Player::get_IsDriver()` branch of `COW.GamePlay.PNCPKGJGBPP::EAIKJCCNGMJ` and sent with
`sendOption = 0` → **unreliable → plaintext, readable without the session key**.
It carries the **vehicle's** world position in millimetres and the **vehicle's** world
rotation as a 4-component quaternion, plus vehicle velocity, one packed-op byte and the
server tick. **It carries no player aim vector and no PlayerID at all.** Cadence is
byte-for-byte the same gate as 2001 (`counter % 3 == 0`), so the tick period is identical.

---

## 2. The layout (template-matched to the solved Cmd 2001 table)

Outer class `message.JBECKHDPPOO`, inner `message.OLEOJNOGCCN`. Handle + 12 values.
The inner object is serialised **inline**, with no length prefix and no tag bytes —
it is a flat continuation of the same varint stream.

| idx | field (obfuscated) | meaning | encoding |
|---|---|---|---|
| h | `OLEOJNOGCCN.FAAMLGOPLAC` | **vehicle LevelObject ID** (`Vehicle.LevelVehicle.GetObjectID()`) — *not* PlayerID | **LEB128** (plain uint varint, **no zigzag**) |
| v0 | `MOEFFAIDCBP.DJOGCAJNMNC` | vehicle position **X** — millimetres | zigzag varint (int32) |
| v1 | `MOEFFAIDCBP.IKOAGHHEHNL` | vehicle position **UP (Y)** — millimetres | zigzag varint (int32) |
| v2 | `MOEFFAIDCBP.HDAKKOIKINN` | vehicle position **Z** — millimetres | zigzag varint (int32) |
| v3 | `LFCNHAJBHEE.DJOGCAJNMNC` | vehicle world rotation **qx** × 1000 | zigzag varint (int16) |
| v4 | `LFCNHAJBHEE.IKOAGHHEHNL` | vehicle world rotation **qy** × 1000 | zigzag varint (int16) |
| v5 | `LFCNHAJBHEE.HDAKKOIKINN` | vehicle world rotation **qz** × 1000 | zigzag varint (int16) |
| v6 | `LFCNHAJBHEE.BCAEBLEEEOD` | vehicle world rotation **qw** × 1000 | zigzag varint (int16) |
| v7 | `OLEOJNOGCCN.JBOGMCKPKLJ` | `Vehicle::GetCurrentPackedOp()` — packed input/op bitfield | **RAW byte** |
| v8 | `AAPGPMPKMBD.DJOGCAJNMNC` | vehicle velocity **X** × 100 (cm/s) | zigzag varint (int16) |
| v9 | `AAPGPMPKMBD.IKOAGHHEHNL` | vehicle velocity **Y** × 100 (cm/s) | zigzag varint (int16) |
| v10 | `AAPGPMPKMBD.HDAKKOIKINN` | vehicle velocity **Z** × 100 (cm/s) | zigzag varint (int16) |
| v11 | `JBECKHDPPOO.DNNFOOGPFHO` | `GameFacade::CurrentServerTick()` | **LEB128** (plain uint varint) |

Typical encoded body: **~22–34 bytes**. There is no checksum, no nonce, no client ms clock,
no platform id and no aim vector (see §6).

### Decoder pseudocode

```
h   = readVarintU()          # vehicle level-object id
px  = zigzag(readVarintU())  # mm
py  = zigzag(readVarintU())  # mm  (UP)
pz  = zigzag(readVarintU())  # mm
qx  = zigzag(readVarintU()) / 1000.0
qy  = zigzag(readVarintU()) / 1000.0
qz  = zigzag(readVarintU()) / 1000.0
qw  = zigzag(readVarintU()) / 1000.0
op  = readRawByte()          # <-- ONE RAW BYTE, not a varint
vx  = zigzag(readVarintU()) / 100.0   # m/s
vy  = zigzag(readVarintU()) / 100.0
vz  = zigzag(readVarintU()) / 100.0
tick= readVarintU()
```

The single raw byte at v7 is the trap: a varint decoder that walks over it desyncs
v8..v11 whenever `op >= 0x80`.

---

## 3. Address evidence, claim by claim

### 3.1 The message identity

| claim | evidence |
|---|---|
| The dispatcher is `COW.GamePlay.PNCPKGJGBPP::EAIKJCCNGMJ` | `0x078cdd78 .. 0x078cf588` (next symbol `OPHFNKPJOCI`) |
| **Cmd 2002 = `message.JBECKHDPPOO`** | `0x078ce558  mov w0, #0x7d2` (= 2002) with `0x078ce560  mov x1, x19`, where `x19` is the object allocated at `0x078ce434 mov x19,x0` / `0x078ce438 bl message.JBECKHDPPOO::.ctor` |
| It is sent at the shared tail-call | `0x078ce564 b #0x78ce64c` → epilogue → `0x078ce684  b #0x75488ac ; COW.GameFacade::Send` |
| `JBECKHDPPOO::Serialize` | `0x049d724c .. 0x049d7334` |
| `OLEOJNOGCCN::.ctor` is the inner object | `0x078ce454  bl #0x47cf0ac ; message.OLEOJNOGCCN::.ctor`, stored to `+0x18` at `0x078ce460  str x22,[x20,#0x18]!` (`x20 = x19`) |
| `OLEOJNOGCCN::Serialize` | `0x047cec24 .. 0x047cee20` |

`[dump.cs]` class shapes (structure only, RVAs there are **not** ours):

```
class JBECKHDPPOO : UDPClientMessageBase   // TypeDefIndex 3515
    OLEOJNOGCCN COCJHEFNCGP;   // 0x18
    uint        DNNFOOGPFHO;   // 0x20

class OLEOJNOGCCN : UDPClientMessageBase   // TypeDefIndex 3353
    uint        FAAMLGOPLAC;   // 0x14
    PMFGOGFPDHM MOEFFAIDCBP;   // 0x18
    BJIPILEFOGL LFCNHAJBHEE;   // 0x20
    byte        JBOGMCKPKLJ;   // 0x28
    BDOPLCJODBN AAPGPMPKMBD;   // 0x30
```

### 3.2 Wire order (from the two `Serialize` bodies, not from field offsets)

`JBECKHDPPOO::Serialize` @ `0x049d724c`:

```
0x049d7290  ldr x22,[x21,#0x18]!        ; inner OLEOJNOGCCN
0x049d72fc  ldp x9,x2,[x8,#0x198]       ; vtable slot 6 == Serialize  -> inner.Serialize(writer)
0x049d7300  blr x9
0x049d7308  ldr w1,[x20,#0x20]          ; DNNFOOGPFHO
0x049d7314  bl  #0x8291898              ; FastBinaryWriter::Write(uint)
0x049d732c  b   #0x8290e84              ; Flush
```

`OLEOJNOGCCN::Serialize` @ `0x047cec24`:

```
0x047cec80  ldr  w1,[x20,#0x14]   0x047cec8c bl #0x8291898  ; Write(uint)        -> h
0x047cec94  ldr  x22,[x21,#0x18]! 0x047ced04 blr (slot 6)   ; PMFGOGFPDHM        -> v0..v2
0x047ced0c  ldr  x22,[x21,#0x20]! 0x047ced7c blr (slot 6)   ; BJIPILEFOGL        -> v3..v6
0x047ced80  ldrb w1,[x20,#0x28]   0x047ced8c bl #0x8291c9c  ; Write(byte)        -> v7
0x047ced90  ldr  x21,[x20,#0x30]! 0x047cee00 blr (slot 6)   ; BDOPLCJODBN        -> v8..v10
0x047cee18  b    #0x8290e84                                 ; Flush
```

Note the byte at `+0x28` is written **between** the quaternion and the velocity, i.e. the
wire order is *not* ascending-offset-with-objects-last. It is: `0x14, 0x18, 0x20, 0x28, 0x30`.

vtable base derivation: `Serialize` is `Slot: 6` `[dump.cs]`, and the virtual dispatch uses
`[klass + 0x198]` ⇒ vtable base `0x138`, slot *n* at `0x138 + 16n`. Used again in §3.5.

### 3.3 Serializer semantics — every writer classified

| helper | address | what it emits |
|---|---|---|
| `FastBinaryWriter::Write(int)` | `0x08290ef4` | **zigzag** (`sbfiz x11,x20,#1,#0x20` + `eor x1,x11,x10,asr #63`) → `AppendVarint` |
| `FastBinaryWriter::Write(short)` | `0x08291b38` | **zigzag** (`sbfiz x11,x20,#1,#0x10` + `eor x1,x11,x10,asr #63`) → `AppendVarint` |
| `FastBinaryWriter::Write(uint)` | `0x08291898` | **plain** `AppendVarint`, **no zigzag** |
| `FastBinaryWriter::Write(byte)` | `0x08291c9c` | tail-calls `WriteFixU8` |
| `FastBinaryWriter::WriteFixU8` | `0x08291ff4` | `DemandSpace(1)` then `strb w19,[x8,#0x20]` — **exactly one raw byte** (`0x08292030`) |
| `FastBinaryWriter::AppendVarint` | `0x08290f64` | LEB128 |

Per-component encodings, read out of the three vector classes' own `Serialize`:

| class | address | components |
|---|---|---|
| `message.PMFGOGFPDHM::Serialize` | `0x047c2ff0` | 3 × `ldr w1,[+0x14/0x18/0x1c]` → `Write(int)` `0x8290ef4` ⇒ **3 zigzag varints of int32** |
| `message.BJIPILEFOGL::Serialize` | `0x047c30f8` | 4 × `ldrh w1,[+0x12/0x14/0x16/0x18]` → `Write(short)` `0x8291b38` ⇒ **4 zigzag varints of int16** |
| `message.BDOPLCJODBN::Serialize` | `0x047c2de0` | 3 × `ldrh w1,[+0x12/0x14/0x16]` → `Write(short)` `0x8291b38` ⇒ **3 zigzag varints of int16** |

### 3.4 Quantisers — units and axis order

| helper | address | multiplier | stores | meaning |
|---|---|---|---|---|
| `message.KANJBNIANHC::COGCJKJPPHI` | `0x0577e298` | `mov w9,#0x447a0000` = **1000.0f** (`0x0577e32c`) | `str` int32 at `+0x14,+0x18,+0x1c` (`0x0577e3f8/0x0577e4bc/0x0577e580`) | **millimetres**, Vector3 |
| `message.KANJBNIANHC::HDMMEFFMIJP` | `0x0577e5e0` | `mov w9,#0x447a0000` = **1000.0f** (`0x0577e67c`) | `strh` int16 at `+0x12,+0x14,+0x16,+0x18` (`0x0577e744/0x0577e804/0x0577e8c4/0x0577e984`) | **quaternion × 1000**, 4 components |
| `message.KANJBNIANHC::JNMALNNFDLI` | `0x0577de98` | `mov w9,#0x42c80000` = **100.0f** (`0x0577df2c`) | `strh` int16 at `+0x12,+0x14,+0x16` (`0x0577dff4/0x0577e0b4/0x0577e174`) | **×100**, Vector3 |
| `message.KANJBNIANHC::JMELIEOFFHJ` | `0x0577e1d8` | none | raw float32 | (used by 2001 only) |

Argument order is preserved verbatim: in all three, `v0→` first slot, `v1→` second, `v2→` third,
`v3→` fourth (e.g. `HDMMEFFMIJP` `0x0577e608-0x0577e614`: `v8=v3, v9=v2, v10=v1, v11=v0`, then
`s11(arg0)→+0x12`, `s10(arg1)→+0x14`, `s9(arg2)→+0x16`, `s8(arg3)→+0x18`). Since
`UnityEngine.Vector3` is `(x,y,z)` and `Quaternion` is `(x,y,z,w)` in register order s0..s3,
the wire order is **X, UP(Y), Z** for vectors — the same convention as Cmd 2001 — and
**qx, qy, qz, qw** for the quaternion.

Rounding: value is `(v + eps) * scale`, then round-half-to-even. `eps` is read from `.rodata`:
`0x18ba38c = 1.0e-4` (used by `COGCJKJPPHI` and `HDMMEFFMIJP`) and
`0x18baec4 = 1.0e-3` (used by `JNMALNNFDLI`). Both are tie-break nudges; ignore them when decoding.

### 3.5 Where each value comes from (the build site, `0x078ce3ec .. 0x078ce564`)

```
0x078ce3f4  bl Player::get_IsDriver                 ; gate
0x078ce408  bl Vehicle::IsLocalAuth                 ; gate  (x21 = GetVehicleIAmIn, set at 0x078ce0e8)
0x078ce418  bl Player::get_WaitForForceSync         ; gate (inverted)
0x078ce438  bl message.JBECKHDPPOO::.ctor           ; x19 = outer
0x078ce454  bl message.OLEOJNOGCCN::.ctor           ; x22 = inner
0x078ce460  str x22,[x20,#0x18]!                    ; outer.COCJHEFNCGP = inner

0x078ce470  ldr x0,[x21,#0x120]                     ; Vehicle.LevelVehicle          [dump.cs: field @0x120]
0x078ce480  bl COW.GamePlay.BaseLevelObject::GetObjectID
0x078ce488  str w0,[x22,#0x14]                      ; h

0x078ce498  bl GCommon.Entity::get_Position   (0x08216bdc -> UnityEngine.Transform::get_position @0x08216c7c)
0x078ce4a0  bl KANJBNIANHC::COGCJKJPPHI             ; ×1000
0x078ce4a8  str x0,[x22,#0x18]!                     ; v0..v2

0x078ce4c4  bl GCommon.Entity::get_Rotation   (0x082174d8 -> UnityEngine.Transform::get_rotation @0x08217578)
0x078ce4cc  bl KANJBNIANHC::HDMMEFFMIJP             ; ×1000, 4 comps
0x078ce4d4  str x0,[x22,#0x20]!                     ; v3..v6

0x078ce4ec  bl PNCPKGJGBPP::INCBJGDHGOA             ; -> Vehicle::GetVelocity()
0x078ce4f4  bl KANJBNIANHC::JNMALNNFDLI             ; ×100
0x078ce4fc  str x0,[x22,#0x30]!                     ; v8..v10

0x078ce520  ldr x9,[x8,#0x8a8] ; 0x078ce528 blr x9  ; Vehicle vtable slot 119
0x078ce530  strb w0,[x20,#0x28]                     ; v7

0x078ce550  bl COW.GameFacade::CurrentServerTick
0x078ce55c  str w8,[x19,#0x20]                      ; v11

0x078ce558  mov w0,#0x7d2                           ; msgid 2002
```

The two virtual calls resolve cleanly with vtable base `0x138`:

* `[klass + 0x8a8]` ⇒ slot `(0x8a8-0x138)/16 = 119` — `[dump.cs] COW.GamePlay.Vehicle`
  slot 119 = `public virtual byte GetCurrentPackedOp()`. Return type **byte** matches the
  `strb` at `0x078ce530`.
* `[klass + 0x8f8]` ⇒ slot `(0x8f8-0x138)/16 = 124` — `[dump.cs]` slot 124 =
  `public virtual Vector3 GetVelocity()`. Return type **Vector3** matches the three floats
  `v0..v2` that `INCBJGDHGOA` forwards into `JNMALNNFDLI`.

  The two slot lookups landing on methods whose return types independently match the store
  widths is strong corroboration that the `dump.cs` slot numbering still applies here.

`PNCPKGJGBPP::INCBJGDHGOA` @ `0x078cdc1c` is a thin wrapper: it calls `Vehicle::GetVelocity()`
(`0x078cdcb0`) and then, if `Vehicle::InWaterAndShouldBreak()` (`0x078cdcec`) and
`|v|² <= threshold²` (`0x078cdcfc-0x078cdd18`, threshold from a static float at
`klass->static_fields + 0x1288`), substitutes `Vector3.zero`. So **while a vehicle is in
water below the break speed, 2002 reports zero velocity** even though the position keeps moving.

---

## 4. Reliable or unreliable — *unreliable, plaintext*

`COW.GameFacade::Send` @ `0x075488ac`. `[dump.cs]` signature:
`public static bool Send(uint messageID, UDPClientMessageBase msg, byte sendOption = 0, bool cacheMsgAnyWay = false)`,
corroborated by the register plumbing (`w0→w22` msgid, `x1→x19` msg, `w2→w20` sendOption,
`w3→w21` bool, forwarded at `0x07548960-0x0754896c` to the match client's vtable slot
`(0x1e8-0x138)/16 = 11`).

Arguments at the three send sites in this dispatcher:

| cmd | site | `w0` (msgid) | `w2` (sendOption) | `w3` (cacheMsgAnyWay) |
|---|---|---|---|---|
| **2002** | `0x078ce684` (tail `b`) | `0x7d2` @ `0x078ce558` | `wzr` @ `0x078ce674` | `wzr` @ `0x078ce678` |
| 2001 | `0x078cf1d4` | `0x7d1` @ `0x078cf1c0` | `wzr` @ `0x078cf1c8` | `wzr` @ `0x078cf1cc` |
| 2006 | `0x078ce8c8` | `0x7d6` @ `0x078ce8b4` | `wzr` @ `0x078ce8bc` | `wzr` @ `0x078ce8c0` |

`GCommon.UDPMsgPacket::IsReliable` @ `0x082c0c04`:

```
0x082c0c54  cmp w20,#2      b.eq -> 0     ; Cmd 2 (UDP_ACK) forced non-reliable
0x082c0c60  ldrb w8,[x8]    cbnz -> 0     ; global "force unreliable" static
0x082c0c68  sub  w8,w19,#1
0x082c0c70  cmp  w9,#4      b.hi -> 0
0x082c0c78  mov  w9,#0x13                 ; 0b10011
0x082c0c7c  lsr  w8,w9,w8
0x082c0c80  and  w0,w8,#1                 ; reliable iff (sendOption-1) in {0,1,4}
```

⇒ reliable iff `sendOption ∈ {1, 2, 5}` (HELLO / RELIABLE / VAR_RELIABLE), matching
`docs/PROTOCOL_CIPHER.md`. **2002 passes 0 ⇒ not reliable ⇒ plaintext, 8-byte header,
MsgKey 100..109, no TEA.** No session key needed to read it.

Independent corroboration: `docs/CMD_CATALOGUE.md` already lists
`2002 | UDP_VEHICLE_STATE_SYNC | low` under *“Confirmed movement / state (plaintext)”*,
i.e. it has already been observed unencrypted on the wire.

---

## 5. Cadence and gating

The counter and the throttle live at the very top of `EAIKJCCNGMJ`, **before** any
vehicle/foot branching, so every message this dispatcher can emit shares one cadence.

```
0x078cdef0  ldr w8,[x19,#0x660]
0x078cdefc  add w8,w8,#1
0x078cdf00  str w8,[x19,#0x660]        ; counter++
0x078cdf04  bl  PNCPKGJGBPP::EFJEIMIIEJO
0x078cdf08  tbz w0,#0,#0x78ce8cc       ; gate false -> return, nothing sent
```

`PNCPKGJGBPP::EFJEIMIIEJO` @ `0x078cdadc` returns **false** (nothing sent at all) when any of:

| condition | address |
|---|---|
| `this->[0x65c] != 0` (a disable flag) | `0x078cdb4c` |
| `player == null` | `0x078cdb78` |
| `AttackableEntity::get_IsDead()` | `0x078cdb8c` |
| `Player::get_IsOnBoard()` | `0x078cdb9c` |
| `Player::get_IsOnFerrisWheel()` | `0x078cdbac` |
| `Player::get_IsFollowing()` | `0x078cdbbc` |
| `Player::get_IsPassiveMoving()` | `0x078cdbcc` |
| `Player::IsOnlineBotAgent()` | `0x078cdbdc` |

otherwise it returns the **divisibility-by-3 test** on the counter:

```
0x078cdbf4  ldr w8,[x19,#0x660]
0x078cdbf8  mov w9,#0xaaab / movk #0xaaaa,lsl#16   ; 0xAAAAAAAB
0x078cdc00  mul w8,w8,w9
0x078cdc04  mov w9,#0x5556 / movk #0x5555,lsl#16   ; 0x55555556
0x078cdc0c  cmp w8,w9
0x078cdc10  cset w0,lo                             ; == (counter % 3 == 0)
```

⇒ **Cmd 2002's send cadence is bit-for-bit identical to Cmd 2001's** — same counter, same
gate, same function. If 2001 is ~99 ms (`%3` off a ~30 Hz driver), 2002 is ~99 ms too.
The absolute driver frequency was **not** re-derived here: the only caller of `EAIKJCCNGMJ`
is `PNCPKGJGBPP::OPHFNKPJOCI+0x220` (`bl` @ `0x078cf7a8`), which iterates the local entity
list and calls it once per `Entity::IsAutonomousProxy()` entity (`0x078cf798`), and
`OPHFNKPJOCI` itself has **zero direct `bl` xrefs** (it is virtual, dispatched through a
vtable), so its Update frequency was not traced. That does not matter for the answer, since
the ratio to 2001 is exact.

---

## 6. Anti-cheat / checksum

**None.** `JBECKHDPPOO::Serialize` writes exactly two things (inner message, then the tick)
and flushes — there is no checksum field, no nonce, and no `GFHPFJMGEKF`-style value.
The driver branch also never calls `PNCPKGJGBPP::BJNKBGDPBAC` (the client-clock helper at
`0x078cf3b8` that supplies 2001's v22 and 2069's trailing field), so **2002 has no client ms
clock either** — its only time reference is the server tick at v11.

---

## 7. Vehicle root or player? Platform-relative rule?

* **Vehicle root.** `x21` is `Player::GetVehicleIAmIn()` (`0x078ce0e8`), and `get_Position`
  / `get_Rotation` / `GetVelocity` / `LevelVehicle` are all taken from `x21`. The player's
  own transform is never read in this branch.
* The reported id `h` is the **vehicle's `LevelVehicle` object id**, not the player id and
  not the player's entity id.
* **No platform-relative rule.** `OLEOJNOGCCN` has no analogue of 2001's `v16`
  (`LPKKPCBKEBA`, moving-platform id) — `Player::get_FootMovePlatfromID` /
  `get_OffsetPositionToMovePlatform` are called only on the on-foot 2001 path
  (`0x078cf088`, `0x078cf09c`, `0x078cf0c8`). The 2002 position is always absolute world space.
* The seat offset between the vehicle root and the player's rendered body is **not** on the
  wire and is not recoverable from the packet — see §9.

---

## 8. The whole mounted dispatch, and where the aim vector actually is

This is the part that decides what the ESP can do while mounted. Control flow of
`EAIKJCCNGMJ`, with the exact branch instructions:

```
0x078cdf18  Player::IsInVehicle
  false -> 0x078cdfd4 ................................. foot / catapult / cannon / chair / 2001
  true  -> 0x078cdf28  Player::IsPassengerInVehicleCanFire
              true  -> 0x078cdf30  build KOEDKEJGCEP+JGGMLMNCMAA ......... Cmd 2006 (0x7d6)
              false -> 0x078ce0d0  Player::IsVehicleSupportDriverWeaponFire
                          true  -> 0x078ce118 build OGHGHMCCKFK .......... Cmd 2069 (0x815)
                          false -> 0x078ce3ec  Player::get_IsDriver
                                      true  -> build JBECKHDPPOO ......... Cmd 2002 (0x7d2)
                                      false -> 0x078ce688 build KOEDKEJGCEP  Cmd 2006 (0x7d6)
```

Confirming the premise in the brief: `0x078cdf1c  tbz w0,#0,#0x78cdfd4` — the 2001 path is
reachable **only** when `IsInVehicle()` is false. Mounted, 2001 stops entirely.

Extra gates on the 2002 branch (all cause a silent return with **nothing sent**):
`x21 == null` (`0x078ce3fc`), `!Vehicle::IsLocalAuth()` (`0x078ce40c → 0x078ce8cc`),
`Player::get_WaitForForceSync()` (`0x078ce41c → 0x078ce8cc`).

Other msgids emitted by the same dispatcher (found while walking it; recorded because the
repo's outbound registry only had 2016 for this Send site):

| cmd | hex | class | branch | msgid instruction |
|---|---|---|---|---|
| 2002 | `0x7d2` | `JBECKHDPPOO` + `OLEOJNOGCCN` | `get_IsDriver` | `0x078ce558` |
| 2006 | `0x7d6` | `KOEDKEJGCEP` + `JGGMLMNCMAA` | passenger / non-driver in vehicle | `0x078ce8b4` |
| 2015 | `0x7df` | `EHCDBOKGLEM` | `IsInCatapult` | `0x078ce0c8` |
| 2016 | `0x7e0` | `ECBGLGKBEBH` | `IsOnChair` | `0x078ce644` |
| 2031 | `0x7ef` | `GOOGGMOFFIK` | `IsInCannon` | `0x078ce3e4` |
| 2069 | `0x815` | `OGHGHMCCKFK` + `OLEOJNOGCCN` | `IsVehicleSupportDriverWeaponFire` | `0x078ce2e0` |
| 2001 | `0x7d1` | `DAIDIMLOEPL` + `ACDHGKMPIDJ` | on foot | `0x078cf1c0` |

### Does 2002 carry a player aim vector? **No.**

`Player::GetAimRotation` (`0x070718a8`) has exactly five call sites in this function:
`0x078ce14c` (2069), `0x078ce59c` (chair/2016), `0x078ce770` and `0x078ce810` (2006),
`0x078cebd4` (2001). It is **never** called on the path between `0x078ce3ec` and
`0x078ce564`. Neither is `GetAuxAimRotation` (`0x070e231c`, 2001 only, at `0x078cedd4`),
nor `Entity::get_Forward` (`0x08216dac`, at `0x078ce7e0` and `0x078cebc4`, both 2006/2001).
2002's only orientation is the **vehicle's** world quaternion.

### Cmd 2069 — the mounted message that *does* carry aim

`OGHGHMCCKFK::Serialize` @ `0x049d74e4`, wire order:

| idx | source | encoding |
|---|---|---|
| — | `OLEOJNOGCCN` (identical inner layout: h + v0..v10 above) | inline |
| next | `DNNFOOGPFHO` = `CurrentServerTick()` (`0x078ce1e4`) | LEB128 uint (`Write` @ `0x8291898`, `0x049d75b8`) |
| next | `DIPPKFBIILG` = `BDOPLCJODBN(GetAimRotation() * forward)` ×100 (`0x078ce14c`→`0x078ce1ac op_Multiply`→`0x078ce1b4 JNMALNNFDLI`) | 3 zigzag shorts |
| next | `HMKGHANBCNJ` = `BJNKBGDPBAC()` client ms clock (`0x078ce138`) | LEB128 uint (`0x049d7640`) |

So when 2069 is active you get the vehicle state **and** a real aim/camera direction in one
packet. But 2069 is gated on `Player::IsVehicleSupportDriverWeaponFire` @ `0x07083924`,
which first tests a game-mode flag: `CurrentGameModeSetting()` (`0x070839c0`) then
`ldrb w8,[x0,#0x23]; cbz w8 -> return false` (`0x070839c8-0x070839cc`). In modes where
that byte is 0, drivers always fall through to 2002.

---

## 9. What this means for the ESP, and what remains unknown

**Recoverable from 2002 while mounted:**

* Own world position, to the millimetre — `v0..v2 / 1000.0` metres, axes X, UP, Z, same
  frame and same 1000-units-per-metre scale as 2001's `v0..v2`. This directly fixes the
  frozen-position half of the bug.
* Own velocity (`v8..v10 / 100.0` m/s), except while in water below the break threshold (§3.5).
* The vehicle's full world orientation as a quaternion (`v3..v6 / 1000.0`), from which a
  vehicle-forward vector can be derived.
* The vehicle's level-object id (`h`) — stable per mounted vehicle, usable to detect
  mount/dismount transitions and to join against level-object traffic.

**Not recoverable from 2002:**

* **The camera / aim direction.** There is no player aim vector in the message. The honest
  options are (a) use the vehicle's forward from `v3..v6` as an approximation — correct for
  a follow-cam behind a car or horse, wrong the moment the player free-looks; or (b) hold
  the last aim vector seen from 2001 before mounting and let it stale; or (c) detect 2069
  and use its aim triple when the mode enables it.
* **The player's own position as distinct from the vehicle root.** The seat offset is never
  sent. It is a fixed per-vehicle local offset applied client-side.
* PlayerID — 2002 never carries it. Association of a 2002 stream to the local player must
  come from the fact that it is *outbound* (it is only ever built for the autonomous-proxy
  entity, `Entity::IsAutonomousProxy` @ `0x078cf798`), not from any field in the body.

**Explicitly undetermined from the binary — a capture would settle each:**

1. **Byte-level confirmation of the field order and the raw byte.** Capture outbound
   plaintext Cmd 2002 while driving in a straight line. Expect: first varint constant
   (the vehicle id), next three zigzag varints changing smoothly by a few hundred to a few
   thousand per tick (mm), then four small zigzag values whose squares sum to ≈ 1 000 000
   (the ×1000 quaternion — this is the single cheapest self-check in the whole record),
   then one byte, then three small zigzag values (cm/s), then a monotonically rising varint.
2. **The bit layout of `v7` (`GetCurrentPackedOp`).** Not decoded here; it is a virtual with
   a per-vehicle-subclass override. Capture while pressing throttle / brake / handbrake /
   horn and diff the byte.
3. **The seat offset** between the vehicle root reported in `v0..v2` and the player's
   rendered position. Measure by comparing 2002's position against an inbound 2012 entry
   for your own entity, or against the last 2001 position at the instant of mounting.
4. **Whether 2069 ever fires in the modes you play.** Gated on
   `CurrentGameModeSetting()+0x23`; check empirically by watching for cmd 0x815 while mounted.
5. **The absolute tick period.** Proven equal to 2001's; if the 99 ms figure for 2001 is
   itself capture-derived, 2002 inherits it without further work.

---

## 10. Quick reference — addresses added by this investigation

| symbol | address |
|---|---|
| `COW.GamePlay.PNCPKGJGBPP::EAIKJCCNGMJ` | `0x078cdd78` (ends `0x078cf588`) |
| `COW.GamePlay.PNCPKGJGBPP::EFJEIMIIEJO` (gate + `%3`) | `0x078cdadc` |
| `COW.GamePlay.PNCPKGJGBPP::INCBJGDHGOA` (vehicle velocity) | `0x078cdc1c` |
| `COW.GamePlay.PNCPKGJGBPP::BJNKBGDPBAC` (client ms clock) | `0x078cf3b8` |
| `COW.GamePlay.PNCPKGJGBPP::OPHFNKPJOCI` (only caller) | `0x078cf588` |
| Cmd 2002 msgid / send | `0x078ce558` / `0x078ce684` |
| `message.JBECKHDPPOO::Serialize` / `.ctor` | `0x049d724c` / `0x049d748c` |
| `message.OLEOJNOGCCN::Serialize` / `.ctor` | `0x047cec24` / `0x047cf0ac` |
| `message.OGHGHMCCKFK::Serialize` / `.ctor` (2069) | `0x049d74e4` / `0x049d7860` |
| `message.PMFGOGFPDHM::Serialize` (3×int32) | `0x047c2ff0` |
| `message.BJIPILEFOGL::Serialize` (4×int16 quat) | `0x047c30f8` |
| `message.BDOPLCJODBN::Serialize` (3×int16) | `0x047c2de0` |
| `message.KANJBNIANHC::HDMMEFFMIJP` (quat ×1000) | `0x0577e5e0` |
| `message.KANJBNIANHC::COGCJKJPPHI` (pos ×1000) | `0x0577e298` |
| `message.KANJBNIANHC::JNMALNNFDLI` (vec ×100) | `0x0577de98` |
| `GCommon.FastBinaryWriter::Write(int)` zigzag | `0x08290ef4` |
| `GCommon.FastBinaryWriter::Write(short)` zigzag | `0x08291b38` |
| `GCommon.FastBinaryWriter::Write(uint)` plain varint | `0x08291898` |
| `GCommon.FastBinaryWriter::Write(byte)` → raw | `0x08291c9c` |
| `GCommon.FastBinaryWriter::WriteFixU8` | `0x08291ff4` |
| `GCommon.FastBinaryWriter::AppendVarint` | `0x08290f64` |
| `GCommon.UDPMsgPacket::IsReliable` | `0x082c0c04` |
| `COW.GameFacade::Send` | `0x075488ac` |
| `GCommon.Entity::get_Position` / `get_Rotation` | `0x08216bdc` / `0x082174d8` |
| `COW.GamePlay.Player::IsVehicleSupportDriverWeaponFire` | `0x07083924` |
| rounding eps `1e-4` / `1e-3` (`.rodata`) | `0x18ba38c` / `0x18baec4` |
| il2cpp vtable base in `Il2CppClass` (slot *n* at base+16n) | `0x138` |
