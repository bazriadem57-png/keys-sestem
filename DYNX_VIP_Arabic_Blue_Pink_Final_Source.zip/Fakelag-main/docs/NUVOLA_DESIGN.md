# Nuvola — visual design system

**2026-09-16.** The app is renamed **SunnyMod → Nuvola** and every surface is
rebuilt against one token set. Live canvas (8 artboards, editable):
<https://claude.ai/artifact/X2wr1s5V3mvCf7uX96pyvF>

---

## 1. The one rule

> **Does this surface sit over live gameplay?**
>
> **No** → *maximalist*. Gradient, depth, generous type, motion on entry.
> **Yes** → *minimal*. One flat 80 % scrim, one accent, no shadow, no
> animation, nothing above 14 sp.

The app header is a gradient band and the floating title is a monospace pill
because they are the same component family answering opposite questions.

**An overlay element that hides an enemy is a bug, whatever it looks like.**
Boxes, radar and crosshair own the centre; everything else lives in the corners.

## 2. Colour — measured from the icon, not invented

Sampled from `Gemini_Generated_Image_o0dur9o0dur9o0du.jpg`:

| token | hex | role |
|---|---|---|
| `brand_gradient` | `135deg #2442A4 → #12A8A7` | header band, primary action, icon — **three places, never a page wash** |
| `teal` | `#16C5C3` | accent, ON state, ready |
| `teal_deep` | `#12A8A7` | icon gradient end |
| `blue` | `#3D5FE0` | secondary accent |
| `blue_deep` | `#2442A4` | icon gradient start |
| `ground` | `#070A18` | app background |
| `surface` | `#0F1430` | cards |
| `raised` | `#161D3F` | controls, chips |
| `line` | `#232B52` | borders, dividers |
| `text` | `#EEF1FB` | primary |
| `text_2` | `#A3AECF` | secondary |
| `text_3` | `#7B87B0` | labels, captions |
| `danger` | `#F2555A` | enemy box, stop, alarms |
| `warn` | `#F5A524` | learning, low HP |

Every text colour clears **4.5:1** on `ground`.

**State colour is the same four everywhere** — app, floating title, tune panel:
teal ready · amber learning · grey off · red alarm.

## 3. Type

| family | weights | used for |
|---|---|---|
| **Sora** | 600, 700 | display — screen titles, wordmark, big numbers |
| **Manrope** | 400–700 | body and UI — labels, rows, buttons |
| **JetBrains Mono** | 400, 500 | **diagnostics only** — DIAG block, hex, counters |

Scale: display 32 · title 20 · body 15 · label 13 · micro 11 · mono 12.

Bundled as `.ttf` under `res/font/` — **no network at runtime**. The ~40
Vietnamese strings inherited from the original fork go with the rename.

## 4. Spacing, radius, targets

4 · 8 · 12 · 16 · 24 · 32 dp. Radius 12 card, 16 panel, 20 hero, 999 pill.
**Touch targets never below 48 dp** (the tune panel's steppers are 52 dp).

## 5. Identity

`app_name` → **"Nuvola"** (Italian for cloud; the mark already reads as one).

**The package id stays `com.fakelag.cryhard8`.** Renaming it moves
`SharedPreferences` to a new file and destroys all 107 persisted settings on the
device. The label changes; the id must not.

### The icon needs real work

The Gemini render is 1024×1024 with the tile floating in white. Measured tight
bounds **(134,126) → (890,896) = 757×771** — not square, and ~12 % of every edge
is padding. It also carries baked-in rounded corners that Android would mask a
second time.

1. Crop to the tile, square on the longer side, centred.
2. Discard the JPEG's corners — Android masks its own.
3. Split into `ic_launcher_background` (vector gradient, edge to edge) and
   `ic_launcher_foreground` (white mark on transparent, inside the 66 dp safe
   circle).
4. **Re-cut the mark as vector.** JPEG edges will not survive 48 dp.

## 5b. Navigation — four pages, bottom bar

The single ~2500 dp scroll is gone. Four pages — **Engine / Overlay / Aim /
System** — with a bottom tab bar and a **pinned engine strip** above it.

**The bar is at the bottom** because this is a one-handed tool used in the
seconds before a match, and on a 2340 px screen the top cannot be reached
without shifting grip. Navigation up there is navigation that needs two hands.
Not a swipe pager either: the page carries 7 horizontal-drag sliders, and a
swipe pager over those is a permanent gesture ambiguity.

**Pages are shown and hidden, never inflated lazily.** ~60 ids are bound by
`findViewById` at startup and held; lazy pages would hand those bindings null
and crash on whichever page opened second.

**The engine strip is pinned above the tabs on every page except Engine**, so
the primary action is always at the most reachable point on the screen. On the
Engine page it stands down — the card is right there and two live copies of one
control 200 dp apart is worse than one.

Grouping is by **tempo**, not by subsystem: what you touch every match (Engine),
every few sessions (Overlay, Aim), once (System). Grouping by subsystem put
1.47 viewports on one page and left two others 70 % empty.

## 5c. Permissions are preconditions, not settings

Only **VPN** and **Display over other apps** remain. Notifications and Storage
were deleted: neither gated anything — the foreground notification posts
regardless, and captures go to the app's own external files dir, which has
needed no storage permission since API 19. Two rows that could sit permanently
red while everything worked, which teaches you to ignore the section.

**A permission is not a toggle.** It rendered as a switch, which lies twice:
you cannot revoke one by tapping it, and an "off" switch reads as a feature you
declined rather than something blocking you. Now: a **GRANT button that
disappears once granted**. Nothing to press means nothing is wrong. Amber dot
when missing — red is reserved for enemy boxes and real alarms.

**VPN is offered on a fresh launch**, once per process (not per `onCreate`, or
returning from the picker re-prompts someone who just declined).

## 6. Where the code goes

Only `config/`, `ui/` and `res/` are touched. Nothing under
`esp/ decode/ protocol/ tunnel/ diag/` moves.

| step | what | where | risk |
|---|---|---|---|
| 01 | tokens, fonts, theme | `res/values/{colors,type,dimens,themes}.xml`, `res/font/` | none |
| 02 | name, strings, adaptive icon | `res/values/strings.xml`, `res/mipmap-anydpi-v26/`, manifest | none |
| 03 | home screen | `res/layout/activity_main.xml` | none |
| 04 | target picker, diagnostics | `res/layout/` | none |
| 05 | floating button + title | `ui/button/` | **live code** |
| 06 | tune panel | `ui/panel/` | **live code** |
| 07 | box & radar paints | `ui/render/` | **live code** |

Steps 01–04 run before the tunnel opens and cannot break a match. 05–07 touch
live code — build and field-test each on its own.

**No literal hex in any layout or Java file.** If a screen needs a colour the
tokens lack, the token set is wrong, not the screen.

## 7. The four constraints this design had to respect

1. **Never rename a `Prefs` key.** All 107 are persisted on the phone.
2. **`onDraw` allocates nothing.** The renderer runs at 120 Hz over live
   gameplay; a gradient there is a cached `Shader` or it does not ship. The last
   decorative flourish cost an animator running `setShadowLayer` every frame.
3. **Capture has no off switch.** A control for it could only ever disable the
   recording every diagnosis depends on. Show `REC`; offer no toggle.
4. **`esp/` never imports `ui/`.** Moving `EspTuning` into `config/` is what
   removed that edge. A new screen reads state through `config/`, never the
   reverse.

---

## Type weights are pinned, and that is deliberate (2026-09-16)

The three faces in `res/font` ship **instanced and subset**, not as variable
fonts — see `tools/subset_fonts.py`, which carries the weights in a `WEIGHTS`
table and refuses to drop a character the original could render.

    nv_body     wght 500    body text and row titles
    nv_display  wght 600    the wordmark and screen titles
    nv_mono     wght 400    diagnostics

**Do not "restore" the variable defaults.** `nv_body`'s axis is
`(200, default 200, 800)` — Manrope's variable default is its *minimum*, so
before this the entire UI rendered at ExtraLight, thin on a dark surface,
purely because nothing ever set a weight and a resource-loaded `.ttf` with no
`<font-family>` wrapper is loaded at its default instance.

Icons: `docs/UI_ICONS.md`.
