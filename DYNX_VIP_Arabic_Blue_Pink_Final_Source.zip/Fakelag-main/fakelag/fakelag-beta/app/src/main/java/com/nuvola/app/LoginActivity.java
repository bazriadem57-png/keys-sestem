package com.nuvola.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.nuvola.app.auth.AuthConfig;
import com.nuvola.app.auth.LicenseClient;
import com.nuvola.app.auth.SessionManager;

/**
 * The login gate. Launcher activity: it either resumes a prior session and
 * jumps straight to {@link MainActivity}, or shows the license-key form.
 * MainActivity and the VPN engine refuse to start without an authorized session
 * (see {@link SessionManager#isAuthorized()}).
 *
 * <p>In a non-enforcing build ({@link AuthConfig#ENFORCE} false — i.e. debug),
 * this activity forwards to MainActivity immediately, so development keeps
 * working without a server.</p>
 */
public class LoginActivity extends Activity {

    private final Handler ui = new Handler(Looper.getMainLooper());
    private EditText etKey;
    private Button btnActivate;
    private TextView tvStatus;
    private View dot;
    private volatile boolean busy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Not enforcing (debug): skip the gate entirely.
        if (!AuthConfig.ENFORCE) {
            goMain();
            return;
        }

        // Keep the license key out of screenshots and the recents thumbnail.
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.activity_login);
        try { if (getActionBar() != null) getActionBar().hide(); } catch (Exception ignored) {}

        etKey = (EditText) findViewById(R.id.et_license_key);
        // Do not let the typed key survive in the saved-instance bundle.
        etKey.setSaveEnabled(false);
        btnActivate = (Button) findViewById(R.id.btn_activate);
        tvStatus = (TextView) findViewById(R.id.tv_login_status);
        dot = findViewById(R.id.dot_login);

        btnActivate.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onActivate(); }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!AuthConfig.ENFORCE || busy) return;
        if (SessionManager.isAuthorized()) { goMain(); return; }
        // Try to resume a prior session (online-required: refresh + reload config).
        setBusy(true, R.string.login_checking, R.drawable.dot_warn);
        new Thread(new Runnable() {
            @Override public void run() {
                final boolean ok = SessionManager.resume(getApplicationContext());
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (ok) { goMain(); }
                        else { setBusy(false, R.string.login_idle, R.drawable.dot_off); }
                    }
                });
            }
        }).start();
    }

    private void onActivate() {
        if (busy) return;
        final String key = etKey.getText().toString().trim();
        if (key.isEmpty()) {
            setStatusText(getString(R.string.login_empty), R.drawable.dot_warn);
            return;
        }
        setBusy(true, R.string.login_activating, R.drawable.dot_warn);
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    SessionManager.activate(getApplicationContext(), key);
                    ui.post(new Runnable() {
                        @Override public void run() {
                            setStatusText(getString(R.string.login_ok), R.drawable.dot_on);
                            goMain();
                        }
                    });
                } catch (final LicenseClient.AuthException e) {
                    ui.post(new Runnable() {
                        @Override public void run() {
                            setBusy(false, 0, R.drawable.dot_warn);
                            setStatusText(e.getMessage(), R.drawable.dot_warn);
                        }
                    });
                }
            }
        }).start();
    }

    private void goMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void setBusy(boolean b, int statusRes, int dotRes) {
        busy = b;
        if (btnActivate != null) btnActivate.setEnabled(!b);
        if (statusRes != 0) setStatusText(getString(statusRes), dotRes);
        else if (dot != null) dot.setBackgroundResource(dotRes);
    }

    private void setStatusText(String s, int dotRes) {
        if (tvStatus != null) tvStatus.setText(s);
        if (dot != null) dot.setBackgroundResource(dotRes);
    }
}
