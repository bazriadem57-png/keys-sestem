package com.nuvola.app.filter;

import com.nuvola.app.protocol.GamePacketTaxonomy;

import com.nuvola.app.dev.DevLogger;
import com.nuvola.app.decode.body.Cmd;

/**
 * Freeze policy: withholds the inbound world-state streams so other players
 * stop moving on screen, and withholds <b>nothing else</b>.
 *
 * <h3>What changed, and why it matters in play</h3>
 *
 * <p>Freeze used to drop everything arriving from the match endpoint in a raw
 * byte window of <b>21-450 B</b> that was not family R. It had no notion of a
 * command id. Two consequences, both reported from real matches:</p>
 *
 * <ol>
 *   <li><b>It ate the player's own damage feed.</b> {@code UDP_PLAYER_HURT}
 *       (2010) is 23-27 B; {@code RUDP_TAKE_DAMAGE} (106),
 *       {@code RUDP_SHOW_DAMAGE} (168, the HUD damage numbers),
 *       {@code RUDP_DEAD} (107) and the HP/armour channel
 *       {@code RUDP_VAR_SYNC_PRI_DATA} (1900) are all inside that window. So
 *       while freeze was on, the client was never told about damage the server
 *       had already applied — making <i>"my shots stopped registering"</i>
 *       indistinguishable from <i>"my shots register and I am not shown it"</i>.
 *       Worse, those are reliable messages: the client never acknowledged them,
 *       so the server retransmitted, and each retransmission was dropped again.
 *       This project's own capture tooling already knew — see the
 *       {@code FREEZE_BLINDED} tag in {@code dev/capture/TAGGED_ANALYZER_DESIGN.md},
 *       which excludes such shots from its accuracy denominator.</li>
 *   <li><b>It missed the biggest entity chains.</b> Survival chains reach
 *       ~630 B against the 450 B ceiling, so in a crowded lobby the
 *       entity-rich updates passed straight through while small ones were
 *       dropped — enemies partially un-froze depending on game mode and roster
 *       size. Exactly the mode-specific, roster-sized constant that
 *       {@code PROTOCOL_MASTER.md} §4.1 warns never to write.</li>
 * </ol>
 *
 * <p>A third gate is gone with them. The old voice exemption passed any packet
 * carrying an adjacent {@code 00 00} anywhere in bytes 2..15 — but those are
 * the XOR-masked, per-session-permuted header fields, so whether they line up
 * is a property of the <i>session</i>, not the packet. In a session where they
 * did, an entire command family was exempt for the whole match, which presents
 * as "freeze just didn't work that game". Voice rides other endpoints and is
 * covered by the endpoint gate below; it does not need a byte heuristic.</p>
 *
 * <h3>The rule now</h3>
 *
 * <p>Drop only {@link Cmd#isWorldStateStream} <b>that arrived non-reliable</b>:
 * the player-entity chains plus vehicles, airdrops, bots, the position-only
 * variant and the aim-rotation sync. Everything else passes — damage, deaths,
 * HP, loot, the reliability layer, and every other endpoint.</p>
 *
 * <p><b>The reliability test is on the header, not the command list.</b> This
 * javadoc used to claim "every one is non-reliable, so withholding owes the
 * server no acknowledgement". That was wrong, and the {@code UDP_} name prefix
 * is what made it look right: {@code Cmd 2003 UDP_AIRDROP_STATE_SYNC} arrives
 * reliable-and-encrypted 7 times in
 * {@code captures/dev_20260916/capture_raw_20260916_214646.txt} against 609
 * unreliable. Withholding a reliable message starves its ack and the server
 * retransmits indefinitely — the suspected mid-match kick mechanism. Reading
 * the header instead of a list also keeps this correct if the server starts
 * sending some other id reliably.</p>
 *
 * <p>Identification is by exact command id, with the byte-shape test kept only
 * for the window before the session's header encoding is solved — the same
 * ordering that fixed ghost after it went silently dead when one link in a
 * chain of learned state broke.</p>
 *
 * <p>Outbound is never touched, and freeze is not even wired to the outbound
 * path. Anything describing freeze as withholding the player's own position is
 * describing ghost.</p>
 */
public final class FreezeFilter implements PacketFilter {

    /**
     * Fallback shape window, used ONLY while the command id is unresolved.
     *
     * <p>Not a policy any more — just a coarse pre-filter so the family
     * heuristic is not asked about packets that obviously are not a chain. The
     * ceiling is deliberately well above the ~630 B survival chains that the
     * old 450 B policy window cut off.</p>
     */
    public static final int SHAPE_MIN = 20;
    public static final int SHAPE_MAX = 1400;

    private final DevLogger logger;
    private volatile boolean active = false;

    // ---- dev-panel telemetry (one filter per tunnel) ----
    /** Freeze toggle as the filter itself sees it. */
    public static volatile boolean dbgActive = false;
    /** True when the last decision used the exact command id. */
    public static volatile boolean dbgExact = false;
    /** Inbound packets withheld (world state only). */
    public static final java.util.concurrent.atomic.AtomicLong dbgDropped =
            new java.util.concurrent.atomic.AtomicLong();
    /** Combat/damage messages passed that the old length window would have eaten. */
    public static final java.util.concurrent.atomic.AtomicLong dbgCombatPassed =
            new java.util.concurrent.atomic.AtomicLong();
    /** World-state packets spared because they were RELIABLE (ack-starvation guard). */
    public static final java.util.concurrent.atomic.AtomicLong dbgReliableSpared =
            new java.util.concurrent.atomic.AtomicLong();

    /** One line for the dev panel. */
    public static String debugLine() {
        return (dbgActive ? "ON " : "off")
                + (dbgExact ? " EXACT" : " heur")
                + " drop=" + dbgDropped.get()
                + " dmgthru=" + dbgCombatPassed.get()
                + " rel=" + dbgReliableSpared.get();
    }

    public FreezeFilter(DevLogger logger) {
        this.logger = logger;
    }

    @Override
    public String name() {
        return "freeze";
    }

    @Override
    public boolean isActive() {
        return active;
    }

    /** Freeze is inbound-only; it has never withheld an outbound packet. */
    @Override
    public FilterDecision onOutbound(PacketContext ctx) {
        return FilterDecision.PASS;
    }

    @Override
    public FilterDecision onInbound(PacketContext ctx) {
        if (!active) {
            return FilterDecision.PASS;
        }
        // Server-gated leash: no live profile => don't withhold world state (PASS
        // => the world keeps flowing, i.e. no freeze). R8-stripped while off.
        if (com.nuvola.app.net.NativeBridge.DECODE_LEASH
                && !com.nuvola.app.auth.ConfigStore.decodeArmed(System.currentTimeMillis() / 1000L)) {
            com.nuvola.app.diag.Diag.hit(com.nuvola.app.diag.Slot.ESP_LEASH_CLOSED);
            return FilterDecision.PASS;
        }
        // Only the tracked match server's stream. Voice and every other
        // server always pass, even while freeze is on. (Inbound contexts
        // carry the REMOTE address in dip/sp — see UdpSessionManager.)
        if (!GamePacketTaxonomy.isFromMatchServer(ctx.dip, ctx.sp)) {
            return FilterDecision.PASS;
        }

        boolean exact = ctx.hasCmd();
        dbgActive = true;
        dbgExact = exact;

        if (exact) {
            // The transport layer is never droppable: starving acks, pings and
            // fragment reassembly trips the client's disconnect flags.
            if (Cmd.isTransportLayer(ctx.cmd)) {
                return FilterDecision.PASS;
            }
            if (!Cmd.isWorldStateStream(ctx.cmd)) {
                // Damage, deaths, HP, loot, everything else: the player must
                // keep being told. This is the whole point of the change.
                if (Cmd.isCombatFeedback(ctx.cmd)) {
                    dbgCombatPassed.incrementAndGet();
                }
                return FilterDecision.PASS;
            }
            // NEVER withhold a RELIABLE message, whatever its command id.
            //
            // The javadoc above used to promise that every isWorldStateStream
            // command is non-reliable, "so withholding owes the server no
            // acknowledgement". That was false, and the UDP_ name prefix is
            // what made it look true. Measured in
            // captures/dev_20260916/capture_raw_20260916_214646.txt:
            // Cmd 2003 UDP_AIRDROP_STATE_SYNC arrives RELIABLE (flags=0x5F,
            // reliable+encrypted) 7 times against 609 unreliable.
            //
            // Withholding one is the ack-starvation kick mechanism: the client
            // cannot acknowledge what it never received, the server
            // retransmits, and this filter drops every retransmission. It only
            // escaped notice because the freeze windows in that capture total
            // 12 s out of 925 s. At the measured 0.0076/s reliable-2003 rate a
            // 30 s freeze has a ~20% chance of hitting one, and 5 minutes is
            // near-certain -- exactly the "rarely, and I don't know why"
            // failure shape.
            //
            // This is a property of the header, not of a command list, so it
            // stays correct when the server starts sending some other id
            // reliably.
            if (ctx.isReliable()) {
                com.nuvola.app.diag.Diag.hit(
                        com.nuvola.app.diag.Slot.FREEZE_RELIABLE_SPARED);
                dbgReliableSpared.incrementAndGet();
                return FilterDecision.PASS;
            }
        } else {
            // Header encoding not solved yet (the first few hundred packets of
            // a session, and again after a match transition rotates the key).
            // Fall back to the shape test, which is the same one the ESP uses
            // to recognise a chain, plus the family-R exemption.
            //
            // THIS PATH IS WEAKER THAN IT LOOKS, AND IT IS NOW LOUD.
            // Measured over every capture from 2026-09-16 (1.19M inbound
            // packets, 222 freeze toggles): it fired ZERO times on the match
            // stream, because every match-server packet was resolved. All
            // 545k unresolved packets came from other endpoints, which the
            // isFromMatchServer gate above already passes.
            //
            // So it is untested in production AND it is wrong: replaying
            // looksLikeEntityChain over the 157 packets freeze actually
            // dropped matches 2001 and 2012 but MISSES 100% of Cmd 2002
            // (vehicle state sync) -- 33 of 157, 21%. Their b8/b9 are 0x02/0x28
            // and 0x04/0x21, not the 0x00/even the test demands. If the solver
            // ever fails mid-match, vehicles keep moving while players stop.
            //
            // Not widened by guesswork: a length rule for 2002 would be exactly
            // the mode-specific, roster-sized constant PROTOCOL_MASTER.md
            // forbids. Instrumented instead, so the DIAG block says plainly
            // that freeze is running degraded rather than looking healthy.
            com.nuvola.app.diag.Diag.hit(
                    com.nuvola.app.diag.Slot.FREEZE_SHAPE_FALLBACK);
            if (!GamePacketTaxonomy.isMatchStreamLive(System.currentTimeMillis())) {
                return FilterDecision.PASS;
            }
            if (ctx.plen < SHAPE_MIN || ctx.plen > SHAPE_MAX) {
                return FilterDecision.PASS;
            }
            if (GamePacketTaxonomy.family(ctx.buf, ctx.off, ctx.plen)
                    == GamePacketTaxonomy.FAMILY_R) {
                return FilterDecision.PASS;
            }
            if (!looksLikeEntityChain(ctx)) {
                com.nuvola.app.diag.Diag.hit(
                        com.nuvola.app.diag.Slot.FREEZE_SHAPE_UNMATCHED);
                return FilterDecision.PASS;
            }
        }

        logger.logPacket("BLOCK_FREEZE", "IN", ctx.buf, ctx.off, ctx.plen,
                ctx.sp, ctx.dp, ctx.dip,
                exact ? "freeze=true cmd="
                                + com.nuvola.app.decode.body.CmdCatalogue.describe(ctx.cmd)
                        : "freeze=true shape");
        dbgDropped.incrementAndGet();
        return FilterDecision.DROP;
    }

    /**
     * Entity-chain shape test for the pre-solver window: {@code b8 == 0x00} and
     * {@code b9} a non-zero even record count. Both bytes sit OUTSIDE the
     * masked b2-b7 header window, which is cyclically permuted per session —
     * identifying this family from b2/b3 is what silently killed the tracker in
     * a previous session and must not be reintroduced.
     */
    private static boolean looksLikeEntityChain(PacketContext ctx) {
        int off = ctx.off;
        if (off + 10 > ctx.buf.length) return false;
        if ((ctx.buf[off + 8] & 0xff) != 0x00) return false;
        int b9 = ctx.buf[off + 9] & 0xff;
        return b9 >= 2 && (b9 & 1) == 0;
    }

    @Override
    public void start() {
        active = true;
        dbgActive = true;
        dbgDropped.set(0);
        dbgCombatPassed.set(0);
        logger.logControl("MODE_FREEZE_ON", "mode=freeze");
    }

    @Override
    public void stop() {
        active = false;
        dbgActive = false;
        logger.logControl("MODE_FREEZE_OFF", "mode=freeze");
    }

    @Override
    public void shutdown() {
        active = false;
        dbgActive = false;
    }
}
