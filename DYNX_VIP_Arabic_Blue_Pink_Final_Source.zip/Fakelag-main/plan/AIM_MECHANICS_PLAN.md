# Aim mechanics plan — signal-button trigger, still-target swipe, scope-aware FOV, freeze-locked ESP

**Status: PLANNING — no implementation. Research-integrated revision 2**
(2026-09-19): four research passes (`plan/research/`) are cited throughout,
question numbering (§6) is now the single source of truth and every in-text
reference resolves to it, and §11 is a **research ledger** — what is already
ANSWERED, what is measurable on-device, and what genuinely still needs
research, so future sessions do not re-search settled ground.
**Written 2026-09-19**, after the touch-coexistence commit (`43ad2c2`) and a
verified end-to-end build of everything it shipped.

Companion reading: `docs/SESSION_2026_09_18_touch_coexistence.md` (how the
daemon works today), `docs/GAME_CLIENT_CONSTANTS.md` (the swipe math, measured
from the binary), `docs/DUAL_TOUCH_INJECTION.md` (why coexistence needs nvmux),
`docs/AIM_PLAN.md` (the OLD aim plan — superseded in mechanism, still the best
detection-surface discussion §4/§7).

**Boundary, stated first (hard rule 7):** this plan is input-side only — it
moves the player's own crosshair through a real (well, virtual-but-kernel-real)
touch device. It does not touch packet content, does not forge hits, and the
deleted Cmd-106 `AimFilter` stays deleted. Where the plan says "the shot
registers", that is the game's own hit registration doing whatever it does; we
only ever aim.

---

## 0. TL;DR

1. **The thesis: aim only where the box IS, and only when the box is not
   moving.** ESP's position for a *still* target is essentially perfect (no
   dead-reckoning error, no lead). For a *moving* target it is an extrapolation
   with measured RMS error that grows every tick — and the swipe itself takes
   100–200 ms during which a runner moves metres. Tracking a running target
   over that chain is latency-loss, not an engineering gap. So the aim is
   **one-shot, open-loop, still-targets-only**.
2. **Freeze is the force multiplier, and it must agree with ESP.** Freeze
   withholds inbound world state, so the *game* holds enemies at their frozen
   pose — but ESP is fed **before** the freeze filter drops the packet, so ESP
   keeps tracking the live enemy. ESP box and frozen model disagree by exactly
   the distance the enemy travelled since the drop. A still-locked ESP while
   freeze is on (F5) is what makes "freeze + sniper = headshot" true — and
   hold-hard is PROVEN safe (enemy world state never arrives reliable;
   research A).
3. **The scope problem split in two — and half of it is already solved.**
   *When* the player is scoped is **on the wire, proven**: the client
   volunteers `RUDP_START_SNIPER=137` / `RUDP_STOP_SNIPER=138` outbound,
   perfectly paired, 100% reliable, ~90 events/match across six captures —
   a cmd-id latcher replaces screen recognition for the on/off gate. *What
   the scoped FOV is* remains unmeasured anywhere (public research: no
   measured magnification exists, and the binary has no scope→FOV path — the
   AnimationClip asset theory stands), so P0 measurement is still the only
   path to the truth values. ESP has no scoped-FOV model, so projection is
   wrong under any scope until F4 lands.
4. **The signal fire button needs no interception at all.** `nvmux` already
   reads every real touch (it holds the panel). The app tells the daemon the
   circle's rect; a real contact landing inside it *is* the fire press. The
   button stays fully press-through because it never needs to see the touch.
   A wire-based fire signal (`FIRING_STATUS`, varId 21, wire-confirmed)
   exists as the no-grab fallback.
5. **Everything routes through the daemon that already works.** The swipe
   becomes a delta/target command over the same stdin pipe (`S/P/U/Q`,
   plus a new move command); the geometry already exists in
   `nuvola-core::geom` (`screen_offset_to_yaw_pitch_deg` was written for
   exactly this and is tested).

---

## 1. Verified context — how it works today

### 1.1 Touch: how a synthetic swipe reaches the game

Proven in a live match (2026-09-18), all of it committed:

- `nvmux` (Rust bin crate `native/touchmux` → shipped as `libnvmux.so`) is
  spawned by `AimInjector` via `Shizuku.newProcess` (shell uid 2000, no root)
  and driven over **stdin**: `S <cx> <cy> <r> <w> <h>` start, `P` heartbeat
  (~400 ms; the daemon's lease is ~1.5 s), `U` stop, `Q` quit. The line
  parser (`parse_line`) accepts one command byte + up to five integer args —
  a new move command slots straight in.
- While armed it **`EVIOCGRAB`s the real panel** and re-emits *both* the user's
  contacts *and* one synthetic contact through a single `/dev/uinput` clone
  carrying the panel's identity. Android sees one device, many pointers —
  nothing cancels. Walk + aim coexist.
- The daemon **self-drives the swipe circle** (16 ms tick, `STEP_RAD` 0.30 rad,
  `nuvola_core::geom`), so Java sends one `S` and heartbeats; there is no
  per-event binder traffic.
- It sees **every real touch event** in `drain_real()` while grabbed, and it
  already classifies contacts per slot (`forward()`, `grab_resync()` via
  `EVIOCGMTSLOTS`). *This is the raw material for fire-press detection (F1).*
- Safety rails that must survive any extension: heartbeat lease, Volume-Down
  escape (different device), release on every exit path + signals + stdin-EOF.
  A grabbed panel is a single point of failure for ALL touch — any new armed
  state inherits this.

### 1.2 The swipe math that exists today

All measured from the decrypted binary, in `docs/GAME_CLIENT_CONSTANTS.md` §3:

- **px per degree (hip):** `px_per_deg = 300 / (15 + 20·sens)`, sens 0..1.
  At the shipped `GAME SENS` 75 → **10.0 px/deg**. DPI-independent (base term);
  the *acceleration* term is DPI-scaled. **Staleness warning (research B):**
  Free Fire's sensitivity UI moved to a **0–200 scale (~OB53/OB54, June 2026)**
  with **six per-scope sliders** (General/RedDot/2x/4x/Sniper/FreeLook); the
  15/35 LO/HI above are the binary's compiled *fallbacks* and the CSV may have
  moved. Re-verify with the 360°-calibration probe (§9) before trusting.
- **Scoped:** rotation is multiplied by **0.2 × per-attachment factor**
  (datatable `GetWeaponSightingAttachmentData`), and per-scope sensitivities
  are separate stored values (8-way jump table). So the swipe gain under scope
  is a different number per scope — and public sources have **no measured
  value for any of them** (research B: every "8x" guide repeats the label
  verbatim; zero datamined or measured magnification exists publicly).
  P0 measures it; nothing to look up.
- **The acceleration term is a controller bug we must respect:** effective
  sensitivity grows with distance from the touch-down point (~3.4× at 300 px on
  a 400 dpi panel). The old aim shipped `MAX TRAVEL = 100 px` with a re-grip.
  Any real-aim motion profile needs the same discipline or it overshoots and
  blames its own gain.
- **Aim assist is friction, not snap:** assist multiplies our rotation *down*
  near a target; there is no cone and nothing closes the error for us. The old
  25 px deadzone premised on "hand off to the cone" was wrong and was corrected
  to 6 px / gain 12. Consequence for the plan: **we must deliver the full
  delta ourselves**, and the last pixels may cost extra — an overshoot/settle
  budget question (Q15).
- **FPP firing damp:** while firing in FPP, yaw is multiplied by
  `GetFPPFiringDampRadio` — our swipe happens exactly while the trigger is
  held, i.e. exactly when the game fights us. Unmeasured (P0).
- `geom::ViewProjection::new(fov_x_deg, w, h, fov_y_scale, zoom)` +
  `.yaw_pitch_from_offset(dx, dy, w, h)` returns the yaw/pitch error in degrees
  from a screen offset — the missing half is only
  `px = deg × px_per_deg_effective`. **Rewritten 2026-09-19**: the old
  5-arg form took `fov_x_deg` literally, dropped `FOV_Y_SCALE` and had no zoom
  term, so it disagreed with `EspRenderView` by 0.5–4.0° and could not express a
  scope at all. Now parity-tested against ESP's own projection over 240 cases.

### 1.3 What ESP gives the aim

- `EspEngine` snapshot → `EspRenderView` at 120 Hz (Choreographer). Boxes are
  projected from feet (`ground`) and head (`ground + boxHUnits`, ~1.8 m); the
  **pose ray** (`SHOW_POSE`, `AIM_RAY_M`) draws an enemy aim ray from a head
  defined at `0.92 × BOX_H_M` — note there are **two different "head"
  definitions** already in the renderer (box-top vs 0.92) — which one the aim
  uses is a decision (Q6).
- Velocity is real wire data (v8–v10) plus finite-difference folding; the
  renderer dead-reckons positions forward between ~10 Hz updates (Cmd 2001 is
  throttled server-side to ~10 Hz).
- Team colouring is **server-published team byte only** (hard rule 1) — the
  aim's target selection must reuse the same friend/foe ladder, never geometry.

### 1.4 ESP's problems that constrain the aim

| # | problem | evidence | consequence for aim |
|---|---|---|---|
| P1 | **Freeze disagreement**: ESP sees live positions during freeze | `UdpSessionManager` feeds ESP (lines 375–401) *before* `filterEngine.onInbound` DROP (line 425) | the aim would swipe at a live box while the world shows a frozen model — must be fixed first (F5) |
| P2 | **Dead reckoning error on movers**: measured RMS 0.573 (one tick), 0.622 (two), 0.679 (three) — the "sometimes ahead, sometimes behind" symptom | `EspRenderView` comments; `EspEngine` extrapolation | moving targets are unusable → still-only policy (F6) |
| P3 | **Camera angular extrapolation**: own view basis is led during turns (`extrapolatedDir`) | `EspEngine` 2546+ | a swipe while turning fights a moving projection — compute the delta once, at trigger time, open-loop |
| P4 | **Mounted: no camera on the wire** (invariant 10) — vehicle heading wrong by free-look angle | `MOUNTED_ESP_FIX.md` | aim disabled while own/target mounted |
| P5 | **CS-mode ESP failure** exists | `CS_MODE_ESP_FAILURE.md` | aim must be gated where ESP is gated |
| P6 | **Viewport / density traps**: overlay must span the true display; this device's density override is 398, not 480 | invariant 5; CLAUDE.md | every px placement (signal circle, swipe zone) measured on device, never hand-computed |
| P7 | **No scoped-FOV model**; 8x visibly magnifies (owner report) but the binary has no scope→FOV path → AnimationClip asset data is the remaining explanation | `GAME_CLIENT_CONSTANTS.md` §1 caveat | F4 — the scope problem; the on/off half is solved (wire), the FOV value needs P0 |
| P8 | **`poseValid` lesson**: a frozen-but-valid flag is indistinguishable from working | CLAUDE.md / invariants | aim gating uses timestamps + freshness, never booleans |
| P9 | **Reliable world state is spared by freeze** (`FREEZE_RELIABLE_SPARED`) — some world state keeps flowing during freeze | `FreezeFilter`; **researched (A)**: enemy world-state (2001/2012/2002) arrived reliable **0 times** in ~40k packets/6 sessions; only 2003/airdrops ever do (0.8–2.1%), and those are world objects | RESOLVED: spared packets cannot move a frozen enemy — hold-hard is exact (F5) |

### 1.5 What the old aim knew, and what was deleted

The head-targeting aim (ring lag-compensator, FOV cone, calibrator, ~30 knobs)
was deleted when the coexistence problem was solved; the *knowledge* survives
in `GAME_CLIENT_CONSTANTS.md` §3/§4 (px/deg, max-travel, friction-not-snap,
deadzone correction). The new aim is a different shape — one-shot swipe, not a
tracking controller — so most knobs do not come back; but the measured
constants do (P0 re-measures them scoped). Orphaned `Prefs.KEY_AIM_*` strings
are kept on purpose (hard rule 5) — several (`aim_fov_deg`,
`aim_game_sensitivity`, `aim_max_travel_px`, `aim_swipe_px_per_deg`) are
semantically right for the new aim and can be **reused verbatim** as new
settings bind to them.

### 1.6 The detection-surface boundary

`AIM_PLAN.md` §4/§7 remains the reference: injected/uinput touch is visible to
device enumeration, and shaping (randomised human-like swipes) is an owner
decision, not an engineering one. Everything here adds *armed time* on the
grab (F1 requires it — see Q5) — that is a real risk increase to state
plainly. The researched specifics (pressure axes, timing statistics, the
unfixable enumeration exposure, TEE-anchored bans) are in §5 and
`plan/research/RESEARCH_SWIPE_SHAPING_DETECTION.md`.

---

## 2. The thesis, expanded: why still-targets-only

The owner's intuition, made explicit with the numbers:

1. ESP updates arrive ~10 Hz; the render loop is 120 Hz; dead reckoning fills
   the gap with measured RMS error 0.57 → 0.68 over three ticks (P2).
2. The swipe takes 100–200 ms (acquire → compute → move → settle). A runner at
   5 m/s covers 0.5–1.0 m in that window — at 150 m and hFOV ~103° that is
   several degrees, i.e. *the target outruns the correction*.
3. Closed-loop tracking makes it worse, not better (P3): while the swipe turns
   the camera, the box's screen position moves *because of the swipe* — a
   tracker chases a projection it is itself moving. This is the deep reason
   "track the running ESP" fails, beyond raw latency.
4. A **still** target has zero dead-reckoning error and a one-shot open-loop
   swipe computed at trigger time is *exact* — the only errors left are the
   px/deg conversion and the projection FOV, both measurable (P0).
5. A **freeze-locked** target is still *by construction* — the strongest form
   of the policy, which is why freeze + sniper is the flagship scenario.

Corollary: the aim is a **single corrective swipe per trigger**, not a
controller. Re-aim decisions happen between shots, not during the swipe.

---

## 3. The feature set (owner's ideas, expanded)

> Question numbers below refer to §6, which is the single authoritative list.

### F1 — Signal fire button (the press-through circle)

**Intent:** the user drags a circle onto the game's Fire button. It never
intercepts, never blocks, never animates presses; it is *labelled intent* +
geometry. When a real fire press lands inside it and an acquisition exists,
the aim swipes.

**Shape (proposed):** an `OverlayButton` (existing drag/touch infra in
`ui/button/`) rendered as a hollow circle, stored as a px rect. Detection
*not* by the overlay window but by the daemon: the app sends the rect to
`nvmux`; while grabbed, the daemon matches a real contact-down inside the rect
and reports it back on stdout (the `drainStdout` reader already consumes
daemon lines; a parsed line protocol back to Java is a small extension).
Touch-slop: a down within the rect inflated by ~8 px counts (drag slop),
pending on-device feel.

**Why daemon-side detection:** the overlay is (and must stay) press-through —
Android gives a non-touchable window no events. The daemon already holds the
only complete copy of real touch. It also keeps detection alive while the
game is fullscreen (overlay buttons never appear in uiautomator dumps —
`FLAG_NOT_FOCUSABLE` — so debugging stays possible).

**A wire-based fire trigger exists too (research A):** **Cmd 1900 varId 21
`FIRING_STATUS` {0,1,2} is wire-confirmed (n=2159)** and flows through
already-decoded code on our own outbound stream — observed locally at send
time, no round trip. Tradeoff against daemon touch-region detection: the
wire path needs no grab and no armed state, but is sampled at the 1900
cadence (assumed ~10 Hz → up to ~100 ms late; **the 1900/varId-21 cadence is
itself a P0 measurement**, §9). The daemon path is instant but requires the
grab (Q5). A sensible ladder: daemon-region when armed, wire FIRING_STATUS as
the always-on fallback/cross-check — the signal-button premise ("press-
through, detection without interception") holds either way.

**Open questions:** Q5 (arming = grab acceptable, given the wire fallback
exists), Q7 (trigger semantics: tap vs hold), Q9 (how many signal buttons —
scope signal later?).

**Fallback ladder (simplest first):** v0 = the existing manual Aim toggle
(already shipped) → v1 = daemon-region detection → (never) an intercepting
button, which the owner explicitly does not want.

### F2 — Acquisition: editable FOV cone, range, and target rules

**Intent (the owner's "Edit FOV of fitting"):** a configurable acquisition
cone around the crosshair — a target is eligible only inside it — plus a max
engagement distance, plus the eligibility rules below. Likely per-scope
presets later (a hip cone ≠ an 8x cone, which in screen terms is *narrower* in
degrees but *larger* in px — coupling to F4 again).

**Eligibility rules (proposed):** alive (see the F5 design note: death/damage
messages keep flowing during freeze, so "alive" stays current even while
positions are held); enemy by server team byte (hard rule 1); pose fresh by
timestamp (P8); not mounted (P4); not in a mode where ESP is broken (P5);
inside cone; inside range; tie-break nearest-to-crosshair by *angular*
distance, not screen distance (screen distance lies under scope — Q16).

**Proposed defaults (owner-tunable, P0-verified):** hip cone half-angle
±10°, scoped per tier from the measured hFOV (an 8x cone is a few degrees);
range default 200 m for snipers, 80 m otherwise; both become per-scope
preset entries once F4 lands (Q17).

**Open questions:** Q17 (cone/range defaults + per-scope presets + whether
the cone auto-shrinks on scope), Q16 (tie-break), and whether "in range"
uses wire-metres distance (we have it) or angular size (which is what
actually matters to a sniper) — folded into Q17.

### F3 — The swipe: configurable zones, motion profile, one-shot math

**Intent (the owner's "configure where it swipes"):** the swipe must not
traverse buttons or land where the user's fingers live. Start point, allowed
region, and max travel are settings.

**Shape (proposed):** extend the stdin protocol with a move command —
either `T <dx_px> <dy_px>` (delta swipe) or a target-point form. The **motion
profile lives in the daemon** (16 ms tick already exists): plant synthetic
finger at the configured start point, advance in steps toward the computed
delta, re-grip if travel exceeds the max (acceleration term, §1.2), settle,
lift. Java computes degrees→px once at trigger; the daemon executes. All
coordinates stay normalised 0..65535 per axis (the existing `geom` discipline)
so other panels keep working.

**The math at trigger (one-shot, open-loop):**

```
error_deg(yaw,pitch) = geom::screen_offset_to_yaw_pitch_deg(headPx - crosshairPx, w, h, FOV_effective)
delta_px             = error_deg × px_per_deg_effective   // hip: 10 @ sens 75; scoped: 0.2 × factor × sens_scope (P0)
profile              = step the delta under MAX-TRAVEL re-grip; settle; lift
```

`FOV_effective` is the *scoped* FOV when scoped (F4) — get it wrong and the
swipe is wrong even with a perfect px/deg. The two corrections are coupled and
must be measured together per scope.

**Open questions:** Q8 (abort decision in daemon vs Java round-trip), Q15
(overshoot budget vs assist friction), Q10 (swipe shaping — owner call,
detection), Q11 (per-weapon swipe caps), Q9 (zone controls: start point +
radius + max travel, or a free rect?).

**Motion profile (research D's recommendation, adopted as the design
target):** a one-shot **min-jerk swipe** — quintic timing
`s(τ) = 10τ³ − 15τ⁴ + 6τ⁵` along a gently curved arc (**3–6% longer than the
chord**; measured human arcs ≈ 4.8%), damped 5–12 Hz tremor at 1–3 px,
**100–200 ms log-normal** durations for 100–300 px, ~10–20% chance of a small
overshoot with correction back. Events emit **only on change, at the real
panel's measured cadence**, with log-normal interval jitter (σ_log ≈ 0.2–0.35)
and ~5–10% skipped frames; variable event count; endpoint scatter ±3–8 px
with 1–2 settle micro-moves before lift. Per-swipe randomised: duration,
curvature sign/magnitude, tremor seed, offsets, overshoot, speed scale ±15%.
**And one structural fix this exposes:** the synthetic finger currently emits
NO pressure/size values (`synth_set` writes only X/Y/TRACKING_ID) while real
Samsung touches carry `ABS_MT_TOUCH_MAJOR/MINOR/PRESSURE` every frame — the
single highest-separation detector feature in published work. The daemon
extension must interpolate pressure/size per frame from the owner's own
`getevent` distributions (target CV ≈ 0.2). Full reasoning and sources:
`plan/research/RESEARCH_SWIPE_SHAPING_DETECTION.md`.

### F4 — Scope awareness (the 8x fix)

**Problem restated:** ESP's projection has no scoped mode; 8x visibly
magnifies on screen; the binary proves the code never changes camera FOV — so
the magnification is asset data (an AnimationClip on `field of view`), which
is also why nobody has the number. **Public research (B) confirms the
negative hard:** no public source states FF's FOV in *any* scope state; every
"2x/4x/8x" guide repeats the nominal label with no measurement behind it. The
only artifacts are garbled unverified cheat-config PDFs — worth recording as
*hypotheses to test, never to trust*: `DEFAULT_FOV=153`, per-gun `AIMFOV`
flags, `SENSITIVITY_MULTIPLIER LOW ZOOM=0.75 / HIGH ZOOM=0.65`, and
`AIM_SENSITIVITY_TRANSITION_TIME=GRADUAL`. That last one matters most: if ADS
*lerps* (camera or sensitivity) over a transition window, then the scoped
correction needs a **transition timestamp, not a boolean** — the
frozen-but-valid trap again (P8): "scoped" that is mid-lerp is neither hip nor
scoped.

**Weapons context (research B):** AWM/Kar98k/M24 ship 8x pre-attached
(swappable); SKS/SVD/AC80 are fixed 4x; VSS integrated (mag unsourced).
**No breath/sway on FF snipers** — sniping is straight-line point-and-shoot,
so the swipe has no sway term. AWM headshots ×2.5 and one-shot any helmet →
**AWM + freeze is the flagship scenario** and the head-pose accuracy bar is
set by it. The **"Hold Fire to Scope"** game setting reorders fire/scope
startup — it changes what state the world is in on the fire press, so it
belongs in trigger semantics (Q7, Q20).

**Options, re-ranked after the wire survey (research A):**

- **O3 — Wire-observed scope state: ANSWERED, and now SHIPPED
  (2026-09-19).** Implemented as `protocol/ScopeState.java`, fed one line from
  `tunnel/PacketLoop.java` inside the existing CRC-valid outbound branch, with
  `Cmd.RUDP_START_SNIPER`/`RUDP_STOP_SNIPER` named and `Slot.SCOPE_IN`/
  `SCOPE_OUT`/`SCOPE_PAIR_DESYNC` for the diag block. It exposes `isScoped()`
  **plus** `sinceEdgeMs()`/`hasEverSeenEdge()` — because the outbound cmd id is
  unresolved until the header solver converges and **the solver collapses on
  every match/room key rotation**, so a bare latched boolean would read "hip"
  through the blind window and look identical to working (the `poseValid`
  trap). It self-clears on `SessionTimeline.matchSeq()` change. Live on the
  `SCOPE` row of the dev readout. Evidence below:
  `RUDP_START_SNIPER=137` / `RUDP_STOP_SNIPER=138`, outbound-only, 26-byte
  empty bodies, perfectly paired, **100% reliable** (45/45, 60/60, 19/19,
  25/25, 91/91, 2/2 across six captures; sender class = the Weapon class per
  the deobf map; the server even runs FOR_CLIENT_REPLAY inbound handlers).
  A cmd-id latcher on the outbound path arms the scoped model with zero new
  decoding, zero permissions, zero capture. For *which* tier (2x/4x/8x):
  **Cmd 1900 varId 12 `EPRI_PLAYER_SIGHTING_ID`** is already decoded
  end-to-end — `PriSync.decode` delivers it and `PriTracker.onProperty`
  currently discards it (PriTracker.java:206-244); it needs a *reader*, not a
  decoder. Settling measurement (§9): does 137 fire for non-sniper ADS
  (red dot), and does varId 12 distinguish tiers on scope-in — one
  Training-Ground session.
- **O1 — Manual scope selector.** Overlay chips (hip / 2x / 4x / 8x) or a
  single toggle; ESP FOV override + swipe gain override per scope. Stays the
  v0 delivery vehicle and the fallback if the wire gate surprises; the FOV
  *number* still has to come from somewhere (O2/P0).
- **O2 — Extract the scoped FOV from the APK assets.** The AnimationClip
  lives in Unity bundles; the same "bridge by name" discipline as the il2cpp
  work applies. This is now the only path to the truth number besides P0
  measurement — pursue whichever is cheaper first.
- **O4 — Screen-capture recognition (the owner's model idea): demoted to
  fallback/cross-check.** Researched
  (`plan/research/RESEARCH_SCOPE_RECOGNITION_CV.md`, ~60 sources): far cheaper
  than assumed — **`AccessibilityService.takeScreenshot` at 1 Hz** (API 30+;
  our device is 34) + a **~50-pixel ring heuristic** on a centre ROI decides
  "scoped" in microseconds, **no OpenCV, no ML, zero allocations per check**;
  tier via per-tier ring colour/radius clusters. No consent dialog, no cast
  icon (unlike `MediaProjection`, which stays the upgrade path with a 270×608
  VirtualDisplay that Android 12L+ downscales for free). But O3 makes it
  unnecessary for the gate — its remaining value is *independent
  cross-validation* (wire says scoped; does the screen agree?) and as a
  backup if 137 turns out to be sniper-only.

**Recommendation (plan-level, updated by research A):** the arming gate is
**O3's 137/138 latcher + the varId-12 reader** — both already flow through
decoded code paths. P0 still measures the scoped FOV truth per scope (the
number exists nowhere public — research B), delivered via O1's selector as
the manual override. O4 is the optional cross-check/backup, an owner call
(Q4).

**Why F4 is blocking for scoped aim (research B):** under a true 8x, the
screen spans ~6–9° hFOV and px/degree scales ~8× — an ESP box projected with
the unscoped FOV lands off-screen by up to 8 screen-widths. Scoped aim before
F4 is not "inaccurate", it is meaningless.

**Open questions:** Q1 (which scopes matter), Q2 (manual arming still wanted
as fallback?), Q3 (does scoped magnification feel like camera zoom? confirms
the AnimationClip theory before asset-digging), Q4 (is the O4 a11y-capture
cross-check wanted at all?).

### F5 — Freeze-locked ESP (the enablement fix)

**Intent (owner's words):** "when freeze is on, ESP should stop at the frozen
enemy position states instead of updating; when freeze is off it should update
like normal."

**Root cause (verified):** ESP is fed before the freeze DROP
(`UdpSessionManager` 375–401 vs 425). The game sees frozen enemies; ESP sees
live ones.

**Shape (proposed, respecting house rules):** when Freeze is active, stop
*applying* world-state position updates to enemy tracks (the same
`isWorldStateStream` + reliability gate as the filter, so ESP and the game
agree exactly). Render the **held** pose. Prefer a new field/flag over
re-pointing existing readers (house rule); use timestamps, not booleans (P8):
`frozenAtMs` + `frozenPose`, cleared the moment freeze turns off, at which
point the live pipeline resumes untouched.

**Design note — deaths during freeze (was a question; settled by
FreezeFilter's own documented design):** FreezeFilter deliberately passes all
combat feedback (damage 2010/106/168, deaths 107, HP 1900) and the roster
kill feed (139) flows regardless — only the world-state *position* streams
are withheld. So while positions are held, "alive vs dead" stays current:
the held-pose eligibility must exclude enemies the death/kill feed marked
dead, and the frozen corpse pose is a known-stale case to drop from
acquisition. No exception path is needed — this is a rendering/eligibility
rule, not a data problem.

**Why this unlocks everything:** a frozen target is still by construction →
F6's gating is trivially satisfied → the one-shot swipe is exact → "freeze +
sniper = headshot" becomes mechanically true instead of accidental.

**Hold-hard vs hold-soft: ANSWERED — hold HARD (research A).** ~40k inbound
world-state packets across six sessions: **2001/2012/2002 never arrived
reliable — zero instances.** The only world-state command that ever arrives
reliable is 2003 (airdrops, 0.8–2.1% of its traffic, 1–18/match) — world
objects, not enemies. So FreezeFilter's spare-reliable rule cannot move a
frozen enemy: the held pose is exact, and the filter stays untouched.
(Method validated: the survey reproduced FreezeFilter's "7 reliable vs 609
unreliable" 2003 claim exactly — total 616, rel 7 — before trusting the
counts elsewhere.)

**Open questions:** Q12 (freeze-lock automatic whenever freeze is on, or an
independent toggle?), Q13 (on unfreeze: snap to live immediately, or hold +
fade for N ms?).

### F6 — Still-target gating

**Intent:** the aim fires only when the chosen target's pose is stable, and
aborts if that changes mid-swipe.

**Shape (proposed):** eligibility requires |velocity| below a threshold for N
consecutive samples (wire velocity v8–v10 exists; threshold and window are
tuning, measured in P0). Abort-on-move: if the target's velocity or position
jumps beyond a bound while the swipe is executing, the daemon lifts early
(abort must be daemon-side to be fast — Q8). Freeze-locked targets pass the
gate by construction (F5).

**Own-camera quiet rule (proposed, from P3):** swiping while already turning
corrupts the open-loop math — cheapest rule: only trigger when our own
angular velocity ≈ 0 for the last ~100 ms.

**Open questions:** Q14 (still-threshold: standing-still only, or slow-walk
eligible at a tighter gate?), Q8 (abort placement).

---

## 4. The interaction model (fire × freeze × scope × aim)

| freeze | scope | target state | aim behaviour |
|---|---|---|---|
| off | hip | still | one-shot swipe to head; gate = velocity threshold |
| off | scoped | still | same, with scoped FOV + scoped gain (F4/P0) |
| **on** | any | frozen (held, hard) | flagship: exact one-shot at the held pose; spared reliable packets cannot move enemies (proven, A) |
| any | any | moving | **never aims** (thesis) |
| any | any | dead (death/kill feed, keeps flowing during freeze) | never eligible (F5 design note) |
| any | any | teammate (team byte) | never eligible (hard rule 1) |
| any | any | mounted / CS-mode / pose stale | never eligible (P4/P5/P8) |
| any | any | our camera turning | gate blocks until quiet (F6) |

Failure posture everywhere: no acquisition, no gate, no daemon, no heartbeat →
**no-op, loudly** (`Diag.hit(Slot.AIM2_*)` — never `DevLogger`), the same
bail-discipline as everything else in this codebase.

---

## 5. Safety, fail-safes, detection surface

- The grab remains a single point of failure; F1 requires grab while armed
  (Q5) unless the wire FIRING_STATUS path is chosen as primary. Lease/
  Volume-Down/exit-path rails are non-negotiable and must be re-verified
  after any protocol extension.
- New armed states must fail *closed* for touch (release) and *open* for
  features (aim no-ops) — the daemon's existing semantics.
- **Detection surface, researched** (`plan/research/RESEARCH_SWIPE_SHAPING_DETECTION.md`).
  The three exposures of the *current* design, ranked:
  1. **Missing pressure/size axes (cheap to fix).** Samsung touch drivers emit
     `ABS_MT_TOUCH_MAJOR/MINOR` + `ABS_MT_PRESSURE` on real touches; our
     synthetic finger emits none → constant/zero `MotionEvent` pressure+size.
     Contact area is the single highest-separation human/automation feature in
     published detector work, and an injected-touch heuristic documents
     "area 0 on Samsung/LG" verbatim.
  2. **Machine-like timing.** Fixed 16 ms tick + fixed-radius circle →
     inter-event std/mean ≈ 0 (human ≈ 0.25–0.45; bot threshold cited < 0.05)
     and swipe-speed CV ≈ 0 (human ≈ 0.51). Any real-aim profile must emit
     only-on-change at the panel's own cadence with log-normal jitter.
  3. **Device enumeration (unfixable by shaping).** The clone is a second
     `/dev/input` node → a second `InputDevice` with the panel's name; the
     name-count/descriptor check is trivial via public API, and `EventHub`
     nonce-forces a different descriptor for identical identity. `EVIOCGRAB`
     itself is invisible to the in-game sandbox (SELinux blocks
     `/dev/input` for untrusted_app) but plainly visible in shell/bugreport
     forensics.
  **Honest statement:** shaping removes *statistical* fingerprints only. It
  cannot hide enumeration, the grab's forensic footprint, server-side
  classification of aim behaviour, or TEE-anchored device bans (public work
  documents ACE binding bans to the Widevine `deviceUniqueId`; Garena bans
  device+account and discloses no evidence). All risk acceptance is the
  owner's (§6, Q10/Q18).
- `onDraw` allocates nothing; the signal button obeys `UI_ICONS.md` (four ways
  to get a vector wrong); all px placements are measured on device (P6, density
  398).
- New settings ship as a plugin `Feature` (settings declared once, index in
  `features/Registry.java`); `Prefs` keys are new strings named verbatim
  (persisted — never rename later) — or re-bind the surviving `KEY_AIM_*`
  strings that already mean the right thing (§1.5).

---

## 6. Open questions for the owner (single authoritative list)

Questions already answered by research are NOT listed here — they are design
notes in §3 and ledger entries in §11 (hold-hard, deaths-during-freeze, the
scope on/off gate, the fire trigger's existence, the motion profile).

**Scope (F4)**
1. Which scopes must be right first — 8x only, or 2x/4x/8x + AWM-style?
2. Manual scope arming (O1) is now a *fallback* next to the proven wire gate.
   Keep it built from day one (recommended), or wire-gate only?
3. Does scoped magnification *feel* like camera zoom (world bigger) to you in
   game? (Confirms the AnimationClip theory before we go asset-digging.)
4. Is the O4 screen-capture cross-check wanted at all (AccessibilityService
   privilege for an independent "is the reticle really up" check), or skip?

**Trigger (F1)**
5. Primary fire trigger: daemon touch-region (instant, but the grab must be
   held while armed) or wire FIRING_STATUS (no grab, but ~10 Hz-sampled)?
   The other becomes fallback/cross-check.
6. Head point: box-top (~1.8 m) or the pose-ray head (0.92 × box)? Or a
   configurable offset per weapon class?
7. Trigger semantics: one swipe per fire *tap*? Continuous re-aim while fire
   is *held* (still still-only)? Both as a setting?

**Swipe (F3)**
8. Abort-on-move latency matters (~1 frame): agree the abort decision lives in
   the daemon (it has the target state via a small state push) rather than
   round-tripping through Java?
9. How many swipe-zone controls are enough — one start point + radius + max
   travel, or a free draggable rect? (Also: how many signal buttons — scope
   signal later?)
10. Swipe shaping/randomisation (human-like variance): yes/no/owner-tuned?
    (Detection surface — your call, not an engineering one.)
11. Per-weapon swipe caps (e.g. clamp delta harder for bolt-actions)? Worth
    having, or skip until real-aim proves it needs them?

**Gating (F5/F6)**
12. Freeze-lock: automatic whenever freeze is on, or an independent toggle?
13. On unfreeze: snap to live immediately, or hold + fade for N ms?
14. Still-threshold: is "standing still" enough, or should slow-walk targets
    (crouch-scoping enemies) be eligible at a tighter gate?

**Acquisition (F2)**
15. Overshoot/settle budget: when the game's assist friction fights the last
    pixels, do we overshoot slightly and settle back (feels different) or
    undershoot and accept a final nudge (slower)?
16. Tie-breaker for two eligible targets: nearest-to-crosshair angularly, or
    nearest by wire distance?
17. Cone/range defaults: accept the proposed defaults (hip ±10°, scoped
    derived from measured hFOV, 200 m sniper / 80 m otherwise), or set your
    own? Includes whether the cone auto-shrinks when scoped (per-scope
    presets).

**Risk posture**
18. Is the increased armed-grab time (signal detection) an acceptable risk
    delta, given `AIM_PLAN.md` §7 and the researched exposures (§5)?
19. Should the aim hard-disable in FPP (firing damp unmeasured) until P0
    numbers exist, or ship hip-FPP behind a flag from day one?
20. The game's **"Hold Fire to Scope"** setting reorders fire/scope startup
    (research B): on a fire press with that setting on, the scope may still be
    mid-lerp. Should the trigger wait for the transition to settle (adds
    latency) or aim with the live (mid-lerp) FOV once its timestamp says the
    lerp ended?

---

## 7. Non-goals

- No moving-target tracking or leading (thesis §2) — not a tuning matter.
- No packet-content changes of any kind; no hit/damage/kill forgery (hard
  rules 2 and 7). The aim never writes a packet. (Observing/latching what the
  client already sends — 137/138, varId 12/21 — is reading, not writing.)
- No mid-match `restartTunnel` or new tunnel heuristics.
- No closed-loop aim controller (the deleted one is not coming back in that
  shape); the swipe is one-shot, open-loop.
- No ML/trained model anywhere in the aim path — every decision in this plan
  is rule-based on measured numbers. (The capture/recognition research exists
  only to say *why not*, and as a cross-check option.)
- No `DevLogger` diagnostics; new `Slot.AIM2_*` + `Diag.hit` only.

---

## 8. Phases (measurement-first, each independently shippable)

- **P0 — Scoped truth (measure, don't assume).** In-game, per scope: does the
  world visibly zoom (AnimationClip theory); scoped px/deg (fixed-angle swipe
  under scope, measure the turn); firing-damp magnitude; assist friction near
  target; head-point screen position vs ESP projection; still-threshold that
  reads as "still" at range. Deliverable: a numbers doc section.
- **P1 — Freeze-locked ESP.** Hold world-state positions while freeze is on
  (F5, hold-hard — the proven design); capture-verify that what we render
  coincides with what the game renders, including the death-feed rule.
  *Independent value even without any aim.*
- **P2 — Signal button + fire detection.** Press-through circle, rect pushed
  to `nvmux`, daemon reports contact-in-region; wire FIRING_STATUS (varId 21)
  read as the no-grab fallback/cross-check (measure its cadence first, §9);
  HUD/Diag proof only — no aim yet.
- **P3 — One-shot still-target swipe (hip).** Editable cone + swipe zone +
  gating; live-match proof: stationary target, fire → headshot-worthy
  crosshair placement; abort-on-move proven.
- **P4 — Scope model.** Wire gate first: `137/138` latcher + the varId-12
  sighting reader (both already on decoded paths); per-scope FOV override +
  scoped gain from P0 numbers; O1's selector as manual override/fallback;
  O4 recognition only if the owner wants the cross-check. Settling
  measurement (Training Ground): does 137 fire for non-sniper ADS; does
  varId 12 distinguish 2x/4x/8x on scope-in.
- **P5 — Hardening.** Diag inventory, WHEN-NOTHING-WORKS entry, plugin
  settings finalised, safety rails re-verified, docs updated.

**Acceptance (flagship, P4 exit):** freeze on, stationary enemy at range,
scope up: press fire → the crosshair lands on the held head pose with one
swipe, ESP box and frozen model coincide within a few px, zero
`ACTION_CANCEL`s, Volume-Down bail works at all times, and every bail that
fired is named in the DIAG block.

---

## 9. Measurement plan (how P0 gets its numbers)

- **Scoped zoom truth:** landmark screenshot ratio — photograph a landmark
  edge at hip and per scope, measure the px ratio (magnification = the ratio);
  cross-check against the AnimationClip theory. `plan/research/RESEARCH_FF_SCOPE_VALUES.md`
  §6 has the full method list.
- **px/deg per scope per slider:** the community **360°-calibration probe**
  (count full-screen swipes per rotation) — reusable verbatim; run it per
  per-scope slider value, and re-verify the hip 15/35 formula against the
  0–200 slider scale first.
- **ADS transition:** timestamp the scope-up event and sample the projected
  FOV across it (the `GRADUAL` hypothesis) — establishes the lerp window and
  whether centre stays invariant through it.
- **Scoped px/deg (game-side):** swipe a fixed px length while scoped, read
  the turn from our own Cmd 2001 v3–v5 (already decoded) in the capture — no
  estimation.
- **Assist friction / firing damp / stock "Aim Precision":** hold fire while
  swiping through a still target at known angle; compare achieved vs
  commanded rotation — the stock assist setting is a second term (research B),
  measure it on and off.
- **Head-point check:** ESP pose ray (`SHOW_POSE`) vs the visible head in a
  screenshot pair at 2–3 distances (density 398 in mind).
- **Still-threshold:** replay existing captures (`captures/`, 330 dirs) to
  pick the velocity window that separates "still" from "slow-walk".
- **Scope-gate settling (Training Ground, one session):** log cmd ids +
  weapon held — does `137` fire for non-sniper ADS (red dot); does varId 12
  distinguish 2x/4x/8x on scope-in; timestamps give the ADS transition
  window (`GRADUAL` hypothesis).
- **FIRING_STATUS cadence:** timestamps of varId-21 changes on our own
  outbound 1900 — is the assumed ~10 Hz real? This sets the wire trigger's
  worst-case latency (P2 input).
- **Panel truth (`getevent -lt` on this unit, feeds the motion profile):**
  real report cadence + skip pattern; whether `ABS_MT_PRESSURE`/
  `TOUCH_MAJOR` are actually emitted (`support_mt_pressure` is
  build-dependent); what MotionEvent pressure a synthetic contact gets today;
  flick duration and touch-down→first-move latency — **no public measurements
  exist for any of these**; calibrate from the owner's own logged swipes
  (`plan/research/RESEARCH_SWIPE_SHAPING_DETECTION.md` §6).

---

## 10. References

- `plan/assets/scope1.jpg`, `scope2.jpg`, `scope3.jpg` — the owner's sniper
  reticle reference set (reviewed by vision 2026-09-19). The invariant across
  all three: a **circular magnified reticle with a heavy dark vignette
  annulus**, fine crosshair with tick marks + centre mark, kill emblem
  overlaid at scope top, compass strip + HP bar (HUD). Observed specifics:
  scope1 = AWM in-game view, damage numbers (624/150) inside the ring; scope2
  = BlueStacks 8x view with a 3D-rendered scope body + knobs and mil-dot
  hashes below centre (emulator HUD); scope3 = AWM knock-down with a red
  hit-direction arc on the right vignette. For the F4/O4 ring heuristic this
  confirms the design: the vignette annulus is the dominant low-frequency
  feature; per-tier colour/radius clusters are plausible, and the red arc +
  kill emblem are additional discriminators to sample.
- `docs/SESSION_2026_09_18_touch_coexistence.md` · `docs/DUAL_TOUCH_INJECTION.md`
  · `docs/EXTERNAL_TAP_COEXISTENCE.md` — the touch/daemon foundation.
- `docs/GAME_CLIENT_CONSTANTS.md` §1 (FOV/boom/shoulder), §3 (px/deg, scoped
  0.2×, acceleration term, assist-is-friction), §5 (the open measurements this
  plan inherits).
- `native/touchmux/src/main.rs` (stdin protocol, `parse_line`, `drain_real`,
  `grab_resync`) · `native/nuvola-core/src/geom.rs`
  (`screen_offset_to_yaw_pitch_deg`, `clamp_circle_center`)
  · `ui/aim/AimInjector.java` (spawn + driver).
- `tunnel/UdpSessionManager.java` 375–425 (ESP-before-filter ordering — the
  F5 root cause) · `filter/FreezeFilter.java` (what freeze withholds — and
  its combat-feedback pass rule, the deaths-during-freeze answer).
- `esp/PriTracker.java` 206–244 (where varId 12 is currently discarded).
- `docs/AIM_PLAN.md` (prior aim plan; detection-surface §4/§7 still applies).

**Research material (2026-09-19 subagent passes, cited by this plan):**
- `plan/research/RESEARCH_WIRE_SCOPE_STATE.md` — the wire survey: **137/138
  scope pair proven** (6 captures, 100% reliable, perfectly paired); varId 12
  sighting id + varId 21 FIRING_STATUS (n=2159) already on decoded paths;
  **hold-hard proven** (enemy world-state never reliable in ~40k packets);
  FreezeFilter's 2003 claim reproduced exactly (method validated).
- `plan/research/RESEARCH_FF_SCOPE_VALUES.md` — public scope
  magnification/FOV/sensitivity knowledge: documented negative on all truth
  values; per-scope sliders (0–200 scale), weapon table, "Hold Fire to
  Scope", AWM ×2.5, no sway; the cheat-PDF hypotheses.
- `plan/research/RESEARCH_SCOPE_RECOGNITION_CV.md` — the recognition
  pipeline: a11y `takeScreenshot` @1 Hz + ~50-px ring heuristic, MediaProjection
  upgrade path, FLAG_SECURE probe, detection surface.
- `plan/research/RESEARCH_SWIPE_SHAPING_DETECTION.md` — uinput detection
  surface (pressure axes, timing statistics, enumeration) + the min-jerk
  swipe profile + the honest limits of shaping.

**Corrections the research surfaced (fold into `docs/` separately):**
`docs/PROTOCOL_MASTER.md:174`'s "v17/v18 weapon/loadout-ish flags" is
retracted by instruction-level analysis (they track low-gravity / RTT);
2001's **v6/v7 are the move stick, not pose**; `docs/SOURCE_MAP.md:7`'s
module root (`com/fakelag/cryhard8`) is stale — the live tree is
`com/nuvola/app`.

---

## 11. Research ledger — what is known, what must be measured, what is open

The purpose of this section: a future session should never re-research
settled ground. Three tiers.

### 11.1 ANSWERED — do not research again (evidence in hand)

| question | answer | evidence |
|---|---|---|
| Why can't injected touch coexist with fingers? | One input device per window connection; injected events are forced to device −1 | AOSP commit `2899c55f`; `docs/DUAL_TOUCH_INJECTION.md` §1 |
| How does the daemon coexist? | `EVIOCGRAB` + one uinput clone carrying panel identity; proven in a live match | `43ad2c2`; session doc |
| Is scoped ON/OFF observable without capture? | **YES** — Cmd 137/138 outbound, 100% reliable, perfectly paired | research A, six captures |
| Is the fire moment observable without capture? | **YES** — varId 21 FIRING_STATUS {0,1,2}, n=2159 (cadence still to measure) | research A |
| Can a spared reliable packet move a frozen enemy? | **NO** — enemy world-state never arrives reliable (0/~40k) | research A |
| Do damage/death updates survive freeze? | **YES** — FreezeFilter passes all combat feedback by design; only world state is withheld | `FreezeFilter.java` javadoc + drop rule |
| Does the binary change FOV on ADS? | **NO** `set_fieldOfView` caller; AnimationClip asset theory stands | `GAME_CLIENT_CONSTANTS.md` §1 |
| Are scoped FOV/magnification numbers publicly known? | **NO — documented negative**, all label-repetition | research B |
| Is a trained model needed for scope recognition? | **NO, twice over.** The wire already answers it exactly (137/138, now shipped) — and even if we had to read the screen, a ~50-px ring heuristic decides in microseconds. A model would need a labelled dataset we'd have to build, a capture permission, a per-frame budget and a false-positive rate, to answer a question one integer comparison answers with no error at all. | research A + C |
| Does `geom` match the projection ESP actually uses? | **NOW YES — defect found AND FIXED 2026-09-19.** `geom` treated `fov_x_deg` literally, dropped `FOV_Y_SCALE` and had no zoom term; `EspRenderView` quotes `FOV_X_DEG` at a **16:9 reference** and re-derives from the true aspect (90 deg -> ~101 deg here). Replaced with `geom::ViewProjection` (`new(fov_x_deg, w, h, fov_y_scale, zoom)`), which reproduces `tan_half_v = tan(fov/2)/(16/9)`, `tan_half_x = tan_half_v*aspect/zoom`, `tan_half_y = tan_half_v*fov_y_scale/zoom` exactly. Added the parity test that never existed: forward-project a camera-space direction with ESP's own maths, invert it, require the original angle back within 0.02 deg — swept over 4 aspects x 3 y-trims x 4 zooms x 5 directions = 240 cases. The old model missed by 0.5-4.0 deg on those same cases, so the test has teeth. **95 Rust tests pass** (was 92). | `geom.rs` vs `EspRenderView.java:1312-1317` |
| Is screen capture detectable by the game (Android 14)? | Not by any public pre-API-35 mechanism; real risks are the a11y privilege + possible FLAG_SECURE | research C |
| Why did every reliable channel go opaque on 2026-09-17/18? | **The match server re-keys the body cipher at `RUDP_JOIN_MATCH` (cmd 100).** `SECRET_KEY` still drives the header mask and exactly 7 handshake packets per match; everything after the join uses a different key that is constant per APP RUN and is **not on the lobby wire at any byte alignment**. Not our code (CRC-7 valid on 38,232/38,232 stored bodies), not the permutation, not ZIPPED, not a TEA parameter change (2,688 configs swept), not a client update (build `2019118525` identical either side). | `plan/tools/repro_rekey.py`; `docs/WHEN_NOTHING_WORKS.md` §0a |
| Can the aim tell teammates from enemies while the reliable channel is dead? | **YES — measured live.** `ESP_TEAM_SRC_DAMAGE=1442` + `_HANDLE=4` give `ESP_CLS_R2_TEAM=6036` while `PROTO_DECRYPT_FAILED=8136` and `_BIND`/`_ROSTER` are zero. Team comes from plaintext damage events and packed handles (`EspEngine.java:2197`, `:319`/`:2147`) — still server-published, so hard rule 1 holds. An earlier claim that Cmd 118 was required was WRONG. | `capture_raw_20260919_184632.txt` DIAG block |
| Where does the post-join body key live? | **Memory only.** Server re-keys at `RUDP_JOIN_MATCH`; key is constant per APP RUN, not on the wire (0 hits / 1.5M packets incl. login), not derivable (18 transforms). Needs root. | `docs/SESSION_2026_09_19_aim_build.md` §2 |
| Is aim assist a cone that closes error? | **NO** — friction (damp) only; we must deliver the full delta | `GAME_CLIENT_CONSTANTS.md` §3 |
| What does a human swipe look like (shape/timing)? | Min-jerk, arc +3–6%, log-normal durations, jittered cadence — parameterised in F3 | research D |
| Does hip px/deg formula hold? | Yes at sens 75 = 10 px/deg, but re-verify vs the 0–200 slider era | constants doc + research B |

### 11.2 MEASURABLE — numbers only, on-device/captures (P0 list; §9 has methods)

1. Scoped FOV per tier (landmark ratio) — the one number F4 cannot ship without.
2. Scoped px/deg per tier per slider (360°-probe + own-2001 v3–v5 readback).
3. ADS transition window + centre invariance (the GRADUAL hypothesis).
4. Firing damp (FPP) + stock "Aim Precision" assist, on/off.
5. Head-point truth vs the two renderer definitions (Q6 input).
6. Still-threshold window from capture replays (Q14 input).
7. varId-21 FIRING_STATUS cadence (wire-trigger latency, P2 input).
8. 137-for-non-sniper-ADS + varId-12 tier semantics (Training Ground).
   **Instrument SHIPPED 2026-09-19** — `ScopeState.observeSighting` is fed from
   `PriTracker.onProperty` (where varId 12 was previously discarded) and the
   dev panel's `TIER` row prints `@in=` the varId-12 value live at the last
   scope-in, `now=` the latest value, `wpn=` the held weapon id, and every
   distinct varId-12 value with its hit count. Procedure: Training Ground,
   scope in with a 2x, then a 4x, then an 8x, and compare the three `@in=`
   readings. Differ ⇒ varId 12 IS the tier and the mapping is read off
   directly. Same ⇒ varId 12 is not the level, and the next two candidates are
   `wpn=` (fixed-scope weapons only) and Cmd 124 `RUDP_ATTACHMENT_CHANGED`
   (inbound, ~1 289/match, all reliable, never decoded). Nothing in the app
   interprets the value until this is done.
9. Panel truth: report cadence/skip, pressure-axis emission, synthetic-finger
   MotionEvent pressure today, flick duration, first-move latency.
10. Hip 15/35 formula vs the 0–200 slider scale.
11. ~~**`geom` <-> `EspRenderView` projection parity**~~ — **DONE 2026-09-19.** `ViewProjection` + a 240-case round-trip parity test. No longer blocks P3.

### 11.3 OPEN — genuine research (nobody has answered these; do not assume)

1. **The scoped-FOV number itself** if P0 measurement is skipped — then O2
   (APK asset extraction) is the only alternative and needs its own session
   (UnityPy/AssetRipper against the game's bundles; "bridge by name"
   discipline). Owner picks measurement vs extraction.
2. **Whether 137/138 or varId 12 are validated server-side** (i.e. can they
   disagree with the true visual state, e.g. desync after a death while
   scoped?). Wire truth ≠ screen truth until the P4 cross-check (only if O4
   is built).
3. **Where the post-join body key comes from, and whether it can be got without root.** The leading hypothesis is `GCommon.UDPParameters.SECRET_KEY_PROXY` (static field +0x58, beside `SECRET_KEY` at +0x48); all four PROXY symbols exist in the live build's metadata. **HYPOTHESIS, not measurement.** If the key turns out to live only in game memory, recovering it forfeits the project's no-root property — an owner decision, not an engineering one. **This blocks F2 eligibility (needs 118 binds + team byte), F5's death-feed rule (needs 107/139), the varId-12 tier probe and all HP.** It does NOT block the swipe math, the daemon, or position/velocity work, because 2001/2012 are unreliable and therefore plaintext.
4. **Whether contact-area interpolation actually normalises detector
   features** on this specific game — research D's sources are cross-game;
   nothing verifies Free Fire's own checks. This is unknowable without
   adversarial testing, which is the owner's call to even attempt.
5. **FPP firing-damp interaction with a moving synthetic finger** (damp is
   measured for static holds in the old data; a 100–200 ms swipe through the
   damp may behave differently — measure once in P0, hip and scoped).
6. **Real panel behaviour on THIS unit** (ledger 11.2 #9) — public data
   contradicts itself on the driver identity (synaptics vs sec touchscreen);
   only `getevent` on the device settles it.

Nothing else in this plan needs searching: if a future question is not in
§11.3, its answer is either in §11.1, or is a §11.2 measurement away.
