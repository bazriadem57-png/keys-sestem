"""
Reproducing test for the 2026-09-17/18 reliable-body decryption regression.

Thesis under test:
  The lobby-advertised SECRET_KEY still decrypts the UDP handshake
  (cmd 1 / 447 / 448 / 100 / 130) and still equals the header XOR mask,
  but it no longer decrypts ANY post-join reliable body.

RED   on every capture from 2026-09-18 17:09 onwards.
GREEN on every capture up to 2026-09-17 05:41.
Goes GREEN again once the correct post-join key is supplied via --key.

usage:
  python repro_rekey.py <capture_raw_*.txt> [--key <32 hex>]
"""
import sys, struct, collections

DELTA = 0x9E3779B9; M = 0xFFFFFFFF; ROUNDS = 16
SALT = 2; ZERO = 7; OVER = 1 + SALT + ZERO
HANDSHAKE = {1, 100, 130, 447, 448}

def le32(b, o): return struct.unpack_from("<I", b, o)[0]
def sched(k16): return [le32(k16, i * 4) for i in range(4)]

def dec_words(c0, c1, k):
    v0, v1 = c0, c1; s = (DELTA * ROUNDS) & M
    for _ in range(ROUNDS):
        v1 = (v1 - ((((v0 << 4) & M) + k[2]) ^ ((v0 + s) & M) ^ ((v0 >> 5) + k[3]))) & M
        v0 = (v0 - ((((v1 << 4) & M) + k[0]) ^ ((v1 + s) & M) ^ ((v1 >> 5) + k[1]))) & M
        s = (s - DELTA) & M
    return v0, v1

def qq_decrypt(buf, k):
    L = len(buf)
    if L < 16 or L & 7: return None
    out = bytearray(L)
    c0, c1 = le32(buf, 0), le32(buf, 4)
    p0, p1 = dec_words(c0, c1, k)
    struct.pack_into("<I", out, 0, p0); struct.pack_into("<I", out, 4, p1)
    pc0, pc1, pp0, pp1 = c0, c1, p0, p1
    for i in range(8, L, 8):
        i0, i1 = le32(buf, i), le32(buf, i + 4)
        d0, d1 = dec_words(i0 ^ pp0, i1 ^ pp1, k)
        struct.pack_into("<I", out, i, d0 ^ pc0); struct.pack_into("<I", out, i + 4, d1 ^ pc1)
        pp0, pp1, pc0, pc1 = d0, d1, i0, i1
    pad = out[0] & 7; plain = L - pad - OVER
    if plain < 0: return None
    st = 1 + pad + SALT
    if any(out[st + plain + i] for i in range(ZERO)): return None
    return bytes(out[st:st + plain])

def hdr_size(first):
    if 90 <= first < 100: return 10
    if 100 <= first <= 110: return 8
    return -1

def main(path, override=None):
    key = sch = None
    hs_ok = hs_bad = pj_ok = pj_bad = 0
    blk0 = collections.defaultdict(collections.Counter)   # secret_key -> ciphertext block0
    for ln in open(path, encoding="utf-8", errors="replace"):
        if ln.startswith("#"):
            if ln.startswith("# secret_key="):
                v = ln.strip().split("=", 1)[1]
                if v != "UNKNOWN":
                    key = v
                    sch = sched(bytes.fromhex(override or v))
            continue
        if sch is None: continue
        t = ln.rstrip("\n").split(" ")
        if len(t) < 17 or not t[8].isdigit(): continue
        try: fl = int(t[10], 16)
        except ValueError: continue
        if not (fl & 0x04) or not (fl & 0x08): continue      # reliable + encrypted
        h = t[16]
        if h == "-" or len(h) % 2: continue
        raw = bytes.fromhex(h); hz = hdr_size(raw[0])
        if hz < 0: continue
        body = raw[hz:]
        if len(body) < 16 or len(body) & 7: continue
        ok = qq_decrypt(body, sch) is not None
        if int(t[8]) in HANDSHAKE:
            hs_ok += ok; hs_bad += not ok
        else:
            pj_ok += ok; pj_bad += not ok
            if t[4] == "IN" and int(t[8]) == 121:
                blk0[key][body[:8]] += 1

    print("capture        : %s" % path)
    print("key(s) in file : %s" % (override or "from capture"))
    print("handshake      : %6d decrypt / %6d opaque   (cmd 1,100,130,447,448)" % (hs_ok, hs_bad))
    print("post-join      : %6d decrypt / %6d opaque" % (pj_ok, pj_bad))
    if len(blk0) > 1:
        print("body-key vs SECRET_KEY rotation (cmd 121 IN, top ciphertext block 0):")
        tops = []
        for k, c in blk0.items():
            if not c: continue
            mc = c.most_common(1)[0]
            tops.append(mc[0])
            print("   SECRET_KEY=%s -> %s x%d" % (k, mc[0].hex(), mc[1]))
        if len(tops) > 1:
            same = len(set(tops)) == 1
            print("   => body ciphertext %s across the SECRET_KEY rotation: body key is %s"
                  % ("UNCHANGED" if same else "CHANGED",
                     "INDEPENDENT of SECRET_KEY (BROKEN)" if same else "tied to SECRET_KEY (OK)"))
    good = pj_ok > 0
    print("\nRESULT: %s  (expect post-join decrypts > 0)" % ("GREEN" if good else "RED"))
    return 0 if good else 1

if __name__ == "__main__":
    a = sys.argv[1:]
    ov = None
    if "--key" in a:
        i = a.index("--key"); ov = a[i + 1]; a = a[:i] + a[i + 2:]
    sys.exit(main(a[0], ov))
