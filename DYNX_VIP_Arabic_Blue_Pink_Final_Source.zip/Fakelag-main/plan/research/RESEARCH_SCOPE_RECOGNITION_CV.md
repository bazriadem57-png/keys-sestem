# Scope recognition via screen capture — research findings

Date: 2026-09-17 (session). Target device: Samsung SM-S948U1 (Galaxy S24 Ultra,
Snapdragon 8 Gen 3 for Galaxy), 1080×2340 @120 Hz, Android 14. App: SunnyMod,
minSdk 21, targetSdk 34. Research only — every numeric claim is sourced; the few
unsourced judgements are marked **SPECULATION** or **measure on device**.

## 1. Scope

When the player aims down a sniper scope, Free Fire replaces the free-look
camera with a circular magnified reticle: a fixed-shape ring, a heavy dark
vignette border that occludes most of the screen, a fine cross with a centre
mark, tier-specific colour/texture. The feature wants a boolean
`scoped` (+ tier label ∈ {2x, 4x, 8x}) sampled slowly — scope state changes a
few times per minute, not 120 times per second — to retune the input-side
projection FOV and swipe gain. The recognition path must read the screen from
inside the app. The reticle is *ours*: it is rendered by the game on our own
screen; nothing about this problem needs to touch memory or packets. The open
engineering question is only: cheapest safe way to get ~1 frame per second of
the screen centre, and the cheapest reliable decision rule on it.

Key constraints discovered during research:

- Any MediaProjection session is **user-visible** (consent dialog per session +
  status-bar cast icon; a large tappable chip on Android 15 QPR1+). There is no
  hidden full-screen capture API for a regular app.
- The cheapest detector is likely not "OpenCV at 1080p" but a tiny ROI /
  ring-sample heuristic evaluated at 1–5 Hz; the vignette border is an unusually
  strong low-frequency feature (documented claim in §3, hypothesis by design).

## 2. Capture options compared

| | MediaProjection + VirtualDisplay → ImageReader | AccessibilityService.takeScreenshot (API 30+) | takeScreenshotOfWindow (API 33+) | Hardware paths (root/adb: scrcpy, `screenrecord`) |
|---|---|---|---|---|
| minSdk | 21 (API 21, [docs](https://developer.android.com/media/grow/media-projection)) — works on this device | 30 — **works** (device is 34) | 33 — **works** | needs adb/root; not usable as in-app background feature |
| Permission UX | consent dialog **every session** ("token used only once to call createVirtualDisplay"); on targetSdk ≥ 34 (U) must run inside an FGS of type `mediaProjection` started *before* `getMediaProjection()`, else `SecurityException` ([MediaProjectionManager](https://developer.android.com/reference/android/media/projection/MediaProjectionManager), [FGS types](https://developer.android.com/about/versions/14/changes/fgs-types-required)) | none at runtime beyond the existing accessibility enablement; service must declare `canTakeScreenshot` capability or it throws `SecurityException` ([AOSP: canTakeScreenshotLocked](https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/services/accessibility/java/com/android/server/accessibility/AbstractAccessibilityServiceConnection.java)) | same | user starts it manually from a PC; not a UI-free in-app path |
| User-visible indicator | yes: status-bar cast icon; Android 15 QPR1+ adds a large tappable "screen is being shared" chip and auto-stop on lock ([Media projection guide](https://developer.android.com/media/grow/media-projection)); Samsung One UI also shows its own cast/recording icon (device-verified by owner previously — **measure on device**) | **no OS indicator**; screenshots are silent to other apps | **no OS indicator** | ADB scrcpy is invisible to the UI; `screenrecord` writes a file, no icon |
| Rate ceiling | continuous stream; ceiling set by the *consumer*: BufferQueue back-pressure → SurfaceFlinger drops frames when the consumer is slow ([xckevin internals writeup](https://xckevin.com/en/blog/android-screen-capture-mediaprojection/)). Recorded output on-device commonly 30–60 fps at 1080p with MediaCodec; with ImageReader the practical cap is what your `onImageAvailable` handler can drain | hard **333 ms** floor per call (`ACCESSIBILITY_TAKE_SCREENSHOT_REQUEST_INTERVAL_TIMES_MS = 333`, AOSP constant; earlier proposal was 1000 ms [e.foundation mirror of the commit](https://gitlab.e.foundation/e/os/android_frameworks_base/-/commit/979600dce1789ac905f5dec5039c7e9c317959cc)) → **≤3 Hz** | same 333 ms floor | 30–120 fps (scrcpy README: [35–70 ms latency](https://github.com/Genymobile/scrcpy)) |
| Latency per screenshot | first frame ~200 ms after session start (AOSP SystemUI recorder path measured 197 ms time-to-first-frame in one writeup — vendor blog, treat as approximate); steady-state frame-to-frame is display-refresh-bound (~8.3 ms at 120 Hz for the buffer, plus your processing) — **measure on device** | one round-trip ≈ 100–300 ms typical; AOSP CTS allows up to `TIMEOUT_TAKE_SCREENSHOT_DONE_MILLIS` before declaring failure ([CTS test](https://android.googlesource.com/platform/cts/+/refs/heads/main/tests/accessibilityservice/src/android/accessibilityservice/cts/AccessibilityTakeScreenshotTest.java)) — **measure on device** | same class of latency; smaller payload (single window) | scrcpy: 35–70 ms glass-to-glass |
| What you get | RGBA_8888 `Image` planes → copy to `Bitmap`/`ByteBuffer` yourself (pixel-stride/row-stride padding — see [SO example](https://stackoverflow.com/questions/71456691/android-media-projection-screen-capture-works-differently-on-real-device)); `acquireLatestImage()` + `maxImages=2` recommended so a slow consumer drops frames instead of stalling ([xckevin](https://xckevin.com/en/blog/android-screen-capture-mediaprojection/)) | `ScreenshotResult` → `HardwareBuffer` → `Bitmap.wrapHardwareBuffer()`; full display | `ScreenshotResult` of **one window** — the game window alone; ideal shape for ROI work | H.264/H.265 stream or PNG |
| Secure content (FLAG_SECURE) | flagged window renders **black for the entire virtual display** while it is foregrounded ([YinkoShield analysis](https://www.yinkoshield.com/knowledge-center/mobile-runtime-attacks/screen-capture-attacks/), [FLAG_SECURE deep dive](https://xckevin.com/en/blog/android-flag-secure-surface-security/)) | fails with `ERROR_TAKE_SCREENSHOT_SECURE_WINDOW` if the window contains secure content ([AccessibilityService reference](https://developer.android.com/reference/android/accessibilityservice/AccessibilityService)) | same error for that window | adb `screencap`/scrcpy also show black for secure layers (SurfaceFlinger skips them; `SKIP_SCREENSHOT`/`SECURE` SurfaceControl flags, [AOSP commit](https://gitlab.e.foundation/e/os/android_frameworks_base/-/commit/b222d48559fdb10955e7a7c321c9e0e4e9dbd812)) |
| Detectable by the game | Not via any public pre-15 API. Android 15 (API 35) adds `WindowManager.addScreenRecordingCallback` + `DETECT_SCREEN_RECORDING` which **does** notify the captured app ([SO/SDK survey](https://github.com/NoobDigital/react-native-shieldscan) — "no public API pre-Android 15"; official docs [Activity.ScreenCaptureCallback (API 34)](https://developer.android.com/about/versions/14/features/screenshot-detection) covers *user* screenshots only, and explicitly not adb/instrumentation). Free Fire on this device (Android 14) therefore has **no public API** to see a MediaProjection session — what it *can* see is summarised in §5. | games could in principle notice an enabled accessibility service by scanning enabled services (package-manager read), a generic and noisy signal | same | invisible to on-device APIs (scrcpy is a `shell` user with `SurfaceControl` access, no app on device) |
| Cost | GPU composites the virtual display every frame; CPU cost is the copy-out you do yourself. Whole-pipeline recorded-CPU ≈ <12–15% at 1080p60 on flagship-class SoCs (vendor blog for SCR recorder; treat as approximate); battery ≈ **<8%/30 min** measured on a Pixel 8 for a WebRTC screen-share session ([Forasoft](https://www.forasoft.com/blog/article/screen-sharing-android-1644)); another vendor blog reports ≤8%/h extra draw at 1080p60 — **blogs, treat as approximate; measure on device** | a single composited read per call; amortised cost negligible at ≤3 Hz; no continuous GPU work | same | outside scope |

Notes that matter for the projection-FOV feature:

- **A smaller VirtualDisplay is a free ROI.** `createVirtualDisplay` accepts any
  w×h; since Android 12L (API 32) content is *uniformly scaled and centred* to
  fit the surface ([Media projection guide](https://developer.android.com/media/grow/media-projection)).
  A 270×608 virtual display therefore receives the whole screen downscaled 4×
  with no extra code — you do not need a crop API to cut capture cost; you need
  a small surface. Android 14's `MediaProjectionConfig`/`onCapturedContentResize`
  adds app/region selection, but vendor support is uneven ([xckevin](https://xckevin.com/en/blog/android-screen-capture-mediaprojection/))
  — do not depend on it.
- **Games are capturable.** SurfaceFlinger composites all visible layers
  (including the game's) into the virtual display; secure layers are the only
  excluded ones. Free Fire does not set `FLAG_SECURE` on gameplay as far as
  public knowledge goes — **measure on device: run one session, check frames
  are not black**.
- The virtual display *includes system UI and our own overlay window* (it is a
  mirror of the default display). Our ESP boxes would appear in captured
  frames; the reticle detector must tolerate or mask them, and the 120 Hz
  Choreographer overlay itself becomes part of the composited GPU load.
  **SPECULATION on cost impact: likely a few %, measure on device.**

## 3. On-device matching options

Three candidate decision rules, from heaviest to lightest:

### 3.1 OpenCV `matchTemplate` at full / quarter resolution

- `matchTemplate` is O(W·H·w·h) per template; it is the single most expensive
  call in every mobile OpenCV thread found. Field data:
  - 1280×720 frame, small template, **~3–4 fps** on an older phone — the
    matcher alone; removing it restored 25 fps ([OpenCV answers](https://answers.opencv.org/question/113998/opencv4android-template-matching/)).
  - A poorly-built Android OpenCV (no optimized dispatch) ran a 1920×1080
    `GaussianBlur` in **600 ms** vs 5 ms on an i7 — i.e. build quality matters
    more than the SoC ([OpenCV forum, 2022](https://forum.opencv.org/t/opencv-bad-performance-android/10773)).
  - `HoughCircles` reduced camera frames to **1–2 fps** on 2013-era hardware,
    and even now runs ~2 ms on a Jetson-class ARM CPU for a small frame
    ([SO HoughCircles thread](https://stackoverflow.com/questions/20466458/vary-slow-frame-rate-when-calling-houghcircles-method-from-oncameraframe-open), [NVIDIA forum](https://forums.developer.nvidia.com/t/why-opencv-cuda-houghcirclesdetector-is-much-slower-than-cv-houghcircles-in-jetsonnano/158531)).
  - Qualcomm's own 2024 deck: stock OpenCV functions average **9× slower** than
    their Snapdragon-optimized equivalents; median 1.2× — i.e. stock OpenCV is
    usable but not great ([Qualcomm slides](https://www.edge-ai-vision.com/wp-content/uploads/2024/06/E2W06_Zhong_Qualcomm_2024.pdf)).
- **No public benchmark exists for `matchTemplate` on an 8 Gen 3 at 1080×2340**
  — extrapolating from the 1280×720 / 3–4 fps data point (an older, weaker SoC),
  quarter-res (270×608) with a small template should land in the
  **tens-of-ms** range, and 1080p in the **hundreds-of-ms** range.
  **SPECULATION — measure on device.**
- Grayscale before matching is the standard first optimisation (SO thread
  above); `TM_CCOEFF_NORMED` on grey at quarter-res with a ≤64 px template is
  the sane configuration.
- Verdict: even in the best case, full-frame template matching at 1–5 Hz is
  10–100× more compute than the problem needs. Its real advantage is tier
  discrimination (three templates, one per scope), not the scoped/not-scoped
  bit.

### 3.2 Hough circle detection

The reticle is a large, high-contrast ring — the classic Hough use case, but
HoughCircles is expensive and brittle on busy game backgrounds (see fps numbers
above). Restricting the radius range to the known reticle radii and running it
on a **centre crop** (e.g. 400×400) at 1 Hz is viable but strictly dominated by
the ring heuristic below for a fixed-shape, camera-centred, always-same-size
target. **SPECULATION** on the "dominated" claim: Hough earns its cost only if
the reticle's on-screen radius varies with FOV — it does not within one scope
tier (fixed zoom ⇒ fixed angular size ⇒ fixed pixel radius at fixed resolution;
**measure once per tier to confirm**).

### 3.3 Ring / vignette heuristic (no OpenCV)

The reticle's vignette is a huge low-frequency feature: a full ring of
near-black pixels at a known radius from screen centre, present in *every*
tier. Two cheap implementations:

1. **Ring sample**: read N ≈ 32–64 pixel positions around a circle of radius r
   (the r that lands on the vignette band) from the centre; count how many are
   dark (e.g. luma < threshold). Scoped if count/K > 0.8. This is ~50 pixel
   loads + ~50 comparisons — microseconds in Java, no native lib.
2. **Cross-hair sample**: a few samples along the vertical/horizontal centre
   lines for the fine cross, as a confirmation bit to reject menus that happen
   to have a dark ring.

The same trick is industry practice in the mobile-automation world: EasyClick's
"multi-point colour finding" (`cmpMultiColorEx`) declares a UI state from a
handful of positioned pixel colours, explicitly as the cheap alternative to
template matching ([EasyClick image-recognition guide](https://ieasyclick.net/blog/en/android-image-recognition-guide/)),
and colour-block boundary finding is used for health bars — i.e. state-from-a-
few-pixels is a proven pattern, not a novelty. Airtest's experience also warns
that grey-scale template matching confuses same-shape/different-colour buttons
([Airtest docs](https://airtest.doc.io.netease.com/en/IDEdocs/airtest_framework/3_airtest_image/))
— relevant because scope tiers differ largely in colour; if template matching is
used for tiers, `rgb=True`-style colour-aware matching is required.

### 3.4 NNAPI / LiteRT

NNAPI is **deprecated as of Android 15** ([official migration guide](https://developer.android.com/ndk/guides/neuralnetworks/migration-guide), [AOSP release notes](https://source.android.com/docs/whatsnew/android-15-release));
Google's recommended replacement is LiteRT (ex-TensorFlow-Lite), preferably via
Play services. A CNN classifier for a fixed reticle is overkill: the decision
boundary is one threshold on one feature. Verdict: **not worth any dependency
for v1**. Revisit only if the heuristic's false-positive rate on menus/loot
screens cannot be tuned below nuisance level.

### 3.5 Sampling-rate design

Scope state changes are rare (player actions, ≈ 1–5 events/minute). A detector
evaluated at **1 Hz** adds ≤1 s latency to reticle-on transitions and costs
almost nothing; a 2–5 Hz profile is available if turn-in/turn-out latency feels
bad. Debounce with a 2-of-3 consecutive-agreement rule to reject single-frame
false positives. Because the *capture* side of MediaProjection is continuous
(GPU composites every refresh regardless of your sampling), the way to make
sampling cheap is to make the **consumer** cheap: a small virtual display
(§2), `acquireLatestImage()` with `maxImages=2` so unread frames are dropped
not queued ([xckevin](https://xckevin.com/en/blog/android-screen-capture-mediaprojection/)),
and a handler thread that drains only 1 frame/second and closes every `Image`
(unclosed `Image`s leak `GraphicBuffer`s and eventually OOM/BlockQueue —
[xckevin](https://xckevin.com/en/blog/android-screen-capture-mediaprojection/)).
With AccessibilityService capture, the 333 ms floor caps you at 3 Hz by design
and there is no continuous cost between calls — a strictly better cost profile
if 3 Hz suffices.

## 4. Prior art

- **Airtest (NetEase) + Poco** — the reference open-source pipeline for
  screen-recognition game automation on Android. Capture via minicap/adbcap or
  MediaProjection-based aircv snapshot; recognition via a strategy chain
  `["mstpl" (multi-scale template), "tpl", "surf", "brisk"]`, threshold 0.7,
  grayscale by default ([docs](https://airtest.doc.io.netease.com/en/IDEdocs/airtest_framework/3_airtest_image/),
  [cv.py source](https://github.com/AirtestProject/Airtest/blob/f296e800a709ac89cc625e6e88025a17b74a8ada/airtest/core/cv.py)).
  Lessons: threshold tuning is the whole game (their own docs devote pages to
  0.6–0.9 tuning and failure modes); plain-text/small-template recognition is
  unreliable; colour matters (grayscale confuses tiers).
- **EasyClick** — commercial Android automation framework with an in-app
  MediaProjection pipeline (`image.requestScreenCapture()`), OpenCV template
  matching, single/multi-point colour finding and colour-block detection,
  "no root" ([guide](https://ieasyclick.net/blog/en/android-image-recognition-guide/)).
  Its documented pattern of *scoped search regions + multipoint colour
  signatures* is the closest public analogue to the ring heuristic proposed in
  §3.3. Their recommended robustness tricks — randomise click points, proxy
  mode — are aimed at *behavioural* detection, not capture detection.
- **PUBG Mobile colorbot** (GitHub `3a1/Pubg-Mobile-Colorbot`) — emulator-side
  HSV colour scan for player outlines at screenshot rate; author claims
  "fully undetected as it doesn't change memory or game files" — a PoC claim,
  not evidence ([repo](https://github.com/3a1/Pubg-Mobile-Colorbot)).
- **PUBG recoil-compensation bot** (BestHub writeup) — PC-side: `pyautogui`
  region capture + OpenCV template matching/SSIM to identify weapon
  attachments when the inventory opens, then mouse-macro compensation; pitch:
  "image recognition without injection … undetectable by anti-cheat" ([writeup](https://www.besthub.dev/articles/build-a-python-recoil-compensation-bot-for-pubg-using-image-recognition-0c911c4ae8bb)).
  Analogous architecture to ours (recognition-side only, input-side effect),
  for PC where capture is unlogged.
- **scrcpy** — not a cheat, but the reference for what off-device capture can
  do: 30–120 fps, 35–70 ms latency, `shell`-privilege capture via
  `SurfaceControl`/MediaCodec — no app on device, invisible to app-side APIs
  ([README](https://github.com/Genymobile/scrcpy),
  [develop.md](https://github.com/Genymobile/scrcpy/blob/master/doc/develop.md)).
  Some Android bots run the game under scrcpy on a *second device/PC* to get
  detection-free frames; that architecture is not available to an on-device
  overlay app.
- **No public Free Fire-specific scope-detection mod found** — no source
  documents an on-device FF scope recognizer. Closest: generic mobile-game
  image-recognition bots above. Write "no public data found" where a FF-specific
  number is wanted.

## 5. Detection surface (honest characterisation; the owner decides risk)

What Free Fire (or its anti-cheat, on this Android 14 device) can and cannot
see about a capture-based reticle detector:

- **No public pre-Android-15 API lets an app detect that it is being captured
  by MediaProjection.** Android 14's `Activity.ScreenCaptureCallback` fires
  only for *user* (power+volume) screenshots, is suppressed for `FLAG_SECURE`
  windows, and explicitly does not fire for adb/test captures ([Android 14
  screenshot-detection docs](https://developer.android.com/about/versions/14/features/screenshot-detection),
  [ScreenCaptureCallbackHandler source](https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/core/java/android/app/ScreenCaptureCallbackHandler.java)).
  Android 15 (API 35) adds `WindowManager.addScreenRecordingCallback` +
  `DETECT_SCREEN_RECORDING`; on our Android 14 device it does not exist, and
  third-party SDK docs confirm "no public, reliable screen-recording-detection
  API on earlier Android versions" ([ShieldScan module notes](https://github.com/NoobDigital/react-native-shieldscan)).
- **Server/behavioural signals remain.** The in-game *effect* of an aim assist
  (swipe micro-corrections, retune cadence) is potentially visible to
  server-side analytics regardless of how scope state was obtained. That
  exposure belongs to the input-side feature, not to the capture mechanism;
  the capture itself adds none.
- **Heuristic on-device signals a vendor could use without a special API:**
  enumerate enabled accessibility services (we already run one), enumerate
  foreground services with the `mediaProjection` type, presence of a cast
  notification, package-name scans for known overlay/automation apps, or
  reading `/proc`-adjacent process lists. These are generic and noisy —
  Tencent's documented ANOGS/ACE telemetry focuses on emulators, virtual
  containers, root, sensor entropy and memory-pattern cheats
  ([ANOGS environment-detection analysis](https://deepwiki.com/arx-oioi/-AntiCheat-Anogs-Tencent-/2.3-environment-and-emulator-detection));
  no public source documents a MediaProjection-specific detection in PUBG/FF
  anti-cheat. **No documented ban case attributable to screen capture alone
  was found** — that is a statement about public sources, not about private
  detection capability. **SPECULATION: a vendor could privately flag
  `FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION` co-occurrence with the game; treat
  "capture adds zero detection surface" as unprovable.**
- **The status-bar cast icon is the real human-side surface.** Any
  screen-recording the user (or a support agent requesting a screen video) does
  will show the icon; more importantly the *icon itself is visible in the
  status bar during gameplay*, and on Android 15 QPR1+ it becomes a large chip
  ([Media projection guide](https://developer.android.com/media/grow/media-projection)).
  On this Android 14 Samsung the indicator is the small cast icon — **confirm
  its exact appearance on the SM-S948U1 build; measure on device.** A player
  who reports the account (or a support agent reviewing a screen recording)
  can see that something is casting. Note the app already shows a persistent
  overlay/FGS notification, so the marginal "something extra is running"
  signal is small.
- **FLAG_SECURE interplay:** if Garena ever marks the game window secure, the
  detector reads black frames (MediaProjection) or gets
  `ERROR_TAKE_SCREENSHOT_SECURE_WINDOW` (AccessibilityService) — graceful
  failure, no ban implication, just feature-off. Measure once: if gameplay
  frames are black under a test projection, the whole recognition approach is
  dead and only packet-side inference remains.
- **Overlay-in-capture artifact:** our own ESP boxes are part of the mirrored
  image. A determined detector could look for overlay signatures; that risk
  already exists for the current ESP feature and is unchanged by this feature.

## 6. Recommended minimal pipeline

Goal: `scoped: bool` (+ tier if reliable), ≤1–2 s transition latency,
negligible battery, minimal new detection surface.

**Capture — AccessibilityService.takeScreenshot at 1 Hz (primary), because:**
- Device is API 34, so the API exists; the app already runs an
  accessibility service, so no new user-facing permission event.
- **No continuous GPU compositing, no cast icon, no consent dialog, no FGS
  type requirements** — strictly the smallest possible footprint.
- 333 ms floor is irrelevant at 1 Hz. Payload: full-display `HardwareBuffer`.
- Fallback/upgrade path — MediaProjection with a **270×608 virtual display**
  (whole screen uniformly downscaled by 12L scaling, ~quarter data volume),
  `ImageReader` RGBA_8888 `maxImages=2`, `acquireLatestImage()`, drain on a
  handler thread at 1 Hz, `Image.close()` always — if window-level capture
  proves noisy or per-call latency >1 s.

**ROI — do not process the full frame.** With MediaProjection-quarter-res the
centre crop is (135±100, 304±100); with full-res AccessibilityService
screenshots, crop a ~(400×400) centre window into a reused `Bitmap` (or read
pixels directly via `Bitmap.getPixel` into a preallocated `int[]` — the
detector allocates nothing per call, matching the repo's `onDraw` rule).

**Decision rule — ring heuristic (§3.3), not OpenCV:**
1. Sample K=48 points on the r_vignette circle (calibrate r_vignette once per
   tier from screenshots) + 8 points for the cross arms + 4 dark-corner
   samples outside the ring (vignette is darker than sky/ground: adds
   contrast-independence).
2. `scoped = (darkRingHits/K ≥ 0.8) AND (crossHits ≥ 6/8)`; hold with
   2-of-3 debounce.
3. Tier: compare the ring's mean colour / radius against per-tier calibration
   clusters; if clusters overlap, report `scoped` only and leave the FOV
   mapping to the tier the user last equipped (the app knows the loadout from
   its own UI or the user's static config).
4. Full-frame template matching only as a *debug/verification* tool during
   development, never in the hot path.

**Expected numbers** (to be confirmed on device):
- Capture (a11y, 1 Hz): ~0 for steady state between calls; per call, one
  composited read — expect 100–300 ms latency, 0.5–2 ms CPU for copy +
  heuristic at 400×400 (heuristic itself is O(60) pixel reads).
- Capture (MediaProjection 270×608, 1 Hz effective): GPU composite of a small
  virtual display — expect low single-digit % GPU, <1% CPU on the 8 Gen 3
  (extrapolated from the 1080p60 ~12–15% CPU and <8%/30 min battery data
  points in §2 — **SPECULATION, measure on device**).
- Decision latency: 1 s sampling + 1 debounced confirm ⇒ ≤2–3 s worst case to
  settle `scoped=false→true`; acceptable for FOV/gain retuning.

**Measurement list (on-device, one calibration session):**
1. Does Free Fire set `FLAG_SECURE` on gameplay? (One test projection; if
   black ⇒ whole approach dead.) Record which windows are secure.
2. `takeScreenshot` round-trip latency at 1080×2340 (log 100 calls).
3. Vignette radius/colour per tier (2x/4x/8x) from captured frames; pick
   r_vignette and thresholds; verify false-positive rate on the 5 busiest
   non-scoped screens (lobby, inventory, map, loot, death cam).
4. MediaProjection path (if used): frame arrival interval, CPU/GPU delta via
   `dumpsys gfxinfo`/`top`, battery delta over 30 min, exact appearance of the
   cast indicator on the SM-S948U1 One UI build.
5. Overlay interference: do ESP boxes near the reticle corrupt the ring
   sample? (Mask or ignore — boxes are thin lines; confirm empirically.)
6. Tier-cluster separation: are 2x/4x/8x ring colours separable at all, or is
   tier detection impractical and loadout-based mapping required?

## 7. Source list

**Primary / official**
- Media projection guide (API 21+, 12L scaling, 14 app-screen-sharing, 15 QPR1
  status chip): https://developer.android.com/media/grow/media-projection
- MediaProjectionManager reference (consent-per-session, FGS-before-token,
  SecurityException semantics): https://developer.android.com/reference/android/media/projection/MediaProjectionManager
- MediaProjection reference (single-use token, callback required):
  https://developer.android.com/reference/kotlin/android/media/projection/MediaProjection
- MediaProjectionConfig (34, user-choice capture):
  https://developer.android.com/reference/android/media/projection/MediaProjectionConfig
- Android 14 app screen sharing:
  https://developer.android.com/about/versions/14/features/app-screen-sharing
- Foreground service types required (14, `mediaProjection` type + permission):
  https://developer.android.com/about/versions/14/changes/fgs-types-required
- FGS types reference (mediaProjection section):
  https://developer.android.com/develop/background-work/services/fgs/service-types
- Android 14 screenshot detection (`Activity.ScreenCaptureCallback`):
  https://developer.android.com/about/versions/14/features/screenshot-detection
- `Activity.ScreenCaptureCallback` reference (FLAG_SECURE suppression):
  https://developer.android.com/reference/android/app/Activity.ScreenCaptureCallback
- AccessibilityService reference (takeScreenshot, error codes incl.
  `ERROR_TAKE_SCREENSHOT_SECURE_WINDOW`):
  https://developer.android.com/reference/android/accessibilityservice/AccessibilityService
- AOSP `AccessibilityService.java` — 333 ms interval constant:
  https://android.googlesource.com/platform/frameworks/base/+/master/core/java/android/accessibilityservice/AccessibilityService.java
- AOSP `AbstractAccessibilityServiceConnection.java` — rate-limit +
  `canTakeScreenshotLocked` enforcement:
  https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/services/accessibility/java/com/android/server/accessibility/AbstractAccessibilityServiceConnection.java
- AOSP CTS `AccessibilityTakeScreenshotTest.java`:
  https://android.googlesource.com/platform/cts/+/refs/heads/main/tests/accessibilityservice/src/android/accessibilityservice/cts/AccessibilityTakeScreenshotTest.java
- AOSP `ScreenCapture.java` (containsSecureLayers semantics):
  https://android.googlesource.com/platform/frameworks/base/+/a1053a7772831c97fcf3be3ab7ab40a508eb4bc9/core/java/android/window/ScreenCapture.java
- AOSP `MediaProjection.java` (flag handling, resize/visibility callbacks):
  https://android.googlesource.com/platform/frameworks/base/+/master/media/java/android/media/projection/MediaProjection.java
- AOSP SystemUI `ScreenMediaRecorder.java` (reference bitrate/encoder setup):
  https://android.googlesource.com/platform/frameworks/base/+/2a9bfb281fadeb74ebaac43794c206e25e1ab873/packages/SystemUI/src/com/android/systemui/screenrecord/ScreenMediaRecorder.java
- AOSP commit: SurfaceControl `SKIP_SCREENSHOT` / `SECURE` flags:
  https://gitlab.e.foundation/e/os/android_frameworks_base/-/commit/b222d48559fdb10955e7a7c321c9e0e4e9dbd812
- e.foundation mirror of the a11y screenshot rate-limit commit (originally
  1000 ms, later 333 ms):
  https://gitlab.e.foundation/e/os/android_frameworks_base/-/commit/979600dce1789ac905f5dec5039c7e9c317959cc
- AOSP ScreenCaptureCallbackHandler source:
  https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/core/java/android/app/ScreenCaptureCallbackHandler.java
- NNAPI deprecated in Android 15 — migration guide:
  https://developer.android.com/ndk/guides/neuralnetworks/migration-guide
- AOSP Android 15 release notes (NNAPI deprecation):
  https://source.android.com/docs/whatsnew/android-15-release
- LiteRT in Play services (recommended NNAPI replacement):
  https://developers.google.com/edge/litert/android/java

**Engineering write-ups / measurements (secondary)**
- MediaProjection internals: BufferQueue back-pressure, ImageReader pitfalls,
  consumer-bound fps: https://xckevin.com/en/blog/android-screen-capture-mediaprojection/
- FLAG_SECURE / SurfaceFlinger secure-layer composition:
  https://xckevin.com/en/blog/android-flag-secure-surface-security/
- FLAG_SECURE boundary & bypass taxonomy (OWASP MASVS framing):
  https://ptkd.com/journal/flag-secure-screen-share-capture-bypass
- MediaProjection abuse / lifecycle analysis (banking视角, FLAG_SECURE =
  whole-frame black):
  https://www.yinkoshield.com/knowledge-center/mobile-runtime-attacks/screen-capture-attacks/
- WebRTC screen-share battery benchmark (<8%/30 min, Pixel 8):
  https://www.forasoft.com/blog/article/screen-sharing-android-1644
- Screen-recorder CPU/battery/thermal vendor writeup (approximate figures):
  https://lifetips.alibaba.com/tech-efficiency/scr-screen-recorder-for-android-captures-high-quality-screen-video-efficiently
- Screen-recording-detection API survey (API 35 only; scrcpy not detected):
  https://github.com/NoobDigital/react-native-shieldscan
- AutoMobile issue #4922/#4927 — real-world 333 ms a11y floor behaviour:
  https://github.com/kaeawc/auto-mobile/issues/4927

**CV cost data**
- OpenCV Android performance collapse (600 ms vs 5 ms GaussianBlur):
  https://forum.opencv.org/t/opencv-bad-performance-android/10773
- matchTemplate ~3–4 fps at 1280×720 on-device:
  https://answers.opencv.org/question/113998/opencv4android-template-matching/
- matchTemplate unusable on a low-end phone (1 frame/10 s), fixes (grayscale,
  downscale): https://stackoverflow.com/questions/52808735/huge-slowup-using-opencv-matchtemplate-on-android
- HoughCircles 1–2 fps on-device:
  https://stackoverflow.com/questions/20466458/vary-slow-frame-rate-when-calling-houghcircles-method-from-oncameraframe-open
- HoughCircles 2 ms (Jetson ARM CPU) / 8 ms (CUDA):
  https://forums.developer.nvidia.com/t/why-opencv-cuda-houghcirclesdetector-is-much-slower-than-cv-houghcircles-in-jetsonnano/158531
- Qualcomm OpenCV-vs-optimized speedups (8 Gen 1):
  https://www.edge-ai-vision.com/wp-content/uploads/2024/06/E2W06_Zhong_Qualcomm_2024.pdf
- Template-matching GPU benchmark harness (AOSP opencv3):
  https://android.googlesource.com/platform/external/opencv3/+/master/samples/gpu/performance/tests.cpp

**Prior art**
- Airtest image recognition (CVSTRATEGY, thresholds, grayscale caveat):
  https://airtest.doc.io.netease.com/en/IDEdocs/airtest_framework/3_airtest_image/
  https://airtest.doc.io.netease.com/en/tutorial/9_Improved_compatibility/
  https://github.com/AirtestProject/Airtest/blob/f296e800a709ac89cc625e6e88025a17b74a8ada/airtest/core/cv.py
- EasyClick in-app MediaProjection + multi-point colour finding:
  https://ieasyclick.net/blog/en/android-image-recognition-guide/
- PUBG Mobile colorbot (PoC, HSV screen scan):
  https://github.com/3a1/Pubg-Mobile-Colorbot
- PUBG PC recoil bot (region capture + SSIM/template):
  https://www.besthub.dev/articles/build-a-python-recoil-compensation-bot-for-pubg-using-image-recognition-0c911c4ae8bb
- scrcpy (30–120 fps, 35–70 ms, shell-privilege capture):
  https://github.com/Genymobile/scrcpy
  https://github.com/Genymobile/scrcpy/blob/master/doc/develop.md

**Anti-cheat landscape**
- PUBG Mobile security bulletins (spectate-xray server fix, 10-year bans;
  plug-in waves): https://www.pubgmobile.com/en-US/m/news_detail/webplat/info/news_version3/35372/35482/35483/35484/35485/m20570/202007/863251.shtml
  https://www.gamespress.com/PUBG-MOBILE-ANNOUNCES-BREAKTHROUGHS-AND-PROGRESS-OF-ANTI-CHEATING
- Tencent ANOGS/ACE environment-detection reverse-engineering (no
  MediaProjection-specific detector documented):
  https://deepwiki.com/arx-oioi/-AntiCheat-Anogs-Tencent-/2.3-environment-and-emulator-detection
