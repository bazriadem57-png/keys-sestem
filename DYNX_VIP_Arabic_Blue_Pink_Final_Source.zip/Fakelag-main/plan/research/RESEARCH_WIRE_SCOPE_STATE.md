# RESEARCH_WIRE_SCOPE_STATE.md — wire-level scope/ADS state, and reliable world state

Research deliverable. Pure read-only study: no code changed, no builds run.
Written 2026-09 (research round for the input-side aim-assist plan).

---

## Scope

Two questions, in my own words:

1. **Is scope/ADS (sniper-scope) state visible on the wire today, with zero new
   decoding?** The aim-assist plan needs to know when the player is looking
   down a scope so the one-shot head swipe can fire (and so swipe calibration
   can switch — each scope state has its own sensitivity,
   `docs/AIM_PLAN.md:86-89`). The three options on the table were a manual
   toggle, extracting scoped-FOV from APK asset bundles, or recognising the
   reticle from screen capture (expensive, adds a MediaProjection permission).
   If scope state is already carried in packets the app decodes — especially
   the player's own outbound stream — screen recognition is unnecessary. This
   required enumerating every decoded field of Cmd 2001 both directions, the
   equipment commands (121/118), the PRI property stream (1900), and the full
   outbound command catalogue.

2. **During a long freeze, do spared RELIABLE world-state packets ever move a
   frozen enemy in steps?** `FreezeFilter` withholds inbound world-state while
   freeze is on but never withholds a RELIABLE message (dropping one starves
   its ack; the server retransmits forever — the suspected mid-match kick).
   The freeze-lock design must choose: hold HARD (ignore spared updates —
   pure snapshot) or hold SOFT (apply them, matching what the game renders).
   That choice needs data: how often do world-state commands actually arrive
   reliable, per command, per capture?

---

## Method

### Files read (paths as in the tree; note on stale paths)

- `docs/SOURCE_MAP.md` — layout + old→new translation. **Its own line 7 is
  stale**: it names the module root `com/fakelag/cryhard8/`, but the live tree
  is `fakelag/fakelag-beta/app/src/main/java/com/nuvola/app/` (the 104-file
  glob confirms; every path below is under that root).
- `fakelag/fakelag-beta/app/src/main/java/com/nuvola/app/decode/body/Cmd.java`
  — command enum, `isWorldStateStream` gate, `isCombatFeedback`.
- `.../decode/body/CmdCatalogue.java` — the complete 1974-id reference
  (`COUNT` at :41, `INBOUND_COUNT = 1384` at :43).
- `.../decode/body/PositionSync.java` — outbound Cmd 2001 field constants and
  rewrite rules.
- `.../decode/body/PriSync.java`, `.../esp/PriTracker.java` — Cmd 1900
  grammar and every consumed property id.
- `.../esp/EspEngine.java` — `observeKeepalive` (:1025), `observePriSync`
  (:2406), `observeEquipment` (:2459), `observeBindPri` (:2487).
- `.../decode/body/BodyDecoderTable.java` — per-(cmd, direction) decode
  programs; the Cmd 106 dual-struct note (:28).
- `.../decode/frame/PacketFlags.java`, `UdpPacket.java` — wire Flags byte
  (0x01 encrypted, 0x02 zipped; reliability is NOT a Flags bit).
- `.../filter/FreezeFilter.java` — the 2003 claim and the spare-reliable rule.
- `fakelag/fakelag-beta/app/src/debug/java/com/nuvola/app/dev/capture/`
  `CaptureWriter.java` (file format), `CaptureAnnotator.java` (flag stamping),
  and `.../dev/capture/CaptureEvent.java` (flag bit values).
- Docs: `PROTOCOL_MASTER.md`, `GAME_CLIENT_CONSTANTS.md`,
  `IL2CPP_FINDINGS.md`, `COMBAT_AND_HEALTH.md`, `CMD_CATALOGUE.md`,
  `AIM_PLAN.md`.
- Tools (ripgrep only, small slices — never `json.load`):
  `tools/ff_cmd_catalogue.txt`, `tools/il2cpp/ff_inbound_registry.tsv`,
  `ff_outbound_registry.txt`, `ff_outbound_registry_full.txt`,
  `ff_outbound_classes.json`, `ff_deobfuscation_map.json`,
  `tools/verify_decode_maps.py`.
- `C:\Users\Tonyt\Videos\ZRT-Toolbox\Dump\dump.cs` (different build —
  structure/enums only, never addresses).

### Capture format and the reliable bit

`CaptureWriter.writeHeader` (`CaptureWriter.java:726-731`) fixes the columns:

```
seq ts_ms dt_us src dir decision phase match cmd cmdname flags peer sp dp len hexlen payload_hex note
```

`flags` is one whitespace-free hex token (no padding — `putHexInt`,
`CaptureWriter.java:657-669`). The capture-level flag bits are defined in
`CaptureEvent.java:25-32` and printed in every file header
(`CaptureWriter.java:730-731`): `01=PARSED 02=CRC_OK 04=RELIABLE 08=ENCRYPTED
10=DECRYPTED 20=ZIPPED 40=LEN_MATCH 80=PRESOLVER`. **The reliable bit is
0x04** (`F_RELIABLE = 1 << 2`, `CaptureEvent.java:27`). It is stamped on the
writer thread from `MsgKey.headerSizeOf` — reliable ⟺ 10-byte header
(`CaptureAnnotator.java:111-117`) — a plaintext framing fact, independent of
the per-session header permutation. This is the *capture* flag namespace, not
the wire `Flags` byte (which only carries encryption/zip, `PacketFlags.java:29-48`).

Counting method: stream each file line by line, skip lines starting with `#`,
split on single spaces, require ≥11 tokens, take `dir` = token 5 (1-based),
`cmd` = token 9 (must be all digits; a non-numeric cmd means the annotator
never resolved the id — counted separately as `nonnum`), `flags` = token 11
parsed as hex, then tally `(dir, cmd) → (total, count(flags & 4 ≠ 0))`.

**Validation against the FreezeFilter claim**: the javadoc
(`FreezeFilter.java:57-64` and :172-199) states Cmd 2003 arrives reliable 7
times against 609 unreliable in
`captures/dev_20260916/capture_raw_20260916_214646.txt`. My count on that
file: `IN|2003 total=616 rel=7` — 616 − 7 = **609 unreliable. Exact match.**
The method was trusted everywhere else only after this check.

### Captures sampled

Six files across six days, all in the post-rewrite v2 line format (the
pre-2026-09-12 files in `captures/device_pull_20260910/dev_logs/` use the old
column set `seq ts phase dir decision dip sp dp len type family kind` — no
cmd/flags columns — and cannot be counted by this method; excluded, see Open
items):

| file | size | rows | note |
|---|---|---|---|
| `captures/device_pull_20260910/dev_logs/capture_raw_20260908_205830.txt` | 16.6 MB | 120 000 | old format, excluded |
| `captures/device_pull_20260910/dev_logs/capture_raw_20260910_155351.txt` | 5.1 MB | 29 652 | old format, excluded |
| `captures/phone_aim3/capture_raw_20260912_150936.txt` | 1.7 MB | 4 454 | short session |
| `captures/pull_20260915_post_reorg/capture_raw_20260915_151018.txt` (+`_001`) | 33.6 MB + 4.3 MB | 90 854 + 10 703 | two parts, one session |
| `captures/pull_20260915_postupdate/capture_raw_20260915_182250.txt` (+`_001`) | 33.6 MB + 5.2 MB | 126 585 | part 1 counted |
| `captures/dev_20260916/capture_raw_20260916_214646.txt` | 29.5 MB | 86 750 | the FreezeFilter verification file |
| `captures/dev_20260917/capture_raw_20260917_054133.txt` | 32.9 MB | 99 196 | full match |

---

## Findings — Question 1 (scope state on the wire)

### 1.1 Cmd 2001 field map, both directions — complete; NO scope field exists (PROVEN)

Outbound (own 10 Hz report), instruction-level reversal in
`docs/IL2CPP_FINDINGS.md:321-343` (class `message.ACDHGKMPIDJ::Serialize`
@ `0x047cb4c4`, sole send site `0x078CF1D4`), cross-checked against
`docs/PROTOCOL_MASTER.md:156-181` (wire table) and `PositionSync.java:59-163`
(the fields the app actually reads/writes):

| idx | meaning | encoding | read by app? |
|---|---|---|---|
| h | PlayerID (object handle; low 24 bits = own entity id) | LEB128 | EspEngine.java:1068-1071 |
| v0–v2 | position X, UP, Z — **millimetres** (UNITS_PER_METRE = 1000) | zigzag int | vPosX/Z/Y :1037-1039 |
| v3–v5 | aim direction #1 = `GetAimRotation()*forward` ×100 — the **un-lagged** aim (shorts, ~0.57°) | zigzag short | not decoded (candidate; GAME_CLIENT_CONSTANTS.md:215-230) |
| v6–v7 | ground move direction (the stick) ×100; (0,0) = no input — **not pose fields** | zigzag short | not decoded by 2001 path; constants exist `PositionSync.java:92-94` |
| v8–v10 | velocity, cm/s (≡ displacement/0.099 s) | zigzag short | not in keepalive path |
| v11 | `EPHYSXSTATE_*` movement state (see 1.2) — EspEngine reads it as `airborne` | RAW byte | :1040, :1085 |
| v12 | `EPHYSXPOSE_*` pose — EspEngine calls it `stateEnum` | RAW byte | :1041, :1086 |
| v13–v15 | aim direction #2 = `GetAuxAimRotation()*forward`, lag-lerped — **the camera forward**, float32, \|v\| = 1.000000 | 3 raw f32 (as varint bits) | :1042-1044, :1090-1094 |
| v16 | moving-platform id (non-zero ⇒ v0–v2 is platform-relative) | LEB128 ushort | not read in keepalive; `PositionSync.java:107` |
| v17 | low-gravity area flag | RAW byte | not decoded |
| v18 | client RTT estimate ms (garbage before `m_StartShowTime`) | LEB128 ushort | :1045, :1097-1105 |
| v19 | UGC only | RAW byte | not decoded |
| v20 | bezier-slide path pos \| slideId<<24 — **NOT a mount handle** (retracted) | LEB128 uint | retraction EspEngine.java:1106-1112 |
| v21 | snowslide side / lobby voice (can exceed 127!) | RAW byte | not decoded |
| v22 | client ms clock, +99/packet | LEB128 uint | :1046, :1096 |

Inbound 2001 (per-entity, ~5 Hz): structurally a one-record chain —
`Cmd.java:163-169`; the self-echo is byte-identical to the outbound keepalive
(`PROTOCOL_MASTER.md:212-214`).

Remote-player chain records (Cmd 2012, and 2001-inbound) carry **no weapon or
sight field**: the 14-field record is [id, X, h, Y, vX, vH, vY, bodyYaw u8,
aimYaw u8, aimPitch i8, mode, state, reserved0, reserved0] with the trailing
region exactly 7 fixed bytes (`PROTOCOL_MASTER.md:490-518`); fields 12/13 are
zero in 99.5–100% of 89 062 records, and §4.6 (`PROTOCOL_MASTER.md:566-585`)
proves by byte budget + exhaustive sweep that **no unexplained region exists**
in the remote record — nothing is hidden there, scope included.

### 1.2 v11/v12 enums enumerated — no ADS/scope member (PROVEN for the enum)

From `dump.cs` (different build, enum *membership* is structure — bridged by
name only):

- `EPHYSXSTATE_*` (v11): WALKING 0, FALLING 1, PARACHUTING 2, ONBOARD 3,
  SKYDIVING 4, HITFLY 5, SWIMMING 6, ONSTROP 7, FOOTBALL 8, JETFLY 9,
  GLIDING 10, ONGRAPPLINGHOOK 11, SKATEBOARDING 12, ONFERRISWHEEL 13,
  FLIGHTROAM 14, FAITHJUMPING 15, SWING 16, FORCEMOVING 17, SPRINT 18,
  SlideRunning 19, SlideFalling 20, PASSIVEMOVING 21, COUNT 22.
- `EPHYSXPOSE_*` (v12): STANDING 0, CROUCHING 1, DASHING 2, CREEPING 3,
  SWIMDASH 4, SKYDIVING 5, CROSSOVER 6, CLIMBOVER 7, KNOCKDOWN 8,
  SWIMSURFING 9, HIGHFALLING 10, LOWFALLING 11, JETFLYRUSH 12,
  SECONDFALLING 13, SITTING 14, CATAPULTFALLING 15, CATAPULTSTANDING 16,
  GLIDING 17, GLIDEFALLING 18, FOUNTAINFALLING 19, HUMANTIREFALLING 20,
  PARTYDANCE 21, FLIGHTROAMRUSH 22, CANNONSTANDING 23, PLATFORM_FALLING 24,
  JUMPPADFALLING 25, STROPFALLING 26, SLIDE_OFF_FALLING 27, DASH_FALLING 28,
  FAST_FALLING 29, SNOWSLIDE_GRAB 30, PARACHUT_FALLING 31,
  SWIMMINGSURFDASH 32, GB_FOOTBALL_FLY 33, BT_TELEPORT 34, FOLLOWING 35,
  CARRYING 36, BEING_CARRIED 37, COUNT 38.

**38 pose values, zero scoping/ADS/sight members.** The "v12 state enum" is a
locomotion pose, nothing more. Wire-vs-enum caveat: the client remaps v11
through `KANJBNIANHC::MBOHNCMOJDE` (wire == enum for 1–16, then shifted;
WALKING/ONFERRISWHEEL/PASSIVEMOVING all encode as wire 0 —
`PositionSync.java:109-124`). Also note v11 = 0 does not mean "grounded and
idle" in the app's `airborne` reading — EspEngine.java:1085 treats any
non-zero as airborne, which is right for falling/parachute but also fires for
SWIMMING/HITFLY.

### 1.3 THE FINDING: Cmd 137/138 `RUDP_START_SNIPER` / `RUDP_STOP_SNIPER` — the scope toggle is on the wire, outbound, and needs zero decoding (PROVEN on the wire)

- Names, straight from the game's own metadata:
  `tools/ff_cmd_catalogue.txt`: **`RUDP_START_SNIPER = 137`**,
  **`RUDP_STOP_SNIPER = 138`**.
- **The client SENDS them.** Outbound census (this research, flags&4 count):

  | capture | OUT 137 total/rel | OUT 138 total/rel |
  |---|---|---|
  | phone_aim3 20260912_150936 | 2/2 | 2/2 |
  | pull_20260915_post_reorg 151018 | 60/60 | 60/60 |
  | pull_20260915_post_reorg 151018_001 | 19/19 | 19/19 |
  | pull_20260915_postupdate 182250 | 25/25 | 25/25 |
  | dev_20260916 214646 | 45/45 | 45/45 |
  | dev_20260917 054133 | 91/91 | 91/91 |

  Perfectly balanced START/STOP pairs in every capture (no stuck state), every
  packet reliable-and-encrypted (flags `0x5F`), 26 bytes total, sent to the
  match server (dp 10017/10014 class). Sampled pair intervals: 0.4 s – 3.4 s —
  exactly scope-tap cadence.
- Direction and handler topology: the inbound handler registry has **no**
  137/138 handler for the live ids, but it does have
  **`RUDP_START_SNIPER_FOR_CLIENT_REPLAY` = 1522** and
  **`RUDP_STOP_SNIPER_FOR_CLIENT_REPLAY` = 1523**
  (`tools/il2cpp/ff_inbound_registry.tsv` rows 1522–1523) — the server
  re-publishes scope transitions, i.e. the protocol treats scoping as a
  server-visible, replayable event, which is what you would expect only if
  137/138 announce it.
- Sender class: the full send-site registry maps 138 to
  `COW.GamePlay.FDAEPHMIEPC::IKCDBOOLKLE+0x4b8`
  (`tools/il2cpp/ff_outbound_registry_full.txt`), and the project's own
  deobfuscation map resolves `FDAEPHMIEPC` → **"Weapon"**
  (`tools/il2cpp/ff_deobfuscation_map.json`). The *Weapon* object notifies the
  server that its sniper/scope mode changed. (137's send site is not in the
  registry files — it presumably reaches Send through a path the scan
  unresolved, 4/731 sites; the wire presence above is not in doubt.)
- Message body: class `IBNFEDBKMIO : UDPClientMessageBase` with **empty
  `Serialize`/`UnSerialize`** (`tools/il2cpp/ff_outbound_classes.json`) — a
  pure signal. The 26 captured bytes are the 10-byte reliable header plus a
  constant envelope (first bytes vary only by the per-session mask; the
  trailing 20 bytes are byte-identical across all sampled packets of a
  session). **The cmd id alone IS the state: 137 = scoped-in edge, 138 =
  scoped-out edge.**
- Not read by the app today: no Java file references 137/138 (grep over
  `com/nuvola/app` returns only catalogue data). No new *decoding* is needed —
  only a cmd-id observer on the outbound path, both of whose inputs (cmd id,
  reliable bit) `PacketPipeline`/`CaptureAnnotator` already produce for every
  packet.

Cross-check against the binary's camera work: scoping is client-visual only —
"**ADS / scope does NOT change FOV.** No aim/sight/scope FOV path exists in
code outside UGC. `COW.ESightAmplifyRatio` (X1/X2/X4/X8) never reaches a
camera" (`docs/GAME_CLIENT_CONSTANTS.md:99-107`), and scoped sensitivity is
`v *= 0.2 * scopeAttachmentFactor` in the touch pipeline
(`GAME_CLIENT_CONSTANTS.md:341`, :441-447). So no *inferred* signal (FOV,
aim-vector behaviour) can substitute for the explicit 137/138 edges — which is
precisely why finding them matters.

### 1.4 Equipment commands: what 121/118/1900 carry (PROVEN)

- **Cmd 121 `RUDP_EQUIPMENT_CHANGED`, inbound only** (0 outbound in any
  census). Parsed at `EspEngine.java:2459-2474`: `v0` = entity handle (low 24
  bits), then up to 10 varints collected as an unordered **value set**
  (`EQUIP_SCAN = 10`, :2441). No named scope field; the set carries the
  inventory-instance id and weapon id halves used for the owner join
  (`PriTracker.java:46-56`, measured 28/28 agreement with Cmd 118). Counts in
  dev_20260916: 2 284 inbound, all reliable.
- **Cmd 118 `RUDP_BIND_PRI`, inbound only, 100% reliable.** Parsed at
  `EspEngine.java:2487-2505`: leading varint is **twice** the record count
  (verified 365/365), then `(U owner, B type, U packedEntity)` records;
  `type == 1` = player, and `packedEntity = (squad<<24)|slot` is the
  server's authoritative friend/foe answer (`PriTracker.java:324-367`).
  No weapon/scope field.
- **Cmd 124 `RUDP_ATTACHMENT_CHANGED`, inbound only** (1 289 in
  dev_20260916, all reliable) — attachment *changes* (a sight was mounted),
  not scope *use*. Never decoded by the app (no reader).
- **Cmd 1900 `RUDP_VAR_SYNC_PRI_DATA`, inbound, 100% reliable in every
  sampled capture** (13 530 / 13 531 / 1 568 / 12 992 / 10 691 / 783 —
  order-of-magnitude above the "0.72 Hz" in `Cmd.java:41`; treat that rate
  claim as stale). Grammar `PriSync.java:15-34` (owner varint, u16-LE
  blockLen, then `[u8 varId][varint value]` records), authority
  `COMBAT_AND_HEALTH.md:43-56` (6 709/6 709 exact-parse). The decoder is
  generic: **every** varId is already delivered to
  `EspEngine.observePriSync` (`EspEngine.java:2406-2438`). `PriTracker`
  consumes only 0 (CUR_HP), 1 (MAX_HP), 4 (ITEM_ON_HAND), 6/7 (EP)
  (`PriTracker.java:200-244`) — **everything else, including varId 12 and 21,
  is decoded and then silently dropped.**
- The dump.cs property enum (`message.NIPHKJAOKGI`, PLAYER namespace) has
  **`EPRI_PLAYER_SIGHTING_ID = 12`** and **`EPRI_PLAYER_FIRING_STATUS = 21`**
  (also `EPRI_PLAYER_ITEM_ON_HAND = 4`, already CONFIRMED on the wire as
  `(inventoryItemId<<32)|weaponId`, `COMBAT_AND_HEALTH.md:66`). varId 21 is
  wire-CONFIRMED as {0,1,2} n=2 159 (`COMBAT_AND_HEALTH.md:67`,
  `PriSync.java:61`); varId 12 is named but **not yet measured** — see
  Verdicts. Note `CMD_CATALOGUE.md:124-135` predates these two names.

### 1.5 Outbound catalogue: everything the client sends (PROVEN on the wire)

Per-capture outbound census (top ids; `total/`prefix = reliable count):

| cmd | name | per-match volume | reliable? |
|---|---|---|---|
| 2 | UDP_ACK | 16k–31k | n/a (transport) |
| 2001 | UDP_PLAYER_STATE_SYNC | 4.8k–11.4k | never |
| 3 | UDP_PING | 0.5k–1.2k | never |
| 2000 | UDP_SYNC_SERVER_TIME (echo) | 0.3k–0.6k | never |
| 2006 / 2069 / 2002 | mounted own-position carriers | 0.1k–1.1k | never |
| **104** | RUDP_START_FIRE (send sites `PlayerNetwork::StartFiring/OnWeaponLift/...`) | 11–134 | always |
| **105** | RUDP_STOP_FIRE | 16–310 | always |
| **106** | RUDP_TAKE_DAMAGE — **BOTH directions**, different structs: 22-field outbound / 8-field inbound (`BodyDecoderTable.java:28`; inbound layout `IL2CPP_FINDINGS.md:436-444`: attacker, victim, damage, SP-damage, weapon(zz, negative=environmental), buff id, ESpecialHitType, hitBodyPart) | 16–82 OUT | always |
| **108** | RUDP_CHANGE_INVENTORY_ON_HAND, send site `PlayerNetwork::SwapWeapon` | 13–122 | always |
| 111/113 | pickup / use inventory | 5–99 | always |
| **133/134** | RUDP_START_RELOAD / STOP_RELOAD (`SendStartReload`/`SendFinishReload`) | 4–31 | always |
| **137/138** | RUDP_START_SNIPER / STOP_SNIPER | 2–91 | always |
| 1370s/148/160/222/513/551/1086 | map-mark, projectile, icewall damage, quick-chat, training damage | sparse | always |

No weapon-switch *state* stream, no reload state, no sight-attachment state,
and **no other scoping-like message exists outbound** — searches of both
outbound registries for scope/sight/zoom/ADS send sites return only a map
"telescope" UI button (`UIGameBigMapSafeZoneChooseBtnController::OnTelescopeConfirmBtnClick`),
unrelated. Outbound is a pure command/edge stream plus the 2001-family state
reports; there is no outbound periodic state message other than 2001/2002/2006/2069.

---

## Findings — Question 2 (reliable world state)

### 2.1 Survey table (world-state gate set, per capture)

Gate set verified against `Cmd.isWorldStateStream` (`Cmd.java:390-409`):
**2001, 2002, 2003, 2009, 2012, 2014, 2016** (identical to the baked set in
`tools/verify_decode_maps.py`, `gates.world_state_stream`). Format: total /
reliable. `nonnum` = rows whose cmd never resolved (pre-solver window).

| capture (file stem) | dir | 2001 | 2002 | 2003 | 2009 | 2012 | 2014 | 2016 | nonnum |
|---|---|---|---|---|---|---|---|---|---|
| phone_aim3 20260912_150936 | IN | 25/0 | 23/0 | 0/0 | 0/0 | 197/0 | 0/0 | 0/0 | 435 |
| | OUT | 483/0 | — | — | — | — | — | — | |
| pull_20260915_post_reorg 20260915_151018 | IN | 6074/0 | 592/0 | 868/18 | 0/0 | 6031/0 | 0/0 | 0/0 | 1006 |
| | OUT | 11360/0 | 137/0 | — | — | — | — | — | |
| pull_20260915_post_reorg …_001 | IN | 813/0 | — | 94/1 | 0/0 | 812/0 | 0/0 | 0/0 | 69 |
| | OUT | 1545/0 | — | — | — | — | — | — | |
| pull_20260915_postupdate 20260915_182250 | IN | 3296/0 | 367/0 | 461/7 | 0/0 | 3250/0 | 0/0 | 0/0 | 55 896* |
| | OUT | 6551/0 | — | — | — | — | — | — | |
| dev_20260916 20260916_214646 | IN | 4618/0 | 2400/0 | **616/7** | 0/0 | 4644/0 | 0/0 | 0/0 | 895 |
| | OUT | 7853/0 | — | — | — | — | — | — | |
| dev_20260917 20260917_054133 | IN | 5796/0 | — | 369/5 | 0/0 | 5833/0 | 0/0 | 0/0 | 35 403* |

\* those two sessions have large pre-solver / unresolved windows (session
rotation bursts), which is also why their IN counts are lower than the
OUT 2001 counts suggest.

Reading of the table:

- **The enemy-position carriers (in 2001, in 2012) arrived reliable 0 times in
  ~40 000 inbound packets across six sessions.** Not once.
- **2002 (vehicles): 0 reliable** in every sample (3 759 inbound packets).
- **2003 (airdrops) is the only world-state id ever seen reliable**: 7/616,
  18/868, 1/94, 7/461, 5/369 — 0.8–2.1% of airdrop packets, 1–18 events per
  match. This matches the FreezeFilter's own numbers and its rate estimate
  0.0076/s (`FreezeFilter.java:186-189`).
- **2009, 2014, 2016 never appeared at all** in any sampled capture — on this
  server/mode mix the bot, position-only and aim-rotation streams are silent.
  The gate covers them, but there is no data to freeze on.

### 2.2 The 2003 verification (method proof)

`FreezeFilter.java:178-180`: "Cmd 2003 … arrives RELIABLE (flags=0x5F,
reliable+encrypted) 7 times against 609 unreliable" in
`captures/dev_20260916/capture_raw_20260916_214646.txt`. My count: total 616,
reliable 7 → unreliable 609. **Exact.** The counted flags token on those rows
is `5F` = PARSED|CRC_OK|RELIABLE|ENCRYPTED|DECRYPTED|LEN_MATCH (0x01|0x02|0x04|0x08|0x10|0x40)
— consistent with invariant 4 (`SOURCE_MAP.md:140-141`: reliable ⟺ TEA-encrypted).

### 2.3 Context that bounds the impact

- Freeze windows are short in practice: the measured session had 222 freeze
  toggles totalling **12 s out of 925 s** (`FreezeFilter.java:185-189`).
- Reliable world-state is airdrops only. Airdrops are world objects, not
  enemies; they do not affect enemy freeze-lock, and (if rendered at all) they
  are cosmetic markers.
- The spare-reliable rule itself is a transport-safety invariant, not a
  choice: `FreezeFilter.java:172-199` and hard rule 2 (`SOURCE_MAP.md:136-138`).

---

## Verdicts

**(a) Can scope/ADS state be observed from the wire TODAY with zero new
decoding? — YES, PROVEN.**
Outbound **Cmd 137 `RUDP_START_SNIPER` / Cmd 138 `RUDP_STOP_SNIPER`** carry the
scope edges explicitly — verified on the wire in six captures (45+45, 60+60,
19+19, 25+25, 91+91, 2+2 per session, 100% reliable, perfectly paired,
26-byte empty-bodied messages sent by the Weapon class,
`ff_outbound_registry_full.txt` + `ff_deobfuscation_map.json` → "Weapon").
The cmd id and reliable bit are both already computed for every packet on the
hot path (`PacketPipeline`/`CaptureAnnotator.java:111-117`), so a scope-state
latcher is a cmd-id comparison plus an if. **Screen recognition and APK asset
extraction are unnecessary for the on/off decision.** No FOV or aim-vector
inference is needed or even possible (`GAME_CLIENT_CONSTANTS.md:99-107`).

**(b) If more than on/off is needed — the ONE thing to decode next:**
**Cmd 1900 varId 12 `EPRI_PLAYER_SIGHTING_ID`.** Evidence it carries scope
identity: the name comes from the game's own PLAYER property enum
(`message.NIPHKJAOKGI`, dump.cs), the stream is per-player keyed and already
fully decoded end-to-end (`PriSync.decode` → `EspEngine.observePriSync`,
`EspEngine.java:2419-2437`) with varId 12 values arriving *today* and being
discarded by `PriTracker.onProperty` (`PriTracker.java:206-244`); sibling
varId 21 `FIRING_STATUS` is wire-CONFIRMED {0,1,2} n=2 159, so the namespace
is live and the encoding ("plain varint" like its neighbours) is known.
Expected payoff: which sight is equipped/selected (2x/4x/8x) per player, not
just per self — and possibly other players' scope state, since the server also
runs `…_FOR_CLIENT_REPLAY` echoes of it (ids 1522/1523). Cost: near zero — a
log-and-observe branch in `onProperty`. Cmd 137/138 give the *edges*; varId 12
would give the *level* (which magnification), cross-checkable against 137/138
timestamps in the same capture.

**(c) Hold-hard vs hold-soft for freeze-lock: HOLD-HARD, PROVEN safe on
today's wire.** Across six sessions (~40 k inbound world-state packets) the
enemy-position carriers (2001, 2012) and vehicles (2002) **never** arrived
reliable; the only spared reliable world-state is 2003/airdrops (0.8–2.1% of
airdrop packets, 1–18 per match) — world objects, not enemies. Therefore
*spared updates cannot move a frozen enemy, ever, in the measured data*: a
pure snapshot (hold-hard) and mirror-the-render (hold-soft) are
indistinguishable for enemy boxes, and hold-hard is the simpler, drift-free
choice for the aim assist (a frozen head that stays frozen). For airdrop
markers hold-soft would match the rendered game, but that is cosmetic and
orthogonal to the assist. Fraction of matches affected by the divergence:
~100% of matches contain a few reliable 2003s, but 0% of enemy tracks are
touched by them; the only behavioural cost of hold-hard today is a stale
airdrop marker during a freeze window (measured 12 s/925 s of freeze in the
reference session). Keep the FreezeFilter's spare-reliable behaviour exactly
as is — the lock decision belongs on the ESP side, not the filter.

**(d) The one measurement that settles the remainder:** a Training-Ground or
live controlled test logging **outbound cmd id + timestamp + which weapon is
held + which scope button was pressed**: (1) tap the scope button with a
non-sniper (SMG/AR with a low-magnification sight) — does 137/138 fire, or
only with sniper-class weapons? (2) fire 137/138 events against 1900 varId-12
updates captured in the same session — does varId 12 change on scope-in, and
does its value distinguish 2x vs 4x vs 8x? (1) validates using 137/138 as the
aim-assist gate for *any* scoped weapon; (2) decides whether per-magnification
calibration (each scope state has its own sensitivity,
`AIM_PLAN.md:86-89`, and scoped touch sensitivity is ×0.2,
`GAME_CLIENT_CONSTANTS.md:341`) can also be read off the wire. Both are pure
observation — no new decoding to build first.

---

## Open items

1. **137 semantics breadth (only unproven link in verdict (a)).** The wire
   proves the client sends START/STOP_SNIPER in balanced pairs; the name, the
   sending class (Weapon) and the replay echoes all say "sniper/scope mode".
   What is NOT proven: whether the scope button with a *non*-sniper weapon
   (red dot, 2x on an AR) also emits 137/138, and whether some characters'
   skills fire them. Settle with verdict (d)'s measurement.
2. **EPRI_PLAYER_SIGHTING_ID (varId 12) wire behaviour.** Named in dump.cs,
   never measured on the wire in this project's docs (`COMBAT_AND_HEALTH.md`
   confirms 0/1/2/4/21/31 only). It is already being decoded and dropped;
   measuring it is a logging change, not research.
3. **Cmd 137's send site is missing from `ff_outbound_registry_full.txt`**
   (4 of 731 sites unresolved there). Only 138 is attributed. Cosmetic — the
   wire evidence stands on its own — but the 137 send-site row would remove
   the last asymmetry.
4. **Pre-2026-09-12 captures are uncountable by the v2 method.** Old-format
   files (`captures/device_pull_20260910/dev_logs/capture_raw_2026090{7,8,9}_*`,
   `*_20260910_15*`, and the `phone_pull*` dirs) carry
   `seq ts phase dir decision dip sp dp len type family kind` with no cmd/flags
   columns; only the `type`/`family`/`kind` taxonomy exists (R = reliable?).
   The survey therefore rests on 6 sessions from 2026-09-12 onward. If
   someone wants the 0907–0910 window added, it needs a different parser keyed
   on the old family column.
5. **World-state ids 2009/2014/2016 never appeared** in any sampled capture,
   so their reliable rate is unknown (vacuously 0/N with N = 0). The gate and
   this survey both handle them; the data does not.
6. **CLAUDE.md's "330 capture directories" is stale**: `captures/` holds 38
   directories (recursive) plus loose per-session artifact files
   (`summary_*`, `bytemap_*`, `freeze_diff_*`, `unknown_*`). Only
   `capture_raw_*.txt` v2 files were eligible for this survey.
7. **Inbound 1900 rate**: the "~0.72 Hz" in `Cmd.java:41` and
   `CMD_CATALOGUE.md` is inconsistent with 13.5 k packets/match (≈5–6 Hz
   sustained) in the sampled sessions. Re-measure before relying on it; the
   reliable-rate conclusion is unaffected (1900 is not in the world-state
   gate).
8. **SOURCE_MAP.md line 7** names the module root `com/fakelag/cryhard8/`;
   the live tree is `com/nuvola/app/`. Anyone following the map's root
   literally lands nowhere. (Doc fix; not changed in this research pass.)
