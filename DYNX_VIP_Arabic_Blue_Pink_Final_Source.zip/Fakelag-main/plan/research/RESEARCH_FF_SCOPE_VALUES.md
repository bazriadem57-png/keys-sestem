# RESEARCH_FF_SCOPE_VALUES — public knowledge on Free Fire scope magnification, scoped FOV, and sensitivity

Compiled 2026-07 (research session). Method: web search (Exa) across wikis, datamine/APK-text
posts, cheat-config dumps, community guides, and measurement posts. Every numeric claim carries
a markdown source link and a date where findable. Confidence tags:

- **OFFICIAL** — a Garena statement, patch note, or in-game item text quoted verbatim by a source.
- **DATAMINED** — someone dumped game files (APK text, config, il2cpp) and published the value.
- **COMMUNITY-MEASURED** — someone measured behaviour in game (counts, screenshots, swipe tests).
- **ANECDOTAL** — guide/SEO consensus claims with no measurement behind them; use only as prior.
- **UNVERIFIED** — published value of unknown provenance, plausibly fabricated (cheat-config dumps).

Framing: research/pentest on the owner's own authorised Free Fire account (SunnyMod). This file
collects PUBLIC knowledge only, to cross-check what we will measure on-device. Nothing here was
obtained by testing against other players.

---

## Scope

The questions this document answers:

1. **Scope magnification truth.** Actual magnification factors of Free Fire's scopes — red dot,
   2x, 4x, 8x, plus weapon-native scopes (AWM/Barrett M82B/Kar98k/M24/SKS/VSS/SCAR-adjacent).
   Is "8x" a true 8x angular magnification or a nominal label with different real zoom?
2. **Does the camera FOV change when scoping?** Any datamined per-scope FOV values (mod-menu
   configs, Unity bundle dumps, cheat configs)? Any official statement? If nothing exists, this
   is documented as an explicit negative result.
3. **Per-scope sensitivity.** Defaults and slider ranges of the General / Red Dot / 2x / 4x /
   Sniper (AWM) / Free Look sliders; community relations between slider values and
   degrees-per-swipe; any formula or measurement posts.
4. **Sniper weapon list + built-in scope behaviour.** Which weapons have hard-coded scopes vs
   attachable; whether AWM aiming differs (breath, sway) in ways that affect a one-shot swipe.
5. **Community aim math.** "Drag distance to headshot" quantifications, cm/360-style or
   screen-rotation measures — the Free Fire equivalent of px-per-degree.

---

## Scope magnification table

**Headline finding: no public source gives a measured or datamined *true* magnification for any
Free Fire scope.** Every guide, wiki table, and datamine-adjacent post repeats the nominal label
(1x/2x/4x/8x). Whether the label equals true angular magnification is **UNSOURCED — needs
on-device measurement**. Our on-device measurement plan should treat the nominal value as a
hypothesis, not a fact.

| Scope | Nominal label | Best-sourced "real" magnification | Source(s) | Confidence |
|---|---|---|---|---|
| Red Dot | 1x / "no zoom" | 1x — "doesn't zoom your camera in at all; far-away enemies look exactly as small as without any scope" | [Free Fire Nation red-dot guide, 2026-06-30](https://freefirenation.com/free-fire-red-dot-scope/); [gurugamer scope list, 2020-10-18](https://gurugamer.com/mobile-games/free-fire-scopes-13633) | ANECDOTAL (consistent across 2020→2026 guides; no measurement, but functionally 1x is the only value consistent with all descriptions) |
| 2x Scope | 2x | 2x nominal — no measured value exists anywhere public | [Free Fire Nation attachments guide, 2026-06-24](https://freefirenation.com/free-fire-all-attachments-guide/); [sportskeeda scope list, 2020-08-20](https://www.sportskeeda.com/free-fire/list-free-fire-scopes); [gurugamer, 2020-08-30](https://gurugamer.com/mobile-games/free-fire-guide-a-list-of-all-scopes-in-the-game-12482) | ANECDOTAL — true factor **UNSOURCED — needs on-device measurement** |
| 4x Scope | 4x | 4x nominal — no measured value exists anywhere public | same three sources as 2x | ANECDOTAL — true factor **UNSOURCED — needs on-device measurement** |
| 8x Scope (Sniper) | 8x | 8x nominal — "8× zoom" repeated verbatim by every source; no screenshot-pair or FOV measurement found | [Free Fire Nation attachments guide, 2026-06-24](https://freefirenation.com/free-fire-all-attachments-guide/); [sportskeeda, 2020-08-20](https://www.sportskeeda.com/free-fire/list-free-fire-scopes); [BlueStacks sniping guide, 2024-01-16](https://www.bluestacks.com/blog/game-guides/free-fire-battlegrounds/free-fire-sniping-guide-en.html) | ANECDOTAL — true factor **UNSOURCED — needs on-device measurement** |
| Thermal Scope | unstated | "Varies (night vision)"; aiming distance described as shorter than 4x, i.e. plausibly between 2x and 4x | [Free Fire Nation attachments guide, 2026-06-24](https://freefirenation.com/free-fire-all-attachments-guide/); [gurugamer thermal vs 4x, 2020-10-17](https://gurugamer.com/mobile-games/free-fire-thermal-scope-vs-4x-scope-which-one-is-better-13658) | ANECDOTAL — true factor **UNSOURCED** |

Notes on conflicts and provenance:

- The nominal labels are at least item-text-adjacent (the in-game pickup names are literally
  "2x Scope" etc.), so the *labels* are OFFICIAL; only the *mapping label→true zoom* is unsourced.
- The only documents on the public web that look like config dumps with FOV-ish numbers are
  cheat-config PDFs on Scribd (see next section). None of them presents a credible per-scope
  magnification table, and their contents are largely garbled filler. We found **zero** reddit
  (r/FreeFireLoops) or XDA posts with a datamined zoom factor, and zero YouTube datamine videos
  quoting a real FOV per scope. This absence is itself the answer to Q1/Q2's datamine half.
- The VSS's built-in scope magnification is also **UNSOURCED** (see Weapon-native scopes).

---

## Scoped FOV findings

**Documented negative result: as of this search, no public source states Free Fire's camera FOV
in any scope state — not the unscoped value, not the scoped value, not a per-scope table.**
Nothing was found in: Unity bundle dumps, mod-menu configs, r/FreeFireLoops datamine posts,
Garena patch notes, or the Chinese/Indonesian guide ecosystem. Concretely:

1. **No OFFICIAL statement exists.** Garena's OB54 patch notes
   ([freefiremobile.com article 1673, 2026-06-23](https://www.freefiremobile.com/en/article/1673/))
   cover movement-wheel and skill-boost changes; no FOV/sensitivity-model changes are mentioned.
   Free Fire has no user-facing FOV slider (contrast PUBG/CODM), so there is no settings-screen
   value to document either.
2. **No DATAMINED FOV table exists publicly.** Searches for datamined FOV values returned only:
   - A Scribd cheat-config document listing keys like `DEFAULT_FOV=153`, `CUSTOM_FOV=256`
     ([scribd "custom value freefireth"](https://www.scribd.com/document/738422235/custom-value-freefireth))
     and per-gun `AIMFOV_OB40_gun_*_180` flags in another
     ([scribd "METAFF IOS"](https://www.scribd.com/document/725988597/METAFF-IOS)).
     **UNVERIFIED** — these are marketing documents for cheat panels; the numbers are garbled
     (hex soup, impossible values) and most plausibly fabricated or meaningless. Their only
     signal value: cheat authors do target an FOV-like *per-weapon* parameter named
     "AIMFOV", i.e. there is some per-gun FOV/aim-cone state in the client worth looking for
     in our own il2cpp work.
   - An emulator guide advising "use 16:9 resolution for wider FOV"
     ([videoreddit.edu.vn FF MAX guide, 2025-10-27](https://videoreddit.edu.vn/free-fire-max-best-sensitivity-settings-for-headshots-usa-2025/))
     — ANECDOTAL, low confidence, but consistent with FOV being derived from aspect ratio.
3. **Circumstantial COMMUNITY evidence that FOV (or the rotation model) does change per scope:**
   - "A 4x scope multiplies how much camera movement you get per finger swipe, so the same
     sensitivity values that felt smooth with a 2x will feel too fast with a 4x."
     ([Free Fire Nation attachments guide, 2026-06-24](https://freefirenation.com/free-fire-all-attachments-guide/)) — ANECDOTAL but mechanically specific.
   - The game ships *separate* sensitivity sliders per scope tier (Red Dot/2x/4x/Sniper), which
     only makes sense if the scoped camera moves differently per tier (OFFICIAL that the sliders
     exist; ANECDOTAL for the interpretation).
   - A dump-adjacent Scribd document claims FF Max config keys
     `SENSITIVITY_MULTIPLIER.(LOW ZOOM)=0.75` and `(HIGH ZOOM)=0.65` with
     `AIM_SENSITIVITY_TRANSITION_TIME=GRADUAL`
     ([scribd FF SetEdit Commands](https://www.scribd.com/document/848336465/FF-Setedit-Commands))
     — **UNVERIFIED** (garbled cheat doc), but if real it implies (a) two zoom classes, (b) a
     *gradual* (lerped) sensitivity/FOV transition on ADS, exactly the Unity
     `Camera.fieldOfView` lerp pattern. Treat as a hypothesis to test on-device, not a fact.
4. **Mechanism context (not FF-specific).** In Unity the standard ADS implementation is a lerp of
   `Camera.fieldOfView`, and true magnification relates to FOV by
   `zoomedFOV = 2·atan(tan(baseFOV/2)/magnification)`
   ([Unity Discussions: Understanding Gun Scopes & FOV, 2013-07-31](https://discussions.unity.com/t/understanding-gun-scopes-fov/77457)).
   Free Fire is an il2cpp Unity title (see repo `tools/il2cpp/`), so this is the expected
   implementation — but the actual FF constants are **UNSOURCED — needs on-device measurement**.

**Explicit UNSOURCED markers (nothing public found for any of these):**
- Unscoped camera FOV in degrees — UNSOURCED.
- Scoped camera FOV per scope (2x/4x/8x/thermal/red-dot) — UNSOURCED.
- Whether the ADS FOV transition is instant or lerped, and its duration — UNSOURCED (one
  UNVERIFIED cheat doc hints "GRADUAL").
- Whether weapon-native scopes (VSS, SKS/SVD/AC80 4x) use the same FOV as attachable scopes of
  the same label — UNSOURCED.

---

## Sensitivity under scope

### Slider set and scale (OFFICIAL structure, ANECDOTAL values)

Free Fire's sensitivity screen has six sliders plus gyroscope: **General, Red Dot, 2x Scope,
4x Scope, Sniper Scope (labelled AWM scope in older builds), Free Look**
([Free Fire Nation attachments guide, 2026-06-24](https://freefirenation.com/free-fire-all-attachments-guide/);
[mediaindonesia, 2026-09-18](https://mediaindonesia.com/teknologi/934796/sensitivitas-ff-auto-headshot-2026-rekomendasi-dpi-dan-kontrol-terbaik)).

**Slider range has changed between client versions — flag any old numbers you read:**

- Legacy scale: **0–100** (all 2020–2025 guides, e.g. sportskeeda 2023 values below).
- Current scale: **0–200**, described as replacing the old 0–100 system around the 9th-anniversary
  / OB53–OB54 era ([ar-pay, 2026-06-18](https://ar-pay.com/blog/en/news/free-fire-sensitivity-2026-0-200-scale-9th-anniversary/);
  [BitTopup guide, updated 2026-08-26, "OB54 live global 23–24 June 2026, Garena's 0–200 slider cap"](https://bittopup.com/article/Free-Fire-Sensitivity-Settings-Guide-3040-Better-Aim);
  [ffguide.site.je settings guide](https://ffguide.site.je/settings-guide/)).
  Note the official OB54 patch notes page does not call this out — the scale claim is
  ANECDOTAL-but-corroborated by four independent 2026 sources, not OFFICIAL.
  (BitTopup also notes sliders accept 1-point taps and that HUD share codes can carry
  sensitivity.)

**Factory defaults: UNSOURCED — needs on-device measurement.** No public source states the
fresh-install default value of any slider on either scale. Guides only publish *recommended*
values. (Cashify's walkthrough just says a value "shall be assigned" on first open — it never
names the numbers: [cashify, 2026-09-14](https://www.cashify.in/best-free-fire-max-sensitivity-settings).)

### What the community recommends (sample values, shows the shape — do not copy)

| Source (date, scale) | General | Red Dot | 2x | 4x | Sniper/AWM | Free Look |
|---|---|---|---|---|---|---|
| [sportskeeda, 2023-09-22, 0–100](https://www.sportskeeda.com/free-fire/free-fire-drag-headshot-guide-sensitivity-settings-tips) | >90 | 78 | 70 | 55 | 48 | 100 |
| [freefirehub pro settings, 2026-03-01, 0–100](https://freefirehub.com/news/free-fire-best-sensitivity-settings-2026-auto-headshot) (Badge99/Raistar/Ajjubhai/Vincenzo) | 100 | 90–100 | 80–100 | 75–85 | **47–60** | 70–82 |
| [freefirenation AWM guide, 2026-07-07, 0–100](https://freefirenation.com/free-fire-awm-gun/) | 90–100 | 80–90 | 75–85 | 70–80 | **50–65** | 80–90 |
| [freefirenation drag-headshot tips, 2026-05-16, 0–100](https://freefirenation.com/free-fire-drag-headshot-tips/) | 90–100 | 88–95 | 75–82 | 60–68 | **30–40** | 60–70 |
| [gamemarket.gg sniper masterclass, 2026-07-23, 0–100](https://gamemarket.gg/news/free-fire/sniper-masterclass-accuracy-tips-for-dominated-long-range-combat) | 60–70 | — | — | — | **15–30** | — |
| [ar-pay, 2026-06-18, 0–200](https://ar-pay.com/blog/en/news/free-fire-sensitivity-2026-0-200-scale-9th-anniversary/) | 185 | 175 | 160 | 140 | **~90** | 120 |
| [takiff OB54 baseline, 0–200](https://takiff.online/blog/best-ff-sensitivity-for-ob54) | 175–195 | 110–160 | 120–140 | 115–135 | **50–80** | — |

**Conflict flag:** "good" sniper values range 8–15 (keros.dwhite.eu, 2026-01-05,
[link](https://keros.dwhite.eu/dwhite-news/best-sensi-settings-for-all-weapons-in-free-fire-1767646680))
to 90–120 (sensitivitysettings.com 0–200 tables,
[link](https://sensitivitysettings.com/)). These are different scales, devices, and eras; the
only stable pattern across ALL sources is **Sniper ≪ 4x < 2x < Red Dot ≤ General**. For our
purposes the absolute numbers don't matter — what matters is that the user's slider settings are
user-chosen state the app cannot assume.

### Slider → degrees-per-swipe: community math

- **No published formula converts slider value to degrees-per-pixel or cm/360.** Nothing
  equivalent to mouse-sensitivity.com's converters exists for Free Fire
  ([mouse-sensitivity.com](https://www.mouse-sensitivity.com/) supports "zoom sensitivities" for
  many games; Free Fire is not among those we found documented).
- **COMMUNITY-MEASURED (crude) method that exists: full-screen-swipe 360° counting.** Vortex
  Gaming's OB50 guide: "Before setting DPI, check current sensitivity (measure the number of
  screen swipes)"; "Increase DPI by 100-150 and check the number of screen rotations (13-15
  times recommended)" ([vortexgaming.io, 2025-08-22](https://vortexgaming.io/en/postdetail/531131)).
  I.e. players calibrate by counting how many full-width swipes a 360° turn takes. This is
  directly reusable by us on-device as a px-per-degree probe.
- **Device DPI coupling.** Community consensus: system DPI shifts effective speed —
  "Default DPI (360–400): General 95–100; custom DPI (450–500): 85–90"
  ([sensitivitysettings.com](https://sensitivitysettings.com/); also sportsadda 480-DPI advice,
  [2026-07-02](https://www.sportsadda.asia/esports/features-esports/best-sensitivity-for-free-fire-one-tap-headshots-and-how-to-land-them/)).
  Relevant to us: our test device runs a **398 density override, not the reported 480**
  (repo CLAUDE.md), so any px-per-degree constant measured on it is device-specific anyway.
- **Zoom multiplies camera movement per swipe; the per-scope sliders compensate.**
  [Free Fire Nation attachments guide, 2026-06-24](https://freefirenation.com/free-fire-all-attachments-guide/)
  states this explicitly for 2x→4x. ANECDOTAL but mechanically load-bearing: under scope,
  deg-per-px = f(slider, zoom class) — two knobs, both user- or game-set.
- **Drag-length folklore (COMMUNITY consensus, not a measurement protocol):** drag distance
  scales inversely with target apparent size — point-blank = long drag, 25–50 m = "very short",
  50 m+ = "micro-nudge only"
  ([freefirenation drag tips, 2026-05-16](https://freefirenation.com/free-fire-drag-headshot-tips/));
  one-tap drag ≈ 1–2 cm thumb travel with a 47–51 % fire button
  ([freefirehub, 2026-03-01](https://freefirehub.com/news/free-fire-best-sensitivity-settings-2026-auto-headshot)).
  No post converts these to px or degrees.

---

## Weapon-native scopes

Sniper/marksman weapons and their scope behaviour. Damage/availability per Liquipedia and
Free Fire Nation (values differ slightly between patch eras; not load-bearing for us).

| Weapon | Class | Scope at pickup | Scope swappable? | Notes relevant to a one-shot swipe | Source(s) |
|---|---|---|---|---|---|
| AWM | Sniper (airdrop; also CS shop) | **8x pre-attached** | Yes (scope slot) | Bolt-action; headshot ×2.5 → one-shots any helmet; "Good for Stationary Targets" (Liquipedia). Garena ships a **"Hold Fire to Scope"** quick-sniping setting (hold fire = auto scope-in, fire on release) that changes *fire/scope ordering* | [Liquipedia AWM](https://liquipedia.net/freefire/AWM); [freefirenation AWM, 2026-07-07](https://freefirenation.com/free-fire-awm-gun/); [BlueStacks, 2024-01-23](https://www.bluestacks.com/blog/game-guides/free-fire-battlegrounds/ff-sniper-rifles-weapon-guide-en.html) |
| Kar98k | Sniper (ground loot) | **8x pre-attached** ("Pre-attached with 8x") | Yes | Bolt-action; same 90 damage as AWM; slower action than AWM per BlueStacks | [Liquipedia Kar98K](https://liquipedia.net/freefire/Kar98K); [freefirenation Kar98k, 2026-07-04](https://freefirenation.com/free-fire-kar98k-gun/) |
| M24 | Sniper | **8x pre-attached** | Yes | "Lightweight sniper rifle that has high mobility and fast firing rate"; upgradable M24-I…M24-III tiers reported by one 2026 guide (single-source) | [Liquipedia M24](https://liquipedia.net/freefire/M24); [astute-betaserver, 2026-02-23](https://astute-betaserver.com/sensitivity-setting/) |
| M82B (Barrett) | Sniper | **CONFLICT:** one guide says "Pre-equipped: 8x Scope" ([freefirenation M82B, 2026-07-08](https://freefirenation.com/free-fire-m82b-gun/)), another says "M82B spawns without scope" ([freefirenation best-attachments, 2026-08-01](https://freefirenation.com/free-fire-best-attachments-for-every-gun/)) | Yes | Semi-auto (no bolt cycle); headshot ×~2.0 (won't one-shot Lv3 helmet); Gloo-wall penetration needs precise aim | both links in previous column |
| SKS | DMR | **4x fixed/built-in** | No (fixed) | "SKS has a fixed 4x" | [freefirenation Woodpecker guide, 2026-07-18](https://freefirenation.com/free-fire-woodpecker-gun/) |
| SVD | DMR/AR | **4x fixed** | No | "SVD has a fixed 4x" | same |
| AC80 | DMR | **4x pre-attached** | Unclear | "AC80 has a pre-attached 4x" | same |
| Woodpecker (M21) | DMR | **None** (iron sights) | Yes (scope slot critical) | Semi-auto; needs scope loot; commonly 4x | same |
| M14 | AR | None by default | Yes | AR-class; scoped manually | [gurugamer default-scope list, 2021-03-08](https://gurugamer.com/mobile-games/free-fire-which-weapon-comes-with-a-scope-by-default-16168) |
| SCAR | AR | None | Yes (scope slot) | "SCAR-adjacent" ARs have no weapon-native scope; BlueStacks' phrase "other rifles have pre-attached 4x scopes" refers to DMRs, not SCAR | [BlueStacks sniping guide, 2024-01-16](https://www.bluestacks.com/blog/game-guides/free-fire-battlegrounds/free-fire-sniping-guide-en.html) |
| VSS | SMG (integrated) | **Built-in scope + silencer** | **CONFLICT:** freefirehub says "No attachment slots — fully integrated" ([link](https://freefirehub.com/weapons/vss)); Liquipedia's VSS attachment table lists a Scope slot ("Increased Zoom intensity") ([link](https://liquipedia.net/freefire/VSS)); fandom says it "comes with a silencer, foregrip, and a scope" ([link](https://free-firebattlegrounds.fandom.com/wiki/VSS)) | — | VSS scope magnification **UNSOURCED** (no number anywhere) |
| M200 (new) | "precision rifle" | unknown | — | **DATAMINED** from OB55 APK text only: "powerful precision rifle designed for long-range eliminations" | [freefiremania, 2026-08-17](https://www.freefiremania.com.br/news/free-fire-ob55-7-weapons-found-in-the-game-files.html) |
| Hawk (new) | Sniper | unknown | — | **DATAMINED** APK text: "high-damage sniper … significant **scope elevation after shots**" — i.e. post-shot scope kick; matters for swipe correction after the first shot | same |

**AWM breath/sway:** we found **no public evidence that Free Fire snipers have a breath-hold or
sway mechanic** (contrast PUBG). Guides consistently describe FF sniping as sway-free and
bullet-drop-free: "bullets move in a straight line… it is literally point and shoot"
([BlueStacks, 2024-01-16](https://www.bluestacks.com/blog/game-guides/free-fire-battlegrounds/free-fire-sniping-guide-en.html)).
Liquipedia's AWM trait "Good for Stationary Targets" refers to *targets*, not shooter sway.
Negative result, moderate confidence — if sway existed, the guides that obsess over tiny
sensitivities would mention it. **Formally: UNSOURCED — verify on-device.**

**In-game aim assist interacts with swipes:** the "Aim Precision" setting at Default pulls the
crosshair toward the enemy torso during fire
([gamemarket.gg, 2026-07-23](https://gamemarket.gg/news/free-fire/sniper-masterclass-accuracy-tips-for-dominated-long-range-combat)),
and Indonesian-community "J-drag" posts explicitly describe exploiting the assist to finish the
climb to the head ([astute-betaserver, 2026-02-23](https://astute-betaserver.com/sensitivity-setting/)).
Any corrective swipe we inject shares the input pipeline with this assist.

---

## Cross-check implications for the plan

Assume the ESP projection currently uses the unscoped FOV and the plan adds one corrective swipe
toward a frozen enemy's head when the player fires.

1. **Projection error under 8x is not a small correction — it is a different camera.** If the
   nominal 8x were a true angular magnification and the unscoped horizontal FOV were F, the
   scoped FOV would be `2·atan(tan(F/2)/8)`. For any plausible F (50–70°), the scoped horizontal
   FOV lands around 6–9°, i.e. roughly **8× more pixels per degree** than unscoped. An enemy box
   computed with the unscoped FOV would sit off-screen by up to ~8 screen-widths at the frame
   edges. Even a 20 % error in assumed magnification displaces a near-centre target by
   hundreds of pixels. ⇒ **We cannot ship scope-aware assist on the nominal label.**
2. **Every constant that matters is unsourced — the on-device measurement list is mandatory:**
   - Scoped vs unscoped FOV per scope tier. Cheap probe: stand a fixed distance from a wall
     edge/landmark of known geometry, screenshot scoped and unscoped, compute the apparent-size
     ratio (true magnification) and derive FOV via the tangent formula above.
   - **px-per-degree per scope tier at the user's slider values** — reuse the community
     full-screen-swipe 360°-count method ([vortexgaming.io, 2025-08-22](https://vortexgaming.io/en/postdetail/531131))
     with scripted swipes of fixed px length; do it per scope AND per a couple of slider values
     to fit the curve.
   - **ADS transition behaviour**: is the FOV/sensitivity change instant or lerped, and how long?
     (One UNVERIFIED dump says `AIM_SENSITIVITY_TRANSITION_TIME=GRADUAL`.) Screen-record at high
     fps while scoping; a swipe fired mid-lerp lands on a moving px-per-degree target. Record a
     timestamp, not a boolean latched "scoped" flag (repo invariant: frozen-but-valid is
     indistinguishable from working).
   - **Centre invariance**: confirm the world point at screen centre is preserved across the
     scope transition (Unity scoped-FOV implementations usually guarantee it; if FF doesn't,
     our swipe vector needs an offset term).
   - **Hold-Fire-to-Scope ordering**: with that setting on, fire precedes full scope-in — the
     trigger for our corrective swipe may fire while the camera is still interpolating.
3. **The per-scope sensitivity sliders are user state, not constants.** px-per-degree under scope
   is a function of (slider value, zoom tier, device DPI, maybe refresh-rate smoothing per
   BitTopup). Either read the settings on-device (we own the account; the values are in the
   game's prefs), or calibrate in Training Ground at the user's actual settings — never bake a
   constant.
4. **Device caveat from the repo:** this device's density override is 398, not the 480 the panel
   reports, so any px constant must be derived from measured px-per-degree on that exact device,
   never from published "1–2 cm drag" folklore.
5. **What the sources *do* give us:** the zoom ordering (Sniper ≫ 4x > 2x > Red Dot = 1x), the
   8x-only-on-snipers pairing (AWM/Kar98k/M24 ship 8x; SKS/SVD/AC80 ship 4x; Woodpecker none),
   AWM's 2.5x headshot multiplier (making the head-freeze swipe high-value on AWM specifically),
   the "Hold Fire to Scope" input mode we must detect, and OB55's "Hawk" sniper datamined with
   post-shot scope elevation (future recoil offset in the swipe model).
6. **Coexistence with the stock aim assist:** the game already pulls toward the torso during fire
   ("Aim Precision: Default"). Our corrective swipe should model the assist as a second term in
   the aim dynamics (it can finish or fight our swipe); measure its effect during the same
   training-ground probes.

---

## Source list

Wikis / weapon data:
- https://liquipedia.net/freefire/AWM — AWM stats, "Pre-attached with 8x" (retrieved 2026-07)
- https://liquipedia.net/freefire/Kar98K — "Pre-attached with 8x"
- https://liquipedia.net/freefire/M24 — M24 exists, "Pre-attached with 8x"
- https://liquipedia.net/freefire/VSS — VSS attachment table (scope row conflict)
- https://free-firebattlegrounds.fandom.com/wiki/VSS — VSS ships with scope+silencer (page blocked to crawlers; via search snippet)
- https://freefirenation.com/free-fire-all-attachments-guide/ — 2026-06-24; scope table, zoom claims, sensitivity-per-scope explanation
- https://freefirenation.com/free-fire-red-dot-scope/ — 2026-06-30; red dot = 1x, no camera zoom
- https://freefirenation.com/free-fire-awm-gun/ — 2026-07-07; AWM stats, 8x pre-equipped, Hold-Fire-to-Scope, sniper sens 50–65
- https://freefirenation.com/free-fire-kar98k-gun/ — 2026-07-04; Kar98k 8x pre-equipped
- https://freefirenation.com/free-fire-m82b-gun/ — 2026-07-08; M82B "Pre-equipped: 8x"
- https://freefirenation.com/free-fire-best-attachments-for-every-gun/ — 2026-08-01; "M82B spawns without scope" (conflict)
- https://freefirenation.com/free-fire-woodpecker-gun/ — 2026-07-18; SKS/AC80/SVD fixed 4x; Woodpecker no scope
- https://freefirenation.com/free-fire-drag-headshot-tips/ — 2026-05-16; drag-length-by-range table
- https://freefirehub.com/weapons/vss — VSS integrated scope, no slots
- https://freefirehub.com/news/free-fire-best-sensitivity-settings-2026-auto-headshot/ — 2026-03-01; pro slider values, 1–2 cm drag folklore
- https://gurugamer.com/mobile-games/free-fire-scopes-13633 — 2020-10-18; scope list
- https://gurugamer.com/mobile-games/free-fire-guide-a-list-of-all-scopes-in-the-game-12482 — 2020-08-30; scope list
- https://gurugamer.com/mobile-games/free-fire-which-weapon-comes-with-a-scope-by-default-16168 — 2021-03-08; default-scope weapons
- https://gurugamer.com/mobile-games/free-fire-thermal-scope-vs-4x-scope-which-one-is-better-13658 — 2020-10-17; thermal < 4x aiming distance
- https://www.sportskeeda.com/free-fire/list-free-fire-scopes — 2020-08-20; scope list
- https://www.sportskeeda.com/free-fire/free-fire-drag-headshot-guide-sensitivity-settings-tips — 2023-09-22; 0–100-era values
- https://www.bluestacks.com/blog/game-guides/free-fire-battlegrounds/free-fire-sniping-guide-en.html — 2024-01-16; no bullet drop, point-and-shoot, 8x pre-attached
- https://www.bluestacks.com/blog/game-guides/free-fire-battlegrounds/ff-sniper-rifles-weapon-guide-en.html — 2024-01-23; Kar98k/AWM/M82B overview
- https://tools.nkbgaming.com/en/free-fire/weapons-database — OB53-era weapon DB (M24/M828 listings)
- https://www.freefiremania.com.br/news/free-fire-ob55-7-weapons-found-in-the-game-files.html — 2026-08-17; DATAMINED OB55 APK text (M200, Hawk scope elevation)

Sensitivity / measurement:
- https://ar-pay.com/blog/en/news/free-fire-sensitivity-2026-0-200-scale-9th-anniversary/ — 2026-06-18; 0–200 scale replaces 0–100, OB53/OB54 values
- https://bittopup.com/article/Free-Fire-Sensitivity-Settings-Guide-3040-Better-Aim — updated 2026-08-26; OB54 dates, 0–200 cap, slider behaviour
- https://ffguide.site.je/settings-guide/ — "FF now uses a 200 sensitivity system"
- https://takiff.online/blog/best-ff-sensitivity-for-ob54 — OB54 0–200 baseline
- https://vortexgaming.io/en/postdetail/531131 — 2025-08-22; screen-swipe/rotation counting method (closest thing to cm/360)
- https://sensitivitysettings.com/ — DPI↔slider formulas, RAM-tier tables
- https://www.mouse-sensitivity.com/ — cm/360 converters; no Free Fire entry found
- https://www.sportsadda.asia/esports/features-esports/best-sensitivity-for-free-fire-one-tap-headshots-and-how-to-land-them/ — 2026-07-02; 480-DPI advice, one-tap vs drag definitions
- https://www.cashify.in/best-free-fire-max-sensitivity-settings — 2026-09-14; settings walkthrough (no defaults published)
- https://gamemarket.gg/news/free-fire/sniper-masterclass-accuracy-tips-for-dominated-long-range-combat — 2026-07-23; Aim Precision assist, AWM sens 15–30
- https://mediaindonesia.com/teknologi/934796/sensitivitas-ff-auto-headshot-2026-rekomendasi-dpi-dan-kontrol-terbaik — 2026-09-18; Indonesian slider labels
- https://keros.dwhite.eu/dwhite-news/best-sensi-settings-for-all-weapons-in-free-fire-1767646680 — 2026-01-05; low-scale AWM values (conflict example)
- https://www.freefiremobile.com/en/article/1673/ — OFFICIAL OB54 patch notes (no sensitivity/FOV items)
- https://ff.garena.com/ — OFFICIAL news index (OB54 patch-note dates)

UNVERIFIED cheat-config dumps (cited only as artifacts, values not trusted):
- https://www.scribd.com/document/738422235/custom-value-freefireth — `DEFAULT_FOV=153` etc.
- https://www.scribd.com/document/725988597/METAFF-IOS — per-gun `AIMFOV_*_180` flags
- https://www.scribd.com/document/848336465/FF-Setedit-Commands — `SENSITIVITY_MULTIPLIER.(LOW ZOOM)=0.75`, `(HIGH ZOOM)=0.65`, `AIM_SENSITIVITY_TRANSITION_TIME=GRADUAL`

Unity mechanism context (not FF-specific):
- https://discussions.unity.com/t/understanding-gun-scopes-fov/77457 — 2013-07-31; magnification↔FOV formula
- https://gamedev.stackexchange.com/questions/167612/fov-value-scaling — zoomed-FOV scaling
