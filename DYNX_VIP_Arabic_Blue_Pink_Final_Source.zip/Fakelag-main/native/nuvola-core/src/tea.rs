//! QQ-TEA: 16-round TEA, little-endian words, wrapped in Tencent's outer
//! framing. Direct port of `com.nuvola.app.decode.crypt.Tea`.
//!
//! Java uses `int` (wrapping two's-complement) throughout with logical shifts
//! (`>>>`); `u32` wrapping arithmetic reproduces that bit-for-bit. The outer
//! framing is CBC-chained over 8-byte blocks:
//! `[padCount][pad zeros][2 salt zeros][plaintext][7 zeros]`. `rand()` is
//! stubbed to 0 in the shipped game binary, so the salt is always zero and the
//! seven-zero tail is a free decrypt oracle — a decrypt whose tail is not seven
//! zeros is rejected (wrong key / not QQ-TEA), returning `None`.

pub const ROUNDS: u32 = 16;
pub const DELTA: u32 = 0x9E37_79B9;
pub const SALT_LEN: usize = 2;
pub const ZERO_LEN: usize = 7;
pub const BLOCK_BYTES: usize = 8;
pub const KEY_BYTES: usize = 16;
/// Framing overhead: pad-count byte + salt + zero tail.
pub const FRAME_OVERHEAD: usize = 1 + SALT_LEN + ZERO_LEN; // 10
/// Shortest legal ciphertext (two blocks).
pub const MIN_CIPHERTEXT: usize = 16;

#[inline(always)]
fn le32(b: &[u8], i: usize) -> u32 {
    (b[i] as u32)
        | ((b[i + 1] as u32) << 8)
        | ((b[i + 2] as u32) << 16)
        | ((b[i + 3] as u32) << 24)
}

#[inline(always)]
fn put_le32(b: &mut [u8], i: usize, v: u32) {
    b[i] = v as u8;
    b[i + 1] = (v >> 8) as u8;
    b[i + 2] = (v >> 16) as u8;
    b[i + 3] = (v >> 24) as u8;
}

/// The four little-endian 32-bit key words, or `None` when the key is missing
/// or short. Compute once per session, never per packet.
pub fn schedule(key: &[u8]) -> Option<[u32; 4]> {
    if key.len() < KEY_BYTES {
        return None;
    }
    let mut k = [0u32; 4];
    for (i, w) in k.iter_mut().enumerate() {
        *w = le32(key, i * 4);
    }
    Some(k)
}

// The two Feistel round cores below live in the separate `nuvola-vmp` crate so
// amice's instruction-level VM_VIRTUALIZE pass can virtualize them in isolation
// (see native/nuvola-vmp + the RUSTC_WRAPPER). These thin `#[inline(always)]`
// shims keep every call site here unchanged and, being inlined, add nothing to
// the codegen — the actual (VMP'd) arithmetic is the cross-crate call. DELTA /
// ROUNDS remain declared above as the documented public algorithm constants.
#[inline(always)]
fn decrypt_words(v0: u32, v1: u32, k: &[u32; 4]) -> (u32, u32) {
    nuvola_vmp::tea_decrypt_round(v0, v1, k)
}

#[inline(always)]
fn encrypt_words(v0: u32, v1: u32, k: &[u32; 4]) -> (u32, u32) {
    nuvola_vmp::tea_encrypt_round(v0, v1, k)
}

/// Ciphertext length for a plaintext length: `align8(plainLen + 10)`.
pub fn qq_tea_encrypt_len(plain_len: usize) -> usize {
    let n = plain_len + FRAME_OVERHEAD;
    let r = n & 7;
    if r == 0 {
        n
    } else {
        n + (8 - r)
    }
}

/// Decrypt a QQ-TEA payload into `out`, verifying the seven-zero tail. Returns
/// the plaintext length (compacted to the front of `out`) or `None` when the
/// input is malformed or the tail check fails. `out` must be at least
/// `input.len()` bytes. Allocation-free.
pub fn qq_tea_decrypt(input: &[u8], k: &[u32; 4], out: &mut [u8]) -> Option<usize> {
    let len = input.len();
    if len < MIN_CIPHERTEXT || (len & 7) != 0 {
        return None;
    }
    if out.len() < len {
        return None;
    }

    // Block 0 decrypts straight through and seeds both chain registers.
    let c0 = le32(input, 0);
    let c1 = le32(input, 4);
    let (mut prev_plain0, mut prev_plain1) = decrypt_words(c0, c1, k);
    put_le32(out, 0, prev_plain0);
    put_le32(out, 4, prev_plain1);
    let (mut prev_cipher0, mut prev_cipher1) = (c0, c1);

    let mut i = BLOCK_BYTES;
    while i < len {
        let ci0 = le32(input, i);
        let ci1 = le32(input, i + 4);
        let (d0, d1) = decrypt_words(ci0 ^ prev_plain0, ci1 ^ prev_plain1, k);
        put_le32(out, i, d0 ^ prev_cipher0);
        put_le32(out, i + 4, d1 ^ prev_cipher1);
        prev_plain0 = d0;
        prev_plain1 = d1;
        prev_cipher0 = ci0;
        prev_cipher1 = ci1;
        i += BLOCK_BYTES;
    }

    let pad = (out[0] & 7) as usize;
    if len < pad + FRAME_OVERHEAD {
        return None;
    }
    let plain_len = len - pad - FRAME_OVERHEAD;
    let start = 1 + pad + SALT_LEN;
    for j in 0..ZERO_LEN {
        if out[start + plain_len + j] != 0 {
            return None; // not our key / not QQ-TEA
        }
    }
    if plain_len > 0 {
        out.copy_within(start..start + plain_len, 0);
    }
    Some(plain_len)
}

/// Encrypt `plain` into `out` with the QQ-TEA framing, returning the ciphertext
/// length (`qq_tea_encrypt_len`) or `None` when `out` is too small. Exact
/// inverse of [`qq_tea_decrypt`]. Allocation-free.
pub fn qq_tea_encrypt(plain: &[u8], k: &[u32; 4], out: &mut [u8]) -> Option<usize> {
    let p_len = plain.len();
    let enc_len = qq_tea_encrypt_len(p_len);
    if out.len() < enc_len {
        return None;
    }
    let pad = enc_len - p_len - FRAME_OVERHEAD;
    for b in out[..enc_len].iter_mut() {
        *b = 0;
    }
    out[0] = pad as u8; // rand() is stubbed to 0 in the game
    let body = 1 + pad + SALT_LEN;
    out[body..body + p_len].copy_from_slice(plain);

    let mut prev_d0 = le32(out, 0);
    let mut prev_d1 = le32(out, 4);
    let (mut prev_c0, mut prev_c1) = encrypt_words(prev_d0, prev_d1, k);
    put_le32(out, 0, prev_c0);
    put_le32(out, 4, prev_c1);

    let mut i = BLOCK_BYTES;
    while i < enc_len {
        let s0 = le32(out, i);
        let s1 = le32(out, i + 4);
        let d0 = s0 ^ prev_c0;
        let d1 = s1 ^ prev_c1;
        let (e0, e1) = encrypt_words(d0, d1, k);
        let c0 = e0 ^ prev_d0;
        let c1 = e1 ^ prev_d1;
        put_le32(out, i, c0);
        put_le32(out, i + 4, c1);
        prev_d0 = d0;
        prev_d1 = d1;
        prev_c0 = c0;
        prev_c1 = c1;
        i += BLOCK_BYTES;
    }
    Some(enc_len)
}
