//! Cmd 2012 entity-stream decoder — the ESP's position source. Pure-decode port
//! of the structured path in `com.nuvola.app.esp.EspEngine`
//! (`observeChainPacket` + `parseStructured`). The stateful half (tracking,
//! prediction, friend/foe classification, match-boundary reset, mounted-camera
//! echo) STAYS in Java and consumes the record list this returns.
//!
//! **2012 is plaintext** — no TEA, no session mask, no CRC. The decoder never
//! keys on the cmd id; it is a self-validating try-parse over the raw datagram,
//! driven by packet shape (`b8==0`, `b9` even, byte budget) and confirmed by an
//! exact terminal check. That end-check is the real validator: it is what
//! rejects heartbeats/ACKs/ciphertext that pass the cheap header gate.
//!
//! Wire grammar of one remote record (NOT a pure varint run — bytes 7/8/9 are
//! fixed-width; mis-decoding them as varints desyncs the whole walk):
//!
//! ```text
//!   id          LEB128 varint (NOT zigzag), gated 1..=64
//!   x, z, y     LEB128 varint, zigzag-encoded coords; RAW x gated >= 500
//!   vx, vz, vy  LEB128 varint, zigzag-encoded velocity
//!   bodyYaw     ONE RAW BYTE  (u8)        * 360/256 deg
//!   aimYaw      ONE RAW BYTE  (u8)        * 360/256 deg
//!   aimPitch    ONE RAW BYTE  (SIGNED i8) * PITCH_DEG_PER_LSB
//!   mode, state LEB128 varint (binary hints raw bytes; identical while <0x80 —
//!               `mdst_high` trips if either reaches 0x80, the 2002 field-8 trap)
//!   reserved x2 LEB128 varint, discarded (zero in >=99.5% / 100%)
//! ```
//!
//! A **self-echo** record (`id == own_id`) is instead 20 plain varints with NO
//! fixed-width block — the server echoing our own player. It carries no pose.
//!
//! Coordinates are stored RAW (the unsigned varint, as the Java stores in its
//! `long[]`); `zigzag_decode` gives signed game units at 1000 units/metre, frame
//! order (X, Z=height, Y) — byte-identical to the outbound 2001 keepalive.
//!
//! Verified vs **1139 real inbound chains** whose decoded ids+coords are
//! cross-checked against the device's own `entities_*.csv` decode
//! (`tests/data/chain2012_golden.json`), plus the self-echo and every rejection
//! path synthetically.

use crate::varint::{zigzag_decode, WireReader};

pub const CHAIN_HEADER: usize = 10;
/// Absolute frame floor (a chain can't be shorter than this) and the fixed
/// capacity of the record array. These are framing facts, not the licensed
/// decode parameters.
pub const CHAIN_MIN_LEN: usize = 20;
pub const RECORD_CAP: usize = 64;

/// The licensed decode parameters — the "how to interpret the 2012 chain"
/// knowledge that used to be hardcoded in the client. Delivered ONLY inside the
/// server's authenticated per-session `/config` envelope (see
/// `docs/SERVER_GATED_DECODE_DESIGN.md`); a production build carries no baked
/// copy, so a cracked offline client has no way to construct a valid one. The
/// decoder fail-closes (returns `None`, no records) unless it is armed with a
/// profile whose `valid_until` is still in the future.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ChainProfile {
    /// Largest accepted packet length.
    pub chain_max_len: usize,
    /// Largest accepted declared record count (must be <= `RECORD_CAP`).
    pub max_records: usize,
    /// Minimum bytes a single record can physically occupy.
    pub min_record_bytes: usize,
    /// Raw-varint floor for a record's X (rejects mis-framed starts).
    pub min_record_x: u64,
    /// Largest accepted entity id.
    pub max_entity_id: u64,
    /// Unix seconds after which this profile is refused. A value of 0 (the
    /// `Default`) always fails — "no profile" and "expired" are the same
    /// fail-closed state.
    pub valid_until: u64,
}

impl Default for ChainProfile {
    /// The fail-closed empty profile: `valid_until == 0` refuses every packet.
    fn default() -> Self {
        ChainProfile {
            chain_max_len: 0,
            max_records: 0,
            min_record_bytes: 0,
            min_record_x: 0,
            max_entity_id: 0,
            valid_until: 0,
        }
    }
}

/// Degrees per LSB for the two u8 yaw bytes (`360/256`).
pub const YAW_DEG_PER_LSB: f32 = 360.0 / 256.0;
/// Degrees per LSB for the signed pitch byte. The Java copy is `volatile` /
/// tunable ("exposed for confirmation by eye, not settled" — the tidy
/// `360/256=1.406` alternative can't be separated at the 5% level), so it is a
/// named default here, applied by the caller, not baked into the decode.
pub const PITCH_DEG_PER_LSB_DEFAULT: f32 = 1.29;

/// One decoded entity record. Coordinates/velocities are RAW (unsigned varint);
/// call `pos_signed` / `vel_signed` for zigzag-decoded game units. Pose is the
/// raw wire bytes; apply the scale constants at the render site.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct ChainRecord {
    pub id: u32,
    pub x: u64,
    pub z: u64,
    pub y: u64,
    pub vx: u64,
    pub vz: u64,
    pub vy: u64,
    pub body_yaw_raw: u8,
    pub aim_yaw_raw: u8,
    pub aim_pitch_raw: i8,
    pub mode: u32,
    pub state: u32,
    /// True for the own-player echo (20 varints, no pose block).
    pub is_self_echo: bool,
}

impl ChainRecord {
    /// Signed (zigzag-decoded) world position, order (X, Z=height, Y), in game
    /// units (1000 units/metre).
    pub fn pos_signed(&self) -> (i64, i64, i64) {
        (zigzag_decode(self.x), zigzag_decode(self.z), zigzag_decode(self.y))
    }
    /// Signed (zigzag-decoded) velocity triple (raw; per 99 ms sub-tick).
    pub fn vel_signed(&self) -> (i64, i64, i64) {
        (zigzag_decode(self.vx), zigzag_decode(self.vz), zigzag_decode(self.vy))
    }
    pub fn body_yaw_deg(&self) -> f32 {
        self.body_yaw_raw as f32 * YAW_DEG_PER_LSB
    }
    pub fn aim_yaw_deg(&self) -> f32 {
        self.aim_yaw_raw as f32 * YAW_DEG_PER_LSB
    }
}

/// A fully-validated 2012 chain: `count` records (allocation-free fixed array).
#[derive(Clone, Copy, Debug)]
pub struct Chain {
    records: [ChainRecord; RECORD_CAP],
    count: usize,
    /// True when any record's mode/state field reached 0x80 — the wire has
    /// crossed into territory where the varint/raw-byte reading of those two
    /// fields would diverge (see the module doc). Meaningful only because the
    /// terminal check already passed.
    pub mdst_high: bool,
}

impl Chain {
    pub fn records(&self) -> &[ChainRecord] {
        &self.records[..self.count]
    }
    pub fn len(&self) -> usize {
        self.count
    }
    pub fn is_empty(&self) -> bool {
        self.count == 0
    }

    /// Serialize the decoded records into `out` for the JNI handoff to Java —
    /// a `u16` count (little-endian) followed by `count` fixed-`RECORD_WIRE`-byte
    /// records, so the Java side reads them straight out of a direct `ByteBuffer`
    /// (the same zero-copy pattern as `crc7Seal`, no per-field JNI calls).
    /// Coordinates/velocities are the RAW varint values (as `parseStructured`
    /// stores them); Java applies zigzag/scale exactly as it does today, so the
    /// render path is unchanged. Returns the byte count written, or `None` when
    /// `out` is too small. Layout per record (all little-endian):
    /// `id:u32 | x,z,y:u64 | vx,vz,vy:u64 | body_yaw:u8 aim_yaw:u8 aim_pitch:i8
    /// flags:u8 | mode:u32 | state:u32` (flags bit0 = self_echo).
    pub fn serialize(&self, out: &mut [u8]) -> Option<usize> {
        let need = 2 + self.count * RECORD_WIRE;
        if out.len() < need {
            return None;
        }
        out[0] = self.count as u8;
        out[1] = (self.count >> 8) as u8;
        let mut p = 2;
        for r in self.records() {
            let rec = &mut out[p..p + RECORD_WIRE];
            rec[0..4].copy_from_slice(&r.id.to_le_bytes());
            rec[4..12].copy_from_slice(&r.x.to_le_bytes());
            rec[12..20].copy_from_slice(&r.z.to_le_bytes());
            rec[20..28].copy_from_slice(&r.y.to_le_bytes());
            rec[28..36].copy_from_slice(&r.vx.to_le_bytes());
            rec[36..44].copy_from_slice(&r.vz.to_le_bytes());
            rec[44..52].copy_from_slice(&r.vy.to_le_bytes());
            rec[52] = r.body_yaw_raw;
            rec[53] = r.aim_yaw_raw;
            rec[54] = r.aim_pitch_raw as u8;
            rec[55] = if r.is_self_echo { 1 } else { 0 };
            rec[56..60].copy_from_slice(&r.mode.to_le_bytes());
            rec[60..64].copy_from_slice(&r.state.to_le_bytes());
            p += RECORD_WIRE;
        }
        Some(need)
    }
}

/// Bytes per serialized record in the JNI handoff (see [`Chain::serialize`]).
pub const RECORD_WIRE: usize = 64;

/// Index just past `count` varints within `buf[i..end]`, or `None` when any is
/// truncated. Mirrors `EspEngine.skipVarints`.
fn skip_varints(buf: &[u8], mut i: usize, end: usize, count: usize) -> Option<usize> {
    for _ in 0..count {
        let mut done = false;
        let mut shift = 0u32;
        while i < end {
            let c = buf[i];
            i += 1;
            if (c & 0x80) == 0 {
                done = true;
                break;
            }
            shift += 7;
            if shift > 63 {
                return None;
            }
        }
        if !done {
            return None;
        }
    }
    Some(i)
}

/// Parse a raw 2012 datagram at `buf[off..off+len]`, gated on a server-issued
/// `ChainProfile`. `own_id` (>0) marks which id takes the 20-varint self-echo
/// shape; pass a value that never matches (e.g. -1) when the own id is unknown.
/// `now` is the current unix time in seconds.
///
/// **Fail-closed:** returns `None` (no records) unless armed with a profile whose
/// `valid_until` is still in the future — so a client with no live licensed
/// session decodes nothing, without ever affecting the render path. Returns
/// `None` for anything that is not a well-formed chain — never a partial result.
pub fn parse_with_profile(
    buf: &[u8],
    off: usize,
    len: usize,
    own_id: i32,
    profile: &ChainProfile,
    now: u64,
) -> Option<Chain> {
    // THE LEASH: no valid, unexpired server profile => decode nothing. A default
    // (valid_until == 0) profile always fails here.
    if profile.valid_until == 0 || now >= profile.valid_until {
        return None;
    }
    let max_records = profile.max_records.min(RECORD_CAP);
    // F4-safe bounds: no `off + len` add that could wrap usize.
    if len < CHAIN_MIN_LEN
        || len > profile.chain_max_len
        || off > buf.len()
        || len > buf.len() - off
    {
        return None;
    }
    let pkt = &buf[off..off + len];
    if pkt[8] != 0x00 {
        return None;
    }
    let b9 = pkt[9];
    if (b9 & 1) != 0 {
        return None;
    }
    let declared = (b9 / 2) as usize;
    if declared < 1 || declared > max_records {
        return None;
    }
    // A record is at minimum an id + three 1-byte varints; a packet that cannot
    // physically hold the count it declares is not a chain.
    if len < CHAIN_HEADER + declared * profile.min_record_bytes {
        return None;
    }
    // Records start after the two leading varints (zero-handle + count), which
    // are single bytes in the common case but need not be (b9==0x80 → 2-byte
    // count would shift the whole parse by one).
    let rec_start = skip_varints(pkt, 8, len, 2)?;

    let mut r = WireReader::new(&pkt[rec_start..]);
    let mut out = Chain {
        records: [ChainRecord::default(); RECORD_CAP],
        count: 0,
        mdst_high: false,
    };

    for _ in 0..declared {
        let id = r.u();
        if r.bad || id < 1 || id > profile.max_entity_id {
            return None;
        }
        let x = r.u();
        let z = r.u();
        let y = r.u();
        if r.bad || x < profile.min_record_x {
            return None;
        }
        let mut rec = ChainRecord {
            id: id as u32,
            x,
            z,
            y,
            ..ChainRecord::default()
        };

        if own_id > 0 && id == own_id as u64 {
            // Self-echo: 16 more varints, no fixed-width block.
            r.skip_u(16);
            if r.bad {
                return None;
            }
            rec.is_self_echo = true;
            out.records[out.count] = rec;
            out.count += 1;
            continue;
        }

        rec.vx = r.u();
        rec.vz = r.u();
        rec.vy = r.u();
        if r.bad {
            return None;
        }
        rec.body_yaw_raw = r.raw_byte() as u8;
        rec.aim_yaw_raw = r.raw_byte() as u8;
        rec.aim_pitch_raw = r.raw_byte() as i8; // signed on purpose
        if r.bad {
            return None;
        }
        let md = r.u();
        let st = r.u();
        r.u(); // reserved
        r.u(); // reserved
        if r.bad {
            return None;
        }
        if md >= 0x80 || st >= 0x80 {
            out.mdst_high = true;
        }
        rec.mode = md as u32;
        rec.state = st as u32;
        out.records[out.count] = rec;
        out.count += 1;
    }

    // The packet must end on its trailing tick varint: exactly 1..=3 bytes left.
    let consumed = r.pos();
    let left = (len - rec_start).saturating_sub(consumed);
    if !(1..=3).contains(&left) {
        return None;
    }
    Some(out)
}
