//! Cmd-id classification the packet filters branch on. Direct port of the
//! predicates in `com.nuvola.app.decode.body.Cmd` — ONLY the predicates and the
//! codes the drop/rewrite logic uses. The ~1900-entry `CmdCatalogue` name table
//! (Bucket-B knowledge) is deliberately NOT ported; nothing on the hot path
//! needs a human name, only these classifications.

// Named codes the filter logic references directly.
pub const UDP_ACK: u32 = 2;
pub const UDP_PING: u32 = 3;
pub const RUDP_TAKE_DAMAGE: u32 = 106; // Aim's Cmd-106 hit rewrite
pub const RUDP_MAPMARK_CHANGED: u32 = 148; // Mark's Cmd-148 pin rewrite
pub const UDP_PLAYER_STATE_SYNC: u32 = 2001; // own on-foot position (the rewritable one)

/// The whole reserved transport range (1..=99): hello/ack/ping/byebye/probe/
/// fragments. Freeze leaves this entire layer alone.
pub fn is_transport_layer(code: u32) -> bool {
    (1..=99).contains(&code)
}

/// Inbound streams carrying other players' positions (2001 + 2012). Non-reliable,
/// so dropping them owes the server nothing.
pub fn is_entity_stream(code: u32) -> bool {
    code == 2001 || code == 2012
}

/// Damage / death / health feed — the messages freeze must NOT swallow.
pub fn is_combat_feedback(code: u32) -> bool {
    matches!(code, 106 | 107 | 168 | 1900 | 2010)
}

/// Every OUTBOUND message that carries our own position. Cmd 2001 is on-foot;
/// the others are mounted variants. Withholding works on any (drop needs no body
/// parse); rewriting only works on 2001, whose body layout is decoded.
pub fn is_own_position_carrier(code: u32) -> bool {
    matches!(code, 2001 | 2002 | 2006 | 2031)
}

/// The mounted position carriers (own-position, but not the parseable 2001).
pub fn is_mounted_position_carrier(code: u32) -> bool {
    code != 2001 && is_own_position_carrier(code)
}

/// Every inbound stream that moves a world object on screen — the freeze drop set.
pub fn is_world_state_stream(code: u32) -> bool {
    matches!(code, 2001 | 2002 | 2003 | 2009 | 2012 | 2014 | 2016)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transport_layer_bounds() {
        assert!(is_transport_layer(1) && is_transport_layer(99));
        assert!(!is_transport_layer(0) && !is_transport_layer(100));
    }

    #[test]
    fn position_carriers() {
        assert!(is_own_position_carrier(2001));
        assert!(is_own_position_carrier(2002) && is_own_position_carrier(2006) && is_own_position_carrier(2031));
        assert!(!is_own_position_carrier(2012));
        // mounted = own-position but not 2001
        assert!(is_mounted_position_carrier(2002));
        assert!(!is_mounted_position_carrier(2001));
    }

    #[test]
    fn world_state_and_combat() {
        for c in [2001, 2002, 2003, 2009, 2012, 2014, 2016] {
            assert!(is_world_state_stream(c), "world state {c}");
        }
        assert!(!is_world_state_stream(106));
        for c in [106, 107, 168, 1900, 2010] {
            assert!(is_combat_feedback(c), "combat {c}");
        }
        assert!(!is_combat_feedback(2001));
        assert!(is_entity_stream(2001) && is_entity_stream(2012) && !is_entity_stream(2002));
    }
}
