//! Cmd 1900 `RUDP_VAR_SYNC_PRI_DATA` (and 1901, match-wide) keyed property
//! stream — where real player health actually lives. Direct port of
//! `com.nuvola.app.decode.body.PriSync`.
//!
//! The ESP used to invent health (start at MAX_HP, only decrement by damage *we*
//! dealt); real HP is a property update in this stream, not a state field.
//!
//! Grammar (authority `GCommon.ReplicationDataPool::SyncReplicationData`;
//! measured 6709/6709 packets parsing with exact byte consumption and zero
//! residue across three keyed sessions, plus 46/46 for Cmd 1901):
//!
//! ```text
//!   body   := group+
//!   group  := varint  ownerReplicationId   (1900 only; 1901 omits it)
//!             u16 LE  blockLen             ReadFixUInt16 — 2 RAW BYTES
//!             record*                      exactly blockLen bytes
//!   record := u8      varId                ReadByte — 1 RAW BYTE
//!             varint  value
//! ```
//!
//! Two traps: `blockLen` is two raw little-endian bytes and `varId` is one raw
//! byte — neither is a varint, and treating either as one desyncs the whole walk.
//! Everything else is LEB128 (including floats: the game's `ReadSingle` reads a
//! varint and reinterprets the bits), so an unknown `varId` is always skippable
//! as exactly one varint without losing framing.
//!
//! **56-bit value ceiling, preserved for parity.** The Java `varint` helper packs
//! (value, length) into one `long`, stealing the top 8 bits for the length, so
//! the value handed to the sink is masked to 56 bits. Ids 2/3/4 are
//! `(itemId << 32) | ...` packings that CAN exceed 56 bits; the Java truncates
//! them and so do we, byte-for-byte. HP/armour/EP (the fields this decoder exists
//! for) are all well under 56 bits, so nothing real is lost — but the ceiling is
//! reproduced exactly rather than silently widened, per the repo rule "keep old
//! readers' old answer".

/// EPRI player-namespace property ids (enum `message.NIPHKJAOKGI`, player type).
/// THE KEY NAMESPACE IS PER ENTITY TYPE — the same ordinal means something else
/// for vehicles/plants/boss/globals. Never read health from an owner not
/// confirmed a player.
pub mod epri {
    /// Current HP. UInt16 as a PLAIN (non-zigzag) varint, 1:1 (200 HP = 200 on
    /// the wire). CONFIRMED n=20 vs HUD.
    pub const CUR_HP: i32 = 0;
    /// Max HP. CONFIRMED — only 9 distinct values ever.
    pub const MAX_HP: i32 = 1;
    /// Vest: `(itemId << 32) | durability`.
    pub const VEST: i32 = 2;
    /// Helmet: same packing.
    pub const HELMET: i32 = 3;
    /// On-hand: `(inventoryItemId << 32) | weaponId`.
    pub const ON_HAND: i32 = 4;
    pub const CUR_EP: i32 = 6;
    pub const MAX_EP: i32 = 7;
    /// Firing state {0,1,2}. CONFIRMED n=2159.
    pub const FIRING: i32 = 21;
    /// Total damage dealt — strictly monotonic per player.
    pub const TOTAL_DMG: i32 = 31;
    /// Sentinel count (EPRI_PLAYER_NB); valid ids are 0..=254.
    pub const PLAYER_NB: i32 = 255;
}

/// The 56-bit value ceiling the Java packing imposes on every decoded value.
pub const VALUE_MASK: u64 = (1u64 << 56) - 1;

/// One decoded varint: `None` on truncation/overlong, else `(value, width)`.
/// `value` is masked to 56 bits, matching the Java packing exactly.
fn varint(b: &[u8], i: usize, end: usize) -> Option<(u64, usize)> {
    let mut v: u64 = 0;
    let mut shift: u32 = 0;
    let mut n = 0usize;
    while i + n < end && n < 10 {
        let c = b[i + n] as u64;
        v |= (c & 0x7f) << shift;
        n += 1;
        if (c & 0x80) == 0 {
            return Some((v & VALUE_MASK, n));
        }
        shift += 7;
    }
    None
}

/// Walk a decrypted Cmd 1900/1901 body, calling `sink(owner, var_id, value)` for
/// every property. `owner` is -1 for 1901 (match-wide, no per-player id).
///
/// `has_owner` is true for 1900 (per-player), false for 1901 (match-wide).
///
/// Returns true only when the body was consumed exactly. False means the body
/// was not this grammar (wrong command, bad key, clipped) and the caller MUST
/// discard whatever the sink already received — the walk is speculative until it
/// lands on `end`.
///
/// `owner` is `ownerReplicationId`, an arbitrary server-assigned int UNRELATED to
/// the ESP handle `(team<<24)|id`; it has to be learned (see `PriBinder`).
pub fn decode<F>(buf: &[u8], off: usize, len: usize, has_owner: bool, mut sink: F) -> bool
where
    F: FnMut(i64, i32, u64),
{
    if len == 0 || !crate::in_bounds(off, len, buf.len()) {
        return false;
    }
    let mut i = off;
    let end = off + len;
    let mut groups = 0u32;
    while i < end {
        let mut owner: i64 = -1;
        if has_owner {
            let (v, w) = match varint(buf, i, end) {
                Some(x) => x,
                None => return false,
            };
            owner = v as i64;
            i += w;
        }
        if i + 2 > end {
            return false;
        }
        let block_len = (buf[i] as usize) | ((buf[i + 1] as usize) << 8);
        i += 2;
        let stop = i + block_len;
        if stop > end {
            return false;
        }
        while i < stop {
            let var_id = buf[i] as i32;
            i += 1;
            let (v, w) = match varint(buf, i, stop) {
                Some(x) => x,
                None => return false,
            };
            i += w;
            sink(owner, var_id, v);
        }
        if i != stop {
            return false;
        }
        groups += 1;
        if groups > 256 {
            return false;
        }
    }
    i == end
}
