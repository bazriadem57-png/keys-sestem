//! The single door every packet mutation leaves by. Direct port of
//! `com.nuvola.app.protocol.PacketIntegrity`.
//!
//! Verify-then-repair, never blind-rewrite: a raw CRC stamp would corrupt other
//! apps' traffic on a shared transport (~8% of arbitrary UDP payloads have a
//! byte-0 in the MsgKey range). `seal` only writes when the packet both IS match
//! traffic AND has a stale checksum — which, by construction, only a mutation of
//! our own can produce. This is the foreign-safe seal the Rust rewrite paths
//! should call instead of a bare `crc7::seal`.

use crate::packet;

/// The outcome of a `seal`.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Seal {
    /// Not Free Fire match traffic: nothing was touched.
    Foreign,
    /// Match traffic whose checksum already agreed: nothing was written.
    Intact,
    /// Match traffic whose checksum was stale: byte 1 was recomputed.
    Repaired,
}

/// Make a packet safe to transmit after any in-place edit. Call immediately
/// before handing bytes to the transport.
pub fn seal(pkt: &mut [u8], off: usize, len: usize) -> Seal {
    if !crate::in_bounds(off, len, pkt.len()) {
        return Seal::Foreign;
    }
    if packet::is_intact_match_traffic(pkt, off, len) {
        return Seal::Intact;
    }
    // Either foreign traffic (leave it alone) or ours with an invalidated CRC.
    if packet::refresh_crc_if_match_traffic(pkt, off, len) {
        return Seal::Repaired;
    }
    Seal::Foreign
}

/// Convenience for a whole-slice packet.
pub fn seal_all(pkt: &mut [u8]) -> Seal {
    let n = pkt.len();
    seal(pkt, 0, n)
}
