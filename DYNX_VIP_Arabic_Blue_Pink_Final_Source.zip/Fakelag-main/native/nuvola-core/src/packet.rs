//! UDP header codec: parse a packet with a solved layout, and re-seal after an
//! edit. Direct port of `com.nuvola.app.decode.frame.{PacketFlags, PacketCodec,
//! UdpPacket}`. Depends only on crc7 + header (both already ported + verified).
//!
//! Every mutation of a packet must come back through `reserialize` (or
//! `integrity::seal`): CRC-7 covers the bytes as transmitted, so a byte edited
//! at offset >= 2 leaves byte 1 stale and the server drops the packet.

use crate::crc7;
use crate::header::{msgkey, Field, HeaderLayout};

/// The `Flags` header byte. Bit 0 = TEA-encrypted, bit 1 = zipped.
pub mod flags {
    pub const ENCRYPTED: i32 = 0x01;
    pub const ZIPPED: i32 = 0x02;
    pub const KNOWN_MASK: i32 = 0x03;

    pub fn is_encrypted(f: i32) -> bool {
        (f & ENCRYPTED) != 0
    }
    pub fn is_zipped(f: i32) -> bool {
        (f & ZIPPED) != 0
    }
    pub fn is_plaintext(f: i32) -> bool {
        (f & KNOWN_MASK) == 0
    }
    /// True when no unknown bit is set — a per-packet test that a candidate
    /// header layout put `Flags` at the right offset.
    pub fn is_plausible(f: i32) -> bool {
        (f & !KNOWN_MASK) == 0
    }
}

/// One parsed Free Fire Max UDP packet (the decoded header fields + framing).
/// `declared_length` is the header's Length field; `payload_length` is what
/// actually arrived — they agree on every outbound packet.
#[derive(Clone, Copy, Debug)]
pub struct UdpPacket {
    pub offset: usize,
    pub length: usize,
    pub msg_key: i32,
    pub checksum: i32,
    pub reliable: bool,
    pub header_size: usize,
    pub send_option: i32,
    pub cmd: i32,
    pub order_id: i32,
    pub flags: i32,
    pub declared_length: i32,
    pub payload_offset: usize,
    pub payload_length: usize,
    pub crc_valid: bool,
}

impl UdpPacket {
    pub fn is_reliable(&self) -> bool {
        self.reliable
    }
    pub fn is_crc_valid(&self) -> bool {
        self.crc_valid
    }
    pub fn is_encrypted(&self) -> bool {
        flags::is_encrypted(self.flags)
    }
    pub fn is_zipped(&self) -> bool {
        flags::is_zipped(self.flags)
    }
    pub fn is_plaintext(&self) -> bool {
        flags::is_plaintext(self.flags)
    }
    /// True when the declared Length matches the bytes that arrived (the
    /// identity the session solver is built on).
    pub fn length_matches(&self) -> bool {
        self.declared_length == self.payload_length as i32
    }
}

/// Parse a packet at `pkt[off..off+len]` with a solved layout. Returns None when
/// the buffer is not match traffic or is too short for its declared header.
pub fn parse(pkt: &[u8], off: usize, len: usize, layout: &HeaderLayout) -> Option<UdpPacket> {
    if !crate::in_bounds(off, len, pkt.len()) || len == 0 {
        return None;
    }
    let msg_key = pkt[off] as i32;
    let hdr = msgkey::header_size(msg_key);
    if hdr == msgkey::NOT_MATCH_TRAFFIC || len < hdr as usize {
        return None;
    }
    let hdr = hdr as usize;
    let reliable = hdr == msgkey::HEADER_RELIABLE;
    let checksum = pkt[off + crc7::CHECKSUM_INDEX] as i32;

    let send_option = layout.read_byte(pkt, off, Field::SendOption, reliable);
    let cmd = layout.read_short(pkt, off, Field::Cmd, reliable);
    let order_id = if reliable {
        layout.read_short(pkt, off, Field::OrderId, reliable)
    } else {
        -1
    };
    let flags_v = layout.read_byte(pkt, off, Field::Flags, reliable);
    let declared = layout.read_short(pkt, off, Field::DataLen, reliable);

    let crc_ok = checksum == crc7::of_packet(&pkt[off..off + len]) as i32;

    Some(UdpPacket {
        offset: off,
        length: len,
        msg_key,
        checksum,
        reliable,
        header_size: hdr,
        send_option,
        cmd,
        order_id,
        flags: flags_v,
        declared_length: declared,
        payload_offset: off + hdr,
        payload_length: len - hdr,
        crc_valid: crc_ok,
    })
}

/// Recompute byte 1 over the packet as it now stands. The whole "reserialize"
/// contract when only the body changed. Returns false if too short.
pub fn reserialize(pkt: &mut [u8], off: usize, len: usize) -> bool {
    if len < 3 || !crate::in_bounds(off, len, pkt.len()) {
        return false;
    }
    crc7::seal(&mut pkt[off..off + len]);
    true
}

/// Rewrite the five header fields with `layout` (pass -1 to keep a field;
/// order_id ignored on non-reliable) then recompute the checksum.
#[allow(clippy::too_many_arguments)]
pub fn reserialize_header(
    pkt: &mut [u8],
    off: usize,
    len: usize,
    layout: &HeaderLayout,
    send_option: i32,
    cmd: i32,
    order_id: i32,
    flags_v: i32,
    data_len: i32,
) -> bool {
    if len < 3 || !crate::in_bounds(off, len, pkt.len()) {
        return false;
    }
    let hdr = msgkey::header_size(pkt[off] as i32);
    if hdr == msgkey::NOT_MATCH_TRAFFIC || len < hdr as usize {
        return false;
    }
    let reliable = hdr as usize == msgkey::HEADER_RELIABLE;
    if send_option >= 0 {
        layout.write_byte(pkt, off, Field::SendOption, reliable, send_option);
    }
    if cmd >= 0 {
        layout.write_short(pkt, off, Field::Cmd, reliable, cmd);
    }
    if order_id >= 0 && reliable {
        layout.write_short(pkt, off, Field::OrderId, reliable, order_id);
    }
    if flags_v >= 0 {
        layout.write_byte(pkt, off, Field::Flags, reliable, flags_v);
    }
    if data_len >= 0 {
        layout.write_short(pkt, off, Field::DataLen, reliable, data_len);
    }
    reserialize(pkt, off, len)
}

/// Repair the checksum of a buffer that is match traffic; leave anything else
/// untouched. Returns true when it was recognised as match traffic.
pub fn refresh_crc_if_match_traffic(pkt: &mut [u8], off: usize, len: usize) -> bool {
    // Self-guard: this may be called directly, not only via `integrity::seal`,
    // so it must not trust `off`/`len` to be pre-bounded before it slices.
    if !crate::in_bounds(off, len, pkt.len()) {
        return false;
    }
    if msgkey::header_size_of(&pkt[off..off + len]) == msgkey::NOT_MATCH_TRAFFIC {
        return false;
    }
    reserialize(pkt, off, len)
}

/// True when a buffer is match traffic whose checksum already agrees.
pub fn is_intact_match_traffic(pkt: &[u8], off: usize, len: usize) -> bool {
    if !crate::in_bounds(off, len, pkt.len()) {
        return false;
    }
    if msgkey::header_size_of(&pkt[off..off + len]) == msgkey::NOT_MATCH_TRAFFIC {
        return false;
    }
    crc7::verify(&pkt[off..off + len])
}
