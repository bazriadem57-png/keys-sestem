//! Cmd 106 (RUDP_TAKE_DAMAGE) hit-rewrite — body walk + zone-edit math. Pure
//! port of the protocol-critical core of `com.nuvola.app.filter.AimFilter`.
//!
//! The engine-driven parts (victim head point from EspEngine, the harvest cache,
//! the config knobs) stay in Java and are passed in; this module owns the
//! decode/locate logic and the width-preserving zone edits — the pieces that
//! must be byte-exact against the wire.
//!
//! Body program (walked over the DECRYPTED body):
//! `UUUUUZUBUZZZZZZ(F)UFUZBB(B)FBU`
//!   U/F/Z = one LEB128 varint; B = one raw byte; (F) = a float list (a zigzag
//!   count then `count` F entries); (B) = a byte list. fStart/fWidth are indexed
//!   by PROGRAM-CHAR position, so the PC_* constants index straight in.

use crate::crc7;
use crate::header::{msgkey, Field, HeaderLayout};
use crate::tea;
use crate::varint::{varint_width, write_varint, zigzag_decode, zigzag_encode};

pub const PROG_106: &[u8] = b"UUUUUZUBUZZZZZZ(F)UFUZBB(B)FBU";
pub const NPROG: usize = 30; // PROG_106.len()

pub const PC_IDX0: usize = 0; // victim handle (low 24 bits = victim id)
pub const PC_IDX3: usize = 3; // uint; zone = high byte (bits 24-31)
pub const PC_IDX7: usize = 7; // raw byte HitBodyPart
pub const PC_IDX8: usize = 8; // tick
pub const PC_IDX9_X: usize = 9; // hit point X (mm, zigzag)
pub const PC_IDX9_UP: usize = 10; // hit point UP
pub const PC_IDX9_Z: usize = 11; // hit point Z
pub const PC_IDX15: usize = 21; // short zigzag hitType|colliderBodyId

pub const ZONE_NONE: u8 = 0;
pub const ZONE_HEAD: u8 = 1;
pub const ZONE_BODY: u8 = 2;
pub const ZONE_LIMB: u8 = 3;

// idx15 write modes.
pub const IDX15_HEAD0: i32 = 0;
pub const IDX15_KEEP: i32 = 1;
pub const IDX15_VALUE1: i32 = 2;

const MAX_LIST: i64 = 4096;
/// Cap on recorded per-entry checkParams offsets. Real head-hit lists are far
/// smaller (the zone triple is at canon index 33); a longer list simply won't
/// get its per-entry offsets recorded, so the CP_ZONE patch declines (safe).
pub const CP_MAX_ENTRIES: usize = 512;

/// Field offsets/widths from one walk of a 106 body. `f_start[pc] == -1` for a
/// program position that is a list bracket (no top-level scalar there).
pub struct BodyWalk {
    pub f_start: [i32; NPROG],
    pub f_width: [i32; NPROG],
    /// checkParams (the `(F)` list) geometry, for the patch/harvest paths.
    pub cp_count_start: i32,
    pub cp_list_end: i32,
    pub cp_count: usize,
    /// Per-entry checkParams offsets (only when cp_count <= CP_MAX_ENTRIES).
    pub cp_ent_start: [i32; CP_MAX_ENTRIES],
    pub cp_ent_width: [i32; CP_MAX_ENTRIES],
    pub cp_recorded: bool,
    last_val: u64,
}

impl Default for BodyWalk {
    fn default() -> Self {
        Self::new()
    }
}

impl BodyWalk {
    pub fn new() -> Self {
        BodyWalk {
            f_start: [-1; NPROG],
            f_width: [0; NPROG],
            cp_count_start: -1,
            cp_list_end: -1,
            cp_count: 0,
            cp_ent_start: [-1; CP_MAX_ENTRIES],
            cp_ent_width: [0; CP_MAX_ENTRIES],
            cp_recorded: false,
            last_val: 0,
        }
    }

    /// Walk PROG_106 over the decrypted body `b`. Returns true only when the
    /// program consumes the body exactly (the decoder's exactness gate).
    pub fn walk(&mut self, b: &[u8]) -> bool {
        self.f_start = [-1; NPROG];
        self.f_width = [0; NPROG];
        self.cp_count_start = -1;
        self.cp_list_end = -1;
        self.cp_count = 0;
        self.cp_recorded = false;

        let end = b.len();
        let prog = PROG_106;
        let n = prog.len();
        let mut i = 0usize;
        let mut pc = 0usize;
        while pc < n {
            let op = prog[pc];
            if op == b'(' {
                let close = match matching(prog, pc) {
                    Some(c) => c,
                    None => return false,
                };
                let count_start = i;
                let ni = match self.skip_varint(b, i, end) {
                    Some(x) => x,
                    None => return false,
                };
                let count = zigzag_decode(self.last_val);
                if !(0..=MAX_LIST).contains(&count) {
                    return false;
                }
                i = ni;
                let inner = &prog[pc + 1..close];
                let is_float_list = inner == b"F";
                let record = is_float_list && (count as usize) <= CP_MAX_ENTRIES;
                if is_float_list {
                    self.cp_count_start = count_start as i32;
                    self.cp_count = count as usize;
                    self.cp_recorded = record;
                }
                for k in 0..count as usize {
                    let s = i;
                    i = match self.walk_inner(inner, b, i, end) {
                        Some(x) => x,
                        None => return false,
                    };
                    if record {
                        self.cp_ent_start[k] = s as i32;
                        self.cp_ent_width[k] = (i - s) as i32;
                    }
                }
                if is_float_list {
                    self.cp_list_end = i as i32;
                }
                pc = close + 1;
                continue;
            }
            let s = i;
            let ni = match self.skip_scalar(op, b, i, end) {
                Some(x) => x,
                None => return false,
            };
            self.f_start[pc] = s as i32;
            self.f_width[pc] = (ni - s) as i32;
            i = ni;
            pc += 1;
        }
        i == end
    }

    fn walk_inner(&mut self, inner: &[u8], b: &[u8], mut i: usize, end: usize) -> Option<usize> {
        for &op in inner {
            i = self.skip_scalar(op, b, i, end)?;
        }
        Some(i)
    }

    fn skip_scalar(&mut self, op: u8, b: &[u8], i: usize, end: usize) -> Option<usize> {
        match op {
            b'U' | b'F' | b'Z' => self.skip_varint(b, i, end),
            b'B' => {
                if i < end {
                    Some(i + 1)
                } else {
                    None
                }
            }
            _ => None,
        }
    }

    fn skip_varint(&mut self, b: &[u8], mut i: usize, end: usize) -> Option<usize> {
        let mut v: u64 = 0;
        let mut shift = 0u32;
        while i < end {
            let c = b[i] as u64;
            i += 1;
            v |= (c & 0x7f) << shift;
            if (c & 0x80) == 0 {
                self.last_val = v;
                return Some(i);
            }
            shift += 7;
            if shift > 63 {
                return None;
            }
        }
        None
    }

    /// Read the varint at `start`, or None if it doesn't terminate before `end`.
    pub fn read_varint_at(&mut self, b: &[u8], start: usize, end: usize) -> Option<u64> {
        self.skip_varint(b, start, end)?;
        Some(self.last_val)
    }

    /// Convenience: the raw varint at a program-char index (uses f_start).
    pub fn raw_at(&mut self, b: &[u8], pc: usize) -> Option<u64> {
        let s = self.f_start[pc];
        if s < 0 {
            return None;
        }
        self.read_varint_at(b, s as usize, b.len())
    }
}

fn matching(prog: &[u8], open: usize) -> Option<usize> {
    let mut depth = 0i32;
    let mut i = open;
    while i < prog.len() {
        match prog[i] {
            b'(' => depth += 1,
            b')' => {
                depth -= 1;
                if depth == 0 {
                    return Some(i);
                }
            }
            _ => {}
        }
        i += 1;
    }
    None
}

// ---- pure zone-edit math (width-preserving) --------------------------------

/// idx3: preserve the low 24 bits (damage/id), set the zone into the high byte.
pub fn new_val3(val3: u64, target_zone: u8) -> u64 {
    (val3 & 0x00FF_FFFF) | ((target_zone as u64) << 24)
}

/// The zone carried in idx3's high byte.
pub fn zone_of_val3(val3: u64) -> u8 {
    ((val3 >> 24) & 0xFF) as u8
}

/// idx15 rewrite for a mode. Returns None for KEEP (leave as-is). Operates on
/// the RAW zigzag value; the zone occupies the low 2 bits of the decoded value.
pub fn new_raw_z15(raw_z15: u64, mode: i32) -> Option<u64> {
    let s = zigzag_decode(raw_z15);
    match mode {
        IDX15_KEEP => None,
        IDX15_VALUE1 => Some(zigzag_encode((s & !0x3) | 1)),
        _ /* IDX15_HEAD0 */ => Some(zigzag_encode(s & !0x3)),
    }
}

/// Write `u` as LEB128 padded to exactly `width` bytes at `b[start..]` (the game
/// emits such padding, so it stays byte-length identical). Caller guarantees fit.
pub fn write_varint_padded(b: &mut [u8], start: usize, width: usize, mut u: u64) {
    for k in 0..width - 1 {
        b[start + k] = ((u & 0x7f) | 0x80) as u8;
        u >>= 7;
    }
    b[start + width - 1] = (u & 0x7f) as u8;
}

/// True when the value fits the width already occupied by a field.
pub fn fits_width(u: u64, width: usize) -> bool {
    varint_width(u) <= width
}

// ---- checkParams (idx11) canonical zone triple (docs/CHECKPARAMS_ZONE_FIELD.md) ----
const CANON_Z31: usize = 31;
const CANON_Z32: usize = 32;
const CANON_Z33: usize = 33;
const CANON_ZONE_MAX: usize = 33;
const CANON_HEAD_31: u32 = 0x3e39_16a6; // ~0.18075
const CANON_HEAD_32: u32 = 0x3e47_60a6; // ~0.19470
const CANON_HEAD_33: u32 = 0x3e38_74c0; // ~0.18013

/// checkParams (idx11) rewrite plan supplied by the caller.
pub enum CpPlan<'a> {
    /// Copy the list verbatim (default; the experimental patch is off).
    None,
    /// Overwrite canon[31,32,33] with HEAD bit-values at the victim's permuted
    /// wire slots (only valid when the rewrite claims Head).
    ZoneHead,
    /// Splice in a harvested head list (count + entries), verbatim.
    Transplant(&'a [u8]),
}

fn xorshift32(mut s: u64) -> u64 {
    s &= 0xFFFF_FFFF;
    s ^= (s << 13) & 0xFFFF_FFFF;
    s ^= s >> 17;
    s ^= (s << 5) & 0xFFFF_FFFF;
    s & 0xFFFF_FFFF
}

/// Per-victim backward Fisher-Yates permutation (docs/CHECKPARAMS_ZONE_FIELD.md
/// §3). `out[j]` is the WIRE slot holding canonical entry `j`. Seed is the raw
/// idx0 word XOR 0xA3B1C6D9. Fills `out[..n]`.
pub fn fisher_yates_idx(n: usize, seed_raw_idx0: u64, out: &mut [usize]) {
    for (j, slot) in out.iter_mut().enumerate().take(n) {
        *slot = j;
    }
    let mut s = (seed_raw_idx0 ^ 0xA3B1_C6D9) & 0xFFFF_FFFF;
    if s == 0 {
        s = 1;
    }
    let mut i = n;
    while i >= 2 {
        s = xorshift32(s);
        let k = (s % i as u64) as usize;
        out.swap(i - 1, k);
        i -= 1;
    }
}

#[inline]
fn write_canonical(np: &mut [u8], p: usize, u: u64) -> usize {
    p + write_varint(&mut np[p..], u)
}

/// Full in-place Cmd-106 hit rewrite: decrypt → walk → zone flip
/// (idx3 hi, idx7, idx15) → optional hit-point move (idx9) → optional
/// checkParams patch → re-encrypt → repair DATA_LEN (if length changed) →
/// reseal CRC-7. Returns the new total packet length, or -1 (packet left
/// byte-for-byte untouched) whenever anything is not right — the caller then
/// passes the hit through unchanged.
///
/// The engine supplies the resolved decisions: `target_zone`, `idx15_mode`, the
/// already-computed victim `head_point` (mm `[X,UP,Z]`, or None to leave the hit
/// point), and the `cp` plan. Safety gates kept from AimFilter: only a real
/// Body/Limb hit is redirected, and the two-copy zone agreement (idx3-hi == idx7)
/// must hold, or the packet is left untouched.
#[allow(clippy::too_many_arguments)]
pub fn rewrite_packet(
    buf: &mut [u8],
    off: usize,
    plen: usize,
    key: &[u32; 4],
    layout: &HeaderLayout,
    target_zone: u8,
    idx15_mode: i32,
    head_point: Option<[i64; 3]>,
    cp: CpPlan,
    valid_until: u64,
    now: u64,
) -> i32 {
    // Server-gated leash: no live profile => no hit rewrite (the -1 no-op path
    // leaves the packet untouched, so an unlicensed client's aim does nothing).
    if !crate::entitled(valid_until, now) {
        return -1;
    }
    let hdr = msgkey::HEADER_RELIABLE;
    if plen < hdr + tea::MIN_CIPHERTEXT || !crate::in_bounds(off, plen, buf.len()) {
        return -1;
    }
    if msgkey::header_size(buf[off] as i32) != hdr as i32 {
        return -1;
    }
    let pay_off = off + hdr;
    let pay_len = plen - hdr;
    if (pay_len & 7) != 0 {
        return -1;
    }
    if layout.read_short(buf, off, Field::DataLen, true) != pay_len as i32 {
        return -1;
    }

    let mut plain = [0u8; 512];
    if pay_len > plain.len() {
        return -1;
    }
    let plain_len = match tea::qq_tea_decrypt(&buf[pay_off..pay_off + pay_len], key, &mut plain) {
        Some(n) if n > 0 => n,
        _ => return -1,
    };
    let plain = &mut plain[..plain_len];

    let mut w = BodyWalk::new();
    if !w.walk(plain) {
        return -1;
    }
    for pc in [PC_IDX0, PC_IDX3, PC_IDX7, PC_IDX15, PC_IDX9_X, PC_IDX9_UP, PC_IDX9_Z] {
        if w.f_start[pc] < 0 {
            return -1;
        }
    }

    let val3 = match w.raw_at(plain, PC_IDX3) {
        Some(v) => v,
        None => return -1,
    };
    let zone7 = plain[w.f_start[PC_IDX7] as usize];
    let zone3hi = zone_of_val3(val3);
    let idx0_raw = match w.raw_at(plain, PC_IDX0) {
        Some(v) => v,
        None => return -1,
    };

    // Only redirect a genuine Body/Limb hit, and never into the zone it already is.
    if (zone7 != ZONE_BODY && zone7 != ZONE_LIMB) || zone7 == target_zone {
        return -1;
    }
    // Two-copy agreement must hold on a real packet.
    if zone3hi != zone7 {
        return -1;
    }

    let new_v3 = new_val3(val3, target_zone);
    let raw_z15 = match w.raw_at(plain, PC_IDX15) {
        Some(v) => v,
        None => return -1,
    };
    let new_z15 = new_raw_z15(raw_z15, idx15_mode);
    if !fits_width(new_v3, w.f_width[PC_IDX3] as usize) {
        return -1;
    }
    if let Some(z) = new_z15 {
        if !fits_width(z, w.f_width[PC_IDX15] as usize) {
            return -1;
        }
    }

    // Hit-point move target.
    let (mut move_hit, mut nr9, mut nr10, mut nr11) = (false, 0u64, 0u64, 0u64);
    if let Some(hp) = head_point {
        nr9 = zigzag_encode(hp[0]);
        nr10 = zigzag_encode(hp[1]);
        nr11 = zigzag_encode(hp[2]);
        move_hit = true;
    }
    let fits9 = move_hit
        && fits_width(nr9, w.f_width[PC_IDX9_X] as usize)
        && fits_width(nr10, w.f_width[PC_IDX9_UP] as usize)
        && fits_width(nr11, w.f_width[PC_IDX9_Z] as usize);

    // checkParams plan validation.
    let end_idx9 = (w.f_start[PC_IDX9_Z] + w.f_width[PC_IDX9_Z]) as usize;
    let mut eff_cp = CpPlan::None;
    let mut cp_slots = (usize::MAX, usize::MAX, usize::MAX);
    match cp {
        CpPlan::None => {}
        CpPlan::Transplant(bytes) => {
            let cp_ok = w.cp_recorded
                && w.cp_count_start as usize >= end_idx9
                && w.cp_list_end > w.cp_count_start
                && (w.cp_list_end as usize) <= plain_len
                && !bytes.is_empty();
            if cp_ok {
                eff_cp = CpPlan::Transplant(bytes);
            }
        }
        CpPlan::ZoneHead => {
            let region_ok = w.cp_recorded
                && w.cp_count_start as usize >= end_idx9
                && w.cp_list_end > w.cp_count_start
                && (w.cp_list_end as usize) <= plain_len
                && w.cp_count > CANON_ZONE_MAX;
            if target_zone == ZONE_HEAD && region_ok {
                let mut perm = [0usize; CP_MAX_ENTRIES];
                fisher_yates_idx(w.cp_count, idx0_raw, &mut perm);
                let (z31, z32, z33) = (perm[CANON_Z31], perm[CANON_Z32], perm[CANON_Z33]);
                if z31 < w.cp_count && z32 < w.cp_count && z33 < w.cp_count {
                    eff_cp = CpPlan::ZoneHead;
                    cp_slots = (z31, z32, z33);
                }
            }
        }
    }

    // Apply the width-preserving zone flip in place (the rebuild builds on this).
    plain[w.f_start[PC_IDX7] as usize] = target_zone;
    write_varint_padded(plain, w.f_start[PC_IDX3] as usize, w.f_width[PC_IDX3] as usize, new_v3);
    if let Some(z) = new_z15 {
        write_varint_padded(plain, w.f_start[PC_IDX15] as usize, w.f_width[PC_IDX15] as usize, z);
    }

    let need_rebuild = (move_hit && !fits9) || !matches!(eff_cp, CpPlan::None);

    if need_rebuild {
        let mut np = [0u8; 640];
        let reg9 = w.f_start[PC_IDX9_X] as usize;
        let mut p = 0usize;
        // 1) everything before idx9 (carries the zone-flipped idx3/idx7)
        np[..reg9].copy_from_slice(&plain[..reg9]);
        p += reg9;
        // 2) idx9: canonical head point or the original bytes
        if move_hit {
            p = write_canonical(&mut np, p, nr9);
            p = write_canonical(&mut np, p, nr10);
            p = write_canonical(&mut np, p, nr11);
        } else {
            let n = end_idx9 - reg9;
            np[p..p + n].copy_from_slice(&plain[reg9..end_idx9]);
            p += n;
        }
        // 3) remainder
        match eff_cp {
            CpPlan::None => {
                let n = plain_len - end_idx9;
                np[p..p + n].copy_from_slice(&plain[end_idx9..plain_len]);
                p += n;
            }
            CpPlan::Transplant(bytes) => {
                let cs = w.cp_count_start as usize;
                np[p..p + (cs - end_idx9)].copy_from_slice(&plain[end_idx9..cs]);
                p += cs - end_idx9;
                if p + bytes.len() > np.len() {
                    return -1;
                }
                np[p..p + bytes.len()].copy_from_slice(bytes);
                p += bytes.len();
                let ce = w.cp_list_end as usize;
                let n = plain_len - ce;
                np[p..p + n].copy_from_slice(&plain[ce..plain_len]);
                p += n;
            }
            CpPlan::ZoneHead => {
                let (z31, z32, z33) = cp_slots;
                let cs = w.cp_count_start as usize;
                // idx10..list start
                np[p..p + (cs - end_idx9)].copy_from_slice(&plain[end_idx9..cs]);
                p += cs - end_idx9;
                // count varint
                let e0 = w.cp_ent_start[0] as usize;
                np[p..p + (e0 - cs)].copy_from_slice(&plain[cs..e0]);
                p += e0 - cs;
                for e in 0..w.cp_count {
                    let repl = if e == z31 {
                        Some(CANON_HEAD_31)
                    } else if e == z32 {
                        Some(CANON_HEAD_32)
                    } else if e == z33 {
                        Some(CANON_HEAD_33)
                    } else {
                        None
                    };
                    match repl {
                        Some(bits) => {
                            p = write_canonical(&mut np, p, bits as u64);
                        }
                        None => {
                            let s = w.cp_ent_start[e] as usize;
                            let ww = w.cp_ent_width[e] as usize;
                            np[p..p + ww].copy_from_slice(&plain[s..s + ww]);
                            p += ww;
                        }
                    }
                }
                let ce = w.cp_list_end as usize;
                let n = plain_len - ce;
                np[p..p + n].copy_from_slice(&plain[ce..plain_len]);
                p += n;
            }
        }
        let new_plain_len = p;
        let enc_len = tea::qq_tea_encrypt_len(new_plain_len);
        let new_total = hdr + enc_len;
        if off + new_total > buf.len() {
            return -1;
        }
        let mut cipher = [0u8; 704];
        if enc_len > cipher.len() {
            return -1;
        }
        match tea::qq_tea_encrypt(&np[..new_plain_len], key, &mut cipher) {
            Some(n) if n == enc_len => {}
            _ => return -1,
        }
        buf[pay_off..pay_off + enc_len].copy_from_slice(&cipher[..enc_len]);
        layout.write_short(buf, off, Field::DataLen, true, enc_len as i32);
        crc7::seal(&mut buf[off..off + new_total]);
        return new_total as i32;
    }

    // In-place length-preserving path.
    if move_hit {
        write_varint_padded(plain, w.f_start[PC_IDX9_X] as usize, w.f_width[PC_IDX9_X] as usize, nr9);
        write_varint_padded(plain, w.f_start[PC_IDX9_UP] as usize, w.f_width[PC_IDX9_UP] as usize, nr10);
        write_varint_padded(plain, w.f_start[PC_IDX9_Z] as usize, w.f_width[PC_IDX9_Z] as usize, nr11);
    }
    let mut cipher = [0u8; 704];
    let enc_len = tea::qq_tea_encrypt_len(plain_len);
    if enc_len > cipher.len() {
        return -1;
    }
    match tea::qq_tea_encrypt(plain, key, &mut cipher) {
        Some(n) if n == pay_len => {}
        _ => return -1,
    }
    buf[pay_off..pay_off + pay_len].copy_from_slice(&cipher[..pay_len]);
    crc7::seal(&mut buf[off..off + plen]);
    plen as i32
}
