//! Reliable-message body decryption with the captured session key. Direct port
//! of `com.nuvola.app.decode.crypt.BodyCrypt`.
//!
//! Cmd 1900 (health) and every other reliable message are TEA-encrypted, which
//! is the mechanical reason the ESP was blind to real health and invented it.
//! This wraps the (already byte-parity-verified) `tea` primitives with the
//! session-key lifecycle: parse the 32-hex-char key, build the schedule once,
//! cache it until the key rotates, and gate on TEA's block/length rules plus the
//! seven-zero tail check (a wrong key => `None`, never a plausible-looking
//! mis-decrypt).
//!
//! The key itself arrives in the clear over lobby TCP and is sniffed on the Java
//! side (`LobbyKeySniffer`); that stays in Java. This struct is the pure
//! schedule-cache + decrypt half, owned by the JNI layer (one instance per
//! session), so it needs no globals and stays `#![forbid(unsafe_code)]`-clean.

use crate::tea;

/// Biggest body we will decrypt. Comfortably above any observed message.
pub const MAX_BODY: usize = 4096;

/// Session-key schedule cache. Holds the current key's hex and its TEA schedule,
/// rebuilding only when the hex changes. Reused across the receive path.
#[derive(Clone, Default)]
pub struct BodyCrypt {
    key_hex: Option<String>,
    schedule: Option<[u32; 4]>,
    /// The reliable-channel leash (server-gated decode). Unix seconds after
    /// which `decrypt_into` refuses; 0 (the default) means "not armed" and
    /// refuses everything. Armed only from the server's authenticated /config
    /// profile — a client with no live licensed session decrypts nothing, so
    /// every reliable channel (health/combat via Cmd 1900, etc.) fails closed.
    /// See `docs/SERVER_GATED_DECODE_DESIGN.md`.
    armed_until: u64,
}

/// Parse a 16-byte key from exactly 32 hex chars (`Character.digit` semantics:
/// only 0-9a-fA-F). Returns `None` on any non-hex char or a wrong length.
fn key_from_hex(hex: &str) -> Option<[u8; tea::KEY_BYTES]> {
    if hex.len() != tea::KEY_BYTES * 2 {
        return None;
    }
    let b = hex.as_bytes();
    let mut key = [0u8; tea::KEY_BYTES];
    for (i, out) in key.iter_mut().enumerate() {
        let hi = (b[i * 2] as char).to_digit(16)?;
        let lo = (b[i * 2 + 1] as char).to_digit(16)?;
        *out = ((hi << 4) | lo) as u8;
    }
    Some(key)
}

impl BodyCrypt {
    pub fn new() -> Self {
        Self::default()
    }

    /// Install/refresh the session key from its 32-hex-char form. Idempotent: a
    /// repeated identical hex reuses the cached schedule. Returns true when a
    /// usable schedule is now present. An invalid hex clears the key.
    pub fn set_key_hex(&mut self, hex: &str) -> bool {
        if self.key_hex.as_deref() == Some(hex) {
            return self.schedule.is_some();
        }
        match key_from_hex(hex).and_then(|k| tea::schedule(&k)) {
            Some(s) => {
                self.schedule = Some(s);
                self.key_hex = Some(hex.to_owned());
                true
            }
            None => {
                self.schedule = None;
                self.key_hex = None;
                false
            }
        }
    }

    /// True once a usable session key has been installed.
    pub fn has_key(&self) -> bool {
        self.schedule.is_some()
    }

    /// Arm the reliable-channel leash with the server profile's validity
    /// (unix seconds). Until this is set to a future time, `decrypt_into`
    /// fail-closes. Re-armed each time a fresh /config profile arrives.
    pub fn arm(&mut self, valid_until: u64) {
        self.armed_until = valid_until;
    }

    /// True when armed with a still-valid entitlement at `now`.
    pub fn is_armed(&self, now: u64) -> bool {
        self.armed_until != 0 && now < self.armed_until
    }

    /// The cached schedule, if any (for callers that decrypt through `tea`).
    pub fn schedule(&self) -> Option<&[u32; 4]> {
        self.schedule.as_ref()
    }

    /// Decrypt `input` into `out`, returning the plaintext length (compacted to
    /// the front of `out`) or `None` when the leash is not armed for `now`,
    /// there is no key, the length is not a whole number of TEA blocks / is out
    /// of range, or the seven-zero tail check fails (the key is wrong for this
    /// body). `out` must be >= `input.len()`.
    ///
    /// THE RELIABLE-CHANNEL LEASH: without a live server entitlement this returns
    /// `None`, so nothing encrypted decodes — fail-closed, and the caller simply
    /// sees "no plaintext" exactly as if the key were absent.
    pub fn decrypt_into(&self, input: &[u8], out: &mut [u8], now: u64) -> Option<usize> {
        if !self.is_armed(now) {
            return None;
        }
        let len = input.len();
        if len < tea::MIN_CIPHERTEXT || (len & 7) != 0 || len > MAX_BODY {
            return None;
        }
        let sched = self.schedule.as_ref()?;
        tea::qq_tea_decrypt(input, sched, out)
    }
}
