//! CRC-7/MMC (polynomial 0x09) — the checksum Free Fire Max carries in UDP
//! packet byte 1. Direct port of `com.nuvola.app.decode.frame.Crc7`.
//!
//! `packet[1] == crc7(packet[2..], seed = 0)`. The table is the Linux
//! `crc7_syndrome_table` shifted right by one, generated at compile time so
//! there is nothing to mistype. Any rewrite of a byte at offset >= 2 invalidates
//! the checksum and must be re-sealed.

/// Index of the checksum byte inside a packet.
pub const CHECKSUM_INDEX: usize = 1;
/// First byte covered by the checksum.
pub const COVERED_FROM: usize = 2;

const TABLE: [u8; 256] = build_table();

const fn build_table() -> [u8; 256] {
    let mut t = [0u8; 256];
    let mut i = 0usize;
    while i < 256 {
        let mut c = i as u32;
        let mut bit = 0;
        while bit < 8 {
            c = if (c & 0x80) != 0 {
                ((c << 1) ^  0x12) & 0xFF
            } else {
                (c << 1) & 0xFF
            };
            bit += 1;
        }
        t[i] = (c >> 1) as u8;
        i += 1;
    }
    t
}

/// CRC-7 over `buf` starting from an explicit seed (protocol seed is 0).
pub fn compute(buf: &[u8], seed: u32) -> u32 {
    let mut crc = seed & 0x7F;
    for &x in buf {
        crc = TABLE[(((x as u32) ^ (crc << 1)) & 0xFF) as usize] as u32;
    }
    crc
}

/// The checksum a packet *should* carry: CRC-7 over bytes `[2..]`. Caller must
/// ensure `pkt.len() >= 2`.
pub fn of_packet(pkt: &[u8]) -> u32 {
    compute(&pkt[COVERED_FROM..], 0)
}

/// True when a packet's byte 1 matches the checksum of its remaining bytes.
pub fn verify(pkt: &[u8]) -> bool {
    if pkt.len() < 3 {
        return false;
    }
    (pkt[CHECKSUM_INDEX] as u32) == of_packet(pkt)
}

/// Re-seal a packet in place: recompute byte 1 over `pkt[2..]`. Returns the new
/// checksum. Caller must ensure `pkt.len() >= 2`.
pub fn seal(pkt: &mut [u8]) -> u32 {
    let crc = of_packet(pkt);
    pkt[CHECKSUM_INDEX] = crc as u8;
    crc
}
