//! Cmd 148 (RUDP_MAPMARK_CHANGED) map-pin retarget. Pure port of the transform
//! in `com.nuvola.app.filter.MarkFilter` — the engine-side gating (target
//! selection, enable switch, counters) stays in Java; this is just the packet
//! math.
//!
//! Reliable body layout (nine elements), TEA-encrypted on the wire:
//! ```text
//!   U author-id | B isDel | B markType | Z posX | Z posUP | Z posZ | B slot | B sound | B (0)
//! ```
//! The three `B` fields are RAW BYTES, not varints — walking them as varints is
//! the classic desync. A delete (`isDel != 0`) is never retargeted.

use crate::crc7;
use crate::header::{Field, HeaderLayout, msgkey};
use crate::tea;
use crate::varint::{write_varint, zigzag_encode};

/// EItemMarkPointType_NoticeEnemy — the squad-visible enemy pin.
pub const TYPE_NOTICE_ENEMY: u8 = 1;

fn skip_varint(b: &[u8], mut i: usize, end: usize) -> Option<usize> {
    let mut n = 0;
    while i < end {
        let c = b[i];
        i += 1;
        if (c & 0x80) == 0 {
            return Some(i);
        }
        n += 1;
        if n > 9 {
            return None;
        }
    }
    None
}

/// Rewrite the DECRYPTED body in `plain[..plain_len]` into `out`, moving the pin
/// to (nx, nup, ny) and optionally forcing the enemy type. Returns the new plain
/// length, or `None` when the body is malformed or is a delete (must not be
/// retargeted). Pure and allocation-free (writes into caller `out`).
pub fn rewrite_body(
    plain: &[u8],
    plain_len: usize,
    out: &mut [u8],
    nx: i64,
    nup: i64,
    ny: i64,
    force_enemy_type: bool,
) -> Option<usize> {
    if plain_len > plain.len() {
        return None;
    }
    // U author
    let mut p = skip_varint(plain, 0, plain_len)?;
    // B isDel, B markType
    if p + 2 > plain_len {
        return None;
    }
    let is_del_pos = p;
    let type_pos = p + 1;
    p += 2;
    let pos_start = p;
    // Z Z Z position
    for _ in 0..3 {
        p = skip_varint(plain, p, plain_len)?;
    }
    let pos_end = p;
    let tail_len = plain_len.checked_sub(pos_end)?;

    // A delete must not be retargeted.
    if plain[is_del_pos] != 0 {
        return None;
    }

    let mut q = 0usize;
    // copy up to and including the two raw flag bytes
    if pos_start > out.len() {
        return None;
    }
    out[..pos_start].copy_from_slice(&plain[..pos_start]);
    q += pos_start;
    if force_enemy_type {
        out[type_pos] = TYPE_NOTICE_ENEMY;
    }
    // three rewritten zigzag varints
    for v in [nx, nup, ny] {
        let mut b = [0u8; 10];
        let w = write_varint(&mut b, zigzag_encode(v));
        if q + w > out.len() {
            return None;
        }
        out[q..q + w].copy_from_slice(&b[..w]);
        q += w;
    }
    // trailing raw bytes, preserved verbatim
    if q + tail_len > out.len() {
        return None;
    }
    out[q..q + tail_len].copy_from_slice(&plain[pos_end..pos_end + tail_len]);
    q += tail_len;
    Some(q)
}

/// Full in-place Cmd-148 packet rewrite: decrypt → rewrite body → re-encrypt →
/// repair DATA_LEN → reseal CRC-7. `buf[off..off+plen]` is the packet (reliable,
/// 10-byte header); `buf` must have room to grow. Returns the new total length,
/// or -1 when anything is not right (caller passes the packet through unchanged).
// The argument count mirrors the Cmd-148 rewrite's real inputs (buffer, frame
// window, key, layout, the three new coords, and the enemy-type flag); grouping
// them into a struct would only move the same fields behind one more name.
#[allow(clippy::too_many_arguments)]
pub fn rewrite_packet(
    buf: &mut [u8],
    off: usize,
    plen: usize,
    key: &[u32; 4],
    layout: &HeaderLayout,
    nx: i64,
    nup: i64,
    ny: i64,
    force_enemy_type: bool,
    valid_until: u64,
    now: u64,
) -> i32 {
    // Server-gated leash: no live profile => no rewrite. The packet is left
    // byte-for-byte untouched (the -1 no-op path), so an unlicensed/cracked
    // client's mark simply does nothing — no desync, no render impact.
    if !crate::entitled(valid_until, now) {
        return -1;
    }
    let hdr = msgkey::HEADER_RELIABLE;
    if plen < hdr + tea::MIN_CIPHERTEXT || !crate::in_bounds(off, plen, buf.len()) {
        return -1;
    }
    // msgkey must actually mark a reliable packet
    if msgkey::header_size(buf[off] as i32) != hdr as i32 {
        return -1;
    }
    let pay_off = off + hdr;
    let pay_len = plen - hdr;
    if (pay_len & 7) != 0 {
        return -1;
    }
    // Layout-stale guard: declared DATA_LEN must equal the payload present.
    if layout.read_short(buf, off, Field::DataLen, true) != pay_len as i32 {
        return -1;
    }

    let mut plain = [0u8; 512];
    if pay_len > plain.len() {
        return -1;
    }
    let plain_len = match tea::qq_tea_decrypt(&buf[pay_off..pay_off + pay_len], key, &mut plain) {
        Some(n) if n > 0 => n,
        _ => return -1,
    };

    let mut out = [0u8; 560];
    let new_plain = match rewrite_body(&plain, plain_len, &mut out, nx, nup, ny, force_enemy_type) {
        Some(n) => n,
        None => return -1,
    };

    let enc_len = tea::qq_tea_encrypt_len(new_plain);
    let new_total = hdr + enc_len;
    if off + new_total > buf.len() {
        return -1;
    }
    let mut cipher = [0u8; 576];
    if enc_len > cipher.len() {
        return -1;
    }
    match tea::qq_tea_encrypt(&out[..new_plain], key, &mut cipher) {
        Some(n) if n == enc_len => {}
        _ => return -1,
    }
    buf[pay_off..pay_off + enc_len].copy_from_slice(&cipher[..enc_len]);
    layout.write_short(buf, off, Field::DataLen, true, enc_len as i32);
    crc7::seal(&mut buf[off..off + new_total]);
    new_total as i32
}
