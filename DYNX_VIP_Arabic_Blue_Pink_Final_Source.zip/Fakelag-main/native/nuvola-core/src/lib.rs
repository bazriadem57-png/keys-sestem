//! Nuvola packet hot-path core, ported from the Java reference in
//! `com.nuvola.app.decode.*`. These are the "Bucket-A" primitives that must
//! ship on-device: the QQ-TEA cipher, the CRC-7 frame checksum, and the LEB128
//! varint codec. They are pure and (on the hot-path entry points) allocation
//! free, so the same discipline the Java side keeps — "per-packet code allocates
//! nothing" — holds here too.
//!
//! Byte-for-byte parity with the Java is the whole point: the wire format does
//! not change just because the language did. Every function here mirrors its
//! Java counterpart's arithmetic exactly (Java `int` overflow → `u32`
//! wrapping ops; Java `>>>` → `u32 >>`; Java `>>` on `long` → `i64 >>`), and
//! `tests/parity.rs` pins that against the CRC-7/MMC standard check value, a
//! TEA round-trip, and vectors emitted by the repo's independent Python oracle.
//!
//! What is deliberately NOT here yet: the stateful rewrite filters
//! (Ghost/Freeze/Teleport/Aim/Mark) and the header permutation table. Those come
//! next, built on top of these proven primitives.

#![forbid(unsafe_code)]

/// True when `pkt[off..off+len]` is wholly in bounds, computed WITHOUT the
/// `off + len` add that can wrap `usize` and turn a `>` bounds guard into a
/// `start > end` slice panic (security review F4). Every `(buf, off, len)` entry
/// point routes its bounds check through this. `panic = "abort"` is set, so a
/// wrapped guard would abort the whole VpnService rather than unwind.
#[inline]
pub fn in_bounds(off: usize, len: usize, total: usize) -> bool {
    off <= total && len <= total - off
}

/// The server-gated leash test shared by every decode AND rewrite entry point:
/// an operation is permitted only when armed with a profile whose `valid_until`
/// (unix seconds) is still in the future. `valid_until == 0` (unarmed) always
/// fails, so a client with no live licensed session performs no manipulation and
/// decodes nothing — fail-closed. See `docs/SERVER_GATED_DECODE_DESIGN.md`.
#[inline]
pub fn entitled(valid_until: u64, now: u64) -> bool {
    valid_until != 0 && now < valid_until
}

pub mod aim;
pub mod bodycrypt;
pub mod chain;
pub mod cmd;
pub mod crc7;
pub mod geom;
pub mod header;
pub mod integrity;
pub mod mark;
pub mod packet;
pub mod possync;
pub mod pri;
pub mod tea;
pub mod varint;
pub mod vehicle;

/// On-device self-test: runs the known-answer checks the host `cargo test` pins
/// (CRC-7/MMC standard value, a TEA round-trip, and a varint/zigzag/chain-decode
/// KAT). The live-update loader calls this through JNI right after
/// `System.load()` and refuses to promote a lib whose self-test does not pass —
/// catching a corrupt or ABI-mismatched build before it ever touches a packet.
/// Allocation on the heap here is fine: this runs once at load, never on the
/// packet path.
pub fn selftest() -> bool {
    if crc7::compute(b"123456789", 0) != 0x75 {
        return false;
    }
    let key = [0x0bu8, 0x30, 0x55, 0x7a, 0x9f, 0xc4, 0xe9, 0x0e,
               0x33, 0x58, 0x7d, 0xa2, 0xc7, 0xec, 0x11, 0x36];
    let k = match tea::schedule(&key) {
        Some(k) => k,
        None => return false,
    };
    // A fixed, non-descriptive TEA round-trip vector. NOT a readable string: an
    // ASCII payload here ("nuvola native self-test payload") printed the project
    // name straight into .rodata and pinpointed selftest() in the 2026-09-18
    // binary audit. Any fixed payload round-trips; these bytes spell nothing.
    let plain: &[u8] = &[
        0x1f, 0x8b, 0x42, 0xd7, 0x6a, 0x03, 0xe5, 0x9c,
        0x11, 0xf4, 0x28, 0x7d, 0xbb, 0x50, 0xc6, 0x39,
        0x84, 0x2e, 0xa1, 0x0d, 0xf9, 0x67, 0x3c, 0xd0,
    ];
    let mut ct = [0u8; 64];
    let enc = match tea::qq_tea_encrypt(plain, &k, &mut ct) {
        Some(n) => n,
        None => return false,
    };
    let mut out = [0u8; 64];
    match tea::qq_tea_decrypt(&ct[..enc], &k, &mut out) {
        Some(n) => {
            if n != plain.len() || out[..n] != plain[..] {
                return false;
            }
        }
        None => return false,
    }
    chain_selftest()
}

/// Known-answer check that the varint / zigzag / framing / pose-byte arithmetic
/// of the chain decoder is intact in this build. Uses **synthetic** decode
/// parameters — deliberately NOT the production game values — so this KAT
/// verifies the decode math without embedding any real decode parameter in the
/// shipped binary (that would undo the server-gated-decode leash; see
/// `docs/SERVER_GATED_DECODE_DESIGN.md`).
fn chain_selftest() -> bool {
    use crate::chain::{parse_with_profile, ChainProfile};
    use crate::varint::{write_varint, zigzag_encode};

    fn pu(out: &mut Vec<u8>, v: u64) {
        let mut b = [0u8; 10];
        let n = write_varint(&mut b, v);
        out.extend_from_slice(&b[..n]);
    }
    // Arbitrary, non-production profile.
    let prof = ChainProfile {
        chain_max_len: 128,
        max_records: 8,
        min_record_bytes: 10,
        min_record_x: 1,
        max_entity_id: 16,
        valid_until: u64::MAX,
    };
    let mut pkt: Vec<u8> = Vec::new();
    pkt.extend_from_slice(&[0u8; 10]);
    pkt[8] = 0x00;
    pkt[9] = 2; // declared = 1 record
    pu(&mut pkt, 5); // id
    pu(&mut pkt, zigzag_encode(600)); // x (raw 1200)
    pu(&mut pkt, zigzag_encode(700)); // z
    pu(&mut pkt, zigzag_encode(800)); // y
    pu(&mut pkt, zigzag_encode(0)); // vx
    pu(&mut pkt, zigzag_encode(0)); // vz
    pu(&mut pkt, zigzag_encode(0)); // vy
    pkt.push(10); // body yaw
    pkt.push(20); // aim yaw
    pkt.push((-5i8) as u8); // aim pitch (signed)
    pu(&mut pkt, 0); // mode
    pu(&mut pkt, 0); // state
    pu(&mut pkt, 0); // reserved
    pu(&mut pkt, 0); // reserved
    pkt.push(0x2A); // trailing tick (1 byte, in [1,3])

    let n = pkt.len();
    match parse_with_profile(&pkt, 0, n, -1, &prof, 0) {
        Some(c) => {
            let r = c.records();
            r.len() == 1
                && r[0].id == 5
                && r[0].x == zigzag_encode(600)
                && r[0].pos_signed() == (600, 700, 800)
                && r[0].body_yaw_raw == 10
                && r[0].aim_yaw_raw == 20
                && r[0].aim_pitch_raw == -5
                && !r[0].is_self_echo
        }
        None => false,
    }
}
