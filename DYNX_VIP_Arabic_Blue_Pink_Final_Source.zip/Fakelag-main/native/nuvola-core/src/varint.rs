//! LEB128 varint codec. Reader ported from
//! `com.nuvola.app.decode.body.WireReader`; the writer/zigzag helpers are
//! unified from the copies scattered across `PositionSync`/`AimFilter`/
//! `MarkFilter` (the Java side re-implements them per rewrite site).
//!
//! Encoding rules (the trap that desyncs naive parsers): `U`/`Z`/floats are ONE
//! LEB128 varint (type changes interpretation, never length); `B` is ONE raw
//! byte; `S` is a zigzag varint byte-length then that many raw UTF-8 bytes.

/// A cursor over a decrypted message body. Every read is bounds-checked and
/// sets `bad` rather than panicking, so a mis-keyed body degrades to "no data".
pub struct WireReader<'a> {
    b: &'a [u8],
    i: usize,
    end: usize,
    /// Set once a read runs off the end or overflows; stays set.
    pub bad: bool,
}

impl<'a> WireReader<'a> {
    pub fn new(buf: &'a [u8]) -> Self {
        WireReader { b: buf, i: 0, end: buf.len(), bad: false }
    }

    pub fn pos(&self) -> usize {
        self.i
    }

    pub fn has_more(&self) -> bool {
        !self.bad && self.i < self.end
    }

    /// LEB128 unsigned varint — every scalar except B, S and FixUInt16.
    pub fn u(&mut self) -> u64 {
        if self.bad {
            return 0;
        }
        let mut v: u64 = 0;
        let mut shift: u32 = 0;
        while self.i < self.end {
            let c = self.b[self.i] as u64;
            self.i += 1;
            v |= (c & 0x7f) << shift;
            if (c & 0x80) == 0 {
                return v;
            }
            shift += 7;
            if shift > 63 {
                break;
            }
        }
        self.bad = true;
        0
    }

    /// Zigzag-decoded varint. Mirrors Java `(v >>> 1) ^ -(v & 1)`.
    pub fn z(&mut self) -> i64 {
        let v = self.u();
        ((v >> 1) ^ (v & 1).wrapping_neg()) as i64
    }

    /// One RAW byte. Reading this as a varint is the classic desync.
    pub fn raw_byte(&mut self) -> u32 {
        if self.bad || self.i >= self.end {
            self.bad = true;
            return 0;
        }
        let b = self.b[self.i] as u32;
        self.i += 1;
        b
    }

    /// Skip `n` varint fields.
    pub fn skip_u(&mut self, n: usize) {
        for _ in 0..n {
            if self.bad {
                break;
            }
            self.u();
        }
    }
}

/// Number of bytes an unsigned LEB128 encoding of `u` occupies.
pub fn varint_width(mut u: u64) -> usize {
    let mut w = 1;
    u >>= 7;
    while u != 0 {
        w += 1;
        u >>= 7;
    }
    w
}

/// Zigzag-encode a signed value. Mirrors Java `(v << 1) ^ (v >> 63)`.
pub fn zigzag_encode(v: i64) -> u64 {
    ((v << 1) ^ (v >> 63)) as u64
}

/// Zigzag-decode.
pub fn zigzag_decode(u: u64) -> i64 {
    ((u >> 1) ^ (u & 1).wrapping_neg()) as i64
}

/// Write an unsigned LEB128 varint into `out`, returning the byte count.
/// Caller must ensure `out.len() >= varint_width(u)`.
pub fn write_varint(out: &mut [u8], mut u: u64) -> usize {
    let mut n = 0;
    loop {
        let mut byte = (u & 0x7f) as u8;
        u >>= 7;
        if u != 0 {
            byte |= 0x80;
        }
        out[n] = byte;
        n += 1;
        if u == 0 {
            break;
        }
    }
    n
}

/// Write an unsigned LEB128 varint padded to exactly `width` bytes (continuation
/// bits set on all but the last), for in-place rewrites that must not change the
/// field's byte length. Mirrors the padded writers in the Java rewrite sites.
pub fn write_varint_padded(out: &mut [u8], mut u: u64, width: usize) -> usize {
    for (j, slot) in out.iter_mut().take(width).enumerate() {
        let mut byte = (u & 0x7f) as u8;
        u >>= 7;
        if j + 1 < width {
            byte |= 0x80;
        }
        *slot = byte;
    }
    width
}
