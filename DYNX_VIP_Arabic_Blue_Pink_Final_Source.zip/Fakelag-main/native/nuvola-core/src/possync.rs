//! Cmd 2001 (UDP_PLAYER_STATE_SYNC) position-report codec. Direct port of
//! `com.nuvola.app.decode.body.PositionSync`.
//!
//! The 10 Hz outbound keepalive is the sole authority on where the server thinks
//! the player is; Teleport/Aim/Mark rewrite it. Body layout after the 8-byte
//! (non-reliable) header: one `objectHandle` varint, then exactly 23 body
//! varints (plaintext LEB128, each minimum-width; zigzag-encoded game units).
//!
//! Two rules that make a rewrite safe (both learned the hard way in the Java):
//! 1. A value can outgrow its field. `set_signed` writes in place padded to the
//!    field's existing width (byte-identical size, but non-canonical padding is a
//!    signature the game never emits — prefer `rebuild` where a length change is
//!    tolerable). `rebuild` re-encodes the whole body canonically and repairs the
//!    packet's own DATA_LEN.
//! 2. CRC-7 (byte 1) must be re-sealed after any edit ≥ offset 2, or the server
//!    drops the packet as corrupt.
//!
//! Signatures mirror the Java `(buf, off, len)` form so `buf` can be the whole
//! datagram buffer and `rebuild` may grow the packet up to `buf.len()`.

use crate::header::{msgkey, Field, HeaderLayout};
use crate::varint::{varint_width, zigzag_decode, zigzag_encode};
use crate::crc7;

pub const BODY_VARINTS: usize = 23;

pub const V_POS_X: usize = 0;
pub const V_POS_Z: usize = 1;
pub const V_POS_Y: usize = 2;
pub const V_MOVE_DIR_X: usize = 6;
pub const V_MOVE_DIR_Z: usize = 7;
pub const V_VEL_X: usize = 8;
pub const V_VEL_Z: usize = 9;
pub const V_VEL_Y: usize = 10;
pub const V_PHYS_STATE: usize = 11;
pub const V_POSE: usize = 12;
pub const V_PLATFORM_ID: usize = 16;

/// Parsed view + staging buffer for one position report. Not self-referential:
/// every method takes the packet buffer, so one instance is reused per tun loop
/// (allocation-free), matching the Java.
pub struct PosSync {
    starts: [usize; BODY_VARINTS],
    widths: [usize; BODY_VARINTS],
    raw: [u64; BODY_VARINTS],
    pending: [u64; BODY_VARINTS],
    off: usize,
    plen: usize,
    hdr_size: usize,
    handle_start: usize,
    valid: bool,
    /// Server-gated leash: the profile validity (unix seconds) that arms the
    /// position rewrite. 0 (unarmed) makes every mutation a no-op, so a client
    /// with no live licensed session cannot teleport. See
    /// `docs/SERVER_GATED_DECODE_DESIGN.md`.
    armed_until: u64,
}

impl Default for PosSync {
    fn default() -> Self {
        Self::new()
    }
}

/// Index just past one varint within `buf[i..end]`, or `None` when truncated.
fn skip_varint(buf: &[u8], mut i: usize, end: usize) -> Option<usize> {
    let mut shift = 0u32;
    while i < end {
        let c = buf[i];
        i += 1;
        if (c & 0x80) == 0 {
            return Some(i);
        }
        shift += 7;
        if shift > 63 {
            return None;
        }
    }
    None
}

impl PosSync {
    pub fn new() -> Self {
        PosSync {
            starts: [0; BODY_VARINTS],
            widths: [0; BODY_VARINTS],
            raw: [0; BODY_VARINTS],
            pending: [0; BODY_VARINTS],
            off: 0,
            plen: 0,
            hdr_size: 0,
            handle_start: 0,
            valid: false,
            armed_until: 0,
        }
    }

    /// Arm the position-rewrite leash with the server profile's validity
    /// (unix seconds). Until this is a future time, `set_signed` and `rebuild`
    /// no-op, leaving the original valid packet untouched. Re-armed each time a
    /// fresh /config profile arrives.
    pub fn arm(&mut self, valid_until: u64) {
        self.armed_until = valid_until;
    }

    /// True when armed with a still-valid entitlement at `now`.
    pub fn is_armed(&self, now: u64) -> bool {
        crate::entitled(self.armed_until, now)
    }

    /// Parse one outbound packet at `buf[off..off+len]`. Returns false (leaving
    /// the packet untouched) for anything that is not a well-formed 23-varint
    /// position report.
    pub fn parse(&mut self, buf: &[u8], off: usize, len: usize) -> bool {
        self.valid = false;
        if len < 12 || !crate::in_bounds(off, len, buf.len()) {
            return false;
        }
        let hdr = msgkey::header_size_of(&buf[off..off + len]);
        if hdr != msgkey::HEADER_NON_RELIABLE as i32 {
            return false;
        }
        let hdr = hdr as usize;

        let end = off + len;
        let mut i = match skip_varint(buf, off + hdr, end) {
            Some(x) => x,
            None => return false,
        };

        for k in 0..BODY_VARINTS {
            if i >= end {
                return false;
            }
            let start = i;
            let mut v: u64 = 0;
            let mut shift = 0u32;
            loop {
                if i >= end {
                    return false;
                }
                let c = buf[i] as u64;
                i += 1;
                v |= (c & 0x7f) << shift;
                if (c & 0x80) == 0 {
                    break;
                }
                shift += 7;
                if shift > 63 {
                    return false;
                }
            }
            self.starts[k] = start;
            self.widths[k] = i - start;
            self.raw[k] = v;
        }
        if i != end {
            return false; // must consume the body exactly
        }

        self.off = off;
        self.plen = len;
        self.hdr_size = hdr;
        self.handle_start = off + hdr;
        self.valid = true;
        self.pending = self.raw;
        true
    }

    pub fn is_valid(&self) -> bool {
        self.valid
    }

    pub fn length(&self) -> usize {
        self.plen
    }

    /// The signed (zigzag-decoded) value at a body index.
    pub fn signed_at(&self, index: usize) -> i64 {
        zigzag_decode(self.raw[index])
    }

    /// The raw (undecoded) varint at a body index.
    pub fn raw_at(&self, index: usize) -> u64 {
        self.raw[index]
    }

    /// True when `value` would still fit the byte width this field already
    /// occupies. Check the whole triple before writing any of it.
    pub fn fits_signed(&self, index: usize, value: i64) -> bool {
        varint_width(zigzag_encode(value)) <= self.widths[index]
    }

    /// Write a zigzag value in place, padded to its existing byte width. Returns
    /// false (leaving the packet untouched) when the value needs more bytes than
    /// the field has, or when the server-gated leash is not armed for `now`.
    pub fn set_signed(&mut self, buf: &mut [u8], index: usize, value: i64, now: u64) -> bool {
        if !self.valid || !self.is_armed(now) {
            return false;
        }
        let mut u = zigzag_encode(value);
        let w = self.widths[index];
        if varint_width(u) > w {
            return false;
        }
        let p = self.starts[index];
        for k in 0..w - 1 {
            buf[p + k] = ((u & 0x7f) | 0x80) as u8;
            u >>= 7;
        }
        buf[p + w - 1] = (u & 0x7f) as u8;
        self.raw[index] = zigzag_encode(value);
        self.pending[index] = self.raw[index];
        true
    }

    /// Recompute CRC-7 over the packet as it now stands. Must follow any edit.
    pub fn seal(&self, buf: &mut [u8]) -> bool {
        if !self.valid {
            return false;
        }
        crc7::seal(&mut buf[self.off..self.off + self.plen]);
        true
    }

    /// Stage a value for `rebuild` (no width limit — rebuild re-encodes the body).
    pub fn stage_signed(&mut self, index: usize, value: i64) {
        self.pending[index] = zigzag_encode(value);
    }

    /// Re-encode the whole body canonically with the staged values, fix the
    /// packet's DATA_LEN, and reseal the checksum. Returns the new total packet
    /// length, or -1 when the packet was left untouched (stale layout, no room,
    /// or the server-gated leash is not armed for `now` — the teleport no-op).
    pub fn rebuild(&mut self, buf: &mut [u8], layout: &HeaderLayout, now: u64) -> i32 {
        if !self.valid || !self.is_armed(now) {
            return -1;
        }
        let reliable = self.hdr_size == msgkey::HEADER_RELIABLE;

        // Prove the layout decodes THIS packet before trusting it to encode:
        // an outbound packet's DATA_LEN must equal the payload actually present.
        // A stale mask/permutation would otherwise write a wrong length and the
        // server drops the session. Refuse (caller withholds one report).
        let declared = layout.read_short(buf, self.off, Field::DataLen, reliable);
        if declared != (self.plen - self.hdr_size) as i32 {
            return -1;
        }

        // Encode into a local scratch (handle copied through unchanged).
        let mut scratch = [0u8; 256];
        let body_start = self.starts[0];
        if body_start < self.handle_start {
            return -1;
        }
        let handle_bytes = body_start - self.handle_start;
        if handle_bytes > scratch.len() {
            return -1;
        }
        scratch[..handle_bytes].copy_from_slice(&buf[self.handle_start..body_start]);
        let mut p = handle_bytes;

        for k in 0..BODY_VARINTS {
            let mut u = self.pending[k];
            loop {
                if p >= scratch.len() {
                    return -1;
                }
                let c = (u & 0x7f) as u8;
                u >>= 7;
                if u != 0 {
                    scratch[p] = c | 0x80;
                    p += 1;
                } else {
                    scratch[p] = c;
                    p += 1;
                    break;
                }
            }
        }

        let new_payload = p;
        let new_len = self.hdr_size + new_payload;
        if self.off + new_len > buf.len() {
            return -1; // no room
        }

        buf[self.off + self.hdr_size..self.off + self.hdr_size + new_payload]
            .copy_from_slice(&scratch[..new_payload]);
        layout.write_short(buf, self.off, Field::DataLen, reliable, new_payload as i32);

        self.plen = new_len;
        crc7::seal(&mut buf[self.off..self.off + new_len]);
        self.raw = self.pending;
        new_len as i32
    }
}
