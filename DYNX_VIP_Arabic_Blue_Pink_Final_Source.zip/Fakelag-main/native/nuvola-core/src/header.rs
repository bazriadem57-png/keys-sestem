//! UDP header codec: the one-byte XOR mask + the `HEAD_SECRET` field
//! permutation. Direct port of `com.nuvola.app.decode.frame.{MsgKey,
//! HeaderField, HeaderLayout}`.
//!
//! The long-standing "the mask rotates per session" observation is really a
//! field *permutation* (`HEAD_SECRET`, an int[5]) plus a single XOR byte (=
//! `SECRET_KEY[0]`) applied to every header byte from index 2 on. Byte 0
//! (`MsgKey`) is the only plaintext discriminator and the only thing that tells
//! a receiver the header size before the session key is solved.

use crate::crc7;

/// Packet byte-0 framing discriminator.
pub mod msgkey {
    pub const MIN: i32 = 90;
    pub const MID: i32 = 100;
    pub const MAX: i32 = 110;
    pub const HEADER_RELIABLE: usize = 10;
    pub const HEADER_NON_RELIABLE: usize = 8;
    pub const NOT_MATCH_TRAFFIC: i32 = -1;

    pub fn is_valid(k: i32) -> bool {
        (MIN..=MAX).contains(&k)
    }
    pub fn is_reliable(k: i32) -> bool {
        (MIN..MID).contains(&k)
    }
    pub fn header_size(k: i32) -> i32 {
        if (MIN..MID).contains(&k) {
            HEADER_RELIABLE as i32
        } else if (MID..=MAX).contains(&k) {
            HEADER_NON_RELIABLE as i32
        } else {
            NOT_MATCH_TRAFFIC
        }
    }
    /// Header size for a packet buffer, or NOT_MATCH_TRAFFIC.
    pub fn header_size_of(pkt: &[u8]) -> i32 {
        if pkt.is_empty() {
            return NOT_MATCH_TRAFFIC;
        }
        let hdr = header_size(pkt[0] as i32);
        if hdr > 0 && pkt.len() >= hdr as usize {
            hdr
        } else {
            NOT_MATCH_TRAFFIC
        }
    }
}

/// The five header fields. The discriminant is the `HEAD_SECRET` id, matching
/// the Java enum ordinal, so `HEAD_SECRET[i]` indexes straight in.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Field {
    SendOption = 0,
    Cmd = 1,
    OrderId = 2,
    Flags = 3,
    DataLen = 4,
}

pub const FIELD_COUNT: usize = 5;

pub const DEFAULT_ORDER: [Field; FIELD_COUNT] = [
    Field::SendOption,
    Field::Cmd,
    Field::OrderId,
    Field::Flags,
    Field::DataLen,
];

impl Field {
    pub fn id(self) -> usize {
        self as usize
    }
    pub fn width(self) -> usize {
        match self {
            Field::Cmd | Field::OrderId | Field::DataLen => 2,
            Field::SendOption | Field::Flags => 1,
        }
    }
    /// ORDER_ID is present on reliable packets only.
    pub fn reliable_only(self) -> bool {
        matches!(self, Field::OrderId)
    }
    pub fn is_present(self, reliable: bool) -> bool {
        reliable || !self.reliable_only()
    }
    pub fn from_id(id: usize) -> Option<Field> {
        match id {
            0 => Some(Field::SendOption),
            1 => Some(Field::Cmd),
            2 => Some(Field::OrderId),
            3 => Some(Field::Flags),
            4 => Some(Field::DataLen),
            _ => None,
        }
    }
}

/// A solved header encoding: the XOR mask plus per-field byte offsets, computed
/// once per session and read lock-free. Offsets are -1 when the field is absent.
#[derive(Clone)]
pub struct HeaderLayout {
    mask: u8,
    order: [Field; FIELD_COUNT],
    reliable_offsets: [i32; FIELD_COUNT],
    non_reliable_offsets: [i32; FIELD_COUNT],
}

fn lay_out(order: &[Field; FIELD_COUNT], reliable: bool) -> Option<[i32; FIELD_COUNT]> {
    let mut offsets = [-1i32; FIELD_COUNT];
    let mut seen = [false; FIELD_COUNT];
    let mut off = crc7::COVERED_FROM as i32; // 2
    for &f in order.iter() {
        let id = f.id();
        if seen[id] {
            return None; // duplicate → not a permutation
        }
        seen[id] = true;
        if !f.is_present(reliable) {
            offsets[id] = -1;
            continue;
        }
        offsets[id] = off;
        off += f.width() as i32;
    }
    let expected = if reliable {
        msgkey::HEADER_RELIABLE
    } else {
        msgkey::HEADER_NON_RELIABLE
    } as i32;
    if off == expected {
        Some(offsets)
    } else {
        None
    }
}

impl HeaderLayout {
    /// Build a layout from a mask and a permutation of all five fields, or
    /// `None` when `order` is not a permutation.
    pub fn new(mask: u8, order: [Field; FIELD_COUNT]) -> Option<HeaderLayout> {
        let reliable_offsets = lay_out(&order, true)?;
        let non_reliable_offsets = lay_out(&order, false)?;
        Some(HeaderLayout {
            mask,
            order,
            reliable_offsets,
            non_reliable_offsets,
        })
    }

    /// The game's fallback encoding: default order, no mask.
    pub fn default_layout() -> HeaderLayout {
        HeaderLayout::new(0, DEFAULT_ORDER).expect("default order is a permutation")
    }

    pub fn mask(&self) -> u8 {
        self.mask
    }
    pub fn order(&self) -> &[Field; FIELD_COUNT] {
        &self.order
    }

    pub fn offset_of(&self, field: Field, reliable: bool) -> i32 {
        let table = if reliable {
            &self.reliable_offsets
        } else {
            &self.non_reliable_offsets
        };
        table[field.id()]
    }

    pub fn header_size(&self, reliable: bool) -> usize {
        if reliable {
            msgkey::HEADER_RELIABLE
        } else {
            msgkey::HEADER_NON_RELIABLE
        }
    }

    /// Read a 1-byte field, unmasking it. -1 when the field is absent.
    pub fn read_byte(&self, pkt: &[u8], base: usize, field: Field, reliable: bool) -> i32 {
        let o = self.offset_of(field, reliable);
        if o < 0 {
            return -1;
        }
        ((pkt[base + o as usize] as i32) & 0xFF) ^ (self.mask as i32)
    }

    /// Read a 2-byte little-endian field, unmasking both bytes. -1 when absent.
    pub fn read_short(&self, pkt: &[u8], base: usize, field: Field, reliable: bool) -> i32 {
        let o = self.offset_of(field, reliable);
        if o < 0 {
            return -1;
        }
        let o = base + o as usize;
        let lo = (pkt[o] as i32 & 0xFF) ^ (self.mask as i32);
        let hi = (pkt[o + 1] as i32 & 0xFF) ^ (self.mask as i32);
        lo | (hi << 8)
    }

    /// Write a 1-byte field, applying the mask. No-op when absent.
    pub fn write_byte(&self, pkt: &mut [u8], base: usize, field: Field, reliable: bool, value: i32) {
        let o = self.offset_of(field, reliable);
        if o < 0 {
            return;
        }
        pkt[base + o as usize] = ((value & 0xFF) ^ (self.mask as i32)) as u8;
    }

    /// Write a 2-byte little-endian field, applying the mask. No-op when absent.
    pub fn write_short(&self, pkt: &mut [u8], base: usize, field: Field, reliable: bool, value: i32) {
        let o = self.offset_of(field, reliable);
        if o < 0 {
            return;
        }
        let o = base + o as usize;
        pkt[o] = ((value & 0xFF) ^ (self.mask as i32)) as u8;
        pkt[o + 1] = (((value >> 8) & 0xFF) ^ (self.mask as i32)) as u8;
    }
}
