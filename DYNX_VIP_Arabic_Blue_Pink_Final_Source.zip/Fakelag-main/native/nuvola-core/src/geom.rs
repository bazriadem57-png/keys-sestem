//! Screen-space angle & coordinate math shared by the touch multiplexer
//! (`nuvola-touchmux`) and, later, aim targeting.
//!
//! ESP already knows the live screen dimensions in px (it projects boxes into
//! them every frame). These helpers convert between three spaces:
//!
//! * **px** — display pixels, what ESP and the overlay work in;
//! * **norm** — the `0..=65535` per-axis range the uinput/touch layer speaks
//!   (the daemon scales norm onto the panel's absolute range, which Android in
//!   turn maps back onto the display, so a norm value is a screen fraction);
//! * **angle** — view yaw/pitch degrees, for turning an on-screen target offset
//!   into a look-swipe (future real aim; the current build only self-drives a
//!   circle).
//!
//! Pure and allocation-free — the same discipline as the rest of `nuvola-core`.
//! No `unsafe`; `f32` trig via `std` is fine here (this is not the packet hot
//! path, and the touch tick runs at ~60 Hz, not per-packet).

/// Full circle in radians (`2*pi`), so callers need no `std::f32::consts` import.
pub const TAU: f32 = core::f32::consts::TAU;

/// Degrees → radians.
#[inline]
pub fn deg2rad(deg: f32) -> f32 {
    deg * (core::f32::consts::PI / 180.0)
}

/// Radians → degrees.
#[inline]
pub fn rad2deg(rad: f32) -> f32 {
    rad * (180.0 / core::f32::consts::PI)
}

/// Clamp a pixel coordinate on an axis of `dim` px into `0..=65535`, the
/// normalised range the touch daemon uses. `dim == 0` maps to 0 (degenerate).
#[inline]
pub fn norm(px: f32, dim: u32) -> u16 {
    if dim == 0 {
        return 0;
    }
    let v = (px / dim as f32) * 65535.0;
    if v <= 0.0 {
        0
    } else if v >= 65535.0 {
        65535
    } else {
        // round-to-nearest; v is in [0,65535] so the cast cannot overflow u16.
        (v + 0.5) as u16
    }
}

/// Inverse of [`norm`]: a normalised value back to px on a `dim`-px axis.
#[inline]
pub fn denorm(n: u16, dim: u32) -> f32 {
    (n as f32 / 65535.0) * dim as f32
}

/// Advance a swipe angle by `step` radians, wrapped into `[0, TAU)`. Keeps the
/// accumulator bounded over a long-running swipe so `f32` precision never drifts.
#[inline]
pub fn advance_angle(angle: f32, step: f32) -> f32 {
    let a = angle + step;
    if a >= TAU {
        a - TAU
    } else if a < 0.0 {
        a + TAU
    } else {
        a
    }
}

/// A point on a true (in-px) circle of radius `r_px` about `(cx_px, cy_px)` at
/// `angle` radians, returned as normalised `(x, y)` for a `w x h` px screen.
///
/// Each axis is normalised independently, which is exactly what the daemon
/// needs: it maps norm→panel-abs→display per axis, so this lands a round circle
/// on the actual screen regardless of aspect ratio.
#[inline]
pub fn circle_point_norm(cx: f32, cy: f32, r: f32, angle: f32, w: u32, h: u32) -> (u16, u16) {
    let x = cx + r * angle.cos();
    let y = cy + r * angle.sin();
    (norm(x, w), norm(y, h))
}

/// Keep a swipe circle fully on screen: clamp its centre so the whole circle of
/// radius `r` fits within `margin` px of every edge. Returns the adjusted
/// `(cx, cy)`. Mirrors the clamp the Java side used to do, moved here so the
/// geometry lives in one place.
#[inline]
pub fn clamp_circle_center(cx: f32, cy: f32, r: f32, w: u32, h: u32, margin: f32) -> (f32, f32) {
    let lo_x = r + margin;
    let hi_x = (w as f32 - r - margin).max(lo_x);
    let lo_y = r + margin;
    let hi_y = (h as f32 - r - margin).max(lo_y);
    (cx.clamp(lo_x, hi_x), cy.clamp(lo_y, hi_y))
}

/// The camera model the ESP renderer actually uses, reproduced exactly.
///
/// `EspRenderView` does NOT treat `FOV_X_DEG` as the literal horizontal field of
/// view. It interprets it as the horizontal FOV **at a 16:9 reference**, derives
/// the aspect-independent vertical half-tangent from it, then re-derives the real
/// horizontal half-tangent from the true viewport aspect (HOR+). On this device
/// (2340x1080, 2.17:1) a `FOV_X_DEG` of 90 is an *effective* hFOV of ~103 deg.
///
/// It also applies a vertical trim (`FOV_Y_SCALE`) and divides both axes by
/// `FOV_ZOOM`. Reproduced from `EspRenderView`:
///
/// ```text
/// tan_half_v = tan(FOV_X_DEG / 2) / (16/9)
/// tan_half_x = tan_half_v * (vp_w / vp_h) / zoom
/// tan_half_y = tan_half_v * FOV_Y_SCALE   / zoom
/// ```
///
/// Getting this wrong is not a small error: with the defaults at 2340x1080 the
/// naive "treat fov_x_deg literally, take the vertical from the aspect" model is
/// a uniform 0.82x on BOTH half-tangents (every derived angle ~18% short), and it
/// stops being a uniform scale the moment `fov_y_scale` or `zoom` moves off 1.0.
/// The zoom term is the load-bearing one for scoped aim: a scope IS a zoom, so a
/// model without it cannot express the scoped case at all.
#[derive(Clone, Copy, Debug)]
pub struct ViewProjection {
    tan_half_x: f32,
    tan_half_y: f32,
}

/// The reference aspect `FOV_X_DEG` is quoted at, matching `EspRenderView`.
pub const REF_ASPECT: f32 = 16.0 / 9.0;

impl ViewProjection {
    /// Build from the renderer's own knobs. `fov_x_deg` is the 16:9-reference
    /// horizontal FOV (`EspRenderView::FOV_X_DEG`), `w`/`h` the GAME viewport,
    /// `fov_y_scale` the vertical trim, `zoom` the scope/zoom factor (1.0 = hip).
    ///
    /// A non-positive `zoom` is treated as 1.0, exactly as the renderer's
    /// `(FOV_ZOOM > 0.05) ? FOV_ZOOM : 1` guard does.
    pub fn new(fov_x_deg: f32, w: u32, h: u32, fov_y_scale: f32, zoom: f32) -> Self {
        let z = if zoom > 0.05 { zoom } else { 1.0 };
        let aspect = if w == 0 || h == 0 { REF_ASPECT } else { w as f32 / h as f32 };
        let tan_half_v = deg2rad(fov_x_deg * 0.5).tan() / REF_ASPECT;
        Self {
            tan_half_x: tan_half_v * aspect / z,
            tan_half_y: tan_half_v * fov_y_scale / z,
        }
    }

    /// The EFFECTIVE horizontal FOV in degrees — what the projection really uses,
    /// not the `fov_x_deg` setting that was fed in.
    pub fn effective_hfov_deg(&self) -> f32 {
        2.0 * rad2deg(self.tan_half_x.atan())
    }

    /// The effective vertical FOV in degrees.
    pub fn effective_vfov_deg(&self) -> f32 {
        2.0 * rad2deg(self.tan_half_y.atan())
    }

    /// Screen offset from the crosshair -> view **(yaw, pitch)** error in degrees.
    /// `dx_px` is pixels right of centre, `dy_px` pixels DOWN. Pitch is negated so
    /// a target above the crosshair reads as a positive look-up error, matching
    /// the renderer's `cy - (...)` sign.
    pub fn yaw_pitch_from_offset(&self, dx_px: f32, dy_px: f32, w: u32, h: u32) -> (f32, f32) {
        if w == 0 || h == 0 {
            return (0.0, 0.0);
        }
        let ndc_x = dx_px / (w as f32 * 0.5);
        let ndc_y = dy_px / (h as f32 * 0.5);
        (
            rad2deg((ndc_x * self.tan_half_x).atan()),
            -rad2deg((ndc_y * self.tan_half_y).atan()),
        )
    }

    /// The forward half: a camera-space direction -> pixel offset from centre,
    /// computed the way `EspRenderView::project` does
    /// (`cx + (camX/depth/tan_half_x) * halfW`, `cy - (camY/depth/tan_half_y) * halfH`).
    /// Exists so the inverse above can be proven against it.
    pub fn offset_from_camera(
        &self,
        cam_x: f32,
        cam_y: f32,
        depth: f32,
        w: u32,
        h: u32,
    ) -> (f32, f32) {
        if depth <= 0.0 || w == 0 || h == 0 {
            return (0.0, 0.0);
        }
        (
            (cam_x / depth / self.tan_half_x) * (w as f32 * 0.5),
            -(cam_y / depth / self.tan_half_y) * (h as f32 * 0.5),
        )
    }
}

/// Turn an on-screen offset from the crosshair into a view **(yaw, pitch)** error
/// in degrees. Thin wrapper over [`ViewProjection`] for callers that have the raw
/// renderer knobs to hand.
///
/// `dx_px`/`dy_px` are pixels right/down of the aim centre on a `w x h` screen.
/// `fov_x_deg` is the **16:9-reference** horizontal FOV (`EspRenderView::FOV_X_DEG`),
/// `fov_y_scale` the vertical trim (`FOV_Y_SCALE`, 1.0 = none) and `zoom` the
/// scope factor (`FOV_ZOOM`, 1.0 = hip). Pure trig; no allocation.
#[inline]
pub fn screen_offset_to_yaw_pitch_deg(
    dx_px: f32,
    dy_px: f32,
    w: u32,
    h: u32,
    fov_x_deg: f32,
    fov_y_scale: f32,
    zoom: f32,
) -> (f32, f32) {
    ViewProjection::new(fov_x_deg, w, h, fov_y_scale, zoom)
        .yaw_pitch_from_offset(dx_px, dy_px, w, h)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn approx(a: f32, b: f32, eps: f32) -> bool {
        (a - b).abs() <= eps
    }

    #[test]
    fn norm_endpoints_and_clamp() {
        assert_eq!(norm(0.0, 1080), 0);
        assert_eq!(norm(1080.0, 1080), 65535);
        assert_eq!(norm(-50.0, 1080), 0); // clamped low
        assert_eq!(norm(5000.0, 1080), 65535); // clamped high
        assert_eq!(norm(540.0, 1080), 32768); // midpoint (round-to-nearest)
        assert_eq!(norm(100.0, 0), 0); // degenerate dim
    }

    #[test]
    fn norm_denorm_roundtrip() {
        for &(px, dim) in &[(0.0f32, 1080u32), (270.0, 1080), (539.0, 1080), (1234.0, 2340)] {
            let back = denorm(norm(px, dim), dim);
            // within one norm quantum (dim/65535 px)
            assert!(approx(back, px, dim as f32 / 65535.0 + 0.6), "px={px} dim={dim} back={back}");
        }
    }

    #[test]
    fn circle_points_cardinal() {
        // centre (500,500), r=100, on a 1000x1000 screen -> norm scale 65.535/px.
        let (w, h) = (1000u32, 1000u32);
        let n = |px: f32| norm(px, 1000);
        // angle 0 -> (cx+r, cy)
        assert_eq!(circle_point_norm(500.0, 500.0, 100.0, 0.0, w, h), (n(600.0), n(500.0)));
        // TAU/4 -> (cx, cy+r)
        let (x, y) = circle_point_norm(500.0, 500.0, 100.0, TAU / 4.0, w, h);
        assert!((x as i32 - n(500.0) as i32).abs() <= 1);
        assert!((y as i32 - n(600.0) as i32).abs() <= 1);
    }

    #[test]
    fn advance_angle_wraps() {
        assert!(approx(advance_angle(0.0, 0.30), 0.30, 1e-6));
        let a = advance_angle(TAU - 0.10, 0.30);
        assert!(a >= 0.0 && a < TAU && approx(a, 0.20, 1e-4));
    }

    #[test]
    fn clamp_center_keeps_circle_on_screen() {
        // Near the top-left corner, r=130: centre pushed in to (134,134).
        let (cx, cy) = clamp_circle_center(20.0, 20.0, 130.0, 1080, 2340, 4.0);
        assert!(approx(cx, 134.0, 0.01) && approx(cy, 134.0, 0.01));
        // Well inside: unchanged.
        let (cx2, cy2) = clamp_circle_center(540.0, 1170.0, 130.0, 1080, 2340, 4.0);
        assert!(approx(cx2, 540.0, 0.01) && approx(cy2, 1170.0, 0.01));
    }

    #[test]
    fn yaw_pitch_zero_at_center_and_signed() {
        let vp = ViewProjection::new(90.0, 2340, 1080, 1.0, 1.0);
        let (yaw, pitch) = vp.yaw_pitch_from_offset(0.0, 0.0, 2340, 1080);
        assert!(approx(yaw, 0.0, 1e-4) && approx(pitch, 0.0, 1e-4));
        // right of centre => positive yaw; below centre => negative pitch
        let (yaw_r, _) = vp.yaw_pitch_from_offset(400.0, 0.0, 2340, 1080);
        assert!(yaw_r > 0.0);
        let (_, pitch_d) = vp.yaw_pitch_from_offset(0.0, 300.0, 2340, 1080);
        assert!(pitch_d < 0.0);
    }

    /// `FOV_X_DEG` is quoted at 16:9; on a 2.17:1 panel the projection really
    /// uses ~103 deg. Hand-checked: tan(45)/(16/9) = 0.5625, x (2340/1080) =
    /// 1.21875, atan = 50.62 deg, doubled = 101.2 deg.
    #[test]
    fn effective_hfov_is_widened_by_the_real_aspect() {
        let vp = ViewProjection::new(90.0, 2340, 1080, 1.0, 1.0);
        assert!(approx(vp.effective_hfov_deg(), 101.25, 0.1), "{}", vp.effective_hfov_deg());
        // At the reference aspect it must return exactly what was quoted.
        let ref_vp = ViewProjection::new(90.0, 1600, 900, 1.0, 1.0);
        assert!(approx(ref_vp.effective_hfov_deg(), 90.0, 0.05));
    }

    /// THE PARITY TEST. Project a known camera-space direction the way
    /// `EspRenderView::project` does, feed the resulting pixel offset back through
    /// the inverse, and require the original angle back. Swept across aspects,
    /// vertical trims and zooms — the three knobs the old implementation ignored.
    #[test]
    fn projection_round_trip_matches_esp_across_all_knobs() {
        let screens = [(2340u32, 1080u32), (1920, 1080), (1600, 720), (1080, 2340)];
        let y_scales = [1.0f32, 0.92, 1.08];
        let zooms = [1.0f32, 2.0, 4.0, 8.0];
        let dirs = [
            (0.0f32, 0.0f32),
            (0.30, 0.10),
            (-0.45, -0.22),
            (0.05, -0.40),
            (-0.12, 0.33),
        ];
        let mut checked = 0;
        for &(w, h) in &screens {
            for &ys in &y_scales {
                for &z in &zooms {
                    let vp = ViewProjection::new(90.0, w, h, ys, z);
                    for &(cx, cy) in &dirs {
                        let depth = 25.0f32;
                        // Forward: ESP's own projection maths.
                        let (dx, dy) = vp.offset_from_camera(cx * depth, cy * depth, depth, w, h);
                        // Inverse: what the aim will call.
                        let (yaw, pitch) = vp.yaw_pitch_from_offset(dx, dy, w, h);
                        // Ground truth straight from the camera-space direction.
                        let want_yaw = rad2deg(cx.atan());
                        let want_pitch = rad2deg(cy.atan());
                        assert!(
                            approx(yaw, want_yaw, 0.02) && approx(pitch, want_pitch, 0.02),
                            "w={w} h={h} ys={ys} z={z} dir=({cx},{cy})                              got=({yaw},{pitch}) want=({want_yaw},{want_pitch})"
                        );
                        checked += 1;
                    }
                }
            }
        }
        assert_eq!(checked, 4 * 3 * 4 * 5);
    }

    /// A scope is a zoom: 8x must make the same pixel offset a much smaller angle.
    /// The old signature had no zoom term at all, so it could not express this.
    #[test]
    fn zoom_shrinks_the_angle_per_pixel() {
        let hip = ViewProjection::new(90.0, 2340, 1080, 1.0, 1.0);
        let x8 = ViewProjection::new(90.0, 2340, 1080, 1.0, 8.0);
        let (yaw_hip, _) = hip.yaw_pitch_from_offset(300.0, 0.0, 2340, 1080);
        let (yaw_8x, _) = x8.yaw_pitch_from_offset(300.0, 0.0, 2340, 1080);
        assert!(yaw_8x < yaw_hip / 5.0, "hip={yaw_hip} 8x={yaw_8x}");
        assert!(x8.effective_hfov_deg() < 20.0, "{}", x8.effective_hfov_deg());
    }

}
