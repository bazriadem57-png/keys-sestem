//! Outbound mounted-state carriers: Cmd 2002 `UDP_VEHICLE_STATE_SYNC` (car/bike,
//! no player aim) and Cmd 2069 `UDP_VEHICLEWEAPONFIRE_STATE_SYNC` (horse/mount,
//! carries a real aim forward). Direct port of
//! `com.nuvola.app.decode.body.VehicleSync`.
//!
//! Why it exists: the game never emits Cmd 2001 while mounted (the outbound
//! branch tests `IsInVehicle()` first), so mounting freezes the only first-hand
//! source of our own position and camera. These carriers restore it at 99 ms,
//! versus the self-echo fallback's quantised 198 ms.
//!
//! Two traps preserved verbatim from the Java:
//! 1. **Field 8 is ONE RAW BYTE** between the quaternion and the velocity. A
//!    varint walk over it eats the following byte the moment its value reaches
//!    0x80. The two source disassembly docs disagree (`WriteFixU8` vs a varint),
//!    so `parse` tries the raw-byte reading first and re-parses as a varint only
//!    when validation fails — which can only happen when that byte is >= 0x80.
//! 2. **Validate before use.** The quaternion components are scaled by 1000, so
//!    their squares must sum to ~1_000_000 (checked in the /1000 domain: ~1.0). A
//!    record that fails is refused outright, never half-applied: a partially
//!    parsed own-state is worse than none, because the renderer cannot tell it is
//!    wrong.
//!
//! No on-wire sample of either command exists in the 330-directory capture
//! corpus (every Cmd 2002 record there is the inbound batched vehicle list, a
//! different class). This parser is written from the disassembly and is
//! deliberately defensive; `tests/vehicle.rs` verifies it by round-tripping a
//! synthetic body built to the same rules and by exercising both the raw-byte /
//! varint retry and every rejection path.

use crate::varint::WireReader;

/// `UDP_VEHICLE_STATE_SYNC` — driver of a car/bike. No player aim.
pub const CMD_VEHICLE: i32 = 2002;
/// `UDP_VEHICLEWEAPONFIRE_STATE_SYNC` — horse/mount. Has player aim.
pub const CMD_VEHICLE_FIRE: i32 = 2069;

/// True when `cmd` is one this parser handles.
pub fn is_vehicle_carrier(cmd: i32) -> bool {
    cmd == CMD_VEHICLE || cmd == CMD_VEHICLE_FIRE
}

/// One decoded outbound vehicle-state body. `has_aim` (Cmd 2069 only) gates the
/// `aim_*` / `client_ms` fields; they are 0 otherwise.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct VehicleState {
    /// Vehicle LevelVehicle object id — NOT an ESP entity id.
    pub vehicle_id: u64,
    /// Vehicle world position in millimetres, wire order (X, UP, Z).
    pub x: i64,
    pub up: i64,
    pub z: i64,
    /// Vehicle rotation quaternion, already divided by 1000.
    pub qx: f32,
    pub qy: f32,
    pub qz: f32,
    pub qw: f32,
    /// Vehicle velocity in m/s.
    pub vx: f32,
    pub vup: f32,
    pub vz: f32,
    /// Undecoded input bitfield (field 8).
    pub packed_op: u32,
    /// Server tick — NOT a millisecond clock.
    pub server_tick: u64,
    /// True only for Cmd 2069: the player aim forward is present.
    pub has_aim: bool,
    /// Player aim forward, unit-ish, only when `has_aim`.
    pub aim_x: f32,
    pub aim_up: f32,
    pub aim_z: f32,
    /// Client millisecond clock, only when `has_aim`.
    pub client_ms: u64,
    /// True when field 8 had to be re-read as a varint.
    pub op_was_varint: bool,
}

impl VehicleState {
    /// The quaternion must be a unit quaternion (already /1000 here), so the sum
    /// of squares is ~1. A 5% band absorbs per-component quantisation without
    /// admitting a mis-parse, which shifts a whole field and misses by orders of
    /// magnitude rather than percent.
    fn quaternion_sane(&self) -> bool {
        let s = (self.qx as f64) * (self.qx as f64)
            + (self.qy as f64) * (self.qy as f64)
            + (self.qz as f64) * (self.qz as f64)
            + (self.qw as f64) * (self.qw as f64);
        s > 0.90 && s < 1.10
    }

    /// The aim forward is a direction; its length must be near 1.
    fn aim_sane(&self) -> bool {
        let s = (self.aim_x as f64) * (self.aim_x as f64)
            + (self.aim_up as f64) * (self.aim_up as f64)
            + (self.aim_z as f64) * (self.aim_z as f64);
        s > 0.80 && s < 1.25
    }
}

/// Parses one outbound vehicle-state body (the decrypted payload, no header).
///
/// Returns `None` when the body is malformed or fails validation — never a
/// partial result. `op_var_reads` / `rejected`, when non-null, are incremented
/// exactly as the Java `opVarintReads` / `rejected` diagnostic counters.
pub fn parse(cmd: i32, body: &[u8]) -> Option<VehicleState> {
    parse_counted(cmd, body, &mut 0, &mut 0)
}

/// `parse` with the two diagnostic counters threaded through, mirroring the Java
/// `opVarintReads()` / `rejected()` volatiles.
pub fn parse_counted(
    cmd: i32,
    body: &[u8],
    op_var_reads: &mut u64,
    rejected: &mut u64,
) -> Option<VehicleState> {
    if !is_vehicle_carrier(cmd) || body.is_empty() {
        return None;
    }
    if let Some(r) = try_parse(cmd, body, false) {
        return Some(r);
    }
    // Field 8 may be a varint after all (the two source docs disagree). This
    // branch is reachable only when that byte is >= 0x80.
    if let Some(mut r) = try_parse(cmd, body, true) {
        r.op_was_varint = true;
        *op_var_reads += 1;
        return Some(r);
    }
    *rejected += 1;
    None
}

// The fields are filled in wire-read order (each read advances the cursor and
// must happen in sequence), so a struct literal would not express the ordering
// any more clearly than default() + ordered assignment does.
#[allow(clippy::field_reassign_with_default)]
fn try_parse(cmd: i32, body: &[u8], op_as_varint: bool) -> Option<VehicleState> {
    let mut r = WireReader::new(body);
    let mut out = VehicleState::default();

    out.vehicle_id = r.u();

    out.x = r.z();
    out.up = r.z();
    out.z = r.z();

    out.qx = r.z() as f32 / 1000.0;
    out.qy = r.z() as f32 / 1000.0;
    out.qz = r.z() as f32 / 1000.0;
    out.qw = r.z() as f32 / 1000.0;

    // FIELD 8: ONE RAW BYTE by default. See the module doc.
    out.packed_op = if op_as_varint {
        (r.u() & 0xFF) as u32
    } else {
        r.raw_byte() & 0xFF
    };

    out.vx = r.z() as f32 / 100.0;
    out.vup = r.z() as f32 / 100.0;
    out.vz = r.z() as f32 / 100.0;

    out.server_tick = r.u();

    if cmd == CMD_VEHICLE_FIRE {
        out.aim_x = r.z() as f32 / 100.0;
        out.aim_up = r.z() as f32 / 100.0;
        out.aim_z = r.z() as f32 / 100.0;
        out.client_ms = r.u();
        out.has_aim = true;
    }

    if r.bad {
        return None;
    }
    // TERMINAL CURSOR: the body must be consumed exactly. A record that leaves
    // bytes over parsed to a different shape than the one intended.
    if r.pos() != body.len() {
        return None;
    }

    if !out.quaternion_sane() {
        return None;
    }
    if out.has_aim && !out.aim_sane() {
        return None;
    }
    Some(out)
}
