#!/usr/bin/env python3
"""Build a Cmd-2012 entity-chain golden from a same-session raw capture +
on-device decoded sidecar CSV.

Strategy (the repo's trusted oracle pattern): extract FULL (untruncated) chain
packets from capture_raw_20260910_183716.txt, decode each with a reference
implementation that mirrors EspEngine.parseStructured EXACTLY, then cross-check
the decoded (id, zz(x), zz(z), zz(y)) against the device's own independently
logged entities_20260910_183716.csv rows matched by `seq`. Only packets that
BOTH parse cleanly AND match the device decode are emitted. This proves: real
wire bytes -> decoder -> the same coordinates the device computed.
"""
import csv, json, os, sys

BASE = os.path.dirname(os.path.abspath(__file__))
REPO = r"C:\Users\Tonyt\Documents\GitHub\Fakelag"
DEVDIR = os.path.join(REPO, "captures", "device_pull_20260910", "dev_logs")
RAW = os.path.join(DEVDIR, "capture_raw_20260910_155351.txt")
CSVF = os.path.join(DEVDIR, "entities_20260910_155352.csv")
OUT = os.path.join(REPO, "native", "nuvola-core", "tests", "data", "chain2012_golden.json")

# ---- constants from EspEngine.java ----
CHAIN_HEADER = 10
CHAIN_MAX_LEN = 1400
MAX_CHAIN_RECORDS = 64
MIN_RECORD_BYTES = 16
MIN_RECORD_X = 500
MAX_ENTITY_ID = 64


def zz(v):  # zigzag decode, matches Java (v>>>1)^-(v&1) on 64-bit
    return (v >> 1) ^ -(v & 1)


def vi(d, pos, end):
    """Cursor LEB128; returns (value, ok). Mirrors EspEngine.vi."""
    v = 0
    sh = 0
    i = pos[0]
    while i < end:
        c = d[i]
        i += 1
        v |= (c & 0x7F) << sh
        if (c & 0x80) == 0:
            pos[0] = i
            return v, True
        sh += 7
        if sh > 63:
            break
    pos[0] = end
    return -1, False


def skip_varints(d, i, end, count):
    for _ in range(count):
        done = False
        while i < end:
            c = d[i]
            i += 1
            if (c & 0x80) == 0:
                done = True
                break
        if not done:
            return -1
    return i


def parse_chain(d, own_id=-1):
    """Return list of records or None. Mirrors observeChainPacket+parseStructured.
    Records carry RAW x/z/y (as Java stores) plus raw pose/vel/mode/state."""
    plen = len(d)
    if plen < 20 or plen > CHAIN_MAX_LEN:
        return None
    if d[8] != 0x00:
        return None
    b9 = d[9]
    if (b9 & 1) != 0:
        return None
    declared = b9 // 2
    if declared < 1 or declared > MAX_CHAIN_RECORDS:
        return None
    if plen < CHAIN_HEADER + declared * MIN_RECORD_BYTES:
        return None
    rec_start = skip_varints(d, 8, plen, 2)
    if rec_start < 0:
        return None
    pos = [rec_start]
    end = plen
    recs = []
    for _ in range(declared):
        idv, ok = vi(d, pos, end)
        if not ok or idv < 1 or idv > MAX_ENTITY_ID:
            return None
        x, ok = vi(d, pos, end)
        if not ok:
            return None
        z, ok = vi(d, pos, end)
        if not ok:
            return None
        y, ok = vi(d, pos, end)
        if not ok:
            return None
        if x < MIN_RECORD_X:
            return None
        if own_id > 0 and idv == own_id:
            # self-echo: 16 more varints, no byte block
            good = True
            for _k in range(4, 20):
                _v, ok = vi(d, pos, end)
                if not ok and pos[0] >= end:
                    good = False
                    break
            if not good:
                return None
            recs.append({"id": idv, "x": x, "z": z, "y": y, "self": True})
            continue
        vx, ok = vi(d, pos, end)
        if not ok:
            return None
        vz, ok = vi(d, pos, end)
        if not ok:
            return None
        vy, ok = vi(d, pos, end)
        if not ok:
            return None
        if pos[0] + 3 > end:
            return None
        by = d[pos[0]]
        ay = d[pos[0] + 1]
        ap = d[pos[0] + 2]
        if ap >= 128:
            ap -= 256  # signed byte
        pos[0] += 3
        md, ok = vi(d, pos, end)
        if not ok:
            return None
        st, ok = vi(d, pos, end)
        if not ok:
            return None
        _r1, ok = vi(d, pos, end)
        if not ok:
            return None
        _r2, ok = vi(d, pos, end)
        if not ok:
            return None
        if pos[0] > end:
            return None
        recs.append({"id": idv, "x": x, "z": z, "y": y, "vx": vx, "vz": vz,
                     "vy": vy, "by": by, "ay": ay, "ap": ap, "md": md, "st": st,
                     "self": False})
    left = end - pos[0]
    if left < 1 or left > 3:
        return None
    return recs


def load_csv():
    """seq -> list of (ent_id, x, z, y) decoded, ordered by rec_idx."""
    groups = {}
    with open(CSVF, newline="") as f:
        for row in csv.DictReader(f):
            seq = int(row["seq"])
            groups.setdefault(seq, []).append(
                (int(row["rec_idx"]), int(row["ent_id"]), int(row["x"]),
                 int(row["z"]), int(row["y"]), int(row["declared_recs"])))
    for seq in groups:
        groups[seq].sort()
    return groups


def iter_raw():
    """Yield (seq, dir, payload_bytes, truncated) from the raw capture."""
    with open(RAW, errors="replace") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) < 4:
                continue
            try:
                seq = int(parts[0])
            except ValueError:
                continue
            hexs = parts[-1]
            truncated = hexs.endswith("..")
            hexs = hexs.rstrip(".")
            if len(hexs) % 2 != 0 or len(hexs) == 0:
                continue
            try:
                payload = bytes.fromhex(hexs)
            except ValueError:
                continue
            direction = parts[3]
            yield seq, direction, payload, truncated


def main():
    csv_groups = load_csv()
    golden = []
    negatives = []
    matched = 0
    seen_chain_but_trunc = 0
    for seq, direction, payload, truncated in iter_raw():
        recs = None if truncated else parse_chain(payload)
        if recs is None:
            # collect a few real INbound non-chain packets as negatives
            if (not truncated and direction.upper().startswith("IN")
                    and len(payload) >= 20 and len(negatives) < 8
                    and parse_chain(payload) is None):
                negatives.append({"seq": seq, "packet_hex": payload.hex(),
                                  "note": "real inbound non-chain, must reject"})
            continue
        # It parsed as a chain. Cross-check against the device CSV by seq.
        if seq not in csv_groups:
            continue
        cg = csv_groups[seq]
        if len(cg) != len(recs):
            continue
        # The device CSV logs the RAW varint values (id, x, z, y); zz() is the
        # separate signed decode. Cross-validate raw == raw.
        ok = True
        for (ri, eid, cx, cz, cy, dre), r in zip(cg, recs):
            if r["id"] != eid or r["x"] != cx or r["z"] != cz or r["y"] != cy:
                ok = False
                break
        if not ok:
            continue
        golden.append({"seq": seq, "packet_hex": payload.hex(),
                       "declared": len(recs), "records": recs})
        matched += 1

    # de-dup identical packets; keep a bounded, deterministic spread across
    # every declared-count bucket (a fixture, not the whole capture).
    PER_BUCKET = 8
    seen = set()
    buckets = {}
    for g in sorted(golden, key=lambda g: (g["declared"], g["seq"])):
        k = g["packet_hex"]
        if k in seen:
            continue
        seen.add(k)
        b = buckets.setdefault(g["declared"], [])
        if len(b) < PER_BUCKET:
            b.append(g)
    uniq = [g for d in sorted(buckets) for g in buckets[d]]

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    out = {"source": "capture_raw_20260910_183716.txt x entities_20260910_183716.csv",
           "note": "real inbound Cmd-2012 chains, decoded coords cross-validated "
                   "against the device's own entities CSV by seq",
           "chains": uniq, "negatives": negatives}
    with open(OUT, "w") as f:
        json.dump(out, f, indent=1)
    n1 = sum(1 for g in uniq if g["declared"] == 1)
    n2 = sum(1 for g in uniq if g["declared"] == 2)
    print(f"matched {matched} chains vs CSV; {len(uniq)} unique "
          f"({n1} single-entity, {n2} two-entity), {len(negatives)} negatives")
    print(f"wrote {OUT}")


if __name__ == "__main__":
    main()
