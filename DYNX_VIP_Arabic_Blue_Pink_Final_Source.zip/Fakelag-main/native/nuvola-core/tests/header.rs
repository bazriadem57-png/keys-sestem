//! Header codec parity. Offsets are the ground truth from the Java `layOut`
//! logic (start at byte 2, ORDER_ID present on reliable only). The mask is
//! applied to every header byte from index 2 on.

use nuvola_core::header::{msgkey, Field, HeaderLayout, DEFAULT_ORDER};

#[test]
fn msgkey_ranges() {
    assert_eq!(msgkey::header_size(90), 10);
    assert_eq!(msgkey::header_size(99), 10);
    assert_eq!(msgkey::header_size(100), 8);
    assert_eq!(msgkey::header_size(110), 8);
    assert_eq!(msgkey::header_size(111), msgkey::NOT_MATCH_TRAFFIC);
    assert_eq!(msgkey::header_size(89), msgkey::NOT_MATCH_TRAFFIC);
    assert!(msgkey::is_reliable(90) && !msgkey::is_reliable(100));
}

#[test]
fn default_order_offsets() {
    let l = HeaderLayout::default_layout();
    // reliable (10-byte header): all five fields present, starting at byte 2.
    assert_eq!(l.offset_of(Field::SendOption, true), 2);
    assert_eq!(l.offset_of(Field::Cmd, true), 3);
    assert_eq!(l.offset_of(Field::OrderId, true), 5);
    assert_eq!(l.offset_of(Field::Flags, true), 7);
    assert_eq!(l.offset_of(Field::DataLen, true), 8);
    // non-reliable (8-byte header): ORDER_ID absent, later fields shift down.
    assert_eq!(l.offset_of(Field::SendOption, false), 2);
    assert_eq!(l.offset_of(Field::Cmd, false), 3);
    assert_eq!(l.offset_of(Field::OrderId, false), -1);
    assert_eq!(l.offset_of(Field::Flags, false), 5);
    assert_eq!(l.offset_of(Field::DataLen, false), 6);
}

#[test]
fn mask_read_write_roundtrip() {
    let l = HeaderLayout::new(0xAB, DEFAULT_ORDER).unwrap();
    let mut pkt = vec![0u8; l.header_size(true)];
    pkt[0] = 90; // msgkey (reliable)
    l.write_byte(&mut pkt, 0, Field::SendOption, true, 0x01);
    l.write_short(&mut pkt, 0, Field::Cmd, true, 2001);
    l.write_short(&mut pkt, 0, Field::OrderId, true, 0x1234);
    l.write_byte(&mut pkt, 0, Field::Flags, true, 0x05);
    l.write_short(&mut pkt, 0, Field::DataLen, true, 512);

    // Raw bytes must be masked (not equal to the plaintext values).
    assert_ne!(pkt[l.offset_of(Field::Cmd, true) as usize], (2001 & 0xFF) as u8);

    assert_eq!(l.read_byte(&pkt, 0, Field::SendOption, true), 0x01);
    assert_eq!(l.read_short(&pkt, 0, Field::Cmd, true), 2001);
    assert_eq!(l.read_short(&pkt, 0, Field::OrderId, true), 0x1234);
    assert_eq!(l.read_byte(&pkt, 0, Field::Flags, true), 0x05);
    assert_eq!(l.read_short(&pkt, 0, Field::DataLen, true), 512);
}

#[test]
fn permuted_order_is_accepted_and_absent_orderid_reads_minus_one() {
    // A non-default permutation: DATA_LEN, SEND_OPTION, CMD, FLAGS, ORDER_ID.
    let order = [
        Field::DataLen,
        Field::SendOption,
        Field::Cmd,
        Field::Flags,
        Field::OrderId,
    ];
    let l = HeaderLayout::new(0x5C, order).unwrap();
    // Non-reliable: ORDER_ID absent → -1, and header is 8 bytes.
    assert_eq!(l.offset_of(Field::OrderId, false), -1);
    assert_eq!(l.header_size(false), 8);
    // DATA_LEN is first here → offset 2 on both.
    assert_eq!(l.offset_of(Field::DataLen, true), 2);
}

#[test]
fn non_permutation_is_rejected() {
    // CMD twice, no DATA_LEN → not a permutation.
    let bad = [Field::Cmd, Field::Cmd, Field::SendOption, Field::OrderId, Field::Flags];
    assert!(HeaderLayout::new(0, bad).is_none());
}
