//! Cmd-148 map-pin rewrite: body transform + full packet round-trip through the
//! (real-capture-verified) TEA cipher.

use nuvola_core::crc7;
use nuvola_core::header::{Field, HeaderLayout, DEFAULT_ORDER};
use nuvola_core::mark;
use nuvola_core::tea;
use nuvola_core::varint::{write_varint, zigzag_decode, zigzag_encode};

fn key16() -> [u32; 4] {
    tea::schedule(&[0x0b, 0x30, 0x55, 0x7a, 0x9f, 0xc4, 0xe9, 0x0e,
                    0x33, 0x58, 0x7d, 0xa2, 0xc7, 0xec, 0x11, 0x36]).unwrap()
}

/// Build a decrypted 148 body: U author, B isDel, B type, Z x, Z up, Z z, B B B tail.
fn build_body(author: u64, is_del: u8, typ: u8, x: i64, up: i64, z: i64, tail: [u8; 3]) -> Vec<u8> {
    let mut b = Vec::new();
    let mut t = [0u8; 10];
    let n = write_varint(&mut t, author);
    b.extend_from_slice(&t[..n]);
    b.push(is_del);
    b.push(typ);
    for v in [x, up, z] {
        let n = write_varint(&mut t, zigzag_encode(v));
        b.extend_from_slice(&t[..n]);
    }
    b.extend_from_slice(&tail);
    b
}

/// Parse the 3 zigzag positions + type out of a decrypted 148 body.
fn parse_body(plain: &[u8]) -> (u8, i64, i64, i64) {
    // skip U author
    let mut i = 0;
    while plain[i] & 0x80 != 0 { i += 1; }
    i += 1;
    let _is_del = plain[i];
    let typ = plain[i + 1];
    i += 2;
    let mut vals = [0i64; 3];
    for v in vals.iter_mut() {
        let mut raw = 0u64;
        let mut shift = 0;
        loop {
            let c = plain[i] as u64;
            i += 1;
            raw |= (c & 0x7f) << shift;
            if c & 0x80 == 0 { break; }
            shift += 7;
        }
        *v = zigzag_decode(raw);
    }
    (typ, vals[0], vals[1], vals[2])
}

#[test]
fn body_rewrite_moves_position_and_forces_type() {
    let body = build_body(0x0102, 0, 5, 111, 222, 333, [3, 1, 0]);
    let mut out = [0u8; 128];
    let n = mark::rewrite_body(&body, body.len(), &mut out, -5000, 12345, 6789, true).unwrap();
    let (typ, x, up, z) = parse_body(&out[..n]);
    assert_eq!(typ, mark::TYPE_NOTICE_ENEMY);
    assert_eq!((x, up, z), (-5000, 12345, 6789));
    // tail (last 3 raw bytes) preserved
    assert_eq!(&out[n - 3..n], &[3, 1, 0]);
}

#[test]
fn body_rewrite_refuses_delete() {
    let body = build_body(0x1, 1 /* isDel */, 1, 1, 2, 3, [0, 0, 0]);
    let mut out = [0u8; 128];
    assert!(mark::rewrite_body(&body, body.len(), &mut out, 9, 9, 9, true).is_none());
}

/// Build a full reliable Cmd-148 packet (default layout, mask 0) with the body
/// TEA-encrypted, so rewrite_packet can be exercised end to end.
fn build_packet(k: &[u32; 4], body: &[u8]) -> Vec<u8> {
    let enc_len = tea::qq_tea_encrypt_len(body.len());
    let mut cipher = vec![0u8; enc_len];
    tea::qq_tea_encrypt(body, k, &mut cipher).unwrap();
    // 10-byte reliable header, default order, mask 0:
    // [0]=msgkey [1]=crc [2]=send_option [3..5]=cmd [5..7]=orderid [7]=flags [8..10]=datalen
    let mut pkt = vec![0u8; 10];
    pkt[0] = 90; // reliable msgkey
    pkt[3] = (148 & 0xFF) as u8;
    pkt[4] = 0;
    pkt[7] = 1; // flags (encrypted)
    pkt[8] = (enc_len & 0xFF) as u8;
    pkt[9] = ((enc_len >> 8) & 0xFF) as u8;
    pkt.extend_from_slice(&cipher);
    crc7::seal(&mut pkt);
    pkt
}

#[test]
fn packet_rewrite_roundtrips_through_tea() {
    let k = key16();
    let body = build_body(0x2233, 0, 2, 1000, -2000, 3000, [1, 1, 0]);
    let orig = build_packet(&k, &body);
    let mut buf = vec![0u8; orig.len() + 32]; // headroom for growth
    buf[..orig.len()].copy_from_slice(&orig);

    let layout = HeaderLayout::new(0, DEFAULT_ORDER).unwrap();
    let (nx, nup, ny) = (-123_456i64, 654_321i64, 42i64);
    let n = mark::rewrite_packet(&mut buf, 0, orig.len(), &k, &layout, nx, nup, ny, true, u64::MAX, 0);
    assert!(n > 0, "rewrite_packet failed");
    let new_total = n as usize;

    // CRC valid and DATA_LEN consistent.
    assert!(crc7::verify(&buf[..new_total]));
    let dl = layout.read_short(&buf, 0, Field::DataLen, true) as usize;
    assert_eq!(dl, new_total - 10);

    // Decrypt the rewritten body and confirm the new pin.
    let mut plain = [0u8; 512];
    let pl = tea::qq_tea_decrypt(&buf[10..10 + dl], &k, &mut plain).expect("decrypt");
    let (typ, x, up, z) = parse_body(&plain[..pl]);
    assert_eq!(typ, mark::TYPE_NOTICE_ENEMY);
    assert_eq!((x, up, z), (nx, nup, ny));
}

#[test]
fn packet_rewrite_refuses_stale_layout() {
    let k = key16();
    let body = build_body(0x1, 0, 1, 1, 2, 3, [0, 0, 0]);
    let orig = build_packet(&k, &body);
    let mut buf = vec![0u8; orig.len() + 32];
    buf[..orig.len()].copy_from_slice(&orig);
    // A non-zero mask makes read_short(DATA_LEN) disagree with the payload → refuse.
    let stale = HeaderLayout::new(0x5A, DEFAULT_ORDER).unwrap();
    assert_eq!(mark::rewrite_packet(&mut buf, 0, orig.len(), &k, &stale, 9, 9, 9, true, u64::MAX, 0), -1);
}

#[test]
fn leash_no_mark_without_live_entitlement() {
    // Without a live server profile the rewrite is a no-op and the packet is
    // left byte-for-byte intact.
    let k = key16();
    let body = build_body(0x2233, 0, 2, 1000, -2000, 3000, [1, 1, 0]);
    let orig = build_packet(&k, &body);
    let mut buf = vec![0u8; orig.len() + 32];
    buf[..orig.len()].copy_from_slice(&orig);
    let snap = buf.clone();
    let layout = HeaderLayout::new(0, DEFAULT_ORDER).unwrap();
    // Unarmed (valid_until 0) and expired (now >= valid_until) both refuse.
    assert_eq!(mark::rewrite_packet(&mut buf, 0, orig.len(), &k, &layout, 1, 2, 3, true, 0, 100), -1);
    assert_eq!(mark::rewrite_packet(&mut buf, 0, orig.len(), &k, &layout, 1, 2, 3, true, 100, 100), -1);
    assert_eq!(buf, snap, "no-op leash must leave the packet untouched");
    // Live: goes through.
    assert!(mark::rewrite_packet(&mut buf, 0, orig.len(), &k, &layout, 1, 2, 3, true, 101, 100) > 0);
}
