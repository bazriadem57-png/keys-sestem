//! Cmd 2012 entity-stream decoder. The golden is REAL inbound chain packets
//! from `capture_raw_20260910_155351.txt`, whose decoded ids + raw coordinates
//! were cross-validated against the device's OWN `entities_20260910_155352.csv`
//! decode (same session, matched by seq) over 1139 packets before extraction —
//! so this proves: real wire bytes -> Rust decoder -> the exact ids/coords the
//! device computed independently. Plus the self-echo path and every rejection
//! path synthetically.

use nuvola_core::chain::{self, Chain, ChainProfile, ChainRecord, RECORD_CAP, RECORD_WIRE};
use nuvola_core::varint::zigzag_encode;
use serde::Deserialize;
use std::path::PathBuf;

/// A fixed "now" and a profile carrying the real game decode params with a
/// far-future validity. In production this profile arrives ONLY inside the
/// server's sealed /config envelope; here (test scaffolding) we supply it
/// directly. The literal params live in test code, never in the shipped lib.
const NOW: u64 = 1_700_000_000;
fn armed() -> ChainProfile {
    ChainProfile {
        chain_max_len: 1400,
        max_records: 64,
        min_record_bytes: 16,
        min_record_x: 500,
        max_entity_id: 64,
        valid_until: 4_000_000_000,
    }
}
/// Test helper: decode with the armed profile at NOW.
fn parse(pkt: &[u8], own_id: i32) -> Option<Chain> {
    chain::parse_with_profile(pkt, 0, pkt.len(), own_id, &armed(), NOW)
}

fn unhex(s: &str) -> Vec<u8> {
    (0..s.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap())
        .collect()
}

#[derive(Deserialize)]
struct GoldenRec {
    id: u32,
    x: u64,
    z: u64,
    y: u64,
    vx: Option<u64>,
    vz: Option<u64>,
    vy: Option<u64>,
    by: Option<u8>,
    ay: Option<u8>,
    ap: Option<i64>,
    md: Option<u32>,
    st: Option<u32>,
    #[serde(rename = "self")]
    self_echo: bool,
}

#[derive(Deserialize)]
struct GoldenChain {
    seq: u64,
    packet_hex: String,
    declared: usize,
    records: Vec<GoldenRec>,
}

#[derive(Deserialize)]
struct GoldenNeg {
    #[allow(dead_code)]
    seq: u64,
    packet_hex: String,
}

#[derive(Deserialize)]
struct Golden {
    chains: Vec<GoldenChain>,
    negatives: Vec<GoldenNeg>,
}

fn load_golden() -> Option<Golden> {
    let p = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/data/chain2012_golden.json");
    let data = std::fs::read_to_string(&p).ok()?;
    Some(serde_json::from_str(&data).unwrap())
}

#[test]
fn real_chains_match_device_decode() {
    let g = match load_golden() {
        Some(g) => g,
        None => {
            eprintln!("SKIP: chain2012 golden not present");
            return;
        }
    };
    assert!(!g.chains.is_empty());
    let mut recs_checked = 0usize;
    for gc in &g.chains {
        let pkt = unhex(&gc.packet_hex);
        let c = parse(&pkt, -1)
            .unwrap_or_else(|| panic!("seq {} must parse as a chain", gc.seq));
        assert_eq!(c.len(), gc.declared, "seq {} record count", gc.seq);
        assert_eq!(c.len(), gc.records.len());
        for (r, e) in c.records().iter().zip(&gc.records) {
            // Cross-validated against the device CSV: id + RAW coords.
            assert_eq!(r.id, e.id, "seq {} id", gc.seq);
            assert_eq!(r.x, e.x, "seq {} x", gc.seq);
            assert_eq!(r.z, e.z, "seq {} z", gc.seq);
            assert_eq!(r.y, e.y, "seq {} y", gc.seq);
            assert!(!r.is_self_echo && !e.self_echo);
            // Pose/velocity: the same raw bytes the Python reference read.
            assert_eq!(r.vx, e.vx.unwrap());
            assert_eq!(r.vz, e.vz.unwrap());
            assert_eq!(r.vy, e.vy.unwrap());
            assert_eq!(r.body_yaw_raw, e.by.unwrap());
            assert_eq!(r.aim_yaw_raw, e.ay.unwrap());
            assert_eq!(r.aim_pitch_raw as i64, e.ap.unwrap());
            assert_eq!(r.mode, e.md.unwrap());
            assert_eq!(r.state, e.st.unwrap());
            recs_checked += 1;
        }
    }
    eprintln!(
        "chain2012: {} real chains, {} records match the device decode",
        g.chains.len(),
        recs_checked
    );

    // Every negative (real inbound non-chain packet) must be refused.
    for n in &g.negatives {
        let pkt = unhex(&n.packet_hex);
        assert!(
            parse(&pkt, -1).is_none(),
            "negative packet must be rejected"
        );
    }
}

/// Encode a synthetic chain to the exact grammar, for the self-echo + boundary
/// paths the real golden doesn't cover (own player rarely in an enemy chain).
struct ChainBuilder {
    body: Vec<u8>,
    declared: usize,
}
impl ChainBuilder {
    fn new() -> Self {
        ChainBuilder { body: Vec::new(), declared: 0 }
    }
    fn u(v: &mut Vec<u8>, mut x: u64) {
        loop {
            let mut b = (x & 0x7f) as u8;
            x >>= 7;
            if x != 0 {
                b |= 0x80;
            }
            v.push(b);
            if x == 0 {
                break;
            }
        }
    }
    fn remote(mut self, id: u64, pos: [i64; 3], vel: [i64; 3], pose: (u8, u8, i8), ms: (u64, u64)) -> Self {
        Self::u(&mut self.body, id);
        for p in pos {
            Self::u(&mut self.body, zigzag_encode(p));
        }
        for v in vel {
            Self::u(&mut self.body, zigzag_encode(v));
        }
        self.body.push(pose.0);
        self.body.push(pose.1);
        self.body.push(pose.2 as u8);
        Self::u(&mut self.body, ms.0);
        Self::u(&mut self.body, ms.1);
        Self::u(&mut self.body, 0); // reserved
        Self::u(&mut self.body, 0); // reserved
        self.declared += 1;
        self
    }
    fn self_echo(mut self, id: u64, pos: [i64; 3]) -> Self {
        Self::u(&mut self.body, id);
        for p in pos {
            Self::u(&mut self.body, zigzag_encode(p));
        }
        for _ in 4..20 {
            Self::u(&mut self.body, 0);
        }
        self.declared += 1;
        self
    }
    /// Assemble the full datagram: 8 header bytes, b8=0, b9=declared*2, the two
    /// leading varints (they ARE b8/b9 in the common single-byte case), records,
    /// and a trailing tick byte.
    fn build(self) -> Vec<u8> {
        let mut pkt = vec![0u8; 10];
        pkt[8] = 0x00;
        pkt[9] = (self.declared * 2) as u8;
        pkt.extend_from_slice(&self.body);
        pkt.push(0x2A); // trailing tick (1 byte in [1..=3])
        pkt
    }
}

#[test]
fn self_echo_is_20_varints_no_pose() {
    let own = 3u64;
    let pkt = ChainBuilder::new()
        .self_echo(own, [1000, 2000, 3000])
        .remote(7, [900000, 55000, 850000], [100, 0, -50], (172, 92, 1), (0, 0))
        .build();
    // own_id known: record 0 takes the self-echo shape.
    let c = parse(&pkt, own as i32).expect("self-echo chain");
    assert_eq!(c.len(), 2);
    assert!(c.records()[0].is_self_echo);
    assert_eq!(c.records()[0].id, 3);
    assert!(!c.records()[1].is_self_echo);
    assert_eq!(c.records()[1].id, 7);

    // Without knowing own_id, the SAME bytes must NOT parse: record 0 would take
    // the remote shape (7 varints + 3 bytes + ...) and desync -> reject.
    assert!(parse(&pkt, -1).is_none());
}

#[test]
fn signed_pitch_roundtrips() {
    let pkt = ChainBuilder::new()
        .remote(5, [600, 700, 800], [0, 0, 0], (0, 0, -100), (0, 0))
        .build();
    let c = parse(&pkt, -1).unwrap();
    assert_eq!(c.records()[0].aim_pitch_raw, -100);
}

#[test]
fn rejects_bad_headers() {
    let good = ChainBuilder::new()
        .remote(5, [600, 700, 800], [1, 2, 3], (10, 20, 5), (0, 0))
        .build();
    assert!(parse(&good, -1).is_some());

    // b8 != 0
    let mut b8 = good.clone();
    b8[8] = 1;
    assert!(parse(&b8, -1).is_none());

    // b9 odd
    let mut odd = good.clone();
    odd[9] = 3;
    assert!(parse(&odd, -1).is_none());

    // too short
    assert!(chain::parse_with_profile(&good, 0, 19, -1, &armed(), NOW).is_none());

    // id out of range: force b9 to declare 1 record but corrupt the id to 0.
    let mut badid = good.clone();
    badid[10] = 0x00; // id varint = 0 (< 1)
    assert!(parse(&badid, -1).is_none());
}

#[test]
fn rejects_trailing_residue_outside_1_3() {
    let mut pkt = ChainBuilder::new()
        .remote(5, [600, 700, 800], [1, 2, 3], (10, 20, 5), (0, 0))
        .build();
    // append 3 more bytes -> 4 trailing (tick was 1) -> outside [1,3]
    pkt.extend_from_slice(&[0, 0, 0]);
    assert!(parse(&pkt, -1).is_none());
}

#[test]
fn rejects_x_below_floor() {
    // raw x < MIN_RECORD_X(500). zigzag_encode(200)=400 (<500) as the RAW varint.
    let pkt = ChainBuilder::new()
        .remote(5, [200, 700, 800], [0, 0, 0], (0, 0, 0), (0, 0))
        .build();
    assert!(parse(&pkt, -1).is_none());
}

#[test]
fn oversized_offset_does_not_panic() {
    // F4: hostile off/len must be rejected, never wrap into a slice panic.
    let pkt = vec![0u8; 40];
    assert!(chain::parse_with_profile(&pkt, usize::MAX, 40, -1, &armed(), NOW).is_none());
    assert!(chain::parse_with_profile(&pkt, 8, usize::MAX, -1, &armed(), NOW).is_none());
    assert!(chain::parse_with_profile(&pkt, 30, 40, -1, &armed(), NOW).is_none());
}

#[test]
fn no_profile_or_expired_decodes_nothing() {
    // THE LEASH. A valid chain that parses with the armed profile must yield
    // NOTHING with a default (absent) profile or an expired one — so a client
    // with no live licensed session decodes no entities.
    let pkt = ChainBuilder::new()
        .remote(7, [900000, 55000, 850000], [100, 0, -50], (172, 92, 1), (0, 0))
        .build();
    assert!(parse(&pkt, -1).is_some(), "armed profile must decode it");
    // Absent profile (Default: valid_until == 0).
    assert!(chain::parse_with_profile(&pkt, 0, pkt.len(), -1, &ChainProfile::default(), NOW).is_none());
    // Expired profile (now >= valid_until).
    let expired = ChainProfile { valid_until: NOW, ..armed() };
    assert!(chain::parse_with_profile(&pkt, 0, pkt.len(), -1, &expired, NOW).is_none());
    // One second before expiry still works.
    let live = ChainProfile { valid_until: NOW + 1, ..armed() };
    assert!(chain::parse_with_profile(&pkt, 0, pkt.len(), -1, &live, NOW).is_some());
}

#[test]
fn serialize_roundtrip_matches_decoded_records() {
    // Serialize a decoded chain for the JNI handoff and read it back exactly —
    // the fixed-layout ByteBuffer format Java will parse. Uses a real golden
    // packet when present, else a synthetic multi-record chain.
    fn le_u32(b: &[u8]) -> u32 {
        u32::from_le_bytes(b[0..4].try_into().unwrap())
    }
    fn le_u64(b: &[u8]) -> u64 {
        u64::from_le_bytes(b[0..8].try_into().unwrap())
    }

    let pkt = match load_golden().and_then(|g| g.chains.into_iter().find(|c| c.declared >= 2)) {
        Some(gc) => unhex(&gc.packet_hex),
        None => ChainBuilder::new()
            .remote(7, [900000, 55000, 850000], [100, 0, -50], (172, 92, 1), (4, 9))
            .remote(3, [700000, 55000, 640000], [0, 10, -3], (5, 250, -7), (1, 2))
            .build(),
    };
    let c = parse(&pkt, -1).expect("chain parses");
    let mut out = vec![0u8; 2 + c.len() * RECORD_WIRE];
    let n = c.serialize(&mut out).expect("serialize");
    assert_eq!(n, 2 + c.len() * RECORD_WIRE);

    let count = (out[0] as usize) | ((out[1] as usize) << 8);
    assert_eq!(count, c.len());
    for (i, r) in c.records().iter().enumerate() {
        let rec = &out[2 + i * RECORD_WIRE..2 + (i + 1) * RECORD_WIRE];
        assert_eq!(le_u32(&rec[0..]), r.id);
        assert_eq!(le_u64(&rec[4..]), r.x);
        assert_eq!(le_u64(&rec[12..]), r.z);
        assert_eq!(le_u64(&rec[20..]), r.y);
        assert_eq!(le_u64(&rec[28..]), r.vx);
        assert_eq!(le_u64(&rec[36..]), r.vz);
        assert_eq!(le_u64(&rec[44..]), r.vy);
        assert_eq!(rec[52], r.body_yaw_raw);
        assert_eq!(rec[53], r.aim_yaw_raw);
        assert_eq!(rec[54] as i8, r.aim_pitch_raw);
        assert_eq!(rec[55] & 1 == 1, r.is_self_echo);
        assert_eq!(le_u32(&rec[56..]), r.mode);
        assert_eq!(le_u32(&rec[60..]), r.state);
    }

    // Too-small buffer fails cleanly (no panic).
    let mut tiny = [0u8; 1];
    assert!(c.serialize(&mut tiny).is_none());
}

#[test]
fn record_array_bound_is_64() {
    assert_eq!(RECORD_CAP, 64);
    let _ = ChainRecord::default();
}
