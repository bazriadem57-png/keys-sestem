//! Session-key schedule cache + body decrypt. The underlying TEA is already
//! cross-checked byte-identical to the Python oracle (parity.rs / cross_oracle);
//! these tests pin the BodyCrypt wrapper: hex parsing, cache hit/rotate, the
//! length/block gate, the wrong-key rejection (seven-zero tail), and an
//! encrypt->decrypt round-trip through a hex-installed key.

use nuvola_core::bodycrypt::{BodyCrypt, MAX_BODY};
use nuvola_core::tea;

const KEY_HEX: &str = "0b30557a9fc4e90e33587da2c7ec1136";
const NOW: u64 = 1_700_000_000;
const FUTURE: u64 = 4_000_000_000; // server profile validity, well past NOW

fn key_bytes() -> [u8; 16] {
    let b = KEY_HEX.as_bytes();
    let mut k = [0u8; 16];
    for i in 0..16 {
        k[i] = u8::from_str_radix(std::str::from_utf8(&b[i * 2..i * 2 + 2]).unwrap(), 16).unwrap();
    }
    k
}

#[test]
fn install_and_decrypt_roundtrip() {
    // Encrypt a body with the raw TEA using the same key, then decrypt it back
    // through a hex-installed BodyCrypt.
    let sched = tea::schedule(&key_bytes()).unwrap();
    let plain = b"cmd 1900 body: HP=200 ARMOUR=100";
    let mut ct = [0u8; 128];
    let n = tea::qq_tea_encrypt(plain, &sched, &mut ct).unwrap();

    let mut bc = BodyCrypt::new();
    assert!(bc.set_key_hex(KEY_HEX));
    assert!(bc.has_key());
    bc.arm(FUTURE);

    let mut out = [0u8; 128];
    let m = bc.decrypt_into(&ct[..n], &mut out, NOW).expect("decrypt");
    assert_eq!(&out[..m], &plain[..]);
}

#[test]
fn leash_fail_closed_without_live_entitlement() {
    // THE RELIABLE-CHANNEL LEASH. A correct key + a real ciphertext still
    // decrypts NOTHING unless armed with a live server entitlement.
    let sched = tea::schedule(&key_bytes()).unwrap();
    let plain = b"cmd 1900 body";
    let mut ct = [0u8; 64];
    let n = tea::qq_tea_encrypt(plain, &sched, &mut ct).unwrap();
    let mut bc = BodyCrypt::new();
    bc.set_key_hex(KEY_HEX);
    let mut out = [0u8; 64];
    // Not armed (default): refuse.
    assert!(bc.decrypt_into(&ct[..n], &mut out, NOW).is_none());
    // Expired: refuse.
    bc.arm(NOW);
    assert!(bc.decrypt_into(&ct[..n], &mut out, NOW).is_none());
    // Live: works.
    bc.arm(NOW + 1);
    assert!(bc.decrypt_into(&ct[..n], &mut out, NOW).is_some());
}

#[test]
fn cache_reuse_and_rotation() {
    let mut bc = BodyCrypt::new();
    assert!(bc.set_key_hex(KEY_HEX));
    let s1 = *bc.schedule().unwrap();
    // Same hex again: still valid, same schedule.
    assert!(bc.set_key_hex(KEY_HEX));
    assert_eq!(*bc.schedule().unwrap(), s1);
    // A different key rotates the schedule.
    let other = "ffeeddccbbaa99887766554433221100";
    assert!(bc.set_key_hex(other));
    assert_ne!(*bc.schedule().unwrap(), s1);
}

#[test]
fn invalid_hex_clears_key() {
    let mut bc = BodyCrypt::new();
    assert!(bc.set_key_hex(KEY_HEX));
    assert!(!bc.set_key_hex("nothex_nothex_nothex_nothex_zzzz"), "non-hex must fail");
    assert!(!bc.has_key(), "an invalid key must clear the cache, not keep the old one");
    assert!(!bc.set_key_hex("abcd"), "wrong length must fail");
}

#[test]
fn no_key_means_no_decrypt() {
    let mut bc = BodyCrypt::new();
    bc.arm(FUTURE); // armed, but still no key -> no decrypt
    let mut out = [0u8; 64];
    assert!(bc.decrypt_into(&[0u8; 16], &mut out, NOW).is_none());
}

#[test]
fn length_gate() {
    let mut bc = BodyCrypt::new();
    bc.set_key_hex(KEY_HEX);
    bc.arm(FUTURE);
    let mut out = [0u8; MAX_BODY + 16];
    // Too short (< MIN_CIPHERTEXT).
    assert!(bc.decrypt_into(&[0u8; 8], &mut out, NOW).is_none());
    // Not a whole number of blocks.
    assert!(bc.decrypt_into(&[0u8; 20], &mut out, NOW).is_none());
    // Over MAX_BODY.
    let big = vec![0u8; MAX_BODY + 8];
    assert!(bc.decrypt_into(&big, &mut out, NOW).is_none());
}

#[test]
fn wrong_key_is_rejected_by_tail_check() {
    let sched = tea::schedule(&key_bytes()).unwrap();
    let plain = b"eight...."; // any body
    let mut ct = [0u8; 64];
    let n = tea::qq_tea_encrypt(plain, &sched, &mut ct).unwrap();

    let mut bc = BodyCrypt::new();
    bc.set_key_hex("ffeeddccbbaa99887766554433221100"); // wrong key
    bc.arm(FUTURE);
    let mut out = [0u8; 64];
    assert!(
        bc.decrypt_into(&ct[..n], &mut out, NOW).is_none(),
        "a wrong key must fail the seven-zero tail check, not return garbage"
    );
}
