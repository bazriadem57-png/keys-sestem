//! Synthetic round-trip tests for the Cmd-2001 codec. Real-capture golden
//! vectors are checked separately (possync_golden.rs) once extracted.

use nuvola_core::crc7;
use nuvola_core::header::{Field, HeaderLayout, DEFAULT_ORDER};
use nuvola_core::possync::{self, PosSync};
use nuvola_core::varint::{varint_width, write_varint, zigzag_encode};

// Server-gated leash: the position rewrite no-ops unless armed with a live
// profile. Tests arm with a far-future validity and mutate at NOW.
const NOW: u64 = 1_700_000_000;
const FUTURE: u64 = 4_000_000_000;

/// Build a well-formed non-reliable Cmd-2001 packet (default layout, mask 0)
/// with a given handle and the 23 signed body values, canonically encoded.
fn build_2001(handle: u64, vals: &[i64; possync::BODY_VARINTS]) -> Vec<u8> {
    let mut body = Vec::new();
    // object handle
    let mut hb = [0u8; 10];
    let hn = write_varint(&mut hb, handle);
    body.extend_from_slice(&hb[..hn]);
    // 23 canonical varints (zigzag)
    for &v in vals.iter() {
        let mut b = [0u8; 10];
        let n = write_varint(&mut b, zigzag_encode(v));
        body.extend_from_slice(&b[..n]);
    }
    let payload_len = body.len();

    // 8-byte non-reliable header, default order, mask 0:
    // [0]=msgkey [1]=crc [2]=send_option [3..5]=cmd LE [5]=flags [6..8]=datalen LE
    let mut pkt = vec![0u8; 8];
    pkt[0] = 100; // non-reliable msgkey
    pkt[2] = 0; // send_option
    pkt[3] = (2001 & 0xFF) as u8;
    pkt[4] = ((2001 >> 8) & 0xFF) as u8;
    pkt[5] = 0; // flags
    pkt[6] = (payload_len & 0xFF) as u8;
    pkt[7] = ((payload_len >> 8) & 0xFF) as u8;
    pkt.extend_from_slice(&body);
    crc7::seal(&mut pkt);
    pkt
}

fn sample_vals() -> [i64; possync::BODY_VARINTS] {
    let mut v = [0i64; possync::BODY_VARINTS];
    v[possync::V_POS_X] = 123_456; // ~123 m in mm
    v[possync::V_POS_Z] = -77_000;
    v[possync::V_POS_Y] = 1_500;
    v[possync::V_MOVE_DIR_X] = 100;
    v[possync::V_MOVE_DIR_Z] = -96;
    v[possync::V_VEL_X] = 40;
    v[possync::V_VEL_Z] = -12;
    v[possync::V_VEL_Y] = 3;
    v[possync::V_PHYS_STATE] = 0;
    v[possync::V_POSE] = 1;
    v[possync::V_PLATFORM_ID] = 0;
    v[22] = 987_654; // wall-clock counter
    v
}

#[test]
fn parse_recovers_values_and_consumes_exactly() {
    let vals = sample_vals();
    let pkt = build_2001(0x42, &vals);
    let mut ps = PosSync::new();
    assert!(ps.parse(&pkt, 0, pkt.len()), "must parse");
    for (i, &want) in vals.iter().enumerate() {
        assert_eq!(ps.signed_at(i), want, "value {i}");
    }
    assert!(crc7::verify(&pkt));
}

#[test]
fn rejects_wrong_msgkey_and_short() {
    let vals = sample_vals();
    let mut pkt = build_2001(0x1, &vals);
    let mut ps = PosSync::new();
    // reliable msgkey (90) => 10-byte header expected => reject as not a 2001 report
    pkt[0] = 90;
    assert!(!ps.parse(&pkt, 0, pkt.len()));
    assert!(!ps.parse(&pkt, 0, 5)); // too short
}

#[test]
fn rebuild_identity_reproduces_the_wire_bytes() {
    // The game emits every field minimum-width, so a rebuild with UNCHANGED
    // values must byte-for-byte reproduce the original packet.
    let vals = sample_vals();
    let orig = build_2001(0x7, &vals);
    let mut buf = orig.clone();
    let mut ps = PosSync::new();
    assert!(ps.parse(&buf, 0, buf.len()));
    ps.arm(FUTURE);
    let layout = HeaderLayout::new(0, DEFAULT_ORDER).unwrap();
    let n = ps.rebuild(&mut buf, &layout, NOW);
    assert_eq!(n as usize, orig.len(), "identity rebuild length");
    assert_eq!(buf[..n as usize], orig[..], "identity rebuild bytes");
}

#[test]
fn set_signed_in_place_within_width() {
    let vals = sample_vals();
    let mut buf = build_2001(0x9, &vals);
    let mut ps = PosSync::new();
    assert!(ps.parse(&buf, 0, buf.len()));
    // POS_X is 123456 -> zigzag 246912 -> 3 bytes. A value that still fits 3B:
    let w = varint_width(zigzag_encode(vals[possync::V_POS_X]));
    let newv = 200_000i64;
    assert!(varint_width(zigzag_encode(newv)) as usize <= w);
    assert!(ps.fits_signed(possync::V_POS_X, newv));
    ps.arm(FUTURE);
    assert!(ps.set_signed(&mut buf, possync::V_POS_X, newv, NOW));
    assert!(ps.seal(&mut buf));
    // Re-parse and confirm.
    let mut ps2 = PosSync::new();
    assert!(ps2.parse(&buf, 0, ps.length()));
    assert_eq!(ps2.signed_at(possync::V_POS_X), newv);
    assert!(crc7::verify(&buf[..ps.length()]));
}

#[test]
fn rebuild_grows_packet_for_oversized_value() {
    // A velocity that outgrows its 1-byte field forces a canonical rebuild that
    // grows the packet; the result must re-parse to the new value with valid CRC.
    let vals = sample_vals();
    let orig = build_2001(0x3, &vals);
    // give the buffer headroom for growth
    let mut buf = vec![0u8; orig.len() + 16];
    buf[..orig.len()].copy_from_slice(&orig);
    let mut ps = PosSync::new();
    assert!(ps.parse(&buf, 0, orig.len()));

    let big = 500_000i64; // needs 3 bytes, VEL_X was 1 byte
    assert!(!ps.fits_signed(possync::V_VEL_X, big));
    ps.stage_signed(possync::V_VEL_X, big);
    ps.arm(FUTURE);
    let layout = HeaderLayout::new(0, DEFAULT_ORDER).unwrap();
    let n = ps.rebuild(&mut buf, &layout, NOW);
    assert!(n > orig.len() as i32, "packet must grow (got {n}, was {})", orig.len());

    let mut ps2 = PosSync::new();
    assert!(ps2.parse(&buf, 0, n as usize), "re-parse grown packet");
    assert_eq!(ps2.signed_at(possync::V_VEL_X), big);
    // Every other field unchanged.
    assert_eq!(ps2.signed_at(possync::V_POS_X), vals[possync::V_POS_X]);
    assert!(crc7::verify(&buf[..n as usize]));
    // DATA_LEN was repaired to the new payload.
    assert_eq!(layout.read_short(&buf, 0, Field::DataLen, false), (n as usize - 8) as i32);
}

#[test]
fn leash_no_teleport_without_live_entitlement() {
    // THE OUTBOUND LEASH. Without a live server profile, set_signed and rebuild
    // are no-ops and leave the original packet byte-for-byte intact — a client
    // with no licensed session cannot teleport.
    let vals = sample_vals();
    let orig = build_2001(0x11, &vals);
    let mut buf = orig.clone();
    let layout = HeaderLayout::new(0, DEFAULT_ORDER).unwrap();
    let mut ps = PosSync::new();
    assert!(ps.parse(&buf, 0, buf.len()));

    // Unarmed (default): both mutators refuse and the bytes are untouched.
    assert!(!ps.set_signed(&mut buf, possync::V_POS_X, 200_000, NOW));
    assert_eq!(ps.rebuild(&mut buf, &layout, NOW), -1);
    assert_eq!(buf, orig, "unarmed: packet must be untouched");

    // Expired: still refuses.
    ps.arm(NOW);
    assert!(!ps.set_signed(&mut buf, possync::V_POS_X, 200_000, NOW));
    assert_eq!(ps.rebuild(&mut buf, &layout, NOW), -1);
    assert_eq!(buf, orig, "expired: packet must be untouched");

    // Live: the rewrite goes through.
    ps.arm(NOW + 1);
    assert!(ps.set_signed(&mut buf, possync::V_POS_X, 200_000, NOW));
}
