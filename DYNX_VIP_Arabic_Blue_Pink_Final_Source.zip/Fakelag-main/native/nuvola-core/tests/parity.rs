//! Parity + correctness gate for the ported primitives.
//!
//! - CRC-7 is anchored to the published CRC-7/MMC check value (0x75 for
//!   "123456789"), which is exactly the algorithm the Java `Crc7` documents.
//! - TEA is exercised by round-trip + a wrong-key rejection (the seven-zero tail
//!   oracle) across block-boundary lengths.
//! - Varints round-trip through the reader and both writers.
//!
//! A separate cross-implementation vector (emitted by the repo's Python oracle,
//! which was validated against the Java on live captures) is checked in
//! `cross_oracle.rs`.

use nuvola_core::{crc7, tea, varint};

#[test]
fn crc7_mmc_standard_check_value() {
    // CRC-7/MMC(check) = 0x75 over the ASCII "123456789".
    assert_eq!(crc7::compute(b"123456789", 0), 0x75);
}

#[test]
fn crc7_seal_then_verify() {
    let mut pkt = vec![90u8, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9]; // byte0=MsgKey, byte1=checksum
    let c = crc7::seal(&mut pkt);
    assert_eq!(pkt[1] as u32, c);
    assert!(crc7::verify(&pkt));
    // Any change past offset 2 must break verification until re-sealed.
    pkt[5] ^= 0xFF;
    assert!(!crc7::verify(&pkt));
}

fn key16(seed: u8) -> [u8; 16] {
    let mut k = [0u8; 16];
    for (i, b) in k.iter_mut().enumerate() {
        *b = seed.wrapping_add(i as u8).wrapping_mul(37).wrapping_add(11);
    }
    k
}

#[test]
fn tea_roundtrip_all_lengths() {
    let k = tea::schedule(&key16(3)).unwrap();
    for plen in [0usize, 1, 5, 6, 7, 8, 9, 15, 16, 31, 100, 255] {
        let plain: Vec<u8> = (0..plen).map(|i| (i as u8).wrapping_mul(97).wrapping_add(5)).collect();
        let enc_len = tea::qq_tea_encrypt_len(plen);
        assert_eq!(enc_len % 8, 0, "ciphertext must be block-aligned");
        assert!(enc_len >= tea::MIN_CIPHERTEXT);

        let mut ct = vec![0u8; enc_len];
        let n = tea::qq_tea_encrypt(&plain, &k, &mut ct).expect("encrypt");
        assert_eq!(n, enc_len);

        let mut out = vec![0u8; enc_len];
        let m = tea::qq_tea_decrypt(&ct, &k, &mut out).expect("decrypt");
        assert_eq!(m, plen, "recovered length (plen={plen})");
        assert_eq!(&out[..plen], &plain[..], "recovered bytes (plen={plen})");
    }
}

#[test]
fn tea_wrong_key_is_rejected_by_tail_oracle() {
    let k = tea::schedule(&key16(1)).unwrap();
    let wrong = tea::schedule(&key16(2)).unwrap();
    let plain = b"hello world, this is a test body";
    let enc_len = tea::qq_tea_encrypt_len(plain.len());
    let mut ct = vec![0u8; enc_len];
    tea::qq_tea_encrypt(plain, &k, &mut ct).unwrap();

    let mut out = vec![0u8; enc_len];
    // Right key decrypts; wrong key fails the seven-zero tail check.
    assert!(tea::qq_tea_decrypt(&ct, &k, &mut out).is_some());
    assert!(tea::qq_tea_decrypt(&ct, &wrong, &mut out).is_none());
}

#[test]
fn tea_rejects_malformed_lengths() {
    let k = tea::schedule(&key16(9)).unwrap();
    let mut out = [0u8; 64];
    assert!(tea::qq_tea_decrypt(&[0u8; 8], &k, &mut out).is_none()); // < MIN_CIPHERTEXT
    assert!(tea::qq_tea_decrypt(&[0u8; 17], &k, &mut out).is_none()); // not block-aligned
}

#[test]
fn varint_unsigned_roundtrip() {
    let vals = [0u64, 1, 127, 128, 300, 16384, u32::MAX as u64, u64::MAX >> 1];
    for &v in &vals {
        let mut buf = [0u8; 10];
        let w = varint::write_varint(&mut buf, v);
        assert_eq!(w, varint::varint_width(v), "width mismatch for {v}");
        let mut r = varint::WireReader::new(&buf[..w]);
        assert_eq!(r.u(), v);
        assert!(!r.bad);
        assert_eq!(r.pos(), w);
    }
}

#[test]
fn varint_zigzag_roundtrip() {
    let vals = [0i64, -1, 1, -2, 2, 63, -64, i32::MIN as i64, i32::MAX as i64];
    for &v in &vals {
        let enc = varint::zigzag_encode(v);
        assert_eq!(varint::zigzag_decode(enc), v);
        let mut buf = [0u8; 10];
        let w = varint::write_varint(&mut buf, enc);
        let mut r = varint::WireReader::new(&buf[..w]);
        assert_eq!(r.z(), v, "zigzag reader for {v}");
    }
}

#[test]
fn varint_padded_writes_fixed_width_and_reads_back() {
    // A value that naturally needs 1 byte, written padded to 3, must read back
    // identically and consume exactly 3 bytes (the in-place-rewrite guarantee).
    let mut buf = [0u8; 3];
    let w = varint::write_varint_padded(&mut buf, 5, 3);
    assert_eq!(w, 3);
    let mut r = varint::WireReader::new(&buf);
    assert_eq!(r.u(), 5);
    assert_eq!(r.pos(), 3);
}

#[test]
fn wire_reader_raw_byte_vs_varint() {
    // 0x81 as a raw byte is 0x81; as a varint start it would consume a second
    // byte — the classic desync the reader must not commit.
    let buf = [0x81u8, 0x01];
    let mut r = varint::WireReader::new(&buf);
    assert_eq!(r.raw_byte(), 0x81);
    assert_eq!(r.raw_byte(), 0x01);
    assert!(!r.bad);
}
