//! Cmd 1900/1901 keyed property-stream decoder. Real captures of this stream are
//! encrypted (the Java measured 6709/6709 live with the session key), so these
//! tests build synthetic bodies to the exact grammar — exercising both raw-field
//! traps (u16 LE blockLen, u8 varId), multi-group 1900, ownerless 1901, the
//! confirmed HP=200-at-1:1 fact, unknown-id skip-as-one-varint, and every
//! rejection path. Round-trip + boundary coverage, labelled as such, not a
//! capture golden.

use nuvola_core::pri::{self, epri, VALUE_MASK};

fn put_u(out: &mut Vec<u8>, mut v: u64) {
    loop {
        let mut byte = (v & 0x7f) as u8;
        v >>= 7;
        if v != 0 {
            byte |= 0x80;
        }
        out.push(byte);
        if v == 0 {
            break;
        }
    }
}

/// One record: u8 varId + varint value.
fn put_record(out: &mut Vec<u8>, var_id: u8, value: u64) {
    out.push(var_id);
    put_u(out, value);
}

/// One 1900 group: owner varint + u16 LE blockLen + records.
fn put_group_1900(out: &mut Vec<u8>, owner: u64, records: &[(u8, u64)]) {
    put_u(out, owner);
    let mut block = Vec::new();
    for &(id, v) in records {
        put_record(&mut block, id, v);
    }
    out.push((block.len() & 0xff) as u8);
    out.push(((block.len() >> 8) & 0xff) as u8);
    out.extend_from_slice(&block);
}

/// One 1901 group: no owner, u16 LE blockLen + records.
fn put_group_1901(out: &mut Vec<u8>, records: &[(u8, u64)]) {
    let mut block = Vec::new();
    for &(id, v) in records {
        put_record(&mut block, id, v);
    }
    out.push((block.len() & 0xff) as u8);
    out.push(((block.len() >> 8) & 0xff) as u8);
    out.extend_from_slice(&block);
}

#[test]
fn single_group_hp_at_one_to_one() {
    // The confirmed fact: 200 HP is 200 on the wire, plain varint, no zigzag.
    let mut body = Vec::new();
    put_group_1900(&mut body, 4242, &[
        (epri::CUR_HP as u8, 200),
        (epri::MAX_HP as u8, 200),
    ]);

    let mut got: Vec<(i64, i32, u64)> = Vec::new();
    assert!(pri::decode(&body, 0, body.len(), true, |o, id, v| got.push((o, id, v))));
    assert_eq!(got, vec![(4242, epri::CUR_HP, 200), (4242, epri::MAX_HP, 200)]);
}

#[test]
fn multi_group_1900_owners_carry_through() {
    let mut body = Vec::new();
    put_group_1900(&mut body, 10, &[(epri::CUR_HP as u8, 150)]);
    put_group_1900(&mut body, 20, &[(epri::CUR_HP as u8, 90), (epri::FIRING as u8, 2)]);

    let mut got: Vec<(i64, i32, u64)> = Vec::new();
    assert!(pri::decode(&body, 0, body.len(), true, |o, id, v| got.push((o, id, v))));
    assert_eq!(got, vec![
        (10, epri::CUR_HP, 150),
        (20, epri::CUR_HP, 90),
        (20, epri::FIRING, 2),
    ]);
}

#[test]
fn cmd_1901_has_no_owner() {
    let mut body = Vec::new();
    put_group_1901(&mut body, &[(epri::TOTAL_DMG as u8, 3300)]);
    let mut got: Vec<(i64, i32, u64)> = Vec::new();
    assert!(pri::decode(&body, 0, body.len(), false, |o, id, v| got.push((o, id, v))));
    assert_eq!(got, vec![(-1, epri::TOTAL_DMG, 3300)]);
}

#[test]
fn unknown_id_is_skipped_as_one_varint_without_desync() {
    // An unknown varId (200) with a multi-byte varint value must be walked as
    // exactly one varint, leaving a following known record correctly framed.
    let mut body = Vec::new();
    put_group_1900(&mut body, 7, &[
        (200u8, 0x1234),            // unknown id, 2-byte varint value
        (epri::CUR_HP as u8, 175),  // must still land here
    ]);
    let mut got: Vec<(i64, i32, u64)> = Vec::new();
    assert!(pri::decode(&body, 0, body.len(), true, |o, id, v| got.push((o, id, v))));
    assert_eq!(got, vec![(7, 200, 0x1234), (7, epri::CUR_HP, 175)]);
}

#[test]
fn blocklen_is_little_endian_u16_not_varint() {
    // Build a block whose length is >= 0x80 so a varint mis-read would truncate
    // it. 130 bytes of records: 65 two-byte records (id + 1-byte value).
    let mut records = Vec::new();
    for _ in 0..65 {
        records.push((epri::FIRING as u8, 1u64));
    }
    let mut body = Vec::new();
    put_group_1900(&mut body, 1, &records);
    // Sanity: blockLen field must be 130 = 0x82 0x00 little-endian.
    // owner=1 (1 byte), then blockLen lo/hi.
    assert_eq!(body[1], 0x82);
    assert_eq!(body[2], 0x00);

    let mut count = 0usize;
    assert!(pri::decode(&body, 0, body.len(), true, |_, _, _| count += 1));
    assert_eq!(count, 65);
}

#[test]
fn value_masked_to_56_bits_matches_java_packing() {
    // A value that overflows 56 bits (like a packed itemId) is truncated to 56
    // bits by the Java packing; we reproduce that exactly.
    let big: u64 = (1u64 << 60) | 0x00AB_CDEF; // bit 60 set, above the 56-bit ceiling
    let mut body = Vec::new();
    put_group_1900(&mut body, 1, &[(epri::VEST as u8, big)]);
    let mut seen = 0u64;
    assert!(pri::decode(&body, 0, body.len(), true, |_, _, v| seen = v));
    assert_eq!(seen, big & VALUE_MASK);
    assert_ne!(seen, big, "the 56-bit ceiling must actually truncate this value");
}

#[test]
fn rejects_trailing_byte() {
    let mut body = Vec::new();
    put_group_1900(&mut body, 1, &[(epri::CUR_HP as u8, 100)]);
    body.push(0x00);
    assert!(!pri::decode(&body, 0, body.len(), true, |_, _, _| {}));
}

#[test]
fn rejects_blocklen_overrun() {
    let mut body = Vec::new();
    put_group_1900(&mut body, 1, &[(epri::CUR_HP as u8, 100)]);
    // Corrupt blockLen (bytes 1,2 for owner=1) to claim more than is present.
    body[1] = 0xFF;
    body[2] = 0xFF;
    assert!(!pri::decode(&body, 0, body.len(), true, |_, _, _| {}));
}

#[test]
fn rejects_truncated_at_every_cut() {
    let mut body = Vec::new();
    put_group_1900(&mut body, 42, &[(epri::CUR_HP as u8, 200), (epri::MAX_HP as u8, 200)]);
    for cut in 1..body.len() {
        assert!(
            !pri::decode(&body, 0, cut, true, |_, _, _| {}),
            "truncation at {cut} must be refused"
        );
    }
}

#[test]
fn rejects_record_value_running_past_block() {
    // A record whose varint value has its continuation bit set at the block
    // boundary must fail (varint returns None against `stop`).
    let mut body = Vec::new();
    // owner=1, blockLen=1, single byte 0x80 (continuation set, no terminator).
    put_u(&mut body, 1);
    body.push(0x02); // blockLen lo
    body.push(0x00); // blockLen hi
    body.push(epri::CUR_HP as u8);
    body.push(0x80); // varint with continuation bit but block ends here
    assert!(!pri::decode(&body, 0, body.len(), true, |_, _, _| {}));
}
