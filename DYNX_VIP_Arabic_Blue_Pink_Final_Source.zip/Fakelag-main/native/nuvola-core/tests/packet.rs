//! Header codec (parse/reserialize) + the foreign-safe seal. Synthetic
//! round-trips plus seal Foreign/Intact/Repaired verified on REAL captured 2001
//! packets (seal uses only MsgKey + CRC, so no per-session layout is needed).

use nuvola_core::crc7;
use nuvola_core::header::{Field, HeaderLayout, DEFAULT_ORDER};
use nuvola_core::integrity::{self, Seal};
use nuvola_core::packet::{self, flags};
use serde::Deserialize;
use std::path::PathBuf;

fn unhex(s: &str) -> Vec<u8> {
    (0..s.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap())
        .collect()
}

#[test]
fn flag_helpers() {
    assert!(flags::is_plaintext(0) && !flags::is_encrypted(0));
    assert!(flags::is_encrypted(1) && !flags::is_plaintext(1));
    assert!(flags::is_zipped(2));
    assert!(flags::is_plausible(0b11) && !flags::is_plausible(0b100));
}

#[test]
fn parse_reliable_roundtrip() {
    // Build a reliable (10-byte header) packet with mask 0x3C, default order.
    let layout = HeaderLayout::new(0x3C, DEFAULT_ORDER).unwrap();
    let body = [1u8, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
    let mut pkt = vec![0u8; 10 + body.len()];
    pkt[0] = 92; // reliable msgkey
    pkt[10..].copy_from_slice(&body);
    layout.write_byte(&mut pkt, 0, Field::SendOption, true, 0x11);
    layout.write_short(&mut pkt, 0, Field::Cmd, true, 106);
    layout.write_short(&mut pkt, 0, Field::OrderId, true, 0x1234);
    layout.write_byte(&mut pkt, 0, Field::Flags, true, flags::ENCRYPTED);
    layout.write_short(&mut pkt, 0, Field::DataLen, true, body.len() as i32);
    crc7::seal(&mut pkt);

    let p = packet::parse(&pkt, 0, pkt.len(), &layout).expect("parse");
    assert!(p.is_reliable() && p.header_size == 10);
    assert_eq!(p.send_option, 0x11);
    assert_eq!(p.cmd, 106);
    assert_eq!(p.order_id, 0x1234);
    assert!(p.is_encrypted());
    assert_eq!(p.declared_length, body.len() as i32);
    assert_eq!(p.payload_offset, 10);
    assert_eq!(p.payload_length, body.len());
    assert!(p.length_matches());
    assert!(p.is_crc_valid());
}

#[test]
fn parse_rejects_foreign_and_nonreliable_hdr() {
    let layout = HeaderLayout::default_layout();
    let mut pkt = vec![0u8; 12];
    pkt[0] = 200; // outside 90..110 -> not match traffic
    assert!(packet::parse(&pkt, 0, pkt.len(), &layout).is_none());
    pkt[0] = 105; // non-reliable -> 8-byte header
    let p = packet::parse(&pkt, 0, pkt.len(), &layout).unwrap();
    assert!(!p.is_reliable() && p.header_size == 8 && p.order_id == -1);
}

#[test]
fn reserialize_after_body_edit_makes_crc_valid() {
    let layout = HeaderLayout::new(0, DEFAULT_ORDER).unwrap();
    let mut pkt = vec![0u8; 8 + 6];
    pkt[0] = 100;
    layout.write_short(&mut pkt, 0, Field::DataLen, false, 6);
    crc7::seal(&mut pkt);
    assert!(crc7::verify(&pkt));
    pkt[9] ^= 0xFF; // edit a body byte -> stale crc
    assert!(!crc7::verify(&pkt));
    let n = pkt.len();
    assert!(packet::reserialize(&mut pkt, 0, n));
    assert!(crc7::verify(&pkt));
}

#[test]
fn seal_foreign_intact_repaired_on_real_2001_packets() {
    let p = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/data/pos2001_golden.json");
    let data = match std::fs::read_to_string(&p) {
        Ok(d) => d,
        Err(_) => {
            eprintln!("SKIP: pos2001 golden not present");
            return;
        }
    };
    #[derive(Deserialize)]
    struct E {
        packet_hex: String,
    }
    let vs: Vec<E> = serde_json::from_str(&data).unwrap();
    assert!(!vs.is_empty());

    // Foreign: a buffer whose byte0 is outside the MsgKey range is never touched.
    let mut foreign = vec![7u8; 20];
    foreign[0] = 200;
    let before = foreign.clone();
    assert_eq!(integrity::seal_all(&mut foreign), Seal::Foreign);
    assert_eq!(foreign, before, "foreign traffic must be left untouched");

    let mut intact = 0usize;
    let mut repaired = 0usize;
    for e in &vs {
        let mut pkt = unhex(&e.packet_hex);
        // A genuine captured packet has a valid CRC -> Intact, nothing written.
        let snapshot = pkt.clone();
        assert_eq!(integrity::seal_all(&mut pkt), Seal::Intact);
        assert_eq!(pkt, snapshot, "intact seal must not modify the packet");
        intact += 1;

        // Edit a body byte -> stale CRC -> Repaired, and the CRC is valid after.
        let n = pkt.len();
        pkt[n - 1] ^= 0xFF;
        assert_eq!(integrity::seal(&mut pkt, 0, n), Seal::Repaired);
        assert!(crc7::verify(&pkt), "repaired packet must have a valid CRC");
        repaired += 1;
    }
    eprintln!("integrity::seal over {intact} real 2001 packets: intact ok, {repaired} repaired ok");
}
