//! Cross-implementation known-answer test. The vectors below were emitted by
//! the repo's independent Python oracle (`tools/ffproto/crypto.py`), which was
//! itself validated against the Java on live captures (138/138, 339/339 for
//! QQ-TEA; 25 596/25 596 for CRC-7). Reproducing them exactly proves the Rust
//! port is byte-identical to Python == Java, not merely self-consistent.
//!
//! Regenerate with scratchpad/gen_vector.py if the reference ever changes.

use nuvola_core::{crc7, tea};

fn unhex(s: &str) -> Vec<u8> {
    (0..s.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap())
        .collect()
}

const KEY: &str = "0b30557a9fc4e90e33587da2c7ec1136";
const PLAIN: &str =
    "0566c72889ea4bac0d6ecf3091f253b41576d73899fa5bbc1d7edf40a10263c42586e748a90a6bcc";
const CT: &str = "fc7b9ca079c40f2588f3dddce0ed7d6846c82b218064b29ccdf17448eddf644c\
                  e394277e39ff4cb611e5a0117aa04477096c7839586c3f80";

#[test]
fn tea_matches_python_oracle_vector() {
    let key = unhex(KEY);
    let plain = unhex(PLAIN);
    let want_ct = unhex(CT);
    let k = tea::schedule(&key).unwrap();

    let mut ct = vec![0u8; tea::qq_tea_encrypt_len(plain.len())];
    let n = tea::qq_tea_encrypt(&plain, &k, &mut ct).unwrap();
    assert_eq!(n, want_ct.len(), "ciphertext length");
    assert_eq!(ct, want_ct, "Rust ciphertext must equal the Python/Java oracle");

    let mut out = vec![0u8; want_ct.len()];
    let m = tea::qq_tea_decrypt(&want_ct, &k, &mut out).unwrap();
    assert_eq!(&out[..m], &plain[..], "Rust must decrypt the oracle ciphertext");
}

#[test]
fn crc7_matches_python_oracle_vector() {
    // pkt = 0x5a,0x00, then bytes 0..30; crc7 over [2..] == 0x55 (85).
    let mut pkt = vec![0x5au8, 0x00];
    pkt.extend(0u8..30);
    assert_eq!(crc7::of_packet(&pkt), 85);
}
