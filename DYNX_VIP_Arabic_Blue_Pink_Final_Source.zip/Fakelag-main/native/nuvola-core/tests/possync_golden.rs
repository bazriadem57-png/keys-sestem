//! Real-capture parity for the Cmd-2001 codec. Loads golden vectors extracted
//! from the live capture corpus (tests/data/pos2001_golden.json) and checks:
//!   1. parse recovers the exact raw + zigzag-decoded values (READ parity), and
//!   2. canonical re-encode of handle + 23 raw varints reproduces the wire body
//!      byte-for-byte (WRITE parity).
//!
//! Both are layout-independent (the 2001 body is plaintext; parse needs only the
//! MsgKey byte for the header size), so no per-session mask is required here —
//! rebuild()'s DATA_LEN/CRC/layout machinery is covered by the synthetic tests.
//!
//! The fixture is produced by scratchpad extraction from `captures/`; until it is
//! copied into tests/data/, this test no-ops with a note.

use nuvola_core::possync::{self, PosSync};
use nuvola_core::varint::write_varint;
use serde::Deserialize;
use std::path::PathBuf;

#[derive(Deserialize)]
struct Vec2001 {
    packet_hex: String,
    header_size: usize,
    #[allow(dead_code)]
    cmd: u32,
    handle_hex: String,
    raw: Vec<u64>,
    signed: Vec<i64>,
}

fn unhex(s: &str) -> Vec<u8> {
    (0..s.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap())
        .collect()
}

#[test]
fn positionsync_matches_real_captures() {
    let p = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/data/pos2001_golden.json");
    let data = match std::fs::read_to_string(&p) {
        Ok(d) => d,
        Err(_) => {
            eprintln!("SKIP: golden fixture not present at {:?} — extract it first", p);
            return;
        }
    };
    let vs: Vec<Vec2001> = serde_json::from_str(&data).expect("valid golden json");
    assert!(!vs.is_empty(), "golden fixture must not be empty");

    for (n, v) in vs.iter().enumerate() {
        assert_eq!(v.raw.len(), possync::BODY_VARINTS, "entry {n} raw len");
        assert_eq!(v.signed.len(), possync::BODY_VARINTS, "entry {n} signed len");
        let orig = unhex(&v.packet_hex);

        // READ parity.
        let mut ps = PosSync::new();
        assert!(ps.parse(&orig, 0, orig.len()), "entry {n} parse: {}", v.packet_hex);
        for i in 0..possync::BODY_VARINTS {
            assert_eq!(ps.raw_at(i), v.raw[i], "entry {n} raw[{i}]");
            assert_eq!(ps.signed_at(i), v.signed[i], "entry {n} signed[{i}]");
        }

        // WRITE parity: handle + canonical(raw) must reproduce the wire body.
        let mut body = unhex(&v.handle_hex);
        for &r in &v.raw {
            let mut b = [0u8; 10];
            let w = write_varint(&mut b, r);
            body.extend_from_slice(&b[..w]);
        }
        assert_eq!(
            body,
            &orig[v.header_size..],
            "entry {n} canonical re-encode != wire body"
        );
    }
    eprintln!("verified {} real Cmd-2001 packets", vs.len());
}
