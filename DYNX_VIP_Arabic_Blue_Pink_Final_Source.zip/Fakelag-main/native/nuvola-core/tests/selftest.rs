//! The load-time self-test the live-update loader gates promotion on. Exercising
//! it here means a build whose crc7/tea/varint/zigzag/chain arithmetic regressed
//! fails `cargo test` in CI, not silently at `System.load()` on a device.

#[test]
fn selftest_passes() {
    assert!(nuvola_core::selftest(), "native selftest KAT must pass");
}
