//! Cmd 2002 / 2069 mounted-carrier parser. No on-wire capture exists for either
//! command (the corpus's Cmd 2002 records are the inbound batched list, a
//! different class), so these tests build a synthetic body to the SAME wire
//! rules the parser reads, round-trip it, and exercise the field-8 raw/varint
//! retry plus every rejection path. This is round-trip + boundary coverage, not
//! a capture golden — and is labelled as such deliberately.

use nuvola_core::varint::{write_varint, zigzag_encode};
use nuvola_core::vehicle::{self, VehicleState, CMD_VEHICLE, CMD_VEHICLE_FIRE};

/// Encode one unsigned varint onto `out`.
fn put_u(out: &mut Vec<u8>, v: u64) {
    let mut buf = [0u8; 10];
    let n = write_varint(&mut buf, v);
    out.extend_from_slice(&buf[..n]);
}

/// Encode one zigzag varint onto `out`.
fn put_z(out: &mut Vec<u8>, v: i64) {
    put_u(out, zigzag_encode(v));
}

/// Millidegree quaternion component: the /1000 float the parser recovers is
/// `milli as f32 / 1000.0`, so we encode the pre-scaled integer.
fn milli(x: f32) -> i64 {
    (x * 1000.0).round() as i64
}
/// Centi-scaled velocity/aim component (parser divides by 100).
fn centi(x: f32) -> i64 {
    (x * 100.0).round() as i64
}

/// Build a synthetic 2002/2069 body. `op` is the raw field-8 byte value.
#[allow(clippy::too_many_arguments)] // a test builder mirroring the full record shape
fn build(cmd: i32, id: u64, pos: [i64; 3], quat: [f32; 4], op: u64, vel: [f32; 3],
         tick: u64, aim: Option<([f32; 3], u64)>) -> Vec<u8> {
    let mut b = Vec::new();
    put_u(&mut b, id);
    for p in pos { put_z(&mut b, p); }
    for q in quat { put_z(&mut b, milli(q)); }
    // FIELD 8: how the wire actually carries it decides the encoding we emit.
    if cmd == CMD_VEHICLE_FIRE && aim.is_none() {
        panic!("2069 requires aim");
    }
    if op < 0x80 {
        b.push(op as u8); // single raw byte, the default reading
    } else {
        // A value >= 0x80 as a *raw* byte is still one byte on the wire.
        b.push(op as u8);
    }
    for v in vel { put_z(&mut b, centi(v)); }
    put_u(&mut b, tick);
    if let Some((a, ms)) = aim {
        for v in a { put_z(&mut b, centi(v)); }
        put_u(&mut b, ms);
    }
    b
}

fn approx(a: f32, b: f32, eps: f32) -> bool {
    (a - b).abs() <= eps
}

#[test]
fn car_2002_roundtrip_no_aim() {
    let h = std::f32::consts::FRAC_1_SQRT_2; // 1/sqrt(2): a unit quaternion component
    let quat = [0.0f32, h, 0.0, h];
    let body = build(CMD_VEHICLE, 4242, [12000, -3000, 88000], quat, 0x05,
                     [3.5, 0.0, -1.25], 90210, None);
    let r = vehicle::parse(CMD_VEHICLE, &body).expect("car parse");
    assert_eq!(r.vehicle_id, 4242);
    assert_eq!((r.x, r.up, r.z), (12000, -3000, 88000));
    assert!(approx(r.qy, h, 1e-3) && approx(r.qw, h, 1e-3));
    assert_eq!(r.packed_op, 0x05);
    assert!(approx(r.vx, 3.5, 1e-2) && approx(r.vz, -1.25, 1e-2));
    assert_eq!(r.server_tick, 90210);
    assert!(!r.has_aim && !r.op_was_varint);
}

#[test]
fn horse_2069_roundtrip_with_aim() {
    let quat = [0.1f32, 0.0, 0.0, (1.0f32 - 0.01).sqrt()]; // unit
    let aim = [0.0f32, 0.0, 1.0];
    let body = build(CMD_VEHICLE_FIRE, 77, [1, 2, 3], quat, 0x11,
                     [0.0, 0.0, 0.0], 5, Some((aim, 123456)));
    let r = vehicle::parse(CMD_VEHICLE_FIRE, &body).expect("horse parse");
    assert!(r.has_aim);
    assert!(approx(r.aim_z, 1.0, 1e-2));
    assert_eq!(r.client_ms, 123456);
    assert_eq!(r.packed_op, 0x11);
}

#[test]
fn field8_high_byte_takes_the_varint_retry() {
    // A field-8 value >= 0x80 written as a single raw byte parses cleanly on the
    // raw-byte path; but if the WIRE used a varint there, the raw reading eats
    // one byte too few and the terminal-cursor check fails, forcing the retry.
    // Build the body with field 8 as a *varint* (two bytes for 0x80) so the
    // raw-byte first attempt must fail and the varint retry must succeed.
    let quat = [0.0f32, 0.0, 0.0, 1.0];
    let mut b = Vec::new();
    put_u(&mut b, 9);
    for p in [0i64, 0, 0] { put_z(&mut b, p); }
    for q in quat { put_z(&mut b, milli(q)); }
    put_u(&mut b, 0x80); // FIELD 8 AS A VARINT (2 bytes: 0x80 0x01)
    for v in [0i64, 0, 0] { put_z(&mut b, v); }
    put_u(&mut b, 1);

    let mut opv = 0u64;
    let mut rej = 0u64;
    let r = vehicle::parse_counted(CMD_VEHICLE, &b, &mut opv, &mut rej)
        .expect("varint-retry parse");
    assert!(r.op_was_varint, "field 8 must have taken the varint retry");
    assert_eq!(r.packed_op, 0x80);
    assert_eq!(opv, 1);
    assert_eq!(rej, 0);
}

#[test]
fn rejects_non_unit_quaternion() {
    let bad_quat = [1.0f32, 1.0, 1.0, 1.0]; // sum of squares = 4, way off
    let body = build(CMD_VEHICLE, 1, [0, 0, 0], bad_quat, 0, [0.0, 0.0, 0.0], 0, None);
    let mut opv = 0u64;
    let mut rej = 0u64;
    assert!(vehicle::parse_counted(CMD_VEHICLE, &body, &mut opv, &mut rej).is_none());
    assert_eq!(rej, 1, "a non-unit quaternion must be rejected, not half-applied");
}

#[test]
fn rejects_trailing_bytes() {
    let quat = [0.0f32, 0.0, 0.0, 1.0];
    let mut body = build(CMD_VEHICLE, 1, [0, 0, 0], quat, 0, [0.0, 0.0, 0.0], 0, None);
    body.push(0x00); // one byte over: terminal-cursor check must fail
    assert!(vehicle::parse(CMD_VEHICLE, &body).is_none());
}

#[test]
fn rejects_truncated_body() {
    let quat = [0.0f32, 0.0, 0.0, 1.0];
    let body = build(CMD_VEHICLE, 1, [0, 0, 0], quat, 0, [0.0, 0.0, 0.0], 0, None);
    for cut in 1..body.len() {
        assert!(
            vehicle::parse(CMD_VEHICLE, &body[..cut]).is_none(),
            "truncation at {cut} must be refused"
        );
    }
}

#[test]
fn rejects_wrong_cmd() {
    let quat = [0.0f32, 0.0, 0.0, 1.0];
    let body = build(CMD_VEHICLE, 1, [0, 0, 0], quat, 0, [0.0, 0.0, 0.0], 0, None);
    assert!(vehicle::parse(2001, &body).is_none());
    assert!(vehicle::parse(106, &body).is_none());
}

#[test]
fn rejects_2069_with_bad_aim() {
    let quat = [0.0f32, 0.0, 0.0, 1.0];
    let bad_aim = [5.0f32, 5.0, 5.0]; // length^2 = 75, far from 1
    let body = build(CMD_VEHICLE_FIRE, 1, [0, 0, 0], quat, 0, [0.0, 0.0, 0.0], 0,
                     Some((bad_aim, 1)));
    assert!(vehicle::parse(CMD_VEHICLE_FIRE, &body).is_none());
}

#[test]
fn default_state_is_zeroed() {
    let s = VehicleState::default();
    assert_eq!(s.vehicle_id, 0);
    assert!(!s.has_aim && !s.op_was_varint);
}
