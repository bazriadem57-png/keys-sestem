//! Non-circular parity for the Cmd-106 walk: verify it locates the SAME field
//! offsets on REAL decrypted hits that the independent Python extraction did.
//! Skips with a note until tests/data/hit106_golden.json is present.

use nuvola_core::aim::{self, BodyWalk};
use nuvola_core::varint::zigzag_decode;
use serde::Deserialize;
use std::path::PathBuf;

#[derive(Deserialize)]
struct Field {
    start: usize,
    width: usize,
    raw: u64,
    #[serde(default)]
    #[allow(dead_code)] // present in the fixture schema; not asserted here
    zone_high_byte: i64,
}
#[derive(Deserialize)]
struct Idx7 {
    pos: usize,
    val: i64,
}
#[derive(Deserialize)]
struct HitPoint {
    starts: Vec<usize>,
    widths: Vec<usize>,
    signed: Vec<i64>,
}
#[derive(Deserialize)]
struct Hit106 {
    #[allow(dead_code)]
    packet_hex: String,
    plain_hex: String,
    idx3: Field,
    idx7: Idx7,
    idx15: Field,
    hitpoint: HitPoint,
}

fn unhex(s: &str) -> Vec<u8> {
    (0..s.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap())
        .collect()
}

#[test]
fn aim106_walk_matches_real_hits() {
    let p = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/data/hit106_golden.json");
    let data = match std::fs::read_to_string(&p) {
        Ok(d) => d,
        Err(_) => {
            eprintln!("SKIP: hit106 golden not present at {:?}", p);
            return;
        }
    };
    let vs: Vec<Hit106> = serde_json::from_str(&data).expect("valid hit106 json");
    assert!(!vs.is_empty(), "hit106 golden must not be empty");

    let mut two_copy_ok = 0usize;
    for (n, v) in vs.iter().enumerate() {
        let plain = unhex(&v.plain_hex);
        let mut w = BodyWalk::new();
        assert!(w.walk(&plain), "entry {n}: walk must consume the body");

        // idx3
        assert_eq!(w.f_start[aim::PC_IDX3] as usize, v.idx3.start, "entry {n} idx3.start");
        assert_eq!(w.f_width[aim::PC_IDX3] as usize, v.idx3.width, "entry {n} idx3.width");
        assert_eq!(w.raw_at(&plain, aim::PC_IDX3).unwrap(), v.idx3.raw, "entry {n} idx3.raw");
        // idx7 raw byte
        assert_eq!(w.f_start[aim::PC_IDX7] as usize, v.idx7.pos, "entry {n} idx7.pos");
        assert_eq!(plain[v.idx7.pos] as i64, v.idx7.val, "entry {n} idx7.val");
        // idx15
        assert_eq!(w.f_start[aim::PC_IDX15] as usize, v.idx15.start, "entry {n} idx15.start");
        assert_eq!(w.f_width[aim::PC_IDX15] as usize, v.idx15.width, "entry {n} idx15.width");
        assert_eq!(w.raw_at(&plain, aim::PC_IDX15).unwrap(), v.idx15.raw, "entry {n} idx15.raw");
        // hit point
        let pcs = [aim::PC_IDX9_X, aim::PC_IDX9_UP, aim::PC_IDX9_Z];
        for (k, &pc) in pcs.iter().enumerate() {
            assert_eq!(w.f_start[pc] as usize, v.hitpoint.starts[k], "entry {n} hp.start[{k}]");
            assert_eq!(w.f_width[pc] as usize, v.hitpoint.widths[k], "entry {n} hp.width[{k}]");
            let raw = w.raw_at(&plain, pc).unwrap();
            assert_eq!(zigzag_decode(raw), v.hitpoint.signed[k], "entry {n} hp.signed[{k}]");
        }
        // Two-copy premise: idx3 high byte == idx7 byte (should hold on real hits).
        if aim::zone_of_val3(v.idx3.raw) as i64 == v.idx7.val {
            two_copy_ok += 1;
        }
    }
    eprintln!("aim106: verified {} real hits; two-copy agree {}/{}",
              vs.len(), two_copy_ok, vs.len());
    assert_eq!(two_copy_ok, vs.len(), "two-copy (idx3-hi == idx7) must hold on every real hit");
}
