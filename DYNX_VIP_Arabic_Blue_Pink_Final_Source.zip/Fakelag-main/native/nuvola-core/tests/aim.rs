//! Cmd-106 body walk (mechanics) + zone-edit math. The non-circular parity
//! against real decrypted hits lives in aim_golden.rs.

use nuvola_core::aim::{self, BodyWalk, CpPlan};
use nuvola_core::crc7;
use nuvola_core::header::{Field, HeaderLayout, DEFAULT_ORDER};
use nuvola_core::tea;
use nuvola_core::varint::{write_varint, zigzag_decode, zigzag_encode};

fn key16() -> [u32; 4] {
    tea::schedule(&[0x27, 0xfd, 0x28, 0x64, 0xdf, 0x69, 0x84, 0xc5,
                    0xf8, 0x43, 0x60, 0x94, 0xc0, 0xe7, 0x0d, 0xef]).unwrap()
}

/// Build a reliable Cmd-106 packet (default layout, mask 0) with `body`
/// TEA-encrypted, so rewrite_packet can run end to end.
fn build_packet(k: &[u32; 4], body: &[u8]) -> Vec<u8> {
    let enc = tea::qq_tea_encrypt_len(body.len());
    let mut cipher = vec![0u8; enc];
    tea::qq_tea_encrypt(body, k, &mut cipher).unwrap();
    let mut pkt = vec![0u8; 10]; // reliable header
    pkt[0] = 90;
    pkt[3] = 106; // cmd lo
    pkt[7] = 1; // flags
    pkt[8] = (enc & 0xFF) as u8;
    pkt[9] = ((enc >> 8) & 0xFF) as u8;
    pkt.extend_from_slice(&cipher);
    crc7::seal(&mut pkt);
    pkt
}

fn push_u(b: &mut Vec<u8>, u: u64) {
    let mut t = [0u8; 10];
    let n = write_varint(&mut t, u);
    b.extend_from_slice(&t[..n]);
}
fn push_z(b: &mut Vec<u8>, v: i64) {
    push_u(b, zigzag_encode(v));
}

/// Build a valid 106 body per PROG_106 = UUUUUZUBUZZZZZZ(F)UFUZBB(B)FBU.
/// Returns (body, val3, zone7, idx15_raw, hitpoint[3]).
fn build_body() -> (Vec<u8>, u64, u8, u64, [i64; 3]) {
    let mut b = Vec::new();
    let val3 = ((aim::ZONE_BODY as u64) << 24) | 0x00_0102; // zone=Body, low24 damage/id
    let zone7 = aim::ZONE_BODY;
    let idx15_raw = zigzag_encode((5i64 << 2) | (aim::ZONE_BODY as i64)); // colliderId|hitType
    let hp = [123_456i64, -7_000, 654_321];

    push_u(&mut b, 0x11FF_0007); // idx0 victim handle (low24 = victim id)
    push_u(&mut b, 10); // idx1
    push_u(&mut b, 20); // idx2
    push_u(&mut b, val3); // idx3
    push_u(&mut b, 40); // idx4
    push_z(&mut b, -9); // idx5 Z
    push_u(&mut b, 60); // idx6 U
    b.push(zone7); // idx7 B raw byte
    push_u(&mut b, 987_654); // idx8 tick
    push_z(&mut b, hp[0]); // idx9 X
    push_z(&mut b, hp[1]); // idx10 UP
    push_z(&mut b, hp[2]); // idx11 Z
    push_z(&mut b, 1); // idx12 hitdir X
    push_z(&mut b, 2); // idx13 hitdir UP
    push_z(&mut b, 3); // idx14 hitdir Z
    // (F) checkParams list: count=2
    push_u(&mut b, zigzag_encode(2)); // list count (zigzag)
    push_u(&mut b, 0x3F80_0000); // F entry 0
    push_u(&mut b, 0x3E4C_CCCD); // F entry 1
    push_u(&mut b, 70); // idx18 U
    push_u(&mut b, 0x4000_0000); // idx19 F
    push_u(&mut b, 80); // idx20 U
    push_u(&mut b, idx15_raw); // idx21 = idx15 Z
    b.push(4); // idx22 B
    b.push(5); // idx23 B
    // (B) token list: count=1
    push_u(&mut b, zigzag_encode(1)); // list count
    b.push(0xAB); // one token byte
    push_u(&mut b, 0x3DCC_CCCD); // idx27 F
    b.push(6); // idx28 B
    push_u(&mut b, 90); // idx29 U
    (b, val3, zone7, idx15_raw, hp)
}

#[test]
fn walk_locates_all_fields_and_consumes_exactly() {
    let (body, val3, zone7, idx15_raw, hp) = build_body();
    let mut w = BodyWalk::new();
    assert!(w.walk(&body), "walk must consume the body exactly");

    // idx3
    assert!(w.f_start[aim::PC_IDX3] >= 0);
    assert_eq!(w.raw_at(&body, aim::PC_IDX3).unwrap(), val3);
    assert_eq!(aim::zone_of_val3(val3), zone7); // two-copy premise
    // idx7 raw byte
    assert_eq!(body[w.f_start[aim::PC_IDX7] as usize], zone7);
    assert_eq!(w.f_width[aim::PC_IDX7], 1);
    // idx15
    assert_eq!(w.raw_at(&body, aim::PC_IDX15).unwrap(), idx15_raw);
    // hit point
    for (k, pc) in [aim::PC_IDX9_X, aim::PC_IDX9_UP, aim::PC_IDX9_Z].iter().enumerate() {
        let raw = w.raw_at(&body, *pc).unwrap();
        assert_eq!(zigzag_decode(raw), hp[k], "hitpoint[{k}]");
    }
    // checkParams list recorded (count = 2)
    assert_eq!(w.cp_count, 2);
    assert!(w.cp_count_start >= 0 && w.cp_list_end > w.cp_count_start);
}

#[test]
fn zone_edit_math() {
    let val3 = (0x02u64 << 24) | 0x0102;
    let nv = aim::new_val3(val3, aim::ZONE_HEAD);
    assert_eq!(aim::zone_of_val3(nv), aim::ZONE_HEAD);
    assert_eq!(nv & 0x00FF_FFFF, 0x0102, "low 24 (damage/id) preserved");

    // idx15 HEAD0 clears the low 2 bits; VALUE1 sets them to 1; KEEP is None.
    let raw = zigzag_encode((7i64 << 2) | 3);
    let h0 = aim::new_raw_z15(raw, aim::IDX15_HEAD0).unwrap();
    assert_eq!(zigzag_decode(h0) & 0x3, 0);
    assert_eq!(zigzag_decode(h0) >> 2, 7, "high bits (colliderId) preserved");
    let v1 = aim::new_raw_z15(raw, aim::IDX15_VALUE1).unwrap();
    assert_eq!(zigzag_decode(v1) & 0x3, 1);
    assert!(aim::new_raw_z15(raw, aim::IDX15_KEEP).is_none());
}

#[test]
fn write_varint_padded_is_width_preserving() {
    let mut b = vec![0u8; 4];
    aim::write_varint_padded(&mut b, 0, 3, 5);
    // reads back as 5 and occupies exactly 3 bytes
    let mut w = BodyWalk::new();
    assert_eq!(w.read_varint_at(&b, 0, 3).unwrap(), 5);
    assert_eq!(b[3], 0, "4th byte untouched");
    assert!(aim::fits_width(5, 3) && !aim::fits_width(0xFFFF_FFFF, 2));
}

/// Re-walk a decrypted body and return (zone7, val3, idx15_raw, hitpoint[3]).
fn reparse(plain: &[u8]) -> (u8, u64, u64, [i64; 3]) {
    let mut w = BodyWalk::new();
    assert!(w.walk(plain), "re-walk must succeed");
    let val3 = w.raw_at(plain, aim::PC_IDX3).unwrap();
    let zone7 = plain[w.f_start[aim::PC_IDX7] as usize];
    let z15 = w.raw_at(plain, aim::PC_IDX15).unwrap();
    let hp = [
        zigzag_decode(w.raw_at(plain, aim::PC_IDX9_X).unwrap()),
        zigzag_decode(w.raw_at(plain, aim::PC_IDX9_UP).unwrap()),
        zigzag_decode(w.raw_at(plain, aim::PC_IDX9_Z).unwrap()),
    ];
    (zone7, val3, z15, hp)
}

fn decrypt_body(buf: &[u8], total: usize, k: &[u32; 4]) -> Vec<u8> {
    let mut out = vec![0u8; total];
    let n = tea::qq_tea_decrypt(&buf[10..total], k, &mut out).expect("decrypt");
    out.truncate(n);
    out
}

#[test]
fn fisher_yates_matches_both_proven_doc_examples() {
    // docs/CHECKPARAMS_ZONE_FIELD.md: vic=3 (idx0=0x2000003) canon{31,32,33} ->
    // wire {61,72,15}; vic=25 (idx0=0x7000019) -> {53,39,60}. n (the list count)
    // is the capture's, not stated — find the shared n that reproduces both.
    let mut buf = [0usize; 600];
    let mut shared = None;
    for n in 73..600 {
        aim::fisher_yates_idx(n, 0x0200_0003, &mut buf);
        if buf[31] == 61 && buf[32] == 72 && buf[33] == 15 {
            aim::fisher_yates_idx(n, 0x0700_0019, &mut buf);
            if buf[31] == 53 && buf[32] == 39 && buf[33] == 60 {
                shared = Some(n);
                break;
            }
        }
    }
    assert!(shared.is_some(), "no n in 73..600 reproduces both proven permutations");
}

#[test]
fn fisher_yates_is_a_valid_permutation() {
    let mut buf = [0usize; 128];
    aim::fisher_yates_idx(64, 0xDEAD_BEEF, &mut buf);
    let mut seen = [false; 64];
    for &v in &buf[..64] {
        assert!(v < 64 && !seen[v], "must be a bijection");
        seen[v] = true;
    }
}

#[test]
fn rewrite_head_in_place_when_hitpoint_fits() {
    let k = key16();
    let (body, val3, _z7, _i15, _hp) = build_body(); // zone=Body, widths [3,2,3]
    let orig = build_packet(&k, &body);
    let mut buf = vec![0u8; orig.len() + 32];
    buf[..orig.len()].copy_from_slice(&orig);
    let layout = HeaderLayout::new(0, DEFAULT_ORDER).unwrap();

    let head = [200_000i64, 3_000, 300_000]; // fits the 3/2/3-byte widths
    let n = aim::rewrite_packet(&mut buf, 0, orig.len(), &k, &layout,
        aim::ZONE_HEAD, aim::IDX15_HEAD0, Some(head), CpPlan::None, u64::MAX, 0);
    assert_eq!(n as usize, orig.len(), "in-place: length unchanged");
    assert!(crc7::verify(&buf[..n as usize]));

    let dl = layout.read_short(&buf, 0, Field::DataLen, true) as usize;
    let plain = decrypt_body(&buf, 10 + dl, &k);
    let (z7, nv3, z15, hp) = reparse(&plain);
    assert_eq!(z7, aim::ZONE_HEAD);
    assert_eq!(aim::zone_of_val3(nv3), aim::ZONE_HEAD);
    assert_eq!(nv3 & 0x00FF_FFFF, val3 & 0x00FF_FFFF, "damage/id preserved");
    assert_eq!(zigzag_decode(z15) & 0x3, 0, "idx15 head0");
    assert_eq!(hp, head, "hit point moved to head");
}

#[test]
fn rewrite_head_rebuild_when_hitpoint_grows() {
    let k = key16();
    let (body, _v3, _z7, _i15, _hp) = build_body();
    let orig = build_packet(&k, &body);
    let mut buf = vec![0u8; orig.len() + 48];
    buf[..orig.len()].copy_from_slice(&orig);
    let layout = HeaderLayout::new(0, DEFAULT_ORDER).unwrap();

    let head = [50_000_000i64, -40_000_000, 60_000_000]; // needs >3 bytes -> rebuild
    let n = aim::rewrite_packet(&mut buf, 0, orig.len(), &k, &layout,
        aim::ZONE_HEAD, aim::IDX15_HEAD0, Some(head), CpPlan::None, u64::MAX, 0);
    assert!(n > orig.len() as i32, "rebuild must grow (got {n}, was {})", orig.len());
    assert!(crc7::verify(&buf[..n as usize]));
    let dl = layout.read_short(&buf, 0, Field::DataLen, true) as usize;
    assert_eq!(dl, n as usize - 10);
    let plain = decrypt_body(&buf, n as usize, &k);
    let (z7, nv3, _z15, hp) = reparse(&plain);
    assert_eq!(z7, aim::ZONE_HEAD);
    assert_eq!(aim::zone_of_val3(nv3), aim::ZONE_HEAD);
    assert_eq!(hp, head);
}

#[test]
fn rewrite_refuses_when_nothing_to_redirect_or_layout_stale() {
    let k = key16();
    let (body, _v3, _z7, _i15, _hp) = build_body(); // zone = Body
    let orig = build_packet(&k, &body);
    let mut buf = vec![0u8; orig.len() + 16];
    buf[..orig.len()].copy_from_slice(&orig);
    let layout = HeaderLayout::new(0, DEFAULT_ORDER).unwrap();
    // target == current zone (Body) -> nothing to redirect
    assert_eq!(aim::rewrite_packet(&mut buf, 0, orig.len(), &k, &layout,
        aim::ZONE_BODY, aim::IDX15_HEAD0, None, CpPlan::None, u64::MAX, 0), -1);
    // stale layout (wrong mask) -> refuse
    let stale = HeaderLayout::new(0x33, DEFAULT_ORDER).unwrap();
    assert_eq!(aim::rewrite_packet(&mut buf, 0, orig.len(), &k, &stale,
        aim::ZONE_HEAD, aim::IDX15_HEAD0, None, CpPlan::None, u64::MAX, 0), -1);
    // and the buffer is still the untouched original after both refusals
    assert_eq!(&buf[..orig.len()], &orig[..]);
}

#[test]
fn leash_no_aim_rewrite_without_live_entitlement() {
    // A rewrite that succeeds when armed must be a no-op (packet untouched) with
    // no live profile.
    let k = key16();
    let (body, _v3, _z7, _i15, _hp) = build_body();
    let orig = build_packet(&k, &body);
    let mut buf = vec![0u8; orig.len() + 48];
    buf[..orig.len()].copy_from_slice(&orig);
    let snap = buf.clone();
    let layout = HeaderLayout::new(0, DEFAULT_ORDER).unwrap();
    let head = [200_000i64, 3_000, 300_000];
    // Unarmed + expired both refuse and leave the packet intact.
    assert_eq!(aim::rewrite_packet(&mut buf, 0, orig.len(), &k, &layout,
        aim::ZONE_HEAD, aim::IDX15_HEAD0, Some(head), CpPlan::None, 0, 100), -1);
    assert_eq!(aim::rewrite_packet(&mut buf, 0, orig.len(), &k, &layout,
        aim::ZONE_HEAD, aim::IDX15_HEAD0, Some(head), CpPlan::None, 100, 100), -1);
    assert_eq!(buf, snap, "no-op leash must leave the packet untouched");
    // Live: the rewrite goes through.
    assert_eq!(aim::rewrite_packet(&mut buf, 0, orig.len(), &k, &layout,
        aim::ZONE_HEAD, aim::IDX15_HEAD0, Some(head), CpPlan::None, 101, 100) as usize, orig.len());
}
