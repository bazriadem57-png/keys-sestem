//! Security review F4: the `(buf, off, len)` entry points must reject inputs
//! whose `off + len` would wrap `usize` — a wrap turns a `>` bounds guard into a
//! `start > end` slice panic, and with `panic="abort"` that kills the whole
//! VpnService. If any of these panicked, the test process would abort (not just
//! fail), so a green run is the assertion.

use nuvola_core::header::HeaderLayout;
use nuvola_core::{aim, chain, in_bounds, integrity, mark, packet, possync, pri};

#[test]
fn in_bounds_does_not_wrap() {
    assert!(in_bounds(0, 10, 10));
    assert!(in_bounds(4, 6, 10));
    assert!(!in_bounds(4, 7, 10));
    assert!(!in_bounds(11, 0, 10)); // off past end
    // The wrap case: off + len overflows usize; the naive `off+len>total` would
    // compute a tiny sum and wrongly pass.
    assert!(!in_bounds(usize::MAX, 5, 100));
    assert!(!in_bounds(5, usize::MAX, 100));
    assert!(!in_bounds(usize::MAX, usize::MAX, 100));
}

#[test]
fn entry_points_reject_wrapping_offsets_without_panicking() {
    let mut buf = vec![0u8; 64];
    let layout = HeaderLayout::default_layout();

    // packet
    assert!(packet::parse(&buf, usize::MAX, 32, &layout).is_none());
    assert!(!packet::reserialize(&mut buf, usize::MAX, 32));
    assert!(!packet::reserialize_header(&mut buf, usize::MAX, 32, &layout, -1, -1, -1, -1, -1));
    assert!(!packet::refresh_crc_if_match_traffic(&mut buf, usize::MAX, 32));
    assert!(!packet::is_intact_match_traffic(&buf, usize::MAX, 32));

    // integrity
    assert_eq!(integrity::seal(&mut buf, usize::MAX, 32), integrity::Seal::Foreign);
    assert_eq!(integrity::seal(&mut buf, 8, usize::MAX), integrity::Seal::Foreign);

    // possync / pri
    let mut ps = possync::PosSync::new();
    assert!(!ps.parse(&buf, usize::MAX, 32));
    assert!(!pri::decode(&buf, usize::MAX, 32, true, |_, _, _| {}));

    // mark / aim (whole-datagram rewrites) — armed live so the BOUNDS guard is
    // what rejects (not the leash), keeping this an F4 regression test.
    let key = [0u32; 4];
    assert_eq!(
        mark::rewrite_packet(&mut buf, usize::MAX, 32, &key, &layout, 0, 0, 0, false, u64::MAX, 0),
        -1
    );
    assert_eq!(
        aim::rewrite_packet(&mut buf, usize::MAX, 32, &key, &layout, 0, 0, None, aim::CpPlan::None, u64::MAX, 0),
        -1
    );

    // chain (armed profile; the bounds guard must reject before touching it)
    let prof = chain::ChainProfile {
        chain_max_len: 1400, max_records: 64, min_record_bytes: 16,
        min_record_x: 500, max_entity_id: 64, valid_until: u64::MAX,
    };
    assert!(chain::parse_with_profile(&buf, usize::MAX, 32, -1, &prof, 0).is_none());
}
