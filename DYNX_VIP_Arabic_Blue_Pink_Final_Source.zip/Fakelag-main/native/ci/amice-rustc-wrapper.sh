#!/usr/bin/env bash
# RUSTC_WRAPPER for the amice experimental obfuscation build.
#
# amice has NO crate/module/symbol filter, and rustc cannot emit the
# `llvm.global.annotations` global amice reads for per-function gating (that is a
# Clang-only construct). A global `-Zllvm-plugins=...` + `AMICE_*` switch therefore
# obfuscates EVERY function in EVERY crate — including `jni` / `obfstr` dependency
# IR, which SIGSEGVs the CF passes.
#
# The fix (see the amice research + docs/SERVER_GATED_DECODE_DESIGN.md): load the
# plugin ONLY into `nuvola_core`'s rustc invocation. `nuvola_core` has zero
# runtime dependencies, so the CF passes then only ever see dependency-free IR and
# never touch jni/obfstr. Everything else compiles with a plain rustc. The
# `AMICE_*` pass switches can stay in the global env — they only act where the
# plugin is actually loaded, i.e. nuvola_core.
#
# Cargo invokes this as:  $0 <path-to-rustc> <rustc args...>
set -euo pipefail

rustc="$1"
shift

crate=""
prev=""
for arg in "$@"; do
  if [ "$prev" = "--crate-name" ]; then
    crate="$arg"
    break
  fi
  prev="$arg"
done

# -Zlocation-detail=none redacts panic `Location` file/line for EVERY crate this
# nightly build compiles. Without it, panic sites (unwrap/index/slice) in
# nuvola_core emit their source paths — "nuvola-core/src/{tea,crc7,chain,...}.rs"
# — straight into .rodata, xref'd from each function, handing a reverser a
# name->function map that bypasses all the CF passes (2026-09-18 binary audit,
# pivot #2). Applied here (not via RUSTFLAGS) so it also runs through the QEMU
# correctness gate and never touches the stable smoke build, which does not use
# this wrapper. panic=abort is already set, so location metadata is pure liability.
common_hardening="-Z location-detail=none"

if [ -n "${AMICE_PLUGIN:-}" ] && [ "$crate" = "nuvola_vmp" ]; then
  # nuvola_vmp holds ONLY the two tiny QQ-TEA Feistel round cores. Give them
  # instruction-level VMP and NOTHING else: the whole-crate global VM_VIRTUALIZE
  # miscompiled (gate run 35398175805), so this run cleanly isolates "does VMP
  # translate THESE functions correctly?" — the exact open question. Stacking VMP
  # under the CF/MBA passes would confound that verdict, so unset them here (they
  # still apply everywhere else via the global env). VM_EMIT_MARKERS stays unset
  # (it would print the readable AMICEVMP magic + bytecode symbols).
  unset AMICE_FLATTEN AMICE_BOGUS_CONTROL_FLOW AMICE_INDIRECT_BRANCH \
        AMICE_INDIRECT_BRANCH_FLAGS AMICE_SPLIT_BASIC_BLOCK AMICE_INDIRECT_CALL \
        AMICE_MBA AMICE_ALIAS_ACCESS AMICE_DELAY_OFFSET_LOADING AMICE_LOWER_SWITCH \
        AMICE_VM_FLATTEN AMICE_SHUFFLE_BLOCKS AMICE_SHUFFLE_BLOCKS_FLAGS \
        AMICE_BASIC_BLOCK_OUTLINING AMICE_BASIC_BLOCK_OUTLINING_MAX_EXTRACTOR_SIZE
  export AMICE_VM_VIRTUALIZE=true
  echo "amice-wrapper: VM_VIRTUALIZE-only into nuvola_vmp rustc" >&2
  exec "$rustc" "$@" $common_hardening -Z llvm-plugins="$AMICE_PLUGIN"
elif [ -n "${AMICE_PLUGIN:-}" ] && [ "$crate" = "nuvola_core" ]; then
  echo "amice-wrapper: loading plugin into nuvola_core rustc" >&2
  exec "$rustc" "$@" $common_hardening -Z llvm-plugins="$AMICE_PLUGIN"
else
  exec "$rustc" "$@" $common_hardening
fi
