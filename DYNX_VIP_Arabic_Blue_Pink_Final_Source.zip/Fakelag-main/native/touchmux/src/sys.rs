//! The ONLY module in this crate that contains `unsafe`.
//!
//! Every ioctl, every raw write, the process-wide fds and the signal handler
//! live here behind checked, safe signatures. Auditing the unsafe surface of
//! this daemon is now a file read rather than a codebase search.
//!
//! <b>Two bugs this module exists to make impossible.</b> The previous code
//! discarded the result of `write()` on the uinput fd — which is opened
//! `O_NONBLOCK`, so a full buffer dropped events with no diagnostic anywhere,
//! indistinguishable from the feature not firing. And the device-probe ioctls
//! were unchecked, so a permission error left the bitmask arrays zeroed and the
//! panel was reported "not a touchscreen" exactly as if it were absent. Both
//! are the silent-skip-one-layer-upstream shape this project keeps relearning.

use core::sync::atomic::{AtomicBool, AtomicI32, Ordering};

// ---- ioctl number encoding (asm-generic, same on aarch64) --------------------
pub(crate) const IOC_NONE: u32 = 0;
pub(crate) const IOC_WRITE: u32 = 1;
pub(crate) const IOC_READ: u32 = 2;
pub(crate) const fn ioc(dir: u32, typ: u32, nr: u32, size: u32) -> u32 {
    (dir << 30) | (typ << 8) | nr | (size << 16)
}
pub(crate) const T_E: u32 = b'E' as u32;
pub(crate) const T_U: u32 = b'U' as u32;

pub(crate) const EVIOCGRAB: u32 = ioc(IOC_WRITE, T_E, 0x90, 4); // _IOW('E',0x90,int)
pub(crate) const UI_DEV_CREATE: u32 = ioc(IOC_NONE, T_U, 1, 0);
pub(crate) const UI_DEV_DESTROY: u32 = ioc(IOC_NONE, T_U, 2, 0);
pub(crate) const UI_SET_EVBIT: u32 = ioc(IOC_WRITE, T_U, 100, 4);
pub(crate) const UI_SET_KEYBIT: u32 = ioc(IOC_WRITE, T_U, 101, 4);
pub(crate) const UI_SET_ABSBIT: u32 = ioc(IOC_WRITE, T_U, 103, 4);
pub(crate) const UI_SET_PROPBIT: u32 = ioc(IOC_WRITE, T_U, 110, 4);

pub(crate) fn eviocgid() -> u32 {
    ioc(IOC_READ, T_E, 0x02, core::mem::size_of::<libc::input_id>() as u32)
}
pub(crate) fn eviocgname(len: u32) -> u32 { ioc(IOC_READ, T_E, 0x06, len) }
pub(crate) fn eviocgprop(len: u32) -> u32 { ioc(IOC_READ, T_E, 0x09, len) }
pub(crate) fn eviocgbit(ev: u32, len: u32) -> u32 { ioc(IOC_READ, T_E, 0x20 + ev, len) }
pub(crate) fn eviocgabs(abs: u32) -> u32 {
    ioc(IOC_READ, T_E, 0x40 + abs, core::mem::size_of::<libc::input_absinfo>() as u32)
}
pub(crate) fn eviocgmtslots(len: u32) -> u32 { ioc(IOC_READ, T_E, 0x0a, len) }
pub(crate) fn ui_dev_setup() -> u32 {
    ioc(IOC_WRITE, T_U, 3, core::mem::size_of::<libc::uinput_setup>() as u32)
}
pub(crate) fn ui_abs_setup() -> u32 {
    ioc(IOC_WRITE, T_U, 4, core::mem::size_of::<libc::uinput_abs_setup>() as u32)
}


// ---- globals the signal handler / release path need -------------------------
pub(crate) static REAL_FD: AtomicI32 = AtomicI32::new(-1);
pub(crate) static UINPUT_FD: AtomicI32 = AtomicI32::new(-1);
pub(crate) static GRABBED: AtomicBool = AtomicBool::new(false);

pub(crate) fn now_ms() -> i64 {
    let mut ts = libc::timespec { tv_sec: 0, tv_nsec: 0 };
    unsafe { libc::clock_gettime(libc::CLOCK_MONOTONIC, &mut ts) };
    ts.tv_sec as i64 * 1000 + ts.tv_nsec as i64 / 1_000_000
}

pub(crate) fn release_grab() {
    if GRABBED.swap(false, Ordering::SeqCst) {
        let fd = REAL_FD.load(Ordering::SeqCst);
        if fd >= 0 {
            unsafe { libc::ioctl(fd, EVIOCGRAB as _, 0) };
        }
    }
}

pub(crate) fn cleanup() {
    release_grab();
    let uf = UINPUT_FD.swap(-1, Ordering::SeqCst);
    if uf >= 0 {
        unsafe {
            libc::ioctl(uf, UI_DEV_DESTROY as _);
            libc::close(uf);
        }
    }
    let rf = REAL_FD.swap(-1, Ordering::SeqCst);
    if rf >= 0 {
        unsafe { libc::close(rf) };
    }
}

extern "C" fn on_signal(_sig: libc::c_int) {
    // Async-signal path: release the grab + tear down uinput so the panel is
    // never left silenced, then hard-exit.
    release_grab();
    let uf = UINPUT_FD.load(Ordering::SeqCst);
    if uf >= 0 {
        unsafe { libc::ioctl(uf, UI_DEV_DESTROY as _); }
    }
    unsafe { libc::_exit(0) };
}

#[inline]
pub(crate) fn test_bit(arr: &[u8], bit: usize) -> bool {
    let b = bit / 8;
    b < arr.len() && (arr[b] >> (bit % 8)) & 1 != 0
}

// ---- FFI helpers ------------------------------------------------------------
pub(crate) fn open_ro_nonblock(path: &str) -> i32 {
    let c = std::ffi::CString::new(path).unwrap();
    unsafe { libc::open(c.as_ptr(), libc::O_RDONLY | libc::O_NONBLOCK) }
}

/// Count of events that did not reach the clone.
///
/// The uinput fd is opened `O_WRONLY | O_NONBLOCK`, so a full kernel buffer
/// makes `write` return `EAGAIN` rather than blocking. The previous code
/// discarded the return value entirely: events vanished with no diagnostic
/// anywhere, which is indistinguishable from the feature not firing at all.
/// This is the same silent-skip-one-layer-upstream shape that has cost this
/// project several debugging sessions, so it is counted and reported rather
/// than assumed not to happen.
pub(crate) static DROPPED: AtomicI32 = AtomicI32::new(0);

pub(crate) fn emit(fd: i32, type_: u16, code: u16, value: i32) {
    let ev = libc::input_event {
        time: libc::timeval { tv_sec: 0, tv_usec: 0 },
        type_,
        code,
        value,
    };
    // SAFETY: a full, aligned, live `input_event` is written by value; the
    // length is exactly its size and `fd` is validated by the kernel.
    let n = unsafe {
        libc::write(
            fd,
            &ev as *const libc::input_event as *const libc::c_void,
            core::mem::size_of::<libc::input_event>(),
        )
    };
    if n != core::mem::size_of::<libc::input_event>() as isize {
        let prev = DROPPED.fetch_add(1, Ordering::Relaxed);
        // Loud on the first, then every 256th: a flood must not become the
        // thing that starves the pipe it is reporting on.
        if prev == 0 || prev % 256 == 0 {
            println!("EMIT_DROPPED n={} errno={} total={}", n, errno(), prev + 1);
        }
    }
}


pub(crate) fn errno() -> i32 {
    std::io::Error::last_os_error().raw_os_error().unwrap_or(0)
}

pub(crate) fn install_signal_handlers() {
    unsafe {
        libc::signal(libc::SIGTERM, on_signal as *const () as libc::sighandler_t);
        libc::signal(libc::SIGINT, on_signal as *const () as libc::sighandler_t);
        libc::signal(libc::SIGHUP, on_signal as *const () as libc::sighandler_t);
        libc::signal(libc::SIGPIPE, libc::SIG_IGN);
    }
}
