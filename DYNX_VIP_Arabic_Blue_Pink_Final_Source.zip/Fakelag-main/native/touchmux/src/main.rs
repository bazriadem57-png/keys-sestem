//! nvmux — touch multiplexer (Rust port of native/touchmux/nvmux.c).
//!
//! THE PROBLEM (docs/EXTERNAL_TAP_COEXISTENCE.md): Android's InputDispatcher
//! allows one input DEVICE active per window. A Shizuku-injected event is a
//! second device (id -1), so it and the user's finger cancel each other — you
//! cannot walk and aim at once.
//!
//! THE FIX: EVIOCGRAB the real touchscreen (its events then reach only us) and
//! re-emit BOTH the user's contacts AND one synthetic contact through a single
//! /dev/uinput clone that carries the panel's identity. Android sees ONE device
//! with many pointers — nothing cancels. Runs as the ADB-shell uid via Shizuku;
//! NO root.
//!
//! Control is over STDIN (Shizuku's binder pipe; an abstract socket is an
//! SELinux connectto denial for an app→shell domain). Line protocol:
//!   S <cx_px> <cy_px> <r_px> <w> <h>   start/aim the self-driven circle swipe
//!   U                                  lift the synthetic finger + release panel
//!   P                                  heartbeat ping
//!   Q                                  quit
//! stdin EOF (app died) => release + exit. The circle itself is generated here
//! (nuvola_core::geom) from the px centre/radius/screen ESP passes in.
//!
//! --selftest [secs] : no stdin; grab + self-drive a circle in the look region.
//!
//! SAFETY: heartbeat lease (~1.5s), VOLUME-DOWN escape, release on every exit
//! path + on fd close, slot discipline (no cross-contamination), and re-inject
//! of any finger already down at grab time (walk-then-aim needs no lift).


mod clone;
mod consts;
mod device;
mod mux;
mod run;
mod sys;

use device::{open_touchscreen, open_volume};
use clone::setup_clone;
use run::{run_selftest, run_stdin};
use sys::{cleanup, install_signal_handlers, REAL_FD};
use core::sync::atomic::Ordering;

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mut selftest = false;
    let mut self_secs: i64 = 20;
    for a in &args[1..] {
        if a == "--selftest" {
            selftest = true;
        } else if selftest {
            if let Ok(n) = a.parse::<i64>() {
                if n > 0 {
                    self_secs = n;
                }
            }
        }
    }

    install_signal_handlers();

    let (real_fd, path) = match open_touchscreen() {
        Some(v) => v,
        None => {
            eprintln!("no touchscreen found");
            std::process::exit(1);
        }
    };
    REAL_FD.store(real_fd, Ordering::SeqCst);
    println!("panel={path}");

    let vol_fd = open_volume();
    println!("volume={}", if vol_fd >= 0 { "found" } else { "none" });

    let mut mux = match setup_clone(real_fd) {
        Some(m) => m,
        None => {
            cleanup();
            std::process::exit(1);
        }
    };
    mux.vol_fd = vol_fd;

    if selftest {
        run_selftest(&mut mux, self_secs);
        cleanup();
        println!("selftest done");
        return;
    }

    run_stdin(&mut mux);
    cleanup();
}

