//! The multiplexer: the panel's event stream in, the clone's out, and the
//! rewriting in between.

use crate::consts::*;
use crate::sys::{emit, eviocgmtslots, EVIOCGRAB, GRABBED};
use core::sync::atomic::Ordering;
use nuvola_core::geom;

pub(crate) struct Mux {
    pub(crate) real_fd: i32,
    pub(crate) uinput_fd: i32,
    pub(crate) vol_fd: i32,
    pub(crate) max_slot: i32,
    pub(crate) synth_slot: i32,
    pub(crate) cur_slot: i32,
    pub(crate) last_emit_slot: i32,
    pub(crate) tracking: [i64; MAX_SLOTS],
    pub(crate) synth_down: bool,
    pub(crate) last_btn: i32,
    pub(crate) abs_x: libc::input_absinfo,
    pub(crate) abs_y: libc::input_absinfo,
    /// Last reported raw position of each REAL contact, panel units.
    pub(crate) real_x: [i32; MAX_SLOTS],
    pub(crate) real_y: [i32; MAX_SLOTS],
    /// Slots whose real contact we have cancelled. Their events are dropped
    /// until the finger genuinely lifts, so the game sees one clean release
    /// rather than a contact that resurrects on the next move.
    pub(crate) suppressed: [bool; MAX_SLOTS],
    /// Slots that went down during the frame being assembled.
    pub(crate) pending_down: u64,
    /// Slots that went down in the LAST completed frame, for the caller.
    pub(crate) new_down: u64,
    /// A grab was asked for while a finger was down; take it when the screen
    /// is next empty.
    pub(crate) grab_pending: bool,
    /// True between a forwarded event and its SYN_REPORT.
    ///
    /// Injecting inside that window splits the panel's frame in two and
    /// delivers a half-frame to InputReader, so the steering tick waits for a
    /// boundary.
    pub(crate) mid_frame: bool,
    /// Last position we actually got past the kernel for the steered slot.
    pub(crate) steer_last_x: i32,
    pub(crate) steer_last_y: i32,
    /// Slot whose REAL contact we are steering, or -1.
    ///
    /// Steering means the player's own finger is the one that moves: we hold
    /// its true position as a base and emit base+offset in its place. The game
    /// sees one contact travelling, which is exactly what a player dragging
    /// looks like — and, scoped, is the only thing that turns the view at all.
    /// A second synthetic contact does not: the scoped look is driven by the
    /// contact that is already down, so an extra finger is simply ignored.
    pub(crate) steer_slot: i32,
}

pub(crate) fn zero_absinfo() -> libc::input_absinfo {
    libc::input_absinfo { value: 0, minimum: 0, maximum: 0, fuzz: 0, flat: 0, resolution: 0 }
}


impl Mux {
    pub(crate) fn set_slot(&mut self, s: i32) {
        if s != self.last_emit_slot {
            emit(self.uinput_fd, EV_ABS, ABS_MT_SLOT, s);
            self.last_emit_slot = s;
        }
    }

    pub(crate) fn any_down(&self) -> bool {
        if self.synth_down {
            return true;
        }
        for i in 0..=(self.max_slot as usize).min(MAX_SLOTS - 1) {
            if self.tracking[i] != -1 {
                return true;
            }
        }
        false
    }

    pub(crate) fn sync_btn(&mut self) {
        let b = if self.any_down() { 1 } else { 0 };
        if b != self.last_btn {
            emit(self.uinput_fd, EV_KEY, BTN_TOUCH, b);
            self.last_btn = b;
        }
    }

    pub(crate) fn scale(n: i32, ai: &libc::input_absinfo) -> i32 {
        let span = ai.maximum as i64 - ai.minimum as i64;
        let mut v = ai.minimum as i64 + (span * n as i64) / 65535;
        if v < ai.minimum as i64 {
            v = ai.minimum as i64;
        }
        if v > ai.maximum as i64 {
            v = ai.maximum as i64;
        }
        v as i32
    }

    /// Set/move/lift the synthetic finger. `xn`/`yn` are normalised 0..=65535.
    pub(crate) fn synth_set(&mut self, down: bool, xn: i32, yn: i32) {
        let sx = Self::scale(xn, &self.abs_x);
        let sy = Self::scale(yn, &self.abs_y);
        self.set_slot(self.synth_slot);
        if down && !self.synth_down {
            emit(self.uinput_fd, EV_ABS, ABS_MT_TRACKING_ID, SYNTH_TRACK);
            self.tracking[self.synth_slot as usize] = SYNTH_TRACK as i64;
            self.synth_down = true;
        }
        if down {
            emit(self.uinput_fd, EV_ABS, ABS_MT_POSITION_X, sx);
            emit(self.uinput_fd, EV_ABS, ABS_MT_POSITION_Y, sy);
        } else if self.synth_down {
            emit(self.uinput_fd, EV_ABS, ABS_MT_TRACKING_ID, -1);
            self.tracking[self.synth_slot as usize] = -1;
            self.synth_down = false;
        }
        self.sync_btn();
        emit(self.uinput_fd, EV_SYN, SYN_REPORT, 0);
    }

    /// Forward one real panel event to the clone, deriving BTN_TOUCH and keeping
    /// strict slot discipline (re-select the slot before every attribute block).
    pub(crate) fn forward(&mut self, ev: &libc::input_event) {
        if ev.type_ == EV_SYN && ev.code == SYN_REPORT {
            // A contact's TRACKING_ID and its first position can arrive in
            // either order inside one frame, so "went down at (x,y)" is only
            // answerable at the frame boundary. Publishing here means the
            // caller always has a position to test against.
            self.new_down |= self.pending_down;
            self.pending_down = 0;
            self.sync_btn();
            emit(self.uinput_fd, EV_SYN, SYN_REPORT, 0);
            self.mid_frame = false;
            return;
        }
        if ev.type_ == EV_KEY && ev.code == BTN_TOUCH {
            return; // derived, not mirrored
        }
        if ev.type_ == EV_ABS {
            if ev.code == ABS_MT_SLOT {
                let mut s = ev.value;
                if s < 0 {
                    s = 0;
                }
                if s >= MAX_SLOTS as i32 {
                    s = MAX_SLOTS as i32 - 1;
                }
                self.cur_slot = s;
                if s == self.synth_slot {
                    return; // never let a real contact use our slot
                }
                self.set_slot(s);
                return;
            }
            if self.cur_slot == self.synth_slot {
                return; // stray attr for our slot
            }
            let slot = self.cur_slot as usize;

            // Record BEFORE any suppression check: the position of a contact we
            // are about to cancel is exactly what decided to cancel it.
            if ev.code == ABS_MT_POSITION_X {
                self.real_x[slot] = ev.value;
            } else if ev.code == ABS_MT_POSITION_Y {
                self.real_y[slot] = ev.value;
            }

            // While steering this slot we publish its position ourselves, on a
            // fixed tick. Forwarding the raw report as well would fight our
            // offset, and a finger held perfectly still emits no position at
            // all — which is why the offset has to be pushed rather than
            // applied to a passing event.
            if self.steer_slot == self.cur_slot
                && (ev.code == ABS_MT_POSITION_X || ev.code == ABS_MT_POSITION_Y)
            {
                return;
            }

            if ev.code == ABS_MT_TRACKING_ID {
                if ev.value < 0 {
                    // The finger genuinely lifted. If we had cancelled this
                    // contact we already emitted its -1, so swallow this one and
                    // stop suppressing -- the slot is free again.
                    self.tracking[slot] = -1;
                    if self.steer_slot == slot as i32 {
                        // The finger we were steering is gone. Anything else
                        // would keep pushing a position for a contact the game
                        // has already released.
                        self.steer_slot = -1;
                    }
                    if self.suppressed[slot] {
                        self.suppressed[slot] = false;
                        return;
                    }
                } else {
                    if self.suppressed[slot] {
                        return;
                    }
                    self.tracking[slot] = ev.value as i64;
                    self.pending_down |= 1u64 << slot;
                }
            } else if self.suppressed[slot] {
                return;
            }

            self.set_slot(self.cur_slot);
            emit(self.uinput_fd, EV_ABS, ev.code, ev.value);
            self.mid_frame = true;
            return;
        }
        emit(self.uinput_fd, ev.type_, ev.code, ev.value);
        self.mid_frame = true;
    }

    /// Takes and clears the set of slots that went down since the last call.
    pub(crate) fn take_new_downs(&mut self) -> u64 {
        let m = self.new_down;
        self.new_down = 0;
        m
    }

    /// A real contact's position in SCREEN px, from its raw panel units.
    pub(crate) fn real_px(&self, slot: usize, sw: u32, sh: u32) -> (f32, f32) {
        (
            Self::unscale(self.real_x[slot], &self.abs_x) * sw as f32,
            Self::unscale(self.real_y[slot], &self.abs_y) * sh as f32,
        )
    }

    /// Panel units -> 0.0..=1.0. The inverse of `scale`, which the synthetic
    /// finger uses, so both directions agree on what "the middle" means.
    pub(crate) fn unscale(v: i32, ai: &libc::input_absinfo) -> f32 {
        let span = ai.maximum as f32 - ai.minimum as f32;
        if span.abs() < 1.0 {
            return 0.0;
        }
        ((v as f32 - ai.minimum as f32) / span).clamp(0.0, 1.0)
    }

    /// Publish the steered contact at its true position plus `off` px.
    ///
    /// Emitted on our own tick, not in response to a real event: a finger held
    /// still reports nothing, and that is precisely the case this exists for.
    pub(crate) fn emit_steer(&mut self, off_x: f32, off_y: f32, sw: u32, sh: u32) -> bool {
        let s = self.steer_slot;
        if s < 0 || s as usize >= MAX_SLOTS {
            return false;
        }
        // Never inside a panel frame: that would split it and hand InputReader
        // half a frame.
        if self.mid_frame {
            return false;
        }
        let slot = s as usize;
        let (bx, by) = self.real_px(slot, sw, sh);
        let nx = geom::norm(bx + off_x, sw) as i32;
        let ny = geom::norm(by + off_y, sh) as i32;
        let px = Self::scale(nx, &self.abs_x);
        let py = Self::scale(ny, &self.abs_y);

        // The kernel drops a value identical to the last one it accepted, and
        // a frame with nothing left in it is discarded whole. Emitting the
        // same coordinate twice is therefore not a no-op that costs a syscall
        // -- it is an invisible failure. Skip it ourselves so the caller knows.
        if px == self.steer_last_x && py == self.steer_last_y {
            return false;
        }
        self.steer_last_x = px;
        self.steer_last_y = py;

        let panel_slot = self.cur_slot;
        self.set_slot(s);
        emit(self.uinput_fd, EV_ABS, ABS_MT_POSITION_X, px);
        emit(self.uinput_fd, EV_ABS, ABS_MT_POSITION_Y, py);
        emit(self.uinput_fd, EV_SYN, SYN_REPORT, 0);

        // ---- THE INVARIANT THIS WHOLE FILE TURNS ON ----
        // ABS_MT_SLOT is device STATE, not an event: the kernel stages it and
        // only materialises it when a later per-slot value changes. So the
        // panel's own stream OMITS ABS_MT_SLOT whenever the slot is unchanged
        // -- across SYN_REPORT boundaries too. That stream is only replayable
        // into a device whose slot pointer follows the same trajectory.
        //
        // Writing our own ABS_MT_SLOT out of band breaks that: the next group
        // of panel events for some other slot arrives with no slot prefix and
        // the kernel applies it to OUR slot. One finger teleports, another
        // freezes. It self-heals at the panel's next explicit slot change,
        // which is why it read as intermittent -- and why it got far worse
        // scoped, where two or three contacts are down and the panel is
        // alternating slots constantly.
        //
        // Putting the staged slot back costs nothing (a lone ABS_MT_SLOT emits
        // no event) and makes the injection invisible to the replay.
        self.set_slot(panel_slot);
        true
    }

    /// Cancel a real contact: emit its lift now and drop its events until the
    /// finger actually leaves the glass.
    ///
    /// Currently unused — steering superseded it for the test — but kept
    /// because it is the abort primitive the live trigger needs: dropping the
    /// player's press is how a swipe gets called off the instant they move.
    #[allow(dead_code)]
    pub(crate) fn cancel_real(&mut self, slot: usize) {
        if slot >= MAX_SLOTS || slot as i32 == self.synth_slot {
            return;
        }
        if self.tracking[slot] != -1 {
            self.set_slot(slot as i32);
            emit(self.uinput_fd, EV_ABS, ABS_MT_TRACKING_ID, -1);
            self.tracking[slot] = -1;
            self.sync_btn();
            emit(self.uinput_fd, EV_SYN, SYN_REPORT, 0);
        }
        self.suppressed[slot] = true;
    }

    pub(crate) fn drain_real(&mut self, forward: bool) {
        let mut ev = libc::input_event {
            time: libc::timeval { tv_sec: 0, tv_usec: 0 },
            type_: 0,
            code: 0,
            value: 0,
        };
        let sz = core::mem::size_of::<libc::input_event>();
        loop {
            let n = unsafe {
                libc::read(self.real_fd, &mut ev as *mut _ as *mut libc::c_void, sz)
            };
            if n != sz as isize {
                break;
            }
            if forward {
                self.forward(&ev);
            } else {
                // Pre-grab: track slot/contacts so grab_resync/any_down are right.
                if ev.type_ == EV_ABS && ev.code == ABS_MT_SLOT && ev.value < MAX_SLOTS as i32 {
                    self.cur_slot = ev.value.max(0);
                }
                if ev.type_ == EV_ABS
                    && ev.code == ABS_MT_TRACKING_ID
                    && self.cur_slot < MAX_SLOTS as i32
                    && self.cur_slot != self.synth_slot
                {
                    self.tracking[self.cur_slot as usize] = ev.value as i64;
                }
            }
        }
    }

    /// Re-inject contacts already down at grab time (the change-driven protocol
    /// never resends them), so walk-then-aim needs no lift.
    pub(crate) fn grab_resync(&mut self) {
        let nslots = ((self.max_slot + 1) as usize).min(MAX_SLOTS);
        let mut tid = vec![0i32; nslots + 1];
        let mut xx = vec![0i32; nslots + 1];
        let mut yy = vec![0i32; nslots + 1];
        tid[0] = ABS_MT_TRACKING_ID as i32;
        xx[0] = ABS_MT_POSITION_X as i32;
        yy[0] = ABS_MT_POSITION_Y as i32;
        let bytes = ((nslots + 1) * 4) as u32;
        let r = unsafe { libc::ioctl(self.real_fd, eviocgmtslots(bytes) as _, tid.as_mut_ptr()) };
        if r < 0 {
            return;
        }
        unsafe {
            libc::ioctl(self.real_fd, eviocgmtslots(bytes) as _, xx.as_mut_ptr());
            libc::ioctl(self.real_fd, eviocgmtslots(bytes) as _, yy.as_mut_ptr());
        }
        let mut any = false;
        for i in 0..nslots {
            if i as i32 == self.synth_slot {
                continue;
            }
            let id = tid[1 + i];
            if id != -1 {
                self.set_slot(i as i32);
                emit(self.uinput_fd, EV_ABS, ABS_MT_TRACKING_ID, id);
                emit(self.uinput_fd, EV_ABS, ABS_MT_POSITION_X, xx[1 + i]);
                emit(self.uinput_fd, EV_ABS, ABS_MT_POSITION_Y, yy[1 + i]);
                self.tracking[i] = id as i64;
                // Record the position too. Without this, a contact carried
                // across the grab has no known base, and steering it would
                // publish base(0,0)+offset -- slamming the user's finger to the
                // top-left corner. The kernel hands us the real value here and
                // it is the only chance to get it before the finger moves.
                self.real_x[i] = xx[1 + i];
                self.real_y[i] = yy[1 + i];
                any = true;
            }
        }
        if any {
            self.sync_btn();
            emit(self.uinput_fd, EV_SYN, SYN_REPORT, 0);
        }
    }

    /// Grab the panel — but NEVER while a finger is already down.
    ///
    /// `EVIOCGRAB` takes the real device away from the framework mid-gesture.
    /// The framework does not get an "up" for the contacts it is already
    /// tracking on that device, because the events that would have carried it
    /// now come to us instead — so it keeps a **stuck pointer**, frozen
    /// wherever the finger was at the instant of the grab, forever. The same
    /// finger then reappears as a NEW pointer on the clone.
    ///
    /// That is two pointers: one pinned at the touch-down point, one following
    /// the finger. It is visible directly in `pointer_location`, it is why an
    /// overlay button under the frozen pointer got dragged around, and it is
    /// almost certainly why the game ignored the steering — a look bound to the
    /// first pointer down is bound to the one that can never move again.
    ///
    /// So the grab waits for an empty screen. There is no way to hand a
    /// half-owned gesture over cleanly; the only fix is not to start one.
    pub(crate) fn do_grab(&mut self) -> bool {
        if GRABBED.load(Ordering::SeqCst) {
            return true;
        }
        if self.any_down() {
            if !self.grab_pending {
                self.grab_pending = true;
                println!("GRAB deferred: finger down");
            }
            return false;
        }
        self.grab_pending = false;
        let r = unsafe { libc::ioctl(self.real_fd, EVIOCGRAB as _, 1) };
        if r != 0 {
            eprintln!("EVIOCGRAB failed");
            return false;
        }
        GRABBED.store(true, Ordering::SeqCst);
        self.last_emit_slot = -999; // force a fresh ABS_MT_SLOT on the first contact
        self.grab_resync();
        println!("grabbed");
        true
    }
}
