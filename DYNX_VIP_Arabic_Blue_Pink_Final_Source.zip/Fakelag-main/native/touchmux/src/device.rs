//! Finding the panel and the volume keys, and reading the volume escape hatch.

use crate::consts::*;
use crate::sys::{eviocgbit, eviocgprop, open_ro_nonblock, test_bit};

// ---- device discovery -------------------------------------------------------
pub(crate) fn open_touchscreen() -> Option<(i32, String)> {
    for i in 0..32 {
        let path = format!("/dev/input/event{i}");
        let fd = open_ro_nonblock(&path);
        if fd < 0 {
            continue;
        }
        let mut ev = [0u8; (EV_MAX as usize / 8) + 1];
        let mut ab = [0u8; (ABS_MAX as usize / 8) + 1];
        let mut ky = [0u8; (KEY_MAX as usize / 8) + 1];
        let mut pr = [0u8; (INPUT_PROP_MAX as usize / 8) + 1];
        // CHECKED. Unchecked, a permission error left every bitmask zeroed,
        // test_bit returned false for all four, and the device was skipped as
        // "not a touchscreen" -- producing `no touchscreen found` for a
        // permissions problem exactly as readily as for an absent panel. The
        // two need different fixes and looked identical.
        let probed = unsafe {
            libc::ioctl(fd, eviocgbit(0, ev.len() as u32) as _, ev.as_mut_ptr()) >= 0
                && libc::ioctl(fd, eviocgbit(EV_ABS as u32, ab.len() as u32) as _,
                               ab.as_mut_ptr()) >= 0
                && libc::ioctl(fd, eviocgbit(EV_KEY as u32, ky.len() as u32) as _,
                               ky.as_mut_ptr()) >= 0
                && libc::ioctl(fd, eviocgprop(pr.len() as u32) as _, pr.as_mut_ptr()) >= 0
        };
        if !probed {
            println!("PROBE_FAILED {path} errno={}", crate::sys::errno());
            unsafe { libc::close(fd) };
            continue;
        }
        if test_bit(&ev, EV_ABS as usize)
            && test_bit(&ab, ABS_MT_POSITION_X as usize)
            && test_bit(&ky, BTN_TOUCH as usize)
            && test_bit(&pr, INPUT_PROP_DIRECT as usize)
        {
            return Some((fd, path));
        }
        unsafe { libc::close(fd) };
    }
    None
}

pub(crate) fn open_volume() -> i32 {
    for i in 0..32 {
        let path = format!("/dev/input/event{i}");
        let fd = open_ro_nonblock(&path);
        if fd < 0 {
            continue;
        }
        let mut ky = [0u8; (KEY_MAX as usize / 8) + 1];
        let mut ab = [0u8; (ABS_MAX as usize / 8) + 1];
        unsafe {
            libc::ioctl(fd, eviocgbit(EV_KEY as u32, ky.len() as u32) as _, ky.as_mut_ptr());
            libc::ioctl(fd, eviocgbit(EV_ABS as u32, ab.len() as u32) as _, ab.as_mut_ptr());
        }
        if test_bit(&ky, KEY_VOLUMEDOWN as usize) && !test_bit(&ab, ABS_MT_POSITION_X as usize) {
            return fd;
        }
        unsafe { libc::close(fd) };
    }
    -1
}

/// All mutable multiplexer state (the C globals), so the merge helpers are
/// straightforward methods rather than free functions over statics.

pub(crate) fn check_volume(vfd: i32) -> bool {
    if vfd < 0 {
        return false;
    }
    let mut ev = libc::input_event {
        time: libc::timeval { tv_sec: 0, tv_usec: 0 },
        type_: 0,
        code: 0,
        value: 0,
    };
    let sz = core::mem::size_of::<libc::input_event>();
    loop {
        let n = unsafe { libc::read(vfd, &mut ev as *mut _ as *mut libc::c_void, sz) };
        if n != sz as isize {
            break;
        }
        if ev.type_ == EV_KEY && ev.code == KEY_VOLUMEDOWN && ev.value == 1 {
            return true;
        }
    }
    false
}
