//! The run loops: the stdin-driven production path and the standalone selftest.

use crate::consts::*;
use crate::device::check_volume;
use crate::mux::Mux;
use crate::sys::{errno, now_ms, release_grab, GRABBED};
use core::sync::atomic::Ordering;
use nuvola_core::geom;
use nvmux_logic::{parse_line, Steer, Swipe, TestSpin, STEER_HOLD_MS};

pub(crate) fn run_selftest(mux: &mut Mux, secs: i64) {
    if !mux.do_grab() {
        return;
    }
    let (w, h) = (1080u32, 2340u32);
    let (cx, cy) = (w as f32 * 0.72, h as f32 * 0.45);
    let r = (w.min(h) as f32) * 0.13;
    let mut angle = 0.0f32;
    let end = now_ms() + secs * 1000;
    let (x0, y0) = geom::circle_point_norm(cx, cy, r, 0.0, w, h);
    mux.synth_set(true, x0 as i32, y0 as i32);
    while now_ms() < end {
        mux.drain_real(true);
        if check_volume(mux.vol_fd) {
            println!("volume-down: bailing");
            return;
        }
        angle = geom::advance_angle(angle, STEP_RAD);
        let (xn, yn) = geom::circle_point_norm(cx, cy, r, angle, w, h);
        mux.synth_set(true, xn as i32, yn as i32);
        unsafe { libc::usleep(16 * 1000) };
    }
    mux.synth_set(false, 0, 0);
}

/// Production: stdin-driven. `S cx cy r w h` starts/aims the self-driven circle.
pub(crate) fn run_stdin(mux: &mut Mux) {
    println!("ready");
    // Self-driven swipe params (px) + normalised centre/radius resolution.
    let mut swiping = false;
    let mut aim = Swipe::idle();
    let mut test = TestSpin::idle();
    let mut steer = Steer::idle();
    let mut steer_idle_since: i64 = 0;
    let (mut cx, mut cy, mut r) = (0.0f32, 0.0f32, 0.0f32);
    let (mut sw, mut sh) = (1080u32, 2340u32);
    let mut angle = 0.0f32;
    let mut release_pending = false;
    let mut last_ping = now_ms();
    let mut last_tick = now_ms();
    let mut linebuf: Vec<u8> = Vec::with_capacity(64);

    loop {
        let mut pfds = [
            libc::pollfd { fd: mux.real_fd, events: libc::POLLIN, revents: 0 },
            libc::pollfd { fd: 0, events: libc::POLLIN, revents: 0 },
            libc::pollfd { fd: mux.vol_fd, events: libc::POLLIN, revents: 0 },
        ];
        let nf = if mux.vol_fd >= 0 { 3 } else { 2 };
        let timeout = if swiping || test.active || aim.active || steer.active { TICK_MS } else { 200 };
        let pr = unsafe { libc::poll(pfds.as_mut_ptr(), nf as libc::nfds_t, timeout as i32) };
        if pr < 0 && errno() != libc::EINTR {
            break;
        }

        if mux.vol_fd >= 0 && (pfds[2].revents & libc::POLLIN) != 0 && check_volume(mux.vol_fd) {
            println!("volume-down: bailing");
            return;
        }
        if (pfds[0].revents & libc::POLLIN) != 0 {
            mux.drain_real(GRABBED.load(Ordering::SeqCst));
        }
        if (pfds[1].revents & (libc::POLLIN | libc::POLLHUP)) != 0 {
            let mut tmp = [0u8; 256];
            let rn = unsafe { libc::read(0, tmp.as_mut_ptr() as *mut libc::c_void, tmp.len()) };
            if rn == 0 {
                println!("stdin EOF: exit");
                if mux.synth_down {
                    mux.synth_set(false, 0, 0);
                }
                release_grab();
                return;
            }
            if rn < 0 {
                // transient (e.g. EAGAIN); nothing to do this iteration.
                continue;
            }
            let n = rn as usize;
            last_ping = now_ms();
            for &ch in &tmp[..n] {
                if ch == b'\n' || linebuf.len() >= 250 {
                    if let Some((cmd, a, b, c, d, e)) = parse_line(&linebuf) {
                        match cmd {
                            b'S' => {
                                if d > 0 {
                                    sw = d as u32;
                                }
                                if e > 0 {
                                    sh = e as u32;
                                }
                                r = (c as f32).max(8.0);
                                let (ccx, ccy) = geom::clamp_circle_center(
                                    a as f32, b as f32, r, sw, sh, 4.0,
                                );
                                cx = ccx;
                                cy = ccy;
                                angle = 0.0;
                                if !GRABBED.load(Ordering::SeqCst) {
                                    mux.do_grab();
                                }
                                let (xn, yn) = geom::circle_point_norm(cx, cy, r, 0.0, sw, sh);
                                mux.synth_set(true, xn as i32, yn as i32);
                                last_tick = now_ms();
                                swiping = true;
                            }
                            b'D' => {
                                // Screen dims + arm the grab, without starting
                                // the test circle. Real aim needs the panel
                                // held so a swipe can coexist with the user's
                                // fingers, but must not draw anything.
                                if a > 0 { sw = a as u32; }
                                if b > 0 { sh = b as u32; }
                                if c > 0 { aim.max_travel = (c as f32).max(16.0); }
                                if !GRABBED.load(Ordering::SeqCst) {
                                    mux.do_grab();
                                }
                            }
                            b'A' => {
                                // A <dx> <dy> <sx> <sy> : one-shot aim swipe of
                                // (dx,dy) px, finger planted at (sx,sy).
                                if !GRABBED.load(Ordering::SeqCst) {
                                    mux.do_grab();
                                }
                                swiping = false;            // cancel any test circle
                                aim.start(a as f32, b as f32, c as f32, d as f32, now_ms());
                                let (xn, yn) = (geom::norm(aim.sx, sw), geom::norm(aim.sy, sh));
                                mux.synth_set(true, xn as i32, yn as i32);
                                last_tick = now_ms();
                                println!("aim from {},{} delta {},{}", a, b, c, d);
                            }
                            b'G' => {
                                // G <dx> <dy> <cx> <cy> [tau_ms] : steer (Guide)
                                // the REAL finger nearest (cx,cy) BY (dx,dy) px.
                                //
                                // tau_ms is optional and sets the chase time
                                // constant live, so the feel can be tuned on
                                // the device rather than recompiled.
                                //
                                // This is the aim's motion and it is NOT 'A'.
                                // 'A' plants a synthetic contact, drags it and
                                // lifts it; repeated on the aim loop that is a
                                // tap every cycle -- which the scoped look
                                // ignores, and which the player sees as the
                                // finger stuttering. Steering publishes an
                                // offset on top of the contact already down, so
                                // the gesture stays ONE continuous drag no
                                // matter how often the aim re-solves.
                                if !GRABBED.load(Ordering::SeqCst) {
                                    mux.do_grab();
                                }
                                let mut found = -1i32;
                                let mut best = f32::MAX;
                                for slot in 0..MAX_SLOTS {
                                    if mux.tracking[slot] == -1
                                        || slot as i32 == mux.synth_slot
                                    {
                                        continue;
                                    }
                                    let (px, py) = mux.real_px(slot, sw, sh);
                                    let ddx = px - c as f32;
                                    let ddy = py - d as f32;
                                    let dd = ddx * ddx + ddy * ddy;
                                    if dd < best { best = dd; found = slot as i32; }
                                }
                                if found < 0 {
                                    // The player is not touching the screen, so
                                    // there is nothing to steer. Say so: silence
                                    // here reads exactly like a dead daemon.
                                    println!("G refused: no finger down");
                                } else {
                                    if mux.steer_slot != found {
                                        // New finger: start this ramp from the
                                        // real position, not from the offset we
                                        // were publishing for the old one.
                                        steer.cur_x = 0.0;
                                        steer.cur_y = 0.0;
                                        mux.steer_last_x = i32::MIN;
                                        mux.steer_last_y = i32::MIN;
                                    }
                                    mux.steer_slot = found;
                                    if e > 0 { steer.set_tau(e as f32); }
                                    // Accumulate-and-cap lives in nvmux-logic
                                    // so it is covered by tests; this handler
                                    // has none. See Steer::command_delta for
                                    // why the offset accumulates at all, and
                                    // why the cap scales the whole vector.
                                    steer.command_delta(a as f32, b as f32,
                                                        aim.max_travel,
                                                        found, now_ms());
                                    steer_idle_since = 0;
                                    // A commanded steer outranks both demos.
                                    test.active = false;
                                    aim.active = false;
                                    swiping = false;
                                    println!("STEER_CMD slot={found} d={:.0}px by {},{} -> {:.0},{:.0}",
                                             best.sqrt(), a, b, steer.to_x, steer.to_y);
                                }
                            }
                            b'T' => {
                                // T <cx> <cy> <r> <hold_ms> : arm the fire-button
                                // test spin. r <= 0 disarms.
                                if c > 0 {
                                    test.cx = a as f32;
                                    test.cy = b as f32;
                                    test.r = c as f32;
                                    test.hold_ms = if d > 0 { d } else { TEST_HOLD_MS_DEFAULT };
                                    test.armed = true;
                                    if !GRABBED.load(Ordering::SeqCst) {
                                        mux.do_grab();
                                    }
                                    println!(
                                        "ARM circle={a},{b} r={c} hold={} screen={sw}x{sh}",
                                        test.hold_ms
                                    );
                                    // Adopt a finger that is ALREADY down.
                                    // The arm arrives after the press that
                                    // caused it -- the scope state it keys off
                                    // comes from the wire -- so waiting for a
                                    // NEW down would miss the very press we are
                                    // here for.
                                    if !test.active {
                                        for slot in 0..MAX_SLOTS {
                                            if mux.tracking[slot] == -1
                                                || slot as i32 == mux.synth_slot
                                            {
                                                continue;
                                            }
                                            let (px, py) = mux.real_px(slot, sw, sh);
                                            if test.contains(px, py) {
                                                test.active = true;
                                                test.t0 = now_ms();
                                                test.slot = slot;
                                                test.from_real = true;
                                                mux.steer_slot = slot as i32;
                                                mux.steer_last_x = i32::MIN;
                                                mux.steer_last_y = i32::MIN;
                                                println!(
                                                    "ADOPT held slot={slot} at={px:.0},{py:.0}"
                                                );
                                                break;
                                            }
                                        }
                                    }
                                } else {
                                    test.armed = false;
                                    if test.active {
                                        test.active = false;
                                        if mux.steer_slot >= 0 {
                                            mux.emit_steer(0.0, 0.0, sw, sh);
                                            mux.steer_slot = -1;
                                        }
                                        mux.synth_set(false, 0, 0);
                                    }
                                    println!("test disarmed");
                                }
                            }
                            b'V' => {
                                // V <cx> <cy> <ms> : spin the synthetic finger
                                // vertically at (cx,cy) RIGHT NOW. No armed
                                // region, no real press, no target -- the
                                // instrument for "does a synthetic drag move
                                // this game's camera at all", with every gate
                                // that could answer "no" removed.
                                if !GRABBED.load(Ordering::SeqCst) {
                                    mux.do_grab();
                                }
                                // Steer whatever finger is down. NEVER plant a
                                // synthetic one: an extra contact is both
                                // useless (the scoped look ignores it) and
                                // actively harmful -- it lands on whatever
                                // overlay button is underneath and drags it.
                                // Pick the contact NEAREST the fire circle,
                                // not simply the first live slot. Scoped, the
                                // player has a thumb on the movement stick too,
                                // and the movement stick is usually slot 0 --
                                // so "first live slot" steers the wrong finger
                                // and walks the player sideways instead of
                                // turning the view.
                                let mut found = -1i32;
                                let mut best = f32::MAX;
                                for slot in 0..MAX_SLOTS {
                                    if mux.tracking[slot] == -1
                                        || slot as i32 == mux.synth_slot
                                    {
                                        continue;
                                    }
                                    let (px, py) = mux.real_px(slot, sw, sh);
                                    let dx = px - a as f32;
                                    let dy = py - b as f32;
                                    let d = dx * dx + dy * dy;
                                    if d < best {
                                        best = d;
                                        found = slot as i32;
                                    }
                                }
                                if found < 0 {
                                    println!("V refused: no finger down to steer");
                                } else {
                                    test.cx = a as f32;
                                    test.cy = b as f32;
                                    test.hold_ms = if c > 0 { c } else { 3000 };
                                    test.active = true;
                                    test.from_real = true;
                                    test.slot = found as usize;
                                    mux.steer_slot = found;
                                    mux.steer_last_x = i32::MIN;
                                    mux.steer_last_y = i32::MIN;
                                    test.t0 = now_ms();
                                    swiping = false;
                                    aim.active = false;
                                    println!(
                                        "TEST_SPIN_START commanded steer slot={found} d={:.0}px ms={}",
                                        best.sqrt(), test.hold_ms
                                    );
                                }
                            }
                            b'U' => {
                                // Deferred for the same reason the GRAB is:
                                // handing the panel back mid-gesture leaves the
                                // CLONE holding a pointer the framework will
                                // never see lifted. Same bug, mirrored.
                                if mux.any_down() {
                                    release_pending = true;
                                    println!("RELEASE deferred: finger down");
                                    linebuf.clear();
                                    continue;
                                }
                                release_pending = false;
                                mux.synth_set(false, 0, 0);
                                release_grab();
                                swiping = false;
                                aim.active = false;
                            }
                            b'Q' => {
                                return;
                            }
                            _ => {} // 'P' ping: last_ping already updated
                        }
                    }
                    linebuf.clear();
                } else {
                    linebuf.push(ch);
                }
            }
        }

        // Take a deferred release the moment the screen is empty, and drop any
        // steering with it -- there is nothing left for us to move.
        if release_pending && !mux.any_down() {
            release_pending = false;
            if mux.steer_slot >= 0 {
                mux.steer_slot = -1;
            }
            test.active = false;
            test.armed = false;
            mux.synth_set(false, 0, 0);
            release_grab();
            swiping = false;
            println!("RELEASE taken (screen empty)");
        }

        // Take a deferred grab the moment the screen is empty. Polled rather
        // than event-driven because the last lift is just another event and
        // the check is two loads.
        if mux.grab_pending && !GRABBED.load(Ordering::SeqCst) && !mux.any_down() {
            if mux.do_grab() {
                println!("GRAB taken (screen empty)");
            }
        }

        // ---- fire-button test spin ----
        // Start it on a real contact landing inside the armed circle. Checked
        // every iteration rather than on a tick, because the down is an event
        // and waiting for the next 16 ms tick would add avoidable latency to
        // the one thing this mode exists to measure.
        if test.armed {
            let downs = mux.take_new_downs();
            if downs != 0 && !test.active && !aim.active {
                for slot in 0..MAX_SLOTS {
                    if downs & (1u64 << slot) == 0 {
                        continue;
                    }
                    let (px, py) = mux.real_px(slot, sw, sh);
                    // THE DUMP LINE. Every real press, where it landed, the
                    // circle it was tested against, and the verdict. If a press
                    // is not triggering, this says whether the daemon saw it at
                    // all and whether the geometry or the detection is at fault
                    // -- which is not answerable from the app side.
                    println!(
                        "DOWN slot={slot} at={px:.0},{py:.0} circle={:.0},{:.0} r={:.0} hit={}",
                        test.cx, test.cy, test.r,
                        if test.contains(px, py) { 1 } else { 0 }
                    );
                    if test.contains(px, py) {
                        test.active = true;
                        test.t0 = now_ms();
                        test.slot = slot;
                        test.from_real = true;
                        // TAKE OVER THIS FINGER. Not a second contact beside
                        // it: scoped, the game steers from the contact already
                        // down, and an extra one is ignored.
                        mux.steer_slot = slot as i32;
                                                mux.steer_last_x = i32::MIN;
                                                mux.steer_last_y = i32::MIN;
                        println!("TEST_SPIN_START steer slot={slot} at={px:.0},{py:.0}");
                        break;
                    }
                }
            }
        } else {
            // Keep the queue from growing while disarmed.
            mux.take_new_downs();
        }

        if test.active {
            let now = now_ms();
            // The steered finger lifting ends the run: there is nothing left to
            // move, and continuing would push a position for a released contact.
            if test.from_real && mux.steer_slot < 0 {
                test.active = false;
                test.from_real = false;
                let held = now - test.t0;
                // Say which it was. A 50 ms release is a TAP, and a tap cannot
                // be steered -- there is no contact left to move. Without this
                // the trace reads the same for "the player let go" and "the
                // steer broke", which are opposite problems.
                if held < 200 {
                    println!("TEST_SPIN_END tap not hold ({held}ms) - hold the button down");
                } else {
                    println!("TEST_SPIN_END finger lifted after {held}ms");
                }
            } else if now - test.t0 >= test.hold_ms {
                test.active = false;
                if test.from_real {
                    // Hand the finger back where it really is, in one report,
                    // before letting go. Dropping the offset without this makes
                    // the contact appear to jump.
                    mux.emit_steer(0.0, 0.0, sw, sh);
                    mux.steer_slot = -1;
                    println!("TEST_SPIN_END steer released slot={}", test.slot);
                } else {
                    mux.synth_set(false, 0, 0);
                    println!("TEST_SPIN_END commanded");
                }
                test.from_real = false;
            } else if now - last_tick >= TICK_MS {
                last_tick = now;
                if test.from_real {
                    let off = test.offset(now, sh);
                    let (bx, by) = mux.real_px(test.slot, sw, sh);
                    mux.emit_steer(0.0, off, sw, sh);
                    // Throttled: enough to prove the offset is being published
                    // and how big it is, without flooding the pipe at 60 Hz.
                    if (now - test.t0) % 300 < TICK_MS {
                        println!("STEER slot={} base={bx:.0},{by:.0} off={off:.0}", test.slot);
                    }
                } else {
                    let (px, py) = test.point(now, sh);
                    let (xn, yn) = (geom::norm(px, sw), geom::norm(py, sh));
                    mux.synth_set(true, xn as i32, yn as i32);
                }
            }
        }

        // Advance a commanded steer. FIRST: it is the production aim path and
        // it must not lose a tick to either demo.
        if steer.active {
            let now = now_ms();
            if now - last_tick >= TICK_MS {
                last_tick = now;
                if mux.steer_slot >= 0
                    && mux.tracking[mux.steer_slot as usize] != -1
                {
                    let (ox, oy) = steer.tick(now);
                    mux.emit_steer(ox, oy, sw, sh);
                    // Let go once the finger has been held at the commanded
                    // offset with nothing new asked for. Ramp to zero first --
                    // dropping a live offset makes the contact jump.
                    if steer_idle_since == 0 {
                        steer_idle_since = now;
                    } else if now - steer_idle_since > STEER_HOLD_MS
                        && (steer.to_x != 0.0 || steer.to_y != 0.0)
                    {
                        steer.release_to_zero(now);
                    } else if steer.at_zero()
                        && steer.to_x == 0.0 && steer.to_y == 0.0
                        && now - steer_idle_since > STEER_HOLD_MS
                    {
                        steer.active = false;
                        mux.steer_slot = -1;
                        println!("STEER_END released");
                    }
                } else {
                    // The finger lifted under us. Drop the steer without
                    // emitting: there is no contact left to hand back.
                    steer.active = false;
                    steer.cur_x = 0.0;
                    steer.cur_y = 0.0;
                    mux.steer_slot = -1;
                    println!("STEER_END finger lifted");
                }
            }
        }

        // Advance a one-shot aim swipe. Checked before the test circle so a
        // real aim always wins over the coexistence demo.
        if aim.active {
            let now = now_ms();
            if now - last_tick >= TICK_MS {
                last_tick = now;
                let replant = aim.needs_replant();
                if let Some((px, py)) = aim.tick(now) {
                    if replant && !aim.needs_replant() {
                        // Segment boundary: lift, then replant at the new start
                        // so the game's distance-based acceleration term resets.
                        mux.synth_set(false, 0, 0);
                    }
                    let (xn, yn) = (geom::norm(px, sw), geom::norm(py, sh));
                    mux.synth_set(true, xn as i32, yn as i32);
                } else {
                    mux.synth_set(false, 0, 0);
                }
            }
            if !aim.active && mux.synth_down {
                mux.synth_set(false, 0, 0);
            }
        }

        // Advance the self-driven circle on the ~16 ms cadence.
        if swiping {
            let now = now_ms();
            if now - last_tick >= TICK_MS {
                last_tick = now;
                angle = geom::advance_angle(angle, STEP_RAD);
                let (xn, yn) = geom::circle_point_norm(cx, cy, r, angle, sw, sh);
                mux.synth_set(true, xn as i32, yn as i32);
            }
        }

        // The lease exists so a dead app cannot leave the panel grabbed. A
        // running aim swipe or test spin is FINITE and self-terminating, so it
        // is not a hostage risk -- and cutting one mid-flight released the grab
        // 1.5 s after arming, which is exactly long enough to look like the
        // feature doing nothing at all.
        if GRABBED.load(Ordering::SeqCst)
            && !test.active
            && !aim.active
            && now_ms() - last_ping > LEASE_MS
        {
            println!("lease expired: releasing");
            if mux.synth_down {
                mux.synth_set(false, 0, 0);
            }
            release_grab();
            swiping = false;
            if test.armed {
                // Armed but no longer grabbed is a lie: the daemon can no
                // longer see the real contacts it was told to watch for.
                test.armed = false;
                println!("test disarmed (lease)");
            }
        }
    }
}
