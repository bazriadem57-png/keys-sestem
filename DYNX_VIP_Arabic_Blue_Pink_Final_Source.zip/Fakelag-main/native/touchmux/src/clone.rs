//! Building the /dev/uinput clone that carries the panel's identity.

use crate::consts::*;
use crate::mux::{zero_absinfo, Mux};
use crate::sys::{errno, eviocgabs, eviocgbit, eviocgid, eviocgname, eviocgprop,
                 test_bit, ui_abs_setup, ui_dev_setup, UINPUT_FD,
                 UI_DEV_CREATE, UI_SET_ABSBIT, UI_SET_EVBIT, UI_SET_KEYBIT,
                 UI_SET_PROPBIT};
use core::sync::atomic::Ordering;

pub(crate) fn setup_clone(real_fd: i32) -> Option<Mux> {
    let fd = unsafe { libc::open(b"/dev/uinput\0".as_ptr() as *const libc::c_char, libc::O_WRONLY | libc::O_NONBLOCK) };
    if fd < 0 {
        println!("OPEN_UINPUT_FAIL errno={}", errno());
        return None;
    }

    let mut id = libc::input_id { bustype: 0, vendor: 0, product: 0, version: 0 };
    let mut name = [0u8; UINPUT_MAX_NAME_SIZE];
    let mut ab = [0u8; (ABS_MAX as usize / 8) + 1];
    let mut pr = [0u8; (INPUT_PROP_MAX as usize / 8) + 1];
    unsafe {
        libc::ioctl(real_fd, eviocgid() as _, &mut id);
        libc::ioctl(real_fd, eviocgname(name.len() as u32) as _, name.as_mut_ptr());
        libc::ioctl(real_fd, eviocgbit(EV_ABS as u32, ab.len() as u32) as _, ab.as_mut_ptr());
        libc::ioctl(real_fd, eviocgprop(pr.len() as u32) as _, pr.as_mut_ptr());

        libc::ioctl(fd, UI_SET_EVBIT as _, EV_SYN as i32);
        libc::ioctl(fd, UI_SET_EVBIT as _, EV_KEY as i32);
        libc::ioctl(fd, UI_SET_EVBIT as _, EV_ABS as i32);
        libc::ioctl(fd, UI_SET_KEYBIT as _, BTN_TOUCH as i32);
        libc::ioctl(fd, UI_SET_KEYBIT as _, BTN_TOOL_FINGER as i32);
    }

    let mut abs_x = zero_absinfo();
    let mut abs_y = zero_absinfo();
    let mut max_slot: i32 = 9;
    for code in 0..ABS_MAX as u16 {
        if !test_bit(&ab, code as usize) {
            continue;
        }
        let mut ai = zero_absinfo();
        if unsafe { libc::ioctl(real_fd, eviocgabs(code as u32) as _, &mut ai) } < 0 {
            continue;
        }
        if code == ABS_MT_POSITION_X {
            abs_x = ai;
        }
        if code == ABS_MT_POSITION_Y {
            abs_y = ai;
        }
        if code == ABS_MT_SLOT {
            max_slot = ai.maximum;
        }
        unsafe {
            libc::ioctl(fd, UI_SET_ABSBIT as _, code as i32);
        }
        // Copy the panel's absinfo, but NEVER its fuzz on the position axes.
        //
        // input_handle_abs_event() runs input_defuzz_abs_event() before it
        // compares against the previous value, so any step smaller than fuzz/2
        // is snapped back to the old value -- and is then dropped outright as
        // "unchanged". A frame whose only events are dropped carries
        // num_vals < 2 and is discarded whole, so a small steering step
        // produces literally nothing downstream, with no error anywhere.
        // Real fingers never notice because they move further than fuzz.
        let mut ai = ai;
        // Only the MT position axes: Android ignores ABS_X/ABS_Y entirely on a
        // device that reports ABS_MT_POSITION_*, so they are not worth touching.
        if code == ABS_MT_POSITION_X || code == ABS_MT_POSITION_Y {
            ai.fuzz = 0;
        }
        let uas = libc::uinput_abs_setup { code, absinfo: ai };
        unsafe {
            libc::ioctl(fd, ui_abs_setup() as _, &uas);
        }
    }
    if test_bit(&pr, INPUT_PROP_DIRECT as usize) {
        unsafe { libc::ioctl(fd, UI_SET_PROPBIT as _, INPUT_PROP_DIRECT as i32) };
    }
    let mut synth_slot = max_slot;
    if synth_slot >= MAX_SLOTS as i32 {
        synth_slot = MAX_SLOTS as i32 - 1;
    }

    let mut us: libc::uinput_setup = unsafe { core::mem::zeroed() };
    us.id = id;
    for (i, &b) in name.iter().enumerate() {
        if i >= us.name.len() - 1 {
            break;
        }
        us.name[i] = b as libc::c_char;
    }
    if unsafe { libc::ioctl(fd, ui_dev_setup() as _, &us) } < 0 {
        println!("UI_DEV_SETUP_FAIL errno={}", errno());
        unsafe { libc::close(fd) };
        return None;
    }
    if unsafe { libc::ioctl(fd, UI_DEV_CREATE as _) } < 0 {
        println!("UI_DEV_CREATE_FAIL errno={}", errno());
        unsafe { libc::close(fd) };
        return None;
    }
    // AOSP cmds/uinput: events before InputReader enumerates the device drop.
    unsafe { libc::usleep(700 * 1000) };
    println!(
        "clone up: slots={} x[{}..{}] y[{}..{}]",
        max_slot, abs_x.minimum, abs_x.maximum, abs_y.minimum, abs_y.maximum
    );

    UINPUT_FD.store(fd, Ordering::SeqCst);
    Some(Mux {
        real_fd,
        uinput_fd: fd,
        vol_fd: -1,
        max_slot,
        synth_slot,
        cur_slot: 0,
        last_emit_slot: -999,
        tracking: [-1; MAX_SLOTS],
        synth_down: false,
        last_btn: 0,
        abs_x,
        abs_y,
        real_x: [0; MAX_SLOTS],
        real_y: [0; MAX_SLOTS],
        suppressed: [false; MAX_SLOTS],
        pending_down: 0,
        new_down: 0,
        grab_pending: false,
        mid_frame: false,
        steer_last_x: i32::MIN,
        steer_last_y: i32::MIN,
        steer_slot: -1,
    })
}
