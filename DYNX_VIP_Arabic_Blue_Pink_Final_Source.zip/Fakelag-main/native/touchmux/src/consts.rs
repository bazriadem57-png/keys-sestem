//! evdev / uinput constants and the daemon's tuning numbers.
//!
//! Pure data: no code, no state. Split out so the interesting files are about
//! behaviour rather than about `linux/input.h`.

// ---- evdev / uinput constants (from linux/input.h, linux/uinput.h) ----------
pub(crate) const EV_SYN: u16 = 0x00;
pub(crate) const EV_KEY: u16 = 0x01;
pub(crate) const EV_ABS: u16 = 0x03;
pub(crate) const EV_MAX: u16 = 0x1f;
pub(crate) const SYN_REPORT: u16 = 0x00;

pub(crate) const KEY_MAX: u16 = 0x2ff;
pub(crate) const KEY_VOLUMEDOWN: u16 = 114;
pub(crate) const BTN_TOUCH: u16 = 0x14a;
pub(crate) const BTN_TOOL_FINGER: u16 = 0x145;

pub(crate) const ABS_MAX: u16 = 0x3f;
pub(crate) const ABS_MT_SLOT: u16 = 0x2f;
pub(crate) const ABS_MT_POSITION_X: u16 = 0x35;
pub(crate) const ABS_MT_POSITION_Y: u16 = 0x36;
pub(crate) const ABS_MT_TRACKING_ID: u16 = 0x39;

pub(crate) const INPUT_PROP_MAX: u16 = 0x1f;
pub(crate) const INPUT_PROP_DIRECT: u16 = 0x01;

pub(crate) const UINPUT_MAX_NAME_SIZE: usize = 80;
pub(crate) const MAX_SLOTS: usize = 64;
pub(crate) const LEASE_MS: i64 = 1500;
pub(crate) const SYNTH_TRACK: i32 = 60001;
pub(crate) const TICK_MS: i64 = 16;
pub(crate) const STEP_RAD: f32 = 0.30;


// ---- fire-button test spin --------------------------------------------------
// A standing proof that a synthetic drag planted on the fire button actually
// turns the view. The player holds fire; the daemon spins the view up and down
// for TEST_HOLD_MS_DEFAULT while the shot goes off, then CANCELS the player's
// own contact so the press ends cleanly without them lifting.
//
// Cancelling rather than waiting for the lift is the whole point: it proves the
// daemon owns the real contact stream, which is the same capability the real
// trigger (F1) needs to abort a swipe the instant the player moves.
/// Peak vertical excursion of the test spin, as a fraction of screen height.
/// One full up-down cycle, ms.
/// How long to spin before cancelling the player's press, ms.
pub(crate) const TEST_HOLD_MS_DEFAULT: i64 = 5000;

// MAX_TRAVEL_DEFAULT / SWIPE_MS / SETTLE_MS / TEST_AMP_FRAC / TEST_PERIOD_MS
// moved to the nvmux-logic crate, next to the state machines that are the only
// things that read them.
