//! JNI shim for the Nuvola packet core.
//!
//! RE-hardening: the worker functions are bound with `RegisterNatives` inside
//! `JNI_OnLoad`, referenced only by pointer, so they carry no `#[no_mangle]` and
//! never enter the dynamic symbol table. `JNI_OnLoad` is the ONLY exported
//! symbol — a reverser gets no Java↔native name map for free (unlike the
//! `Java_com_nuvola_...` mangled-export scheme). With `strip="symbols"` +
//! `lto=true` an `llvm-nm -D` on the shipped `.so` should list only `JNI_OnLoad`.
//!
//! `panic="abort"` is set (workspace profile), so nothing here may panic across
//! the boundary — every entry returns an error code instead.

use std::os::raw::c_void;

use jni::objects::{JByteBuffer, JClass};
use jni::sys::{jint, jlong, JNI_ERR, JNI_VERSION_1_6};
use jni::{JNIEnv, JavaVM, NativeMethod};

/// Build-stamped self-test magic: high 32 bits = native ABI/logic version, low
/// 16 bits = "NV". The Java loader refuses to promote a lib whose `nnSelftest`
/// does not return exactly this (catches corrupt / ABI-mismatched builds).
/// Bump the version half whenever the Rust↔Java contract changes.
const NATIVE_ABI_VERSION: i64 = 1;
const NN_SELFTEST_MAGIC: jlong = (NATIVE_ABI_VERSION << 32) | 0x4E56;

/// `long nnSelftest()` — runs the core known-answer checks; returns the magic on
/// success, 0 on failure. Called once at load, never on the packet path.
unsafe extern "system" fn nn_selftest<'local>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jlong {
    if nuvola_core::selftest() {
        NN_SELFTEST_MAGIC
    } else {
        0
    }
}

/// `int crc7Seal(ByteBuffer directBuf, int len)` — recompute the CRC-7 checksum
/// (packet byte 1) over `buf[2..len]` in place and return it (0..127), or -1 on
/// a bad buffer. Zero-copy against a reused direct `ByteBuffer`.
unsafe extern "system" fn crc7_seal<'local>(
    env: JNIEnv<'local>,
    _class: JClass<'local>,
    buf: JByteBuffer<'local>,
    len: jint,
) -> jint {
    let ptr = match env.get_direct_buffer_address(&buf) {
        Ok(p) => p,
        Err(_) => return -1,
    };
    let cap = match env.get_direct_buffer_capacity(&buf) {
        Ok(c) => c,
        Err(_) => return -1,
    };
    if ptr.is_null() || len < 3 || (len as usize) > cap {
        return -1;
    }
    let pkt = std::slice::from_raw_parts_mut(ptr, len as usize);
    nuvola_core::crc7::seal(pkt) as jint
}

/// `int chainDecode(ByteBuffer pkt, int off, int len, int ownId, int maxLen,
/// int maxRecords, int minRecordBytes, long minRecordX, long maxEntityId,
/// long validUntil, long now, ByteBuffer out)` — decode a raw Cmd-2012 chain from
/// `pkt[off..off+len]` under the server-issued profile and serialize the records
/// into `out` (see `chain::Chain::serialize`). Returns the record count (>= 0),
/// or -1 on a bad buffer / not-a-chain / no live profile. Zero-copy on both
/// direct buffers. Phase-4 staging: bound to Java behind a hard-off flag and not
/// yet on the live path; see `docs/SERVER_GATED_DECODE_DESIGN.md`.
#[allow(clippy::too_many_arguments)]
unsafe extern "system" fn chain_decode<'local>(
    env: JNIEnv<'local>,
    _class: JClass<'local>,
    pkt: JByteBuffer<'local>,
    off: jint,
    len: jint,
    own_id: jint,
    max_len: jint,
    max_records: jint,
    min_record_bytes: jint,
    min_record_x: jlong,
    max_entity_id: jlong,
    valid_until: jlong,
    now: jlong,
    out: JByteBuffer<'local>,
) -> jint {
    let pkt_ptr = match env.get_direct_buffer_address(&pkt) {
        Ok(p) => p,
        Err(_) => return -1,
    };
    let pkt_cap = match env.get_direct_buffer_capacity(&pkt) {
        Ok(c) => c,
        Err(_) => return -1,
    };
    let out_ptr = match env.get_direct_buffer_address(&out) {
        Ok(p) => p,
        Err(_) => return -1,
    };
    let out_cap = match env.get_direct_buffer_capacity(&out) {
        Ok(c) => c,
        Err(_) => return -1,
    };
    if pkt_ptr.is_null()
        || out_ptr.is_null()
        || off < 0
        || len < 0
        || max_len < 0
        || max_records < 0
        || min_record_bytes < 0
        || min_record_x < 0
        || max_entity_id < 0
        || valid_until < 0
        || now < 0
    {
        return -1;
    }
    let pkt_slice = std::slice::from_raw_parts(pkt_ptr as *const u8, pkt_cap);
    let profile = nuvola_core::chain::ChainProfile {
        chain_max_len: max_len as usize,
        max_records: max_records as usize,
        min_record_bytes: min_record_bytes as usize,
        min_record_x: min_record_x as u64,
        max_entity_id: max_entity_id as u64,
        valid_until: valid_until as u64,
    };
    let chain = match nuvola_core::chain::parse_with_profile(
        pkt_slice,
        off as usize,
        len as usize,
        own_id,
        &profile,
        now as u64,
    ) {
        Some(c) => c,
        None => return -1,
    };
    let out_slice = std::slice::from_raw_parts_mut(out_ptr, out_cap);
    match chain.serialize(out_slice) {
        Some(_) => chain.len() as jint,
        None => -1, // out buffer too small
    }
}

/// The only exported symbol. Binds the native methods by pointer, so the workers
/// above stay internal/mangled and out of `.dynsym`.
/// # Safety
/// The JVM fixes this signature (raw `*mut JavaVM`) and calls it once at load
/// with a valid `vm` pointer; `_reserved` is unused. It must not be called with
/// an invalid or dangling `vm`. Marking it `unsafe` (identical symbol + ABI) is
/// the honest signal for the raw-pointer deref rather than an allow-and-hope.
#[no_mangle]
pub unsafe extern "system" fn JNI_OnLoad(vm: *mut jni::sys::JavaVM, _reserved: *mut c_void) -> jint {
    let vm = match JavaVM::from_raw(vm) {
        Ok(v) => v,
        Err(_) => return JNI_ERR,
    };
    let mut env = match vm.get_env() {
        Ok(e) => e,
        Err(_) => return JNI_ERR,
    };

    // Method names AND signatures are obfstr-wrapped, not just the class name: a
    // plaintext RegisterNatives table (name -> JNI signature -> fn_ptr, all wired
    // in this function) is a name->ABI->code map that bypasses every CF pass, so
    // it was the single highest-value pivot in the 2026-09-18 binary audit. obfstr
    // yields a statement-scoped &str; `.into()` consumes it into an owned JNIString
    // within this `let`, so it must stay inline (never let-bound).
    let methods = [
        NativeMethod {
            name: obfstr::obfstr!("nnSelftest").into(),
            sig: obfstr::obfstr!("()J").into(),
            fn_ptr: nn_selftest as *mut c_void,
        },
        NativeMethod {
            name: obfstr::obfstr!("crc7Seal").into(),
            sig: obfstr::obfstr!("(Ljava/nio/ByteBuffer;I)I").into(),
            fn_ptr: crc7_seal as *mut c_void,
        },
    ];

    // Class name kept out of .rodata. obfstr! yields a &str valid only for the
    // enclosing statement, so it must be passed inline (not let-bound).
    if env
        .register_native_methods(obfstr::obfstr!("com/nuvola/app/net/NativeBridge"), &methods)
        .is_err()
    {
        return JNI_ERR;
    }

    // Phase-4 methods (decode/rewrite routing), staged behind a Java hard-off
    // flag. Registered in a SEPARATE, NON-FATAL step on purpose: this binding is
    // not yet verified on-device, so if it ever failed to resolve it must NOT
    // take down the core `nnSelftest`/`crc7Seal` above — the loader can still
    // promote a working lib. A failure here just leaves the phase-4 methods
    // unbound (the Java flag that would call them is off anyway).
    let phase4 = [NativeMethod {
        name: obfstr::obfstr!("chainDecode").into(),
        sig: obfstr::obfstr!("(Ljava/nio/ByteBuffer;IIIIIIJJJJLjava/nio/ByteBuffer;)I").into(),
        fn_ptr: chain_decode as *mut c_void,
    }];
    let _ = env.register_native_methods(obfstr::obfstr!("com/nuvola/app/net/NativeBridge"), &phase4);

    JNI_VERSION_1_6
}
