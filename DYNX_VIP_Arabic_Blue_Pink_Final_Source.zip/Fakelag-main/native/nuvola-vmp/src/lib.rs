//! VMP-isolation crate — see `Cargo.toml`.
//!
//! Holds only the QQ-TEA Feistel round cores, moved out of `nuvola_core::tea`
//! so amice's instruction-level `VM_VIRTUALIZE` pass can virtualize exactly
//! these functions. The CI `RUSTC_WRAPPER` sets `AMICE_VM_VIRTUALIZE=true` only
//! for `--crate-name nuvola_vmp`, because the whole-crate global enable
//! miscompiles the packet logic (the QEMU correctness gate caught it). Behavior
//! here is byte-identical to the original inline bodies; the TEA round-trip and
//! `selftest()` KATs in `nuvola-core` cover it exactly, and the QEMU gate runs
//! them against this crate compiled WITH the VMP pass — so a VMP miscompile of
//! these two functions fails a golden instead of shipping.
#![forbid(unsafe_code)]

/// QQ-TEA round count (16-round TEA). Kept local so this crate is self-contained.
const ROUNDS: u32 = 16;
/// The TEA key-schedule delta (0x9E3779B9). MBA/`movk`-obfuscated in the shipped
/// build, so it is not a findable literal (2026-09-18 binary audit confirmed).
const DELTA: u32 = 0x9E37_79B9;

/// Decrypt one 64-bit block (two little-endian words `v0`,`v1`) under the 4-word
/// key. `#[inline(never)]` so it stays a distinct function for the VMP pass to
/// virtualize — and so a host or LTO build cannot dissolve it back into the
/// caller, which would defeat the isolation.
#[inline(never)]
pub fn tea_decrypt_round(mut v0: u32, mut v1: u32, k: &[u32; 4]) -> (u32, u32) {
    let (k0, k1, k2, k3) = (k[0], k[1], k[2], k[3]);
    let mut sum = DELTA.wrapping_mul(ROUNDS);
    for _ in 0..ROUNDS {
        v1 = v1.wrapping_sub(
            ((v0 << 4).wrapping_add(k2)) ^ v0.wrapping_add(sum) ^ ((v0 >> 5).wrapping_add(k3)),
        );
        v0 = v0.wrapping_sub(
            ((v1 << 4).wrapping_add(k0)) ^ v1.wrapping_add(sum) ^ ((v1 >> 5).wrapping_add(k1)),
        );
        sum = sum.wrapping_sub(DELTA);
    }
    (v0, v1)
}

/// Encrypt one 64-bit block. Exact inverse of [`tea_decrypt_round`].
#[inline(never)]
pub fn tea_encrypt_round(mut v0: u32, mut v1: u32, k: &[u32; 4]) -> (u32, u32) {
    let (k0, k1, k2, k3) = (k[0], k[1], k[2], k[3]);
    let mut sum: u32 = 0;
    for _ in 0..ROUNDS {
        sum = sum.wrapping_add(DELTA);
        v0 = v0.wrapping_add(
            ((v1 << 4).wrapping_add(k0)) ^ v1.wrapping_add(sum) ^ ((v1 >> 5).wrapping_add(k1)),
        );
        v1 = v1.wrapping_add(
            ((v0 << 4).wrapping_add(k2)) ^ v0.wrapping_add(sum) ^ ((v0 >> 5).wrapping_add(k3)),
        );
    }
    (v0, v1)
}

#[cfg(test)]
mod tests {
    use super::*;

    // A round-trip KAT local to this crate (nuvola-core also covers it via the
    // full TEA vectors). Guards the isolation refactor independently.
    #[test]
    fn round_trip() {
        let k = [0x1234_5678u32, 0x9abc_def0, 0x0f1e_2d3c, 0x4b5a_6978];
        let (c0, c1) = tea_encrypt_round(0xdead_beef, 0xfeed_face, &k);
        let (p0, p1) = tea_decrypt_round(c0, c1, &k);
        assert_eq!((p0, p1), (0xdead_beef, 0xfeed_face));
    }
}
