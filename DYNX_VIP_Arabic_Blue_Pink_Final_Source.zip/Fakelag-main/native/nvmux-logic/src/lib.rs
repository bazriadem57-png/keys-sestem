//! Pure logic for the nvmux touch daemon.
//!
//! Everything here is arithmetic and state transitions with no IO, no `libc`
//! and no platform assumptions — so it compiles and runs its tests on the
//! Windows dev host, which the daemon itself never can (it is
//! `aarch64-linux-android`-only and deliberately excluded from this workspace's
//! sibling `touchmux`).
//!
//! That is the whole point of the split. The swipe easing, the steer geometry
//! and the line protocol are exactly the parts that fail *silently* — a wrong
//! easing curve or a mis-parsed command produces no error, just a feature that
//! does nothing — and they were previously welded to the ioctls, where no test
//! could reach them.

#![forbid(unsafe_code)]

mod proto;
mod spin;
mod steer;
mod swipe;

pub use proto::parse_line;
pub use spin::TestSpin;
pub use steer::{Steer, STEER_MS, STEER_HOLD_MS};
pub use swipe::Swipe;

/// Longest single drag before lifting and re-planting the finger, px.
///
/// The game's touch-look has an ACCELERATION term: effective sensitivity grows
/// with distance from the touch-down point (~3.4x at 300 px on a 400 dpi
/// panel). A single long drag therefore turns far more than gain*distance
/// predicts and the aim overshoots while blaming its own calibration. This is a
/// workaround for a client bug, not a tuning knob.
pub const MAX_TRAVEL_DEFAULT: f32 = 100.0;
/// Nominal duration of one swipe segment, ms.
pub const SWIPE_MS: i64 = 120;
/// Settle hold after the last segment before lifting, ms.
pub const SETTLE_MS: i64 = 40;

/// Peak vertical excursion of the steer, as a fraction of screen height.
pub const TEST_AMP_FRAC: f32 = 0.10;
/// One full up-down cycle, ms.
pub const TEST_PERIOD_MS: i64 = 900;
/// How long to steer before giving the finger back, ms.
pub const TEST_HOLD_MS_DEFAULT: i64 = 5000;
