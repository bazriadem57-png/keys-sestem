//! The stdin line protocol.

/// five integer args (missing args = 0).
pub fn parse_line(line: &[u8]) -> Option<(u8, i64, i64, i64, i64, i64)> {
    let s = std::str::from_utf8(line).ok()?;
    let mut it = s.split_whitespace();
    let cmd = it.next()?.as_bytes().first().copied()?;
    let mut vals = [0i64; 5];
    for v in vals.iter_mut() {
        if let Some(tok) = it.next() {
            *v = tok.parse().unwrap_or(0);
        }
    }
    Some((cmd, vals[0], vals[1], vals[2], vals[3], vals[4]))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_a_full_command() {
        assert_eq!(parse_line(b"A 100 200 -30 40"),
                   Some((b'A', 100, 200, -30, 40, 0)));
    }

    /// Missing args read as zero — which is what every caller assumes.
    #[test]
    fn missing_args_are_zero() {
        assert_eq!(parse_line(b"U"), Some((b'U', 0, 0, 0, 0, 0)));
        assert_eq!(parse_line(b"T 5"), Some((b'T', 5, 0, 0, 0, 0)));
    }

    /// Garbage must not panic and must not silently become a valid command.
    /// This runs on the daemon's stdin, which an app crash can fill with
    /// anything.
    #[test]
    fn malformed_input_is_rejected_or_zeroed() {
        assert_eq!(parse_line(b""), None);
        assert_eq!(parse_line(b"   "), None);
        assert_eq!(parse_line(b"A x y"), Some((b'A', 0, 0, 0, 0, 0)));
        assert_eq!(parse_line(&[0xff, 0xfe]), None);   // invalid UTF-8
    }

    /// Only the first byte selects the command, so extra letters cannot make a
    /// different one fire by accident.
    #[test]
    fn command_is_the_first_byte_only() {
        assert_eq!(parse_line(b"Quit").map(|t| t.0), Some(b'Q'));
    }
}
