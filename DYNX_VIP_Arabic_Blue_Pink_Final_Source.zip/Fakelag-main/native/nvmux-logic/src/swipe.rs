//! One-shot aim swipe: a min-jerk drag split into <= max_travel segments with a
//! lift-and-replant between them.

use crate::*;

/// One-shot aim swipe: a min-jerk drag, split into <= MAX_TRAVEL_PX segments
/// with a lift-and-replant between them.
///
/// Open-loop by design. The target's screen position moves *because of* the
/// swipe, so a closed-loop tracker chases a projection it is itself moving --
/// the delta is computed once, at trigger time, and executed blind.
pub struct Swipe {
    pub active: bool,
    /// Segment start and end, screen px.
    pub sx: f32,
    pub sy: f32,
    pub ex: f32,
    pub ey: f32,
    /// Delta still owed after this segment.
    pub rem_x: f32,
    pub rem_y: f32,
    pub t0: i64,
    pub settling: bool,
    /// Re-grip cap, px. Sent by the app so the editable value and the
    /// daemon's behaviour cannot drift apart.
    pub max_travel: f32,
}

impl Swipe {
    pub fn idle() -> Self {
        Swipe { active: false, sx: 0.0, sy: 0.0, ex: 0.0, ey: 0.0,
                rem_x: 0.0, rem_y: 0.0, t0: 0, settling: false,
                max_travel: MAX_TRAVEL_DEFAULT }
    }

    /// Begin a swipe of (dx, dy) px starting the finger at (sx, sy).
    ///
    /// Takes `now` rather than reading a clock: it is the one line that used to
    /// make this whole state machine impure, and therefore untestable anywhere.
    pub fn start(&mut self, sx: f32, sy: f32, dx: f32, dy: f32, now: i64) {
        self.sx = sx; self.sy = sy;
        self.plan(dx, dy);
        self.active = true;
        self.settling = false;
        self.t0 = now;
    }

    /// Clamp this segment to MAX_TRAVEL_PX and stash the remainder.
    pub fn plan(&mut self, dx: f32, dy: f32) {
        let mag = (dx * dx + dy * dy).sqrt();
        if mag <= self.max_travel || mag < 1e-3 {
            self.ex = self.sx + dx;
            self.ey = self.sy + dy;
            self.rem_x = 0.0;
            self.rem_y = 0.0;
        } else {
            let k = self.max_travel / mag;
            self.ex = self.sx + dx * k;
            self.ey = self.sy + dy * k;
            self.rem_x = dx * (1.0 - k);
            self.rem_y = dy * (1.0 - k);
        }
    }

    /// Minimum-jerk position along the segment. Flash & Hogan's quintic:
    /// s(t) = 10t^3 - 15t^4 + 6t^5, the standard model of human point-to-point
    /// reaching (bell-shaped velocity, zero vel/accel at both ends).
    pub fn eased(tau: f32) -> f32 {
        let t = tau.clamp(0.0, 1.0);
        let t3 = t * t * t;
        10.0 * t3 - 15.0 * t3 * t + 6.0 * t3 * t * t
    }

    /// Advance one tick. Returns Some((px, py)) to emit, or None when finished.
    pub fn tick(&mut self, now: i64) -> Option<(f32, f32)> {
        if !self.active {
            return None;
        }
        if self.settling {
            if now - self.t0 >= SETTLE_MS {
                self.active = false;
            }
            return Some((self.ex, self.ey));
        }
        let tau = (now - self.t0) as f32 / SWIPE_MS as f32;
        if tau >= 1.0 {
            if self.rem_x != 0.0 || self.rem_y != 0.0 {
                // Re-grip: this segment is done but delta remains. The caller
                // lifts and replants at the same start point, which is what
                // resets the game's distance-based acceleration term.
                let (rx, ry) = (self.rem_x, self.rem_y);
                self.plan(rx, ry);
                self.t0 = now;
                return Some((self.sx, self.sy));
            }
            self.settling = true;
            self.t0 = now;
            return Some((self.ex, self.ey));
        }
        let s = Self::eased(tau);
        Some((self.sx + (self.ex - self.sx) * s, self.sy + (self.ey - self.sy) * s))
    }

    /// True at the instant a segment boundary needs a lift + replant.
    pub fn needs_replant(&self) -> bool {
        (self.rem_x != 0.0 || self.rem_y != 0.0) && !self.settling
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Flash & Hogan's quintic: zero at both ends, exactly half at the midpoint,
    /// and monotonic in between. If this is wrong the swipe still "works" and
    /// just feels and lands wrong, which is why it needs a test and not an eye.
    #[test]
    fn eased_is_a_min_jerk_curve() {
        assert_eq!(Swipe::eased(0.0), 0.0);
        assert_eq!(Swipe::eased(1.0), 1.0);
        assert!((Swipe::eased(0.5) - 0.5).abs() < 1e-6);
        let mut prev = -1.0;
        for i in 0..=100 {
            let v = Swipe::eased(i as f32 / 100.0);
            assert!(v >= prev, "not monotonic at {i}");
            prev = v;
        }
    }

    /// Out-of-range tau must clamp, not extrapolate. An unclamped quintic runs
    /// away fast: at tau = 2 it returns 32.
    #[test]
    fn eased_clamps_outside_zero_one() {
        assert_eq!(Swipe::eased(-5.0), 0.0);
        assert_eq!(Swipe::eased(2.0), 1.0);
    }

    #[test]
    fn short_swipe_is_one_segment() {
        let mut s = Swipe::idle();
        s.max_travel = 100.0;
        s.start(500.0, 500.0, 30.0, 40.0, 0);      // |d| = 50
        assert_eq!((s.rem_x, s.rem_y), (0.0, 0.0));
        assert_eq!((s.ex, s.ey), (530.0, 540.0));
        assert!(!s.needs_replant());
    }

    /// The re-grip cap is a workaround for the game's distance-based look
    /// acceleration, so the split point has to be exactly max_travel — not
    /// "about" it. A 3-4-5 triangle makes that checkable by hand.
    #[test]
    fn long_swipe_splits_at_max_travel_and_keeps_direction() {
        let mut s = Swipe::idle();
        s.max_travel = 100.0;
        s.start(0.0, 0.0, 300.0, 400.0, 0);        // |d| = 500
        let seg = ((s.ex * s.ex) + (s.ey * s.ey)).sqrt();
        assert!((seg - 100.0).abs() < 1e-3, "segment was {seg}");
        // Direction preserved: the segment is d scaled by 100/500.
        assert!((s.ex - 60.0).abs() < 1e-3 && (s.ey - 80.0).abs() < 1e-3);
        // And the remainder is the rest of it, same direction.
        let rem = ((s.rem_x * s.rem_x) + (s.rem_y * s.rem_y)).sqrt();
        assert!((rem - 400.0).abs() < 1e-3, "remainder was {rem}");
        assert!(s.needs_replant());
    }

    /// A zero-length swipe must not produce NaN through the 1/mag normalise.
    #[test]
    fn zero_delta_is_not_nan() {
        let mut s = Swipe::idle();
        s.start(10.0, 20.0, 0.0, 0.0, 0);
        assert!(s.ex.is_finite() && s.ey.is_finite());
        assert_eq!((s.ex, s.ey), (10.0, 20.0));
    }

    /// The whole swipe must terminate. An off-by-one in the settle branch
    /// leaves the synthetic finger planted forever, holding the panel down.
    #[test]
    fn swipe_terminates() {
        let mut s = Swipe::idle();
        s.max_travel = 100.0;
        s.start(0.0, 0.0, 250.0, 0.0, 0);
        let mut now = 0i64;
        for _ in 0..10_000 {
            if s.tick(now).is_none() {
                assert!(!s.active);
                return;
            }
            now += 16;
        }
        panic!("swipe never finished");
    }
}
