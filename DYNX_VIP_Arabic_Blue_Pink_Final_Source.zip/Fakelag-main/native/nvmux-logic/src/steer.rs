//! Steering the player's OWN contact by a commanded delta.
//!
//! This is the aim's motion, and it is deliberately not [`crate::Swipe`].
//!
//! # Why not a swipe
//!
//! `Swipe` plants a synthetic finger, drags it, and lifts it. Repeated on the
//! aim loop that produces a *tap, tap, tap* — a new contact every cycle — which
//! is both wrong for the game (the scoped look ignores an extra contact) and
//! visibly wrong to the player. The project already learned this once: steer
//! the contact that is already down, never add one.
//!
//! # The motion: an exponential chase, NOT a ramp
//!
//! `cur += (target - cur) * (1 - exp(-dt/tau))`, re-evaluated every daemon
//! tick. The offset never stops moving and never restarts, because there is no
//! ramp to finish.
//!
//! This replaced a min-jerk ramp, and the reason is worth keeping. A min-jerk
//! curve **begins and ends at zero velocity** — that is what makes it look
//! natural for a single gesture. But the aim re-commands every ~120 ms while
//! the ramp lasted 90 ms, so every cycle ran: accelerate, decelerate to a dead
//! stop, sit still for 30 ms, accelerate again. On screen that is *move, wait,
//! move, wait* — which is what it was reported as. The stall was not the 30 ms
//! gap alone; even back-to-back the ease-out into ease-in puts a full stop at
//! every seam.
//!
//! An exponential chase has no seam. Re-commanding mid-flight only changes
//! where it is heading; the velocity stays continuous through the change, so a
//! tracked target is one unbroken drag — the way a finger actually moves.
//!
//! The offset is an absolute displacement published on top of the real
//! finger's position, so it is held, not decayed: dropping it would snap the
//! contact back. The caller lets go via [`Steer::release_to_zero`].

use crate::*;

/// Time constant of the chase, ms — the time to close ~63% of the remaining
/// distance.
///
/// This is the single feel knob. Lower is snappier and, past a point, visibly
/// robotic; higher is smoother and laggier behind a moving target. It wants to
/// stay comfortably BELOW the aim's re-solve period (~120 ms) so the offset
/// substantially arrives before the next correction, or corrections pile up
/// faster than they are consumed.
pub const STEER_TAU_MS: f32 = 55.0;

/// Legacy ramp length, kept only for the swipe path's timing.
pub const STEER_MS: i64 = 90;

/// How long the offset is held with nothing new commanded before the steer
/// ramps back to the real finger and lets go, ms.
///
/// The aim re-solves every ~120 ms, so anything comfortably above that keeps a
/// tracked target under one continuous drag. Too short and the contact walks
/// back between updates, which is the tapping this whole module exists to fix.
pub const STEER_HOLD_MS: i64 = 400;

pub struct Steer {
    pub active: bool,
    /// Offset being published right now, screen px.
    pub cur_x: f32,
    pub cur_y: f32,
    /// Offset at the start of this ramp. Retained for diagnostics only.
    pub from_x: f32,
    pub from_y: f32,
    /// Offset the chase is heading to. Re-commanding moves this and nothing
    /// else, which is why the motion stays continuous.
    pub to_x: f32,
    pub to_y: f32,
    pub t0: i64,
    pub ramp_ms: i64,
    /// Time of the last tick, for the dt the chase integrates over.
    pub last_ms: i64,
    /// Live time constant, ms. Commandable so the feel can be tuned on the
    /// device instead of recompiled — it is the single knob that decides
    /// whether the aim reads as smooth or as robotic, and that is not a
    /// judgement to bake into a constant.
    pub tau_ms: f32,
    /// Slot of the real contact being steered; -1 when none.
    pub slot: i32,
}

impl Steer {
    pub fn idle() -> Self {
        Steer { active: false, cur_x: 0.0, cur_y: 0.0,
                from_x: 0.0, from_y: 0.0, to_x: 0.0, to_y: 0.0,
                t0: 0, ramp_ms: STEER_MS, last_ms: 0,
                tau_ms: STEER_TAU_MS, slot: -1 }
    }

    /// Point the chase at a NEW total offset.
    ///
    /// Deliberately does not touch `cur_*`: the offset keeps moving from
    /// wherever it is, at whatever speed it had. Only the destination changes.
    pub fn command(&mut self, to_x: f32, to_y: f32, slot: i32, now: i64) {
        self.from_x = self.cur_x;
        self.from_y = self.cur_y;
        self.to_x = to_x;
        self.to_y = to_y;
        self.slot = slot;
        self.t0 = now;
        self.ramp_ms = STEER_MS;
        // Starting fresh: begin the dt clock here, or the first tick would
        // integrate the whole gap since the daemon booted and teleport the
        // offset straight to the target.
        if !self.active {
            self.last_ms = now;
        }
        self.active = true;
    }

    /// Add a delta to the live offset and chase the result, capped.
    ///
    /// This is what the aim actually calls, and the accumulation is
    /// deliberate: the game's look responds to the contact MOVING, so an offset
    /// that stops growing stops turning the view. Each correction therefore
    /// adds to the last rather than replacing it.
    ///
    /// Which is also why the cap is not optional. If the view does not respond
    /// as fast as the aim expects, the residual error never shrinks, every tick
    /// adds more, and the contact is dragged off the panel — the view then
    /// swings at the sky while faithfully "tracking" a target it can no longer
    /// reach.
    ///
    /// Lives here rather than in the daemon's command handler because that
    /// handler has no tests; this is the only place the behaviour can be
    /// pinned down.
    pub fn command_delta(&mut self, dx: f32, dy: f32, cap: f32,
                         slot: i32, now: i64) {
        let cap = if cap > 0.0 { cap } else { 200.0 };
        let mut tx = self.cur_x + dx;
        let mut ty = self.cur_y + dy;
        let mag = (tx * tx + ty * ty).sqrt();
        if mag > cap && mag > 1e-3 {
            // Scale the WHOLE vector. Clamping each axis separately would also
            // respect the cap while silently rotating the target, turning an
            // overshoot on one axis into a miss on the other.
            let k = cap / mag;
            tx *= k;
            ty *= k;
        }
        self.command(tx, ty, slot, now);
    }

    /// Set the chase time constant, clamped to a sane band.
    pub fn set_tau(&mut self, tau_ms: f32) {
        if tau_ms.is_finite() {
            self.tau_ms = tau_ms.clamp(10.0, 400.0);
        }
    }

    /// Ramp back to the finger's real position. The caller drops the steer
    /// only after this reaches zero, so the contact never jumps.
    pub fn release_to_zero(&mut self, now: i64) {
        self.command(0.0, 0.0, self.slot, now);
    }

    /// True once a release ramp has landed.
    pub fn at_zero(&self) -> bool {
        self.cur_x.abs() < 0.5 && self.cur_y.abs() < 0.5
    }

    /// Advance and return the offset to publish, screen px.
    pub fn tick(&mut self, now: i64) -> (f32, f32) {
        if !self.active {
            return (0.0, 0.0);
        }
        // dt is clamped, not trusted. A scheduling hiccup or a daemon that sat
        // idle would otherwise hand the chase a huge dt, alpha would saturate
        // at 1, and the offset would jump the whole remaining distance in one
        // frame -- a snap, which is the exact artefact this module exists to
        // avoid.
        let dt = ((now - self.last_ms).max(0) as f32).min(64.0);
        self.last_ms = now;

        // Guard the divisor: a zero or negative tau from a bad
        // command would make alpha NaN and freeze the offset at
        // NaN forever, which no later good command could recover.
        let tau = if self.tau_ms >= 1.0 { self.tau_ms } else { STEER_TAU_MS };
        let alpha = 1.0 - (-dt / tau).exp();
        self.cur_x += (self.to_x - self.cur_x) * alpha;
        self.cur_y += (self.to_y - self.cur_y) * alpha;
        (self.cur_x, self.cur_y)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The whole point: a new command continues from the CURRENT offset, not
    /// from zero. Restarting at zero is what makes a steer read as a tap.
    #[test]
    fn recommand_continues_from_current_offset() {
        let mut s = Steer::idle();
        s.command(100.0, 0.0, 3, 0);
        s.tick(STEER_MS / 2);
        let mid = s.cur_x;
        assert!(mid > 1.0 && mid < 99.0, "mid-ramp was {mid}");
        s.command(200.0, 0.0, 3, STEER_MS / 2);
        assert_eq!(s.from_x, mid);           // continues, does not snap back
        let (x, _) = s.tick(STEER_MS / 2);
        assert!((x - mid).abs() < 0.001);    // no discontinuity at the seam
    }

    /// Drive the chase at the daemon's real 16 ms cadence.
    fn run(s: &mut Steer, from: i64, ms: i64) -> i64 {
        let mut t = from;
        while t < from + ms {
            t += 16;
            s.tick(t);
        }
        t
    }

    #[test]
    fn chase_converges_on_the_commanded_offset_and_holds() {
        let mut s = Steer::idle();
        s.command(-60.0, 40.0, 1, 0);
        let t = run(&mut s, 0, 400);
        assert!((s.cur_x + 60.0).abs() < 0.5 && (s.cur_y - 40.0).abs() < 0.5,
                "converged to {},{}", s.cur_x, s.cur_y);
        // Holds rather than decaying -- the offset is absolute, and letting it
        // fall back would walk the contact to the finger between updates.
        run(&mut s, t, 1000);
        assert!((s.cur_x + 60.0).abs() < 0.5 && (s.cur_y - 40.0).abs() < 0.5);
    }

    #[test]
    fn release_returns_to_the_real_finger() {
        let mut s = Steer::idle();
        s.command(120.0, -80.0, 2, 0);
        let t = run(&mut s, 0, 300);
        assert!(!s.at_zero());
        s.release_to_zero(t);
        run(&mut s, t, 500);
        assert!(s.at_zero(), "left at {},{}", s.cur_x, s.cur_y);
    }

    /// THE regression this rewrite exists for.
    ///
    /// The old min-jerk ramp ended at zero velocity, so a target re-commanded
    /// on the aim's ~120 ms period produced a dead stop every cycle -- "move,
    /// wait, move, wait". Re-command a moving target the way the aim actually
    /// does and assert the offset is still moving at every single seam.
    #[test]
    fn recommanding_never_stalls_the_motion() {
        let mut s = Steer::idle();
        let mut t = 0i64;
        let mut target = 0.0f32;
        let mut stalls = 0;

        // Six aim updates, each pushing the target 60 px further, exactly as a
        // tracked target walking across the screen would.
        for _ in 0..6 {
            target += 60.0;
            s.command(target, 0.0, 1, t);
            for _ in 0..7 {            // ~112 ms at the 16 ms tick
                let before = s.cur_x;
                t += 16;
                s.tick(t);
                if (s.cur_x - before).abs() < 0.05 {
                    stalls += 1;
                }
            }
        }
        assert_eq!(stalls, 0, "offset stood still on {stalls} ticks");
    }

    /// The aim's real calling pattern: repeated deltas accumulate, because a
    /// held offset stops turning the view.
    #[test]
    fn deltas_accumulate_then_stop_at_the_cap() {
        let mut s = Steer::idle();
        let mut t = 0i64;
        let mut seen = Vec::new();
        for _ in 0..6 {
            s.command_delta(40.0, 0.0, 100.0, 1, t);
            seen.push(s.to_x);
            t = run(&mut s, t, 250);      // let the chase converge
        }
        assert_eq!(seen[0], 40.0);
        assert!((seen[1] - 80.0).abs() < 1.0, "second was {}", seen[1]);
        // Capped from here on, never growing without bound.
        for v in &seen[2..] {
            assert!((v - 100.0).abs() < 1.0, "expected cap 100, got {v}");
        }
    }

    /// The cap must not rotate the aim. Clamping per-axis would keep the
    /// magnitude legal and quietly change the direction.
    #[test]
    fn cap_preserves_direction() {
        let mut s = Steer::idle();
        s.command_delta(300.0, 400.0, 100.0, 1, 0);   // 3-4-5: magnitude 500
        let mag = (s.to_x * s.to_x + s.to_y * s.to_y).sqrt();
        assert!((mag - 100.0).abs() < 0.01, "magnitude {mag}");
        // Same heading as the 300,400 that was asked for.
        assert!((s.to_x - 60.0).abs() < 0.01 && (s.to_y - 80.0).abs() < 0.01,
                "rotated to {},{}", s.to_x, s.to_y);
    }

    /// A delta that would fit is left exactly alone -- the cap is a limiter,
    /// not a scaler applied to every command.
    #[test]
    fn cap_does_not_touch_a_small_delta() {
        let mut s = Steer::idle();
        s.command_delta(12.0, -9.0, 100.0, 1, 0);
        assert_eq!((s.to_x, s.to_y), (12.0, -9.0));
    }

    /// An idle steer must publish nothing, or it would drag an untouched
    /// contact the moment the daemon starts.
    #[test]
    fn idle_publishes_zero() {
        let mut s = Steer::idle();
        assert_eq!(s.tick(1234), (0.0, 0.0));
    }
}
