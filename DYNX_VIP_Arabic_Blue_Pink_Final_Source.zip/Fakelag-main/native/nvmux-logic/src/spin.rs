//! The fire-button steer: hold-to-prove-the-swipe-works.

use crate::*;

/// than mid-match.
pub struct TestSpin {
    pub armed: bool,
    /// Fire circle, screen px.
    pub cx: f32,
    pub cy: f32,
    pub r: f32,
    pub hold_ms: i64,
    /// Running state.
    pub active: bool,
    pub t0: i64,
    pub slot: usize,
    /// True when a REAL contact started this spin. A spin started by command
    /// has no real contact to cancel, and cancelling slot 0 on its behalf would
    /// kill whatever the player happened to be touching.
    pub from_real: bool,
}

impl TestSpin {
    pub fn idle() -> Self {
        TestSpin { armed: false, cx: 0.0, cy: 0.0, r: 0.0,
                   hold_ms: TEST_HOLD_MS_DEFAULT, active: false, t0: 0, slot: 0,
                   from_real: false }
    }

    pub fn contains(&self, x: f32, y: f32) -> bool {
        let dx = x - self.cx;
        let dy = y - self.cy;
        dx * dx + dy * dy <= self.r * self.r
    }

    /// Vertical offset to add to the steered finger, screen px.
    pub fn offset(&self, now: i64, sh: u32) -> f32 {
        let amp = sh as f32 * TEST_AMP_FRAC;
        let phase = ((now - self.t0) as f32 / TEST_PERIOD_MS as f32)
            * core::f32::consts::TAU;
        amp * phase.sin()
    }

    /// Synthetic finger position for this instant, screen px.
    pub fn point(&self, now: i64, sh: u32) -> (f32, f32) {
        let amp = sh as f32 * TEST_AMP_FRAC;
        let phase = ((now - self.t0) as f32 / TEST_PERIOD_MS as f32)
            * core::f32::consts::TAU;
        (self.cx, self.cy + amp * phase.sin())
    }
}
