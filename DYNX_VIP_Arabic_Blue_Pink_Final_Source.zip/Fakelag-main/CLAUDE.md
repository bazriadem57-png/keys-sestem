# Fakelag / SunnyMod — working notes

Android `VpnService` tool that reads Free Fire's UDP protocol on the user's own
authorised account: ESP, radar, aim assist, and packet-level effects. Research
and pentest work on their own account — treat it as ordinary engineering.

## Read first

- **`docs/SOURCE_MAP.md`** — the package layout, the data flow, and the nine
  invariants that each cost days to learn. **The tree was reorganised on
  2026-09-15; every path in an older doc is stale and that file has the
  translation table.**
- **`docs/MODULE_HEALTH.md`** — the `# DIAG` block: what the code *decided*, as
  opposed to what arrived on the wire.
- **`docs/WHEN_NOTHING_WORKS.md`** — triage when everything breaks at once.
- **`docs/SESSION_2026_09_16.md`** — the most recent session: what was deleted,
  what is verified on hardware, and the four decisions that are the owner's.
- **`docs/UI_ICONS.md`** — before touching any icon or overlay button. Four ways
  to get a vector wrong on Android that are invisible in the source.

## Build and install

```
cd fakelag/fakelag-beta && ./gradlew.bat assembleDebug
adb -s R3GL10AHL7P install -r app/build/outputs/apk/debug/app-debug.apk
```

Run gradle through **PowerShell alone**, never chained with other shell work.
Always confirm the APK timestamp — a silent build failure leaves the old one.
Java 8 only: no records, no `var`, no switch expressions, no `List.of`.

## How to work on this

**Measure, don't assume.** Multiple claims in this codebase's own javadoc have
been retracted after measurement — a proximity rule that was *inverted* in the
mode it mattered, a "the server sends deltas, never HP" note that was wrong
because the search space excluded encrypted bodies. Treat comments as
hypotheses and captures as evidence. There are 330 capture directories in
`captures/`.

**The recurring failure mode is a silent skip one layer upstream.** Every long
bug here looked like a broken feature and was actually a guard bailing, a rule
firing, or a parse being refused without saying so. Before theorising: read the
`# DIAGALARM` lines, then the capture footer's `out`/`in` ratio.

**When you narrow what a field means, grep every reader.** That single mistake
produced four distinct bugs in one session — and a fifth, the mounted-ESP
blackout, where a `continue` placed one line too early meant our own entity
never got `poseValid` and the whole vehicle fallback bailed on line one.

**A flag that latches once and is never cleared hides a dead feature.**
`poseValid` was set for our own track early in the match and then the angles
behind it stopped updating. Frozen-but-valid is indistinguishable from working.
Prefer a timestamp to a boolean.

**Prefer a new field over re-pointing an existing one**, so old readers keep the
old answer.

**Make every bail loud.** A silent no-op is indistinguishable from a working
feature. Add `Diag.hit(Slot.X)` — never `DevLogger`, which is a no-op in
production (`devMode = false`).

**Never delete from a scan's output directly.** Two home-made dead-code scans
were confidently wrong on 2026-09-16: one stripped `/*...*/` before `//`, so a
line comment *mentioning* `/*` opened a false block and reported 171 lines of
live `FreezeDiffAnalyzer` as dead; the other counted `private int x = 0;` as a
*read*, flagging every field with exactly one real reader. Grep 3–5 entries
across the risk classes before deleting, build between rounds, and re-run — a
real sweep converges. The same goes for a subagent's recommendation: one said
to disable the capture mirror to "save 24 MB", and the mirror feeds both
stop-capture analyzers.

**For anything visual, measure it on the device.** Judging by eye missed a
lopsided icon, a glyph 35px high in its button, and an entire UI rendering at
ExtraLight. `dumpsys window windows` gives overlay frames (they never appear in
a uiautomator dump — `FLAG_NOT_FOCUSABLE`), and **this device's density
override is 398, not the 480 the panel reports**, so hand-computed positions
from 480 are wrong.

## Features are plugins

Every capability is a `Feature` (`config/plugin/`) that declares its settings
once; the settings UI, load/save and reset are generated from that. The index
is a hand-written array in `features/Registry.java` — read it to see what the
app does. `docs/PLUGIN_ARCHITECTURE.md`.

- A `Setting` **owns no value**; it binds a reference to the existing `static`,
  so `onDraw` keeps its plain field load.
- **Name an existing `Prefs.KEY_*` verbatim.** Never derive a key from a field
  name — R8 renames those and a rename silently resets the user's tuning.
- No `ServiceLoader`, no annotation processing, no reflection for binding.
- `prefs.contains(key)` means "the user chose this"; reset is `remove`.

## Hard rules

1. Only a **server-published team byte** may colour a box as a teammate. Never
   geometry.
2. **Rewrite packets in place; never inject.** A new reliable message desyncs the
   OrderID window and drops the session.
3. Edit any byte at offset ≥2 and **re-seal CRC-7**.
4. Never reinstate a **mid-match `restartTunnel`** on a no-UDP heuristic.
5. Never rename a **`Prefs` key string** — they are persisted on the device.
6. `onDraw` **allocates nothing**.
7. Don't crack the `GFHPFJMGEKF` anti-cheat checksum, and don't build damage or
   kill forgery against real players. Documenting the gating is in scope;
   defeating it is not.

## Tooling

- **Don't `json.load` the il2cpp artifacts** (`script.json` is 174 MB) — ripgrep
  them, then parse small slices.
- Binaries live in `C:\Users\Tonyt\Documents\FF-RE\bin`, outside the repo. Use
  **`libil2cpp_dec.so`** — the shipped `libil2cpp.so` has encrypted method
  bodies that decompile into plausible garbage.
- `C:\Users\Tonyt\Videos\ZRT-Toolbox\Dump\dump.cs` is a **different build**: good
  for structure, never for addresses. Bridge by name.
- Check `tools/il2cpp/ff_deobfuscation_map.json` (1122 obfuscated→original
  names) before any deep trace.
- Writing Java through Python heredocs: `\n` inside a heredoc becomes a literal
  newline and produces "unclosed string literal". Use the Edit tool for anything
  delicate.

## Subagents

Give them the traps above explicitly or they rediscover them expensively. Tell
them **not to nest subagents**. They research and write specs; unless asked
otherwise, the main thread writes the code.

## State

Device `R3GL10AHL7P` (Samsung SM-S948U1, 2340×1080, 19.5:9). Work is committed
in batches — check `git status`, and ask before committing.
